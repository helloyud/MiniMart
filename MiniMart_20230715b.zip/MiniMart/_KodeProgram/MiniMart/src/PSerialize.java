import java.util.Date;

public class PSerialize {
 
 static OGregorianCalendar cal=new OGregorianCalendar();
 
 public static byte[] serString(String Str){
  byte[] ret;
  int temp, temp_;
  if(Str==null){return null;}
  temp=Str.length();
  ret=new byte[temp];
  if(temp!=0){
   temp_=0;
   do{
    ret[temp_]=(byte)Str.charAt(temp_);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
  return ret;
 }
 public static String deserString(byte[] Bytes){
  char[] ret;
  int temp, temp_;
  
  if(Bytes==null){return null;}
  
  temp=Bytes.length;
  if(temp==0){return "";}
  
  ret=new char[temp];
  temp_=0;
  do{
   ret[temp_]=(char)Bytes[temp_];
   temp_=temp_+1;
  }while(temp_!=temp);
  
  return new String(ret);
 }
 public static byte[] serInt(int I){
  byte[] ret=new byte[4];
  int temp=I;
  ret[3]=(byte)temp;
  temp=temp >>> 8;
  ret[2]=(byte)temp;
  temp=temp >>> 8;
  ret[1]=(byte)temp;
  temp=temp >>> 8;
  ret[0]=(byte)temp;
  return ret;
 }
 public static Integer deserInt(byte[] Bytes){
  int ret=0x00000000;
  int temp;
  if(Bytes==null){return null;}
  if(Bytes.length!=4){return null;}
  temp=(((int)Bytes[0]) << 24);
  ret=ret|temp;
  temp=(((int)Bytes[1]) << 16)&0x00ff0000;
  ret=ret|temp;
  temp=(((int)Bytes[2]) << 8)&0x0000ff00;
  ret=ret|temp;
  temp=((int)Bytes[3])&0x000000ff;
  ret=ret|temp;
  return ret;
 }
 public static byte[] serByte(byte B){
  byte[] ret=new byte[1];
  ret[0]=B;
  return ret;
 }
 public static Byte deserByte(byte[] Bytes){
  byte ret=0;
  if(Bytes==null){return null;}
  if(Bytes.length!=1){return null;}
  ret=Bytes[0];
  return ret;
 }
 public static byte[] serLong(long L){
  byte[] ret=new byte[8];
  long temp=L;
  ret[7]=(byte)temp;
  temp=temp >>> 8;
  ret[6]=(byte)temp;
  temp=temp >>> 8;
  ret[5]=(byte)temp;
  temp=temp >>> 8;
  ret[4]=(byte)temp;
  temp=temp >>> 8;
  ret[3]=(byte)temp;
  temp=temp >>> 8;
  ret[2]=(byte)temp;
  temp=temp >>> 8;
  ret[1]=(byte)temp;
  temp=temp >>> 8;
  ret[0]=(byte)temp;
  return ret;
 }
 public static Long deserLong(byte[] Bytes){
  long ret=0x00000000_00000000L;
  long temp;
  if(Bytes==null){return null;}
  if(Bytes.length!=8){return null;}
  temp=(((long)Bytes[0]) << 56);
  ret=ret|temp;
  temp=(((long)Bytes[1]) << 48)&0x00ff0000_00000000L;
  ret=ret|temp;
  temp=(((long)Bytes[2]) << 40)&0x0000ff00_00000000L;
  ret=ret|temp;
  temp=(((long)Bytes[3]) << 32)&0x000000ff_00000000L;
  ret=ret|temp;
  temp=(((long)Bytes[4]) << 24)&0x00000000_ff000000L;
  ret=ret|temp;
  temp=(((long)Bytes[5]) << 16)&0x00000000_00ff0000L;
  ret=ret|temp;
  temp=(((long)Bytes[6]) << 8)&0x00000000_0000ff00L;
  ret=ret|temp;
  temp=((long)Bytes[7])&0x00000000_000000ffL;
  ret=ret|temp;
  return ret;
 }
 public static byte[] serDouble(double D){
  byte[] ret=new byte[8];
  long temp=Double.doubleToLongBits(D);
  ret[7]=(byte)temp;
  temp=temp >>> 8;
  ret[6]=(byte)temp;
  temp=temp >>> 8;
  ret[5]=(byte)temp;
  temp=temp >>> 8;
  ret[4]=(byte)temp;
  temp=temp >>> 8;
  ret[3]=(byte)temp;
  temp=temp >>> 8;
  ret[2]=(byte)temp;
  temp=temp >>> 8;
  ret[1]=(byte)temp;
  temp=temp >>> 8;
  ret[0]=(byte)temp;
  return ret;
 }
 public static Double deserDouble(byte[] Bytes){
  long ret=0x00000000_00000000L;
  long temp;
  if(Bytes==null){return null;}
  if(Bytes.length!=8){return null;}
  temp=(((long)Bytes[0]) << 56);
  ret=ret|temp;
  temp=(((long)Bytes[1]) << 48)&0x00ff0000_00000000L;
  ret=ret|temp;
  temp=(((long)Bytes[2]) << 40)&0x0000ff00_00000000L;
  ret=ret|temp;
  temp=(((long)Bytes[3]) << 32)&0x000000ff_00000000L;
  ret=ret|temp;
  temp=(((long)Bytes[4]) << 24)&0x00000000_ff000000L;
  ret=ret|temp;
  temp=(((long)Bytes[5]) << 16)&0x00000000_00ff0000L;
  ret=ret|temp;
  temp=(((long)Bytes[6]) << 8)&0x00000000_0000ff00L;
  ret=ret|temp;
  temp=((long)Bytes[7])&0x00000000_000000ffL;
  ret=ret|temp;
  return Double.longBitsToDouble(ret);
 }
 public static byte[] serBoolean(boolean Bool){
  byte[] ret=new byte[1];
  if(Bool==true){ret[0]=1;}
  else{ret[0]=0;}
  return ret;
 }
 public static Boolean deserBoolean(byte[] Bytes){
  boolean ret=false;
  if(Bytes==null){return null;}
  if(Bytes.length!=1){return null;}
  if(Bytes[0]==1){ret=true;}
  return ret;
 }
 public static byte[] serDate(Date Dt){
  if(Dt==null){return null;}
  cal.setNewTime(Dt);
  return serLong(cal.getTimeInMillis());
 }
 public static Date deserDate(byte[] Bytes){
  Long ret=deserLong(Bytes);
  if(ret==null){return null;}
  cal.setNewTimeInMillis(ret);
  return cal.getTime();
 }
 
 public static byte[] ser(int ValueType, Object Value){
  byte[] ret=null;
  if(Value==null){return ret;}
  switch(ValueType){
   case CCore.TypeBoolean : ret=serBoolean((Boolean)Value); break;
   case CCore.TypeInteger : ret=serInt((Integer)Value); break;
   case CCore.TypeLong : ret=serLong((Long)Value); break;
   case CCore.TypeDouble : ret=serDouble((Double)Value); break;
   case CCore.TypeString : ret=serString((String)Value); break;
   case CCore.TypeDate : ret=serDate((Date)Value); break;
  }
  return ret;
 }
 public static Object deser(int ValueType, byte[] Bytes){
  Object ret=null;
  switch(ValueType){
   case CCore.TypeBoolean : ret=deserBoolean(Bytes); break;
   case CCore.TypeInteger : ret=deserInt(Bytes); break;
   case CCore.TypeLong : ret=deserLong(Bytes); break;
   case CCore.TypeDouble : ret=deserDouble(Bytes); break;
   case CCore.TypeString : ret=deserString(Bytes); break;
   case CCore.TypeDate : ret=deserDate(Bytes); break;
  }
  return ret;
 }
 public static Object deser(int ValueType, Object Bytes){
  byte[] data=null; if(Bytes!=null){data=(byte[])Bytes;}
  return deser(ValueType, data);
 }
 
}