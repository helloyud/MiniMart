import java.util.Vector;

public class OCsvImportValuesInColsAndValues extends OCsvImportValues {

 public OCsvImportValuesInColsAndValues(){}
 public OCsvImportValuesInColsAndValues(Vector<String> Separators,
  Vector<String> Columns, Vector<String> OperatorBetweenColumnAndColumnValue, Vector<OCsvImportValue> ColumnsValue) {
  initVariables(Separators, Columns, OperatorBetweenColumnAndColumnValue, ColumnsValue);
 }
 
 void initVariables(Vector<String> Separators,
  Vector<String> Columns, Vector<String> OperatorBetweenColumnAndColumnValue, Vector<OCsvImportValue> ColumnsValue){
  Vector<OCsvImportValue> Values;
  int temp, length;
  length=Columns.size();
  Values=new Vector();
  temp=0;
  do{
   Values.addElement(new OCsvImportValueColAndValue(Columns.elementAt(temp), OperatorBetweenColumnAndColumnValue.elementAt(temp), ColumnsValue.elementAt(temp)));
   temp=temp+1;
  }while(temp!=length);
  super.initVariables(Separators, Values);
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile) {super.prepareGenerateSQLValue(LastReadRecordFromFile);}
 
}