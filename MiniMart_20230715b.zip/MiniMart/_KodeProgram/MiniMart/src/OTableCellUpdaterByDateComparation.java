import java.util.Date;
import java.util.Vector;

public class OTableCellUpdaterByDateComparation
 extends OTableCellUpdater{
	
	Date DateComparation;
	int ComparationMode; // 1 Min, 2 Max

	public OTableCellUpdaterByDateComparation(int TableColumnIndex,
		Date DateComparation, int ComparationMode) {
		init(TableColumnIndex);
		this.DateComparation = DateComparation;
		this.ComparationMode = ComparationMode;
	}

	public void update(int TableRowIndex) {
		Vector<Object[]> Data=getRows();
		Date ColValue;
		
		ColValue=PCore.objDate(Data.elementAt(TableRowIndex)[TableColumnIndex], null);
		
		switch(ComparationMode){
			case 1 : if(PDate.grading(ColValue, DateComparation, Long.MAX_VALUE)==1){ColValue=DateComparation;} break;
			case 2 : if(PDate.grading(ColValue, DateComparation, Long.MIN_VALUE)==2){ColValue=DateComparation;} break;
		}
		
		Data.elementAt(TableRowIndex)[TableColumnIndex]=ColValue;
	}

}