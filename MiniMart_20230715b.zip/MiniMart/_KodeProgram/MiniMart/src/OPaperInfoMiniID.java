public class OPaperInfoMiniID {
 
 int DigitSeries;
 int RowsCount;
 int ColumnsCount;
 boolean IsRotated;

 public OPaperInfoMiniID(int DigitSeries, int RowsCount, int ColumnsCount, boolean IsRotated) {
  this.DigitSeries=DigitSeries;
  this.RowsCount = RowsCount;
  this.ColumnsCount = ColumnsCount;
  this.IsRotated = IsRotated;
 }
 
}