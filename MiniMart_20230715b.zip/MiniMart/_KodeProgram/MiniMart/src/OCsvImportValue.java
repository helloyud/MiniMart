import java.util.Vector;

public abstract class OCsvImportValue {
 
 Vector<String> LastReadRecordFromFile;

 public void setLastRecordFromFile(Vector<String> LastReadRecordFromFile){this.LastReadRecordFromFile=LastReadRecordFromFile;}
 
 public void preGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  setLastRecordFromFile(LastReadRecordFromFile);
 }
 
 public abstract void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile);
 public abstract OGeneratedSQLValue generateSQLValue();

}