public abstract class OInput {
 
 public abstract boolean isValid();
 public abstract Object getValue();

}