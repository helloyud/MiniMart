public class OBarcodePatternsSpecification {

 double ModuleWidth;
 double ModuleHeight;
 int ModulePixelCount;
 int QuietZoneLeftModuleCount;
 int QuietZoneRightModuleCount;

 public OBarcodePatternsSpecification(double ModuleWidth, double ModuleHeight, int ModulePixelCount,
  int QuietZoneLeftModuleCount, int QuietZoneRightModuleCount) {
  this.ModuleWidth=ModuleWidth;
  this.ModuleHeight=ModuleHeight;
  this.ModulePixelCount = ModulePixelCount;
  this.QuietZoneLeftModuleCount = QuietZoneLeftModuleCount;
  this.QuietZoneRightModuleCount = QuietZoneRightModuleCount;
 }

}