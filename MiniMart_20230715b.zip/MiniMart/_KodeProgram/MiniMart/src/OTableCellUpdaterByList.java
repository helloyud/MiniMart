import java.util.Vector;

public class OTableCellUpdaterByList
 extends OTableCellUpdater{

 int[] TableLookupColumnIndex;
 
 OCustomModel List;
 int[] ListLookupColumnIndex;
 int ListUpdateColumnIndex;
 
 boolean IfLookupNotFound_IsUpdate;
 Object IfLookupNotFound_UpdateValue;
 
 public OTableCellUpdaterByList(int TableColumnIndex,
  int[] TableLookupColumnIndex,
  OCustomModel List, int[] ListLookupColumnIndex, int ListUpdateColumnIndex,
  boolean IfLookupNotFound_IsUpdate, Object IfLookupNotFound_UpdateValue){
  init(TableColumnIndex);
  this.TableLookupColumnIndex=TableLookupColumnIndex;
  this.List=List;
  this.ListLookupColumnIndex=ListLookupColumnIndex;
  this.ListUpdateColumnIndex=ListUpdateColumnIndex;
  this.IfLookupNotFound_IsUpdate=IfLookupNotFound_IsUpdate;
  this.IfLookupNotFound_UpdateValue=IfLookupNotFound_UpdateValue;
 }
 
 public void update(int TableRowIndex){
  int found_index;
  Object[] CurrRow;
  Vector<Object[]> Data=getRows();
  
  // lookup in list
  found_index=-1;
  CurrRow=Data.elementAt(TableRowIndex);
  if(CurrRow!=null){
   found_index=PTable.findData(ColumnsType, false, List.getRows(), ListLookupColumnIndex, CurrRow, TableLookupColumnIndex);
  }
  
  // update
  if(found_index==-1){
   if(IfLookupNotFound_IsUpdate){Data.elementAt(TableRowIndex)[TableColumnIndex]=IfLookupNotFound_UpdateValue;}
  }
  else{Data.elementAt(TableRowIndex)[TableColumnIndex]=List.getRows().elementAt(found_index)[ListUpdateColumnIndex];}
 }
 
}