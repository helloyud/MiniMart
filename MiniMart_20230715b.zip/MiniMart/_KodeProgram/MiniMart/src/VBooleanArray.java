public class VBooleanArray {
 
 boolean[] Value;
 
 public VBooleanArray(){}
 public VBooleanArray(boolean[] Value){this.Value=Value;}
 
}