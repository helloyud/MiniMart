import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.AffineTransform;
import java.util.Vector;

public class OLabelCreatorItemPriceTag extends OLabelCreatorItem {
 
 
 
 
 
 // Ideal label size (in pixel)
 public static final double IdealLabelWidth  = OUnit.mm_to_pixel(44);
 public static final double IdealLabelHeight = OUnit.mm_to_pixel(25);
 
 double Area1_X, Area1_Width;
 
 Font FonItemId;
 double Id_asc, Id_desc, Id_h, Id_w;
 final int ItemIdColumn = 13+1;
 double ItemIdY;
 double ItemIdAreaHeight;
 
 double SeparatorLineIdX;
 
 double Area2_X, Area2_Width;
 
 Font FonItemName;
 double Name_asc, Name_desc, Name_h, Name_w;
 final int ItemNameColumnMax=55;
 final  int MinimalItemNameFitFixedTop = 1;
 final int MinimalItemNameLineCount = 2;
 final int MaximalItemNameLineCount = 4;
 int ItemNameLineCount, ItemNameColumn, ItemNameFitFixedTop, ItemNameFitFixedRight;
 double ItemNameY;
 double NameAreaHeight;
 
 double SeparatorLineNameY;
 
 Font FonItemPrice;
 double Price_asc, Price_desc, Price_h, Price_w;
 final int ItemPriceColumn = 8;
 double ItemPriceY;
 
 final double SpaceBetweenFontContent = OUnit.mm_to_pixel(0.6);
 
 Font FonPromo;
 double Promo_asc, Promo_desc, Promo_h, Promo_w;
 final int MinimalPromoFitFixedTop = 1;
 final int MinimalPromoLineCount = 1;
 final int MaximalPromoLineCount = 2;
 int PromoLineCount, PromoColumn, PromoFitFixedTop, PromoFitFixedRight;
 double PromoY;
 double PromoAreaHeight;

 
 
 
 
 public OLabelCreatorItemPriceTag(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher) {
  
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  BoxWidthMin=
   2*MarginHorizontal+
   Id_h+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   PCore.getMinMax_Double(false, PCore.refArr(ItemPriceColumn*Price_w));
  
  BoxHeightMin=
   2*MarginVertical+
   PCore.getMinMax_Double(false, PCore.refArr(
    
    ItemIdColumn*Id_w,
    
    MinimalItemNameLineCount*Name_h+(MinimalItemNameLineCount-1)*TextLineSpacing+
    SpaceToLine+
    LineWidth+
    SpaceToLine+
    Price_h+
    SpaceBetweenFontContent+
    MinimalPromoLineCount*Promo_h+(MinimalPromoLineCount-1)*TextLineSpacing
    
   ));
 }
 protected void initDrawComponentsVariables(){
  super.initDrawComponentsVariables();
  TextLineSpacing=OUnit.mm_to_pixel(0.3);
 }
 protected String getName(){return "Price Tag) Normal";}
 protected void initFontVariables(){
  FontRenderContext Frc;
  LineMetrics lmetric;
  
  Frc=new FontRenderContext(new AffineTransform(), true, true);
  
  FonItemId=PFont.getFont(FontCustom.FontFamily, FontCustom.getPointSize(FontStandard, 8.5f), false, false);
  Id_w=FonItemId.getStringBounds("W", Frc).getWidth();
  lmetric=FonItemId.getLineMetrics("Wg", Frc);
  Id_asc=lmetric.getAscent();
  Id_desc=lmetric.getDescent();
  Id_h=Id_asc+Id_desc;
  
  FonItemName=PFont.getFont(FontCustom.FontFamily, FontCustom.getPointSize(FontStandard, 9.5f), false, false);
  Name_w=FonItemName.getStringBounds("W", Frc).getWidth();
  lmetric=FonItemName.getLineMetrics("Wg", Frc);
  Name_asc=lmetric.getAscent();
  Name_desc=lmetric.getDescent();
  Name_h=Name_asc+Name_desc;
  
  FonItemPrice=PFont.getFont(FontCustom.FontFamily, FontCustom.getPointSize(FontStandard, 16.0f), false, false);
  Price_w=FonItemPrice.getStringBounds("W", Frc).getWidth();
  lmetric=FonItemPrice.getLineMetrics("Wg", Frc);
  Price_asc=lmetric.getAscent();
  Price_desc=lmetric.getDescent();
  Price_h=Price_asc+Price_desc;
  
  FonPromo=PFont.getFont(FontCustom.FontFamily, FontCustom.getPointSize(FontStandard, 8.5f), false, true);
  Promo_w=FonPromo.getStringBounds("W", Frc).getWidth();
  lmetric=FonPromo.getLineMetrics("Wg", Frc);
  Promo_asc=lmetric.getAscent();
  Promo_desc=lmetric.getDescent();
  Promo_h=Promo_asc+Promo_desc;
 }
 
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  OPaper papr;
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth, IdealLabelHeight, 0, 0, 0, true, true, true, true, false));
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 1-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return false;}
 protected boolean isLabelRotatedInternalPaper(){return false;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 protected boolean genLayoutVariables(){
  boolean ret=true;
  double dbl;
  
  dbl=LabelHeight-(
   2*MarginVertical+
   MinimalItemNameLineCount*Name_h+(MinimalItemNameLineCount-1)*TextLineSpacing+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   Price_h+
   SpaceBetweenFontContent+
   MinimalPromoLineCount*Promo_h+(MinimalPromoLineCount-1)*TextLineSpacing);
  if(dbl<0){return false;}
  ItemNameLineCount=MinimalItemNameLineCount+(int)(dbl/(TextLineSpacing+Name_h));
  if(ItemNameLineCount>MaximalItemNameLineCount){ItemNameLineCount=MaximalItemNameLineCount;}
  
  dbl=LabelHeight-(
   2*MarginVertical+
   ItemNameLineCount*Name_h+(ItemNameLineCount-1)*TextLineSpacing+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   Price_h+
   SpaceBetweenFontContent+
   MinimalPromoLineCount*Promo_h+(MinimalPromoLineCount-1)*TextLineSpacing);
  PromoLineCount=MinimalPromoLineCount+(int)(dbl/(TextLineSpacing+Promo_h));
  if(PromoLineCount>MaximalPromoLineCount){PromoLineCount=MaximalPromoLineCount;}
  
  BoxHeight=
   2*MarginVertical+
   ItemNameLineCount*Name_h+(ItemNameLineCount-1)*TextLineSpacing+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   Price_h+
   SpaceBetweenFontContent+
   PromoLineCount*Promo_h+(PromoLineCount-1)*TextLineSpacing;
  
  BoxWidth=
   2*MarginHorizontal+
   Id_h+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   ItemNameColumnMax*Name_w;
  if(BoxWidth>LabelWidth){BoxWidth=LabelWidth;}
  
  Area1_X=MarginHorizontal;
  Area1_Width=Id_h;
  
  ItemIdY=MarginVertical;
  ItemIdAreaHeight=BoxHeight-(2*MarginVertical);
  
  SeparatorLineIdX=Area1_X+Area1_Width+SpaceToLine;
  
  Area2_X=SeparatorLineIdX+LineWidth+SpaceToLine;
  Area2_Width=BoxWidth-(Area2_X+MarginHorizontal);
  
  ItemNameColumn=(int)(Area2_Width/Name_w);
  ItemNameFitFixedTop=(int)(0.5*ItemNameLineCount); if(ItemNameFitFixedTop<MinimalItemNameFitFixedTop){ItemNameFitFixedTop=MinimalItemNameFitFixedTop;}
  ItemNameFitFixedRight=(int)(0.7*ItemNameColumn);
  ItemNameY=MarginVertical;
  NameAreaHeight=ItemNameLineCount*Name_h+(ItemNameLineCount-1)*TextLineSpacing;
  
  PromoColumn=(int)(Area2_Width/Promo_w);
  PromoFitFixedTop=PromoLineCount/2; if(PromoFitFixedTop<MinimalPromoFitFixedTop){PromoFitFixedTop=MinimalPromoFitFixedTop;}
  PromoFitFixedRight=(int)(0.7*PromoColumn);
  PromoAreaHeight=PromoLineCount*Promo_h+(PromoLineCount-1)*TextLineSpacing;
  PromoY=BoxHeight-(MarginVertical+PromoAreaHeight);
  
  ItemPriceY=PromoY-(SpaceBetweenFontContent+Price_h);
  
  SeparatorLineNameY=(ItemNameY+NameAreaHeight)+(((ItemPriceY-(ItemNameY+NameAreaHeight))/2)-(LineWidth/2));
  
  return ret;
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  OLabelDataItem Data;
  Stroke strok;
  OBarcodePatterns patt;
  String str;
  Vector<String> strv=null;
  int temp, count;
  double CurrY;
  
  Data=(OLabelDataItem)LabelData;
  
  g.setFont(FonItemId);
  str="#"+Data.ItemId;
  PGraphics.paintImageInBox(g, Scaled_BoxX+Area1_X, Scaled_BoxY+ItemIdY, PGraphics.getImageString(str, FonItemId, Scaling*AlreadyScaled),
   true, null, 1, CGraph.Rotate_090Degree, Area1_Width, ItemIdAreaHeight, null, false);
  
  strok=g.getStroke();
  g.setStroke(new BasicStroke((float)LineWidth));
  g.drawLine(PMath.round(Scaled_BoxX+SeparatorLineIdX, 0), PMath.round(0, 0),
   PMath.round(Scaled_BoxX+SeparatorLineIdX, 0), PMath.round(Scaled_LabelHeight, 0));
  g.setStroke(strok);
  
  g.setFont(FonItemName);
  if(ItemNameLineCount==1){
   strv=PCore.vect(PText.fitString(Data.ItemName, ItemNameColumn, false, ItemNameFitFixedRight, 1, '~'));
  }
  else{
   strv=PText.fitMultiLine(
    PText.multiLine(Data.ItemName, ItemNameColumn), ItemNameLineCount, true, ItemNameFitFixedTop,
    ItemNameColumn, false, ItemNameFitFixedRight, 1, '~');
  }
  count=strv.size();
  CurrY=ItemNameY+PGraphics.getInsetY(NameAreaHeight, FonItemName, count, TextLineSpacing, OAlignment.VerticalCenter);
  temp=0;
  do{
   if(temp!=0){CurrY=CurrY+TextLineSpacing;}

   str=strv.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+Area2_X+PGraphics.getInsetX(Area2_Width, FonItemName, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+Name_asc));
   CurrY=CurrY+Name_h;

   temp=temp+1;
  }while(temp!=count);
  
  strok=g.getStroke();
  g.setStroke(new BasicStroke((float)LineWidth));
  g.drawLine(PMath.round(Scaled_BoxX+SeparatorLineIdX, 0), PMath.round(Scaled_BoxY+SeparatorLineNameY, 0),
   PMath.round(Scaled_LabelWidth, 0), PMath.round(Scaled_BoxY+SeparatorLineNameY, 0));
  g.setStroke(strok);
  
  g.setFont(FonItemPrice);
  str=PText.priceToString(Data.ItemSellPrice);
  g.drawString(str, (float)(Scaled_BoxX+Area2_X+PGraphics.getInsetX(Area2_Width, FonItemPrice, str, OAlignment.HorizontalRight)), (float)(Scaled_BoxY+ItemPriceY+Price_asc));
  
  g.setFont(FonPromo);
  if(PromoLineCount==1){
   strv=PCore.vect(PText.fitString(Data.PromoComment, PromoColumn, false, PromoFitFixedRight, 1, '~'));
  }
  else{
   strv=PText.fitMultiLine(
    PText.multiLine(Data.PromoComment, PromoColumn), PromoLineCount, true, PromoFitFixedTop,
    PromoColumn, false, PromoFitFixedRight, 1, '~');
  }
  count=strv.size();
  CurrY=PromoY+PGraphics.getInsetY(PromoAreaHeight, FonPromo, count, TextLineSpacing, OAlignment.VerticalCenter);
  temp=0;
  do{
   if(temp!=0){CurrY=CurrY+TextLineSpacing;}

   str=strv.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+Area2_X+PGraphics.getInsetX(Area2_Width, FonPromo, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+Promo_asc));
   CurrY=CurrY+Promo_h;

   temp=temp+1;
  }while(temp!=count);
 }
 
 
 
 
 
}