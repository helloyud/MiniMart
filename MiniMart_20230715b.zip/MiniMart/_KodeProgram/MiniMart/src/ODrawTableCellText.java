import java.awt.Font;
import java.util.Vector;

public class ODrawTableCellText extends ODrawTableCell {
	
 String Word;
 Font FontType;
 double AddLineSpacing;
 OAlignment Alignment;
 
 boolean FitLine;
 
 int FitLineCount; boolean FitLineFixedTopSide; int FitLineFixedSideCount;
 
 boolean ConcatenateFixedLeftSide;
 double ConcatenateFixedSidePercentage;
 int ConcatenateDotCount;
 char ConcatenateDotChar;
 
 Vector<String> ProcessedWord;

 public ODrawTableCellText(String Word, Font FontType, double AddLineSpacing, OAlignment Alignment){
  this(Word, FontType, AddLineSpacing, Alignment,
   false, 0, true, 0,
   true, 0, 0, '~');
 }
 public ODrawTableCellText(String Word, Font FontType, double AddLineSpacing, OAlignment Alignment,
  boolean FitLine, int FitLineCount, boolean FitLineFixedTopSide, int FitLineFixedSideCount,
  boolean ConcatenateFixedLeftSide, double ConcatenateFixedSidePercentage, int ConcatenateDotCount, char ConcatenateDotChar){
  init(Word, FontType, AddLineSpacing, Alignment,
   FitLine, FitLineCount, FitLineFixedTopSide, FitLineFixedSideCount,
   ConcatenateFixedLeftSide, ConcatenateFixedSidePercentage, ConcatenateDotCount, ConcatenateDotChar);
 }
 public void init(String Word, Font FontType, double AddLineSpacing, OAlignment Alignment,
  boolean FitLine, int FitLineCount, boolean FitLineFixedTopSide, int FitLineFixedSideCount,
  boolean ConcatenateFixedLeftSide, double ConcatenateFixedSidePercentage, int ConcatenateDotCount, char ConcatenateDotChar){
  super.init();
  
  this.Word=Word;
  this.FontType=FontType;
  this.AddLineSpacing=AddLineSpacing;
  this.Alignment=Alignment;
  
  this.FitLine=FitLine;
  this.FitLineCount=FitLineCount;
  this.FitLineFixedTopSide=FitLineFixedTopSide;
  this.FitLineFixedSideCount=FitLineFixedSideCount;
  
  this.ConcatenateFixedLeftSide=ConcatenateFixedLeftSide;
  this.ConcatenateDotCount=ConcatenateDotCount;
  this.ConcatenateFixedSidePercentage=ConcatenateFixedSidePercentage;
  this.ConcatenateDotChar=ConcatenateDotChar;
 }
	
 public boolean preGenerateDrawContents(ODrawTable InsertToTable, int InsertToRowIndex, int InsertToColumnIndex, ODrawTableRow NewRow){
  boolean ret=false;
  int MaxChar;
  int ConcatenateFixedSideCount;
  
  do{
   MaxChar=PGraphics.getCharCountAtAreaWidth(FontType, InsertToTable.Columns[InsertToColumnIndex].Width-(InsertToTable.Inset.InsetLeft+InsertToTable.Inset.InsetRight));
   if(MaxChar==0){break;}
   
   ConcatenateFixedSideCount=(int)(ConcatenateFixedSidePercentage*MaxChar);
   if(ConcatenateFixedSideCount<=0){ConcatenateFixedSideCount=1;}
   if(ConcatenateFixedSideCount+ConcatenateDotCount>MaxChar){ConcatenateFixedSideCount=MaxChar-ConcatenateDotCount;}
   if(FitLine && ConcatenateFixedSideCount<=0){break;}
   
   if(FitLine && FitLineCount==1){
    ProcessedWord=PCore.vect(PText.fitString(PText.getString(Word, "", false), MaxChar, ConcatenateFixedLeftSide, ConcatenateFixedSideCount, ConcatenateDotCount, ConcatenateDotChar));
   }
   else{
    ProcessedWord=PText.multiLine(Word, MaxChar);
    if(FitLine){
     ProcessedWord=PText.fitMultiLine(ProcessedWord, FitLineCount, FitLineFixedTopSide, FitLineFixedSideCount,
      MaxChar, ConcatenateFixedLeftSide, ConcatenateFixedSideCount, ConcatenateDotCount, ConcatenateDotChar);
    }
   }
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public ODimension calculatePreGeneratedDrawContentsDimension(ODrawTable InsertToTable, int InsertToRowIndex, int InsertToColumnIndex, ODrawTableRow NewRow){
  ODimension ret=null;
  
  if(ProcessedWord==null){ret=new ODimension(0, 0);}
  else{ret=PGraphics.getDimension(FontType, ProcessedWord.size(), PText.getMinMaxChars(false, ProcessedWord), 0, 0, AddLineSpacing);}
  
  return ret;
 }
	public void generateDrawContents(ODrawTable InsertToTable, int InsertToRowIndex, int InsertToColumnIndex, ODrawTableRow NewRow){
  Contents.addElement(new ODrawComponentText(0, 0, FontType, ProcessedWord,
   InsertToTable.Columns[InsertToColumnIndex].Width-(InsertToTable.Inset.InsetLeft+InsertToTable.Inset.InsetRight),
   NewRow.Height-(InsertToTable.Inset.InsetTop+InsertToTable.Inset.InsetBottom),
   AddLineSpacing, Alignment));
 }
	
}