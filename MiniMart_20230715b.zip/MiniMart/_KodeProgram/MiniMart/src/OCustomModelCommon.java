import java.sql.ResultSetMetaData;
import java.util.Vector;

public class OCustomModelCommon implements OCustomModel{
 
 public static final int ShowOptionNormal=0;
 public static final int ShowOptionObject=1;
 
 OCustomModel ParentModel;
 
 Vector<Object[]> Rows;
 
 boolean EnableCheck;
 boolean CheckEditable;
 Vector<Boolean> Checked;
 boolean CheckDefaultNewValue;
 int CheckedCount;
 
 boolean EnableIndex;
 OQuickListOfLong Index;
 int IndexColumn;

 // set
 int[] ColumnsType;
 int ColumnsCount;
 
 void init(OCustomModel ParentModel, boolean EnableCheck, boolean CheckDefaultNewValue, boolean CheckEditable,
  boolean EnableIndex, int IndexColumn){
  this.ParentModel=ParentModel;
  
  Rows=new Vector<Object[]>();
  
  this.EnableCheck=EnableCheck;
  this.CheckDefaultNewValue=CheckDefaultNewValue;
  this.CheckEditable=CheckEditable;
  if(EnableCheck){
   Checked=new Vector<Boolean>();
   CheckedCount=0;
  }
  
  this.EnableIndex=EnableIndex;
  this.IndexColumn=IndexColumn;
  if(EnableIndex){
   Index=new OQuickListOfLong(1024, 1024, false, true);
  }
 }
 
 // metadata methods
	public int getColumnsCount(){return ColumnsType.length;}
 public int[] getColumnsType(){return ColumnsType;}
 public void updateColumnsInfo(ResultSetMetaData RsM) throws Exception{ParentModel.updateColumnsInfo(RsM);}
 
 // data methods
 public Vector<Object[]> getRows(){return Rows;}
 public void insert_(int RowIndex, Object[] NewData,
  int Data_AddMode, int[] Data_ByCustomCols,
  int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  int colcount, coltemp;
  Object[] ARow=null;
  boolean ARow_CheckValue=false;
  
  switch(Data_AddMode){
   case 2 :
    colcount=Data_ByCustomCols.length;
    ARow=new Object[colcount];

    coltemp=0;
    do{
     ARow[coltemp]=NewData[Data_ByCustomCols[coltemp]];
     coltemp=coltemp+1;
    }while(coltemp!=colcount);

    break;
   default : ARow=NewData; break;
  }

  switch(Check_AddMode){
   case 1 : ARow_CheckValue=Check_ByValue; break;
   case 2 : ARow_CheckValue=PCore.objBoolean(NewData[Check_ByDataCol], false); break;
   default : ARow_CheckValue=CheckDefaultNewValue; break;
  }

  Rows.insertElementAt(ARow, RowIndex);
  if(EnableCheck){
   Checked.insertElementAt(ARow_CheckValue, RowIndex);
   if(ARow_CheckValue){CheckedCount=CheckedCount+1;}
  }
  if(EnableIndex){
   Index.addAt(RowIndex, Index.getValueObject(ColumnsType[IndexColumn], ARow[IndexColumn]));
  }
 }
 public void insert(int RowIndex, Object[] NewRow,
  int Data_AddMode, int[] Data_ByCustomCols,
  int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  insert_(RowIndex, NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
  refreshInsert(RowIndex, RowIndex);
 }
 public void insert(int RowIndex, Object[] NewRow){
  insert(RowIndex, NewRow, -1, null, -1, CheckDefaultNewValue, -1);
 }
 public void append_(Object[] NewData,
  int Data_AddMode, int[] Data_ByCustomCols,
  int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  insert_(Rows.size(), NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow,
  int Data_AddMode, int[] Data_ByCustomCols,
  int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  int size=Rows.size();
  append_(NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
  refreshInsert(size, size);
 }
 public void append(Object[] NewRow){
  append(NewRow, -1, null, -1, CheckDefaultNewValue, -1);
 }
 public void append(Vector<Object[]> NewData,
  int Data_AddMode, int[] Data_ByCustomCols,
  int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  int temp, temp_;
  int size=Rows.size();
  Object[] CurrRow;
  
  temp=0; if(NewData!=null){temp=NewData.size();} if(temp==0){return;}
  temp_=0;
  do{
   CurrRow=NewData.elementAt(temp_);
   append_(CurrRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
   
   temp_=temp_+1;
  }while(temp_!=temp);
  
  refreshInsert(size, size+(temp-1));
 }
 public void append(Vector<Object[]> NewData){
  append(NewData, -1, null, -1, CheckDefaultNewValue, -1);
 }
 public void remove_(int RowIndex){
  Rows.removeElementAt(RowIndex);
  if(EnableCheck){
   if(Checked.elementAt(RowIndex)){CheckedCount=CheckedCount-1;}
   Checked.removeElementAt(RowIndex);
  }
  if(EnableIndex){
   Index.removeAt(RowIndex);
  }
 }
 public void remove(int RowIndex){
  remove_(RowIndex);
  refreshRemove(RowIndex, RowIndex);
 }
 public void remove(int[] RowsIndex){
  // RowsIndex must already sorted in ascending order
  int length, temp;
  length=RowsIndex.length;
  if(length==0){return;}
  if(length==Rows.size()){removeAll(); return;}
  temp=length-1;
  do{
   remove_(RowsIndex[temp]);
   temp=temp-1;
  }while(temp!=-1);
  refreshRemove(RowsIndex[0], RowsIndex[length-1]);
 }
 public void remove(int[] RowsIndex, boolean[] IsRemove){
  // RowsIndex must already sorted in ascending order
  int length, temp, RemoveSmallestIndex, RemoveLargestIndex;
  boolean removed;
  length=RowsIndex.length;
  if(length==0){return;}
  removed=false;
  RemoveSmallestIndex=-1;
  RemoveLargestIndex=-1;
  temp=length-1;
  do{
   if(IsRemove[temp]){
    if(!removed){
     RemoveLargestIndex=temp;
     removed=true;
    }
    remove_(RowsIndex[temp]);
    RemoveSmallestIndex=temp;
   }
   temp=temp-1;
  }while(temp!=-1);
  if(removed){refreshRemove(RowsIndex[RemoveSmallestIndex], RowsIndex[RemoveLargestIndex]);}
 }
 public void removeAll(){
  int temp=Rows.size();
  
  if(temp==0){return;}
  
  Rows=new Vector<Object[]>();
  if(EnableCheck){
   Checked=new Vector<Boolean>();
   CheckedCount=0;
  }
  if(EnableIndex){
   Index.removeAll();
  }
  refreshRemove(0, temp-1);
 }
 public void changeValue_(int RowIndex, Object[] NewValue){
  Rows.setElementAt(NewValue, RowIndex);
  if(EnableIndex){
   Index.changeAt(RowIndex, Index.getValueObject(ColumnsType[IndexColumn], NewValue[IndexColumn]));
  }
 }
 public void changeValue(int RowIndex, Object[] NewValue){
  changeValue_(RowIndex, NewValue);
  refreshUpdate(RowIndex, RowIndex);
 }
 
 public Vector<Object[]> subData(int[] Columns, int[] SelectedRows){
  return PGUI.subDataFromSelectedRows(this, SelectedRows, Columns);
 }
 public Object[] getObjects(int Column, int[] SelectedRows){
  return PGUI.getObjectsFromSelectedRows(this, SelectedRows, Column);
 }
 public long[] getIds(int Column, int[] SelectedRows){
  return PGUI.getIdsFromSelectedRows(this, SelectedRows, Column);
 }
 
 // check methods
 public boolean isCheckable(){return EnableCheck;}
 public Vector<Boolean> getCheckList(){return Checked;}
 public Vector<Boolean> getCheckList(int[] Rows){return PCore.subVect(getCheckList(), Rows);}
 public boolean getCheckDefaultNewValue(){return CheckDefaultNewValue;}
 public int getCheckedCount(){return CheckedCount;}
 public void setCheckedCount(int CheckedCount){this.CheckedCount=CheckedCount;}
 public void addCheckedCount(int AddValue, boolean IsAdd){
  if(IsAdd){CheckedCount=CheckedCount+AddValue;}
  else{CheckedCount=CheckedCount-AddValue;}
 }
 public boolean getChecked(int RowIndex){
  boolean ret=false;
  if(EnableCheck){ret=Checked.elementAt(RowIndex);}
  return ret;
 }
 public int[] getChecked(boolean Value){
  Vector<Integer> ret=new Vector();
  int temp, length;
  
  length=Rows.size();
  if(length!=0){
   temp=0;
   do{
    if(Checked.elementAt(temp)==Value){ret.addElement(temp);}
    temp=temp+1;
   }while(temp!=length);
  }
  
  return PCore.primArr_VectInt(ret);
 }
 public int[] getChecked(int[] RowsIndex, boolean Value){
  Vector<Integer> ret=new Vector();
  int temp, length;
  
  length=RowsIndex.length;
  if(length!=0){
   temp=0;
   do{
    if(Checked.elementAt(RowsIndex[temp])==Value){ret.addElement(RowsIndex[temp]);}
    temp=temp+1;
   }while(temp!=length);
  }
  
  return PCore.primArr_VectInt(ret);
 }
 public long[] getCheckedLong(int Column){
  OQuickListOfLong ret=new OQuickListOfLong(1024, 1024, false, false);
  int count, temp;
  boolean IsInteger=ColumnsType[Column]==CCore.TypeInteger;
  long Value;
  count=Rows.size();
  if(count!=0){
   temp=0;
   do{
    if(Checked.elementAt(temp)){
     Value=PCore.getValueIntLong(Rows.elementAt(temp)[Column], IsInteger, -1);
     ret.appendElement(Value);
    }
    temp=temp+1;
   }while(temp!=count);
  }
  return ret.getElements();
 }
 public boolean setChecked(int RowIndex, boolean Chk){
  boolean ret=false;
  
  if(EnableCheck){
   if(Checked.elementAt(RowIndex)!=Chk){
    if(Chk){CheckedCount=CheckedCount+1;}
    else{CheckedCount=CheckedCount-1;}
    Checked.setElementAt(Chk, RowIndex);
    refreshUpdate(RowIndex, RowIndex);
    ret=true;
   }
  }
  
  return ret;
 }
 public int[] setChecked(int[] Indices, boolean Chk){
  // Indices must have been sorted ascending
  Vector<Integer> ret=new Vector();
  int temp, count, currindex, start, end;
  count=Indices.length;
  if(count!=0){
   start=-1;
   end=-1;
   temp=0;
   do{
    currindex=Indices[temp];
    if(Checked.elementAt(currindex)!=Chk){
     if(Chk){CheckedCount=CheckedCount+1;}
     else{CheckedCount=CheckedCount-1;}
     Checked.setElementAt(Chk, currindex);
     ret.addElement(currindex);
     if(start==-1){start=currindex; end=start;}
     else{end=currindex;}
    }
    temp=temp+1;
   }while(temp!=count);
   if(start!=-1){refreshUpdate(start, end);}
  }
  return PCore.primArr_VectInt(ret);
 }
 public int[] checkAll(boolean CheckValue){
  Vector<Integer> ret=new Vector();
  int count, temp, start, end;
  count=Checked.size();
  if(count!=0){
   start=-1;
   end=-1;
   temp=0;
   do{
    if(Checked.elementAt(temp)!=CheckValue){
     if(CheckValue){CheckedCount=CheckedCount+1;}
     else{CheckedCount=CheckedCount-1;}
     Checked.setElementAt(CheckValue, temp);
     ret.addElement(temp);
     if(start==-1){start=temp; end=start;}
     else{end=temp;}
    }
    temp=temp+1;
   }while(temp!=count);
   if(start!=-1){refreshUpdate(start, end);}
  }
  return PCore.primArr_VectInt(ret);
 }
 public Object[] check(long[] Data, int Column, int[] RangeRows,
  int IfFound_AddRowMode, boolean IfFound_IsUpdate, boolean IfFound_UpdateValue,
  int IfNotFound_AddRowMode, boolean IfNotFound_IsUpdate, boolean IfNotFound_UpdateValue){
  // AddRowMode : 1 add found, 2 add found && do-check
  Vector<Integer> Found_Rows=new Vector();
  int Found_UpdateRowStart=-1;
  int Found_UpdateRowEnd=-1;
  
  Vector<Integer> NotFound_Rows=new Vector();
  int NotFound_UpdateRowStart=-1;
  int NotFound_UpdateRowEnd=-1;
  
  boolean IsInteger=ColumnsType[Column]==CCore.TypeInteger;
  int row_temp, data_temp, curr_row;
  long data_at_row, data_;
  
  do{
   if(Data==null || RangeRows==null || Rows.size()==0){break;}
   if(Data.length==0 || RangeRows.length==0){break;}
   
   row_temp=0;
   do{
    curr_row=RangeRows[row_temp];
    if(IsInteger){data_at_row=(Integer)Rows.elementAt(curr_row)[Column];}
    else{data_at_row=(Long)Rows.elementAt(curr_row)[Column];}
    
    data_temp=0;
    do{
     data_=Data[data_temp];
     
     // if found
     if(data_at_row==data_){
      do{
       if(IfFound_AddRowMode==1){Found_Rows.addElement(curr_row);}
       
       if(!IfFound_IsUpdate){break;}
       if(Checked.elementAt(curr_row)==IfFound_UpdateValue){break;}
       
       if(IfFound_AddRowMode==2){Found_Rows.addElement(curr_row);}
       
       if(IfFound_UpdateValue){CheckedCount=CheckedCount+1;}else{CheckedCount=CheckedCount-1;}
       Checked.setElementAt(IfFound_UpdateValue, curr_row);
       
       if(Found_UpdateRowStart==-1){Found_UpdateRowStart=curr_row; Found_UpdateRowEnd=Found_UpdateRowStart;}
       else{
        if(curr_row<Found_UpdateRowStart){Found_UpdateRowStart=curr_row;}else if(curr_row>Found_UpdateRowEnd){Found_UpdateRowEnd=curr_row;}
       }
      }while(false);
      
      break;
     }
     
     data_temp=data_temp+1;
    }while(data_temp!=Data.length);
    
    // if not found
    if(data_temp==Data.length){
     do{
      if(IfNotFound_AddRowMode==1){NotFound_Rows.addElement(curr_row);}
      
      if(!IfNotFound_IsUpdate){break;}
      if(Checked.elementAt(curr_row)==IfNotFound_UpdateValue){break;}
      
      if(IfNotFound_AddRowMode==2){NotFound_Rows.addElement(curr_row);}
      
      if(IfNotFound_UpdateValue){CheckedCount=CheckedCount+1;}else{CheckedCount=CheckedCount-1;}
      Checked.setElementAt(IfNotFound_UpdateValue, curr_row);
      
      if(NotFound_UpdateRowStart==-1){NotFound_UpdateRowStart=curr_row; NotFound_UpdateRowEnd=NotFound_UpdateRowStart;}
      else{
       if(curr_row<NotFound_UpdateRowStart){NotFound_UpdateRowStart=curr_row;}else if(curr_row>NotFound_UpdateRowEnd){NotFound_UpdateRowEnd=curr_row;}
      }
     }while(false);
    }
    
    row_temp=row_temp+1;
   }while(row_temp!=RangeRows.length);
  }while(false);
  
  return PCore.objArrVariant(
   PCore.primArr_VectInt(Found_Rows), Found_UpdateRowStart, Found_UpdateRowEnd,
   PCore.primArr_VectInt(NotFound_Rows), NotFound_UpdateRowStart, NotFound_UpdateRowEnd);
 }
 public int[] check(long[] Data, boolean Chk, int Column){
  Object[] result=check(Data, Column, PCore.newIntegerArrayInOrderedSequence(Rows.size(), 0, 1), 2, true, Chk, 0, false, false);
  
  int[] Found_Rows=(int[])result[0];
  int Found_UpdateRowStart=(Integer)result[1];
  int Found_UpdateRowEnd=(Integer)result[2];
  
  if(Found_UpdateRowStart!=-1){refreshUpdate(Found_UpdateRowStart, Found_UpdateRowEnd);}
  
  return Found_Rows;
 }
 
 // GUI methods
 public void refreshInsert(int StartIndex, int EndIndex){ParentModel.refreshInsert(StartIndex, EndIndex);}
 public void refreshUpdate(int StartIndex, int EndIndex){ParentModel.refreshUpdate(StartIndex, EndIndex);}
 public void refreshRemove(int StartIndex, int EndIndex){ParentModel.refreshRemove(StartIndex, EndIndex);}
 
}