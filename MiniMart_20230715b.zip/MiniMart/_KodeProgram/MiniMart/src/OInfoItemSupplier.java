import java.util.Date;

public class OInfoItemSupplier {
 
 double BuyPrc;
 String BuyComment;
 Date Update;
 boolean IsActive;

}