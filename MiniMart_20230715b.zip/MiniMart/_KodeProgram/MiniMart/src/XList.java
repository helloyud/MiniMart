import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JList;

public class XList extends JList {
 
 int OnKeyPress_PosRow;
 int FocusState;
 boolean IsSelecting;
 
 public XList(){
  super();
  
  addKeyListener(new KeyAdapter(){
    public void keyPressed(KeyEvent evt){
     int KeyCode=evt.getKeyCode();
     
     setFocusState(CGUI.FocusState_Work);
     if(PNav.isKeyArrow(KeyCode) && evt.isShiftDown()){setIsSelecting(true);}
     
     setOnKeyPressPosCell(getSelectedIndex());
    }
    public void keyReleased(KeyEvent evt){}
   });
  
  addFocusListener(new FocusAdapter(){
    public void focusGained(FocusEvent evt){setFocusState(CGUI.FocusState_Enter); setIsSelecting(false);}
    public void focusLost(FocusEvent evt){setFocusState(CGUI.FocusState_Leave); setIsSelecting(false);}
   });
 }
 
 void setOnKeyPressPosCell(int Row){OnKeyPress_PosRow=Row;}
 void setFocusState(int Value){FocusState=Value;}
 void setIsSelecting(boolean Value){IsSelecting=Value;}
 
}