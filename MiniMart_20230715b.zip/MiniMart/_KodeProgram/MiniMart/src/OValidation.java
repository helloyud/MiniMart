public class OValidation {

	boolean IsValid;
	StringBuilder MessageError;

	public OValidation(boolean IsValid){
		initVar();
		this.IsValid=IsValid;
	}
	public OValidation(boolean IsValid, StringBuilder MsgError) {
		initVar();
  this.IsValid = IsValid;
		if(MsgError!=null){MessageError.append(MsgError.toString());}
	}
	public OValidation(boolean IsValid, String MsgError) {
		initVar();
		this.IsValid = IsValid;
		if(MsgError!=null){MessageError.append(MsgError);}
	}
	
	void initVar(){
		IsValid=false;
		MessageError=new StringBuilder();
	}
	
	public void addError(String Msg){IsValid=false; MessageError.append(Msg);}
	public String getError(){return MessageError.toString();}
	
	public void setValid(boolean IsValid){this.IsValid=IsValid;}
	public boolean getValid(){return IsValid;}

}