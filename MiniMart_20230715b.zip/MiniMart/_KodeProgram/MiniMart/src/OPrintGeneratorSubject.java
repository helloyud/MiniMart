import java.sql.Statement;
import java.util.LinkedList;
import java.util.Vector;

public class OPrintGeneratorSubject extends OPrintGenerator{

 // additional printing properties
 LinkedList<Long> Id;
 boolean PaginationByAlphabet;
 boolean PrintDetail;
 
 LinkedList<OIdName> Subjects;
 OIdName CurrSubject;
 Vector<String> CurrName;
 int CurrNameLine;
 Vector<Vector<String>> CurrAddress;
 int CurrAddressLine;
 Vector<Vector<String>> CurrContact;
 int CurrContactLine;
 
 char CurrAlphabet;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 double SubjectAddLineSpacing, SubjectDetailAddlineSpacing;
 int Pos1A, Pos1B, Pos2A, Pos2B;
 int NameFit, DetailFit;
 
 OPrintGeneratorSubject(OFont FontStandard) {super(FontStandard);}
 
 /*
  printing operation's common properties:
  - 72 dpi measurement tools
    - FontMetrics
  - printer and paper properties
    - on what paper that data will be printed.
    - printer's dpi.
  - printing data
  - printing layout/presentation
 */
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> Id, boolean PaginationByAlphabet, boolean PrintDetail, int ColumnarCount){
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.Id=Id;
  this.PaginationByAlphabet=PaginationByAlphabet;
  this.PrintDetail=PrintDetail;
		this.ColumnarCount=ColumnarCount;
 }
 
 // standard private methods
	protected boolean hasHeader(){return true;}
 protected boolean hasFooter(){return false;}
	protected boolean isMultiColumnar(){return true;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.5f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(7.5f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  SubjectAddLineSpacing=7;
  SubjectDetailAddlineSpacing=3;
  Pos1A=1;
  Pos1B=3;
  Pos2A=3;
  Pos2B=5;
  NameFit=ColumnarColumnCount-Pos1B+1;
  DetailFit=ColumnarColumnCount-Pos2B+1;
 }
 protected void prepareFirstPageData() throws Exception{
  getSubjects();
  if(Subjects.isEmpty()){throw new Exception();}
  CurrSubject=Subjects.pop();
  generateASubjectPrint();
 }
 protected void addHeader() throws Exception{
  PText.refillChars(TxtPage, ' ');
  if(PaginationByAlphabet){
   PText.fillStringToChars(TxtPage, "\" "+PText.upperCase(CurrAlphabet)+" \"", PageColumnCount-1, 3);
  }
  else{
   PText.fillStringToChars(TxtPage, "~", PageColumnCount-1, 3);
  }
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
  CurrY=CurrY+NormalHeight;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  CurrY=CurrY+HeaderAddLineSpacing;
 }
 protected boolean addColumnar() throws Exception{
  boolean ret=false;
		boolean KeepPrinting=true;
  int temp, count, temp_, count_;
  double temp_d;
  Vector<String> CategoryText;
  char BefAlphabet;
  
  do{
   // a subject
   if(IsANewColumnar){IsANewColumnar=false;}
   else{CurrY=CurrY+SubjectAddLineSpacing;}
    
    // name
   PText.refillChars(Txt, ' ');
   PText.fillStringToChars(Txt, "*", Pos1A-1, 1);
   PText.fillStringToChars(Txt, CurrName.elementAt(0), Pos1B-1, 1);
   DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
   CurrY=CurrY+NormalHeight;
   if(CurrNameLine>1){
    temp=1;
    do{
     DrawComponents.add(new ODrawComponentText(BaseX+(Pos1B-1)*FontWidth, BaseY+CurrY+BaselineHeight, FontType, CurrName.elementAt(temp)));
     CurrY=CurrY+NormalHeight;
     temp=temp+1;
    }while(temp!=CurrNameLine);
   }
   
   if(PrintDetail){
      // detail : address
    if(CurrAddressLine!=0){
     count=CurrAddress.size();
     CurrY=CurrY+SubjectDetailAddlineSpacing;
     temp=0;
     do{
      CategoryText=CurrAddress.elementAt(temp);
      PText.refillChars(Txt, ' ');
      PText.fillStringToChars(Txt, "@", Pos2A-1, 1);
      PText.fillStringToChars(Txt, CategoryText.elementAt(0), Pos2B-1, 1);
      DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
      CurrY=CurrY+NormalHeight;
      count_=CategoryText.size();
      if(count_>1){
       temp_=1;
       do{
        DrawComponents.add(new ODrawComponentText(BaseX+(Pos2B-1)*FontWidth, BaseY+CurrY+BaselineHeight, FontType, CategoryText.elementAt(temp_)));
        CurrY=CurrY+NormalHeight;
        temp_=temp_+1;
       }while(temp_!=count_);
      }
      temp=temp+1;
     }while(temp!=count);
    }

     // detail : contact
    if(CurrContactLine!=0){
     count=CurrContact.size();
     CurrY=CurrY+SubjectDetailAddlineSpacing;
     temp=0;
     do{
      CategoryText=CurrContact.elementAt(temp);
      PText.refillChars(Txt, ' ');
      PText.fillStringToChars(Txt, "X", Pos2A-1, 1);
      PText.fillStringToChars(Txt, CategoryText.elementAt(0), Pos2B-1, 1);
      DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
      CurrY=CurrY+NormalHeight;
      count_=CategoryText.size();
      if(count_>1){
       temp_=1;
       do{
        DrawComponents.add(new ODrawComponentText(BaseX+(Pos2B-1)*FontWidth, BaseY+CurrY+BaselineHeight, FontType, CategoryText.elementAt(temp_)));
        CurrY=CurrY+NormalHeight;
        temp_=temp_+1;
       }while(temp_!=count_);
      }
      temp=temp+1;
     }while(temp!=count);
    }
   }
   
   // terminate current page if:
    // no more subject to be printed
   if(Subjects.isEmpty()){
    CurrSubject=null;
    break;
   }
   
   BefAlphabet=CurrAlphabet;
   CurrSubject=Subjects.pop();
   generateASubjectPrint();
   
    // pagination by alphabet and next subject's alphabet != curr subject's alphabet
   if(PaginationByAlphabet){
    if(!PText.compare(CurrAlphabet, BefAlphabet, false)){break;}
   }
   
    // checkOverPage()==true
   temp_d=SubjectAddLineSpacing+(CurrNameLine*NormalHeight);
   if(PrintDetail){
    if(CurrAddressLine!=0){temp_d=temp_d+SubjectDetailAddlineSpacing+(CurrAddressLine*NormalHeight);}
    if(CurrContactLine!=0){temp_d=temp_d+SubjectDetailAddlineSpacing+(CurrContactLine*NormalHeight);}
   }
   if(checkOverColumnarHeight(temp_d)){ret=true; break;}
  }while(KeepPrinting);
  return ret;
 }
 protected void addFooter() throws Exception{}
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  if(CurrSubject==null){return false;}
  return true;
 }
 protected void clearVar(){
  Id=null;
  CurrAddress=null;
  CurrContact=null;
  CurrName=null;
  CurrSubject=null;
  Subjects=null;
 }
 
 // additional private methods
 private void getSubjects() throws Exception{
  StringBuilder strb=new StringBuilder();
  OIdName Subject;
  strb=strb.append(Id.pop().toString());
  if(!Id.isEmpty()){
   do{
    strb=strb.append(","+Id.pop().toString());
   }while(!Id.isEmpty());
  }
  Rs=Stm.executeQuery("select Id, Name from Subject where Id in ("+strb.toString()+") order by Name asc;");
  Subjects=new LinkedList();
  if(Rs.next()){
   do{
    Subject=new OIdName();
    Subject.Id=Rs.getLong(1);
    Subject.Name=Rs.getString(2);
    Subjects.addLast(Subject);
   }while(Rs.next());
  }
 }
 private char getAlphabetFromCurrSubject(){
  char ret='#';
  int temp=(int)CurrName.firstElement().charAt(0);
  
  // if curr subject's alphabet is 'A'-'Z' (65-90) or 'a'-'z' (97-122)
  if((temp>=65 && temp<=90) || (temp>=97 && temp<=122)){
   ret=(char)temp;
  }
  
  return ret;
 }
 private void generateASubjectPrint() throws Exception{
  StringBuilder strb;
  Vector<String> strv;
  int CurrCategory, NextCategory;
  boolean EndOfResultSet, EndOfCategory;
  
  if(PrintDetail){
   // address
   CurrAddressLine=0;
   Rs=Stm.executeQuery("select Id, Name, Address from (select City, Address from SubjectXAddress where Subject="+CurrSubject.Id+
    ") as tb1 left join City on tb1.City=City.Id order by Name asc, Address asc;");
   if(Rs.next()){
    CurrAddress=new Vector();
    EndOfResultSet=false;
    NextCategory=Rs.getInt(1);
    if(Rs.wasNull()){NextCategory=-1;}
    do{
     // new category
     CurrCategory=NextCategory;
     strb=new StringBuilder();
     if(CurrCategory==-1){str="Tdk didefenisikan";}
     else{str=Rs.getString(2);}
     strb=strb.append(str+": ");

     // for the same category
     EndOfCategory=false;
     do{
      strb.append(PText.singleLine(Rs.getString(3), '~'));

      // EndOfResultSet
      EndOfResultSet=!Rs.next();
      // NextCategory
      if(!EndOfResultSet){
       NextCategory=Rs.getInt(1);
       if(Rs.wasNull()){NextCategory=-1;}
       if(NextCategory!=CurrCategory){EndOfCategory=true;}
       else{strb.append("; ");}
      }
     }while(!EndOfResultSet && !EndOfCategory);

     strv=PText.multiLine(strb.toString(), DetailFit);
     CurrAddressLine=CurrAddressLine+strv.size();
     CurrAddress.add(strv);
    }while(!EndOfResultSet);
   }
   
   // contact
   CurrContactLine=0;
   Rs=Stm.executeQuery("select Id, Name, Contact from (select ContactType, Contact from SubjectXContact where Subject="+CurrSubject.Id+
    ") as tb1 left join ContactType on tb1.ContactType=ContactType.Id order by Name asc, Contact asc;");
   if(Rs.next()){
    CurrContact=new Vector();
    EndOfResultSet=false;
    NextCategory=Rs.getInt(1);
    if(Rs.wasNull()){NextCategory=-1;}
    do{
     // new category
     CurrCategory=NextCategory;
     strb=new StringBuilder();
     if(CurrCategory==-1){str="Tdk didefenisikan";}
     else{str=Rs.getString(2);}
     strb=strb.append(str+": ");

     // for the same category
     EndOfCategory=false;
     do{
      strb.append(PText.singleLine(Rs.getString(3), '~'));

      // EndOfResultSet
      EndOfResultSet=!Rs.next();
      // NextCategory
      if(!EndOfResultSet){
       NextCategory=Rs.getInt(1);
       if(Rs.wasNull()){NextCategory=-1;}
       if(NextCategory!=CurrCategory){EndOfCategory=true;}
       else{strb.append("; ");}
      }
     }while(!EndOfResultSet && !EndOfCategory);

     strv=PText.multiLine(strb.toString(), DetailFit);
     CurrContactLine=CurrContactLine+strv.size();
     CurrContact.add(strv);
    }while(!EndOfResultSet);
   }
  }
  
  // name
  CurrName=PText.multiLine(CurrSubject.Name, NameFit);
  CurrNameLine=CurrName.size();
  CurrAlphabet=getAlphabetFromCurrSubject();
 }
 
 
}
