import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class F_ItemPreview extends XFormPreview {
 
 // set
 long wId;
 OInfoItem wInfoItem;
 
 // Pic
 boolean IIPicClear;
 OCustomListModel ListMdlPic;
 int LastSelectedRowPic;
 boolean PanelImageClear;
 
 // Vrs
 boolean IIVrsClear;
 
  // Secondary Id
 boolean IISecClear;
 OCustomListModel ListMdlSec;
 int LastSelectedRowSec;
 boolean InfoSecClear;
 int SecsCount;
 
  // Variant
 boolean IIVartClear;
 OCustomTableModel TableMdlVart;
	String[] TableMdlVartColsName;
	int[] TableMdlVartColsType, TableMdlVartColsShowOption, TableMdlVartColsVisible, TableVartColsWidth;
	boolean[] TableMdlVartColsEditable;
 int LastSelectedRowVart;
 boolean InfoVartClear;
 
 // Etc
 boolean IIEtcClear;
 
  // Cat
 boolean IICatClear;
 OCustomListModel ListMdlCat;
 int LastSelectedRowCat;
 boolean InfoCatClear;
 int CategoriesCount;
 
  // Tag
 boolean IITagClear;
 OCustomListModel ListMdlTag;
 int LastSelectedRowTag;
 boolean InfoTagClear;
 int TagsCount;
 
 //
 boolean ShowBuyPrice;
 
 public F_ItemPreview(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Detail
  CB_Buy.setSelected(false); CmB_Buy.setSelectedIndex(0); fillBuy();
  CB_Sell.setSelected(true); CmB_Sell.setSelectedIndex(0); fillSell();
  
  // Pic
  IIPicClear=true;
  
  ListMdlPic=new OCustomListModel(false);
  ListMdlPic.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  List_Pic.setModel(ListMdlPic);
  
  LastSelectedRowPic=-1;
  PanelImageClear=true;
  
  // Vrs
  IIVrsClear=true;
  
   // Sec
  IISecClear=true;
  
  ListMdlSec=new OCustomListModel(false);
  ListMdlSec.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeString), 1); // secondary_id, secondary_id's formatted_text
  List_Sec.setModel(ListMdlSec);
  
  LastSelectedRowSec=-1;
  InfoSecClear=true;
  
   // Vart
  IIVartClear=true;
  
  TableMdlVart=new OCustomTableModel();
  Tbl_Vart.setModel(TableMdlVart);
  
  TableMdlVartColsName=PMyShop.getItemVart_ColumnsName();
  TableMdlVartColsType=PMyShop.getItemVart_ColumnsType();
  TableMdlVartColsShowOption=PMyShop.getItemVart_ColumnsShowOption();
  TableMdlVartColsEditable=PMyShop.getItemVart_ColumnsEditable(false, false, false, false, false);
  
  LastSelectedRowVart=-1;
  InfoVartClear=true;
  
  PGUI.setSelected(true, CB_VartViewComment, CB_VartViewBuyPrice, CB_VartViewBuyComment);
  
  buildTableVartViewStructure(true, true);
  updateTableVartView(false);
  
  Pnl_VartInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Etc
  IIEtcClear=true;
  
   // Cat
  IICatClear=true;
  
  ListMdlCat=new OCustomListModel(false);
  ListMdlCat.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_Cat.setModel(ListMdlCat);
  
  LastSelectedRowCat=-1;
  InfoCatClear=true;
  
   // Tag
  IITagClear=true;
  
  ListMdlTag=new OCustomListModel(false);
  ListMdlTag.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_Tag.setModel(ListMdlTag);
  
  LastSelectedRowTag=-1;
  InfoTagClear=true;
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    ),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
 }
 
 public boolean proceed(Object AKey){
  boolean ret=false;
  
  do{
   wId=(Long)AKey;
   
   wInfoItem=PMyShop.getItemInfo(IFV.Stm, wId, true);
   if(wInfoItem==null){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public String getName(){return "barang";}

 
 void clearComponents(){
  clearPic();
  clearVrs();
  clearEtc();
  
  clearSetVariables();
 }
 
 // Pic
 void onPicRowSelected(boolean UpdateAnyway){
  int row=List_Pic.getSelectedIndex();
  
  if(LastSelectedRowPic==row && !UpdateAnyway){return;}
  
  LastSelectedRowPic=row;
  if(row==-1){clearInfoPic(); return;}
  fillInfoPic(row);
 }
 void fillPic(){
  int datacount;
  
  clearPic();
  
  IIPicClear=false;
  
  datacount=PDatabase.queryToList(IFV.Stm,
   "select ItemXPicture.FileName from ItemXPicture where "+
   "ItemXPicture.Item="+wInfoItem.PrimaryId+" order by ItemXPicture.FileName asc",
   ListMdlPic, false, null, -1, false, -1);
  if(datacount==-1){clearPic(); return;}
  if(datacount>0){List_Pic.setSelectedIndex(0); onPicRowSelected(true);}
 }
 void clearPic(){
  if(IIPicClear){return;}
  
  ListMdlPic.removeAll();
  LastSelectedRowPic=-1;
  clearInfoPic();
  
  IIPicClear=true;
 }
 void fillInfoPic(int PicRowSelected){
  Object[] Objs=ListMdlPic.Mdl.Rows.elementAt(PicRowSelected);
  
  PGUI.fillPanelPictureURL(Pnl_Image, IFV.Conf.ImageDirSubject, PCore.objString(Objs[0], null));
  
  PanelImageClear=false;
 }
 void clearInfoPic(){
  if(PanelImageClear){return;}
  
  PGUI.fillPanelPictureURL(Pnl_Image, IFV.Conf.ImageDirSubject, null);

  PanelImageClear=true;
 }
 
 // Vrs
 void fillVrs(){
  boolean bool;
  
  clearVrs();
  
  IIVrsClear=false;
  
  bool=false;
  do{
   if(!fillSec()){break;}
   if(!fillVart()){break;}
   bool=true;
  }while(false);
  if(!bool){clearVrs();}
 }
 void clearVrs(){
  if(IIVrsClear){return;}
  
  clearSec();
  clearVart();
  
  IIVrsClear=true;
 }
 
  // Sec
 void onSecRowSelected(boolean UpdateAnyway){
  int row=List_Sec.getSelectedIndex();
  
  if(LastSelectedRowSec==row && !UpdateAnyway){return;}
  
  LastSelectedRowSec=row;
  if(row==-1){clearInfoSec(); return;}
  fillInfoSec(row);
 }
 String formatSecondaryId(long SecondaryId){
  return PText.separate(String.valueOf(SecondaryId), " - ", 5);
 }
 void formatListSecondaryId(){
  int temp, length;
  Vector<Object[]> Data=ListMdlSec.getRows();
  Object[] AData;
  length=Data.size();
  if(length==0){return;}
  temp=0;
  do{
   AData=Data.elementAt(temp);
   AData[1]=formatSecondaryId((Long)AData[0]);
   temp=temp+1;
  }while(temp!=length);
  ListMdlSec.refreshUpdate(0, length-1);
 }
 boolean fillSec(){
  boolean ret=false;
  int datacount;
  
  clearSec();
  
  IISecClear=false;
  do{
   datacount=PDatabase.queryToList(IFV.Stm,
    "select SecondaryId, '' from ItemXSecondaryId where Item="+wInfoItem.PrimaryId+" order by SecondaryId asc",
    ListMdlSec, false, null, -1, false, -1);
   if(datacount==-1){break;}
   formatListSecondaryId();
   SecsCount=datacount;
   if(datacount>0){List_Sec.setSelectedIndex(0); onSecRowSelected(true);}
   
   ret=true;
  }while(false);
  if(!ret){clearSec();}
  
  return ret;
 }
 void clearSec(){
  if(IISecClear){return;}
  
  ListMdlSec.removeAll();
  LastSelectedRowSec=-1;
  clearInfoSec();
  SecsCount=0;
  
  IISecClear=true;
 }
 void fillInfoSec(int SecRowSelected){
  Object[] Objs=ListMdlSec.Mdl.Rows.elementAt(SecRowSelected);
  
  
  
  InfoSecClear=false;
 }
 void clearInfoSec(){
  if(InfoSecClear){return;}
  
  
  
  InfoSecClear=true;
 }
 
  // Vart
 void onSelectedRowVartChanged(boolean UpdateAnyway){
  int row=Tbl_Vart.getSelectedRow();
  if(LastSelectedRowVart==row && !UpdateAnyway){return;}
  LastSelectedRowVart=row;
  if(row==-1){clearInfoVart(); return;}
  fillInfoVart(row);
 }
 
 boolean fillVart(){
  boolean ret=false;
  int datacount;
  
  clearVart();
  
  IIVartClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getItemVart_Query(PCore.primArr(wInfoItem.PrimaryId), false, null, false, -1, null, false),
    TableMdlVart, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Vart.changeSelection(0, 0, false, false); onSelectedRowVartChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearVart();}
  
  return ret;
 }
 void clearVart(){
  if(IIVartClear){return;}
  
  TableMdlVart.removeAll();
  LastSelectedRowVart=-1;
  clearInfoVart();
  
  IIVartClear=true;
 }
 /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
 String getInfoVart_Name(Object[] objs){
  StringBuilder ret=new StringBuilder();
  String Name, Comment;
  
  Name=PCore.objString(objs[0], null);
  Comment=PCore.objString(objs[5], null);
  
  ret.append(Name);
  ret.append(PText.getString(Comment, "", "   { "+Comment+" }", true));
  
  return ret.toString();
 }
 String getInfoVart_Buy(Object[] objs){
  StringBuilder ret=new StringBuilder();
  double BuyPrice;
  String BuyComment;
  Date BuyUpdate;
  
  BuyPrice=PCore.objDouble(objs[2], 0D);
  BuyComment=PCore.objString(objs[3], null);
  BuyUpdate=PCore.objDate(objs[4], null);
  
  if(ShowBuyPrice){
   ret.append(PText.getStringObj(BuyUpdate, "", "~ "+PText.dateToString(BuyUpdate, 2)+" ~\n", false));
   ret.append(PText.priceToString(BuyPrice));
   ret.append(PText.getString(BuyComment, "", "   { "+BuyComment+" }", true));
  }
  
  return ret.toString();
 }
 void fillInfoVart(int row){
  Object[] objs;
  
  if(row==-1){return;}
  
  objs=TableMdlVart.Mdl.Rows.elementAt(row);
  TA_VartInfoName.setText(getInfoVart_Name(objs));
  TA_VartInfoBuy.setText(getInfoVart_Buy(objs));
  PGUI.fillPanelPictureURL(Pnl_VartInfoPreview, IFV.Conf.ImageDirItem, PCore.objString(objs[6], null));
  
  InfoVartClear=false;
 }
 void clearInfoVart(){
  if(InfoVartClear){return;}
  
  PGUI.clearText(TA_VartInfoName, TA_VartInfoBuy);
  PGUI.fillPanelPictureURL(Pnl_VartInfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoVartClear=true;
 }
 
 void updateTableVartView(boolean Requery){
  TableMdlVart.updateColumnsInfo(TableMdlVartColsName, TableMdlVartColsType, TableMdlVartColsShowOption,
   TableMdlVartColsVisible, TableMdlVartColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Vart, TableVartColsWidth);
  if(!Requery){onSelectedRowVartChanged(false);}
  else{fillVart();}
 }
 void buildTableVartColumns(){
  TableMdlVartColsVisible=PMyShop.getItemVart_ColumnsVisible(
   CB_VartViewBuyPrice.isSelected(), CB_VartViewBuyComment.isSelected(), CB_VartViewBuyUpdate.isSelected(), CB_VartViewComment.isSelected());
  TableVartColsWidth=PMyShop.getItemVart_ColumnsWidth(
   CB_VartViewBuyPrice.isSelected(), CB_VartViewBuyComment.isSelected(), CB_VartViewBuyUpdate.isSelected(), CB_VartViewComment.isSelected());
 }
 void buildTableVartOrderBy(){}
 void buildTableVartViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableVartColumns();}
  if(RebuildOrderBy){buildTableVartOrderBy();}
 }
 void changeVartViewByNormal(){
  buildTableVartViewStructure(true, false);
  updateTableVartView(false);
 }
 
 // Etc
 void fillEtc(){
  boolean bool;
  
  clearEtc();
  
  IIEtcClear=false;
  
  bool=false;
  do{
   if(!fillCat()){break;}
   if(!fillTag()){break;}
   bool=true;
  }while(false);
  if(!bool){clearEtc();}
 }
 void clearEtc(){
  if(IIEtcClear){return;}
  
  clearCat();
  clearTag();
  
  IIEtcClear=true;
 }
 
  // Cat
 void onCatRowSelected(boolean UpdateAnyway){
  int row=List_Cat.getSelectedIndex();
  
  if(LastSelectedRowCat==row && !UpdateAnyway){return;}
  
  LastSelectedRowCat=row;
  if(row==-1){clearInfoCat(); return;}
  fillInfoCat(row);
 }
 boolean fillCat(){
  boolean ret=false;
  int datacount;
  
  clearCat();
  
  IICatClear=false;
  do{
   datacount=PDatabase.queryToList(IFV.Stm,
    "select CategoryId, Name as 'CategoryName' from "+
     "(select CategoryOfItem as 'CategoryId' from ItemXCategory where Item="+wInfoItem.PrimaryId+") as tb1 "+
    "inner join CategoryOfItem on tb1.CategoryId=CategoryOfItem.Id order by Name asc",
    ListMdlCat, false, null, -1, false, -1);
   if(datacount==-1){break;}
   CategoriesCount=datacount;
   if(datacount>0){List_Cat.setSelectedIndex(0); onCatRowSelected(true);}
   
   ret=true;
  }while(false);
  if(!ret){clearCat();}
  
  return ret;
 }
 void clearCat(){
  if(IICatClear){return;}
  
  ListMdlCat.removeAll();
  LastSelectedRowCat=-1;
  clearInfoCat();
  CategoriesCount=0;
  
  IICatClear=true;
 }
 void fillInfoCat(int CatRowSelected){
  Object[] Objs=ListMdlCat.Mdl.Rows.elementAt(CatRowSelected);
  
  
  
  InfoCatClear=false;
 }
 void clearInfoCat(){
  if(InfoCatClear){return;}
  
  
  
  InfoCatClear=true;
 }
 
  // Tag
 void onTagRowSelected(boolean UpdateAnyway){
  int row=List_Tag.getSelectedIndex();
  
  if(LastSelectedRowTag==row && !UpdateAnyway){return;}
  
  LastSelectedRowTag=row;
  if(row==-1){clearInfoTag(); return;}
  fillInfoTag(row);
 }
 boolean fillTag(){
  boolean ret=false;
  int datacount;
  
  clearTag();
  
  IITagClear=false;
  do{
   datacount=PDatabase.queryToList(IFV.Stm,
     "select TagId, Name as 'TagName' from "+
     "(select TagOfItem as 'TagId' from ItemXTag where Item="+wInfoItem.PrimaryId+") as tb1 "+
    "inner join TagOfItem on tb1.TagId=TagOfItem.Id order by Name asc",
    ListMdlTag, false, null, -1, false, -1);
   if(datacount==-1){break;}
   TagsCount=datacount;
   if(datacount>0){List_Tag.setSelectedIndex(0); onTagRowSelected(true);}
   
   ret=true;
  }while(false);
  if(!ret){clearTag();}
  
  return ret;
 }
 void clearTag(){
  if(IITagClear){return;}
  
  ListMdlTag.removeAll();
  LastSelectedRowTag=-1;
  clearInfoTag();
  TagsCount=0;
  
  IITagClear=true;
 }
 void fillInfoTag(int TagRowSelected){
  Object[] Objs=ListMdlTag.Mdl.Rows.elementAt(TagRowSelected);
  
  
  
  InfoTagClear=false;
 }
 void clearInfoTag(){
  if(InfoTagClear){return;}
  
  

  InfoTagClear=true;
 }
 
 // Others
 void clearSetVariables(){
  wInfoItem=null;
 }
 
 void fillComponentsWithSetVariables(){
  StringBuilder strb;
  boolean first;
  int temp, length;
  
  strb=new StringBuilder();
  strb.append("("+PText.separate(String.valueOf(wInfoItem.PrimaryId), " - ", 5)+")");
  length=wInfoItem.SecondaryIds.size();
  if(length!=0){
   temp=0;
   do{
    strb.append(" ; "+PText.separate(String.valueOf(wInfoItem.SecondaryIds.elementAt(temp)), " - ", 5));
    temp=temp+1;
   }while(temp!=length);
  }
  TA_Id.setText(strb.toString());
  TA_Name.setText(wInfoItem.Name);
  TA_Comment.setText(PText.getString(wInfoItem.Comment, "", false));
  CB_Active.setSelected(wInfoItem.IsActive);
  
  TF_Stock.setText(PText.priceToString(wInfoItem.Stock)+" "+"( "+PText.priceToString(wInfoItem.MinStock)+" - "+PText.priceToString(wInfoItem.MaxStock)+" )"+PText.getString(wInfoItem.StockUnitName, "", " "+wInfoItem.StockUnitName, true));
  CB_AutoUpdateStock.setSelected(wInfoItem.UpdateStock);
  
  CB_IsOpname.setSelected(wInfoItem.IsOpname);
  
  TF_OrderSpec.setText(
   "Min "+PText.priceToString(wInfoItem.OrderMinPack)+" Pak, "+
   "@ "+PText.priceToString(wInfoItem.OrderEachPackQty)+PText.getString(wInfoItem.StockUnitName, "", " "+wInfoItem.StockUnitName, true)+
   " ( "+PText.priceToString(wInfoItem.OrderEachPackThreshold)+" % )");
  CB_IsReorder.setSelected(wInfoItem.IsReorder);
  
  CB_Exp.setSelected(wInfoItem.HasExpireDate);
  strb=new StringBuilder(); first=true;
  if(wInfoItem.ExpireCheckPeriod!=-1){
   if(first){first=false;}else{strb.append(", ");}
   strb.append("Cek "+PDate.spellDaysCount(wInfoItem.ExpireCheckPeriod, 1));
  }
  if(wInfoItem.ExpireThreshold!=-1){
   if(first){first=false;}else{strb.append(", ");}
   strb.append("Batas "+PDate.spellDaysCount(wInfoItem.ExpireThreshold, 1));
  }
  TF_Expire.setText(strb.toString());
  
  fillSell();
  fillBuy();
  
  //
  fillPic();
  fillVrs();
  fillEtc();
 }
 void fillSell(){
  String str=null;
  if(wInfoItem!=null){
   if(CB_Sell.isSelected()){
    switch(CmB_Sell.getSelectedIndex()){
     case 0 : str=PText.getStringObj(wInfoItem.SellUpdate, "", "~ "+PText.dateToString(wInfoItem.SellUpdate, 2)+" ~\n", false)+PText.priceToString(wInfoItem.SellPrice)+PText.getString(wInfoItem.SellPriceComment, "", "\n{ "+wInfoItem.SellPriceComment+" }", true); break;
     case 1 : str=PText.getStringObj(wInfoItem.SellUpdate, "", "~ "+PText.dateToString(wInfoItem.SellUpdate, 2)+" ~\n", false)+PText.priceToString(wInfoItem.SellPrice); break;
     case 2 : str=PText.getStringObj(wInfoItem.SellUpdate, "", "~ "+PText.dateToString(wInfoItem.SellUpdate, 2)+" ~\n", false)+PText.getString(wInfoItem.SellPriceComment, "", false); break;
    }
   }
   TA_Sell.setText(PText.getString(str, "", false));
  }
 }
 void fillBuy(){
  String str=null;
  if(wInfoItem!=null){
   if(CB_Buy.isSelected()){
    switch(CmB_Buy.getSelectedIndex()){
     case 0 : str=PText.getStringObj(wInfoItem.BuyUpdate, "", "~ "+PText.dateToString(wInfoItem.BuyUpdate, 2)+" ~\n", false)+PText.priceToString(wInfoItem.BuyPriceEstimation)+PText.getString(wInfoItem.BuyPriceComment, "", "\n{ "+wInfoItem.BuyPriceComment+" }", true); break;
     case 1 : str=PText.getStringObj(wInfoItem.BuyUpdate, "", "~ "+PText.dateToString(wInfoItem.BuyUpdate, 2)+" ~\n", false)+PText.priceToString(wInfoItem.BuyPriceEstimation); break;
     case 2 : str=PText.getStringObj(wInfoItem.BuyUpdate, "", "~ "+PText.dateToString(wInfoItem.BuyUpdate, 2)+" ~\n", false)+PText.getString(wInfoItem.BuyPriceComment, "", false); break;
    }
   }
   TA_Buy.setText(PText.getString(str, "", false));
  }
 }
 
 void initPrivGUIShow(){
  boolean allow;
  
  allow=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;
  ShowBuyPrice=allow;
  
  PGUI.setEnabled(allow, CB_Buy);
  if(!allow && CB_Buy.isSelected()){CB_Buy.setSelected(false); CB_BuyActionPerformed(null);}
  
  PGUI.setEnabled(allow, CB_VartViewBuyPrice, CB_VartViewBuyComment, CB_VartViewBuyUpdate);
  if(!allow && (CB_VartViewBuyPrice.isSelected() || CB_VartViewBuyComment.isSelected() || CB_VartViewBuyUpdate.isSelected())){
   PGUI.setSelected(false, CB_VartViewBuyPrice, CB_VartViewBuyComment, CB_VartViewBuyUpdate); changeVartViewByNormal();}
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jSeparator1 = new javax.swing.JSeparator();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  CB_Active = new javax.swing.JCheckBox();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_Id = new javax.swing.JTextArea();
  Lbl_IdName = new javax.swing.JLabel();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_Name = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  Lbl_Comment = new javax.swing.JLabel();
  CB_IsOpname = new javax.swing.JCheckBox();
  jSeparator2 = new javax.swing.JSeparator();
  jPanel4 = new javax.swing.JPanel();
  CB_AutoUpdateStock = new javax.swing.JCheckBox();
  TF_Stock = new javax.swing.JTextField();
  Lbl_Stock = new javax.swing.JLabel();
  jPanel5 = new javax.swing.JPanel();
  TF_OrderSpec = new javax.swing.JTextField();
  CB_IsReorder = new javax.swing.JCheckBox();
  Lbl_OrderSpec = new javax.swing.JLabel();
  jSeparator3 = new javax.swing.JSeparator();
  jPanel6 = new javax.swing.JPanel();
  TF_Expire = new javax.swing.JTextField();
  CB_Exp = new javax.swing.JCheckBox();
  Lbl_Exp = new javax.swing.JLabel();
  jSeparator4 = new javax.swing.JSeparator();
  jPanel7 = new javax.swing.JPanel();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_Sell = new javax.swing.JTextArea();
  CB_Sell = new javax.swing.JCheckBox();
  filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(106, 0), new java.awt.Dimension(106, 0), new java.awt.Dimension(106, 32767));
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_Buy = new javax.swing.JTextArea();
  CB_Buy = new javax.swing.JCheckBox();
  CmB_Sell = new javax.swing.JComboBox<>();
  CmB_Buy = new javax.swing.JComboBox<>();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_Picture = new javax.swing.JPanel();
  Pnl_Image = new XImgBoxURL();
  jScrollPane13 = new javax.swing.JScrollPane();
  List_Pic = new XList();
  Panel_Variant = new javax.swing.JPanel();
  jPanel9 = new javax.swing.JPanel();
  jLabel3 = new javax.swing.JLabel();
  jScrollPane6 = new javax.swing.JScrollPane();
  List_Sec = new XList();
  jPanel10 = new javax.swing.JPanel();
  jPanel11 = new javax.swing.JPanel();
  Pnl_VartInfoPreview = new XImgBoxURL();
  jPanel13 = new javax.swing.JPanel();
  jPanel12 = new javax.swing.JPanel();
  CB_VartViewBuyUpdate = new javax.swing.JToggleButton();
  CB_VartViewBuyComment = new javax.swing.JToggleButton();
  CB_VartViewBuyPrice = new javax.swing.JToggleButton();
  CB_VartViewComment = new javax.swing.JToggleButton();
  jPanel14 = new javax.swing.JPanel();
  jScrollPane10 = new javax.swing.JScrollPane();
  TA_VartInfoBuy = new javax.swing.JTextArea();
  jScrollPane11 = new javax.swing.JScrollPane();
  TA_VartInfoName = new javax.swing.JTextArea();
  jLabel4 = new javax.swing.JLabel();
  jScrollPane12 = new javax.swing.JScrollPane();
  Tbl_Vart = new XTable();
  Panel_Etc = new javax.swing.JPanel();
  jPanel1 = new javax.swing.JPanel();
  jLabel1 = new javax.swing.JLabel();
  jScrollPane9 = new javax.swing.JScrollPane();
  List_Cat = new XList();
  jPanel8 = new javax.swing.JPanel();
  jLabel2 = new javax.swing.JLabel();
  jScrollPane7 = new javax.swing.JScrollPane();
  List_Tag = new XList();

  setTitle("Keterangan Barang");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  CB_Active.setText("Masih Aktif");
  CB_Active.setEnabled(false);
  CB_Active.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TA_Id.setEditable(false);
  TA_Id.setBackground(new java.awt.Color(204, 255, 204));
  TA_Id.setColumns(20);
  TA_Id.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Id.setLineWrap(true);
  TA_Id.setRows(1);
  TA_Id.setWrapStyleWord(true);
  jScrollPane1.setViewportView(TA_Id);

  Lbl_IdName.setText("Id & Nama");

  TA_Name.setEditable(false);
  TA_Name.setBackground(new java.awt.Color(204, 255, 204));
  TA_Name.setColumns(20);
  TA_Name.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Name.setLineWrap(true);
  TA_Name.setRows(1);
  TA_Name.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_Name);

  TA_Comment.setEditable(false);
  TA_Comment.setBackground(new java.awt.Color(204, 255, 204));
  TA_Comment.setColumns(20);
  TA_Comment.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Comment.setLineWrap(true);
  TA_Comment.setRows(5);
  TA_Comment.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_Comment);

  Lbl_Comment.setText("Keterangan");

  CB_IsOpname.setText("Di-Opname");
  CB_IsOpname.setEnabled(false);
  CB_IsOpname.setMargin(new java.awt.Insets(0, 0, 0, 0));

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(CB_IsOpname)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_Active))
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_IdName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_Comment, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addComponent(jScrollPane1)
     .addComponent(jScrollPane3)))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Active)
     .addComponent(CB_IsOpname))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_IdName)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane3)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(Lbl_Comment)
      .addGap(0, 0, Short.MAX_VALUE))))
  );

  CB_AutoUpdateStock.setText("Di-Perbarui");
  CB_AutoUpdateStock.setEnabled(false);
  CB_AutoUpdateStock.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TF_Stock.setEditable(false);
  TF_Stock.setBackground(new java.awt.Color(204, 255, 204));
  TF_Stock.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N

  Lbl_Stock.setText("Stok");

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(Lbl_Stock, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Stock)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_AutoUpdateStock, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Lbl_Stock)
    .addComponent(CB_AutoUpdateStock))
  );

  TF_OrderSpec.setEditable(false);
  TF_OrderSpec.setBackground(new java.awt.Color(204, 255, 204));
  TF_OrderSpec.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N

  CB_IsReorder.setText("Di-Reorder");
  CB_IsReorder.setEnabled(false);
  CB_IsReorder.setMargin(new java.awt.Insets(0, 0, 0, 0));

  Lbl_OrderSpec.setText("OrderSpec");

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(Lbl_OrderSpec, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_OrderSpec)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_IsReorder, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_OrderSpec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_IsReorder)
    .addComponent(Lbl_OrderSpec))
  );

  TF_Expire.setEditable(false);
  TF_Expire.setBackground(new java.awt.Color(204, 255, 204));
  TF_Expire.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N

  CB_Exp.setText("Berkadaluarsa");
  CB_Exp.setEnabled(false);
  CB_Exp.setMargin(new java.awt.Insets(0, 0, 0, 0));

  Lbl_Exp.setText("Expire");

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(Lbl_Exp, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Expire)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_Exp, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_Expire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_Exp)
    .addComponent(Lbl_Exp))
  );

  TA_Sell.setEditable(false);
  TA_Sell.setBackground(new java.awt.Color(204, 255, 204));
  TA_Sell.setColumns(20);
  TA_Sell.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Sell.setLineWrap(true);
  TA_Sell.setRows(1);
  TA_Sell.setWrapStyleWord(true);
  jScrollPane4.setViewportView(TA_Sell);

  CB_Sell.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Sell.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellActionPerformed(evt);
   }
  });

  TA_Buy.setEditable(false);
  TA_Buy.setBackground(new java.awt.Color(204, 255, 204));
  TA_Buy.setColumns(20);
  TA_Buy.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Buy.setLineWrap(true);
  TA_Buy.setRows(5);
  TA_Buy.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_Buy);

  CB_Buy.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Buy.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyActionPerformed(evt);
   }
  });

  CmB_Sell.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jual", "H Jual", "Kt Jual" }));
  CmB_Sell.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_SellActionPerformed(evt);
   }
  });

  CmB_Buy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beli", "H Beli", "Kt Beli" }));
  CmB_Buy.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_BuyActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(CB_Sell)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_Sell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(CB_Buy)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_Buy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane5)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE)))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(CmB_Sell)
       .addComponent(CB_Sell, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(CmB_Buy)
       .addComponent(CB_Buy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addGap(0, 0, Short.MAX_VALUE))))
  );

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator2)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator3)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator4)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  List_Pic.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_PicMouseReleased(evt);
   }
  });
  List_Pic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PicKeyReleased(evt);
   }
  });
  jScrollPane13.setViewportView(List_Pic);

  javax.swing.GroupLayout Panel_PictureLayout = new javax.swing.GroupLayout(Panel_Picture);
  Panel_Picture.setLayout(Panel_PictureLayout);
  Panel_PictureLayout.setHorizontalGroup(
   Panel_PictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_Image, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE)
   .addComponent(jScrollPane13)
  );
  Panel_PictureLayout.setVerticalGroup(
   Panel_PictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_PictureLayout.createSequentialGroup()
    .addComponent(Pnl_Image, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("Gambar", Panel_Picture);

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setText("- - Secondary Id");

  jScrollPane6.setViewportView(List_Sec);

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(jLabel3)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane6)
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
    .addComponent(jLabel3)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE))
  );

  Pnl_VartInfoPreview.setToolTipText("klik utk melihat pembesaran gambar");
  Pnl_VartInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_VartInfoPreviewMouseClicked(evt);
   }
  });

  jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_VartViewBuyUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewBuyUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewBuyUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewBuyUpdate.setText("Tgl");
  CB_VartViewBuyUpdate.setToolTipText("Tanggal Pembaruan");
  CB_VartViewBuyUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewBuyUpdate.setIconTextGap(0);
  CB_VartViewBuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewBuyUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewBuyUpdateActionPerformed(evt);
   }
  });

  CB_VartViewBuyComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewBuyComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewBuyComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewBuyComment.setText("Ket H-Beli");
  CB_VartViewBuyComment.setToolTipText("Keterangan Harga Beli");
  CB_VartViewBuyComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewBuyComment.setIconTextGap(0);
  CB_VartViewBuyComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewBuyComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewBuyCommentActionPerformed(evt);
   }
  });

  CB_VartViewBuyPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewBuyPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewBuyPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewBuyPrice.setText("H-Beli");
  CB_VartViewBuyPrice.setToolTipText("Harga Beli");
  CB_VartViewBuyPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewBuyPrice.setIconTextGap(0);
  CB_VartViewBuyPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewBuyPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewBuyPriceActionPerformed(evt);
   }
  });

  CB_VartViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewComment.setText("Ket");
  CB_VartViewComment.setToolTipText("Keterangan");
  CB_VartViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewComment.setIconTextGap(0);
  CB_VartViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewCommentActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
    .addComponent(CB_VartViewComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_VartViewBuyPrice)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_VartViewBuyComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_VartViewBuyUpdate)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_VartViewBuyUpdate)
    .addComponent(CB_VartViewBuyComment)
    .addComponent(CB_VartViewBuyPrice)
    .addComponent(CB_VartViewComment))
  );

  TA_VartInfoBuy.setEditable(false);
  TA_VartInfoBuy.setBackground(new java.awt.Color(204, 255, 204));
  TA_VartInfoBuy.setLineWrap(true);
  TA_VartInfoBuy.setWrapStyleWord(true);
  jScrollPane10.setViewportView(TA_VartInfoBuy);

  TA_VartInfoName.setEditable(false);
  TA_VartInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_VartInfoName.setLineWrap(true);
  TA_VartInfoName.setWrapStyleWord(true);
  jScrollPane11.setViewportView(TA_VartInfoName);

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane10)
   .addComponent(jScrollPane11)
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
    .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addComponent(Pnl_VartInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_VartInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("- - Varian");

  Tbl_Vart.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Vart.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Vart.setRowHeight(17);
  Tbl_Vart.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_VartMouseReleased(evt);
   }
  });
  Tbl_Vart.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_VartKeyReleased(evt);
   }
  });
  jScrollPane12.setViewportView(Tbl_Vart);

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addComponent(jLabel4)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
    .addComponent(jLabel4)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Panel_VariantLayout = new javax.swing.GroupLayout(Panel_Variant);
  Panel_Variant.setLayout(Panel_VariantLayout);
  Panel_VariantLayout.setHorizontalGroup(
   Panel_VariantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_VariantLayout.setVerticalGroup(
   Panel_VariantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_VariantLayout.createSequentialGroup()
    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("Varian", Panel_Variant);

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("- - Kategori");

  jScrollPane9.setViewportView(List_Cat);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel1)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel1)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE))
  );

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setText("- - Tag");

  jScrollPane7.setViewportView(List_Tag);

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(jLabel2)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane7)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
    .addComponent(jLabel2)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout Panel_EtcLayout = new javax.swing.GroupLayout(Panel_Etc);
  Panel_Etc.setLayout(Panel_EtcLayout);
  Panel_EtcLayout.setHorizontalGroup(
   Panel_EtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_EtcLayout.setVerticalGroup(
   Panel_EtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_EtcLayout.createSequentialGroup()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("Dll", Panel_Etc);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(TabbedPane)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jSeparator1)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(TabbedPane, javax.swing.GroupLayout.Alignment.TRAILING))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;

  initPrivGUIShow();

  fillComponentsWithSetVariables();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void CmB_BuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_BuyActionPerformed
  fillBuy();
 }//GEN-LAST:event_CmB_BuyActionPerformed

 private void CmB_SellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_SellActionPerformed
  fillSell();
 }//GEN-LAST:event_CmB_SellActionPerformed

 private void CB_BuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyActionPerformed
  fillBuy();
 }//GEN-LAST:event_CB_BuyActionPerformed

 private void CB_SellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellActionPerformed
  fillSell();
 }//GEN-LAST:event_CB_SellActionPerformed

 private void Tbl_VartKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_VartKeyReleased
  onSelectedRowVartChanged(false);
 }//GEN-LAST:event_Tbl_VartKeyReleased

 private void Tbl_VartMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_VartMouseReleased
  onSelectedRowVartChanged(false);
 }//GEN-LAST:event_Tbl_VartMouseReleased

 private void List_PicKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PicKeyReleased
  onPicRowSelected(false);
 }//GEN-LAST:event_List_PicKeyReleased

 private void List_PicMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_PicMouseReleased
  onPicRowSelected(false);
 }//GEN-LAST:event_List_PicMouseReleased

 private void Pnl_VartInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_VartInfoPreviewMouseClicked
  int RowVart;
  Object[] objs;
  String PictureFile;
  F_ImagePreview fm=IFV.FImagePreview;
  
  RowVart=Tbl_Vart.getSelectedRow();
  if(RowVart==-1){return;}
  
  objs=TableMdlVart.Mdl.Rows.elementAt(RowVart);
  PictureFile=PText.getString(PCore.objString(objs[6], null), null, true);
  if(PictureFile==null){return;}
  
  fm.wTitle="Gambar Varian";
  fm.wAutoHideListPic=true;
  fm.wImageDir=IFV.Conf.ImageDirItem;
  fm.wModeFetchList=1;
  fm.wList=PCore.vectObj(PictureFile);
  
  if(!fm.showForm()){return;}
 }//GEN-LAST:event_Pnl_VartInfoPreviewMouseClicked

 private void CB_VartViewBuyUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewBuyUpdateActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewBuyUpdateActionPerformed

 private void CB_VartViewBuyCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewBuyCommentActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewBuyCommentActionPerformed

 private void CB_VartViewBuyPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewBuyPriceActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewBuyPriceActionPerformed

 private void CB_VartViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewCommentActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewCommentActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JCheckBox CB_Active;
 private javax.swing.JCheckBox CB_AutoUpdateStock;
 private javax.swing.JCheckBox CB_Buy;
 private javax.swing.JCheckBox CB_Exp;
 private javax.swing.JCheckBox CB_IsOpname;
 private javax.swing.JCheckBox CB_IsReorder;
 private javax.swing.JCheckBox CB_Sell;
 private javax.swing.JToggleButton CB_VartViewBuyComment;
 private javax.swing.JToggleButton CB_VartViewBuyPrice;
 private javax.swing.JToggleButton CB_VartViewBuyUpdate;
 private javax.swing.JToggleButton CB_VartViewComment;
 private javax.swing.JComboBox<String> CmB_Buy;
 private javax.swing.JComboBox<String> CmB_Sell;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_Exp;
 private javax.swing.JLabel Lbl_IdName;
 private javax.swing.JLabel Lbl_OrderSpec;
 private javax.swing.JLabel Lbl_Stock;
 private XList List_Cat;
 private XList List_Pic;
 private XList List_Sec;
 private XList List_Tag;
 private javax.swing.JPanel Panel_Etc;
 private javax.swing.JPanel Panel_Picture;
 private javax.swing.JPanel Panel_Variant;
 private XImgBoxURL Pnl_Image;
 private XImgBoxURL Pnl_VartInfoPreview;
 private javax.swing.JTextArea TA_Buy;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextArea TA_Id;
 private javax.swing.JTextArea TA_Name;
 private javax.swing.JTextArea TA_Sell;
 private javax.swing.JTextArea TA_VartInfoBuy;
 private javax.swing.JTextArea TA_VartInfoName;
 private javax.swing.JTextField TF_Expire;
 private javax.swing.JTextField TF_OrderSpec;
 private javax.swing.JTextField TF_Stock;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_Vart;
 private javax.swing.Box.Filler filler1;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane12;
 private javax.swing.JScrollPane jScrollPane13;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane9;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 // End of variables declaration//GEN-END:variables
}
