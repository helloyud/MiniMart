public class OLabelDataItem extends OLabelData {

 long ItemId;
 String ItemName;
 double ItemSellPrice;
 String PromoComment;
 
 public OLabelDataItem(long ItemId, String ItemName, double ItemSellPrice, String PromoComment){
  setData(ItemId, ItemName, ItemSellPrice, PromoComment);
 }
 
 public void setData(long ItemId, String ItemName, double ItemSellPrice, String PromoComment) {
  this.ItemId = ItemId;
  this.ItemName = ItemName;
  this.ItemSellPrice = ItemSellPrice;
  this.PromoComment = PromoComment;
 }
 
}