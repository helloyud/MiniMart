import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_ItemLabelModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 long wItemId;
 int wLabelCount;
 String wPromo;
 boolean wInitPromo;
 int wInitPromoIndex;
 
 // get
 String Promo;
 
 //
  // Item
 long CheckedItemId, I_CheckedItemId;
 long LastInputId;
 OInfoItem ItemDet, I_ItemDet;
 boolean InputInfoClearedItem;
  // Qty
 int Qty; double I_Qty;
 
 //
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 Color Lbl_PromoColor;
 
 public F_ItemLabelModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  //
  EnableDocumentListener=new VBoolean(true);
  
  TF_LabelCount.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQty();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQty();
     }
    }
    
   });
  
  EnableDocumentListener.Value=true;
  
  InputInfoClearedItem=true;
  
  //
  I_ItemDet=new OInfoItem();
  Lbl_PromoColor=Lbl_Promo.getForeground();
  
  clearItemId();
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  I_Qty=-1;
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_ItemId, Btn_ChooseItem, CmB_ItemComment,
    TF_LabelCount,
    CB_InitPromo, TF_Promo,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearInputLabel();
  Lbl_ItemId.setForeground(CGUI.Color_Label_InputRight);
  Lbl_LabelCount.setForeground(CGUI.Color_Label_InputRight);
  Lbl_Promo.setForeground(Lbl_PromoColor);
  clearSetVariables();
 }
 void clearSetVariables(){
  wPromo=null;
 }
 
 // Input
  // Item
 void clearItemId(){
  TF_ItemId.setText(""); LastInputId=-1; I_CheckedItemId=-1; clearItem();
 }
 boolean changeLastInputId(){
  boolean ret=false;
  long Input;
  String str=TF_ItemId.getText();
  
  // convert input in TF_ItemId to number; if input is empty or false, then value it to -1
  Input=-1;
  if(str.length()!=0){
   try{Input=Long.parseLong(str);}catch(Exception E){Input=-1;}
  }
  
  if(Input!=LastInputId){
   ret=true; LastInputId=Input;
  }
  
  return ret;
 }
 void changeItem(boolean FillOtherInputFromItem){
  OInfoItem InfoItem;
  
  InfoItem=PMyShop.getItemInfo(IFV.Stm, LastInputId, false);
  if(InfoItem==null){
   I_CheckedItemId=-1; clearItem();
   if(FillOtherInputFromItem){clearInputFromItem();}
   return;
  }
  
  I_ItemDet=InfoItem;
  I_CheckedItemId=LastInputId;
  
  changeItemQuantityPrice();
  
  setIQty(I_Qty, false);
  fillInputInfoItem();
  
  if(FillOtherInputFromItem){fillInputFromItem();}
 }
 void inputItem(boolean FillOtherInputFromItem){
  if(!changeLastInputId()){return;}
  changeItem(FillOtherInputFromItem);
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
 }
 void fillInputInfoItem(){
  if(I_CheckedItemId==-1){clearInputInfoItem(); return;}
  
  TA_ItemName.setText(I_ItemDet.Name);
  TF_ItemPrice.setText(PText.priceToString(I_ItemDet.SellPrice));
  fillItemComment();
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  TA_ItemName.setText("");
  TF_ItemPrice.setText("");
  TA_ItemComment.setText("");
  
  InputInfoClearedItem=true;
 }
 String getItemComment(){
  String ret=null;
  
  do{
   if(I_CheckedItemId==-1){break;}

   switch(CmB_ItemComment.getSelectedIndex()){
    case 0 : ret=I_ItemDet.Comment; break;
    case 1 : if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){ret=I_ItemDet.BuyPriceComment;} break;
    case 2 : ret=I_ItemDet.SellPriceComment; break;
   }
  }while(false);
  
  return PText.getString(ret, "", false);
 }
 void fillItemComment(){
  TA_ItemComment.setText(getItemComment());
 }
 void clearItem(){
  clearInputInfoItem();
  
  clearInputFromItem();
 }
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_LabelCount, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_LabelCount, "");}}
 }
 void inputQty(){
  I_Qty=PText.parseDouble(TF_LabelCount.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}
  
  if(I_Qty<=0){return;}
 }
 int getLabelCount(){
  int US_Qty; // unit standard's quantity
  
  US_Qty=PMath.round(I_Qty, 1); if(US_Qty<=0){US_Qty=1;}
  
  return US_Qty;
 }
  // Promo
 void fillPromo(){
  String str;
  
  if(I_CheckedItemId==-1){return;}
  
  str=null; if(CB_InitPromo.isSelected()){str=getItemComment();}
  TF_Promo.setText(PText.singleLine(PText.getString(str, "", false), '~'));
 }
  // Others
 void clearInputLabel(){
  clearItemId();
  setIQty(-1, true);
  TF_Promo.setText("");
 }
 void fillInputFromItem(){
  if(I_CheckedItemId==-1){return;}
  fillPromo();
 }
 void clearInputFromItem(){
  
 }
 void fillInputVariablesIntoRealVariables(){
  CheckedItemId=I_CheckedItemId;
  ItemDet=I_ItemDet;
  
  Qty=getLabelCount();
 }
 
 //
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 
 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_ItemId = new javax.swing.JTextField();
  Lbl_ItemId = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  TF_ItemPrice = new javax.swing.JTextField();
  TF_LabelCount = new javax.swing.JTextField();
  TF_Promo = new javax.swing.JTextField();
  Lbl_ItemName = new javax.swing.JLabel();
  Lbl_ItemPrice = new javax.swing.JLabel();
  Lbl_LabelCount = new javax.swing.JLabel();
  Lbl_Promo = new javax.swing.JLabel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Btn_ChooseItem = new javax.swing.JButton();
  CmB_ItemComment = new javax.swing.JComboBox<>();
  CB_InitPromo = new javax.swing.JCheckBox();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemComment = new javax.swing.JTextArea();

  setTitle("Ubah Data Label");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_ItemId.setToolTipText("{F6} ket brg {Spasi} cari brg");
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Barang");

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(20);
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setRows(1);
  TA_ItemName.setToolTipText("klik utk melihat keterangan barang");
  TA_ItemName.setWrapStyleWord(true);
  TA_ItemName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_ItemName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_ItemNameMouseClicked(evt);
   }
  });
  jScrollPane1.setViewportView(TA_ItemName);

  TF_ItemPrice.setEditable(false);
  TF_ItemPrice.setBackground(new java.awt.Color(204, 255, 204));

  TF_LabelCount.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_LabelCount.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelCountFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_LabelCountFocusLost(evt);
   }
  });
  TF_LabelCount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelCountKeyPressed(evt);
   }
  });

  TF_Promo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_Promo.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PromoFocusGained(evt);
   }
  });
  TF_Promo.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PromoKeyPressed(evt);
   }
  });

  Lbl_ItemName.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_ItemName.setText("- Nama");

  Lbl_ItemPrice.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_ItemPrice.setText("- Harga Jual ");

  Lbl_LabelCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_LabelCount.setText("Jumlah Label");

  Lbl_Promo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Promo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_Promo.setText("Komntr");
  Lbl_Promo.setToolTipText("Klik untuk melihat \"Catatan Input Komentar\" !");
  Lbl_Promo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_Promo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PromoMouseClicked(evt);
   }
  });

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });
  Btn_ChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseItemKeyPressed(evt);
   }
  });

  CmB_ItemComment.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  CmB_ItemComment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ket. Umum", "Ket. Beli", "Ket. Jual" }));
  CmB_ItemComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ItemCommentActionPerformed(evt);
   }
  });
  CmB_ItemComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ItemCommentKeyPressed(evt);
   }
  });

  CB_InitPromo.setToolTipText("Centang opsi ini utk menginisialisasi komentar dgn \"Ket. Brg\"");
  CB_InitPromo.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_InitPromo.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_InitPromoKeyPressed(evt);
   }
  });

  TA_ItemComment.setEditable(false);
  TA_ItemComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemComment.setColumns(20);
  TA_ItemComment.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemComment.setLineWrap(true);
  TA_ItemComment.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemComment);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_ItemId)
       .addComponent(Lbl_ItemName)
       .addComponent(Lbl_ItemPrice)
       .addGroup(layout.createSequentialGroup()
        .addComponent(Lbl_Promo)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(CB_InitPromo))
       .addComponent(Lbl_LabelCount)
       .addComponent(CmB_ItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_ItemPrice)
       .addComponent(jScrollPane1)
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
        .addComponent(TF_ItemId)
        .addGap(0, 0, 0)
        .addComponent(Btn_ChooseItem))
       .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
       .addComponent(TF_Promo)
       .addComponent(TF_LabelCount))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ItemId)
     .addComponent(Btn_ChooseItem))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_ItemName)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ItemPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ItemPrice))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(CmB_ItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, Short.MAX_VALUE))
     .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_LabelCount))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_InitPromo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_Promo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_Promo)))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean valid;
  
  // check input
  inputItem(true);
  
  valid=true;
  
  if(I_CheckedItemId!=-1){Lbl_ItemId.setForeground(CGUI.Color_Label_InputRight);}
  else{Lbl_ItemId.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  if(I_Qty>0){Lbl_LabelCount.setForeground(CGUI.Color_Label_InputRight);}
  else{Lbl_LabelCount.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  if(PText.checkInput(TF_Promo.getText(), true, 0, 0, 1, 1, 0)){Lbl_Promo.setForeground(Lbl_PromoColor);}
  else{Lbl_Promo.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  if(!valid){
   JOptionPane.showMessageDialog(null, "Input masih salah, silahkan koreksi label yg berwarna merah !");
   return;
  }
  
  // fill get variables
  fillInputVariablesIntoRealVariables();
  Promo=TF_Promo.getText();
  
  // close form
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ItemId, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseItem)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F6 : inputItem(true); break;
   case KeyEvent.VK_ENTER : TF_LabelCount.requestFocusInWindow(); break;
   case KeyEvent.VK_DOWN : TF_LabelCount.requestFocusInWindow(); break;
   case KeyEvent.VK_SPACE : evt.consume(); Btn_ChooseItemActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  inputItem(true);
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  LastInputId=IFV.FItem.ChoosedId[0];
  TF_ItemId.setText(String.valueOf(LastInputId));
  changeItem(true);
  TF_LabelCount.requestFocusInWindow();
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void TF_LabelCountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelCountKeyPressed
  int consumed=PNav.onKey_TF(this, TF_LabelCount, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Promo)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_LabelCountKeyPressed

 private void TF_PromoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PromoKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Promo, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_LabelCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_InitPromo)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_PromoKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : TF_Promo.requestFocusInWindow(); break;
   case KeyEvent.VK_RIGHT : Btn_Cancel.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : TF_Promo.requestFocusInWindow(); break;
   case KeyEvent.VK_LEFT : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(!Activ){
   Activ=true;
   
   CB_InitPromo.setSelected(wInitPromo);
   if(wInitPromoIndex>=0 && wInitPromoIndex<CmB_ItemComment.getItemCount()){
    CmB_ItemComment.setSelectedIndex(wInitPromoIndex);
   }
   
   TF_ItemId.setText(String.valueOf(wItemId)); inputItem(false);
   setIQty(wLabelCount, false);
   TF_Promo.setText(wPromo);
   
   TF_LabelCount.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_PromoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PromoMouseClicked
  JOptionPane.showMessageDialog(null, PMyShop.getLabelCommentInputInfo()+
   "\n\nAturan input !\n"+PText.getInputInfo(true, 0, 0, 1, 1, 0, false));
 }//GEN-LAST:event_Lbl_PromoMouseClicked

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  TF_ItemId.selectAll();
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void TF_LabelCountFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelCountFocusGained
  DocumentListenerFocus=1;
  TF_LabelCount.selectAll();
 }//GEN-LAST:event_TF_LabelCountFocusGained

 private void TF_PromoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PromoFocusGained
  TF_Promo.selectAll();
 }//GEN-LAST:event_TF_PromoFocusGained

 private void CmB_ItemCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ItemCommentActionPerformed
  fillItemComment();
 }//GEN-LAST:event_CmB_ItemCommentActionPerformed

 private void TF_LabelCountFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelCountFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_LabelCountFocusLost

 private void TA_ItemNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_ItemNameMouseClicked
  if(I_CheckedItemId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedItemId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_ItemNameMouseClicked

 private void Btn_ChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseItemKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_LabelCount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseItemKeyPressed

 private void CmB_ItemCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ItemCommentKeyPressed
  PNav.onKey_CmB(this, CmB_ItemComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_LabelCount)));
 }//GEN-LAST:event_CmB_ItemCommentKeyPressed

 private void CB_InitPromoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_InitPromoKeyPressed
  PNav.onKey_CB(this, CB_InitPromo, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_LabelCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Promo)));
 }//GEN-LAST:event_CB_InitPromoKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_InitPromo;
 private javax.swing.JComboBox<String> CmB_ItemComment;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_ItemName;
 private javax.swing.JLabel Lbl_ItemPrice;
 private javax.swing.JLabel Lbl_LabelCount;
 private javax.swing.JLabel Lbl_Promo;
 private javax.swing.JTextArea TA_ItemComment;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_ItemPrice;
 private javax.swing.JTextField TF_LabelCount;
 private javax.swing.JTextField TF_Promo;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 // End of variables declaration//GEN-END:variables
}
