public class OPreventAutoFire extends OPrevent {
 
 boolean IsPrevent;
 
 public OPreventAutoFire(){IsPrevent=false;}
 
 public void doPrevent(boolean Prevent){IsPrevent=Prevent;}
 public boolean isPrevent(){return IsPrevent;}
 public void preventConfirmed(){IsPrevent=false;}

}