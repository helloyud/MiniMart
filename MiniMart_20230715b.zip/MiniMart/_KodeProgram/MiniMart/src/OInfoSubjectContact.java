public class OInfoSubjectContact {
 
 int Enumeration;
 String Cont;
 int ContactTypeId; String ContactTypeName;
 String Comment;

}