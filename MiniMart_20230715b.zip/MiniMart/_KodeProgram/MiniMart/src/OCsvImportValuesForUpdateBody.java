import java.util.Vector;

public class OCsvImportValuesForUpdateBody extends OCsvImportValuesInColsAndValues {

 public OCsvImportValuesForUpdateBody(Vector<String> Columns, Vector<OCsvImportValue> ColumnsValue) {
  int ColumnsCount=Columns.size();
  initVariables(PCore.vect(PCore.newStringArray(ColumnsCount, ",")), Columns, PCore.vect(PCore.newStringArray(ColumnsCount, "=")), ColumnsValue);
 }
 
}