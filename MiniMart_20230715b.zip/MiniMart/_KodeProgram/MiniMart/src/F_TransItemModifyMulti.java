import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_TransItemModifyMulti extends XFormDialog {
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeQuantity; double Quantity;
 boolean ChangePriceUnit; double PriceUnit;
 boolean ChangePriceTotal; double PriceTotal;
 boolean ChangeTransItemComment; boolean ChangeTransItemCommentSubString; String TransItemCommentFind; String TransItemComment;
 
 public F_TransItemModifyMulti(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  CB_TransItemCommentSubActionPerformed(null);
 }
 
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_TransItemComment, TF_TransItemCommentSub, CB_TransItemCommentSub, TF_TransItemComment,
    CB_Quantity, TF_Quantity,
    CB_Price, CmB_Price, TF_Price,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void closingForm(){
  CB_Quantity.setSelected(false); CB_Quantity.setForeground(CGUI.Color_Label_InputRight); TF_Quantity.setText("");
  CB_Price.setSelected(false); CB_Price.setForeground(CGUI.Color_Label_InputRight); TF_Price.setText("");
  CB_TransItemComment.setSelected(false); CB_TransItemComment.setForeground(CGUI.Color_Label_InputRight); TF_TransItemCommentSub.setText(""); TF_TransItemComment.setText("");
  Activ=false;
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Price = new javax.swing.ButtonGroup();
  TF_Price = new javax.swing.JTextField();
  TF_Quantity = new javax.swing.JTextField();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  CB_Price = new javax.swing.JCheckBox();
  CB_Quantity = new javax.swing.JCheckBox();
  Lbl_DataCount = new javax.swing.JLabel();
  CmB_Price = new javax.swing.JComboBox<>();
  CB_TransItemComment = new javax.swing.JCheckBox();
  CB_TransItemCommentSub = new javax.swing.JCheckBox();
  TF_TransItemCommentSub = new javax.swing.JTextField();
  TF_TransItemComment = new javax.swing.JTextField();
  Lbl_CommentHelp = new javax.swing.JLabel();

  setTitle("Ubah Beberapa Data Barang Pada Suatu Transaksi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_Price.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PriceKeyPressed(evt);
   }
  });

  TF_Quantity.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_Quantity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QuantityKeyPressed(evt);
   }
  });

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  CB_Price.setToolTipText("centang utk mengubah harga");
  CB_Price.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PriceKeyPressed(evt);
   }
  });

  CB_Quantity.setText("Kuantitas");
  CB_Quantity.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Quantity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QuantityKeyPressed(evt);
   }
  });

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data");

  CmB_Price.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hrg Satuan", "Hrg Total" }));
  CmB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PriceKeyPressed(evt);
   }
  });

  CB_TransItemComment.setText("Komentar");
  CB_TransItemComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransItemComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransItemCommentKeyPressed(evt);
   }
  });

  CB_TransItemCommentSub.setText("Ganti Sub-Kata");
  CB_TransItemCommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransItemCommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransItemCommentSubActionPerformed(evt);
   }
  });
  CB_TransItemCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransItemCommentSubKeyPressed(evt);
   }
  });

  TF_TransItemCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransItemCommentSubKeyPressed(evt);
   }
  });

  TF_TransItemComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransItemCommentKeyPressed(evt);
   }
  });

  Lbl_CommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentHelp.setText("(?)");
  Lbl_CommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 181, Short.MAX_VALUE)
      .addComponent(Lbl_DataCount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_Quantity)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_Price)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_TransItemComment)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_CommentHelp)))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_TransItemCommentSub)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_TransItemCommentSub))
       .addComponent(TF_Quantity)
       .addComponent(TF_Price)
       .addComponent(TF_TransItemComment))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_TransItemComment)
     .addComponent(CB_TransItemCommentSub)
     .addComponent(TF_TransItemCommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TransItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Quantity))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Price)
     .addComponent(TF_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)
     .addComponent(Lbl_DataCount))
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid, CurrCheck;
  
  ChangeQuantity=CB_Quantity.isSelected();
  ChangePriceUnit=CB_Price.isSelected() && CmB_Price.getSelectedIndex()==0;
  ChangePriceTotal=CB_Price.isSelected() && CmB_Price.getSelectedIndex()==1;
  ChangeTransItemComment=CB_TransItemComment.isSelected();
  if(!ChangeQuantity && !ChangePriceUnit && !ChangePriceTotal && !ChangeTransItemComment){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  IsValid=true;
  
  if(ChangeQuantity){
   try{Quantity=Double.parseDouble(TF_Quantity.getText());}catch(Exception E){Quantity=-1;}
   if(Quantity<=0){IsValid=false; CB_Quantity.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Quantity.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangePriceUnit){
   try{PriceUnit=Double.parseDouble(TF_Price.getText());}catch(Exception E){PriceUnit=-1;}
   if(PriceUnit<0){IsValid=false; CB_Price.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Price.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangePriceTotal){
   try{PriceTotal=Double.parseDouble(TF_Price.getText());}catch(Exception E){PriceTotal=-1;}
   if(PriceTotal<0){IsValid=false; CB_Price.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Price.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeTransItemComment){
   TransItemComment=TF_TransItemComment.getText();
   ChangeTransItemCommentSubString=CB_TransItemCommentSub.isSelected();
   if(!ChangeTransItemCommentSubString){CurrCheck=PText.checkInput(TransItemComment, true, CApp.DbVarcharMaxSize, 0, 0, 0, 0);}
   else{
    TransItemCommentFind=TF_TransItemCommentSub.getText();
    CurrCheck=TransItemCommentFind.length()!=0;
   }
   if(!CurrCheck){IsValid=false; CB_TransItemComment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_TransItemComment.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+
    "Silahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  DialogResult=1;
  closingForm();
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  DialogResult=0;
  closingForm();
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   
   Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data");
   
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  closingForm();
 }//GEN-LAST:event_formWindowClosing

 private void CB_QuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QuantityKeyPressed
  PNav.onKey_CB(this, CB_Quantity, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_TransItemComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Price)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Quantity)));
 }//GEN-LAST:event_CB_QuantityKeyPressed

 private void TF_QuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QuantityKeyPressed
  PNav.onKey_TF(this, TF_Quantity, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransItemComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Price)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Quantity)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_QuantityKeyPressed

 private void CB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PriceKeyPressed
  PNav.onKey_CB(this, CB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_Price)));
 }//GEN-LAST:event_CB_PriceKeyPressed

 private void CmB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PriceKeyPressed
  PNav.onKey_CmB(this, CmB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Price)));
 }//GEN-LAST:event_CmB_PriceKeyPressed

 private void TF_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PriceKeyPressed
  PNav.onKey_TF(this, TF_Price, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_PriceKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Price)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Price)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void CB_TransItemCommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransItemCommentSubActionPerformed
  PGUI.enableInput(CB_TransItemCommentSub.isSelected(), TF_TransItemCommentSub, true);
 }//GEN-LAST:event_CB_TransItemCommentSubActionPerformed

 private void CB_TransItemCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransItemCommentKeyPressed
  PNav.onKey_CB(this, CB_TransItemComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_TransItemCommentSub, CB_TransItemCommentSub)));
 }//GEN-LAST:event_CB_TransItemCommentKeyPressed

 private void TF_TransItemCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransItemCommentSubKeyPressed
  PNav.onKey_TF(this, TF_TransItemCommentSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransItemComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_TransItemComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_TransItemCommentSub)));
 }//GEN-LAST:event_TF_TransItemCommentSubKeyPressed

 private void CB_TransItemCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransItemCommentSubKeyPressed
  PNav.onKey_CB(this, CB_TransItemCommentSub, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransItemComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_TransItemCommentSub, CB_TransItemComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_TransItemCommentSubKeyPressed

 private void TF_TransItemCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransItemCommentKeyPressed
  PNav.onKey_TF(this, TF_TransItemComment, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransItemCommentSub, CB_TransItemCommentSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_TransItemComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_TransItemCommentKeyPressed

 private void Lbl_CommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true)+"\n"+
   "- Dalam mode 'Ganti Sub-Kata', inputan 'Ganti Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Komentar' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_CommentHelpMouseClicked

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_Price;
 private javax.swing.JCheckBox CB_Quantity;
 private javax.swing.JCheckBox CB_TransItemComment;
 private javax.swing.JCheckBox CB_TransItemCommentSub;
 private javax.swing.JComboBox<String> CmB_Price;
 private javax.swing.JLabel Lbl_CommentHelp;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.ButtonGroup RG_Price;
 private javax.swing.JTextField TF_Price;
 private javax.swing.JTextField TF_Quantity;
 private javax.swing.JTextField TF_TransItemComment;
 private javax.swing.JTextField TF_TransItemCommentSub;
 // End of variables declaration//GEN-END:variables
}
