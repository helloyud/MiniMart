import java.awt.Graphics2D;

public class ODrawComponentTable extends ODrawComponent {
 
 ODrawTable Tbl;
 
 public ODrawComponentTable(double OffsetX, double OffsetY, ODrawTable Tbl) {
  this.OffsetX=OffsetX;
  this.OffsetY=OffsetY;
  this.Tbl=Tbl;
 }
 
 public void draw(Graphics2D graphics, OGraphicsProperties Prop){
  Tbl.draw(graphics, Prop, OffsetX, OffsetY);
 }
 
 public ODimension calcDrawDimension(){
  ODimension ret=new ODimension();
  
  ret.setSize(Tbl.Width, Tbl.Height);
  
  return ret;
 }
 
}