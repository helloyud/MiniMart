import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;

public class OPrintGeneratorTrans extends OPrintGenerator{

 // additional printing properties
 LinkedList<Long> Id;
 boolean IsPreTrans;
 boolean OptMain_IdExternal;
 boolean OptInfo_IdInternal, OptInfo_IdExternal,
  OptInfo_Important, OptInfo_Comment, OptInfo_TransType,
  OptInfo_Date, OptInfo_CreditDays, OptInfo_DateBill, OptInfo_DateRepayment,
  OptInfo_CashOut, OptInfo_CashOutComment, OptInfo_CashIn, OptInfo_CashInComment,
  OptInfo_Subject, OptInfo_Salesman;
 boolean OptList_ItemIn, OptList_ItemOut, OptList_PaymentOut, OptList_PaymentIn;
 boolean OptList_ItemCategorized;
 boolean ShowListItemIn, ShowListItemOut;
 
 //
 /*
    CurrOperation :

    1 category header,
    
    21 trans, 22 trans info,
    31 trans item-in's header, 32 trans item-in's category header, 33 trans item-in's list,
    41 trans item-out's header, 42 trans item-out's category header, 43 trans item-out's list,
    51 trans pay-out's header, 52 trans pay-out's list,
    61 trans pay-in's header, 62 trans pay-in's list,
 
    7 summary
 */
 final int OpTransCategory_Header=1;
 final int OpTrans_Main=21; final int OpTrans_Info=22;
 final int OpTrans_ItemIn_Header=31; final int OpTrans_ItemIn_Category_Header=32; final int OpTrans_ItemIn_List=33;
 final int OpTrans_ItemOut_Header=41; final int OpTrans_ItemOut_Category_Header=42; final int OpTrans_ItemOut_List=43;
 final int OpTrans_PayOut_Header=51; final int OpTrans_PayOut_List=52;
 final int OpTrans_PayIn_Header=61; final int OpTrans_PayIn_List=62;
 final int OpTransCategory_Summary=7;
 
 String DbTable, DbItemIn, DbItemOut, DbPayOut, DbPayIn;
 String IdQ;
 Vector<OIdName> Category;
 int CurrOperation;
 ODrawTableRow TableNewRow, TableNewRow2, TableNewRow3;
 Statement Stm2; ResultSet Rs2;
 OQuickListOfLong PrintedItems;
 
 // Category Header
 int CurrCategory;
 
 // Trans List
 VDrawTable Table_Trans;
 VDrawTable Table_TransHeader;
 
 final int PointOfTransCharCount=2;
 final String PointOfTrans="*";
 
 // Trans Info
 long CurrTrans_Id;
 OInfoTrans CurrTrans_Info;
 Date CurrTrans_InfoDateBill;
 int CurrTrans_InfoItemInCount; double CurrTrans_InfoItemInPrice;
 int CurrTrans_InfoItemOutCount; double CurrTrans_InfoItemOutPrice;
 int CurrTrans_InfoPaymentOutCount; double CurrTrans_InfoPaymentOutPrice;
 int CurrTrans_InfoPaymentInCount; double CurrTrans_InfoPaymentInPrice;
 
 Vector<String> InfoTrans;
 
 // Trans's Items In
 int ItemInIdsCount;
 String ItemInIdsStr;
 Vector<OIdName> ItemInCategories;
 
 VDrawTable Table_ListItemIn, Table_ListItemInCategoryHeader;
 
 int ItemInCurrCategory;
 Vector<Object[]> ItemInList;
 int ItemInListCurrItem;
 
 int ItemInListItemCount;
 double ItemInListItemPrice;
 
 // Trans's Items Out
 int ItemOutIdsCount;
 String ItemOutIdsStr;
 Vector<OIdName> ItemOutCategories;
 
 VDrawTable Table_ListItemOut, Table_ListItemOutCategoryHeader;
 
 int ItemOutCurrCategory;
 Vector<Object[]> ItemOutList;
 int ItemOutListCurrItem;
 
 int ItemOutListItemCount;
 double ItemOutListItemPrice;
 
 // Trans's Pay Out
 VDrawTable Table_ListPayOut;
 
 // Trans's Pay In
 VDrawTable Table_ListPayIn;
 
 //
 final int PointOfTransListCharCount=2;
 final String PointOfTransList=">";
 final String PointOfTransListItemUnchecked="-";
 final String PointOfTransListItemChecked="o";
 final String PointOfTransListCategory="+";
 
 // Category Summary
 VDrawTable Table_CategorySummary;
 
 int TotalTransCount;
 double TotalItemInPrice, TotalItemOutPrice, TotalPaymentOutPrice, TotalPaymentInPrice;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 final int ColSizeId=18;
 final int ColSizeDate=11;
 final int ColSizeQty=7;
 final int ColSizePrice=14;
 final int ColSizeTextMin=10;
 final int ColSizeTextMed=20;
 final int ColSizeTextMax=30;
 double CategoryAddLineSpacing, CategoryToTransAddLineSpacing, CategorySumAddLineSpacing,
  PostTextAddLineSpacing, ItemCategoryAddLineSpacing;
 double TransToDetailAddLineSpacing;
 double TableListXIndent;
 int MaxCharTransList;
 double CellAreaMinHeight;
 boolean EnablePreAddLineSpacing, EnablePostAddLineSpacing;
 
 OPrintGeneratorTrans(OFont FontStandard) {
  super(FontStandard);
  
  Table_TransHeader=new VDrawTable();
  Table_Trans=new VDrawTable();
  Table_ListItemIn=new VDrawTable();
  Table_ListItemInCategoryHeader=new VDrawTable();
  Table_ListItemOut=new VDrawTable();
  Table_ListItemOutCategoryHeader=new VDrawTable();
  Table_ListPayOut=new VDrawTable();
  Table_ListPayIn=new VDrawTable();
  Table_CategorySummary=new VDrawTable();
  
  CurrTrans_Info=new OInfoTrans();
 }
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> Id, boolean IsPreTrans,
  
  boolean OptMain_IdExternal,
  
  boolean OptInfo_IdInternal, boolean OptInfo_IdExternal,
  boolean OptInfo_Important, boolean OptInfo_Comment, boolean OptInfo_TransType,
  boolean OptInfo_Date, boolean OptInfo_CreditDays, boolean OptInfo_DateBill, boolean OptInfo_DateRepayment,
  boolean OptInfo_CashOut, boolean OptInfo_CashOutComment, boolean OptInfo_CashIn, boolean OptInfo_CashInComment,
  boolean OptInfo_Subject, boolean OptInfo_Salesman,
  
  boolean OptList_ItemIn, boolean OptList_ItemOut,
  boolean OptList_PaymentOut, boolean OptList_PaymentIn,
  
  boolean OptList_ItemCategorized,
  
  boolean ShowListItemIn, boolean ShowListItemOut){
  
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.Id=Id;
  this.IsPreTrans=IsPreTrans;
  
  this.OptMain_IdExternal=OptMain_IdExternal;
  
  this.OptInfo_IdInternal=OptInfo_IdInternal;
  this.OptInfo_IdExternal=OptInfo_IdExternal;
  this.OptInfo_Important=OptInfo_Important;
  this.OptInfo_Comment=OptInfo_Comment;
  this.OptInfo_TransType=OptInfo_TransType;
  this.OptInfo_Date=OptInfo_Date;
  this.OptInfo_CreditDays=OptInfo_CreditDays;
  this.OptInfo_DateBill=OptInfo_DateBill;
  this.OptInfo_DateRepayment=OptInfo_DateRepayment;
  this.OptInfo_CashOut=OptInfo_CashOut;
  this.OptInfo_CashOutComment=OptInfo_CashOutComment;
  this.OptInfo_CashIn=OptInfo_CashIn;
  this.OptInfo_CashInComment=OptInfo_CashInComment;
  this.OptInfo_Subject=OptInfo_Subject;
  this.OptInfo_Salesman=OptInfo_Salesman;
  
  this.OptList_ItemIn=OptList_ItemIn;
  this.OptList_ItemOut=OptList_ItemOut;
  this.OptList_PaymentOut=OptList_PaymentOut;
  this.OptList_PaymentIn=OptList_PaymentIn;
  
  this.OptList_ItemCategorized=OptList_ItemCategorized;
  
  this.ShowListItemIn=ShowListItemIn;
  this.ShowListItemOut=ShowListItemOut;
 }
 
 // standard private methods
	protected boolean hasHeader(){return true;}
 protected boolean hasFooter(){return true;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(7.8f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(5.3f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  ODrawTableColumnMetadata[] Columns;
  OInset Inset;
  double TableListWidth;
  double temp_d;
  ODrawTable tbl;
  
  CellAreaMinHeight=NormalHeight;
  Inset=new OInset(0.2*FontHeight, 0.2*FontHeight, 0.7*FontWidth, 0.7*FontWidth);
  PostTextAddLineSpacing=0.2*FontHeight;
  ItemCategoryAddLineSpacing=0.6*FontHeight;
  
  // Category Header
  CategoryAddLineSpacing=3.0*FontHeight;
  CategoryToTransAddLineSpacing=0.75*FontHeight;
  
  // Trans
  Columns=new ODrawTableColumnMetadata[8+1];
  Columns[0]=new ODrawTableColumnMetadata(null, PointOfTransCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[1]=new ODrawTableColumnMetadata("Tgl", ColSizeDate*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[2]=new ODrawTableColumnMetadata("Tgl Tagih", ColSizeDate*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[3]=new ODrawTableColumnMetadata("Subjek", 0);
  Columns[4]=new ODrawTableColumnMetadata("Id", ColSizeId*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[5]=new ODrawTableColumnMetadata("Brg Masuk", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[6]=new ODrawTableColumnMetadata("Byr Keluar", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[7]=new ODrawTableColumnMetadata("Brg Keluar", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[8]=new ODrawTableColumnMetadata("Byr Masuk", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)+temp_d>ColumnarWidth){throw new Exception();}
  Columns[3].Width=ColumnarWidth-temp_d;
  
  Table_Trans.Value=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillEmpty);
  
  Table_TransHeader.Value=Table_Trans.Value.createNewTable();
  Table_TransHeader.Value.insertARow(0, Table_TransHeader.Value.getRowHeader(FontType, LineSpacing,
   new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalCenter), true, 1, true, 0, true, 1.0, 1, '~'));
  
  // Trans Detail
  TransToDetailAddLineSpacing=0.3*FontHeight;
  
  TableListXIndent=Table_Trans.Value.Columns[0].Width;
  TableListWidth=ColumnarWidth-TableListXIndent;
  MaxCharTransList=(int)(TableListWidth/FontWidth);
  
   // Table Item In - Out
  Columns=new ODrawTableColumnMetadata[4+1];
  Columns[0]=new ODrawTableColumnMetadata(null, PointOfTransListCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[1]=new ODrawTableColumnMetadata("Barang", 0);
  Columns[2]=new ODrawTableColumnMetadata("Qty", ColSizeQty*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[3]=new ODrawTableColumnMetadata("Hrg Satuan", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[4]=new ODrawTableColumnMetadata("Hrg Total", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)+temp_d>TableListWidth){throw new Exception();}
  Columns[1].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillAll);
  Table_ListItemIn.Value=tbl.createNewTable();
  Table_ListItemOut.Value=tbl.createNewTable();
  
  Columns=new ODrawTableColumnMetadata[1];
  Columns[0]=new ODrawTableColumnMetadata("Kategori", 0);
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  Columns[0].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillEmpty);
  Table_ListItemInCategoryHeader.Value=tbl.createNewTable();
  Table_ListItemOutCategoryHeader.Value=tbl.createNewTable();
  
   // Table Payment Out - In
  Columns=new ODrawTableColumnMetadata[4+1];
  Columns[0]=new ODrawTableColumnMetadata(null, PointOfTransListCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[1]=new ODrawTableColumnMetadata("Tgl Bayar", ColSizeDate*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[2]=new ODrawTableColumnMetadata("Kas Kredit", (ColSizeTextMed+10)*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[3]=new ODrawTableColumnMetadata("Jumlah Bayar", ColSizePrice*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[4]=new ODrawTableColumnMetadata("Keterangan", 0);
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)+temp_d>TableListWidth){throw new Exception();}
  Columns[4].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillAll);
  Table_ListPayOut.Value=tbl.createNewTable();
  Table_ListPayIn.Value=tbl.createNewTable();
  
  // Category Sum
  CategorySumAddLineSpacing=0.75*FontHeight;
  
  Columns=new ODrawTableColumnMetadata[5];
  Columns[0]=new ODrawTableColumnMetadata(null, 0);
  Columns[1]=Table_Trans.Value.Columns[5];
  Columns[2]=Table_Trans.Value.Columns[6];
  Columns[3]=Table_Trans.Value.Columns[7];
  Columns[4]=Table_Trans.Value.Columns[8];
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  Columns[0].Width=Table_Trans.Value.Width-temp_d;
  
  Table_CategorySummary.Value=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillEmpty);
 }
 protected void prepareFirstPageData() throws Exception{
  DbTable=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  DbItemIn=DbTable+"XItemIn";
  DbItemOut=DbTable+"XItemOut";
  DbPayOut=DbTable+"XPayment";
  DbPayIn=DbTable+"XPaymentIn";
  
  Stm2=Stm.getConnection().createStatement();
  
  saveId(); saveCategory();
  
  preInitLayoutVarDefault();
  if(!getNextCategory()){throw new Exception();}
  queryTrans(); if(!getNextTrans()){throw new Exception();}
  CurrOperation=OpTransCategory_Header;
  postInitLayoutVarDefault();
 }
 protected void addHeader() throws Exception{
  DrawComponents.add(new ODrawComponentTable(0, CurrY, Table_TransHeader.Value));
  CurrY=CurrY+Table_TransHeader.Value.Height;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  CurrY=CurrY+HeaderAddLineSpacing;
 }
 protected boolean addColumnar() throws Exception{
  VBoolean KeepPrinting=new VBoolean(true);
  VBoolean CloseTable=new VBoolean();
  VDrawTable CurrTable=null;
  boolean processed;
  double PreAddLineSpacing, PostAddLineSpacing;
  Vector<String> Words=null;
  double Pos_X=0;
  double Pos_Y=0;
  double WordsBox_Width=0;
  double WordsBox_Height=0;
  OAlignment WordsBox_Alignment=null;
  OAlignment WordsBox_AlignmentDefault=new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop);
  
  do{
   
   do{
    // Operation without check
    PreAddLineSpacing=0; PostAddLineSpacing=PostTextAddLineSpacing;
    Pos_X=BaseX;
    WordsBox_Alignment=WordsBox_AlignmentDefault;
    
    processed=true;
    do{
     if(CurrOperation==OpTransCategory_Header){
      PreAddLineSpacing=CategoryAddLineSpacing;
      PostAddLineSpacing=CategoryToTransAddLineSpacing;
      Words=PCore.vect("- "+PText.fitString(Category.elementAt(CurrCategory).Name, (ColumnarColumnCount-4), true, (ColumnarColumnCount-4)/2, 1, '~')+" -");
      WordsBox_Width=Table_Trans.Value.Width;
      WordsBox_Alignment=new OAlignment(OAlignment.HorizontalCenter, WordsBox_AlignmentDefault.AlignmentVertical);
      break;
     }
     if(CurrOperation==OpTrans_Info){
      PreAddLineSpacing=TransToDetailAddLineSpacing;
      Words=InfoTrans;
      WordsBox_Width=Table_ListItemIn.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     if(CurrOperation==OpTrans_ItemIn_Header){
      PreAddLineSpacing=TransToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Barang Masuk { Jumlah : "+PText.intToString(CurrTrans_InfoItemInCount)+
       " ; Harga : "+PText.priceToString(CurrTrans_InfoItemInPrice)+" }", MaxCharTransList, true, MaxCharTransList-1, 1, '~'));
      WordsBox_Width=Table_ListItemIn.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     if(CurrOperation==OpTrans_ItemOut_Header){
      PreAddLineSpacing=TransToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Barang Keluar { Jumlah : "+PText.intToString(CurrTrans_InfoItemOutCount)+
       " ; Harga : "+PText.priceToString(CurrTrans_InfoItemOutPrice)+" }", MaxCharTransList, true, MaxCharTransList-1, 1, '~'));
      WordsBox_Width=Table_ListItemOut.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     if(CurrOperation==OpTrans_PayOut_Header){
      PreAddLineSpacing=TransToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Pembayaran Keluar { Jumlah : "+PText.intToString(CurrTrans_InfoPaymentOutCount)+
       " ; Harga : "+PText.priceToString(CurrTrans_InfoPaymentOutPrice)+" }", MaxCharTransList, true, MaxCharTransList-1, 1, '~'));
      WordsBox_Width=Table_ListPayOut.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     if(CurrOperation==OpTrans_PayIn_Header){
      PreAddLineSpacing=TransToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Pembayaran Masuk { Jumlah : "+PText.intToString(CurrTrans_InfoPaymentInCount)+
       " ; Harga : "+PText.priceToString(CurrTrans_InfoPaymentInPrice)+" }", MaxCharTransList, true, MaxCharTransList-1, 1, '~'));
      WordsBox_Width=Table_ListPayIn.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     
     processed=false;
    }while(false);
    if(processed){
     if(IsANewColumnar){IsANewColumnar=false;}
     else{if(EnablePreAddLineSpacing){CurrY=CurrY+PreAddLineSpacing;}}
     
     Pos_Y=BaseY+CurrY;
     WordsBox_Height=Words.size()*NormalHeight;
     
     DrawComponents.add(new ODrawComponentText(Pos_X, Pos_Y, FontType, Words, WordsBox_Width, WordsBox_Height,
      LineSpacing, WordsBox_Alignment));

     CurrY=CurrY+WordsBox_Height; if(EnablePostAddLineSpacing){CurrY=CurrY+PostAddLineSpacing;}
     
     processNextOperation(KeepPrinting, CloseTable, 0);
     
     break;
    }
    
    // Operation with check
    PreAddLineSpacing=0; PostAddLineSpacing=0;
    Pos_X=BaseX;
    
    processed=true;
    do{
     if(CurrOperation==OpTrans_Main){CurrTable=Table_Trans; break;}
     
     if(CurrOperation==OpTrans_ItemIn_Category_Header){CurrTable=Table_ListItemInCategoryHeader; Pos_X=Pos_X+TableListXIndent; PreAddLineSpacing=ItemCategoryAddLineSpacing; break;}
     if(CurrOperation==OpTrans_ItemIn_List){CurrTable=Table_ListItemIn; Pos_X=Pos_X+TableListXIndent; break;}
     
     if(CurrOperation==OpTrans_ItemOut_Category_Header){CurrTable=Table_ListItemOutCategoryHeader; Pos_X=Pos_X+TableListXIndent; PreAddLineSpacing=ItemCategoryAddLineSpacing; break;}
     if(CurrOperation==OpTrans_ItemOut_List){CurrTable=Table_ListItemOut; Pos_X=Pos_X+TableListXIndent; break;}
     
     if(CurrOperation==OpTrans_PayOut_List){CurrTable=Table_ListPayOut; Pos_X=Pos_X+TableListXIndent; break;}
     
     if(CurrOperation==OpTrans_PayIn_List){CurrTable=Table_ListPayIn; Pos_X=Pos_X+TableListXIndent; break;}
     
     if(CurrOperation==OpTransCategory_Summary){CurrTable=Table_CategorySummary; PreAddLineSpacing=CategorySumAddLineSpacing; break;}
     
     processed=false;
    }while(false);
    if(processed){
     if(IsANewColumnar){IsANewColumnar=false;}
     else{if(EnablePreAddLineSpacing){CurrY=CurrY+PreAddLineSpacing;}}
     
     Pos_Y=BaseY+CurrY;
     
     CurrTable.Value.insertARow(CurrTable.Value.Rows.size(), TableNewRow);
     
     processNextOperation(KeepPrinting, CloseTable, CurrTable.Value.Height);
     
     if(CloseTable.Value){
      DrawComponents.addElement(new ODrawComponentTable(Pos_X, Pos_Y, CurrTable.Value));
      CurrY=CurrY+CurrTable.Value.Height; if(EnablePostAddLineSpacing){CurrY=CurrY+PostAddLineSpacing;}
      CurrTable.Value=CurrTable.Value.createNewTable();
     }
     
     break;
    }
   }while(false);
   
   if(!KeepPrinting.Value){break;}
   
  }while(KeepPrinting.Value);
		return false;
 }
 void preInitLayoutVarDefault(){
  EnablePreAddLineSpacing=true;
  EnablePostAddLineSpacing=true;
 }
 void postInitLayoutVarDefault(){
  if(TableNewRow==null){TableNewRow=TableNewRow2;}
 }
 void processNextOperation(VBoolean KeepPrinting, VBoolean CloseTable, double CurrDrawComponentHeight) throws Exception{
  double NextDrawComponentHeight;
  int BefOp;
  
  NextDrawComponentHeight=0;
  BefOp=CurrOperation;
  CloseTable.Value=false;
  TableNewRow=null;
  
  preInitLayoutVarDefault();
  
  do{
   // from 'category_header' next to 'trans_main'
   if(CurrOperation==OpTransCategory_Header){CurrOperation=OpTrans_Main; break;}
   
   // from 'trans_main' next to 'trans_info'
   if(CurrOperation==OpTrans_Main){
    if(InfoTrans!=null){
     CurrOperation=OpTrans_Info;
     NextDrawComponentHeight=TransToDetailAddLineSpacing+(InfoTrans.size()*NormalHeight)+PostTextAddLineSpacing;
     break;
    }
   }
   
   if(OptList_ItemIn && ShowListItemIn){
    // from ... next to 'trans_list_item_in_header'
    if(CurrOperation==OpTrans_Main || CurrOperation==OpTrans_Info){
     preparePrintItemIn();
     if(OptList_ItemCategorized){
      prepareItemInCategorized();
      if(getItemInNextCategory()){
       CurrOperation=OpTrans_ItemIn_Header; EnablePostAddLineSpacing=false;
       NextDrawComponentHeight=TransToDetailAddLineSpacing+NormalHeight+ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
     else{
      queryItemIn();
      if(getNextItemIn()){
       CurrOperation=OpTrans_ItemIn_Header;
       NextDrawComponentHeight=TransToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
       break;
      }
     }
    }
    
    if(OptList_ItemCategorized){
     // from 'trans_list_item_in_header' next to 'trans_list_item_in_category_header'
     if(CurrOperation==OpTrans_ItemIn_Header){CurrOperation=OpTrans_ItemIn_Category_Header; TableNewRow=TableNewRow3; break;}
    }
    
    // from ... next to 'trans_list_item_in_data'
    if(CurrOperation==OpTrans_ItemIn_Header || CurrOperation==OpTrans_ItemIn_Category_Header){
     CurrOperation=OpTrans_ItemIn_List; break;
    }

    // from 'trans_list_item_in_data' next to 'trans_list_item_in_data'
    if(CurrOperation==OpTrans_ItemIn_List){
     if(getNextItemIn()){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
    
    if(OptList_ItemCategorized){
     // from 'trans_list_item_in_category_summary' next to 'trans_list_item_in_category_header'
     if(CurrOperation==OpTrans_ItemIn_List){
      if(getItemInNextCategory()){
       CurrOperation=OpTrans_ItemIn_Category_Header; TableNewRow=TableNewRow3;
       NextDrawComponentHeight=ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
    }
   }
   
   if(OptList_ItemOut && ShowListItemOut){
    // from ... next to 'trans_list_item_out_header'
    if(CurrOperation==OpTrans_Main || CurrOperation==OpTrans_Info ||
     CurrOperation==OpTrans_ItemIn_List){
     preparePrintItemOut();
     if(OptList_ItemCategorized){
      prepareItemOutCategorized();
      if(getItemOutNextCategory()){
       CurrOperation=OpTrans_ItemOut_Header; EnablePostAddLineSpacing=false;
       NextDrawComponentHeight=TransToDetailAddLineSpacing+NormalHeight+ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
     else{
      queryItemOut();
      if(getNextItemOut()){
       CurrOperation=OpTrans_ItemOut_Header;
       NextDrawComponentHeight=TransToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
       break;
      }
     }
    }
    
    if(OptList_ItemCategorized){
     // from 'trans_list_item_out_header' next to 'trans_list_item_out_category_header'
     if(CurrOperation==OpTrans_ItemOut_Header){CurrOperation=OpTrans_ItemOut_Category_Header; TableNewRow=TableNewRow3; break;}
    }
    
    // from ... next to 'trans_list_item_out_data'
    if(CurrOperation==OpTrans_ItemOut_Header || CurrOperation==OpTrans_ItemOut_Category_Header){CurrOperation=OpTrans_ItemOut_List; break;}

    // from 'trans_list_item_out_data' next to 'trans_list_item_out_data'
    if(CurrOperation==OpTrans_ItemOut_List){
     if(getNextItemOut()){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
    
    if(OptList_ItemCategorized){
     // from 'trans_list_item_out_category_summary' next to 'trans_list_item_out_category_header'
     if(CurrOperation==OpTrans_ItemOut_List){
      if(getItemOutNextCategory()){
       CurrOperation=OpTrans_ItemOut_Category_Header; TableNewRow=TableNewRow3;
       NextDrawComponentHeight=ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
    }
   }
   
   if(OptList_PaymentOut){
    // from ... next to 'trans_list_pay_out_header'
    if(CurrOperation==OpTrans_Main || CurrOperation==OpTrans_Info ||
     CurrOperation==OpTrans_ItemIn_List || CurrOperation==OpTrans_ItemOut_List){
     queryPayOut();
     if(getNextPayOut()){
      CurrOperation=OpTrans_PayOut_Header;
      NextDrawComponentHeight=TransToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
      break;
     }
    }

    // from 'trans_list_pay_out_header' next to 'trans_list_pay_out_data'
    if(CurrOperation==OpTrans_PayOut_Header){CurrOperation=OpTrans_PayOut_List; break;}

    // from 'trans_list_pay_out_data' next to 'trans_list_pay_out_data'
    if(CurrOperation==OpTrans_PayOut_List){
     if(getNextPayOut()){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
   }
   
   if(OptList_PaymentIn){
    // from ... next to 'trans_list_pay_in_header'
    if(CurrOperation==OpTrans_Main || CurrOperation==OpTrans_Info ||
     CurrOperation==OpTrans_ItemIn_List || CurrOperation==OpTrans_ItemOut_List ||
     CurrOperation==OpTrans_PayOut_List){
     queryPayIn();
     if(getNextPayIn()){
      CurrOperation=OpTrans_PayIn_Header;
      NextDrawComponentHeight=TransToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
      break;
     }
    }

    // from 'trans_list_pay_in_header' next to 'trans_list_pay_in_data'
    if(CurrOperation==OpTrans_PayIn_Header){CurrOperation=OpTrans_PayIn_List; break;}

    // from 'trans_list_pay_in_data' next to 'trans_list_pay_in_data'
    if(CurrOperation==OpTrans_PayIn_List){
     if(getNextPayIn()){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
   }
   
   // from ... next to 'trans_main'
   if(CurrOperation==OpTrans_Main || CurrOperation==OpTrans_Info ||
    CurrOperation==OpTrans_ItemIn_List || CurrOperation==OpTrans_ItemOut_List ||
    CurrOperation==OpTrans_PayOut_List || CurrOperation==OpTrans_PayIn_List){
    if(getNextTrans()){
     CurrOperation=OpTrans_Main;
     NextDrawComponentHeight=TableNewRow2.Height;
     if(InfoTrans!=null){
      NextDrawComponentHeight=NextDrawComponentHeight+TransToDetailAddLineSpacing+(InfoTrans.size()*NormalHeight)+PostTextAddLineSpacing;
     }
     break;
    }
   }
   
   // from ... next to 'category_summary'
   if(CurrOperation==OpTrans_Main || CurrOperation==OpTrans_Info ||
    CurrOperation==OpTrans_ItemIn_List || CurrOperation==OpTrans_ItemOut_List ||
    CurrOperation==OpTrans_PayOut_List || CurrOperation==OpTrans_PayIn_List){
    getCategorySummary();
    CurrOperation=OpTransCategory_Summary;
    NextDrawComponentHeight=CategorySumAddLineSpacing+TableNewRow2.Height;
    break;
   }
   
   // from 'category_summary' next to 'category_header'
   if(CurrOperation==OpTransCategory_Summary){
    if(!getNextCategory()){KeepPrinting.Value=false; break;}
    queryTrans(); if(!getNextTrans()){throw new Exception();}
    CurrOperation=OpTransCategory_Header;

    NextDrawComponentHeight=CategoryAddLineSpacing+NormalHeight+CategoryToTransAddLineSpacing+TableNewRow2.Height;
    if(InfoTrans!=null){
     NextDrawComponentHeight=NextDrawComponentHeight+TransToDetailAddLineSpacing+(InfoTrans.size()*NormalHeight)+PostTextAddLineSpacing;
    }
    break;
   }
  }while(false);
  
  postInitLayoutVarDefault();
  
  if(checkOverColumnarHeight(CurrDrawComponentHeight+NextDrawComponentHeight)){KeepPrinting.Value=false;}
  if(CurrOperation!=BefOp || KeepPrinting.Value==false){CloseTable.Value=true;}
 }
 protected void addFooter() throws Exception{
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  PText.fillStringToChars(TxtPage, "Hal. "+CurrPage, PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  if(CurrCategory==Category.size()){return false;}
  return true;
 }
 protected void clearVar(){
  Category=null;
  Id=null;
  IdQ=null;
  InfoTrans=null;
  ItemInCategories=null;
  ItemInIdsStr=null;
  ItemInList=null;
  ItemOutCategories=null;
  ItemOutIdsStr=null;
  ItemOutList=null;
  PrintedItems=null;
  TableNewRow=null;
  TableNewRow2=null;
  TableNewRow3=null;
  try{Rs2.close();}catch(Exception E){} Rs2=null;
  try{Stm2.close();}catch(Exception E){} Stm2=null;
 }
 
 // additional private methods
 
 // Trans Category
 void saveCategory() throws Exception{
  OIdName ACategory;
  boolean ThereIsNull;
  
  Category=new Vector();
  CurrCategory=-1;
  
  Rs=Stm.executeQuery("select TransType, Name from (select TransType from "+DbTable+" where Id in ("+IdQ+") group by TransType) as tb1 "+
   "left join TransType on tb1.TransType=TransType.Id order by Name asc;");
  
  if(!Rs.next()){return;}
  
  ThereIsNull=false;
  do{
   ACategory=new OIdName();
   ACategory.Id=Rs.getInt(1);
   ACategory.Name=Rs.getString(2);
   if(Rs.wasNull()){ThereIsNull=true;}
   else{Category.addElement(ACategory);}
  }while(Rs.next());
  if(ThereIsNull){
   ACategory=new OIdName(); ACategory.Id=-1; ACategory.Name="Tidak didefenisikan";
   Category.insertElementAt(ACategory, 0);
  }
 }
 boolean getNextCategory(){
  if(CurrCategory<Category.size()){CurrCategory=CurrCategory+1;}
  return CurrCategory!=Category.size();
 }
 private void fillCategorySummaryWithCurrentTrans(){
  if(CurrTrans_InfoItemInPrice>=0){TotalItemInPrice=TotalItemInPrice+CurrTrans_InfoItemInPrice;}
  if(CurrTrans_InfoItemOutPrice>=0){TotalItemOutPrice=TotalItemOutPrice+CurrTrans_InfoItemOutPrice;}
  if(CurrTrans_InfoPaymentOutPrice>=0){TotalPaymentOutPrice=TotalPaymentOutPrice+CurrTrans_InfoPaymentOutPrice;}
  if(CurrTrans_InfoPaymentInPrice>=0){TotalPaymentInPrice=TotalPaymentInPrice+CurrTrans_InfoPaymentInPrice;}
  TotalTransCount=TotalTransCount+1;
 }
 private void clearCategorySummary(){
  TotalItemInPrice=0;
  TotalItemOutPrice=0;
  TotalPaymentOutPrice=0;
  TotalPaymentInPrice=0;
  TotalTransCount=0;
 }
 private void getCategorySummary(){
  int insertpos;
  ODimension dim;
  
  TableNewRow2=new ODrawTableRow(0, Table_CategorySummary.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText("("+PText.intToString(TotalTransCount)+") Akumulasi Harga :",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(1, new ODrawTableCellText(PText.priceToString(TotalItemInPrice),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.priceToString(TotalPaymentOutPrice),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.priceToString(TotalItemOutPrice),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(4, new ODrawTableCellText(PText.priceToString(TotalPaymentInPrice),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  
  insertpos=Table_CategorySummary.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_CategorySummary.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_CategorySummary.Value.Inset.InsetTop+Table_CategorySummary.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_CategorySummary.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_CategorySummary.Value.Inset.InsetTop+Table_CategorySummary.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_CategorySummary.Value, insertpos);
  }
 }
 
 
 // Trans
 void saveId(){
  StringBuilder strb=new StringBuilder();
  strb=strb.append(Id.pop().toString());
  if(!Id.isEmpty()){
   do{
    strb=strb.append(","+Id.pop().toString());
   }while(!Id.isEmpty());
  }
  IdQ=strb.toString();
 }
 private void queryTrans() throws Exception{
  if(Category.elementAt(CurrCategory).Id!=-1){str="="+String.valueOf(Category.elementAt(CurrCategory).Id);}
  else{str=" is "+CCore.vNull;}
  
  Rs=Stm.executeQuery(
   "select tb7.*, Count("+DbTable+"XPaymentIn.Price) as 'CountPaymentIn', Sum("+DbTable+"XPaymentIn.Price) as 'PricePaymentIn' from "+
    "(select tb6.*, Count("+DbTable+"XPayment.Price) as 'CountPaymentOut', Sum("+DbTable+"XPayment.Price) as 'PricePaymentOut' from "+
     "(select tb5.Id, tb5.InfoIdExternal, tb5.IsImportant, tb5.TransTypeName, tb5.Comment, "+
       "tb5.TransDate, tb5.CreditDays, tb5.BillDate, tb5.RepaymentPeriodStart, tb5.RepaymentPeriodEnd, "+
       "tb5.SubjectName, tb5.SalesmanName, tb5.CashOutName, tb5.CashOutComment, tb5.CashInName, tb5.CashInComment, CountItemIn, PriceItemIn, "+
       "Count(tb5.ItemOut_Price) as 'CountItemOut', Sum(tb5.ItemOut_Price) as 'PriceItemOut', "+
       "Sum(tb5.ItemOut_Stock*BuyPriceEstimation) as 'BasicPriceItemOut' from "+
      "(select tb4.*, "+DbTable+"XItemOut.Item as 'ItemOut_Item', "+DbTable+"XItemOut.Stock as 'ItemOut_Stock', "+DbTable+"XItemOut.Price as 'ItemOut_Price' from "+
        "(select tb3.*, Count("+DbTable+"XItemIn.Price) as 'CountItemIn', Sum("+DbTable+"XItemIn.Price) as 'PriceItemIn' from "+
         "(select tb2.*, Subject.Name as 'SalesmanName', Cash.Name as 'CashInName' from "+
          "(select tb1.*, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName', Cash.Name as 'CashOutName' from "+
            "(select "+DbTable+".*, "+
             "if(CreditDays is "+CCore.vNull+", "+CCore.vNull+", Date_Add(TransDate, Interval ifnull(CreditDays, 0) Day)) as 'BillDate' "+
            "from "+DbTable+" where Id in ("+IdQ+") and TransType"+str+") as tb1 "+
          "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id left join Cash on tb1.Cash=Cash.Id) as tb2 "+
         "left join Subject on tb2.Salesman=Subject.Id left join Cash on tb2.CashIn=Cash.Id) as tb3 "+
        "left join "+DbTable+"XItemIn on tb3.Id="+DbTable+"XItemIn."+DbTable+" group by tb3.Id) as tb4 "+
      "left join "+DbTable+"XItemOut on tb4.Id="+DbTable+"XItemOut."+DbTable+") as tb5 "+
     "left join Item on tb5.ItemOut_Item=Item.Id group by tb5.Id) as tb6 "+
    "left join "+DbTable+"XPayment on tb6.Id="+DbTable+"XPayment."+DbTable+" group by tb6.Id) as tb7 "+
   "left join "+DbTable+"XPaymentIn on tb7.Id="+DbTable+"XPaymentIn."+DbTable+" group by tb7.Id "+
   "order by TransDate desc, SubjectName asc, BillDate asc, Id desc;");
  
  clearCategorySummary();
 }
 private boolean getNextTrans() throws Exception{
  int insertpos;
  ODimension dim;
  
  if(!Rs.next()){return false;}
  
  CurrTrans_Id=Rs.getLong(1);
  CurrTrans_Info.InfoIdExternal=Rs.getString(2); if(Rs.wasNull()){CurrTrans_Info.InfoIdExternal=null;}
  CurrTrans_Info.Important=Rs.getBoolean(3);
  CurrTrans_Info.TypeName=Rs.getString(4); if(Rs.wasNull()){CurrTrans_Info.TypeName=null;}
  CurrTrans_Info.Comment=Rs.getString(5); if(Rs.wasNull()){CurrTrans_Info.Comment=null;}
  CurrTrans_Info.Dt=Rs.getDate(6);
  CurrTrans_Info.CreditDays=Rs.getInt(7); if(Rs.wasNull()){CurrTrans_Info.CreditDays=-1;}
  CurrTrans_InfoDateBill=Rs.getDate(8); if(Rs.wasNull()){CurrTrans_InfoDateBill=null;}
  CurrTrans_Info.RepaymentPeriodStart=Rs.getDate(9); if(Rs.wasNull()){CurrTrans_Info.RepaymentPeriodStart=null;}
  CurrTrans_Info.RepaymentPeriodEnd=Rs.getDate(10); if(Rs.wasNull()){CurrTrans_Info.RepaymentPeriodEnd=null;}
  CurrTrans_Info.SubjectName=Rs.getString(11); if(Rs.wasNull()){CurrTrans_Info.SubjectName=null;}
  CurrTrans_Info.SalesmanName=Rs.getString(12); if(Rs.wasNull()){CurrTrans_Info.SalesmanName=null;}
  CurrTrans_Info.CashOutName=Rs.getString(13); if(Rs.wasNull()){CurrTrans_Info.CashOutName=null;}
  CurrTrans_Info.CashOutComment=Rs.getString(14); if(Rs.wasNull()){CurrTrans_Info.CashOutComment=null;}
  CurrTrans_Info.CashInName=Rs.getString(15); if(Rs.wasNull()){CurrTrans_Info.CashInName=null;}
  CurrTrans_Info.CashInComment=Rs.getString(16); if(Rs.wasNull()){CurrTrans_Info.CashInComment=null;}
  CurrTrans_InfoItemInCount=Rs.getInt(17); if(Rs.wasNull()){CurrTrans_InfoItemInCount=-1;}
  CurrTrans_InfoItemInPrice=Rs.getDouble(18); if(Rs.wasNull()){CurrTrans_InfoItemInPrice=-1;}
  CurrTrans_InfoItemOutCount=Rs.getInt(19); if(Rs.wasNull()){CurrTrans_InfoItemOutCount=-1;}
  CurrTrans_InfoItemOutPrice=Rs.getDouble(20); if(Rs.wasNull()){CurrTrans_InfoItemOutPrice=-1;}
  CurrTrans_InfoPaymentOutCount=Rs.getInt(22); if(Rs.wasNull()){CurrTrans_InfoPaymentOutCount=-1;}
  CurrTrans_InfoPaymentOutPrice=Rs.getDouble(23); if(Rs.wasNull()){CurrTrans_InfoPaymentOutPrice=-1;}
  CurrTrans_InfoPaymentInCount=Rs.getInt(24); if(Rs.wasNull()){CurrTrans_InfoPaymentInCount=-1;}
  CurrTrans_InfoPaymentInPrice=Rs.getDouble(25); if(Rs.wasNull()){CurrTrans_InfoPaymentInPrice=-1;}
  
  TableNewRow2=new ODrawTableRow(0, Table_Trans.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PointOfTrans,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(1, new ODrawTableCellText(PText.dateToString(CurrTrans_Info.Dt, 1),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.getString(CurrTrans_InfoDateBill==null, "-", PText.dateToString(CurrTrans_InfoDateBill, 1)),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.getString(CurrTrans_Info.SubjectName, "-", true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(4, new ODrawTableCellText(PText.getString(!OptMain_IdExternal || PText.isEmptyString(CurrTrans_Info.InfoIdExternal, true, true), String.valueOf(CurrTrans_Id), "{"+CurrTrans_Info.InfoIdExternal+"}"),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(5, new ODrawTableCellText(PText.getStringDouble(CurrTrans_InfoItemInPrice, "-", -0.1, true, true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(6, new ODrawTableCellText(PText.getStringDouble(CurrTrans_InfoPaymentOutPrice, "-", -0.1, true, true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(7, new ODrawTableCellText(PText.getStringDouble(CurrTrans_InfoItemOutPrice, "-", -0.1, true, true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(8, new ODrawTableCellText(PText.getStringDouble(CurrTrans_InfoPaymentInPrice, "-", -0.1, true, true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), true, 1, true, 0, true, 1.0, 1, '~'));
  
  insertpos=Table_Trans.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_Trans.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_Trans.Value.Inset.InsetTop+Table_Trans.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_Trans.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_Trans.Value.Inset.InsetTop+Table_Trans.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_Trans.Value, insertpos);
  }
  
  getInfoTrans();
  
  fillCategorySummaryWithCurrentTrans();
  
  return true;
 }
 private void getInfoTrans(){
  StringBuilder strb;
  boolean first;
  
  strb=new StringBuilder();
  first=true;
  
  if(OptInfo_IdInternal){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(String.valueOf(CurrTrans_Id));
  }
  if(OptInfo_IdExternal){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(PText.isEmptyString(CurrTrans_Info.InfoIdExternal, true, true), "-", "{"+CurrTrans_Info.InfoIdExternal+"}"));
  }
  if(OptInfo_Important){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.Important, "Pnt", "-"));
  }
  if(OptInfo_TransType){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.TypeName, "-", true));
  }
  if(OptInfo_Date){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.Dt==null, "-", PText.dateToString(CurrTrans_Info.Dt, 2)));
  }
  if(OptInfo_CreditDays){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.CreditDays, -1, PText.intToString(CurrTrans_Info.CreditDays)+" hari", "-"));
  }
  if(OptInfo_DateBill){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_InfoDateBill==null, "-", PText.dateToString(CurrTrans_InfoDateBill, 2)));
  }
  if(OptInfo_DateRepayment){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.RepaymentPeriodStart==null, "-",
    PText.dateToString(CurrTrans_Info.RepaymentPeriodStart, 2)+" ... "+PText.dateToString(CurrTrans_Info.RepaymentPeriodEnd, 2)));
  }
  if(OptInfo_CashOut){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.CashOutName, "-", true));
  }
  if(OptInfo_CashOutComment){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(PText.isEmptyString(CurrTrans_Info.CashOutComment, true, true), "-", "{"+CurrTrans_Info.CashOutComment+"}"));
  }
  if(OptInfo_CashIn){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.CashInName, "-", true));
  }
  if(OptInfo_CashInComment){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(PText.isEmptyString(CurrTrans_Info.CashInComment, true, true), "-", "{"+CurrTrans_Info.CashInComment+"}"));
  }
  if(OptInfo_Subject){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.SubjectName, "-", true));
  }
  if(OptInfo_Salesman){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.SalesmanName, "-", true));
  }
  if(OptInfo_Comment){
   if(first){first=false;}else{strb.append(", ");}
   strb.append(PText.getString(CurrTrans_Info.Comment, "-", PText.singleLine(CurrTrans_Info.Comment, '~'), true));
  }
  InfoTrans=null; if(!first){InfoTrans=PText.multiLine("{"+strb.toString()+"}", MaxCharTransList);}
 }
 
 // Item In
 private void preparePrintItemIn(){
  PrintedItems=new OQuickListOfLong(1024, 1024, true, false);
 }
 private void getItemInIds() throws Exception{
  StringBuilder strb;
  long ItemId;
  
  ItemInIdsCount=0;
  ItemInIdsStr=null;
  
  Rs2=Stm2.executeQuery("select Item from "+DbItemIn+" where "+DbTable+"="+CurrTrans_Id);
  
  if(!Rs2.next()){return;}
  
  strb=new StringBuilder();
  do{
   if(ItemInIdsCount!=0){strb.append(",");}

   ItemId=Rs2.getLong(1);
   strb.append(ItemId);

   ItemInIdsCount=ItemInIdsCount+1;
  }while(Rs2.next());
  ItemInIdsStr=strb.toString();
 }
 private void getItemInCategories() throws Exception{
  OIdName CategoryOfItem;
  boolean ThereIsNull;
  
  ItemInCategories=new Vector();
  ItemInCurrCategory=-1;
  
  if(ItemInIdsCount==0){return;}
  
  Rs2=Stm2.executeQuery(
   "select CategoryOfItem, Name from "+
    "(select CategoryOfItem from "+
     "(select Id as 'ItemId' from Item where Id in("+ItemInIdsStr+")) as tb1 "+
    "left join ItemXCategory on tb1.ItemId=ItemXCategory.Item group by CategoryOfItem) as tb2 "+
   "left join CategoryOfItem on tb2.CategoryOfItem=CategoryOfItem.Id order by Name asc");
  
  if(!Rs2.next()){throw new Exception();}
  
  ThereIsNull=false;
  do{
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=Rs2.getLong(1);
   CategoryOfItem.Name=Rs2.getString(2);
   if(Rs2.wasNull()){ThereIsNull=true;}
   else{ItemInCategories.addElement(CategoryOfItem);}
  }while(Rs2.next());
  if(ThereIsNull){
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=-1;
   CategoryOfItem.Name="Tidak didefenisikan";
   ItemInCategories.addElement(CategoryOfItem);
  }
 }
 private void prepareItemInCategorized() throws Exception{
  getItemInIds();
  getItemInCategories();
 }
 private void fillItemInCategorySummary(int Count, double Price){
  ItemInListItemCount=Count; ItemInListItemPrice=Price;
 }
 private void clearItemInCategorySummary(){
  ItemInListItemCount=0; ItemInListItemPrice=0;
 }
 private boolean getItemInNextCategory() throws Exception{
  boolean ThereIs;
  
  ThereIs=false;
  do{
   
   if(ItemInCurrCategory<ItemInCategories.size()){
    ItemInCurrCategory=ItemInCurrCategory+1;
    clearItemInCategorySummary();
   }
   
   if(ItemInCurrCategory==ItemInCategories.size()){break;}
   
   queryItemIn();
   if(getNextItemIn()){ThereIs=true; break;}
   
  }while(!ThereIs);
  if(!ThereIs){return false;}
  
  getItemInCategoryHeader();
  return true;
 }
 private void getItemInCategoryHeader(){
  int insertpos;
  ODimension dim;
  
  TableNewRow3=new ODrawTableRow(0, Table_ListItemInCategoryHeader.Value.ColumnsCount);
  TableNewRow3.setCell(0, new ODrawTableCellText(ItemInCategories.elementAt(ItemInCurrCategory).Name+
   " ( "+PText.intToString(ItemInListItemCount)+" ; "+PText.priceToString(ItemInListItemPrice)+" )",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItemInCategoryHeader.Value.Rows.size();
  if(!TableNewRow3.preGenerateCellsDrawContents(Table_ListItemInCategoryHeader.Value, insertpos)){
   TableNewRow3.clearAllCells();
   TableNewRow3.setHeight(CellAreaMinHeight+(Table_ListItemInCategoryHeader.Value.Inset.InsetTop+Table_ListItemInCategoryHeader.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow3.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItemInCategoryHeader.Value, insertpos);
   TableNewRow3.setHeight(dim.getHeight()+(Table_ListItemInCategoryHeader.Value.Inset.InsetTop+Table_ListItemInCategoryHeader.Value.Inset.InsetBottom));
   TableNewRow3.generateCellsDrawContents(Table_ListItemInCategoryHeader.Value, insertpos);
  }
 }
 private void queryItemIn() throws Exception{
  String Query;
  String con=null;
  boolean[] ItemInSumColumn;
  double[] ItemInSumResult;
  
  ItemInList=new Vector();
  ItemInListCurrItem=-1;
  
  ItemInSumColumn=PCore.newBooleanArray(8, false); ItemInSumColumn[4]=true;
  ItemInSumResult=new double[ItemInSumColumn.length];
  
  // Item-Id, Item-Name, Qty, Stock-Unit, Price-Total, Price-Unit, Checked
  Query=
   "select TransItem, ItemName, TransItemQty, StockUnit.Name as 'ItemStockUnitName', TransItemPriceTotal, TransItemPriceUnit, TransItemComment, TransItemChecked from "+
    "(select tb1.*, Item.Name as 'ItemName', StockUnit from "+
     "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
     "from "+DbTable+"XItemIn where "+DbTable+"="+CurrTrans_Id+") as tb1 "+
    "left join Item on tb1.TransItem=Item.Id) as tb2 "+
   "left join StockUnit on tb2.StockUnit=StockUnit.Id "+
   "order by ItemName asc";
  
  if(OptList_ItemCategorized){
   if(ItemInCategories.elementAt(ItemInCurrCategory).Id==-1){con=" is "+CCore.vNull;}
   else{con="="+ItemInCategories.elementAt(ItemInCurrCategory).Id;}
   Query=
    "select c1.*, CategoryOfItem from "+
     "("+Query+") as c1 "+
    "left join ItemXCategory on c1.TransItem=ItemXCategory.Item where CategoryOfItem"+con+" "+
    "order by ItemName asc";
  }
  
  if(PDatabase.queryToRows(Stm2, Query, ItemInList,
   PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeBoolean),
   null, true, ItemInSumColumn, ItemInSumResult, false, false, null, -1, false, -1, true, true, false, PrintedItems, 0)==-1){throw new Exception();}
  
  fillItemInCategorySummary(ItemInList.size(), ItemInSumResult[4]);
 }
 private boolean getNextItemIn() throws Exception{
  int insertpos;
  ODimension dim;
  Object[] objs;
  long ItemId; String ItemName; double ItemQty; double ItemPriceTotal; double ItemPriceUnit; String ItemComment; boolean ItemChecked; String ItemDescription;
  
  if(ItemInListCurrItem<ItemInList.size()){ItemInListCurrItem=ItemInListCurrItem+1;;}
  
  if(ItemInListCurrItem==ItemInList.size()){return false;}
  
  objs=ItemInList.elementAt(ItemInListCurrItem);
  ItemId=PCore.objLong(objs[0], -1L);
  ItemName=PCore.objString(objs[1], null);
  ItemQty=PCore.objDouble(objs[2], 0D);
  ItemPriceTotal=PCore.objDouble(objs[4], 0D);
  ItemPriceUnit=PCore.objDouble(objs[5], 0D);
  ItemComment=PCore.objString(objs[6], null);
  ItemChecked=PCore.objBoolean(objs[7], false);
  ItemDescription=
   ItemName+" ("+ItemId+")"+
   PText.getString(ItemComment, "", " {"+ItemComment+"}", true);
  
  TableNewRow2=new ODrawTableRow(0, Table_ListItemIn.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PText.getString(ItemChecked, PointOfTransListItemChecked, PointOfTransListItemUnchecked),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(1, new ODrawTableCellText(ItemDescription,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.priceToString(ItemQty),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.priceToString(ItemPriceUnit),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(4, new ODrawTableCellText(PText.priceToString(ItemPriceTotal),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItemIn.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_ListItemIn.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_ListItemIn.Value.Inset.InsetTop+Table_ListItemIn.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItemIn.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_ListItemIn.Value.Inset.InsetTop+Table_ListItemIn.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_ListItemIn.Value, insertpos);
  }
  
  return true;
 }
 
 // Item Out
 private void preparePrintItemOut(){
  PrintedItems=new OQuickListOfLong(1024, 1024, true, false);
 }
 private void getItemOutIds() throws Exception{
  StringBuilder strb;
  long ItemId;
  
  ItemOutIdsCount=0;
  ItemOutIdsStr=null;
  
  Rs2=Stm2.executeQuery("select Item from "+DbItemOut+" where "+DbTable+"="+CurrTrans_Id);
  
  if(!Rs2.next()){return;}
  
  strb=new StringBuilder();
  do{
   if(ItemOutIdsCount!=0){strb.append(",");}

   ItemId=Rs2.getLong(1);
   strb.append(ItemId);

   ItemOutIdsCount=ItemOutIdsCount+1;
  }while(Rs2.next());
  ItemOutIdsStr=strb.toString();
 }
 private void getItemOutCategories() throws Exception{
  OIdName CategoryOfItem;
  boolean ThereIsNull;
  
  ItemOutCategories=new Vector();
  ItemOutCurrCategory=-1;
  
  if(ItemOutIdsCount==0){return;}
  
  Rs2=Stm2.executeQuery(
   "select CategoryOfItem, Name from "+
    "(select CategoryOfItem from "+
     "(select Id as 'ItemId' from Item where Id in("+ItemOutIdsStr+")) as tb1 "+
    "left join ItemXCategory on tb1.ItemId=ItemXCategory.Item group by CategoryOfItem) as tb2 "+
   "left join CategoryOfItem on tb2.CategoryOfItem=CategoryOfItem.Id order by Name asc");
  
  if(!Rs2.next()){throw new Exception();}
  
  ThereIsNull=false;
  do{
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=Rs2.getLong(1);
   CategoryOfItem.Name=Rs2.getString(2);
   if(Rs2.wasNull()){ThereIsNull=true;}
   else{ItemOutCategories.addElement(CategoryOfItem);}
  }while(Rs2.next());
  if(ThereIsNull){
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=-1;
   CategoryOfItem.Name="Tidak didefenisikan";
   ItemOutCategories.addElement(CategoryOfItem);
  }
 }
 private void prepareItemOutCategorized() throws Exception{
  getItemOutIds();
  getItemOutCategories();
 }
 private void fillItemOutCategorySummary(int Count, double Price){
  ItemOutListItemCount=Count; ItemOutListItemPrice=Price;
 }
 private void clearItemOutCategorySummary(){
  ItemOutListItemCount=0; ItemOutListItemPrice=0;
 }
 private boolean getItemOutNextCategory() throws Exception{
  boolean ThereIs;
  
  ThereIs=false;
  do{
   
   if(ItemOutCurrCategory<ItemOutCategories.size()){
    ItemOutCurrCategory=ItemOutCurrCategory+1;
    clearItemOutCategorySummary();
   }
   
   if(ItemOutCurrCategory==ItemOutCategories.size()){break;}
   
   queryItemOut();
   if(getNextItemOut()){ThereIs=true; break;}
   
  }while(!ThereIs);
  if(!ThereIs){return false;}
  
  getItemOutCategoryHeader();
  return true;
 }
 private void getItemOutCategoryHeader(){
  int insertpos;
  ODimension dim;
  
  TableNewRow3=new ODrawTableRow(0, Table_ListItemOutCategoryHeader.Value.ColumnsCount);
  TableNewRow3.setCell(0, new ODrawTableCellText(ItemOutCategories.elementAt(ItemOutCurrCategory).Name+
   " ( "+PText.intToString(ItemOutListItemCount)+" ; "+PText.priceToString(ItemOutListItemPrice)+" )",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItemOutCategoryHeader.Value.Rows.size();
  if(!TableNewRow3.preGenerateCellsDrawContents(Table_ListItemOutCategoryHeader.Value, insertpos)){
   TableNewRow3.clearAllCells();
   TableNewRow3.setHeight(CellAreaMinHeight+(Table_ListItemOutCategoryHeader.Value.Inset.InsetTop+Table_ListItemOutCategoryHeader.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow3.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItemOutCategoryHeader.Value, insertpos);
   TableNewRow3.setHeight(dim.getHeight()+(Table_ListItemOutCategoryHeader.Value.Inset.InsetTop+Table_ListItemOutCategoryHeader.Value.Inset.InsetBottom));
   TableNewRow3.generateCellsDrawContents(Table_ListItemOutCategoryHeader.Value, insertpos);
  }
 }
 private void queryItemOut() throws Exception{
  String Query;
  String con=null;
  boolean[] ItemOutSumColumn;
  double[] ItemOutSumResult;
  
  ItemOutList=new Vector();
  ItemOutListCurrItem=-1;
  
  ItemOutSumColumn=PCore.newBooleanArray(10, false); ItemOutSumColumn[4]=true;
  ItemOutSumResult=new double[ItemOutSumColumn.length];
  
  // Item-Id, Item-Name, Qty, Stock-Unit, Price-Total, Price-Unit, BasicPrice-Unit, BasicPrice-Total, Checked
  Query=
   "select TransItem, ItemName, TransItemQty, StockUnit.Name as 'ItemStockUnitName', TransItemPriceTotal, TransItemPriceUnit, BuyPriceEstimation, TransItemPriceTotalBasic, TransItemComment, TransItemChecked from "+
    "(select tb1.*, Item.Name as 'ItemName', StockUnit, BuyPriceEstimation, TransItemQty*BuyPriceEstimation as 'TransItemPriceTotalBasic' from "+
     "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
     "from "+DbTable+"XItemOut where "+DbTable+"="+CurrTrans_Id+") as tb1 "+
    "left join Item on tb1.TransItem=Item.Id) as tb2 "+
   "left join StockUnit on tb2.StockUnit=StockUnit.Id "+
   "order by ItemName asc";
  
  if(OptList_ItemCategorized){
   if(ItemOutCategories.elementAt(ItemOutCurrCategory).Id==-1){con=" is "+CCore.vNull;}
   else{con="="+ItemOutCategories.elementAt(ItemOutCurrCategory).Id;}
   Query=
    "select c1.*, CategoryOfItem from "+
     "("+Query+") as c1 "+
    "left join ItemXCategory on c1.TransItem=ItemXCategory.Item where CategoryOfItem"+con+" "+
    "order by ItemName asc";
  }
  
  if(PDatabase.queryToRows(Stm2, Query, ItemOutList,
   PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeBoolean),
   null, true, ItemOutSumColumn, ItemOutSumResult, false, false, null, -1, false, -1, true, true, false, PrintedItems, 0)==-1){throw new Exception();}
  
  fillItemOutCategorySummary(ItemOutList.size(), ItemOutSumResult[4]);
 }
 private boolean getNextItemOut() throws Exception{
  int insertpos;
  ODimension dim;
  long ItemId; String ItemName; double ItemQty; double ItemPriceTotal; double ItemPriceUnit; String ItemComment; boolean ItemChecked; String ItemDescription;
  Object[] objs;
  
  if(ItemOutListCurrItem<ItemOutList.size()){ItemOutListCurrItem=ItemOutListCurrItem+1;;}
  
  if(ItemOutListCurrItem==ItemOutList.size()){return false;}
  
  objs=ItemOutList.elementAt(ItemOutListCurrItem);
  ItemId=PCore.objLong(objs[0], -1L);
  ItemName=PCore.objString(objs[1], null);
  ItemQty=PCore.objDouble(objs[2], 0D);
  ItemPriceTotal=PCore.objDouble(objs[4], 0D);
  ItemPriceUnit=PCore.objDouble(objs[5], 0D);
  ItemComment=PCore.objString(objs[8], null);
  ItemChecked=PCore.objBoolean(objs[9], false);
  ItemDescription=
   ItemName+" ("+ItemId+")"+
   PText.getString(ItemComment, "", " {"+ItemComment+"}", true);
  
  TableNewRow2=new ODrawTableRow(0, Table_ListItemOut.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PText.getString(ItemChecked, PointOfTransListItemChecked, PointOfTransListItemUnchecked),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(1, new ODrawTableCellText(ItemDescription,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.priceToString(ItemQty),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.priceToString(ItemPriceUnit),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(4, new ODrawTableCellText(PText.priceToString(ItemPriceTotal),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItemOut.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_ListItemOut.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_ListItemOut.Value.Inset.InsetTop+Table_ListItemOut.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItemOut.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_ListItemOut.Value.Inset.InsetTop+Table_ListItemOut.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_ListItemOut.Value, insertpos);
  }
  
  return true;
 }
 
 // Payment Out
 private void queryPayOut() throws Exception{
  // Date-Pay, Cash-Credit, Price, Comment
  Rs2=Stm2.executeQuery(
   "select PaymentDate, Cash.Name as 'CashName', Price, Comment from "+
    "(select * from "+DbTable+"XPayment where "+DbTable+"="+CurrTrans_Id+") as tb1 "+
   "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, Cash.Name asc;");
 }
 private boolean getNextPayOut() throws Exception{
  int insertpos;
  ODimension dim;
  Date PayDate; String PayCash; double PayPrice; String PayComment;
  
  if(!Rs2.next()){return false;}
  
  PayDate=Rs2.getDate(1);
  PayCash=Rs2.getString(2);
  PayPrice=Rs2.getDouble(3);
  PayComment=Rs2.getString(4);
  
  TableNewRow2=new ODrawTableRow(0, Table_ListPayOut.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PointOfTransList,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(1, new ODrawTableCellText(PText.getString(PayDate==null, "-", PText.dateToString(PayDate, 1)),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.getString(PayCash, "-", true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.priceToString(PayPrice),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(4, new ODrawTableCellText(PText.getString(PayComment, "-", "{"+PText.singleLine(PayComment, '~')+"}", true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListPayOut.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_ListPayOut.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_ListPayOut.Value.Inset.InsetTop+Table_ListPayOut.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_ListPayOut.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_ListPayOut.Value.Inset.InsetTop+Table_ListPayOut.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_ListPayOut.Value, insertpos);
  }
  
  return true;
 }
 
 // Payment In
 private void queryPayIn() throws Exception{
  // Date-Pay, Cash-Credit, Price, Comment
  Rs2=Stm2.executeQuery(
   "select PaymentDate, Cash.Name as 'CashName', Price, Comment from "+
    "(select * from "+DbTable+"XPaymentIn where "+DbTable+"="+CurrTrans_Id+") as tb1 "+
   "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, Cash.Name asc;");
 }
 private boolean getNextPayIn() throws Exception{
  int insertpos;
  ODimension dim;
  Date PayDate; String PayCash; double PayPrice; String PayComment;
  
  if(!Rs2.next()){return false;}
  
  PayDate=Rs2.getDate(1);
  PayCash=Rs2.getString(2);
  PayPrice=Rs2.getDouble(3);
  PayComment=Rs2.getString(4);
  
  TableNewRow2=new ODrawTableRow(0, Table_ListPayIn.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PointOfTransList,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(1, new ODrawTableCellText(PText.getString(PayDate==null, "-", PText.dateToString(PayDate, 1)),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.getString(PayCash, "-", true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.priceToString(PayPrice),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(4, new ODrawTableCellText(PText.getString(PayComment, "-", "{"+PText.singleLine(PayComment, '~')+"}", true),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListPayIn.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_ListPayIn.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_ListPayIn.Value.Inset.InsetTop+Table_ListPayIn.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_ListPayIn.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_ListPayIn.Value.Inset.InsetTop+Table_ListPayIn.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_ListPayIn.Value, insertpos);
  }
  
  return true;
 }

}
