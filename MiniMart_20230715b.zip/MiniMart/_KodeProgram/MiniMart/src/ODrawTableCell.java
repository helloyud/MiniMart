import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.util.Vector;

public abstract class ODrawTableCell {
 
	Vector<ODrawComponent> Contents;

 public void init(){
  Contents=new Vector();
 }
 
 /*
  Parameters in the 'generate draw contents' procedure can be anything, which indicates
  the identity of row and column of the table that will be inserted to the table.
  So, it will be better if the parameters in the 'generate draw contents' procedure are independence from the table, because
  we assume that the 'generate draw contents' procedure is run before a row (which contains the cells) is inserted to the table.
  
  Parameters description :
  - ODrawTable InsertToTable = this cell is planned to be inserted to 'InsertToTable'
  - int InsertToRowIndex = this cell is planned to be inserted to 'InsertToRowIndex' of the 'InsertToTable'
  - int InsertToColumnIndex = this cell is planned to be inserted to 'InsertToColumnIndex' of the 'InsertToTable'
  - ODrawTableRow NewRow = this cell is belonged to 'NewRow'
 */
 public abstract boolean preGenerateDrawContents(ODrawTable InsertToTable, int InsertToRowIndex, int InsertToColumnIndex, ODrawTableRow NewRow);
 public abstract ODimension calculatePreGeneratedDrawContentsDimension(ODrawTable InsertToTable, int InsertToRowIndex, int InsertToColumnIndex, ODrawTableRow NewRow);
 public abstract void generateDrawContents(ODrawTable InsertToTable, int InsertToRowIndex, int InsertToColumnIndex, ODrawTableRow NewRow);
	
 // draw
	public void drawInCell(Graphics2D g, OGraphicsProperties Prop,
		double CellAreaOffsetX, double CellAreaOffsetY){
		int temp, length;
		AffineTransform at;
  
  length=Contents.size();
		if(length==0){return;}
		
		at=g.getTransform();
		g.translate(CellAreaOffsetX, CellAreaOffsetY);
		
		temp=0;
		do{
			Contents.elementAt(temp).draw(g, Prop);
			temp=temp+1;
		}while(temp!=length);
	 
		g.setTransform(at);
	}
	
}