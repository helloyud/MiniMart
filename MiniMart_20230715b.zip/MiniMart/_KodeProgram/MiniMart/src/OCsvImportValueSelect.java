import java.util.Vector;

public class OCsvImportValueSelect extends OCsvImportValue {
 
 OCsvImportValueCheckable SQLValueCheckable;
 OCsvImportValue SQLValueIfCheckableError;
 OCsvImportValue SQLValueIfCheckableEmpty;
 OCsvImportValue SQLValueIfCheckableValid;

 public OCsvImportValueSelect(OCsvImportValueCheckable SQLValueCheckable, OCsvImportValue SQLValueIfCheckableError, OCsvImportValue SQLValueIfCheckableEmpty, OCsvImportValue SQLValueIfCheckableValid) {
  initVariables(SQLValueCheckable, SQLValueIfCheckableError, SQLValueIfCheckableEmpty, SQLValueIfCheckableValid);
 }
 
 public void initVariables(OCsvImportValueCheckable SQLValueCheckable, OCsvImportValue SQLValueIfCheckableError, OCsvImportValue SQLValueIfCheckableEmpty, OCsvImportValue SQLValueIfCheckableValid){
  this.SQLValueCheckable = SQLValueCheckable;
  this.SQLValueIfCheckableError = SQLValueIfCheckableError;
  this.SQLValueIfCheckableEmpty = SQLValueIfCheckableEmpty;
  this.SQLValueIfCheckableValid = SQLValueIfCheckableValid;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  preGenerateSQLValue(LastReadRecordFromFile);
  SQLValueCheckable.prepareGenerateSQLValue(LastReadRecordFromFile);
  if(SQLValueIfCheckableError!=null){SQLValueIfCheckableError.prepareGenerateSQLValue(LastReadRecordFromFile);}
  if(SQLValueIfCheckableEmpty!=null){SQLValueIfCheckableEmpty.prepareGenerateSQLValue(LastReadRecordFromFile);}
  if(SQLValueIfCheckableValid!=null){SQLValueIfCheckableValid.prepareGenerateSQLValue(LastReadRecordFromFile);}
 }
 public OGeneratedSQLValue generateSQLValue(){
  OGeneratedSQLValue ret=new OGeneratedSQLValue();
  OCsvImportValue SQLValue;
  OGeneratedSQLValue GenSQLValue;
  
  SQLValue=null;
  switch(SQLValueCheckable.checkAndGenerateSQLValue()){
   case OCsvImportValueCheckable.CheckError : if(SQLValueIfCheckableError!=null){SQLValue=SQLValueIfCheckableError;} break;
   case OCsvImportValueCheckable.CheckEmpty : if(SQLValueIfCheckableEmpty!=null){SQLValue=SQLValueIfCheckableEmpty;} break;
   case OCsvImportValueCheckable.CheckValid :
    if(SQLValueCheckable.GetValidFromThisClass){SQLValue=SQLValueCheckable;}
    else{
     if(SQLValueIfCheckableValid!=null){SQLValue=SQLValueIfCheckableValid;}
    }
    break;
  }
  
  if(SQLValue!=null){
   GenSQLValue=SQLValue.generateSQLValue();
   if(GenSQLValue.isGenerated()){ret.setGeneratedSQLValue(GenSQLValue.getGeneratedSQLValue());}
  }
  
  return ret;
 }
 
}
