import java.sql.ResultSetMetaData;
import java.util.Vector;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;

public class OCustomComboBoxModel extends AbstractListModel
 implements ComboBoxModel, OCustomModel {

 OCustomModelCommon Mdl;
 
 // set
 int MainColumn;

 Object SelectedItem;
 
 // constructor
 OCustomComboBoxModel(){
  init(false, false, false, false, -1);
 }
 OCustomComboBoxModel(boolean EnableCheck, boolean CheckDefaultNewValue, boolean CheckEditable, boolean EnableIndex, int IndexColumn){
  init(EnableCheck, CheckDefaultNewValue, CheckEditable, EnableIndex, IndexColumn);
 }
 void init(boolean EnableCheck, boolean CheckDefaultNewValue, boolean CheckEditable, boolean EnableIndex, int IndexColumn){
  Mdl=new OCustomModelCommon();
  Mdl.init(this, EnableCheck, CheckDefaultNewValue, CheckEditable, EnableIndex, IndexColumn);
 }
 
 // Mdl methods
 public int getColumnsCount(){return Mdl.getColumnsCount();}
 public int[] getColumnsType(){return Mdl.getColumnsType();}
 
 public Vector<Object[]> getRows(){return Mdl.getRows();}

 public void insert_(int RowIndex, Object[] NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.insert_(RowIndex, NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void insert(int RowIndex, Object[] NewRow, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.insert(RowIndex, NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void insert(int RowIndex, Object[] NewRow){Mdl.insert(RowIndex, NewRow);}
 public void append_(Object[] NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append_(NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append(NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow){Mdl.append(NewRow);}
 public void append(Vector<Object[]> NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append(NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Vector<Object[]> NewData){Mdl.append(NewData);}
 public void remove_(int RowIndex){Mdl.remove_(RowIndex);}
 public void remove(int RowIndex){Mdl.remove(RowIndex);}
 public void remove(int[] RowsIndex){Mdl.remove(RowsIndex);}
 public void remove(int[] RowsIndex, boolean[] IsRemove){Mdl.remove(RowsIndex, IsRemove);}
 public void removeAll(){Mdl.removeAll();}
 public void changeValue_(int RowIndex, Object[] NewValue){Mdl.changeValue_(RowIndex, NewValue);}
 public void changeValue(int RowIndex, Object[] NewValue){Mdl.changeValue(RowIndex, NewValue);}
 
 public Vector<Object[]> subData(int[] Columns, int[] SelectedRows){return Mdl.subData(Columns, SelectedRows);}
 public Object[] getObjects(int Column, int[] SelectedRows){return Mdl.getObjects(Column, SelectedRows);}
 public long[] getIds(int Column, int[] SelectedRows){return Mdl.getIds(Column, SelectedRows);}
 
 public boolean isCheckable(){return Mdl.isCheckable();}
 public Vector<Boolean> getCheckList(){return Mdl.getCheckList();}
 public Vector<Boolean> getCheckList(int[] Rows){return Mdl.getCheckList(Rows);}
 public boolean getCheckDefaultNewValue(){return Mdl.getCheckDefaultNewValue();}
 public int getCheckedCount(){return Mdl.getCheckedCount();}
 public void setCheckedCount(int CheckedCount){Mdl.setCheckedCount(CheckedCount);}
 public void addCheckedCount(int AddValue, boolean IsAdd){Mdl.addCheckedCount(AddValue, IsAdd);}
 public boolean getChecked(int RowIndex){return Mdl.getChecked(RowIndex);}
 public int[] getChecked(boolean Value){return Mdl.getChecked(Value);}
 public int[] getChecked(int[] RowsIndex, boolean Value){return Mdl.getChecked(RowsIndex, Value);}
 public long[] getCheckedLong(int Column){return Mdl.getCheckedLong(Column);}
 public boolean setChecked(int RowIndex, boolean Chk){return Mdl.setChecked(RowIndex, Chk);}
 public int[] setChecked(int[] Indices, boolean Chk){return Mdl.setChecked(Indices, Chk);}
 public int[] checkAll(boolean CheckValue){return Mdl.checkAll(CheckValue);}
 public Object[] check(long[] Data, int Column, int[] RangeRows, int IfFound_AddRowMode, boolean IfFound_IsUpdate, boolean IfFound_UpdateValue,
  int IfNotFound_AddRowMode, boolean IfNotFound_IsUpdate, boolean IfNotFound_UpdateValue){
  return Mdl.check(Data, Column, RangeRows, IfFound_AddRowMode, IfFound_IsUpdate, IfFound_UpdateValue,
   IfNotFound_AddRowMode, IfNotFound_IsUpdate, IfNotFound_UpdateValue);
 }
 public int[] check(long[] Data, boolean Chk, int Column){
  return Mdl.check(Data, Chk, Column);
 }
 
 // metadata methods
 void setColumnsInfo(int[] ColumnsType_, int MainColumn_){
  Mdl.ColumnsType=ColumnsType_;
  Mdl.ColumnsCount=Mdl.ColumnsType.length;
  MainColumn=MainColumn_;
 }
 public void updateColumnsInfo(ResultSetMetaData RsM) throws Exception{
  int[] ColumnsType_;
  int temp, temp_;
  removeAll();
  temp=RsM.getColumnCount();
  ColumnsType_=new int[temp];
  temp_=0;
  do{
   ColumnsType_[temp_]=PDatabase.convertJavaSQLDataTypeToMyType(RsM, temp_+1);
   temp_=temp_+1;
  }while(temp_!=temp);
  if(MainColumn>=temp){MainColumn=0;}
  setColumnsInfo(ColumnsType_, MainColumn);
 }

 // GUI methods
 public Object getSelectedItem(){return SelectedItem;}
 public void setSelectedItem(Object Item){SelectedItem=Item;}
 public Object getElementAt(int index) {return Mdl.Rows.elementAt(index)[MainColumn];}
 public int getSize() {return Mdl.Rows.size();}
 public void fireIntervalAdded(Object source, int index0, int index1){super.fireIntervalAdded(source, index0, index1);}
 public void fireContentsChanged(Object source, int index0, int index1){super.fireContentsChanged(source, index0, index1);}
 public void fireIntervalRemoved(Object source, int index0, int index1){super.fireIntervalRemoved(source, index0, index1);}
 public void refreshInsert(int StartIndex, int EndIndex){fireIntervalAdded(this, StartIndex, EndIndex);}
 public void refreshUpdate(int StartIndex, int EndIndex){fireContentsChanged(this, StartIndex, EndIndex);}
 public void refreshRemove(int StartIndex, int EndIndex){fireIntervalRemoved(this, StartIndex, EndIndex);}

}