public class OLabelDataTestPrint extends OLabelData {
 
 public static final int ModeNormal=0;
 
 int Mode;

 public OLabelDataTestPrint(int Mode) {
  this.Mode = Mode;
 }
 public OLabelDataTestPrint() {this(ModeNormal);}
 
}