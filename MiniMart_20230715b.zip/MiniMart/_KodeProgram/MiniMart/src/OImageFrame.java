public class OImageFrame {
 String FileName;
 StringBuilder Comment;
}