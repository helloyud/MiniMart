import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;
import java.util.Vector;

public class OActionKeyFocusOrdered extends OActionKey {
 
 boolean MoveInside;
 boolean MoveInside_OnlyMoveInside;
 boolean IsForward;
 Object[] OrderedCmps;
 
 public OActionKeyFocusOrdered(){}
 public OActionKeyFocusOrdered(boolean MoveInside, boolean MoveInside_OnlyMoveInside, boolean IsForward, Object[] OrderedCmps) {
  init(MoveInside, MoveInside_OnlyMoveInside, IsForward, OrderedCmps);
 }
 public OActionKeyFocusOrdered(
  Window Form, Component Cmp, KeyEvent evt,
  boolean MoveInside, boolean MoveInside_OnlyMoveInside, boolean IsForward, Object[] OrderedCmps) {
  
  init(Form, Cmp, evt, MoveInside, MoveInside_OnlyMoveInside, IsForward, OrderedCmps);
 
 }
 
 OActionKeyFocusOrdered init(boolean MoveInside, boolean MoveInside_OnlyMoveInside, boolean IsForward, Object[] OrderedCmps){
  this.MoveInside=MoveInside;
  this.MoveInside_OnlyMoveInside=MoveInside_OnlyMoveInside;
  this.IsForward=IsForward;
  this.OrderedCmps = OrderedCmps;
  return this;
 }
 OActionKeyFocusOrdered init(
  Window Form, Component Cmp, KeyEvent evt,
  boolean MoveInside, boolean MoveInside_OnlyMoveInside, boolean IsForward, Object[] OrderedCmps){
  
  init(Form, Cmp, evt);
  init(MoveInside, MoveInside_OnlyMoveInside, IsForward, OrderedCmps);
  
  return this;
 }
 
 public int doAction() {
  int ret=CNav.Ret_Unconsumed;
  
  if(PGUI.requestFocusInWindow_Ordered(MoveInside, MoveInside_OnlyMoveInside, IsForward, OrderedCmps, Cmp)){ret=CNav.Ret_Consumed;}
  
  return ret;
 }
 
}