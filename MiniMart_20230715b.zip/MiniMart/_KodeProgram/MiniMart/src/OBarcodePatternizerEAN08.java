public class OBarcodePatternizerEAN08 extends OBarcodePatternizer {
 
 /*
  EAN-8 encoding process's example :
  
  barcode : 1234-5670
 
  > check whether 'the last digit' is valid or not with checksum (this step is optional)
  
  > add start marker : 101
 
  > translate 'digit 1st .. digit 4th' using fixed left pattern rule AAAA
    1 -> 0011001
    2 -> 0010011
    3 -> 0111101
    4 -> 0100011
 
  > add center marker : 01010
 
  > translate 'digit 5th .. digit 8th' using right pattern
    5 -> 1001110
    6 -> 1010000
    7 -> 1000100
    0 -> 1110010 (here, the last digit is the checksum)
 
  > add end marker : 101
 
 */
 
 String[] LeftPatternsA;
 String[] RightPatterns;
 String StartEndMarker;
 String CenterMarker;
 
 public OBarcodePatternizerEAN08(){
  LeftPatternsA=OBarcodePatternsEAN.getLeftPatternsA();
  RightPatterns=OBarcodePatternsEAN.getRightPatterns();
  StartEndMarker=OBarcodePatternsEAN.getStartEndMarker();
  CenterMarker=OBarcodePatternsEAN.getCenterMarker();
 }
 
 protected OBarcodePatterns patternizing(){
  // max digit of Number <= 18, MinimalDigitCount >=1 && <=18
  String[] ret=null;
  String Code;
  int temp;
  
  Code=PText.paddingNumber(Number, OBarcodeGeneratorEAN.Ean08_Length);
  if(OBarcodeGeneratorEAN.checkCodeValidity(Code, OBarcodeGeneratorEAN.Ean08_Length)==false){return null;}
  
  ret=new String[11];
  
  ret[0]=StartEndMarker;
  
  temp=0;
  do{
   ret[1+temp]=getLeftPattern(Code, 0+temp);
   temp=temp+1;
  }while(temp!=4);
  
  ret[5]=CenterMarker;
  
  temp=0;
  do{
   ret[6+temp]=getRightPattern(Code, 4+temp);
   temp=temp+1;
  }while(temp!=4);
  
  ret[10]=StartEndMarker;
  
  return new OBarcodePatterns(ret, OBarcodePatternsEAN08.getStandardSpecification());
 }
 
 private String getLeftPattern(String Code, int CodeIndex){
  return LeftPatternsA[Code.charAt(CodeIndex)-48];
 }
 private String getRightPattern(String Code, int CodeIndex){
  return RightPatterns[Code.charAt(CodeIndex)-48];
 }

}