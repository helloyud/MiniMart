import java.util.Vector;

public class OVector<E> extends Vector<E> {

 public OVector add2(int index, E element) {
  add(index, element);
  return this;
 }
 public OVector addElement2(E obj) {
  addElement(obj);
  return this;
 }
 
}