import java.io.File;
import javax.swing.filechooser.FileFilter;

public class OFileFilterLabel extends FileFilter {
 public boolean accept(File path){
  boolean ret=true;
  if(path.isFile()){
   ret=PFile.compareIgnoreCaseExtension(path.getName(), "labels");
  }
  return ret;
 }
 public String getDescription(){
  return new String("File Data Label (.labels)");
 }
}