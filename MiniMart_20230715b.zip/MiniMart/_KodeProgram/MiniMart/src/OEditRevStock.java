import java.util.Date;

public class OEditRevStock {
 
 boolean EditRevDate; Date EditedRevDate;
 boolean EditReasonOfRevisi; Integer EditedReasonOfRevisiId; String EditedReasonOfRevisiName;
 
 public OEditRevStock(){clearAll();}
 
 OEditRevStock clearAll(){
  init(
   false, null,
   false, -1, null);
  
  return this;
 }
 
 OEditRevStock init(
  boolean EditRevDate, Date EditedRevDate,
  boolean EditReasonOfRevisi, int EditedReasonOfRevisiId, String EditedReasonOfRevisiName) {
  
  this.EditRevDate = EditRevDate; this.EditedRevDate = EditedRevDate;
  this.EditReasonOfRevisi = EditReasonOfRevisi; this.EditedReasonOfRevisiId = EditedReasonOfRevisiId; this.EditedReasonOfRevisiName = EditedReasonOfRevisiName;
  
  return this;
 }
 
}