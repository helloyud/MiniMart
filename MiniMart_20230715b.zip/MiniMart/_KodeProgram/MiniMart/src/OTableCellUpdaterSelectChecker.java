import java.util.Vector;

public abstract class OTableCellUpdaterSelectChecker {
 
 OCustomModel Model; Vector<Object[]> Rows; int[] ColumnsType;

 void setModel(OCustomModel Model, Vector<Object[]> Rows, int[] ColumnsType){
  this.Model=Model;
  this.Rows=Rows;
  this.ColumnsType=ColumnsType;
 }
 void setModel(OCustomModel Model){
  setModel(Model, Model.getRows(), Model.getColumnsType());
 }
 Vector<Object[]> getRows(){
  if(Model==null){return Rows;}else{return Model.getRows();}
 }
 
 public abstract boolean check(int TableRowIndex);

}