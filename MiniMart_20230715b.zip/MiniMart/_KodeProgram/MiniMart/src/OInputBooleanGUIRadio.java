import javax.swing.JRadioButton;

public class OInputBooleanGUIRadio extends OInput {

 JRadioButton GUI_Yes;
 JRadioButton GUI_No;
 
 VBoolean Value;

 public OInputBooleanGUIRadio(JRadioButton GUI_Yes, JRadioButton GUI_No) {
  this.GUI_Yes = GUI_Yes;
  this.GUI_No = GUI_No;
  Value=new VBoolean();
 }
 
 public boolean isValid(){return PGUI.checkInputBoolean(GUI_Yes, GUI_No, Value);}
 public Object getValue(){return Value.Value;}

}