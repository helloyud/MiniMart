import java.awt.Component;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.table.TableCellEditor;
import javax.swing.text.JTextComponent;

public class XTable extends JTable {

 AbstractAction Editing_Action;
 TableCellEditor Editing_Editor;
 int Editing_Row, Editing_Col;
 Object Editing_ValueOld, Editing_ValueNew;
 
 int OnKeyPress_PosRow, OnKeyPress_PosCol;
 int FocusState;
 boolean IsSelecting;
 
 public XTable(){
  super();
  /*
   method putClientProperty("terminateEditOnFocusLost", Boolean.TRUE) can be changed by :
    adding "onFocustLost" event to XTable and put XTable.terminateEditing() inside of "onFocusLost" event.
  */
  putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
  
  addKeyListener(new KeyAdapter(){
    public void keyPressed(KeyEvent evt){
     int KeyCode=evt.getKeyCode();
     
     setFocusState(CGUI.FocusState_Work);
     if(PNav.isKeyArrow(KeyCode) && evt.isShiftDown()){setIsSelecting(true);}
     
     setOnKeyPressPosCell(getSelectedRow(), getSelectedColumn());
    }
    public void keyReleased(KeyEvent evt){}
   });
  
  addFocusListener(new FocusAdapter(){
    public void focusGained(FocusEvent evt){setFocusState(CGUI.FocusState_Enter); setIsSelecting(false);}
    public void focusLost(FocusEvent evt){setFocusState(CGUI.FocusState_Leave); setIsSelecting(false);}
   });
 }
 
 public void editingStopped(ChangeEvent e) {
  if(Editing_Action==null){super.editingStopped(e); return;}
  
  Editing_Editor=getCellEditor();
  if(Editing_Editor==null){return;}
  saveEditing();
  removeEditor();
  if(Editing_Action!=null){Editing_Action.actionPerformed(null);}
 }
 void saveEditing(){
  Editing_Row=convertRowIndexToModel(getEditingRow());
  Editing_Col=convertColumnIndexToModel(getEditingColumn());
  Editing_ValueOld=getModel().getValueAt(Editing_Row, Editing_Col);
  Editing_ValueNew=Editing_Editor.getCellEditorValue();
 }

 public Component prepareEditor(TableCellEditor editor, int row, int column) {
  Component ret=super.prepareEditor(editor, row, column);
  if (ret instanceof JTextComponent) {
   ((JTextComponent)ret).selectAll();
  }
  return ret;
 }
 
 void terminateEditing(){
  TableCellEditor editor=getCellEditor();
  if(editor==null){return;}
  editor.stopCellEditing();
 }
 
 void setOnKeyPressPosCell(int Row, int Col){OnKeyPress_PosRow=Row; OnKeyPress_PosCol=Col;}
 void setFocusState(int Value){FocusState=Value;}
 void setIsSelecting(boolean Value){IsSelecting=Value;}
 
}