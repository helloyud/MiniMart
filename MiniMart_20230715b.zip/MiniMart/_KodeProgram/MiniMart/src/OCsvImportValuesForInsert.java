import java.util.Vector;

public class OCsvImportValuesForInsert extends OCsvImportValues {

 public OCsvImportValuesForInsert(Vector<OCsvImportValue> ColumnsValue) {
  initVariables(PCore.vect(PCore.newStringArray(ColumnsValue.size(), ",")), ColumnsValue);
 }
 
}
