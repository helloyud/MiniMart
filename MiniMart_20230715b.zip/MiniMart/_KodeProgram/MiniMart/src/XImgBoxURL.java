import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;

public class XImgBoxURL extends XImgBox{

 URL ImageFile;
 
 public XImgBoxURL(){
  super();
  setImageSource(null);
 }
 
 public void setImageSource(String path){
  boolean bool=false;
  if(path!=null){
   try{ImageFile=new URL(path); bool=true;}
   catch(Exception E_){}
  }
  if(!bool){ImageFile=null;}
  
  updateImageSource();
  updateImgSizeAndPosition(true);
 }
 protected boolean isImageSourceAvailable(){
  return ImageFile!=null;
 }
 protected BufferedImage readImageSource(){
  BufferedImage ret=null;
  try{ret=ImageIO.read(ImageFile);}catch(Exception E){}
  return ret;
 }
 
}
