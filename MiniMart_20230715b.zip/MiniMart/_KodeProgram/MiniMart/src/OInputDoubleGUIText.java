import javax.swing.JTextField;

public class OInputDoubleGUIText extends OInput {

 JTextField GUI_Text;
 boolean AcceptEmptyInput;
 boolean AcceptZero;
 boolean PositiveOnly;
 boolean WithinRange;
 double Range1, Range2;
 
 VDouble Value;

 public OInputDoubleGUIText(JTextField GUI_Text, boolean AcceptEmptyInput, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, double Range1, double Range2) {
  this.GUI_Text = GUI_Text;
  this.AcceptEmptyInput = AcceptEmptyInput;
  this.AcceptZero = AcceptZero;
  this.PositiveOnly = PositiveOnly;
  this.WithinRange=WithinRange;
  this.Range1=Range1;
  this.Range2=Range2;
  
  Value=new VDouble();
 }
 
 public boolean isValid(){return PGUI.checkInputDouble(GUI_Text, Value, AcceptEmptyInput, AcceptZero, PositiveOnly, WithinRange, Range1, Range2);}
 public Object getValue(){return Value.Value;}

}