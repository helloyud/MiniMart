import java.util.Vector;

public class ODatabaseTable {
 
 String Name;
 int SinceVersion;
 boolean IncludeInBackup;
 
 Vector<ODatabaseTableColumn> Columns;

 public ODatabaseTable(String Name, int SinceVersion, boolean IncludeInBackup) {
  this.Name = Name;
  this.SinceVersion = SinceVersion;
  this.IncludeInBackup=IncludeInBackup;
  Columns=new Vector();
 }
 
}