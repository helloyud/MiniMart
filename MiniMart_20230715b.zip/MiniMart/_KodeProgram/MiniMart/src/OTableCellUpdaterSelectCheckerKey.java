import java.util.Vector;

public class OTableCellUpdaterSelectCheckerKey extends OTableCellUpdaterSelectChecker {
 
 int[] CheckColumns_Table;
 
 Vector<Object[]> Key;
 int[] CheckColumns_Key;

 public OTableCellUpdaterSelectCheckerKey(int[] CheckColumns_Table, Vector<Object[]> Key, int[] CheckColumns_Key) {
  this.CheckColumns_Table = CheckColumns_Table;
  this.Key = Key;
  this.CheckColumns_Key = CheckColumns_Key;
 }
 
 public boolean check(int TableRowIndex){
  Object[] CurrRow=getRows().elementAt(TableRowIndex);
  
  return PTable.findData(ColumnsType, false, Key, CheckColumns_Key, CurrRow, CheckColumns_Table)!=-1;
 }
 
}