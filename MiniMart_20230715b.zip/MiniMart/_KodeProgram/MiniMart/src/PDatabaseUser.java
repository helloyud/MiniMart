import java.sql.Statement;
import java.util.Vector;

public class PDatabaseUser {

 static String[] ItemColPublic={
  "Name", "IsActive", "Comment",
  "StockUnit", "MinimalStock", "MaximalStock",
  "IsOpname", "IsReorder", "OrderEachPackQty", "OrderEachPackThreshold", "OrderMinPack",
  "SellPrice", "SellPriceComment", "SellUpdate", "BuyPriceEstimation", "BuyPriceComment", "BuyUpdate",
  "HasExpireDate", "ExpireCheckPeriod", "ExpireThreshold",
  "OpnameStock", "OpnameExpire", "OrderQuantity"};
 static String[] ItemColPrivate={"Id", "Stock", "UpdateStockOnTransaction", "MismatchStock"};
 static String[] TransColPublic={
  "TransDate", "TransType", "IsImportant", "Comment", "InfoIdExternal",
  "Cash", "CashOutComment", "CashIn", "CashInComment",
  "Subject", "Salesman",
  "CreditDays", "RepaymentPeriodStart", "RepaymentPeriodEnd"};
 static String[] TransXItemColPublic={"Stock", "Price", "Comment", "Checked"};
 static String[] TransXPaymentColPublic={"PaymentDate", "Cash", "Price", "Comment"};
 static String[] RevisiStockColPublic={"RevisiDate", "ReasonOfRevisi"};
 static String[] ConvColPublic={
  "ConvDate", "ReasonOfConv", "RuleOfConvDirection", "RuleOfConvCount"};
 static String[] ConvXItemColPublic={"Stock"};
 static String[] CheckAdminPrivillegesCol={"super_priv", "grant_priv", "create_priv", "drop_priv"};
 static final int DatabasePrivillegesCount=9;

 public static int createUser(Statement Stm, String NewUser, String Password){
  int ret=execUser(Stm, NewUser, "create user", "identified by '"+PSql.norm(Password)+"'");
  
  if(ret!=0){grantUserBasicPrivilleges(Stm, true, NewUser);}
  
  return ret;
 }
 public static int dropUser(Statement Stm, String User){
  return execUser(Stm, User, "drop user", "");
 }

 public static int changePassword(Statement Stm, String ToUser, String NewPassword){
  int ret;
  do{
   ret=execUser(Stm, ToUser, "set password for", "= password('"+PSql.norm(NewPassword)+"')"); if(ret>0){break;}
   ret=execUser(Stm, ToUser, "alter user", "identified by '"+PSql.norm(NewPassword)+"'"); if(ret>0){break;}
  }while(false);
  return ret;
 }

 public static boolean[] checkAccessLocation(Statement Stm, String User){
  boolean[] ret=null;
  boolean[] ret_=PCore.newBooleanArray(2, false);
  int result;
  do{
   // check localhost
   result=PDatabase.isQueryEmpty(Stm, "select user from mysql.user where lower(user)=lower('"+PSql.norm(User)+"') and lower(host)='localhost'", true);
   if(result==-1){break;}
   ret_[0]=result==1;
   
   // check remote
   result=PDatabase.isQueryEmpty(Stm, "select user from mysql.user where lower(user)=lower('"+PSql.norm(User)+"') and host='%'", true);
   if(result==-1){break;}
   ret_[1]=result==1;
   
   ret=ret_;
  }while(false);
  return ret;
 }

 public static int grantAdminPrivilleges(Statement Stm, String User){
  return execUser(Stm, User, "grant all on *.* to", "with grant option");
 }
 public static int hasAdminPrivilleges(Statement Stm, String User){
  return PDatabase.isQueryEmpty(Stm, "select user from mysql.user where lower(user)=lower('"+PSql.norm(User)+"')"+
   PText.toStringColsValues(PText.modify(CheckAdminPrivillegesCol, PCore.newStringArray(CheckAdminPrivillegesCol.length, "lower("), PCore.newStringArray(CheckAdminPrivillegesCol.length, ")")),
   PCore.newStringArray(CheckAdminPrivillegesCol.length, "="), PCore.newStringArray(CheckAdminPrivillegesCol.length, "lower('Y')"),
   PCore.newStringArray(CheckAdminPrivillegesCol.length, " and ")), true);
 }

 public static boolean grantUserBasicPrivilleges(Statement Stm, boolean IsGrant, String User){
  boolean ret=true;
  
  // check admin privilleges
  if(!grantColumnsPrivillege(Stm, IsGrant, User, "mysql", "user", PCore.concat(false, PCore.refArr("user", "host"), CheckAdminPrivillegesCol), true, false, false)){ret=false;}
  
  // check db privilleges
  if(!grantTablePrivillege(Stm, IsGrant, User, "mysql", "db", true, false, false, false)){ret=false;}
  if(!grantTablePrivillege(Stm, IsGrant, User, "mysql", "tables_priv", true, false, false, false)){ret=false;}
  if(!grantTablePrivillege(Stm, IsGrant, User, "mysql", "columns_priv", true, false, false, false)){ret=false;}
  if(!grantTablePrivillege(Stm, IsGrant, User, "mysql", "procs_priv", true, false, false, false)){ret=false;}
  
  return ret;
 }
 
 public static boolean grantDatabasePrivilleges(Statement Stm, boolean IsGrant, String User, String Database, int Access, boolean IgnoreError){
  boolean ret=true;
  do{
   if(Access==0){ // view all
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "*", true, false, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "CustomPaperLabel", false, true, true, true)==false){ret=false;}
    break;
   }
   if(Access==1){ // manage item - public
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Item", false, true, false, false)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "Item", ItemColPublic, false, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "StockUnit", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "CategoryOfItem", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXCategory", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TagOfItem", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXTag", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXPicture", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXSupplier", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXSecondaryId", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXVariant", false, true, true, true)==false){ret=false;}
    break;
   }
   if(Access==2){ // manage item - private
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Item", false, false, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "Item", ItemColPrivate, false, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ItemXSecondaryId", false, false, true, true)==false){ret=false;}
    
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "RevisiStock", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "RevisiStock", RevisiStockColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "RevAdd")==false){ret=false;}
    
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "RuleOfConv", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "RuleOfConvXSideA", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "RuleOfConvXSideB", false, true, true, true)==false){ret=false;}
    break;
   }
   if(Access==3){ // manage subject - public
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Subject", false, true, true, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "City", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ContactType", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "BankPlatform", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "CategoryOfSubject", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "SubjectXCategory", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "SubjectXAddress", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "SubjectXContact", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "SubjectXBankAccount", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TagOfSubject", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "SubjectXTag", false, true, true, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "SubjectXPicture", false, true, true, true)==false){ret=false;}
    break;
   }
   if(Access==4){ // manage subject - private
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Subject", false, false, false, true)==false){ret=false;}
    break;
   }
   if(Access==5){ // manage trans - public
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Trans", false, true, false, false)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransEditNotImportant")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransRemoveEmpty")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("TransXItemIn"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("TransXItemOut"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("TransXPayment"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("TransXPaymentIn"), false, true, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransInsert")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransRemoveTemporary")==false){ret=false;}
    
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransPend", false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransPendXItemIn", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransPendXItemOut", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransPendXPaymentOut", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransPendXPaymentIn", false, true, false, false)==false){ret=false;}
    
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Conv", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("ConvXItemOut"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("ConvXItemIn"), false, true, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "ConvInsert")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "ConvRemoveTemporary")==false){ret=false;}
    break;
   }
   if(Access==6){ // manage trans - private
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Trans", false, false, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "Trans", TransColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransInAdd")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransInAddUpdate")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransXItemIn", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "TransXItemIn", TransXItemColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransOutAdd")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "TransOutAddUpdate")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransXItemOut", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "TransXItemOut", TransXItemColPublic, false, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransXPayment", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "TransXPayment", TransXPaymentColPublic, false, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "TransXPaymentIn", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "TransXPaymentIn", TransXPaymentColPublic, false, false, true)==false){ret=false;}
    
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "Conv", false, false, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "Conv", ConvColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "ConvInAdd")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "ConvInAddUpdate")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ConvXItemIn", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "ConvXItemIn", ConvXItemColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "ConvOutAdd")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "ConvOutAddUpdate")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "ConvXItemOut", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "ConvXItemOut", ConvXItemColPublic, false, false, true)==false){ret=false;}
    break;
   }
   if(Access==7){ // manage pretrans - public
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTrans", false, true, false, false)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransEditNotImportant")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransRemoveEmpty")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransCancel")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("PreTransXItemIn"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("PreTransXItemOut"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("PreTransXPayment"), false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, CSQL.getTableTemp("PreTransXPaymentIn"), false, true, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransInsert")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransRemoveTemporary")==false){ret=false;}
    
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransPend", false, true, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransPendXItemIn", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransPendXItemOut", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransPendXPaymentOut", false, true, false, false)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransPendXPaymentIn", false, true, false, false)==false){ret=false;}
    break;
   }
   if(Access==8){ // manage pretrans - private
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTrans", false, false, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "PreTrans", TransColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransInAdd")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransInAddUpdate")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransXItemIn", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "PreTransXItemIn", TransXItemColPublic, false, false, true)==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransOutAdd")==false){ret=false;}
    if(grantExecuteProcedure(Stm, User, IsGrant, true, Database, "PreTransOutAddUpdate")==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransXItemOut", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "PreTransXItemOut", TransXItemColPublic, false, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransXPayment", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "PreTransXPayment", TransXPaymentColPublic, false, false, true)==false){ret=false;}
    if(grantTablePrivillege(Stm, IsGrant, User, Database, "PreTransXPaymentIn", false, true, false, true)==false){ret=false;}
    if(grantColumnsPrivillege(Stm, IsGrant, User, Database, "PreTransXPaymentIn", TransXPaymentColPublic, false, false, true)==false){ret=false;}
    break;
   }
  }while(false);
  if(IgnoreError){ret=true;}
  return ret;
 }
 public static boolean[] getDatabasePrivilleges(Statement Stm, String User, String Database,
  boolean OnlyCheckBase, boolean IgnoreError){
  /*
   The index order of "Access Permission" in "getDatabasePrivilleges() and grantDatabasePrivilleges() methods" must same.
   For example :
   - if "Access Permission of Item - Public" is at index 1 at "getDatabasePrivilleges() method",
     then it must be at index 1 too at "grantDatabasePrivilleges() method".
   - if "Access Permission of Trans - Public" is at index 6 at "getDatabasePrivilleges() method",
     then it must be at index 6 too at "grantDatabasePrivilleges() method".
  */
  boolean[] ret=PCore.newBooleanArray(DatabasePrivillegesCount, false); // return null (error) or result
  int temp;
  int result=0;
  
  temp=0;
  do{
   do{
    if(temp==0){ // select all
     result=checkTablePrivillege(Stm, User, Database, "*", true, false, false, false); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkTablePrivillege(Stm, User, Database, "CustomPaperLabel", false, true, true, true); if(result!=1){break;}
     break;
    }
    if(temp==1){ // manage item - public
     result=checkTablePrivillege(Stm, User, Database, "Item", false, true, false, false); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "Item", ItemColPublic, false, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "StockUnit", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "CategoryOfItem", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXCategory", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TagOfItem", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXTag", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXPicture", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXSupplier", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXSecondaryId", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXVariant", false, true, true, true); if(result!=1){break;}
     break;
    }
    if(temp==2){ // manage item - private
     result=checkTablePrivillege(Stm, User, Database, "Item", false, false, false, true); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "Item", ItemColPrivate, false, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ItemXSecondaryId", false, false, true, true); if(result!=1){break;}
     
     result=checkTablePrivillege(Stm, User, Database, "RevisiStock", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "RevisiStock", RevisiStockColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "RevAdd"); if(result!=1){break;}
     
     result=checkTablePrivillege(Stm, User, Database, "RuleOfConv", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "RuleOfConvXSideA", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "RuleOfConvXSideB", false, true, true, true); if(result!=1){break;}
     break;
    }
    if(temp==3){ // manage subject - public
     result=checkTablePrivillege(Stm, User, Database, "Subject", false, true, true, false); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkTablePrivillege(Stm, User, Database, "City", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ContactType", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "BankPlatform", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "CategoryOfSubject", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "SubjectXCategory", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "SubjectXAddress", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "SubjectXContact", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "SubjectXBankAccount", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TagOfSubject", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "SubjectXTag", false, true, true, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "SubjectXPicture", false, true, true, true); if(result!=1){break;}
     break;
    }
    if(temp==4){ // manage subject - private
     result=checkTablePrivillege(Stm, User, Database, "Subject", false, false, false, true); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     break;
    }
    if(temp==5){ // manage trans - public
     result=checkTablePrivillege(Stm, User, Database, "Trans", false, true, false, false); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransEditNotImportant"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransRemoveEmpty"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("TransXItemIn"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("TransXItemOut"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("TransXPayment"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("TransXPaymentIn"), false, true, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransInsert"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransRemoveTemporary"); if(result!=1){break;}

     result=checkTablePrivillege(Stm, User, Database, "TransPend", false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransPendXItemIn", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransPendXItemOut", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransPendXPaymentOut", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransPendXPaymentIn", false, true, false, false); if(result!=1){break;}
     
     result=checkTablePrivillege(Stm, User, Database, "Conv", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("ConvXItemOut"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("ConvXItemIn"), false, true, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "ConvInsert"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "ConvRemoveTemporary"); if(result!=1){break;}
     break;
    }
    if(temp==6){ // manage trans - private
     result=checkTablePrivillege(Stm, User, Database, "Trans", false, false, false, true); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "Trans", TransColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransInAdd"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransInAddUpdate"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransXItemIn", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "TransXItemIn", TransXItemColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransOutAdd"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "TransOutAddUpdate"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransXItemOut", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "TransXItemOut", TransXItemColPublic, false, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransXPayment", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "TransXPayment", TransXPaymentColPublic, false, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "TransXPaymentIn", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "TransXPaymentIn", TransXPaymentColPublic, false, false, true); if(result!=1){break;}
     
     result=checkTablePrivillege(Stm, User, Database, "Conv", false, false, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "Conv", ConvColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "ConvInAdd"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "ConvInAddUpdate"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ConvXItemIn", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "ConvXItemIn", ConvXItemColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "ConvOutAdd"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "ConvOutAddUpdate"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "ConvXItemOut", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "ConvXItemOut", ConvXItemColPublic, false, false, true); if(result!=1){break;}
     break;
    }
    if(temp==7){ // manage pretrans - public
     result=checkTablePrivillege(Stm, User, Database, "PreTrans", false, true, false, false); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransEditNotImportant"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransRemoveEmpty"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransCancel"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("PreTransXItemIn"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("PreTransXItemOut"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("PreTransXPayment"), false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, CSQL.getTableTemp("PreTransXPaymentIn"), false, true, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransInsert"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransRemoveTemporary"); if(result!=1){break;}

     result=checkTablePrivillege(Stm, User, Database, "PreTransPend", false, true, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransPendXItemIn", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransPendXItemOut", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransPendXPaymentOut", false, true, false, false); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransPendXPaymentIn", false, true, false, false); if(result!=1){break;}
     break;
    }
    if(temp==8){ // manage pretrans - private
     result=checkTablePrivillege(Stm, User, Database, "PreTrans", false, false, false, true); if(result!=1){break;}
     if(OnlyCheckBase){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "PreTrans", TransColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransInAdd"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransInAddUpdate"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransXItemIn", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "PreTransXItemIn", TransXItemColPublic, false, false, true); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransOutAdd"); if(result!=1){break;}
     result=checkProcPrivillege(Stm, true, User, Database, "PreTransOutAddUpdate"); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransXItemOut", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "PreTransXItemOut", TransXItemColPublic, false, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransXPayment", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "PreTransXPayment", TransXPaymentColPublic, false, false, true); if(result!=1){break;}
     result=checkTablePrivillege(Stm, User, Database, "PreTransXPaymentIn", false, true, false, true); if(result!=1){break;}
     result=checkColumnsPrivillege(Stm, User, Database, "PreTransXPaymentIn", TransXPaymentColPublic, false, false, true); if(result!=1){break;}
     break;
    }
   }while(false);
   if(!IgnoreError && result==-1){break;} if(result==1){ret[temp]=true;}
   
   temp=temp+1;
  }while(temp!=DatabasePrivillegesCount);
  if(temp!=DatabasePrivillegesCount){ret=null;}
  
  return ret;
 }
 public static String[] getUsers(Statement Stm){
  return PCore.strArr_VectObj(PDatabase.getListFromQuery(Stm, "select user from mysql.user group by user order by user asc;", CCore.TypeString, false, null));
 }
 public static Vector<OUserAccess> createUsersAccess(String[] Users, boolean[] InitAccess){
  Vector<OUserAccess> ret=null;
  int temp, count;
  
  if(Users==null){return null;}
  
  ret=new Vector();
  count=Users.length;
  if(count!=0){
   temp=0;
   do{
    ret.addElement(new OUserAccess(Users[temp], InitAccess));
    temp=temp+1;
   }while(temp!=count);
  }
  
  return ret;
 }
 public static boolean getUsersDatabasePrivilleges(Statement Stm, String Database, Vector<OUserAccess> UsersAccess, boolean IgnoreError){
  boolean ret=true;
  int temp, count;
  boolean[] CheckAccess;
  OUserAccess UserAccess;
  
  count=UsersAccess.size();
  if(count!=0){
   temp=0;
   do{
    UserAccess=UsersAccess.elementAt(temp);
    CheckAccess=getDatabasePrivilleges(Stm, UserAccess.User, Database, true, IgnoreError); if(CheckAccess==null){break;}
    UserAccess.Access=CheckAccess;
    temp=temp+1;
   }while(temp!=count);
   if(temp!=count){ret=false;}
  }
  
  return ret;
 }
 public static boolean setUsersDatabasePrivilleges(Statement Stm, String Database, Vector<OUserAccess> UsersAccess, boolean IgnoreError){
  boolean ret=true;
  int temp, count;
  int accesscount, accesstemp;
  OUserAccess UserAccess;
  
  count=UsersAccess.size();
  if(count!=0){
   temp=0;
   do{
    UserAccess=UsersAccess.elementAt(temp);
    if(!PCore.isArrayEmpty(UserAccess.Access, true)){
     accesscount=UserAccess.Access.length;
     accesstemp=0;
     do{
      if(!grantDatabasePrivilleges(Stm, UserAccess.Access[accesstemp], UserAccess.User, Database, accesstemp, IgnoreError)){break;}
      accesstemp=accesstemp+1;
     }while(accesstemp!=accesscount);
     if(accesstemp!=accesscount){break;}
    }
    temp=temp+1;
   }while(temp!=count);
   if(temp!=count){ret=false;}
  }
  
  return ret;
 }

 private static boolean grantTablePrivillegeCommon(Statement Stm, boolean IsGrant, String User, String Database, String Table,
  String[] PrivillegeName){
  boolean ret=true;
  int result;
  String Grant=PText.getString(IsGrant, "grant ", "revoke ");
  String To=PText.getString(IsGrant, " to", " from");
  
  result=1;
  if(!IsGrant){
   result=checkTablePrivillegeCommon(Stm, User, Database, Table, PrivillegeName);
  }
  if(result==1){
   if(execUser(Stm, User, Grant+PText.toString(PrivillegeName, 0, PrivillegeName.length, ",")+" on "+Database+"."+Table+To, "")==0){ret=false;}
  }
  else if(result==-1){ret=false;}
  
  return ret;
 }
 private static boolean grantTablePrivillege(Statement Stm, boolean IsGrant, String User, String Database, String Table,
  boolean Select, boolean Insert, boolean Update, boolean Delete){
  boolean ret=true;
  boolean first;
  int result;
  String Grant=null;
  String To=null;
  StringBuilder Op;
  if(IsGrant){
   Grant="grant ";
   To=" to";
  }
  else{
   Grant="revoke ";
   To=" from";
  }
  result=1;
  if(!IsGrant){
   result=checkTablePrivillege(Stm, User, Database, Table, false, false, false, false);
  }
  if(result==1){
   Op=new StringBuilder();
   first=true;
   if(Select){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("select");
   }
   if(Insert){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("insert");
   }
   if(Update){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("update");
   }
   if(Delete){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("delete");
   }
   if(execUser(Stm, User, Grant+Op.toString()+" on "+Database+"."+Table+To, "")==0){ret=false;}
  }
  else if(result==-1){ret=false;}
  return ret;
 }
 private static boolean grantColumnsPrivillege(Statement Stm, boolean IsGrant, String User, String Database, String Table, String[] Columns,
  boolean Select, boolean Insert, boolean Update){
  boolean ret=true;
  boolean first;
  int result, temp;
  String Grant=null;
  String To=null;
  StringBuilder Op, Col1;
  String Col;
  String[] Columns_;
  if(IsGrant){
   Grant="grant ";
   To=" to";
  }
  else{
   Grant="revoke ";
   To=" from";
  }
   
  if(!IsGrant){
   Columns_=new String[1];
   temp=0;
   do{
    Columns_[0]=Columns[temp];
    result=checkColumnsPrivillege(Stm, User, Database, Table, Columns_, false, false, false);
    if(result==1){
     Op=new StringBuilder();
     first=true;
     if(Select){
      if(first){first=false;}
      else{Op=Op.append(",");}
      Op=Op.append("select ("+Columns[temp]+")");
     }
     if(Insert){
      if(first){first=false;}
      else{Op=Op.append(",");}
      Op=Op.append("insert ("+Columns[temp]+")");
     }
     if(Update){
      if(first){first=false;}
      else{Op=Op.append(",");}
      Op=Op.append("update ("+Columns[temp]+")");
     }
     if(execUser(Stm, User, Grant+Op.toString()+" on "+Database+"."+Table+To, "")==0){ret=false;}
    }
    else if(result==-1){ret=false;}
    temp=temp+1;
   }while(temp!=Columns.length);
  }
  else{
   Col1=new StringBuilder();
   Col1=Col1.append(Columns[0]);
   if(Columns.length!=1){
    temp=1;
    do{
     Col1=Col1.append(","+Columns[temp]);
     temp=temp+1;
    }while(temp!=Columns.length);
   }
   Col=Col1.toString();
   Op=new StringBuilder();
   first=true;
   if(Select){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("select ("+Col+")");
   }
   if(Insert){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("insert ("+Col+")");
   }
   if(Update){
    if(first){first=false;}
    else{Op=Op.append(",");}
    Op=Op.append("update ("+Col+")");
   }
   if(execUser(Stm, User, Grant+Op.toString()+" on "+Database+"."+Table+To, "")==0){ret=false;}
  }
  return ret;
 }
 private static boolean grantExecuteProcedure(Statement Stm, String User, boolean IsGrant, boolean IsProcedure, String Database, String Procedure){
  boolean ret=true;
  int result;
  String Grant=null;
  String To=null;
  String Proc=null;
  if(IsGrant){
   Grant="grant ";
   To=" to";
  }
  else{
   Grant="revoke ";
   To=" from";
  }
  if(IsProcedure){Proc="procedure ";}
  else{Proc="function ";}
  result=1;
  if(!IsGrant){
   result=checkProcPrivillege(Stm, IsProcedure, User, Database, Procedure);
  }
  if(result==1){ret=execUser(Stm, User, Grant+"execute on "+Proc+Database+"."+Procedure+To, "")!=0;}
  else if(result==-1){ret=false;}
  return ret;
 }

 private static int checkTablePrivillegeCommon(Statement Stm, String User, String Database, String Table,
  String[] PrivillegeName){
  int ret=0;
  int temp, count;
  String Priv;
  StringBuilder Con;
  
  Con=new StringBuilder();
  
  if(Table.charAt(0)!='*'){
   temp=0; count=PrivillegeName.length;
   do{
    Priv=PrivillegeName[temp];
    
    do{
     // if(PText.compare(Priv, CSQL.UserPriv_?????, false)){Con.append(" and find_in_set('?????', table_priv)<>0"); break;}
    }while(false);
    
    temp=temp+1;
   }while(temp!=count);
   
   ret=PDatabase.isQueryEmpty(Stm, "select user from mysql.tables_priv where lower(user)=lower('"+PSql.norm(User)+"') and lower(db)=lower('"+Database+"')"+
    " and lower(table_name)=lower('"+Table+"')"+Con, true);
  }
  else{
   temp=0; count=PrivillegeName.length;
   do{
    Priv=PrivillegeName[temp];
    
    do{
     if(PText.compare(Priv, CSQL.UserPriv_CreateTableTemp, false)){Con.append(" and create_tmp_table_priv='Y'"); break;}
    }while(false);
    
    temp=temp+1;
   }while(temp!=count);
   
   ret=PDatabase.isQueryEmpty(Stm, "select user from mysql.db where lower(user)=lower('"+PSql.norm(User)+"') and lower(db)=lower('"+Database+"')"+
    Con, true);
  }
  
  return ret;
 }
 private static int checkTablePrivillege(Statement Stm, String User, String Database, String Table,
  boolean SelectPriv, boolean InsertPriv, boolean UpdatePriv, boolean DeletePriv){
  int ret=0;
  String strSelect=null;
  String strInsert=null;
  String strUpdate=null;
  String strDelete=null;
  if(Table.charAt(0)!='*'){
   if(SelectPriv){strSelect=" and find_in_set('select', table_priv)<>0";}
   else{strSelect="";}
   if(InsertPriv){strInsert=" and find_in_set('insert', table_priv)<>0";}
   else{strInsert="";}
   if(UpdatePriv){strUpdate=" and find_in_set('update', table_priv)<>0";}
   else{strUpdate="";}
   if(DeletePriv){strDelete=" and find_in_set('delete', table_priv)<>0";}
   else{strDelete="";}
   ret=PDatabase.isQueryEmpty(Stm, "select user from mysql.tables_priv where lower(user)=lower('"+PSql.norm(User)+"') and lower(db)=lower('"+Database+"')"+
    " and lower(table_name)=lower('"+Table+"')"+strSelect+strInsert+strUpdate+strDelete, true);
  }
  else{
   if(SelectPriv){strSelect=" and select_priv='Y'";}
   else{strSelect="";}
   if(InsertPriv){strInsert=" and insert_priv='Y'";}
   else{strInsert="";}
   if(UpdatePriv){strUpdate=" and update_priv='Y'";}
   else{strUpdate="";}
   if(DeletePriv){strDelete=" and delete_priv='Y'";}
   else{strDelete="";}
   ret=PDatabase.isQueryEmpty(Stm, "select user from mysql.db where lower(user)=lower('"+PSql.norm(User)+"') and lower(db)=lower('"+Database+"')"+
    strSelect+strInsert+strUpdate+strDelete, true);
  }
  return ret;
 }
 private static int checkColumnsPrivillege(Statement Stm, String User, String Database, String Table, String[] Columns,
  boolean SelectPriv, boolean InsertPriv, boolean UpdatePriv){
  int ret=0;
  int temp;
  String strSelect=null;
  String strInsert=null;
  String strUpdate=null;
  if(SelectPriv){strSelect=" and find_in_set('select', column_priv)<>0";}
  else{strSelect="";}
  if(InsertPriv){strInsert=" and find_in_set('insert', column_priv)<>0";}
  else{strInsert="";}
  if(UpdatePriv){strUpdate=" and find_in_set('update', column_priv)<>0";}
  else{strUpdate="";}
  temp=0;
  do{
   ret=PDatabase.isQueryEmpty(Stm, "select user from mysql.columns_priv where lower(user)=lower('"+PSql.norm(User)+"') and lower(db)=lower('"+Database+"')"+
    " and lower(table_name)=lower('"+Table+"') and lower(column_name)=lower('"+Columns[temp]+"')"+strSelect+strInsert+strUpdate, true);
   if(ret!=1){break;}
   temp=temp+1;
  }while(temp!=Columns.length);
  return ret;
 }
 private static int checkProcPrivillege(Statement Stm, boolean IsProcedure, String User, String Database, String Procedure){
  String Proc=null;
  if(IsProcedure){Proc="'PROCEDURE'";}
  else{Proc="'FUNCTION'";}
  return PDatabase.isQueryEmpty(Stm, "select user from mysql.procs_priv where lower(user)=lower('"+PSql.norm(User)+"') and lower(db)=lower('"+Database+"')"+
   " and lower(routine_type)=lower("+Proc+") and lower(routine_name)=lower('"+Procedure+"')", true);
 }

 private static int execUser(Statement Stm, String User, String QueryBefore, String QueryAfter){
  int ret=0;
  try{
   Stm.execute(QueryBefore+" '"+PSql.norm(User)+"'@'localhost' "+QueryAfter);
   ret=ret+1;
  }catch(Exception E_){}
  try{
   Stm.execute(QueryBefore+" '"+PSql.norm(User)+"'@'%' "+QueryAfter);
   ret=ret+1;
  }catch(Exception E_){}
  return ret;
 }

}