import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.image.BufferedImage;
import java.util.Vector;

public abstract class OLabelCreator implements Cloneable {

 
 
 // info
 String Name;
 
 // internal papers
 Vector<OPaper> InternalPapers;
 int DefaultInternalPaper;
 OPaperMargin MgSt; // margin standard paper
 OPaperMargin MgTher; // margin thermal roll paper
 
 // data
 OLabelData LabelData;
 
 // layout
 boolean LayoutVariablesAlreadySet;
 
 double LabelWidth, LabelHeight;
 
 OPaperLabel Papr;
 boolean IsLabelRotated;
 
 OFont FontStandard; // used to calculate the point size of another custom font
 OFontLayout FontStandardIdealLayout;
 OFont FontCustom;
 
  // label's border
 double BorderWidth;
 
  // scaling
 double Scaling;
 
  // box
 double BoxWidth, BoxHeight;
 double BoxX, BoxY;
 double BoxWidthMin, BoxWidthMax;
 double BoxHeightMin, BoxHeightMax;
 double MarginHorizontal, MarginVertical;
 double AreaX, AreaY;
 double AreaWidth, AreaHeight;
 
 // scaled variables of box outside
 double Scaled_BoxX, Scaled_BoxY;
 double Scaled_LabelWidth, Scaled_LabelHeight;
 
  // text
 Font Fon;
 double TextAscent, TextDescent, TextHeight, TextWidth;
 double TextLineSpacing;
 int ColumnsCount, RowsCount;
 int ColumnsCountMin, ColumnsCountMax, RowsCountMin, RowsCountMax;
 
  // line
 double LineWidth;
 double SpaceToLine;
 
 
 
 
 
 // constructor
 public OLabelCreator(){}
 protected void init(
  OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  this.FontStandard=FontStandard;
  this.FontStandardIdealLayout=FontStandardIdealLayout;
  this.FontCustom=FontCustom;
  this.MgSt=MgSt;
  this.MgTher=MgTher;
  
  Name=getName();
  
  initLayoutVariables();
  
  InternalPapers=getInternalPapers();
  DefaultInternalPaper=getDefaultInternalPaper();
 }
 protected void initLayoutVariables(){
  initFontVariables();
  initDrawComponentsVariables();
 }
 protected void initFontVariables(){
  ODrawInfoString DrawStringInfo;
  
  Fon=PFont.getFont(FontCustom.FontFamily, (float)(FontCustom.getPointSize(FontStandard, FontStandardIdealLayout.PointSize)),
   FontStandardIdealLayout.IsBold, FontStandardIdealLayout.IsItalic);
  DrawStringInfo=PGraphics.getDrawInfoString(Fon);
  TextAscent=DrawStringInfo.LineAscent;
  TextDescent=DrawStringInfo.LineDescent;
  TextHeight=DrawStringInfo.LineHeight;
  TextWidth=DrawStringInfo.SingleCharWidth;
 }
 protected void initDrawComponentsVariables(){
  initMargin(OUnit.mm_to_pixel(0.7), OUnit.mm_to_pixel(0.7));
  BorderWidth=OUnit.mm_to_pixel(0.3);
  TextLineSpacing=OUnit.mm_to_pixel(0.1);
  LineWidth=OUnit.mm_to_pixel(0.3);
  SpaceToLine=OUnit.mm_to_pixel(0.7);
 }
 protected void initMargin(double MarginHorizontal, double MarginVertical){
  this.MarginHorizontal=MarginHorizontal;
  this.MarginVertical=MarginVertical;
 }
 // abstract
 protected abstract String getName();
 protected abstract Vector<OPaper> getInternalPapers();
 protected abstract int getDefaultInternalPaper();
 
 
 
 
 
 // change Paper & generate layout
 // after calling "set layout variables method (setPaper(), ...)", must calling generateLayoutVariables()
 public void setPaper(OPaperLabel Papr){this.Papr=Papr;}
 public boolean generateLayoutVariables(){
  LayoutVariablesAlreadySet=false;
  
  do{
   if(!acceptPaper(Papr)){break;}
   preGenLayoutVariables();
   preGen();
   if(!genLayoutVariables()){break;}
   postGen();
   postGenLayoutVariables();
   LayoutVariablesAlreadySet=true;
  }while(false);
  
  return LayoutVariablesAlreadySet;
 }
 public boolean acceptPaper(OPaperLabel Papr){
  boolean ret=false;
  ODimension PreferredSize;
  ODefMinMax WidthRange, HeightRange;
  
  do{
   if(Papr==null){break;}
   if(!Papr.IsCustomPaperLabel){return true;}
   if(!supportCustomPaperLabel()){break;}
   PreferredSize=PGraphics.getDimensionInOrientation(getDefaultOrientation(), Papr.LabelWidth, Papr.LabelHeight);
   WidthRange=getLabelWidthRange(); HeightRange=getLabelHeightRange();
   if(PreferredSize.Width<WidthRange.Minimal || PreferredSize.Width>WidthRange.Maximal){break;}
   if(PreferredSize.Height<HeightRange.Minimal || PreferredSize.Height>HeightRange.Maximal){break;}
   ret=true;
  }while(false);
  
  return ret;
 }
 // Pre-Gen
 protected void preGenLayoutVariables(){}
 private void preGen(){
  initLabelSize();
 }
 private void initLabelSize(){
  IsLabelRotated=isLabelRotated();
  if(!IsLabelRotated){setLabelSize(Papr.LabelWidth, Papr.LabelHeight);}
  else{setLabelSize(Papr.LabelHeight, Papr.LabelWidth);}
 }
 private boolean isLabelRotated(){
  boolean ret;
  if(!Papr.IsCustomPaperLabel && defineInternalPaperLabelRotationManually()){
   ret=isLabelRotatedInternalPaper();
  }
  else{
   ret=PGraphics.isRotated(getDefaultOrientation(), Papr.LabelWidth, Papr.LabelHeight);
  }
  return ret;
 }
 private void setLabelSize(double LabelWidth, double LabelHeight){
  this.LabelWidth=LabelWidth;
  this.LabelHeight=LabelHeight;
 }
 // Post-Gen
 private void postGen(){
  initArea();
  initBoxScaleAndOffset();
 }
 private void initArea(){
  AreaX=MarginHorizontal;
  AreaY=MarginVertical;
  AreaWidth=BoxWidth-2*MarginHorizontal;
  AreaHeight=BoxHeight-2*MarginVertical;
 }
 private void initBoxScaleAndOffset(){
  OCoordinate scale_size;
  if(!scaleBoxToFitWithLabel()){
   Scaling=1;
   BoxX=(LabelWidth-BoxWidth)/2;
   BoxY=(LabelHeight-BoxHeight)/2;
  }
  else{
   scale_size=PGraphics.calculateCoordinate(LabelWidth, LabelHeight, BoxWidth, BoxHeight, 1, CGraph.Rotate_000Degree, true, true, null, false, false);
   Scaling=scale_size.Width/BoxWidth;
   BoxX=scale_size.OffsetX;
   BoxY=scale_size.OffsetY;
  }
 }
 protected void postGenLayoutVariables(){}
 // abstract
 protected abstract boolean supportCustomPaperLabel();
 protected abstract int getDefaultOrientation();
 protected abstract ODefMinMax getLabelWidthRange();
 protected abstract ODefMinMax getLabelHeightRange();
 protected abstract boolean defineInternalPaperLabelRotationManually();
 protected abstract boolean isLabelRotatedInternalPaper();
 protected abstract boolean genLayoutVariables();
 protected abstract boolean scaleBoxToFitWithLabel();
 
 
 
 
 
 // set label's data
 public void setLabelData(OLabelData Data){this.LabelData=Data;}
 
 
 
 
 
 // create image
 public BufferedImage createBufferedImage(double ScaleFactor){
  BufferedImage ret;
  Graphics2D g;
  Stroke strok;
  
  if(!LayoutVariablesAlreadySet || LabelData==null){return null;}
  
  // create BufferedImage
  ret=new BufferedImage(PMath.roundCustom(ScaleFactor*LabelWidth, 0.2), PMath.roundCustom(ScaleFactor*LabelHeight, 0.2), BufferedImage.TYPE_INT_RGB);
  g=ret.createGraphics();
  g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
  g.setBackground(CGUI.White);
  g.clearRect(0, 0, ret.getWidth(), ret.getHeight());
  g.setColor(CGUI.Black);
  
  if(Papr.DrawCutLine){
   strok=g.getStroke();
   g.setStroke(new BasicStroke((float)(BorderWidth*ScaleFactor)));
   g.drawRect(0, 0, PMath.round(ret.getWidth(), 0), PMath.round(ret.getHeight(), 0));
   g.setStroke(strok);
  }
  
  g.scale(ScaleFactor, ScaleFactor);
  
  g.scale(Scaling, Scaling);
  scalingVariablesOfOutsideBox();
  
  draw(g, ScaleFactor);
  
  return ret;
 }
 private void scalingVariablesOfOutsideBox(){
  double ScalingToBox=(1/Scaling);
  
  Scaled_BoxX=ScalingToBox*BoxX;
  Scaled_BoxY=ScalingToBox*BoxY;
  Scaled_LabelWidth=ScalingToBox*LabelWidth;
  Scaled_LabelHeight=ScalingToBox*LabelHeight;
 }
 // abstract
 protected abstract void draw(Graphics2D g, double AlreadyScaled);
 
 
 
 
 
 // etc
 public Object clone() throws CloneNotSupportedException{return super.clone();}

 
 
 
 
}