public class OScaleFactor {
 
 double X;
 double Y;

 public OScaleFactor() {}
 public OScaleFactor(double X, double Y) {
  this.X = X;
  this.Y = Y;
 }
 
}