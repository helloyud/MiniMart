public class OCalculation {
 
 OCalculationOperand SecondOperand;
 int MathOperation;
	boolean IsChangeNegativeResult;
	double ChangeNegativeResult;
 
 OCalculation Next;

 public OCalculation(OCalculationOperand SecondOperand, int MathOperation,
		boolean IsChangeNegativeResult, double ChangeNegativeResult) {
  this.SecondOperand = SecondOperand;
  this.MathOperation = MathOperation;
		this.IsChangeNegativeResult=IsChangeNegativeResult;
		this.ChangeNegativeResult=ChangeNegativeResult;
  Next=null;
 }
 
 public void calculateResultFromChainedCalculation(OCalculationResult Result, OCalculationOperand FirstOperand,
  int TableRowIndex){
  double result;
  SecondOperand.setTableRowIndex(TableRowIndex);
  result=PMath.calculate(FirstOperand.getOperand(), SecondOperand.getOperand(), MathOperation, IsChangeNegativeResult, ChangeNegativeResult);
  
  if(Next==null){Result.Result=result; return;}
  
  Next.calculateResultFromChainedCalculation(Result, new OCalculationOperandConstanta(result), TableRowIndex);
 }
 
 public OCalculation nextCalculation(OCalculation NextCalculation){
  Next=NextCalculation;
  return this;
 }
 
}