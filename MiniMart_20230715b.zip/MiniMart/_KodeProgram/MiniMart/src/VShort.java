public class VShort {

 short Value;

 public VShort() {}
 public VShort(short Value) {this.Value = Value;}

}