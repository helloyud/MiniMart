import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;

public class OActionKeyFocusCustom extends OActionKey {
 
 Object[] DestCmps;
 
 public OActionKeyFocusCustom(){}
 public OActionKeyFocusCustom(Object[] DestCmps) {
  init(DestCmps);
 }
 public OActionKeyFocusCustom(
  Window Form, Component Cmp, KeyEvent evt,
  Object[] DestCmps) {
  
  init(Form, Cmp, evt, DestCmps);
 
 }
 
 OActionKeyFocusCustom init(Object[] DestCmps){
  this.DestCmps = DestCmps;
  return this;
 }
 OActionKeyFocusCustom init(
  Window Form, Component Cmp, KeyEvent evt,
  Object[] DestCmps){
  
  init(Form, Cmp, evt);
  init(DestCmps);
  
  return this;
 }
 
 public int doAction() {
  int ret=CNav.Ret_Unconsumed;
  
  if(PGUI.requestFocusInWindow(DestCmps)){ret=CNav.Ret_Consumed;}
  
  return ret;
 }
 
}