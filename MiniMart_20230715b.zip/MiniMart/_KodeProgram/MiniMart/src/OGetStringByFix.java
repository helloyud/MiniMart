public class OGetStringByFix extends OGetString {
 
 String Prefix, Postfix;
 
 public OGetStringByFix(String Prefix, String Postfix){
  this.Prefix=Prefix; this.Postfix=Postfix;
 }
 
 public String getString(String Word){
  return PText.getString(Word, "", PText.getString(Prefix, "", true)+Word+(PText.getString(Postfix, "", true)), true);
 }
 
}