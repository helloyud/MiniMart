import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_OrderModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 int wMode; // 0 Add_new, 1 edit
 long wItemId;
 
 // get
  // Item
 boolean RecheckId;
 long CheckedId, I_CheckedId;
 OInfoItem ItemInfo, I_ItemInfo;
 boolean InputInfoClearedItem;
 
  // Unit
 OCustomComboBoxModel ComboMdlUnit;
 int LastSelectedRowUnit;
 boolean UnitCleared;
 boolean InputInfoClearedQty;
 
 OInfoItemStockUnit ItemUnit;
 OInfoItemStockUnit LastItemUnit;
 
  // Qty
 double Qty, I_Qty;
 
  // Price
 double PriceUnit, I_PriceUnit;
 double PriceTotal, I_PriceTotal;
 
 //
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 
 public F_OrderModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  I_ItemInfo=new OInfoItem();
  
  ComboMdlUnit=new OCustomComboBoxModel();
  ComboMdlUnit.setColumnsInfo(PCore.primArr(CCore.TypeString, CCore.TypeUnknown), 0);
  CmB_Unit.setModel(ComboMdlUnit);
  LastSelectedRowUnit=-1;
  
  EnableDocumentListener=new VBoolean(true);
  
  TF_ItemId.setToolTipText("{F6} ket brg, {Spasi} cari brg, {Enter} tbh brg, {Down} ubah qty & hrg");
  TF_ItemId.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    
   });
  TF_Quantity.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    
   });
  EnableDocumentListener.Value=true;
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  InputInfoClearedItem=true;
  InputInfoClearedQty=true;
 }
 
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearInputItem();
  LastItemUnit=null;
 }
 
 // Input Item Methods
  // Item
 void inputItem(){
  if(!changeItemMetadata()){return;}
  afterChangeItemMetadata();
 }
 boolean changeItemMetadata(){
  boolean ret=false;
  OInfoItem InfoItem;
  
  do{
   // Parse TF_ItemId
   try{I_CheckedId=Long.parseLong(TF_ItemId.getText());}catch(Exception E){break;}
   
   // Check if Item is exist in database
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId); if(InfoItem==null){break;}
   
   // init input-item's non-gui variables
   I_ItemInfo=InfoItem;
   fillUnit(LastItemUnit, false);
   changeItemQuantityPrice();
   
   ret=true;
  }while(false);
  
  if(!ret){I_CheckedId=-1; clearItem();}
  
  RecheckId=false;
  
  return ret;
 }
 void afterChangeItemMetadata(){
  // init input-item's gui variables
  setIQty(I_Qty, false);
  setIPriceUnit(I_PriceUnit, false);
  setIPriceTotal(I_PriceTotal, false);
  
  fillInputInfoItem();
  fillInputInfoQty();
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
  I_PriceUnit=ItemUnit.Qty*I_ItemInfo.BuyPriceEstimation;
  I_PriceTotal=I_Qty*I_PriceUnit;
 }
 void fillInputInfoItem(){
  if(I_CheckedId==-1){clearInputInfoItem(); return;}
  
  TA_ItemName.setText(I_ItemInfo.Name);
  CB_ItemUpStock.setSelected(I_ItemInfo.UpdateStock);
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  PGUI.clearText(TA_ItemName);
  CB_ItemUpStock.setSelected(false);
  
  InputInfoClearedItem=true;
 }
 void clearItem(){
  clearInputInfoItem();
  
  clearUnit();
  clearInputInfoQty();
 }
 void focusItem(){
  PGUI.requestFocusInWindow(TF_ItemId);
 }
  // Unit
 void onSelectedRowChangedUnit(boolean UpdateAnyway, boolean UpdateGUI){
  int row=CmB_Unit.getSelectedIndex();
  
  if(!(LastSelectedRowUnit!=row || UpdateAnyway)){return;}
  
  LastSelectedRowUnit=row;
  
  if(row==-1){ItemUnit=null;}else{ItemUnit=(OInfoItemStockUnit)ComboMdlUnit.Mdl.Rows.elementAt(row)[1];}
  
  LastItemUnit=ItemUnit;
  
  if(row!=-1){
   setIPriceUnit(ItemUnit.Qty*I_ItemInfo.BuyPriceEstimation, false);
   
   if(I_Qty>0){setIPriceTotal(I_Qty*I_PriceUnit, false);}
  }
  
  if(UpdateGUI){
   fillInputInfoQty();
  }
 }
 void setUnit(int Row, boolean UpdateGUI){
  PGUI.changeDocument(EnableDocumentListener, CmB_Unit, Row); onSelectedRowChangedUnit(true, UpdateGUI);
 }
 void setUnit(OInfoItemStockUnit AUnit, boolean UpdateGUI){
  int row;
  
  row=PGUI.findData(ComboMdlUnit, 1, AUnit); if(row==-1){row=0;}
  setUnit(row, UpdateGUI);
 }
 void fillUnit(OInfoItemStockUnit InitUnit_AUnit, boolean InitUnit_UpdateGUI){
  Vector<Object[]> Units;
  
  clearUnit();
  
  Units=PMyShop.getListForComboBox_InfoItemUnits(IFV.Stm, false, I_ItemInfo, true, true);
  ComboMdlUnit.append(Units);
  
  setUnit(InitUnit_AUnit, InitUnit_UpdateGUI);
  
  UnitCleared=false;
 }
 void clearUnit(){
  if(UnitCleared){return;}
  
  ComboMdlUnit.removeAll(); LastSelectedRowUnit=-1; PGUI.changeDocument(EnableDocumentListener, CmB_Unit, -1);
  
  UnitCleared=true;
 }
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, "");}}
 }
 void inputQuantity(){
  I_Qty=PText.parseDouble(TF_Quantity.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}

  fillInputInfoQty();
  
  if(I_Qty<=0){return;}
  
  if(I_PriceUnit>=0){setIPriceTotal(I_Qty*I_PriceUnit, false);}
 }
 void focusQty(){
  PGUI.requestFocusInWindow(TF_Quantity);
 }
  // Unit & Qty
 void fillInputInfoQty(){
  String str=null;
  double US_Qty; // unit standard's quantity
  
  if(I_CheckedId==-1 || I_Qty<=0){clearInputInfoQty(); return;}
  
  US_Qty=I_Qty*ItemUnit.Qty;
  str="( "+PText.priceToString(US_Qty)+PText.getString(I_ItemInfo.StockUnit, -1, " "+I_ItemInfo.StockUnitName, "")+" )";
  
  TF_AddInfoQty.setText(PText.getString(str, "", false));
  
  InputInfoClearedQty=false;
 }
 void clearInputInfoQty(){
  if(InputInfoClearedQty){return;}
  
  PGUI.clearText(TF_AddInfoQty);
  
  InputInfoClearedQty=true;
 }
  // Price
 void setIPriceUnit(double Value, boolean ClearInvalidValue){
  I_PriceUnit=Value;
  
  if(I_PriceUnit>=0){PGUI.changeDocument(EnableDocumentListener, TF_PriceUnit, PText.doubleToString(I_PriceUnit, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_PriceUnit, "");}}
 }
 void setIPriceTotal(double Value, boolean ClearInvalidValue){
  I_PriceTotal=Value;
  
  if(I_PriceTotal>=0){PGUI.changeDocument(EnableDocumentListener, TF_PriceTotal, PText.doubleToString(I_PriceTotal, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_PriceTotal, "");}}
 }
  // Others
 void fillInputVariablesIntoRealVariables(){
  CheckedId=I_CheckedId;
  ItemInfo=I_ItemInfo;
  
  Qty=I_Qty*ItemUnit.Qty;
  PriceTotal=I_PriceTotal;
  PriceUnit=PriceTotal/Qty;
 }
 void clearInputItem(){
  EnableDocumentListener.Value=false;
  
  TF_ItemId.setText(""); I_CheckedId=-1; RecheckId=false; clearItem();
  setIQty(-1, true);
  setIPriceUnit(-1, true);
  setIPriceTotal(-1, true);
  
  EnableDocumentListener.Value=true;
 }
 void changeDocument(JTextField TF, String Str){
  EnableDocumentListener.Value=false;
  TF.setText(Str);
  EnableDocumentListener.Value=true;
 }
 void focus(JTextField TF){
  TF.requestFocusInWindow();
 }
 void enableItemIdEdit(boolean Enable){
  TF_ItemId.setEditable(Enable);
  if(Enable){TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOff);}
  else{TF_ItemId.setBackground(CGUI.Color_TextBox_Uneditable);}
  Btn_ChooseItem.setEnabled(Enable);
 }
 
 //
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_PriceUnit = new javax.swing.JTextField();
  TF_PriceTotal = new javax.swing.JTextField();
  Lbl_ItemName = new javax.swing.JLabel();
  Lbl_ItemId = new javax.swing.JLabel();
  TF_Quantity = new javax.swing.JTextField();
  Lbl_Quantity = new javax.swing.JLabel();
  TF_ItemId = new javax.swing.JTextField();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  TF_AddInfoQty = new javax.swing.JTextField();
  CB_ItemUpStock = new javax.swing.JCheckBox();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Btn_ChooseItem = new javax.swing.JButton();
  jLabel1 = new javax.swing.JLabel();
  jLabel4 = new javax.swing.JLabel();
  CmB_Unit = new javax.swing.JComboBox<>();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_PriceUnit.setEditable(false);
  TF_PriceUnit.setBackground(new java.awt.Color(204, 255, 204));
  TF_PriceUnit.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_PriceUnit.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_PriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  TF_PriceUnit.setNextFocusableComponent(TF_PriceTotal);

  TF_PriceTotal.setEditable(false);
  TF_PriceTotal.setBackground(new java.awt.Color(204, 255, 204));
  TF_PriceTotal.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_PriceTotal.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_PriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  TF_PriceTotal.setNextFocusableComponent(Btn_Ok);

  Lbl_ItemName.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_ItemName.setText("- Nama");
  Lbl_ItemName.setRequestFocusEnabled(false);

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Barang");
  Lbl_ItemId.setRequestFocusEnabled(false);

  TF_Quantity.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_Quantity.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_Quantity.setMargin(new java.awt.Insets(0, 0, 0, 0));
  TF_Quantity.setNextFocusableComponent(TF_PriceUnit);
  TF_Quantity.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusLost(evt);
   }
  });
  TF_Quantity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QuantityKeyPressed(evt);
   }
  });

  Lbl_Quantity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Quantity.setText("Kuantitas Order");

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_ItemId.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_ItemId.setToolTipText("");
  TF_ItemId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  TF_ItemId.setNextFocusableComponent(TF_Quantity);
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(20);
  TA_ItemName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setWrapStyleWord(true);
  jScrollPane1.setViewportView(TA_ItemName);

  TF_AddInfoQty.setEditable(false);
  TF_AddInfoQty.setBackground(new java.awt.Color(204, 255, 204));
  TF_AddInfoQty.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_AddInfoQty.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_AddInfoQty.setToolTipText("");

  CB_ItemUpStock.setText("Dibarui");
  CB_ItemUpStock.setToolTipText("Pembaruan Stok Saat Transaksi");
  CB_ItemUpStock.setEnabled(false);
  CB_ItemUpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemUpStock.setRequestFocusEnabled(false);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_Cancel.setNextFocusableComponent(TF_ItemId);
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_Ok.setNextFocusableComponent(Btn_Cancel);
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setToolTipText("Pilih sebuah barang");
  Btn_ChooseItem.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("Kis. Hrg Beli / Unit");

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("Kis. Hrg Beli Total");

  CmB_Unit.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  CmB_Unit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_UnitActionPerformed(evt);
   }
  });
  CmB_Unit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_UnitKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_ItemId)
       .addComponent(Lbl_ItemName)
       .addComponent(Lbl_Quantity)
       .addComponent(jLabel1)
       .addComponent(jLabel4))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jScrollPane1)
       .addComponent(TF_PriceUnit)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_ItemId)
        .addGap(0, 0, 0)
        .addComponent(Btn_ChooseItem))
       .addComponent(TF_PriceTotal, javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(layout.createSequentialGroup()
          .addComponent(TF_AddInfoQty)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(CB_ItemUpStock))
         .addComponent(CmB_Unit, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE))))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_ItemId)
     .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ChooseItem))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_ItemName)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(Lbl_Quantity)
       .addComponent(TF_AddInfoQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(CB_ItemUpStock))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_Unit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(TF_Quantity))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PriceUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PriceTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel4))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  if(RecheckId){changeItemMetadata();}
  if(I_CheckedId!=-1 && I_Qty>0){
   fillInputVariablesIntoRealVariables();
   closingForm(1);
   setVisible(false);
  }
  else{
   JOptionPane.showMessageDialog(null, "Masukan belum benar !"+
    "\nSilahkan periksa kembali !");
  }
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  closingForm(0);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  OInfoItem InfoItem;
  
  if(Activ){return;}
  
  Activ=true;
  
  I_CheckedId=-1; RecheckId=false;
  I_Qty=-1;
  I_PriceUnit=-1;
  I_PriceTotal=-1;
  
  if(wMode==0){
   setTitle("Tambah Data Order Baru");
   enableItemIdEdit(true);
   
   TF_ItemId.requestFocusInWindow();
  }
  else{
   setTitle("Ubah Data Order");
   enableItemIdEdit(false);
   
   EnableDocumentListener.Value=false;
   
   I_CheckedId=wItemId; RecheckId=false;
   
   TF_ItemId.setText(String.valueOf(I_CheckedId));
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId); if(InfoItem==null){InfoItem=new OInfoItem();}
   I_ItemInfo=InfoItem;
   
   fillUnit(null, false);
   
   if(I_ItemInfo.OrderQuantity>0){I_Qty=I_ItemInfo.OrderQuantity;}
   I_PriceUnit=ItemUnit.Qty*I_ItemInfo.BuyPriceEstimation;
   I_PriceTotal=I_Qty*I_PriceUnit;
   
   setIQty(I_Qty, false);
   setIPriceUnit(I_PriceUnit, false);
   setIPriceTotal(I_PriceTotal, false);

   fillInputInfoItem();
   fillInputInfoQty();
   
   EnableDocumentListener.Value=true;
   
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  if(Activ && RecheckId){inputItem();}
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : case KeyEvent.VK_DOWN :
    if(wMode==0){
     if(Activ && RecheckId){inputItem();}
     focus(TF_Quantity);
    }
    break;
   case KeyEvent.VK_F6 :
    if(wMode==0){
     if(RecheckId){inputItem();}
    }
    break;
   case KeyEvent.VK_SPACE :
    evt.consume();
    if(wMode==0){Btn_ChooseItemActionPerformed(null);}
    break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void TF_QuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QuantityKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_Ok.requestFocusInWindow(); break;
   case KeyEvent.VK_DOWN : Btn_Ok.requestFocusInWindow(); break;
   case KeyEvent.VK_UP : if(TF_ItemId.isEditable()){focus(TF_ItemId);} break;
   case KeyEvent.VK_RIGHT : PGUI.requestFocusInWindow(CmB_Unit); break;
  }
 }//GEN-LAST:event_TF_QuantityKeyPressed

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  if(!Btn_ChooseItem.isEnabled()){return;}
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult==1){
   // change ItemInfo's variables directly from FItem
   I_CheckedId=IFV.FItem.ChoosedId[0];
   changeDocument(TF_ItemId, String.valueOf(I_CheckedId));
   inputItem();
   
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void TF_QuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusGained
  DocumentListenerFocus=1;
  TF_Quantity.selectAll();
 }//GEN-LAST:event_TF_QuantityFocusGained

 private void TF_QuantityFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_QuantityFocusLost

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP :
    TF_Quantity.requestFocusInWindow();
    break;
   case KeyEvent.VK_ENTER :
    Btn_OkActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT :
    Btn_Cancel.requestFocusInWindow();
    break;
  }
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP :
    TF_Quantity.requestFocusInWindow();
    break;
   case KeyEvent.VK_ENTER :
    Btn_CancelActionPerformed(null);
    break;
   case KeyEvent.VK_LEFT :
    Btn_Ok.requestFocusInWindow();
    break;
  }
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  if(TF_ItemId.isEditable()){TF_ItemId.selectAll();}
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void CmB_UnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_UnitActionPerformed
  if(!EnableDocumentListener.Value){return;}
  
  onSelectedRowChangedUnit(false, true);
 }//GEN-LAST:event_CmB_UnitActionPerformed

 private void CmB_UnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_UnitKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : PGUI.requestFocusInWindow(TF_Quantity); break;
  }
 }//GEN-LAST:event_CmB_UnitKeyPressed


 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_ItemUpStock;
 private javax.swing.JComboBox<String> CmB_Unit;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_ItemName;
 private javax.swing.JLabel Lbl_Quantity;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextField TF_AddInfoQty;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_PriceTotal;
 private javax.swing.JTextField TF_PriceUnit;
 private javax.swing.JTextField TF_Quantity;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
