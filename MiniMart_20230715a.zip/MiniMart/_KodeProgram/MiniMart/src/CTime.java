

public class CTime {
	
 static String[] Month=
  {"Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
   "Jul", "Agu", "Sep", "Okt", "Nop", "Des"};
	
 final static String YearSpell="Tahun";
 final static String MonthSpell="Bulan";
 final static String DaySpell="Hari";
 
 final static String YearSpellShort="Th";
 final static String MonthSpellShort="Bl";
 final static String DaySpellShort="Hr";

 final static long BeginDayInMillis=59400000L; // 1970-Jan-02, 00.00.00.000
 final static long OneDayMillis=24L*60L*60L*1000L;

}