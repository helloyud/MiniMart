public class OIdName {
 long Id;
 String Name;
}
