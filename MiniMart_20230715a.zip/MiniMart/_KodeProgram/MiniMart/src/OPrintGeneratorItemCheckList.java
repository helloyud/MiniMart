import java.sql.Statement;
import java.util.Date;
import java.util.LinkedList;

public class OPrintGeneratorItemCheckList extends OPrintGenerator {
 
 // additional printing properties
 LinkedList<Long> ItemsId;
 boolean ShowBuyPrice;
 boolean OptVariants;
 boolean OptIsActive;
 boolean OptIsStockUpdated;
 boolean OptStock;
 boolean OptStockPre;
 boolean OptStockEst;
 boolean OptStockMinMax;
 boolean OptIsOpname;
 boolean OptIsReorder;
 boolean OptOrderMinPack;
 boolean OptOrderEachPackQty;
 boolean OptOrderEachPackThreshold;
 boolean OptIsExpire;
 boolean OptExpCheckPeriod;
 boolean OptExpThreshold;
 boolean OptExpThresholdDate;
 boolean OptSellPrice;
	boolean OptSellComment;
 boolean OptSellUpdate;
 boolean OptBuyPriceEst;
	boolean OptBuyComment;
 boolean OptBuyUpdate;
	boolean OptComment;
 boolean OptOpnameStock;
 boolean OptOpnameExp;
 boolean OptOrderQty;
 boolean OptOrderPriceEst;
 LinkedList<OIdName> ItemsCategory;
 String ItemsIdQ;
 OQuickListOfLong PrintedId;
 
 int CategoryCount;
 OIdName CurrCategory;
 String CurrItemName;
 long CurrItemId;
	String CurrItemText;
	ODrawTableRow TableNewRow;
 ODrawTable Table;
 boolean CurrCategoryHeaderPrint;
	
	String QueryCondition;
 String QueryAdditionalTable;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 double CategoryAddLineSpacing, TableAddLineSpacing;
	final int CheckListMinColumnsCount=2;
	final double CellAreaMinHeight=OUnit.mm_to_pixel(6);
 
 OPrintGeneratorItemCheckList(OFont FontStandard){super(FontStandard);}
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> ItemsId,
  int ColumnarCount, boolean ShowBuyPrice,
  boolean OptVariants, boolean OptIsActive,
  boolean OptIsStockUpdated, boolean OptStock, boolean OptStockPre, boolean OptStockEst, boolean OptStockMinMax,
  boolean OptIsOpname, boolean OptIsReorder, boolean OptOrderMinPack, boolean OptOrderEachPackQty, boolean OptOrderEachPackThreshold,
		boolean OptIsExpire, boolean OptExpCheckPeriod, boolean OptExpThreshold, boolean OptExpThresholdDate,
		boolean OptSellPrice, boolean OptSellPriceComment, boolean OptSellUpdate, boolean OptBuyPriceEst, boolean OptBuyPriceComment, boolean OptBuyUpdate,
		boolean OptComment,
  boolean OptOpnameStock, boolean OptOpnameExp,
  boolean OptOrderQty, boolean OptOrderPriceEst){
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.ItemsId=ItemsId;
		this.ColumnarCount=ColumnarCount;
  this.ShowBuyPrice=ShowBuyPrice;
  this.OptVariants=OptVariants;
  this.OptIsActive=OptIsActive;
  this.OptIsStockUpdated=OptIsStockUpdated;
		this.OptStock=OptStock;
		this.OptStockPre=OptStockPre;
		this.OptStockEst=OptStockEst;
  this.OptStockMinMax=OptStockMinMax;
  this.OptIsOpname=OptIsOpname;
  this.OptIsReorder=OptIsReorder;
  this.OptOrderMinPack=OptOrderMinPack;
  this.OptOrderEachPackQty=OptOrderEachPackQty;
  this.OptOrderEachPackThreshold=OptOrderEachPackThreshold;
  this.OptIsExpire=OptIsExpire;
  this.OptExpCheckPeriod=OptExpCheckPeriod;
  this.OptExpThreshold=OptExpThreshold;
		this.OptExpThresholdDate=OptExpThresholdDate;
  this.OptSellPrice=OptSellPrice;
		this.OptSellComment=OptSellPriceComment;
  this.OptSellUpdate=OptSellUpdate;
  this.OptBuyPriceEst=OptBuyPriceEst;
		this.OptBuyComment=OptBuyPriceComment;
  this.OptBuyUpdate=OptBuyUpdate;
		this.OptComment=OptComment;
  this.OptOpnameStock=OptOpnameStock;
  this.OptOpnameExp=OptOpnameExp;
  this.OptOrderQty=OptOrderQty;
  this.OptOrderPriceEst=OptOrderPriceEst;
 }
 
 // standard private methods
	protected  boolean isMultiColumnar(){return true;}
	protected boolean drawColumnarSeparator(){return false;}
	protected boolean hasHeader(){return false;}
 protected boolean hasFooter(){return true;}
 protected boolean checkLastUsedLayout(){return false;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.5f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(7.5f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  int temp;
  double ColWidthItem, ColWidthCheckList;
	 int CheckListColumnsCount;
  ODrawTableColumnMetadata[] Columns;
  OInset ContentInset;
  
  CategoryAddLineSpacing=7;
  TableAddLineSpacing=3;
  
  ContentInset=new OInset(OUnit.mm_to_pixel(0.7),
   OUnit.mm_to_pixel(0.7), OUnit.mm_to_pixel(1.1), OUnit.mm_to_pixel(1.1));
  
  ColWidthItem=0.375*OrientedPaprImageableWidth;
  ColWidthCheckList=OUnit.mm_to_pixel(10);
  CheckListColumnsCount=(int)((ColumnarWidth-ColWidthItem)/ColWidthCheckList);
		if(CheckListColumnsCount<CheckListMinColumnsCount){CheckListColumnsCount=CheckListMinColumnsCount;}
  ColWidthItem=ColumnarWidth-(CheckListColumnsCount*ColWidthCheckList);
		if(ColWidthItem<=0){throw new Exception();}
  
  Columns=new ODrawTableColumnMetadata[1+CheckListColumnsCount];
  Columns[0]=new ODrawTableColumnMetadata("Barang", ColWidthItem);
  temp=0;
  do{
   Columns[1+temp]=new ODrawTableColumnMetadata(null, ColWidthCheckList);
   temp=temp+1;
  }while(temp!=CheckListColumnsCount);
  
  // create an empty table for simulating purpose
  Table=new ODrawTable(Columns, ContentInset, ODrawTableBorder.DefaultFillAll);
 }
 protected void prepareFirstPageData() throws Exception{
  PrintedId=new OQuickListOfLong(1024, 1024, true, true);
  saveItemsId();
  saveItemsCategory();
  if(!getNextCategory()){throw new Exception();}
  if(!getItemsFromCurrCategory()){throw new Exception();}
 }
 protected void addHeader() throws Exception{}
 protected boolean addColumnar() throws Exception{
  boolean ret=true;
		boolean KeepPrinting=true;
  boolean IsOverPage, ThereIs;
  double temp;
  ODrawTable tbl;
  
		do{
   // print curr item
   if(CurrCategoryHeaderPrint){
    if(IsANewColumnar){IsANewColumnar=false;}
    else{CurrY=CurrY+CategoryAddLineSpacing;}
    PText.refillChars(Txt, ' ');
    PText.fillStringToChars(Txt, PText.fitString("+ "+CurrCategory.Name, ColumnarColumnCount, true, ColumnarColumnCount-1, 1, '~'), 0, 1);
    DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
    CurrY=CurrY+NormalHeight;
    
    CurrCategoryHeaderPrint=false;
   }
   
   // print a table
   if(IsANewColumnar){IsANewColumnar=false;}
   else{CurrY=CurrY+TableAddLineSpacing;}
   tbl=Table.createNewTable();
   IsOverPage=false;
   do{
    tbl.insertARow(tbl.Rows.size(), TableNewRow);
    
    if(!getNextItemFromResultSet()){break;}
    if(checkOverColumnarHeight(tbl.Height+TableNewRow.Height)){IsOverPage=true; break;}
   }while(KeepPrinting);
   DrawComponents.add(new ODrawComponentTable(BaseX, BaseY+CurrY, tbl));
   if(IsOverPage){break;}
   CurrY=CurrY+tbl.Height;
   
   // searching if there is any category that has an item that haven't been printed
   ThereIs=true;
   do{
    if(!getNextCategory()){ThereIs=false; break;}
    if(getItemsFromCurrCategory()){break;}
   }while(ThereIs);
   if(!ThereIs){CurrItemName=null; ret=false; break;}
   
   temp=CategoryAddLineSpacing+NormalHeight+TableAddLineSpacing+TableNewRow.Height;
   if(checkOverColumnarHeight(temp)){break;}
   
  }while(KeepPrinting);
		return ret;
 }
 protected void addFooter() throws Exception{
  String FooterStr=null;
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  FooterStr="Hal. "+CurrPage;
  PText.fillStringToChars(TxtPage, FooterStr, PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  boolean ret=true;
  do{
   // prepare print data for next page
   if(CurrItemName==null){ret=false; break;}
  }while(false);
  return ret;
 }
 protected void clearVar(){
  ItemsId=null;
  ItemsCategory=null;
  CurrCategory=null;
  CurrItemName=null;
  ItemsIdQ=null;
  PrintedId=null;
  CurrItemText=null;
  TableNewRow=null;
 }
 
 // additional private methods
	String getQuery(){
		return
   "select tb4.*, Sum(PreTransXItemOut.Stock) as 'PreStockOut' from "+
				"(select tb3.*, Sum(PreTransXItemIn.Stock) as 'PreStockIn' from "+
     "(select tb2.*, Group_Concat(Variant Order By Variant asc Separator ', ') as 'Variants' from "+
      "(select tb1.*, StockUnit.Name as 'StockUnitName' from "+
       "(select Name, Id, IsActive, "+
        "UpdateStockOnTransaction, StockUnit, Stock, MinimalStock, MaximalStock, IsOpname, IsReorder, OrderMinPack, OrderEachPackQty, OrderEachPackThreshold, "+
        "SellPrice, SellPriceComment, SellUpdate, BuyPriceEstimation, BuyPriceComment, BuyUpdate, Comment, "+
        "HasExpireDate, ExpireCheckPeriod, ExpireThreshold, if(ExpireThreshold is "+CCore.vNull+", "+CCore.vNull+", Date_Add(CurDate(), Interval ifnull(ExpireThreshold, 0) Day)), "+
        "OpnameStock, OpnameExpire, OrderQuantity from Item"+QueryAdditionalTable+" where "+QueryCondition+") as tb1 "+
      "left join StockUnit on tb1.StockUnit=StockUnit.Id) as tb2 "+
     "left join ItemXVariant on tb2.Id=ItemXVariant.Item group by Id) as tb3 "+
				"left join PreTransXItemIn on tb3.Id=PreTransXItemIn.Item group by Id) as tb4 "+
			"left join PreTransXItemOut on tb4.Id=PreTransXItemOut.Item group by Id "+
			"order by Name asc;";
	}
 void saveItemsId(){
  StringBuilder strb=new StringBuilder();
  strb=strb.append(ItemsId.pop().toString());
  if(!ItemsId.isEmpty()){
   do{
    strb.append(","+ItemsId.pop().toString());
   }while(!ItemsId.isEmpty());
  }
  ItemsIdQ=strb.toString();
 }
 void saveItemsCategory() throws Exception{
  OIdName data;
  int temp;
  boolean IsNull;
  ItemsCategory=new LinkedList();
  Rs=Stm.executeQuery(
   "select Id, Name from "+
    "(select CategoryOfItem from "+
     "(select Id from Item where Id in ("+ItemsIdQ+")) as i "+
    "left join ItemXCategory on i.Id=ItemXCategory.Item group by CategoryOfItem) as tb1 "+
   "left join CategoryOfItem on tb1.CategoryOfItem=CategoryOfItem.Id order by Name asc;");
  if(Rs.next()){
   IsNull=false;
   do{
    temp=Rs.getInt(1);
    if(Rs.wasNull()){IsNull=true;}
    else{
     data=new OIdName();
     data.Id=temp;
     data.Name=Rs.getString(2);
     ItemsCategory.addLast(data);
    }
   }while(Rs.next());
   if(IsNull){
    data=new OIdName();
    data.Id=-1;
    data.Name="~ Belum Terkategori ~";
    ItemsCategory.addLast(data);
   }
  }
  CategoryCount=ItemsCategory.size();
 }
 private boolean getNextCategory(){
  if(ItemsCategory.isEmpty()){return false;}
  CurrCategory=ItemsCategory.pop();
  return true;
 }
 private boolean getItemsFromCurrCategory() throws Exception{
  QueryAdditionalTable="";
  if(CurrCategory.Id!=-1){
   QueryAdditionalTable=", ItemXCategory";
   QueryCondition="Item.Id=ItemXCategory.Item and Item.Id in ("+ItemsIdQ+") and ItemXCategory.CategoryOfItem="+CurrCategory.Id;
  }
  else{
   if(CategoryCount==1){QueryCondition="Item.Id in ("+ItemsIdQ+")";}
   else{
    QueryAdditionalTable=" left join ItemXCategory on Item.Id=ItemXCategory.Item";
    QueryCondition="Item.Id in ("+ItemsIdQ+") and ItemXCategory.Item is null";
   }
  }
  Rs=Stm.executeQuery(getQuery());
  
  if(!getNextItemFromResultSet()){return false;}
  CurrCategoryHeaderPrint=true;
  return true;
 }
 private boolean getNextItemFromResultSet() throws Exception{
  boolean ItemIsActive;
  boolean ItemIsStockUpdated; double ItemStock, ItemStockPreIn, ItemStockPreOut, ItemStockMin, ItemStockMax; String ItemStockUnit;
  boolean ItemIsOpname; boolean ItemIsReorder; double ItemOrderMinPack, ItemOrderEachPackQty; double ItemOrderEachPackThreshold;
		boolean ItemIsExpire; int ItemExpireCheckPeriod, ItemExpireThreshold; Date ItemExpireThresholdDate;
  double ItemSellPrice, ItemBuyPriceEst; String ItemSellComment, ItemBuyComment; Date ItemSellUpdate, ItemBuyUpdate;
  double ItemOpnameStock; Date ItemOpnameExp;
  double ItemOrderQty;
  String ItemComment;
  String ItemVariants;
  StringBuilder strb;
  boolean first;
		boolean ThereIs;
		
		ThereIs=true;
		do{
			if(!Rs.next()){ThereIs=false; break;}
			CurrItemName=Rs.getString(1); CurrItemId=Rs.getLong(2);
			if(PrintedId.addElement(CurrItemId)==-1){break;}
		}while(ThereIs);
		if(!ThereIs){return false;}

		strb=new StringBuilder();
		
  ItemVariants=Rs.getString(29);
		ItemIsActive=Rs.getBoolean(3);
  ItemIsStockUpdated=Rs.getBoolean(4);
  ItemStock=Rs.getDouble(6); ItemStockMin=Rs.getDouble(7); ItemStockMax=Rs.getDouble(8);
		ItemStockUnit=Rs.getString(28);
		ItemStockPreIn=Rs.getDouble(30); if(Rs.wasNull()){ItemStockPreIn=0;}
  ItemStockPreOut=Rs.getDouble(31); if(Rs.wasNull()){ItemStockPreOut=0;}
		ItemIsOpname=Rs.getBoolean(9);
  ItemIsReorder=Rs.getBoolean(10);
  ItemOrderMinPack=Rs.getDouble(11);
  ItemOrderEachPackQty=Rs.getDouble(12);
  ItemOrderEachPackThreshold=Rs.getDouble(13);
		ItemSellPrice=Rs.getDouble(14);
		ItemSellComment=Rs.getString(15);
  ItemSellUpdate=Rs.getDate(16);
  ItemBuyPriceEst=Rs.getDouble(17);
		ItemBuyComment=Rs.getString(18);
  ItemBuyUpdate=Rs.getDate(19);
		ItemComment=Rs.getString(20);
  ItemIsExpire=Rs.getBoolean(21);
  ItemExpireCheckPeriod=Rs.getInt(22); if(Rs.wasNull()){ItemExpireCheckPeriod=-1;}
		ItemExpireThreshold=Rs.getInt(23); if(Rs.wasNull()){ItemExpireThreshold=-1;}
		ItemExpireThresholdDate=Rs.getDate(24);
  ItemOpnameStock=Rs.getDouble(25); if(Rs.wasNull()){ItemOpnameStock=-1;}
  ItemOpnameExp=Rs.getDate(26);
  ItemOrderQty=Rs.getDouble(27); if(Rs.wasNull()){ItemOrderQty=-1;}
		
		strb.append(CurrItemName);
  if(OptVariants && !PText.isEmptyString(ItemVariants, false, true)){
   strb.append(" ["+ItemVariants+"]");
  }
  strb.append(" ("+CurrItemId+")");
		if(
   OptIsActive || OptComment || 
   OptIsStockUpdated || OptStock || OptStockPre || OptStockEst || OptStockMinMax || 
   OptIsOpname || OptIsReorder || OptOrderMinPack || OptOrderEachPackQty || OptOrderEachPackThreshold || 
   OptIsExpire || OptExpCheckPeriod || OptExpThreshold || OptExpThresholdDate || 
   OptSellPrice || OptSellComment || OptSellUpdate || (OptBuyPriceEst && ShowBuyPrice) || (OptBuyComment && ShowBuyPrice) || OptBuyUpdate || 
   OptOpnameStock || OptOpnameExp || 
   OptOrderQty || (OptOrderPriceEst && ShowBuyPrice)){
			strb.append(" {");
			first=true;
   if(OptIsActive){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PText.getString(ItemIsActive, "A", "-"));
   }
   if(OptIsStockUpdated){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PText.getString(ItemIsStockUpdated, "S", "-"));
   }
			if(OptStock){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.priceToString(ItemStock));
			}
			if(OptStockPre){
				if(first){first=false;}else{strb.append(", ");}
				strb.append("+"+PText.priceToString(ItemStockPreIn)+" -"+PText.priceToString(ItemStockPreOut));
			}
			if(OptStockEst){
				if(first){first=false;}else{strb.append(", ");}
				strb.append("("+PText.priceToString(ItemStock+ItemStockPreIn-ItemStockPreOut)+")");
			}
			if(OptStockMinMax){
				if(first){first=false;}else{strb.append(", ");}
				strb.append("("+PText.priceToString(ItemStockMin)+"-"+PText.priceToString(ItemStockMax)+")");
			}
   if(OptIsOpname){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PText.getString(ItemIsOpname, "Op", "-"));
   }
   if(OptIsReorder){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PText.getString(ItemIsReorder, "R", "-"));
   }
   if(OptOrderMinPack){
    if(first){first=false;}else{strb.append(", ");}
				strb.append("P-"+PText.priceToString(ItemOrderMinPack));
   }
   if(OptOrderEachPackQty){
    if(first){first=false;}else{strb.append(", ");}
				strb.append("@"+PText.priceToString(ItemOrderEachPackQty));
   }
			if(OptStock || OptStockPre || OptStockEst || OptStockMinMax || OptOrderEachPackQty){
				strb.append(PText.getString(ItemStockUnit, "", " "+ItemStockUnit, true));
			}
   if(OptOrderEachPackThreshold){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.priceToString(ItemOrderEachPackThreshold)+"%");
   }
   if(OptIsExpire){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PText.getString(ItemIsExpire, "E", "-"));
   }
			if(OptExpCheckPeriod){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getString(ItemExpireCheckPeriod, -1, PDate.spellDaysCount(ItemExpireCheckPeriod, 4), "-"));
			}
			if(OptExpThreshold){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getString(ItemExpireThreshold, -1, PDate.spellDaysCount(ItemExpireThreshold, 4), "-"));
			}
			if(OptExpThresholdDate){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PCore.subtituteObj(ItemExpireThresholdDate, PText.dateToString(ItemExpireThresholdDate, 2), "-"));
			}
			if(OptSellPrice){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.priceToString(ItemSellPrice));
			}
			if(OptSellComment){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getString(PText.singleLine(ItemSellComment, '~'), "-", true));
			}
   if(OptSellUpdate){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getStringObj(ItemSellUpdate, "-", PText.dateToString(ItemSellUpdate, 2), false));
   }
			if(OptBuyPriceEst && ShowBuyPrice){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.priceToString(ItemBuyPriceEst));
			}
			if(OptBuyComment && ShowBuyPrice){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getString(PText.singleLine(ItemBuyComment, '~'), "-", true));
			}
   if(OptBuyUpdate){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getStringObj(ItemBuyUpdate, "-", PText.dateToString(ItemBuyUpdate, 2), false));
   }
			if(OptComment){
				if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getString(PText.singleLine(ItemComment, '~'), "-", true));
			}
   if(OptOpnameStock){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getStringDouble(ItemOpnameStock, -0.1, PText.priceToString(ItemOpnameStock), "-"));
   }
   if(OptOpnameExp){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PCore.subtituteObj(ItemOpnameExp, PText.dateToString(ItemOpnameExp, 2), "-"));
   }
   if(OptOrderQty){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getStringDouble(ItemOrderQty, -0.1, PText.priceToString(ItemOrderQty), "-"));
   }
   if(OptOrderPriceEst && ShowBuyPrice){
    if(first){first=false;}else{strb.append(", ");}
				strb.append(PText.getStringDouble(ItemOrderQty, -0.1, PText.priceToString(ItemOrderQty*ItemBuyPriceEst), "-"));
   }
			strb.append("}");
		}
		CurrItemText=strb.toString();
  
  createTableNewRow();
		
  return true;
 }
 private void createTableNewRow(){
  ODimension dim;
  
  // Create new row
  TableNewRow=new ODrawTableRow(0, Table.ColumnsCount);
  
   // set new row's cells
  TableNewRow.setCell(0, new ODrawTableCellText(CurrItemText, FontType, LineSpacing, ODrawComponentText.DefaultAlignment));
		
   // set new row's height
  if(TableNewRow.preGenerateCellsDrawContents(Table, 0)==false){TableNewRow.clearAllCells(); return;}
  dim=TableNewRow.calculatePreGeneratedCellsDrawContentsDimension(Table, 0);
  dbl=PCore.getMinMax_Double(false, PCore.refArr(CellAreaMinHeight, dim.getHeight()));
  TableNewRow.setHeight(dbl+(Table.Inset.InsetTop+Table.Inset.InsetBottom));
  
  TableNewRow.generateCellsDrawContents(Table, 0);
 }
 
}