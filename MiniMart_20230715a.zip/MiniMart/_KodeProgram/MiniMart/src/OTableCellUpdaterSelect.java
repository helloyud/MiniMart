import java.util.Vector;

public class OTableCellUpdaterSelect extends OTableCellUpdater {
 
 OTableCellUpdaterSelectChecker Checker;
 OTableCellUpdater UpdaterIfTrue;
 OTableCellUpdater UpdaterIfFalse;
 
 public OTableCellUpdaterSelect(OTableCellUpdaterSelectChecker Checker, OTableCellUpdater UpdaterIfTrue, OTableCellUpdater UpdaterIfFalse){
  this.Checker = Checker;
  this.UpdaterIfTrue=UpdaterIfTrue;
  this.UpdaterIfFalse=UpdaterIfFalse;
 }
 
 void setModel(OCustomModel Model, Vector<Object[]> Rows, int[] ColumnsType){
  super.setModel(Model, Rows, ColumnsType);
  Checker.setModel(Model, Rows, ColumnsType);
  UpdaterIfTrue.setModel(Model, Rows, ColumnsType);
  UpdaterIfFalse.setModel(Model, Rows, ColumnsType);
 }
 void setModel(OCustomModel Model){
  setModel(Model, Model.getRows(), Model.getColumnsType());
 }
 
 public void update(int TableRowIndex){
  boolean CheckResult;
  CheckResult=Checker.check(TableRowIndex);
  if(CheckResult){UpdaterIfTrue.update(TableRowIndex);}
  else{UpdaterIfFalse.update(TableRowIndex);}
 }
 
}