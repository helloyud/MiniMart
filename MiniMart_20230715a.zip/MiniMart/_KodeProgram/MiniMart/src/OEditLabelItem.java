public class OEditLabelItem {
 
 boolean EditItem; Long EditedItemId; OInfoItem EditedItemInfo;
 boolean EditLabelCount; Integer EditedLabelCount;
 boolean EditPromo; boolean ReplaceSubPromo; String SubPromo; String EditedPromo;

 public OEditLabelItem(){clearAll();}
 
 OEditLabelItem clearAll(){
  init(
   false, -1, null,
   false, -1,
   false, false, null, null);
  
  return this;
 }
 OEditLabelItem init(
  boolean EditItem, long EditedItemId, OInfoItem EditedItemInfo,
  boolean EditLabelCount, int EditedLabelCount,
  boolean EditPromo, boolean ReplaceSubPromo, String SubPromo, String EditedPromo) {
  
  this.EditItem = EditItem; this.EditedItemId = EditedItemId; this.EditedItemInfo = EditedItemInfo;
  this.EditLabelCount = EditLabelCount; this.EditedLabelCount = EditedLabelCount;
  this.EditPromo = EditPromo; this.ReplaceSubPromo = ReplaceSubPromo; this.SubPromo = SubPromo; this.EditedPromo = EditedPromo;
  
  return this;
 }
 
}