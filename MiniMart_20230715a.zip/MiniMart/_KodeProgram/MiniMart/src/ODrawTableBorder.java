public class ODrawTableBorder {
 
 int BorderFill;
 public static final int BorderFillEmpty=0;
 public static final int BorderFillAll=1;
 public static final int BorderFillHorizontalOnly=2;
 boolean FillBorderTop;
 boolean FillBorderBottom;
 boolean FillBorderLeft;
 boolean FillBorderRight;
 boolean FillBorderInsideHorizontal;
 boolean FillBorderInsideVertical;
 
 double BorderWidth;
 
 static ODrawTableBorder DefaultFillAll=new ODrawTableBorder(BorderFillAll, OUnit.mm_to_pixel(0.2));
 static ODrawTableBorder DefaultFillEmpty=new ODrawTableBorder(BorderFillEmpty, OUnit.mm_to_pixel(0.2));
 static ODrawTableBorder DefaultFillHorizontalOnly=new ODrawTableBorder(BorderFillHorizontalOnly, OUnit.mm_to_pixel(0.2));
 
 ODrawTableBorder(int BorderFill, double BorderWidth){
  this.BorderFill=BorderFill;
  this.BorderWidth=BorderWidth;
  
  switch(BorderFill){
   case BorderFillEmpty :
    FillBorderTop=false;
    FillBorderBottom=false;
    FillBorderLeft=false;
    FillBorderRight=false;
    FillBorderInsideHorizontal=false;
    FillBorderInsideVertical=false;
    break;
   case BorderFillAll :
    FillBorderTop=true;
    FillBorderBottom=true;
    FillBorderLeft=true;
    FillBorderRight=true;
    FillBorderInsideHorizontal=true;
    FillBorderInsideVertical=true;
    break;
   case BorderFillHorizontalOnly :
    FillBorderTop=true;
    FillBorderBottom=true;
    FillBorderLeft=false;
    FillBorderRight=false;
    FillBorderInsideHorizontal=true;
    FillBorderInsideVertical=false;
    break;
  }
 }
 
}