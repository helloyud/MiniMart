public class OInfoCustomPaperLabel {
 
 int Id;
 String PaperName;
 boolean DrawCutLine;
 boolean IsRollPaper;
 double PaperWidth;
 double PaperHeight;
 double MarginLeft;
 double MarginTop;
 double LabelWidth;
 double LabelHeight;
 double LabelGapHorizontal;
 double LabelGapVerticalA;
 double LabelGapVerticalB;

 public OInfoCustomPaperLabel(){}
 public OInfoCustomPaperLabel(
  int Id, String PaperName,
  boolean IsRollPaper, boolean DrawCutLine,
  double PaperWidth, double PaperHeight, double MarginLeft, double MarginTop,
  double LabelWidth, double LabelHeight, double LabelGapHorizontal, double LabelGapVerticalA, double LabelGapVerticalB) {
  this.Id=Id;
  this.PaperName = PaperName;
  this.IsRollPaper=IsRollPaper;
  this.DrawCutLine = DrawCutLine;
  this.PaperWidth = PaperWidth;
  this.PaperHeight = PaperHeight;
  this.MarginLeft = MarginLeft;
  this.MarginTop = MarginTop;
  this.LabelWidth = LabelWidth;
  this.LabelHeight = LabelHeight;
  this.LabelGapHorizontal = LabelGapHorizontal;
  this.LabelGapVerticalA = LabelGapVerticalA;
  this.LabelGapVerticalB = LabelGapVerticalB;
 }
 
 public OPaperLabel getPaperLabel(boolean AddPaperSizeTolerance, OPaperMargin MarginSt, OPaperMargin MarginTh){
  OPaperLabel ret=null;
  double WidthTolerance, HeightTolerance;
  
  WidthTolerance=0;
  if(AddPaperSizeTolerance && !IsRollPaper){
   WidthTolerance=CPrint.PaperWidthToleranceDefault;
  }
  HeightTolerance=0;
  if(AddPaperSizeTolerance && !IsRollPaper){
   HeightTolerance=CPrint.PaperHeightToleranceDefault;
  }
  ret=new OPaperLabel(
   Id, PaperName, null, IsRollPaper, null, MarginSt, MarginTh,
   PaperWidth, PaperHeight,
   MarginLeft, MarginTop, PaperWidth-MarginLeft, PaperHeight-MarginTop,
   WidthTolerance, HeightTolerance, 0, 0,
   LabelWidth, LabelHeight, LabelGapHorizontal, LabelGapVerticalA, LabelGapVerticalB,
   false, true, (Boolean)PCore.subtituteBool(!IsRollPaper, true, false), DrawCutLine, true);
  
  return ret;
 }
 
}