import javax.swing.JDialog;

public abstract class XFormDialog extends JDialog
 implements XForm{
 
 MInterFormVariables IFV;
 boolean Activ;
 int DialogResult; // 0 Cancel, 1 Ok
 
 public void preInitComponents(){
  
 }
 public void postInitComponents(){
  // getContentPane().setBackground(CGUI.Color_Form_Background);
 }
 
 public boolean showForm(){
  boolean ret=false;
  
  if(!canShowForm(true)){return ret;}
  
  PEtc.setDialogToCenter(this);
  setVisible(true);
  ret=true;
  
  return ret;
 }
 
 protected boolean canShowForm(boolean ShowMessage){return true;}
 
 void clearComponents(){}
 void closingForm(int DialogResult){
  this.DialogResult=DialogResult;
  clearComponents();
  Activ=false;
 }
 
}