import java.awt.Component;
import java.awt.DefaultKeyboardFocusManager;
import java.awt.event.KeyEvent;

public class OKeyboardFocusManager extends DefaultKeyboardFocusManager {
 
 boolean ShortcutKeyIsPressing;
 
 boolean ShortcutRefreshConnection;
 
 boolean ShortcutComponent;
 OFormSupportsComponentShortcut CmpForm;
 Component Cmp;
 int[] ComponentKeys;

 MInterFormVariables IFV;

 public OKeyboardFocusManager(MInterFormVariables IFV) {
  ShortcutRefreshConnection=true;
  ShortcutComponent=false;
  
  this.IFV=IFV;
  ShortcutKeyIsPressing=false;
 }
 
 void enableComponentShortcut(OFormSupportsComponentShortcut CmpForm, Component Cmp, int[] ComponentKeys){
  ShortcutComponent=true;
  this.CmpForm=CmpForm;
  this.Cmp=Cmp;
  this.ComponentKeys=ComponentKeys;
 }
 void disableComponentShortcut(){ShortcutComponent=false;}
 
 @Override
 public boolean dispatchKeyEvent(KeyEvent e) {
  int Event=e.getID();
  int Code=e.getKeyCode();
  int temp, count;
  
  if(Event==KeyEvent.KEY_PRESSED){
   
   if(ShortcutKeyIsPressing){return true;}
   
   if(Code==KeyEvent.VK_F5 && e.isControlDown()){
    if(ShortcutRefreshConnection){
     ShortcutKeyIsPressing=true;
     IFV.refreshConnection(true);
     return true;
    }
    return super.dispatchKeyEvent(e);
   }

   if(ShortcutComponent){
    count=ComponentKeys.length;
    temp=0;
    do{
     if(Code==ComponentKeys[temp]){
      ShortcutKeyIsPressing=true;
      CmpForm.fireKeyAction(Cmp, e);
      return true;
     }
     temp=temp+1;
    }while(temp!=count);
    return super.dispatchKeyEvent(e);
   }
   
   return super.dispatchKeyEvent(e);
  }

  if(Event==KeyEvent.KEY_TYPED){
   
   if(ShortcutKeyIsPressing){return true;}
   
   return super.dispatchKeyEvent(e);
  }

  if(Event==KeyEvent.KEY_RELEASED){
   
   if(ShortcutKeyIsPressing){ShortcutKeyIsPressing=false; return true;}
   
   return super.dispatchKeyEvent(e);
  }

  return super.dispatchKeyEvent(e);
 }
}