import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class F_ItemModifyMulti extends XFormDialog{
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeId; int IdOption;
 boolean ChangeName; String NameFind, NameReplace;
 boolean ChangeIsActive; boolean IsActive;
 boolean ChangeComment; boolean ChangeCommentSubString; String CommentFind; String Comment;
 
 boolean ChangeStockUnit; int StockUnitId; String StockUnitName;
 boolean ChangeStock; double Stock;
 boolean ChangeUpdateStock; boolean UpdateStock;
 boolean ChangeMinStock; double MinStock;
 boolean ChangeMaxStock; double MaxStock;
 
 boolean ChangeIsOpname; boolean IsOpname;
 boolean ChangeIsReorder; boolean IsReorder;
 boolean ChangeOrderMinPack; double OrderMinPack;
 boolean ChangeOrderEachPackQty; double OrderEachPackQty;
 boolean ChangeOrderEachPackThreshold; double OrderEachPackThreshold;
 
 boolean ChangeHasExpireDate; boolean HasExpireDate;
 boolean ChangeExpireCheckPeriod; int ExpireCheckPeriod;
 boolean ChangeExpireThreshold; int ExpireThreshold;
 
 boolean ChangeSellPrice; double SellPrice;
 boolean ChangeSellPriceComment; boolean ChangeSellPriceCommentSubString; String SellPriceCommentFind; String SellPriceComment;
 boolean ChangeSellUpdate; Date SellUpdate;
 boolean ChangeBuyPriceEst; double BuyPriceEst;
 boolean ChangeBuyPriceComment; boolean ChangeBuyPriceCommentSubString; String BuyPriceCommentFind; String BuyPriceComment;
 boolean ChangeBuyUpdate; Date BuyUpdate;
 
 boolean ChangeOpStock; Double OpStock;
 boolean ChangeOpExpire; Date OpExpire;
 boolean ChangeOrderQty; double OrderQty;
 
 public F_ItemModifyMulti(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  RB_UpdateStockY.setSelected(true);
  RB_ExpireN.setSelected(true);
  RB_ActiveY.setSelected(true);
  RB_IsOpnameY.setSelected(true);
  RB_IsReorderY.setSelected(true);
  CB_CommentSubActionPerformed(null);
  CB_SellCommentSubActionPerformed(null);
  CB_BuyCommentSubActionPerformed(null);
  CB_OpExpireOnActionPerformed(null);
  CB_SellUpdateOnActionPerformed(null);
  CB_BuyUpdateOnActionPerformed(null);
  clearComponents();
  
  CmB_IdOption.setSelectedIndex(1);
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_Id, CmB_IdOption,
    CB_Name, TF_NameFind, TF_NameReplace,
    CB_Active, RB_ActiveY, RB_ActiveN,
    CB_Comment, TF_CommentSub, CB_CommentSub, TA_Comment,
    CB_StockUnit, Btn_ChooseStockUnit, Btn_ClearStockUnit,
    CB_UpdateStock, RB_UpdateStockY, RB_UpdateStockN,
    CB_Stock, TF_Stock,
    CB_MinStock, TF_MinStock,
    CB_MaxStock, TF_MaxStock,
    CB_IsOpname, RB_IsOpnameY, RB_IsOpnameN, CB_IsReorder, RB_IsReorderY, RB_IsReorderN,
    CB_OrderEachPackQty, TF_OrderEachPackQty,
    CB_OrderEachPackThreshold, TF_OrderEachPackThreshold,
    CB_OrderMinPack, TF_OrderMinPack,
    CB_Expire, RB_ExpireY, RB_ExpireN,
    CB_ExpireCheckPeriod, TF_ExpireCheckPeriod,
    CB_ExpireThreshold, TF_ExpireThreshold,
    CB_Sell, TF_Sell,
    CB_SellUpdate, CB_SellUpdateOn, TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay, Btn_SellUpdateSetToday,
    CB_SellComment, TF_SellCommentSub, CB_SellCommentSub, TA_SellComment,
    CB_BuyPriceEst, TF_BuyPriceEst,
    CB_BuyUpdate, CB_BuyUpdateOn, TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay, Btn_BuyUpdateSetToday,
    CB_BuyComment, TF_BuyCommentSub, CB_BuyCommentSub, TA_BuyComment,
    CB_OpStock, TF_OpStock,
    CB_OpExpire, CB_OpExpireOn, TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay,
    CB_OrderQty, TF_OrderQty,
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     if(Btn_Ok.isVisible()){Btn_OkActionPerformed(null);}
    }
   });
 }

 
 void clearComponents(){
  CB_Id.setSelected(false); CB_Id.setForeground(CGUI.Color_Label_InputPrimary);
  CB_Name.setSelected(false); CB_Name.setForeground(CGUI.Color_Label_InputPrimary); TF_NameFind.setText(""); TF_NameReplace.setText("");
  CB_Active.setSelected(false); CB_Active.setForeground(CGUI.Color_Label_InputPrimary);
  CB_Comment.setSelected(false); CB_Comment.setForeground(CGUI.Color_Label_InputSecondary); TF_CommentSub.setText(""); TA_Comment.setText("");
  
  CB_StockUnit.setSelected(false); CB_StockUnit.setForeground(CGUI.Color_Label_InputPrimary); TF_StockUnit.setText("");
  CB_Stock.setSelected(false); CB_Stock.setForeground(CGUI.Color_Label_InputPrimary); TF_Stock.setText("");
  CB_UpdateStock.setSelected(false); CB_UpdateStock.setForeground(CGUI.Color_Label_InputPrimary);
  CB_MinStock.setSelected(false); CB_MinStock.setForeground(CGUI.Color_Label_InputPrimary); TF_MinStock.setText("");
  CB_MaxStock.setSelected(false); CB_MaxStock.setForeground(CGUI.Color_Label_InputPrimary); TF_MaxStock.setText("");
  
  CB_IsOpname.setSelected(false); CB_IsOpname.setForeground(CGUI.Color_Label_InputPrimary);
  CB_IsReorder.setSelected(false); CB_IsReorder.setForeground(CGUI.Color_Label_InputPrimary);
  CB_OrderMinPack.setSelected(false); CB_OrderMinPack.setForeground(CGUI.Color_Label_InputSecondary); TF_OrderMinPack.setText("");
  CB_OrderEachPackQty.setSelected(false); CB_OrderEachPackQty.setForeground(CGUI.Color_Label_InputPrimary); TF_OrderEachPackQty.setText("");
  CB_OrderEachPackThreshold.setSelected(false); CB_OrderEachPackThreshold.setForeground(CGUI.Color_Label_InputSecondary); TF_OrderEachPackThreshold.setText("");
  
  CB_Expire.setSelected(false); CB_Expire.setForeground(CGUI.Color_Label_InputPrimary);
  CB_ExpireCheckPeriod.setSelected(false); CB_ExpireCheckPeriod.setForeground(CGUI.Color_Label_InputPrimary); TF_ExpireCheckPeriod.setText("");
  CB_ExpireThreshold.setSelected(false); CB_ExpireThreshold.setForeground(CGUI.Color_Label_InputPrimary); TF_ExpireThreshold.setText("");
  
  CB_Sell.setSelected(false); CB_Sell.setForeground(CGUI.Color_Label_InputPrimary); TF_Sell.setText("");
  CB_SellComment.setSelected(false); CB_SellComment.setForeground(CGUI.Color_Label_InputSecondary); TF_SellCommentSub.setText(""); TA_SellComment.setText("");
  CB_SellUpdate.setSelected(false); CB_SellUpdate.setForeground(CGUI.Color_Label_InputSecondary); TF_SellUpdateYear.setText(""); CB_SellUpdateOn.setSelected(false); CB_SellUpdateOnActionPerformed(null);
  CB_BuyPriceEst.setSelected(false); CB_BuyPriceEst.setForeground(CGUI.Color_Label_InputPrimary); TF_BuyPriceEst.setText("");
  CB_BuyComment.setSelected(false); CB_BuyComment.setForeground(CGUI.Color_Label_InputSecondary); TF_BuyCommentSub.setText(""); TA_BuyComment.setText("");
  CB_BuyUpdate.setSelected(false); CB_BuyUpdate.setForeground(CGUI.Color_Label_InputSecondary); TF_BuyUpdateYear.setText(""); CB_BuyUpdateOn.setSelected(false); CB_BuyUpdateOnActionPerformed(null);
  
  CB_OpStock.setSelected(false); CB_OpStock.setForeground(CGUI.Color_Label_InputSecondary); TF_OpStock.setText("");
  CB_OpExpire.setSelected(false); CB_OpExpire.setForeground(CGUI.Color_Label_InputSecondary); TF_OpExpireYear.setText(""); CB_OpExpireOn.setSelected(false); CB_OpExpireOnActionPerformed(null);
  CB_OrderQty.setSelected(false); CB_OrderQty.setForeground(CGUI.Color_Label_InputSecondary); TF_OrderQty.setText("");
  
  clearSetVariables();
 }
 
 void clearSetVariables(){
  
 }
 
 void enableInputInTextField(boolean Enable, JTextField TF){
  TF.setEnabled(Enable);
  if(!TF.isEnabled()){TF.setText("");}
 }
 void enableInputInDateComponents(boolean Enable, JTextField CompYear, JComboBox CompMonth, JComboBox CompDay){
  CompYear.setEnabled(Enable);
  CompMonth.setEnabled(Enable);
  CompDay.setEnabled(Enable);
 }
 
 int getInputOfIdOption(){
  int ret=0;
  
  switch(CmB_IdOption.getSelectedIndex()){
   case 0 : ret=1; break;
   case 1 : ret=2; break;
  }
  
  return ret;
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_UpdateStock = new javax.swing.ButtonGroup();
  RG_Expire = new javax.swing.ButtonGroup();
  RG_Active = new javax.swing.ButtonGroup();
  RG_MismatchStock = new javax.swing.ButtonGroup();
  RG_Stock = new javax.swing.ButtonGroup();
  RG_IsReorder = new javax.swing.ButtonGroup();
  RG_IsOpname = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_DataCount = new javax.swing.JLabel();
  jPanel2 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  TF_Sell = new javax.swing.JTextField();
  CB_Sell = new javax.swing.JCheckBox();
  Lbl_SellHelp = new javax.swing.JLabel();
  CB_SellCommentSub = new javax.swing.JCheckBox();
  TF_SellCommentSub = new javax.swing.JTextField();
  CB_SellComment = new javax.swing.JCheckBox();
  Lbl_SellCommentHelp = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_SellComment = new javax.swing.JTextArea();
  CB_BuyCommentSub = new javax.swing.JCheckBox();
  TF_BuyCommentSub = new javax.swing.JTextField();
  CB_BuyComment = new javax.swing.JCheckBox();
  Lbl_BuyCommentHelp = new javax.swing.JLabel();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_BuyComment = new javax.swing.JTextArea();
  TF_BuyPriceEst = new javax.swing.JTextField();
  CB_BuyPriceEst = new javax.swing.JCheckBox();
  Lbl_BuyPriceEst = new javax.swing.JLabel();
  CmB_SellUpdateDay = new javax.swing.JComboBox<>();
  CmB_SellUpdateMonth = new javax.swing.JComboBox<>();
  TF_SellUpdateYear = new javax.swing.JTextField();
  CB_SellUpdateOn = new javax.swing.JCheckBox();
  CB_SellUpdate = new javax.swing.JCheckBox();
  CmB_BuyUpdateDay = new javax.swing.JComboBox<>();
  CmB_BuyUpdateMonth = new javax.swing.JComboBox<>();
  CB_BuyUpdateOn = new javax.swing.JCheckBox();
  TF_BuyUpdateYear = new javax.swing.JTextField();
  CB_BuyUpdate = new javax.swing.JCheckBox();
  Btn_SellUpdateSetToday = new javax.swing.JButton();
  Btn_BuyUpdateSetToday = new javax.swing.JButton();
  jSeparator3 = new javax.swing.JSeparator();
  jPanel6 = new javax.swing.JPanel();
  TF_OpStock = new javax.swing.JTextField();
  CmB_OpExpireDay = new javax.swing.JComboBox<>();
  CmB_OpExpireMonth = new javax.swing.JComboBox<>();
  TF_OpExpireYear = new javax.swing.JTextField();
  CB_OpExpireOn = new javax.swing.JCheckBox();
  CB_OpStock = new javax.swing.JCheckBox();
  Lbl_OpStockHelp = new javax.swing.JLabel();
  CB_OpExpire = new javax.swing.JCheckBox();
  TF_OrderQty = new javax.swing.JTextField();
  CB_OrderQty = new javax.swing.JCheckBox();
  Lbl_OrderQtyHelp = new javax.swing.JLabel();
  jSeparator5 = new javax.swing.JSeparator();
  jPanel5 = new javax.swing.JPanel();
  RB_ExpireY = new javax.swing.JRadioButton();
  RB_ExpireN = new javax.swing.JRadioButton();
  CB_Expire = new javax.swing.JCheckBox();
  TF_ExpireCheckPeriod = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  CB_ExpireCheckPeriod = new javax.swing.JCheckBox();
  Lbl_ExpireCheckPeriodHelp = new javax.swing.JLabel();
  TF_ExpireThreshold = new javax.swing.JTextField();
  jLabel4 = new javax.swing.JLabel();
  CB_ExpireThreshold = new javax.swing.JCheckBox();
  Lbl_ExpireThresholdHelp = new javax.swing.JLabel();
  jPanel3 = new javax.swing.JPanel();
  jPanel7 = new javax.swing.JPanel();
  TF_NameFind = new javax.swing.JTextField();
  TF_NameReplace = new javax.swing.JTextField();
  RB_ActiveN = new javax.swing.JRadioButton();
  RB_ActiveY = new javax.swing.JRadioButton();
  CB_Active = new javax.swing.JCheckBox();
  CB_Name = new javax.swing.JCheckBox();
  Lbl_NameHelp = new javax.swing.JLabel();
  jLabel2 = new javax.swing.JLabel();
  jLabel3 = new javax.swing.JLabel();
  TF_CommentSub = new javax.swing.JTextField();
  CB_CommentSub = new javax.swing.JCheckBox();
  CB_Comment = new javax.swing.JCheckBox();
  Lbl_CommentHelp = new javax.swing.JLabel();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  CmB_IdOption = new javax.swing.JComboBox<>();
  CB_Id = new javax.swing.JCheckBox();
  jSeparator4 = new javax.swing.JSeparator();
  jPanel8 = new javax.swing.JPanel();
  Btn_ClearStockUnit = new javax.swing.JButton();
  Btn_ChooseStockUnit = new javax.swing.JButton();
  TF_StockUnit = new javax.swing.JTextField();
  CB_StockUnit = new javax.swing.JCheckBox();
  TF_Stock = new javax.swing.JTextField();
  CB_Stock = new javax.swing.JCheckBox();
  Lbl_StockHelp = new javax.swing.JLabel();
  RB_UpdateStockY = new javax.swing.JRadioButton();
  RB_UpdateStockN = new javax.swing.JRadioButton();
  CB_UpdateStock = new javax.swing.JCheckBox();
  TF_MinStock = new javax.swing.JTextField();
  CB_MinStock = new javax.swing.JCheckBox();
  Lbl_MinStockHelp = new javax.swing.JLabel();
  TF_MaxStock = new javax.swing.JTextField();
  CB_MaxStock = new javax.swing.JCheckBox();
  Lbl_MaxStockHelp = new javax.swing.JLabel();
  TF_OrderEachPackQty = new javax.swing.JTextField();
  CB_OrderEachPackQty = new javax.swing.JCheckBox();
  Lbl_OrderEachPackQtyHelp = new javax.swing.JLabel();
  jLabel5 = new javax.swing.JLabel();
  TF_OrderEachPackThreshold = new javax.swing.JTextField();
  CB_OrderEachPackThreshold = new javax.swing.JCheckBox();
  Lbl_OrderEachPackThresholdHelp = new javax.swing.JLabel();
  CB_OrderMinPack = new javax.swing.JCheckBox();
  Lbl_OrderMinPackHelp = new javax.swing.JLabel();
  TF_OrderMinPack = new javax.swing.JTextField();
  RB_IsReorderY = new javax.swing.JRadioButton();
  RB_IsReorderN = new javax.swing.JRadioButton();
  CB_IsReorder = new javax.swing.JCheckBox();
  CB_IsOpname = new javax.swing.JCheckBox();
  RB_IsOpnameY = new javax.swing.JRadioButton();
  RB_IsOpnameN = new javax.swing.JRadioButton();
  jSeparator2 = new javax.swing.JSeparator();

  setTitle("Ubah Data Dari Beberapa Barang");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data Barang");

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Lbl_DataCount)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok)
    .addComponent(Lbl_DataCount))
  );

  TF_Sell.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellKeyPressed(evt);
   }
  });

  CB_Sell.setText("Harga Jual");
  CB_Sell.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Sell.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellKeyPressed(evt);
   }
  });

  Lbl_SellHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellHelp.setText("(?)");
  Lbl_SellHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellHelpMouseClicked(evt);
   }
  });

  CB_SellCommentSub.setText("Ganti Sub-Kata");
  CB_SellCommentSub.setToolTipText("centang opsi ini utk mengganti sub-kata");
  CB_SellCommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellCommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellCommentSubActionPerformed(evt);
   }
  });
  CB_SellCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellCommentSubKeyPressed(evt);
   }
  });

  TF_SellCommentSub.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TF_SellCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellCommentSubKeyPressed(evt);
   }
  });

  CB_SellComment.setText("~ Ket Hrg Jual");
  CB_SellComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellCommentKeyPressed(evt);
   }
  });

  Lbl_SellCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellCommentHelp.setText("(?)");
  Lbl_SellCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellCommentHelpMouseClicked(evt);
   }
  });

  TA_SellComment.setColumns(5);
  TA_SellComment.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_SellComment.setLineWrap(true);
  TA_SellComment.setWrapStyleWord(true);
  TA_SellComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_SellCommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_SellComment);

  CB_BuyCommentSub.setText("Ganti Sub-Kata");
  CB_BuyCommentSub.setToolTipText("centang opsi ini utk mengganti sub-kata");
  CB_BuyCommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyCommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyCommentSubActionPerformed(evt);
   }
  });
  CB_BuyCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyCommentSubKeyPressed(evt);
   }
  });

  TF_BuyCommentSub.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TF_BuyCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyCommentSubKeyPressed(evt);
   }
  });

  CB_BuyComment.setText("~ Ket Hrg Beli");
  CB_BuyComment.setToolTipText("");
  CB_BuyComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyCommentKeyPressed(evt);
   }
  });

  Lbl_BuyCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyCommentHelp.setText("(?)");
  Lbl_BuyCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyCommentHelpMouseClicked(evt);
   }
  });

  TA_BuyComment.setColumns(20);
  TA_BuyComment.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_BuyComment.setLineWrap(true);
  TA_BuyComment.setWrapStyleWord(true);
  TA_BuyComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyCommentKeyPressed(evt);
   }
  });
  jScrollPane3.setViewportView(TA_BuyComment);

  TF_BuyPriceEst.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceEstKeyPressed(evt);
   }
  });

  CB_BuyPriceEst.setText("Kis. Harga Beli");
  CB_BuyPriceEst.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyPriceEst.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyPriceEstKeyPressed(evt);
   }
  });

  Lbl_BuyPriceEst.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceEst.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceEst.setText("(?)");
  Lbl_BuyPriceEst.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceEst.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceEstMouseClicked(evt);
   }
  });

  CmB_SellUpdateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_SellUpdateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateDayKeyPressed(evt);
   }
  });

  CmB_SellUpdateMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_SellUpdateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateMonthKeyPressed(evt);
   }
  });

  TF_SellUpdateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellUpdateYearKeyPressed(evt);
   }
  });

  CB_SellUpdateOn.setText(" ");
  CB_SellUpdateOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdateOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellUpdateOnActionPerformed(evt);
   }
  });
  CB_SellUpdateOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateOnKeyPressed(evt);
   }
  });

  CB_SellUpdate.setText("~ Tgl Pembaruan Jual");
  CB_SellUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateKeyPressed(evt);
   }
  });

  CmB_BuyUpdateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_BuyUpdateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDayKeyPressed(evt);
   }
  });

  CmB_BuyUpdateMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_BuyUpdateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateMonthKeyPressed(evt);
   }
  });

  CB_BuyUpdateOn.setText(" ");
  CB_BuyUpdateOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdateOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyUpdateOnActionPerformed(evt);
   }
  });
  CB_BuyUpdateOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateOnKeyPressed(evt);
   }
  });

  TF_BuyUpdateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateYearKeyPressed(evt);
   }
  });

  CB_BuyUpdate.setText("~ Tgl Pembaruan Beli");
  CB_BuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateKeyPressed(evt);
   }
  });

  Btn_SellUpdateSetToday.setText("Hari Ini");
  Btn_SellUpdateSetToday.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SellUpdateSetToday.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SellUpdateSetTodayActionPerformed(evt);
   }
  });
  Btn_SellUpdateSetToday.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_SellUpdateSetTodayKeyPressed(evt);
   }
  });

  Btn_BuyUpdateSetToday.setText("Hari Ini");
  Btn_BuyUpdateSetToday.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_BuyUpdateSetToday.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_BuyUpdateSetTodayActionPerformed(evt);
   }
  });
  Btn_BuyUpdateSetToday.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_BuyUpdateSetTodayKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_SellComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_SellCommentHelp))
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_BuyComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyCommentHelp))
     .addComponent(CB_BuyUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_SellUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_Sell)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_SellHelp))
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_BuyPriceEst)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPriceEst)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(TF_BuyCommentSub)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_BuyCommentSub))
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(TF_SellCommentSub)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_SellCommentSub))
     .addComponent(jScrollPane1)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_BuyUpdateOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_BuyUpdateMonth, 0, 159, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_BuyUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_BuyUpdateSetToday))
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_SellUpdateOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_SellUpdateMonth, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_SellUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_SellUpdateSetToday))
     .addComponent(TF_Sell, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_BuyPriceEst)))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Sell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Sell)
     .addComponent(Lbl_SellHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SellUpdate)
     .addComponent(CB_SellUpdateOn)
     .addComponent(Btn_SellUpdateSetToday)
     .addComponent(TF_SellUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SellCommentSub)
     .addComponent(TF_SellCommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellComment)
     .addComponent(Lbl_SellCommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_BuyPriceEst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyPriceEst)
     .addComponent(Lbl_BuyPriceEst))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_BuyUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyUpdateOn)
     .addComponent(TF_BuyUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyUpdate)
     .addComponent(Btn_BuyUpdateSetToday))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BuyCommentSub)
     .addComponent(TF_BuyCommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyComment)
     .addComponent(Lbl_BuyCommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE))
  );

  TF_OpStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpStockKeyPressed(evt);
   }
  });

  CmB_OpExpireDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_OpExpireDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpireDayKeyPressed(evt);
   }
  });

  CmB_OpExpireMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_OpExpireMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpireMonthKeyPressed(evt);
   }
  });

  TF_OpExpireYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpExpireYearKeyPressed(evt);
   }
  });

  CB_OpExpireOn.setText(" ");
  CB_OpExpireOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExpireOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OpExpireOnActionPerformed(evt);
   }
  });
  CB_OpExpireOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpireOnKeyPressed(evt);
   }
  });

  CB_OpStock.setText("Op-Stok (Selisih)");
  CB_OpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpStockKeyPressed(evt);
   }
  });

  Lbl_OpStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OpStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OpStockHelp.setText("(?)");
  Lbl_OpStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OpStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OpStockHelpMouseClicked(evt);
   }
  });

  CB_OpExpire.setText("Op. Expire");
  CB_OpExpire.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExpire.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpireKeyPressed(evt);
   }
  });

  TF_OrderQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderQtyKeyPressed(evt);
   }
  });

  CB_OrderQty.setText("Order Qty");
  CB_OrderQty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderQtyKeyPressed(evt);
   }
  });

  Lbl_OrderQtyHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderQtyHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderQtyHelp.setText("(?)");
  Lbl_OrderQtyHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderQtyHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderQtyHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel6Layout.createSequentialGroup()
      .addComponent(CB_OrderQty)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderQtyHelp))
     .addGroup(jPanel6Layout.createSequentialGroup()
      .addComponent(CB_OpStock)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OpStockHelp))
     .addComponent(CB_OpExpire, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_OrderQty)
     .addComponent(TF_OpStock)
     .addGroup(jPanel6Layout.createSequentialGroup()
      .addComponent(CB_OpExpireOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OpExpireYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_OpExpireMonth, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_OpExpireDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OpStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpStock)
     .addComponent(Lbl_OpStockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_OpExpireDay)
     .addComponent(CmB_OpExpireMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OpExpireYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpExpireOn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_OpExpire))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OrderQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OrderQty)
     .addComponent(Lbl_OrderQtyHelp)))
  );

  RG_Expire.add(RB_ExpireY);
  RB_ExpireY.setText("Ya");
  RB_ExpireY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ExpireY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ExpireYKeyPressed(evt);
   }
  });

  RG_Expire.add(RB_ExpireN);
  RB_ExpireN.setText("Tidak");
  RB_ExpireN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ExpireN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ExpireNKeyPressed(evt);
   }
  });

  CB_Expire.setText("Berkadaluarsa");
  CB_Expire.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Expire.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpireKeyPressed(evt);
   }
  });

  TF_ExpireCheckPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpireCheckPeriodKeyPressed(evt);
   }
  });

  jLabel1.setText("hari");

  CB_ExpireCheckPeriod.setText("~ Cek Exp Tiap");
  CB_ExpireCheckPeriod.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ExpireCheckPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpireCheckPeriodKeyPressed(evt);
   }
  });

  Lbl_ExpireCheckPeriodHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpireCheckPeriodHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpireCheckPeriodHelp.setText("(?)");
  Lbl_ExpireCheckPeriodHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpireCheckPeriodHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpireCheckPeriodHelpMouseClicked(evt);
   }
  });

  TF_ExpireThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpireThresholdKeyPressed(evt);
   }
  });

  jLabel4.setText("hari");

  CB_ExpireThreshold.setText("~ Batas Expire");
  CB_ExpireThreshold.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ExpireThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpireThresholdKeyPressed(evt);
   }
  });

  Lbl_ExpireThresholdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpireThresholdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpireThresholdHelp.setText("(?)");
  Lbl_ExpireThresholdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpireThresholdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpireThresholdHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_Expire, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_ExpireThreshold)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ExpireThresholdHelp))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_ExpireCheckPeriod)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ExpireCheckPeriodHelp)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addComponent(TF_ExpireThreshold)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel4))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(RB_ExpireY)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(RB_ExpireN)
      .addContainerGap())
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(TF_ExpireCheckPeriod)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel1))))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_ExpireY)
     .addComponent(RB_ExpireN)
     .addComponent(CB_Expire))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpireCheckPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ExpireCheckPeriod)
     .addComponent(Lbl_ExpireCheckPeriodHelp)
     .addComponent(jLabel1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpireThreshold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ExpireThreshold)
     .addComponent(Lbl_ExpireThresholdHelp)
     .addComponent(jLabel4)))
  );

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator3)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator5)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_NameFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameFindKeyPressed(evt);
   }
  });

  TF_NameReplace.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameReplaceKeyPressed(evt);
   }
  });

  RG_Active.add(RB_ActiveN);
  RB_ActiveN.setText("Tidak");
  RB_ActiveN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ActiveN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ActiveNKeyPressed(evt);
   }
  });

  RG_Active.add(RB_ActiveY);
  RB_ActiveY.setText("Ya");
  RB_ActiveY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ActiveY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ActiveYKeyPressed(evt);
   }
  });

  CB_Active.setText("Masih Aktif");
  CB_Active.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Active.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ActiveKeyPressed(evt);
   }
  });

  CB_Name.setText("Nama");
  CB_Name.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_NameKeyPressed(evt);
   }
  });

  Lbl_NameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_NameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_NameHelp.setText("(?)");
  Lbl_NameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_NameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_NameHelpMouseClicked(evt);
   }
  });

  jLabel2.setText("Sub-Kata");

  jLabel3.setText("Diganti");

  TF_CommentSub.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TF_CommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CommentSubKeyPressed(evt);
   }
  });

  CB_CommentSub.setText("Ganti Sub-Kata");
  CB_CommentSub.setToolTipText("centang opsi ini utk mengganti sub-kata");
  CB_CommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_CommentSubActionPerformed(evt);
   }
  });
  CB_CommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentSubKeyPressed(evt);
   }
  });

  CB_Comment.setText("Ket.");
  CB_Comment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentKeyPressed(evt);
   }
  });

  Lbl_CommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentHelp.setText("(?)");
  Lbl_CommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentHelpMouseClicked(evt);
   }
  });

  TA_Comment.setColumns(5);
  TA_Comment.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_Comment.setLineWrap(true);
  TA_Comment.setWrapStyleWord(true);
  TA_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_Comment);

  CmB_IdOption.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Konversi ke EAN-8/13", "Konversi ke EAN-8/13 (preservasi 'Id lama' ke 'Secondary Id')" }));
  CmB_IdOption.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IdOptionKeyPressed(evt);
   }
  });

  CB_Id.setText("Id");
  CB_Id.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Id.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IdKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(CB_Name)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_NameHelp))
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(CB_Comment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CommentHelp))
     .addComponent(CB_Id, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_Active, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addComponent(CmB_IdOption, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jLabel2)
       .addComponent(jLabel3))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_NameReplace)
       .addComponent(TF_NameFind)))
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(RB_ActiveY)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(RB_ActiveN)
      .addContainerGap())
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(TF_CommentSub)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_CommentSub))))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_IdOption, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Id))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_NameFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2)
     .addComponent(CB_Name)
     .addComponent(Lbl_NameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_NameReplace, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel3))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_ActiveN)
     .addComponent(RB_ActiveY)
     .addComponent(CB_Active))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_CommentSub)
     .addComponent(CB_Comment)
     .addComponent(Lbl_CommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane2))
  );

  Btn_ClearStockUnit.setText("-");
  Btn_ClearStockUnit.setToolTipText("hapus satuan stok yang dipilih");
  Btn_ClearStockUnit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearStockUnitActionPerformed(evt);
   }
  });
  Btn_ClearStockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearStockUnitKeyPressed(evt);
   }
  });

  Btn_ChooseStockUnit.setText("...");
  Btn_ChooseStockUnit.setToolTipText("Pilih satuan stok");
  Btn_ChooseStockUnit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseStockUnitActionPerformed(evt);
   }
  });
  Btn_ChooseStockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseStockUnitKeyPressed(evt);
   }
  });

  TF_StockUnit.setEditable(false);
  TF_StockUnit.setBackground(new java.awt.Color(204, 255, 204));

  CB_StockUnit.setText("Satuan Stok");
  CB_StockUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockUnitKeyPressed(evt);
   }
  });

  TF_Stock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockKeyPressed(evt);
   }
  });

  CB_Stock.setText("~ Stok");
  CB_Stock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Stock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockKeyPressed(evt);
   }
  });

  Lbl_StockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockHelp.setText("(?)");
  Lbl_StockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockHelpMouseClicked(evt);
   }
  });

  RG_UpdateStock.add(RB_UpdateStockY);
  RB_UpdateStockY.setText("Ya");
  RB_UpdateStockY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_UpdateStockY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_UpdateStockYKeyPressed(evt);
   }
  });

  RG_UpdateStock.add(RB_UpdateStockN);
  RB_UpdateStockN.setText("Tidak");
  RB_UpdateStockN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_UpdateStockN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_UpdateStockNKeyPressed(evt);
   }
  });

  CB_UpdateStock.setText("Perbarui Stok");
  CB_UpdateStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_UpdateStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpdateStockKeyPressed(evt);
   }
  });

  TF_MinStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_MinStockKeyPressed(evt);
   }
  });

  CB_MinStock.setText("~ Stok Minimal");
  CB_MinStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_MinStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_MinStockKeyPressed(evt);
   }
  });

  Lbl_MinStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MinStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_MinStockHelp.setText("(?)");
  Lbl_MinStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_MinStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_MinStockHelpMouseClicked(evt);
   }
  });

  TF_MaxStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_MaxStockKeyPressed(evt);
   }
  });

  CB_MaxStock.setText("~ Stok Maksimal");
  CB_MaxStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_MaxStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_MaxStockKeyPressed(evt);
   }
  });

  Lbl_MaxStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MaxStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_MaxStockHelp.setText("(?)");
  Lbl_MaxStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_MaxStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_MaxStockHelpMouseClicked(evt);
   }
  });

  TF_OrderEachPackQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackQtyKeyPressed(evt);
   }
  });

  CB_OrderEachPackQty.setText("~ Order Qty / Pak");
  CB_OrderEachPackQty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderEachPackQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderEachPackQtyKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackQtyHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackQtyHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackQtyHelp.setText("(?)");
  Lbl_OrderEachPackQtyHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackQtyHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackQtyHelpMouseClicked(evt);
   }
  });

  jLabel5.setText("%");

  TF_OrderEachPackThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackThresholdKeyPressed(evt);
   }
  });

  CB_OrderEachPackThreshold.setText("~ Pembulatan / Pak");
  CB_OrderEachPackThreshold.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderEachPackThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderEachPackThresholdKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackThresholdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackThresholdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackThresholdHelp.setText("(?)");
  Lbl_OrderEachPackThresholdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackThresholdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackThresholdHelpMouseClicked(evt);
   }
  });

  CB_OrderMinPack.setText("~ Order Min Pak");
  CB_OrderMinPack.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderMinPack.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderMinPackKeyPressed(evt);
   }
  });

  Lbl_OrderMinPackHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderMinPackHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderMinPackHelp.setText("(?)");
  Lbl_OrderMinPackHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderMinPackHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderMinPackHelpMouseClicked(evt);
   }
  });

  TF_OrderMinPack.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderMinPackKeyPressed(evt);
   }
  });

  RG_IsReorder.add(RB_IsReorderY);
  RB_IsReorderY.setText("Ya");
  RB_IsReorderY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsReorderY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsReorderYKeyPressed(evt);
   }
  });

  RG_IsReorder.add(RB_IsReorderN);
  RB_IsReorderN.setText("Tidak");
  RB_IsReorderN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsReorderN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsReorderNKeyPressed(evt);
   }
  });

  CB_IsReorder.setText("Di-Reorder");
  CB_IsReorder.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsReorder.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsReorderKeyPressed(evt);
   }
  });

  CB_IsOpname.setText("Di-Opname");
  CB_IsOpname.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsOpname.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsOpnameKeyPressed(evt);
   }
  });

  RG_IsOpname.add(RB_IsOpnameY);
  RB_IsOpnameY.setLabel("Ya");
  RB_IsOpnameY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsOpnameY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsOpnameYKeyPressed(evt);
   }
  });

  RG_IsOpname.add(RB_IsOpnameN);
  RB_IsOpnameN.setLabel("Tidak");
  RB_IsOpnameN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsOpnameN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsOpnameNKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(CB_StockUnit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_Stock)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_StockHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_MinStock)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_MinStockHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_MaxStock)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_MaxStockHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_OrderEachPackQty)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderEachPackQtyHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_OrderEachPackThreshold)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderEachPackThresholdHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_OrderMinPack)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderMinPackHelp))
     .addComponent(CB_UpdateStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_IsReorder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_IsOpname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_OrderMinPack)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(TF_OrderEachPackThreshold)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel5))
     .addComponent(TF_MinStock, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_MaxStock, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(TF_StockUnit)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseStockUnit)
      .addGap(3, 3, 3)
      .addComponent(Btn_ClearStockUnit))
     .addComponent(TF_OrderEachPackQty, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_Stock)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(jPanel8Layout.createSequentialGroup()
        .addComponent(RB_IsOpnameY)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(RB_IsOpnameN))
       .addGroup(jPanel8Layout.createSequentialGroup()
        .addComponent(RB_IsReorderY)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(RB_IsReorderN))
       .addGroup(jPanel8Layout.createSequentialGroup()
        .addComponent(RB_UpdateStockY)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(RB_UpdateStockN)))
      .addGap(0, 0, Short.MAX_VALUE))))
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_ClearStockUnit)
     .addComponent(Btn_ChooseStockUnit)
     .addComponent(TF_StockUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_StockUnit))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_UpdateStockY)
     .addComponent(RB_UpdateStockN)
     .addComponent(CB_UpdateStock))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addGap(1, 1, 1)
      .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(CB_Stock)
       .addComponent(Lbl_StockHelp))))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_MinStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_MinStock)
     .addComponent(Lbl_MinStockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_MaxStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_MaxStock)
     .addComponent(Lbl_MaxStockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_IsOpname)
     .addComponent(RB_IsOpnameY)
     .addComponent(RB_IsOpnameN))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_IsReorderY)
     .addComponent(RB_IsReorderN)
     .addComponent(CB_IsReorder))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OrderEachPackQty)
     .addComponent(CB_OrderEachPackQty)
     .addComponent(Lbl_OrderEachPackQtyHelp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel5)
     .addComponent(TF_OrderEachPackThreshold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OrderEachPackThreshold)
     .addComponent(Lbl_OrderEachPackThresholdHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_OrderMinPack)
     .addComponent(Lbl_OrderMinPackHelp)
     .addComponent(TF_OrderMinPack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator4)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(layout.createSequentialGroup()
      .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jSeparator2)
     .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addGap(18, 18, 18)
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Lbl_MinStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_MinStockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_MinStockHelpMouseClicked

 private void Lbl_MaxStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_MaxStockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_MaxStockHelpMouseClicked

 private void Lbl_CommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true)+"\n"+
   "- Dalam mode 'Ganti Sub-Kata', inputan 'Ganti Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Keterangan' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_CommentHelpMouseClicked

 private void Lbl_SellHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_SellHelpMouseClicked

 private void Lbl_SellCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true)+"\n"+
   "- Dalam mode 'Ganti Sub-Kata', inputan 'Ganti Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Ket Hrg Jual' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_SellCommentHelpMouseClicked

 private void Lbl_BuyCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true)+"\n"+
   "- Dalam mode 'Ganti Sub-Kata', inputan 'Ganti Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Ket Hrg Beli' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_BuyCommentHelpMouseClicked

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   
   StockUnitId=-1;
   
   Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data Barang");
   
   TF_MinStock.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  DialogResult=0;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrCheck=false;
  String str;
  double dbl=0;
  int it;
  
  ChangeId=CB_Id.isSelected();
  ChangeName=CB_Name.isSelected();
  ChangeIsActive=CB_Active.isSelected();
  ChangeComment=CB_Comment.isSelected();
  
  ChangeStockUnit=CB_StockUnit.isSelected();
  ChangeStock=CB_Stock.isSelected();
  ChangeUpdateStock=CB_UpdateStock.isSelected();
  ChangeMinStock=CB_MinStock.isSelected();
  ChangeMaxStock=CB_MaxStock.isSelected();
  
  ChangeIsOpname=CB_IsOpname.isSelected();
  ChangeIsReorder=CB_IsReorder.isSelected();
  ChangeOrderMinPack=CB_OrderMinPack.isSelected();
  ChangeOrderEachPackQty=CB_OrderEachPackQty.isSelected();
  ChangeOrderEachPackThreshold=CB_OrderEachPackThreshold.isSelected();
  
  ChangeHasExpireDate=CB_Expire.isSelected();
  ChangeExpireCheckPeriod=CB_ExpireCheckPeriod.isSelected();
  ChangeExpireThreshold=CB_ExpireThreshold.isSelected();
  
  ChangeSellPrice=CB_Sell.isSelected();
  ChangeSellPriceComment=CB_SellComment.isSelected();
  ChangeSellUpdate=CB_SellUpdate.isSelected();
  ChangeBuyPriceEst=CB_BuyPriceEst.isSelected();
  ChangeBuyPriceComment=CB_BuyComment.isSelected();
  ChangeBuyUpdate=CB_BuyUpdate.isSelected();
  
  ChangeOpStock=CB_OpStock.isSelected();
  ChangeOpExpire=CB_OpExpire.isSelected();
  ChangeOrderQty=CB_OrderQty.isSelected();
  
  if(
   !ChangeId && !ChangeName && !ChangeIsActive && !ChangeComment &&
   !ChangeStockUnit && !ChangeStock && !ChangeUpdateStock && !ChangeMinStock && !ChangeMaxStock &&
   !ChangeIsOpname && !ChangeIsReorder && !ChangeOrderMinPack && !ChangeOrderEachPackQty && !ChangeOrderEachPackThreshold &&
   !ChangeHasExpireDate && !ChangeExpireCheckPeriod && !ChangeExpireThreshold &&
   !ChangeSellPrice && !ChangeSellPriceComment && !ChangeSellUpdate && !ChangeBuyPriceEst && !ChangeBuyPriceComment && !ChangeBuyUpdate &&
   !ChangeOpStock && !ChangeOpExpire && !ChangeOrderQty){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  // check input validity
  IsValid=true;
  
  if(ChangeId){
   IdOption=getInputOfIdOption();
  }
  
  if(ChangeName){
   NameFind=TF_NameFind.getText();
   if(NameFind.length()==0){IsValid=false; CB_Name.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_Name.setForeground(CGUI.Color_Label_InputPrimary);
    NameReplace=TF_NameReplace.getText();
   }
  }
  
  if(ChangeIsActive){IsActive=RB_ActiveY.isSelected();}
  
  if(ChangeComment){
   Comment=TA_Comment.getText();
   ChangeCommentSubString=CB_CommentSub.isSelected();
   if(!ChangeCommentSubString){CurrCheck=PText.checkInput(Comment, true, CApp.DbVarcharMaxSize, 0, 1, 1, 0);}
   else{
    CommentFind=TF_CommentSub.getText();
    CurrCheck=CommentFind.length()!=0;
   }
   if(!CurrCheck){IsValid=false; CB_Comment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Comment.setForeground(CGUI.Color_Label_InputSecondary);}
  }
  
  if(ChangeStock){
   if(!PText.checkInput(TF_Stock.getText(), false, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){IsValid=false; CB_Stock.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_Stock.setForeground(CGUI.Color_Label_InputPrimary);
    Stock=Double.parseDouble(TF_Stock.getText());
   }
  }
  
  if(ChangeUpdateStock){UpdateStock=RB_UpdateStockY.isSelected();}
  
  if(ChangeMinStock){
   if(!PText.checkInput(TF_MinStock.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)){IsValid=false; CB_MinStock.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_MinStock.setForeground(CGUI.Color_Label_InputPrimary);
    MinStock=Double.parseDouble(TF_MinStock.getText());
   }
  }
  
  if(ChangeMaxStock){
   if(!PText.checkInput(TF_MaxStock.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)){IsValid=false; CB_MaxStock.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_MaxStock.setForeground(CGUI.Color_Label_InputPrimary);
    MaxStock=Double.parseDouble(TF_MaxStock.getText());
   }
  }
  
  if(ChangeIsOpname){IsOpname=RB_IsOpnameY.isSelected();}
  
  if(ChangeIsReorder){IsReorder=RB_IsReorderY.isSelected();}
  
  if(ChangeOrderMinPack){
   if(!PText.checkInput(TF_OrderMinPack.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 7)){IsValid=false; CB_OrderMinPack.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_OrderMinPack.setForeground(CGUI.Color_Label_InputSecondary);
    OrderMinPack=Double.parseDouble(TF_OrderMinPack.getText());
   }
  }
  
  if(ChangeOrderEachPackQty){
   if(!PText.checkInput(TF_OrderEachPackQty.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 7)){IsValid=false; CB_OrderEachPackQty.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_OrderEachPackQty.setForeground(CGUI.Color_Label_InputPrimary);
    OrderEachPackQty=Double.parseDouble(TF_OrderEachPackQty.getText());
   }
  }
  
  if(ChangeOrderEachPackThreshold){
   CurrCheck=false;
   do{
    if(!PText.checkInput(TF_OrderEachPackThreshold.getText(), false, CCore.CharsCount_DoublePercentage(), 6, 6, 6, 7)){break;}
    dbl=Double.parseDouble(TF_OrderEachPackThreshold.getText());
    if(!(dbl>0 && dbl<=100)){break;}
    CurrCheck=true;
   }while(false);
   if(!CurrCheck){IsValid=false; CB_OrderEachPackThreshold.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_OrderEachPackThreshold.setForeground(CGUI.Color_Label_InputSecondary);
    OrderEachPackThreshold=dbl;
   }
  }
  
  if(ChangeHasExpireDate){HasExpireDate=RB_ExpireY.isSelected();}
  
  if(ChangeExpireCheckPeriod){
   if(!PText.checkInput(TF_ExpireCheckPeriod.getText(), true, CCore.CharsCount_Int(), 2, 7, 0, 0)){IsValid=false; CB_ExpireCheckPeriod.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_ExpireCheckPeriod.setForeground(CGUI.Color_Label_InputPrimary);
    ExpireCheckPeriod=PText.parseInt(TF_ExpireCheckPeriod.getText(), -1, -1);
   }
  }
  
  if(ChangeExpireThreshold){
   if(!PText.checkInput(TF_ExpireThreshold.getText(), true, CCore.CharsCount_Int(), 2, 3, 0, 0)){IsValid=false; CB_ExpireThreshold.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_ExpireThreshold.setForeground(CGUI.Color_Label_InputPrimary);
    ExpireThreshold=PText.parseInt(TF_ExpireThreshold.getText(), -1, -1);
   }
  }
  
  if(ChangeSellPrice){
   if(!PText.checkInput(TF_Sell.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)){IsValid=false; CB_Sell.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_Sell.setForeground(CGUI.Color_Label_InputPrimary);
    SellPrice=Double.parseDouble(TF_Sell.getText());
   }
  }
  
  if(ChangeSellPriceComment){
   SellPriceComment=TA_SellComment.getText();
   ChangeSellPriceCommentSubString=CB_SellCommentSub.isSelected();
   if(!ChangeSellPriceCommentSubString){CurrCheck=PText.checkInput(SellPriceComment, true, CApp.DbVarcharMaxSize, 0, 1, 1, 0);}
   else{
    SellPriceCommentFind=TF_SellCommentSub.getText();
    CurrCheck=SellPriceCommentFind.length()!=0;
   }
   if(!CurrCheck){IsValid=false; CB_SellComment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_SellComment.setForeground(CGUI.Color_Label_InputSecondary);}
  }
  
  if(ChangeSellUpdate){
   CurrCheck=true;
   SellUpdate=null;
   if(CB_SellUpdateOn.isSelected()){
    SellUpdate=PGUI.valueOfDateComponent(TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay);
    CurrCheck=SellUpdate!=null;
   }
   if(!CurrCheck){IsValid=false; CB_SellUpdate.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_SellUpdate.setForeground(CGUI.Color_Label_InputSecondary);}
  }
  
  if(ChangeBuyPriceEst){
   if(!PText.checkInput(TF_BuyPriceEst.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)){IsValid=false; CB_BuyPriceEst.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_BuyPriceEst.setForeground(CGUI.Color_Label_InputPrimary);
    BuyPriceEst=Double.parseDouble(TF_BuyPriceEst.getText());
   }
  }
  
  if(ChangeBuyPriceComment){
   BuyPriceComment=TA_BuyComment.getText();
   ChangeBuyPriceCommentSubString=CB_BuyCommentSub.isSelected();
   if(!ChangeBuyPriceCommentSubString){CurrCheck=PText.checkInput(BuyPriceComment, true, CApp.DbVarcharMaxSize, 0, 1, 1, 0);}
   else{
    BuyPriceCommentFind=TF_BuyCommentSub.getText();
    CurrCheck=BuyPriceCommentFind.length()!=0;
   }
   if(!CurrCheck){IsValid=false; CB_BuyComment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_BuyComment.setForeground(CGUI.Color_Label_InputSecondary);}
  }
  
  if(ChangeBuyUpdate){
   CurrCheck=true;
   BuyUpdate=null;
   if(CB_BuyUpdateOn.isSelected()){
    BuyUpdate=PGUI.valueOfDateComponent(TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay);
    CurrCheck=BuyUpdate!=null;
   }
   if(!CurrCheck){IsValid=false; CB_BuyUpdate.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_BuyUpdate.setForeground(CGUI.Color_Label_InputSecondary);}
  }
  
  if(ChangeOpStock){
   str=TF_OpStock.getText();
   if(!PText.checkInput(str, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){IsValid=false; CB_OpStock.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_OpStock.setForeground(CGUI.Color_Label_InputSecondary);
    if(str.length()==0){OpStock=null;}else{OpStock=Double.parseDouble(str);}
   }
  }
  
  if(ChangeOpExpire){
   CurrCheck=true;
   OpExpire=null;
   if(CB_OpExpireOn.isSelected()){
    OpExpire=PGUI.valueOfDateComponent(TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay);
    CurrCheck=OpExpire!=null;
   }
   if(!CurrCheck){IsValid=false; CB_OpExpire.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_OpExpire.setForeground(CGUI.Color_Label_InputSecondary);}
  }
  
  if(ChangeOrderQty){
   str=TF_OrderQty.getText();
   if(!PText.checkInput(str, true, CCore.CharsCount_Deci(), 6, 6, 6, 6)){IsValid=false; CB_OrderQty.setForeground(CGUI.Color_Label_InputWrong);}
   else{
    CB_OrderQty.setForeground(CGUI.Color_Label_InputSecondary);
    if(str.length()==0){OrderQty=-1;}else{OrderQty=Double.parseDouble(str);}
   }
  }
  
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+
    "Silahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_ClearStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearStockUnitActionPerformed
  StockUnitId=-1;
  TF_StockUnit.setText("");
 }//GEN-LAST:event_Btn_ClearStockUnitActionPerformed

 private void Btn_ChooseStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseStockUnitActionPerformed
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=false;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblStockUnit;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   StockUnitId=(int)IFV.FDataIdName.DataId[0];
   StockUnitName=IFV.FDataIdName.DataName[0];
   TF_StockUnit.setText(StockUnitName);
  }
 }//GEN-LAST:event_Btn_ChooseStockUnitActionPerformed

 private void Lbl_ExpireThresholdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpireThresholdHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Peringatan kadaluarsa .... hari menjelang tanggal kadaluarsa.\n"+
   "- Data di-input dalam satuan hari.\n"+
   PText.getInputInfo(true, 9, 2, 3, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpireThresholdHelpMouseClicked

 private void Lbl_ExpireCheckPeriodHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpireCheckPeriodHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Lakukan pengecekan kadaluarsa setiap .... hari.\n"+
   "- Data di-input dalam satuan hari.\n"+
   PText.getInputInfo(true, 9, 2, 7, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpireCheckPeriodHelpMouseClicked

 private void Lbl_NameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_NameHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Inputan 'Sub-Kata' harus diisi, sedangkan\n"+
   "  inputan 'Diganti' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_NameHelpMouseClicked

 private void CB_CommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_CommentSubActionPerformed
  enableInputInTextField(CB_CommentSub.isSelected(), TF_CommentSub);
 }//GEN-LAST:event_CB_CommentSubActionPerformed

 private void CB_SellCommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellCommentSubActionPerformed
  enableInputInTextField(CB_SellCommentSub.isSelected(), TF_SellCommentSub);
 }//GEN-LAST:event_CB_SellCommentSubActionPerformed

 private void CB_BuyCommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyCommentSubActionPerformed
  enableInputInTextField(CB_BuyCommentSub.isSelected(), TF_BuyCommentSub);
 }//GEN-LAST:event_CB_BuyCommentSubActionPerformed

 private void CB_OpExpireOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OpExpireOnActionPerformed
  enableInputInDateComponents(CB_OpExpireOn.isSelected(), TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay);
 }//GEN-LAST:event_CB_OpExpireOnActionPerformed

 private void Lbl_OpStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OpStockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_OpStockHelpMouseClicked

 private void Lbl_BuyPriceEstMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceEstMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPriceEstMouseClicked

 private void Lbl_OrderQtyHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderQtyHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_OrderQtyHelpMouseClicked

 private void CB_BuyUpdateOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyUpdateOnActionPerformed
  enableInputInDateComponents(CB_BuyUpdateOn.isSelected(), TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay);
 }//GEN-LAST:event_CB_BuyUpdateOnActionPerformed

 private void CB_SellUpdateOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellUpdateOnActionPerformed
  enableInputInDateComponents(CB_SellUpdateOn.isSelected(), TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay);
 }//GEN-LAST:event_CB_SellUpdateOnActionPerformed

 private void Btn_SellUpdateSetTodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SellUpdateSetTodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_SellUpdateOn, TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay, false);
 }//GEN-LAST:event_Btn_SellUpdateSetTodayActionPerformed

 private void Btn_BuyUpdateSetTodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_BuyUpdateSetTodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_BuyUpdateOn, TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay, false);
 }//GEN-LAST:event_Btn_BuyUpdateSetTodayActionPerformed

 private void Lbl_OrderEachPackThresholdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackThresholdHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Bulatkan menjadi 1 pak jika 'sisa perhitungan' >= 'n' % x 'Order Qty / Pak'."+"\n"+
   "- Jangkauan nilai 'n' adalah 0 < 'n' <= 100."+"\n"+
   PText.getInputInfo(false, 6, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackThresholdHelpMouseClicked

 private void Lbl_OrderMinPackHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderMinPackHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderMinPackHelpMouseClicked

 private void Lbl_OrderEachPackQtyHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackQtyHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackQtyHelpMouseClicked

 private void Lbl_StockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_StockHelpMouseClicked

 private void CB_IdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IdKeyPressed
  PNav.onKey_CB(this, CB_Id, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Name)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IdOption)));
 }//GEN-LAST:event_CB_IdKeyPressed

 private void CmB_IdOptionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IdOptionKeyPressed
  PNav.onKey_CmB(this, CmB_IdOption, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_CmB_IdOptionKeyPressed

 private void CB_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_NameKeyPressed
  PNav.onKey_CB(this, CB_Name, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Id)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Active)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_NameFind)));
 }//GEN-LAST:event_CB_NameKeyPressed

 private void TF_NameFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameFindKeyPressed
  PNav.onKey_TF(this, TF_NameFind, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_IdOption)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_NameReplace)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Name)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_NameFindKeyPressed

 private void TF_NameReplaceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameReplaceKeyPressed
  PNav.onKey_TF(this, TF_NameReplace, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ActiveY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Name)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_NameReplaceKeyPressed

 private void CB_ActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ActiveKeyPressed
  PNav.onKey_CB(this, CB_Active, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ActiveY)));
 }//GEN-LAST:event_CB_ActiveKeyPressed

 private void RB_ActiveYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ActiveYKeyPressed
  PNav.onKey_RB(this, RB_ActiveY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameReplace)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Active)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ActiveN)));
 }//GEN-LAST:event_RB_ActiveYKeyPressed

 private void RB_ActiveNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ActiveNKeyPressed
  PNav.onKey_RB(this, RB_ActiveN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameReplace)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ActiveY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_RB_ActiveNKeyPressed

 private void CB_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentKeyPressed
  PNav.onKey_CB(this, CB_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Active)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockUnit)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)));
 }//GEN-LAST:event_CB_CommentKeyPressed

 private void TF_CommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CommentSubKeyPressed
  PNav.onKey_TF(this, TF_CommentSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ActiveY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_CommentSub)));
 }//GEN-LAST:event_TF_CommentSubKeyPressed

 private void CB_CommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentSubKeyPressed
  PNav.onKey_CB(this, CB_CommentSub, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ActiveY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CommentSub, CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_CB_CommentSubKeyPressed

 private void TA_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentKeyPressed
  PNav.onKey_TA(this, TA_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TA_CommentKeyPressed

 private void CB_StockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockUnitKeyPressed
  PNav.onKey_CB(this, CB_StockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_UpdateStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseStockUnit)));
 }//GEN-LAST:event_CB_StockUnitKeyPressed

 private void Btn_ChooseStockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseStockUnitKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseStockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_UpdateStockY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearStockUnit)));
 }//GEN-LAST:event_Btn_ChooseStockUnitKeyPressed

 private void Btn_ClearStockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearStockUnitKeyPressed
  PNav.onKey_Btn(this, Btn_ClearStockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_UpdateStockY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_Btn_ClearStockUnitKeyPressed

 private void CB_UpdateStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpdateStockKeyPressed
  PNav.onKey_CB(this, CB_UpdateStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Stock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_UpdateStockY)));
 }//GEN-LAST:event_CB_UpdateStockKeyPressed

 private void RB_UpdateStockYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_UpdateStockYKeyPressed
  PNav.onKey_RB(this, RB_UpdateStockY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Stock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_UpdateStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_UpdateStockN)));
 }//GEN-LAST:event_RB_UpdateStockYKeyPressed

 private void RB_UpdateStockNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_UpdateStockNKeyPressed
  PNav.onKey_RB(this, RB_UpdateStockN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Stock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_UpdateStockY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_RB_UpdateStockNKeyPressed

 private void CB_StockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockKeyPressed
  PNav.onKey_CB(this, CB_Stock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_UpdateStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_MinStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Stock)));
 }//GEN-LAST:event_CB_StockKeyPressed

 private void TF_StockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockKeyPressed
  PNav.onKey_TF(this, TF_Stock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_UpdateStockY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_MinStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Stock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_StockKeyPressed

 private void CB_MinStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_MinStockKeyPressed
  PNav.onKey_CB(this, CB_MinStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Stock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_MaxStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_MinStock)));
 }//GEN-LAST:event_CB_MinStockKeyPressed

 private void TF_MinStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_MinStockKeyPressed
  PNav.onKey_TF(this, TF_MinStock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Stock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_MaxStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_MinStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_MinStockKeyPressed

 private void CB_MaxStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_MaxStockKeyPressed
  PNav.onKey_CB(this, CB_MaxStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_MinStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsOpname)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_MaxStock)));
 }//GEN-LAST:event_CB_MaxStockKeyPressed

 private void TF_MaxStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_MaxStockKeyPressed
  PNav.onKey_TF(this, TF_MaxStock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_MinStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsOpnameY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_MaxStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_MaxStockKeyPressed

 private void CB_IsReorderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsReorderKeyPressed
  PNav.onKey_CB(this, CB_IsReorder, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsOpname)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderEachPackQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsReorderY)));
 }//GEN-LAST:event_CB_IsReorderKeyPressed

 private void RB_IsReorderYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsReorderYKeyPressed
  PNav.onKey_RB(this, RB_IsReorderY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsOpnameY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsReorder)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsReorderN)));
 }//GEN-LAST:event_RB_IsReorderYKeyPressed

 private void RB_IsReorderNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsReorderNKeyPressed
  PNav.onKey_RB(this, RB_IsReorderN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsOpnameN)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsReorderY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_RB_IsReorderNKeyPressed

 private void CB_OrderEachPackQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderEachPackQtyKeyPressed
  PNav.onKey_CB(this, CB_OrderEachPackQty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsReorder)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderEachPackThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQty)));
 }//GEN-LAST:event_CB_OrderEachPackQtyKeyPressed

 private void TF_OrderEachPackQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackQty, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsReorderY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderEachPackQty)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_OrderEachPackQtyKeyPressed

 private void CB_OrderEachPackThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderEachPackThresholdKeyPressed
  PNav.onKey_CB(this, CB_OrderEachPackThreshold, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderEachPackQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderMinPack)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackThreshold)));
 }//GEN-LAST:event_CB_OrderEachPackThresholdKeyPressed

 private void TF_OrderEachPackThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackThreshold, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderMinPack)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderEachPackThreshold)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_OrderEachPackThresholdKeyPressed

 private void CB_OrderMinPackKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderMinPackKeyPressed
  PNav.onKey_CB(this, CB_OrderMinPack, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderEachPackThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Expire)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderMinPack)));
 }//GEN-LAST:event_CB_OrderMinPackKeyPressed

 private void TF_OrderMinPackKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderMinPackKeyPressed
  PNav.onKey_TF(this, TF_OrderMinPack, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ExpireY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderMinPack)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_TF_OrderMinPackKeyPressed

 private void CB_ExpireKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpireKeyPressed
  PNav.onKey_CB(this, CB_Expire, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderMinPack)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ExpireCheckPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ExpireY)));
 }//GEN-LAST:event_CB_ExpireKeyPressed

 private void RB_ExpireYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ExpireYKeyPressed
  PNav.onKey_RB(this, RB_ExpireY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderMinPack)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpireCheckPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Expire)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ExpireN)));
 }//GEN-LAST:event_RB_ExpireYKeyPressed

 private void RB_ExpireNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ExpireNKeyPressed
  PNav.onKey_RB(this, RB_ExpireN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderMinPack)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpireCheckPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ExpireY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_RB_ExpireNKeyPressed

 private void CB_ExpireCheckPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpireCheckPeriodKeyPressed
  PNav.onKey_CB(this, CB_ExpireCheckPeriod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Expire)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ExpireThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpireCheckPeriod)));
 }//GEN-LAST:event_CB_ExpireCheckPeriodKeyPressed

 private void TF_ExpireCheckPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpireCheckPeriodKeyPressed
  PNav.onKey_TF(this, TF_ExpireCheckPeriod, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ExpireY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpireThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ExpireCheckPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpireCheckPeriodKeyPressed

 private void CB_ExpireThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpireThresholdKeyPressed
  PNav.onKey_CB(this, CB_ExpireThreshold, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ExpireCheckPeriod)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Sell)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpireThreshold)));
 }//GEN-LAST:event_CB_ExpireThresholdKeyPressed

 private void TF_ExpireThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpireThresholdKeyPressed
  PNav.onKey_TF(this, TF_ExpireThreshold, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpireCheckPeriod)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Sell)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ExpireThreshold)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpireThresholdKeyPressed

 private void CB_SellKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellKeyPressed
  PNav.onKey_CB(this, CB_Sell, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ExpireThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Sell)));
 }//GEN-LAST:event_CB_SellKeyPressed

 private void TF_SellKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellKeyPressed
  PNav.onKey_TF(this, TF_Sell, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpireThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Sell)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_SellKeyPressed

 private void CB_SellUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateKeyPressed
  PNav.onKey_CB(this, CB_SellUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_SellUpdateOn)));
 }//GEN-LAST:event_CB_SellUpdateKeyPressed

 private void CB_SellUpdateOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateOnKeyPressed
  PNav.onKey_CB(this, CB_SellUpdateOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellCommentSub, CB_SellCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellUpdateYear, Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_CB_SellUpdateOnKeyPressed

 private void TF_SellUpdateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellUpdateYearKeyPressed
  PNav.onKey_TF(this, TF_SellUpdateYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellCommentSub, CB_SellCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateMonth, Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_TF_SellUpdateYearKeyPressed

 private void CmB_SellUpdateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateMonthKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellUpdateYear, CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateDay, Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_CmB_SellUpdateMonthKeyPressed

 private void CmB_SellUpdateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateDayKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SellUpdateMonth, CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_CmB_SellUpdateDayKeyPressed

 private void Btn_SellUpdateSetTodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_SellUpdateSetTodayKeyPressed
  PNav.onKey_Btn(this, Btn_SellUpdateSetToday, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellCommentSub, CB_SellCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SellUpdateDay, CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_SellUpdateSetTodayKeyPressed

 private void CB_SellCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellCommentKeyPressed
  PNav.onKey_CB(this, CB_SellComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyPriceEst)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellCommentSub, CB_SellCommentSub)));
 }//GEN-LAST:event_CB_SellCommentKeyPressed

 private void TF_SellCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellCommentSubKeyPressed
  PNav.onKey_TF(this, TF_SellCommentSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_SellCommentSub)));
 }//GEN-LAST:event_TF_SellCommentSubKeyPressed

 private void CB_SellCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellCommentSubKeyPressed
  PNav.onKey_CB(this, CB_SellCommentSub, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellCommentSub, CB_SellComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_SellCommentSubKeyPressed

 private void TA_SellCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_SellCommentKeyPressed
  PNav.onKey_TA(this, TA_SellComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellCommentSub, CB_SellCommentSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_SellCommentKeyPressed

 private void CB_BuyPriceEstKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyPriceEstKeyPressed
  PNav.onKey_CB(this, CB_BuyPriceEst, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPriceEst)));
 }//GEN-LAST:event_CB_BuyPriceEstKeyPressed

 private void TF_BuyPriceEstKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceEst, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_SellComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyPriceEst)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPriceEstKeyPressed

 private void CB_BuyUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_BuyUpdateOn)));
 }//GEN-LAST:event_CB_BuyUpdateKeyPressed

 private void CB_BuyUpdateOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateOnKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdateOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyCommentSub, CB_BuyCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateYear, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CB_BuyUpdateOnKeyPressed

 private void TF_BuyUpdateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateYearKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyCommentSub, CB_BuyCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateMonth, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_TF_BuyUpdateYearKeyPressed

 private void CmB_BuyUpdateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateMonthKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateYear, CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateDay, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CmB_BuyUpdateMonthKeyPressed

 private void CmB_BuyUpdateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDayKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateMonth, CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CmB_BuyUpdateDayKeyPressed

 private void Btn_BuyUpdateSetTodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_BuyUpdateSetTodayKeyPressed
  PNav.onKey_Btn(this, Btn_BuyUpdateSetToday, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyCommentSub, CB_BuyCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateDay, CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_BuyUpdateSetTodayKeyPressed

 private void CB_BuyCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyCommentKeyPressed
  PNav.onKey_CB(this, CB_BuyComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyCommentSub, CB_BuyCommentSub)));
 }//GEN-LAST:event_CB_BuyCommentKeyPressed

 private void TF_BuyCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyCommentSubKeyPressed
  PNav.onKey_TF(this, TF_BuyCommentSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_BuyCommentSub)));
 }//GEN-LAST:event_TF_BuyCommentSubKeyPressed

 private void CB_BuyCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyCommentSubKeyPressed
  PNav.onKey_CB(this, CB_BuyCommentSub, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyCommentSub, CB_BuyComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_BuyCommentSubKeyPressed

 private void TA_BuyCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyCommentKeyPressed
  PNav.onKey_TA(this, TA_BuyComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyCommentSub, CB_BuyCommentSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyCommentKeyPressed

 private void CB_OpStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpStockKeyPressed
  PNav.onKey_CB(this, CB_OpStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExpire)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpStock)));
 }//GEN-LAST:event_CB_OpStockKeyPressed

 private void TF_OpStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpStockKeyPressed
  PNav.onKey_TF(this, TF_OpStock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExpireOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OpStockKeyPressed

 private void CB_OpExpireKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpireKeyPressed
  PNav.onKey_CB(this, CB_OpExpire, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_OpExpireOn)));
 }//GEN-LAST:event_CB_OpExpireKeyPressed

 private void CB_OpExpireOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpireOnKeyPressed
  PNav.onKey_CB(this, CB_OpExpireOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExpire)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpExpireYear)));
 }//GEN-LAST:event_CB_OpExpireOnKeyPressed

 private void TF_OpExpireYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpExpireYearKeyPressed
  PNav.onKey_TF(this, TF_OpExpireYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExpireOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpireMonth)));
 }//GEN-LAST:event_TF_OpExpireYearKeyPressed

 private void CmB_OpExpireMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpireMonthKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpireMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpExpireYear, CB_OpExpireOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpireDay)));
 }//GEN-LAST:event_CmB_OpExpireMonthKeyPressed

 private void CmB_OpExpireDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpireDayKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpireDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_OpExpireMonth, CB_OpExpireOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQty)));
 }//GEN-LAST:event_CmB_OpExpireDayKeyPressed

 private void CB_OrderQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderQtyKeyPressed
  PNav.onKey_CB(this, CB_OrderQty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExpire)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQty)));
 }//GEN-LAST:event_CB_OrderQtyKeyPressed

 private void TF_OrderQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderQtyKeyPressed
  PNav.onKey_TF(this, TF_OrderQty, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExpireOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderQty)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderQtyKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void CB_IsOpnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsOpnameKeyPressed
  PNav.onKey_CB(this, CB_IsOpname, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_MaxStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsReorder)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsOpnameY)));
 }//GEN-LAST:event_CB_IsOpnameKeyPressed

 private void RB_IsOpnameYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsOpnameYKeyPressed
  PNav.onKey_RB(this, RB_IsOpnameY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_MaxStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsReorderY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsOpname)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsOpnameN)));
 }//GEN-LAST:event_RB_IsOpnameYKeyPressed

 private void RB_IsOpnameNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsOpnameNKeyPressed
  PNav.onKey_RB(this, RB_IsOpnameN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_MaxStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsReorderN)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsOpnameY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Expire)));
 }//GEN-LAST:event_RB_IsOpnameNKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_BuyUpdateSetToday;
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseStockUnit;
 private javax.swing.JButton Btn_ClearStockUnit;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_SellUpdateSetToday;
 private javax.swing.JCheckBox CB_Active;
 private javax.swing.JCheckBox CB_BuyComment;
 private javax.swing.JCheckBox CB_BuyCommentSub;
 private javax.swing.JCheckBox CB_BuyPriceEst;
 private javax.swing.JCheckBox CB_BuyUpdate;
 private javax.swing.JCheckBox CB_BuyUpdateOn;
 private javax.swing.JCheckBox CB_Comment;
 private javax.swing.JCheckBox CB_CommentSub;
 private javax.swing.JCheckBox CB_Expire;
 private javax.swing.JCheckBox CB_ExpireCheckPeriod;
 private javax.swing.JCheckBox CB_ExpireThreshold;
 private javax.swing.JCheckBox CB_Id;
 private javax.swing.JCheckBox CB_IsOpname;
 private javax.swing.JCheckBox CB_IsReorder;
 private javax.swing.JCheckBox CB_MaxStock;
 private javax.swing.JCheckBox CB_MinStock;
 private javax.swing.JCheckBox CB_Name;
 private javax.swing.JCheckBox CB_OpExpire;
 private javax.swing.JCheckBox CB_OpExpireOn;
 private javax.swing.JCheckBox CB_OpStock;
 private javax.swing.JCheckBox CB_OrderEachPackQty;
 private javax.swing.JCheckBox CB_OrderEachPackThreshold;
 private javax.swing.JCheckBox CB_OrderMinPack;
 private javax.swing.JCheckBox CB_OrderQty;
 private javax.swing.JCheckBox CB_Sell;
 private javax.swing.JCheckBox CB_SellComment;
 private javax.swing.JCheckBox CB_SellCommentSub;
 private javax.swing.JCheckBox CB_SellUpdate;
 private javax.swing.JCheckBox CB_SellUpdateOn;
 private javax.swing.JCheckBox CB_Stock;
 private javax.swing.JCheckBox CB_StockUnit;
 private javax.swing.JCheckBox CB_UpdateStock;
 private javax.swing.JComboBox<String> CmB_BuyUpdateDay;
 private javax.swing.JComboBox<String> CmB_BuyUpdateMonth;
 private javax.swing.JComboBox<String> CmB_IdOption;
 private javax.swing.JComboBox<String> CmB_OpExpireDay;
 private javax.swing.JComboBox<String> CmB_OpExpireMonth;
 private javax.swing.JComboBox<String> CmB_SellUpdateDay;
 private javax.swing.JComboBox<String> CmB_SellUpdateMonth;
 private javax.swing.JLabel Lbl_BuyCommentHelp;
 private javax.swing.JLabel Lbl_BuyPriceEst;
 private javax.swing.JLabel Lbl_CommentHelp;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.JLabel Lbl_ExpireCheckPeriodHelp;
 private javax.swing.JLabel Lbl_ExpireThresholdHelp;
 private javax.swing.JLabel Lbl_MaxStockHelp;
 private javax.swing.JLabel Lbl_MinStockHelp;
 private javax.swing.JLabel Lbl_NameHelp;
 private javax.swing.JLabel Lbl_OpStockHelp;
 private javax.swing.JLabel Lbl_OrderEachPackQtyHelp;
 private javax.swing.JLabel Lbl_OrderEachPackThresholdHelp;
 private javax.swing.JLabel Lbl_OrderMinPackHelp;
 private javax.swing.JLabel Lbl_OrderQtyHelp;
 private javax.swing.JLabel Lbl_SellCommentHelp;
 private javax.swing.JLabel Lbl_SellHelp;
 private javax.swing.JLabel Lbl_StockHelp;
 private javax.swing.JRadioButton RB_ActiveN;
 private javax.swing.JRadioButton RB_ActiveY;
 private javax.swing.JRadioButton RB_ExpireN;
 private javax.swing.JRadioButton RB_ExpireY;
 private javax.swing.JRadioButton RB_IsOpnameN;
 private javax.swing.JRadioButton RB_IsOpnameY;
 private javax.swing.JRadioButton RB_IsReorderN;
 private javax.swing.JRadioButton RB_IsReorderY;
 private javax.swing.JRadioButton RB_UpdateStockN;
 private javax.swing.JRadioButton RB_UpdateStockY;
 private javax.swing.ButtonGroup RG_Active;
 private javax.swing.ButtonGroup RG_Expire;
 private javax.swing.ButtonGroup RG_IsOpname;
 private javax.swing.ButtonGroup RG_IsReorder;
 private javax.swing.ButtonGroup RG_MismatchStock;
 private javax.swing.ButtonGroup RG_Stock;
 private javax.swing.ButtonGroup RG_UpdateStock;
 private javax.swing.JTextArea TA_BuyComment;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextArea TA_SellComment;
 private javax.swing.JTextField TF_BuyCommentSub;
 private javax.swing.JTextField TF_BuyPriceEst;
 private javax.swing.JTextField TF_BuyUpdateYear;
 private javax.swing.JTextField TF_CommentSub;
 private javax.swing.JTextField TF_ExpireCheckPeriod;
 private javax.swing.JTextField TF_ExpireThreshold;
 private javax.swing.JTextField TF_MaxStock;
 private javax.swing.JTextField TF_MinStock;
 private javax.swing.JTextField TF_NameFind;
 private javax.swing.JTextField TF_NameReplace;
 private javax.swing.JTextField TF_OpExpireYear;
 private javax.swing.JTextField TF_OpStock;
 private javax.swing.JTextField TF_OrderEachPackQty;
 private javax.swing.JTextField TF_OrderEachPackThreshold;
 private javax.swing.JTextField TF_OrderMinPack;
 private javax.swing.JTextField TF_OrderQty;
 private javax.swing.JTextField TF_Sell;
 private javax.swing.JTextField TF_SellCommentSub;
 private javax.swing.JTextField TF_SellUpdateYear;
 private javax.swing.JTextField TF_Stock;
 private javax.swing.JTextField TF_StockUnit;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 // End of variables declaration//GEN-END:variables
}
