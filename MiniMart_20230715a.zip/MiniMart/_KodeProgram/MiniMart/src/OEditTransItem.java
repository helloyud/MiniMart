public class OEditTransItem {
 
 boolean EditQuantity; Double EditedQuantity;
 boolean EditPriceUnit; Double EditedPriceUnit;
 boolean EditPriceTotal; Double EditedPriceTotal;
 boolean EditComment; boolean ReplaceSubComment; String SubComment; String EditedComment;

 public OEditTransItem(){clearAll();}
 
 OEditTransItem clearAll(){
  init(
   false, -1,
   false, -1,
   false, -1,
   false, false, null, null);
  
  return this;
 }
 OEditTransItem init(
  boolean EditQuantity, double EditedQuantity,
  boolean EditPriceUnit, double EditedPriceUnit,
  boolean EditPriceTotal, double EditedPriceTotal,
  boolean EditComment, boolean ReplaceSubComment, String SubComment, String EditedComment) {
  
  this.EditQuantity = EditQuantity; this.EditedQuantity = EditedQuantity;
  this.EditPriceUnit = EditPriceUnit; this.EditedPriceUnit = EditedPriceUnit;
  this.EditPriceTotal = EditPriceTotal; this.EditedPriceTotal = EditedPriceTotal;
  this.EditComment = EditComment; this.ReplaceSubComment = ReplaceSubComment; this.SubComment = SubComment; this.EditedComment = EditedComment;
  
  return this;
 }
 
}