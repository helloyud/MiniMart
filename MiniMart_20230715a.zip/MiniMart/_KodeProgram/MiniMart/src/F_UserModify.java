import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_UserModify extends XFormDialog {
 
 Color cfont, cselectedfont;
 
 int wMode; // 1 Add, 2 Reset Password, 3 Modify Own Password
 String wUser;
 
 String User;
 String UserPassword;
 
 public F_UserModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  cfont=TF_User.getForeground();
  cselectedfont=TF_User.getSelectedTextColor();
  
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_User,
    PF_Pass1, PF_Pass2,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
 }
 void clearComponents(){
  TF_User.setText("");
  PF_Pass1.setText("");
  PF_Pass2.setText("");
  clearSetVariables();
 }
 void clearSetVariables(){
  wUser=null;
 }
 
 void enableInputUser(boolean Enable, boolean Visible){
  TF_User.setEditable(Enable);
  if(Enable){
   TF_User.setBackground(CGUI.Color_TextBox_FocusOff);
  }
  else{
   TF_User.setBackground(CGUI.Color_TextBox_Uneditable);
  }
  if(Visible){
   TF_User.setForeground(cfont);
   TF_User.setSelectedTextColor(cselectedfont);
  }
  else{
   TF_User.setForeground(TF_User.getBackground());
   TF_User.setSelectedTextColor(TF_User.getSelectionColor());
  }
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_User = new javax.swing.JTextField();
  Lbl_User = new javax.swing.JLabel();
  PF_Pass1 = new javax.swing.JPasswordField();
  Lbl_Pass = new javax.swing.JLabel();
  PF_Pass2 = new javax.swing.JPasswordField();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_PassInfo = new javax.swing.JLabel();
  Lbl_UserInfo = new javax.swing.JLabel();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_User.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_UserKeyPressed(evt);
   }
  });

  Lbl_User.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_User.setText("User");
  Lbl_User.setFocusable(false);

  PF_Pass1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    PF_Pass1KeyPressed(evt);
   }
  });

  Lbl_Pass.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Pass.setText("Password");
  Lbl_Pass.setFocusable(false);

  PF_Pass2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    PF_Pass2KeyPressed(evt);
   }
  });

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_PassInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PassInfo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_PassInfo.setText("(?)");
  Lbl_PassInfo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_PassInfo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PassInfoMouseClicked(evt);
   }
  });

  Lbl_UserInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_UserInfo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_UserInfo.setText("(?)");
  Lbl_UserInfo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_UserInfo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_UserInfoMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(PF_Pass1)
     .addComponent(PF_Pass2, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_Pass)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 288, Short.MAX_VALUE)
      .addComponent(Lbl_PassInfo))
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_User)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_UserInfo))
     .addComponent(TF_User))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_User)
     .addComponent(Lbl_UserInfo))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_User, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Pass)
     .addComponent(Lbl_PassInfo))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(PF_Pass1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(PF_Pass2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Lbl_PassInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PassInfoMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 50, 0, 1, 1, 0, false));
 }//GEN-LAST:event_Lbl_PassInfoMouseClicked

 private void PF_Pass1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PF_Pass1KeyPressed
  if(!PGUI.isEnabled(PF_Pass1)){return;}
  
  int consumed=PNav.onKey_TF(this, PF_Pass1, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_User)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(PF_Pass2)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_PF_Pass1KeyPressed

 private void PF_Pass2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PF_Pass2KeyPressed
  if(!PGUI.isEnabled(PF_Pass2)){return;}
  
  int consumed=PNav.onKey_TF(this, PF_Pass2, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(PF_Pass1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: Btn_OkActionPerformed(null); break;
  }
 }//GEN-LAST:event_PF_Pass2KeyPressed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean bool;
  String pass=null;
  String usr=null;
  bool=false;
  do{
   // check user
   if(wMode==1 || wMode==3){
    usr=TF_User.getText();
    if(wMode==1){
     if(PText.checkInput(usr, false, 30, 3, 2, 0, 0)==false){break;}
    }
   }
   
   // check password
   pass=new String(PF_Pass1.getPassword());
   if(PText.checkInput(pass, false, 50, 0, 1, 1, 0)==false){break;}
   if(PText.compare(pass, new String(PF_Pass2.getPassword()), true)==false){break;}
   bool=true;
  }while(false);
  if(bool){
   User=usr;
   UserPassword=pass;
   DialogResult=1;
   clearComponents();
   Activ=false;
   setVisible(false);
  }
  else{
   JOptionPane.showMessageDialog(null, "Masukan belum benar !\nCoba periksa kembali !");
  }
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(!Activ){
   Activ=true;
   if(wMode==1){
    setTitle("Tambah User (Dpt Akses Di Komp. Server & Remote)");
    Lbl_User.setText("Masukkan Nama User Baru :");
    enableInputUser(true, true);
    Lbl_Pass.setText("Masukkan Password (Di-input 2 Kali) :");
    Btn_Ok.setText("Buat User Baru {F11}");
    TF_User.requestFocusInWindow();
   }
   else if(wMode==2){
    setTitle("Reset Password User");
    Lbl_User.setText("User :");
    TF_User.setText(wUser);
    enableInputUser(false, true);
    Lbl_Pass.setText("Masukkan Password Baru (Di-input 2 Kali) :");
    Btn_Ok.setText("Reset Password {F11}");
    PF_Pass1.requestFocusInWindow();
   }
   else if(wMode==3){
    setTitle("Ganti Password User Saat Ini");
    Lbl_User.setText("Password Saat Ini :");
    enableInputUser(true, false);
    Lbl_Pass.setText("Masukkan Password Baru (Di-input 2 Kali) :");
    Btn_Ok.setText("Ganti Password {F11}");
    TF_User.requestFocusInWindow();
   }
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
  DialogResult=0;
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_UserInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_UserInfoMouseClicked
  if(!TF_User.isEditable()){return;}
  if(wMode==1){JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 30, 3, 2, 0, 0, true));}
  if(wMode==3){JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 0, 0, 0, 0, 0, false));}
 }//GEN-LAST:event_Lbl_UserInfoMouseClicked

 private void TF_UserKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_UserKeyPressed
  if(!PGUI.isEnabled(TF_User)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_User, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(PF_Pass1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_UserKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(PF_Pass2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(PF_Pass2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed



 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JLabel Lbl_Pass;
 private javax.swing.JLabel Lbl_PassInfo;
 private javax.swing.JLabel Lbl_User;
 private javax.swing.JLabel Lbl_UserInfo;
 private javax.swing.JPasswordField PF_Pass1;
 private javax.swing.JPasswordField PF_Pass2;
 private javax.swing.JTextField TF_User;
 // End of variables declaration//GEN-END:variables
}
