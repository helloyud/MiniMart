import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Vector;

public class ODrawComponentText extends ODrawComponent {
	
 int Mode;
	/*
	 1 = draw 'UnprocessedWord' directly at 'OffsetX, OffsetY'
	 2 = draw 'UnprocessedWord (followed by 'fit in box' operation) / ProcessedWord' within 'Specified Box at OffsetX, OffsetY'
	*/
	
 Font FontType;
	
	boolean IsUnprocessedWord;
	String UnprocessedWord;
	Vector<String> ProcessedWord;
	
	double WordLineSpacing;

	double BoxWidth;
	double BoxHeight;
	OAlignment BoxAlignment;
	
	static OAlignment DefaultAlignment=new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalCenter);

 public ODrawComponentText(double OffsetX, double OffsetY, Font FontType, String UnprocessedWord) {
		this.Mode = 1;
		
  this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
		
  this.FontType = FontType;
		this.UnprocessedWord=UnprocessedWord;
 }
 public ODrawComponentText(double OffsetX, double OffsetY, Font FontType, String UnprocessedWord,
		double BoxWidth, double BoxHeight, double WordLineSpacing, OAlignment BoxAlignment) {
  this.Mode=2;
		
		this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
		
  this.FontType = FontType;
		
		this.IsUnprocessedWord=true;
		this.UnprocessedWord=UnprocessedWord;
		
		this.BoxWidth=BoxWidth;
		this.BoxHeight=BoxHeight;
		this.WordLineSpacing=WordLineSpacing;
		this.BoxAlignment=BoxAlignment;
 }
 public ODrawComponentText(double OffsetX, double OffsetY, Font FontType, Vector<String> ProcessedWord,
		double BoxWidth, double BoxHeight, double WordLineSpacing, OAlignment BoxAlignment) {
  this.Mode=2;
		
		this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
		
  this.FontType = FontType;
		
		this.IsUnprocessedWord=false;
		this.ProcessedWord=ProcessedWord;
		
		this.BoxWidth=BoxWidth;
		this.BoxHeight=BoxHeight;
		this.WordLineSpacing=WordLineSpacing;
		this.BoxAlignment=BoxAlignment;
 }
 
 public void draw(Graphics2D graphics, OGraphicsProperties Prop){
  int temp, linecount, maxchar, maxline;
  double text_size, CurrX, CurrY;
  ODrawInfoString inf;
  String currstr;
  boolean firstline;
		Vector<String> Text;
  
  graphics.setFont(FontType);
		
		if(Mode==1){
			graphics.drawString(UnprocessedWord, (float)OffsetX, (float)OffsetY);
			return;
		}
		
  inf=PGraphics.getDrawInfoString(FontType);
  maxchar=(int)(BoxWidth/inf.SingleCharWidth);
		if(BoxHeight<inf.LineHeight){return;}
		maxline=1+(int)((BoxHeight-inf.LineHeight)/(WordLineSpacing+inf.LineHeight));
		
		Text=ProcessedWord;
		if(IsUnprocessedWord){
			if(maxline==1){
				Text=PCore.vect(PText.fitString(UnprocessedWord, maxchar, true, maxchar/2, 1, '~'));
			}
			else{
				Text=PText.fitMultiLine(PText.multiLine(UnprocessedWord, maxchar), maxline, true, maxline/2, maxchar, true, maxchar/2, 1, '~');
			}
		}
		
  linecount=Text.size();
  
  // calculate coordinate Y's start
  CurrY=OffsetY;
  if(BoxAlignment.AlignmentVertical!=OAlignment.VerticalTop){
   // calculate text's height
   text_size=(linecount*inf.LineHeight)+((linecount-1)*WordLineSpacing);
   if(BoxAlignment.AlignmentVertical==OAlignment.VerticalCenter){CurrY=OffsetY+(BoxHeight/2)-(text_size/2);}
   else{CurrY=OffsetY+BoxHeight-text_size;}
  }
  
  // start drawing
  firstline=true;
  temp=0;
  do{
   if(firstline){firstline=false;}
   else{CurrY=CurrY+WordLineSpacing;}
   
   currstr=Text.elementAt(temp);
   
   // calculate coordinate X's start
   CurrX=OffsetX;
   if(BoxAlignment.AlignmentHorizontal!=OAlignment.HorizontalLeft){
    // calculate text's width
    text_size=PGraphics.getStringWidth(FontType, currstr);
    if(BoxAlignment.AlignmentHorizontal==OAlignment.HorizontalCenter){CurrX=OffsetX+(BoxWidth/2)-(text_size/2);}
    else{CurrX=OffsetX+BoxWidth-text_size;}
   }
   
   graphics.drawString(currstr, (float)CurrX, (float)(CurrY+inf.LineAscent));
   CurrY=CurrY+inf.LineHeight;
   
   temp=temp+1;
  }while(temp!=linecount);
 }
 
 public ODimension calcDrawDimension(){
  ODimension ret=new ODimension();
  ODimension size;
  
  do{
   if(Mode==1){
    size=PGraphics.getStringDimension(FontType, UnprocessedWord);
    ret.setSize(size.getWidth(), size.getHeight());
    break;
   }
   if(Mode==2){
    ret.setSize(BoxWidth, BoxHeight);
    break;
   }
  }while(false);
  
  return ret;
 }
 

}