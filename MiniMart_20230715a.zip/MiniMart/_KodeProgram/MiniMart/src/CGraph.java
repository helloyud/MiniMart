public class CGraph {
 
 public static final int Rotate_000Degree=1;
 public static final int Rotate_090Degree=2;
 public static final int Rotate_180Degree=3;
 public static final int Rotate_270Degree=4;
 
 public static final double BarcodeWidthMin=PMyShop.patternize(0).getBufferedImage(1, 1).getWidth();
 public static final double BarcodeWidthMax=PMyShop.patternize(123456789012345678L).getBufferedImage(1, 1).getWidth();
 public static final double BarcodeHeightMin=OUnit.mm_to_pixel(6);
 public static final double BarcodeHeightMax=OUnit.mm_to_pixel(18.5);
 
}