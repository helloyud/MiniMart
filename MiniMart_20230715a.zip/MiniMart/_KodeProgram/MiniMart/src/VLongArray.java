public class VLongArray {
 
 long[] Value;
 
 public VLongArray(){}
 public VLongArray(long[] Value){this.Value=Value;}
 
}