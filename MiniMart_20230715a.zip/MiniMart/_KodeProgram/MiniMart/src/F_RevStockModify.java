import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_RevStockModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 OCustomComboBoxModel ComboMdlReasonOfRevisi;
 
 // set
 int wMode; // 1 add, 2 edit
 OInfoRevStock wInfoRevStock;
 
 // get
 Date RevDate;
 int ReasonOfRevisiId; String ReasonOfRevisiName;
 
 //
  // Item
 long CheckedItemId, I_CheckedItemId;
 long LastInputId;
 OInfoItem ItemDet, I_ItemDet;
 boolean InputInfoClearedItem;
  // Qty
 double StockOld; Double I_StockOld;
 double StockNew; Double I_StockNew;
 double StockDiff; Double I_StockDiff;
 
 //
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 
 //
 Object[] FocusOrdered;
 
 public F_RevStockModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  ComboMdlReasonOfRevisi=new OCustomComboBoxModel();
  ComboMdlReasonOfRevisi.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_ReasonOfRevisi.setModel(ComboMdlReasonOfRevisi);
  
  //
  EnableDocumentListener=new VBoolean(true);
  
  TF_StockDiff.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputStockDiff();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputStockDiff();
     }
    }
    
   });
  
  EnableDocumentListener.Value=true;
  
  InputInfoClearedItem=true;
  
  //
  I_ItemDet=new OInfoItem();
  
  clearItemId();
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  I_StockDiff=null;
  I_StockNew=null;
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  FocusOrdered=PCore.objArrVariant(
   PCore.cmpArr(TF_RevDateY, CmB_RevDateM, CmB_RevDateD),
   CmB_ReasonOfRevisi,
   PCore.cmpArr(TF_ItemId, Btn_ChooseItem),
   TF_StockDiff,
   PCore.cmpArr(Btn_Ok, Btn_Cancel));
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   FocusOrdered,
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  Lbl_RevDate.setForeground(CGUI.Color_Label_InputRight);
  ComboMdlReasonOfRevisi.removeAll();
  clearInputItem();
  Lbl_ItemId.setForeground(CGUI.Color_Label_InputRight);
  Lbl_StockDiff.setForeground(CGUI.Color_Label_InputRight);
  clearSetVariables();
 }
 void clearSetVariables(){
  
 }
 
 // Input
  // Item
 void clearItemId(){
  TF_ItemId.setText(""); LastInputId=-1; I_CheckedItemId=-1; clearItem();
 }
 boolean changeLastInputId(){
  boolean ret=false;
  long Input;
  String str=TF_ItemId.getText();
  
  // convert input in TF_ItemId to number; if input is empty or false, then value it to -1
  Input=-1;
  if(str.length()!=0){
   try{Input=Long.parseLong(str);}catch(Exception E){Input=-1;}
  }
  
  if(Input!=LastInputId){
   ret=true; LastInputId=Input;
  }
  
  return ret;
 }
 void changeItem(){
  OInfoItem InfoItem;
  
  InfoItem=PMyShop.getItemInfo(IFV.Stm, LastInputId, false);
  if(InfoItem==null){
   I_CheckedItemId=-1; clearItem();
   return;
  }
  
  I_ItemDet=InfoItem;
  I_CheckedItemId=LastInputId;
  
  fillInputInfoItem();
  
  fillInputFromItem();
  
  changeItemQuantityPrice();
  
  setIStockDiff(I_StockDiff, true);
  setIStockNew(I_StockNew, true);
 }
 void inputItem(){
  if(!changeLastInputId()){return;}
  changeItem();
 }
 void changeItemQuantityPrice(){
  if(I_StockDiff==null){
   I_StockDiff=0D; if(I_ItemDet.Stock<0){I_StockDiff=-1*I_ItemDet.Stock;}
   genIStockNew();
  }
 }
 void fillInputInfoItem(){
  String StockUnit;
  
  if(I_CheckedItemId==-1){clearInputInfoItem(); return;}
  
  StockUnit=PText.getString(I_ItemDet.StockUnitName, "", false);
  
  TA_ItemName.setText(I_ItemDet.Name);
  TF_ItemStockOldUnit.setText(StockUnit); CB_ItemUpdateStock.setSelected(I_ItemDet.UpdateStock);
  TF_ItemStockDiffUnit.setText(StockUnit);
  TF_ItemStockNewUnit.setText(StockUnit);
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  PGUI.clearText(TA_ItemName, TF_ItemStockOldUnit, TF_ItemStockDiffUnit, TF_ItemStockNewUnit);
  CB_ItemUpdateStock.setSelected(false);
  
  InputInfoClearedItem=true;
 }
 void clearItem(){
  clearInputInfoItem();
  
  clearInputFromItem();
 }
  // Stock Old
 void setIStockOld(Double Value, boolean ClearInvalidValue){
  I_StockOld=Value;
  
  if(I_StockOld!=null){PGUI.changeDocument(EnableDocumentListener, TF_StockOld, PText.priceToString(I_StockOld));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_StockOld, "");}}
 }
  // Stock New
 void genIStockNew(){I_StockNew=null; if(I_StockOld!=null && I_StockDiff!=null){I_StockNew=I_StockOld+I_StockDiff;}}
 void setIStockNew(Double Value, boolean ClearInvalidValue){
  I_StockNew=Value;
  
  if(I_StockNew!=null){PGUI.changeDocument(EnableDocumentListener, TF_StockNew, PText.priceToString(I_StockNew));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_StockNew, "");}}
 }
  // Stock Diff
 void setIStockDiff(Double Value, boolean ClearInvalidValue){
  I_StockDiff=Value;
  
  if(I_StockDiff!=null){PGUI.changeDocument(EnableDocumentListener, TF_StockDiff, PText.doubleToString(I_StockDiff, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_StockDiff, "");}}
 }
 void inputStockDiff(){
  I_StockDiff=PText.parseDouble(TF_StockDiff.getText(), null, null);
  
  if(I_StockDiff==null){return;}
  
  if(I_StockOld!=null){genIStockNew(); setIStockNew(I_StockNew, true);}
 }
  // Others
 void fillInputFromItem(){
  if(I_CheckedItemId==-1){return;}
  
  setIStockOld(I_ItemDet.Stock, true);
 }
 void clearInputFromItem(){
  setIStockOld(null, true);
 }
 void clearInputItem(){
  EnableDocumentListener.Value=false;
  
  clearItemId();
  setIStockDiff(null, true);
  setIStockNew(null, true);
  
  EnableDocumentListener.Value=true;
 }
 void fillInputVariablesIntoRealVariables(){
  CheckedItemId=I_CheckedItemId;
  ItemDet=I_ItemDet;
  
  StockOld=PCore.objDouble(I_StockOld, 0D);
  StockDiff=PCore.objDouble(I_StockDiff, 0D);
  StockNew=PCore.objDouble(I_StockNew, 0D);
 }
 
 //
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 void initGUI(boolean ModeAdd){
  PGUI.setEnabled(ModeAdd, CGUI.Color_TextBox_FocusOff, CGUI.Color_TextBox_Uneditable, TF_ItemId, TF_StockDiff);
  PGUI.setEnabled(ModeAdd, Btn_ChooseItem);
 }
 
 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_ItemId = new javax.swing.JTextField();
  Lbl_ItemId = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  TF_StockOld = new javax.swing.JTextField();
  TF_StockNew = new javax.swing.JTextField();
  Lbl_StockOld = new javax.swing.JLabel();
  Lbl_StockNew = new javax.swing.JLabel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Btn_ChooseItem = new javax.swing.JButton();
  TF_RevDateY = new javax.swing.JTextField();
  CmB_RevDateM = new javax.swing.JComboBox<>();
  CmB_RevDateD = new javax.swing.JComboBox<>();
  Lbl_RevDate = new javax.swing.JLabel();
  CB_ItemUpdateStock = new javax.swing.JCheckBox();
  TF_ItemStockOldUnit = new javax.swing.JTextField();
  CmB_ReasonOfRevisi = new javax.swing.JComboBox<>();
  Lbl_ReasonOfRevisi = new javax.swing.JLabel();
  TF_ItemStockNewUnit = new javax.swing.JTextField();
  TF_StockDiff = new javax.swing.JTextField();
  Lbl_StockDiff = new javax.swing.JLabel();
  TF_ItemStockDiffUnit = new javax.swing.JTextField();

  setTitle("Ubah Data Revisi-Stok");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_ItemId.setToolTipText("{F6} ket brg {Spasi} cari brg");
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Barang");

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(20);
  TA_ItemName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setRows(1);
  TA_ItemName.setToolTipText("klik utk melihat keterangan barang");
  TA_ItemName.setWrapStyleWord(true);
  TA_ItemName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_ItemName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_ItemNameMouseClicked(evt);
   }
  });
  jScrollPane1.setViewportView(TA_ItemName);

  TF_StockOld.setEditable(false);
  TF_StockOld.setBackground(new java.awt.Color(204, 255, 204));
  TF_StockOld.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  TF_StockNew.setEditable(false);
  TF_StockNew.setBackground(new java.awt.Color(204, 255, 204));
  TF_StockNew.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  Lbl_StockOld.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockOld.setText("Stok Lama");

  Lbl_StockNew.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockNew.setText("Stok Baru");

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });
  Btn_ChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseItemKeyPressed(evt);
   }
  });

  TF_RevDateY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_RevDateYKeyPressed(evt);
   }
  });

  CmB_RevDateM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember" }));
  CmB_RevDateM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_RevDateMKeyPressed(evt);
   }
  });

  CmB_RevDateD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_RevDateD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_RevDateDKeyPressed(evt);
   }
  });

  Lbl_RevDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_RevDate.setText("Tgl Revisi");

  CB_ItemUpdateStock.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  CB_ItemUpdateStock.setText("Diperbarui");
  CB_ItemUpdateStock.setEnabled(false);
  CB_ItemUpdateStock.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TF_ItemStockOldUnit.setEditable(false);
  TF_ItemStockOldUnit.setBackground(new java.awt.Color(204, 255, 204));

  CmB_ReasonOfRevisi.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ReasonOfRevisiKeyPressed(evt);
   }
  });

  Lbl_ReasonOfRevisi.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ReasonOfRevisi.setText("Alasan Revisi");

  TF_ItemStockNewUnit.setEditable(false);
  TF_ItemStockNewUnit.setBackground(new java.awt.Color(204, 255, 204));

  TF_StockDiff.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_StockDiff.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockDiffFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_StockDiffFocusLost(evt);
   }
  });
  TF_StockDiff.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockDiffKeyPressed(evt);
   }
  });

  Lbl_StockDiff.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockDiff.setText("Selisih");

  TF_ItemStockDiffUnit.setEditable(false);
  TF_ItemStockDiffUnit.setBackground(new java.awt.Color(204, 255, 204));

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_ItemId)
       .addComponent(Lbl_StockOld)
       .addComponent(Lbl_StockNew)
       .addComponent(Lbl_RevDate)
       .addComponent(Lbl_ReasonOfRevisi)
       .addComponent(Lbl_StockDiff))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_RevDateY, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_RevDateM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_RevDateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 417, Short.MAX_VALUE)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_ItemId)
        .addGap(0, 0, 0)
        .addComponent(Btn_ChooseItem))
       .addComponent(CmB_ReasonOfRevisi, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addGroup(layout.createSequentialGroup()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
         .addComponent(TF_StockDiff)
         .addComponent(TF_StockNew, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
         .addComponent(TF_StockOld, javax.swing.GroupLayout.Alignment.LEADING))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(layout.createSequentialGroup()
          .addComponent(TF_ItemStockOldUnit)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(CB_ItemUpdateStock))
         .addComponent(TF_ItemStockNewUnit)
         .addComponent(TF_ItemStockDiffUnit)))))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_RevDateY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_RevDateM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_RevDateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_RevDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_ReasonOfRevisi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ReasonOfRevisi))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ItemId)
     .addComponent(Btn_ChooseItem))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_StockOld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockOld)
     .addComponent(TF_ItemStockOldUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ItemUpdateStock))
    .addGap(11, 11, 11)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_StockNew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockNew)
     .addComponent(TF_ItemStockNewUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_StockDiff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockDiff)
     .addComponent(TF_ItemStockDiffUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean valid, currcheck;
  Object[] objs;
  
  valid=true;
  
  RevDate=PGUI.valueOfDateComponent(TF_RevDateY, CmB_RevDateM, CmB_RevDateD);
  if(RevDate!=null){Lbl_RevDate.setForeground(CGUI.Color_Label_InputRight);}
  else{Lbl_RevDate.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  objs=ComboMdlReasonOfRevisi.Mdl.Rows.elementAt(CmB_ReasonOfRevisi.getSelectedIndex()); ReasonOfRevisiId=PCore.objInteger(objs[0], -1); ReasonOfRevisiName=PCore.objString(objs[1], null);
  
  if(TF_ItemId.isEnabled()){
   inputItem();
   if(I_CheckedItemId!=-1){Lbl_ItemId.setForeground(CGUI.Color_Label_InputRight);}
   else{Lbl_ItemId.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  }
  
  if(TF_StockDiff.isEnabled()){
   currcheck=I_StockDiff!=null && PCore.objDouble(I_StockDiff, 0D)!=0D;
   if(currcheck){Lbl_StockDiff.setForeground(CGUI.Color_Label_InputRight);}
   else{Lbl_StockDiff.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  }
  
  if(!valid){
   JOptionPane.showMessageDialog(null, "Input masih salah, silahkan koreksi label yg berwarna merah !");
   return;
  }
  
  // close form
  fillInputVariablesIntoRealVariables();
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  if(!PGUI.isEnabled(TF_ItemId)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_ItemId, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsOrdr_Rg.init(true, false, true, FocusOrdered));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F6 : inputItem(); break;
   case KeyEvent.VK_SPACE : evt.consume(); Btn_ChooseItemActionPerformed(null); break;
   case KeyEvent.VK_UP : CmB_ReasonOfRevisi.requestFocusInWindow(); break;
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_DOWN : TF_StockDiff.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  if(!TF_ItemId.isEnabled()){return;}
  
  IFV.KeyboardManager.disableComponentShortcut();
  
  inputItem();
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  if(!Btn_ChooseItem.isEnabled()){return;}
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  LastInputId=IFV.FItem.ChoosedId[0];
  TF_ItemId.setText(String.valueOf(LastInputId));
  changeItem();
  TF_StockDiff.requestFocusInWindow();
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean ModeAdd=wMode==1;
  
  if(Activ){return;}
  
  Activ=true;

  setTitle(PText.getString(ModeAdd, "Tambah Data Revisi Stok", "Ubah Data Revisi Stok"));
  
  PDatabase.queryToComboBox(IFV.Stm, "select Id, Name from ReasonOfRevisi", ComboMdlReasonOfRevisi, true, PCore.refArr("Tidak Didefenisikan")); CmB_ReasonOfRevisi.setSelectedIndex(0);
  
  initGUI(ModeAdd);
  
  if(ModeAdd){
   PGUI.setDateComponent(new Date(), TF_RevDateY, CmB_RevDateM, CmB_RevDateD);
  }
  else{
   PGUI.setDateComponent(wInfoRevStock.RevDate, TF_RevDateY, CmB_RevDateM, CmB_RevDateD);

   PGUI.findAndSelect_Number_ComboBox(ComboMdlReasonOfRevisi, CmB_ReasonOfRevisi, 0, wInfoRevStock.ReasonOfRevisiId, true, -1, true, 0, true, 0);
   
   TF_ItemId.setText(String.valueOf(wInfoRevStock.ItemId)); inputItem();
   setIStockOld(wInfoRevStock.StockOld, true);
   setIStockDiff(wInfoRevStock.StockDiff, true);
   setIStockNew(wInfoRevStock.StockNew, true);
  }

  PGUI.requestFocusInWindow((JComponent)PCore.subtituteObj(ModeAdd, TF_ItemId, TF_RevDateY));
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  if(!TF_ItemId.isEnabled()){return;}
  
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  TF_ItemId.selectAll();
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void TF_RevDateYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_RevDateYKeyPressed
  int consumed=PNav.onKey_TF(this, TF_RevDateY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_RevDateM)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_RevDateYKeyPressed

 private void CmB_ReasonOfRevisiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ReasonOfRevisiKeyPressed
  int consumed=PNav.onKey_CmB(this, CmB_ReasonOfRevisi, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsOrdr_Lf.init(false, false, false, FocusOrdered),
   /* Right */  CNav.B_FcsOrdr_Rg.init(false, false, true, FocusOrdered));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_CmB_ReasonOfRevisiKeyPressed

 private void CmB_RevDateMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_RevDateMKeyPressed
  PNav.onKey_CmB(this, CmB_RevDateM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsOrdr_Lf.init(true, false, false, FocusOrdered),
   /* Right */  CNav.B_FcsOrdr_Rg.init(true, false, true, FocusOrdered));
 }//GEN-LAST:event_CmB_RevDateMKeyPressed

 private void CmB_RevDateDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_RevDateDKeyPressed
  PNav.onKey_CmB(this, CmB_RevDateD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsOrdr_Lf.init(true, false, false, FocusOrdered),
   /* Right */  CNav.B_FcsOrdr_Rg.init(true, false, true, FocusOrdered));
 }//GEN-LAST:event_CmB_RevDateDKeyPressed

 private void TA_ItemNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_ItemNameMouseClicked
  if(I_CheckedItemId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedItemId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_ItemNameMouseClicked

 private void Btn_ChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseItemKeyPressed
  if(!PGUI.isEnabled(Btn_ChooseItem)){return;}
  
  int consumed=PNav.onKey_Btn(this, Btn_ChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsOrdr_Lf.init(true, false, false, FocusOrdered),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Btn_ChooseItemKeyPressed

 private void TF_StockDiffFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockDiffFocusGained
  if(!TF_StockDiff.isEnabled()){return;}
  
  DocumentListenerFocus=1;
  TF_StockDiff.selectAll();
 }//GEN-LAST:event_TF_StockDiffFocusGained

 private void TF_StockDiffFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockDiffFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_StockDiffFocusLost

 private void TF_StockDiffKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockDiffKeyPressed
  if(!PGUI.isEnabled(TF_StockDiff)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_StockDiff, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : TF_ItemId.requestFocusInWindow(); break;
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_DOWN : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_TF_StockDiffKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_ItemUpdateStock;
 private javax.swing.JComboBox<String> CmB_ReasonOfRevisi;
 private javax.swing.JComboBox<String> CmB_RevDateD;
 private javax.swing.JComboBox<String> CmB_RevDateM;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_ReasonOfRevisi;
 private javax.swing.JLabel Lbl_RevDate;
 private javax.swing.JLabel Lbl_StockDiff;
 private javax.swing.JLabel Lbl_StockNew;
 private javax.swing.JLabel Lbl_StockOld;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_ItemStockDiffUnit;
 private javax.swing.JTextField TF_ItemStockNewUnit;
 private javax.swing.JTextField TF_ItemStockOldUnit;
 private javax.swing.JTextField TF_RevDateY;
 private javax.swing.JTextField TF_StockDiff;
 private javax.swing.JTextField TF_StockNew;
 private javax.swing.JTextField TF_StockOld;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
