public class VDouble {

 double Value;

 public VDouble() {}

 public VDouble(double Value) {this.Value = Value;}
 
 

}