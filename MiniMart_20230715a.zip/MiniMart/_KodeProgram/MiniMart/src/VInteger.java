public class VInteger {

 int Value;
 
 public VInteger(){}
 public VInteger(int Value){this.Value=Value;}

}