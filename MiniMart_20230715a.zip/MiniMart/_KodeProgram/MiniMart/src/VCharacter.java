public class VCharacter {

 char Value;

 public VCharacter() {}
 public VCharacter(char Value) {this.Value = Value;}
 
}