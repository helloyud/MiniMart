import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Vector;

public class OLabelCreatorItemMiniPriceTagB extends OLabelCreatorItem {
 
 
 
 
 
 public static ODimension getDimensionByCharacters(Font Fn, int RowsCount, int ColumnsCount, double MarginHorizontal, double MarginVertical, double TextAddLineSpacing){
  return PGraphics.getDimension(Fn, RowsCount, ColumnsCount, MarginHorizontal, MarginVertical, TextAddLineSpacing);
 }

 
 
 
 
 public OLabelCreatorItemMiniPriceTagB(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  ODimension dim;
  
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  dim=getDimensionByCharacters(Fon, RowsCountMin, ColumnsCountMin, MarginHorizontal, MarginVertical, TextLineSpacing);
  BoxWidthMin=dim.Width;
  BoxHeightMin=dim.Height;
 }
 protected void initDrawComponentsVariables(){
  super.initDrawComponentsVariables();
  TextLineSpacing=OUnit.mm_to_pixel(0.3);
  
  ColumnsCountMin=20;
  ColumnsCountMax=120;
  RowsCountMin=1;
 }
 protected String getName(){return "Price Tag) Mini B";}
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  OPaper papr;
  ODimension LabelSize;
  Vector<OPaperInfoMiniPriceTag2> Formats;
  OPaperInfoMiniPriceTag2 CurrFormat;
  int temp, count;
  int rowstart, rowadd, rowaddcount, colstart, coladd, coladdcount;
  int rowaddcurr, coladdcurr;
  
  Formats=new Vector();
  
  rowstart=1; rowadd=1; rowaddcount=6;
  colstart=20; coladd=5; coladdcount=12;
  
  rowaddcurr=0;
  do{
   coladdcurr=0;
   do{
    Formats.addElement(new OPaperInfoMiniPriceTag2(rowstart+(rowadd*rowaddcurr), colstart+(coladd*coladdcurr), false));
    coladdcurr=coladdcurr+1;
   }while(coladdcurr!=coladdcount);
   rowaddcurr=rowaddcurr+1;
  }while(rowaddcurr!=rowaddcount);
  
  count=Formats.size();
  
  // A4 Half
  temp=0;
  do{
   CurrFormat=Formats.elementAt(temp);
   
   papr=CPrint.A4Half.cloneWithMargin(MgSt);
   
   LabelSize=getDimensionByCharacters(Fon, CurrFormat.RowsCount, CurrFormat.ColumnsCount, MarginHorizontal, MarginVertical, TextLineSpacing);
   CurrFormat.IsRotated=PGraphics.gradingLabelCount(papr.RealImageableWidth, papr.RealImageableHeight,
    0, 0, 0, LabelSize.getWidth(), LabelSize.getHeight(), LabelSize.getHeight(), LabelSize.getWidth(), papr.IsRollPaper, true, false, true)==2;
   
   papr.Description=papr.Description+" {"+CurrFormat.RowsCount+" x "+CurrFormat.ColumnsCount+"}";
   papr.setAdditionalInfo(CurrFormat);
   
   if(!CurrFormat.IsRotated){ret.addElement(new OPaperLabel(papr, LabelSize.getWidth(), LabelSize.getHeight(), 0, 0, 0, false, true, true, true, false));}
   else{ret.addElement(new OPaperLabel(papr, LabelSize.getHeight(), LabelSize.getWidth(), 0, 0, 0, false, true, true, true, false));}
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 39-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return true;}
 protected boolean isLabelRotatedInternalPaper(){return ((OPaperInfoMiniPriceTag2)Papr.AdditionalInfo).IsRotated;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 protected boolean genLayoutVariables(){
  boolean ret=true;
  OPaperInfoMiniPriceTag2 Format;
  ODimensionAbsolute rowcol_count;
  ODimension BoxSize;
  OCoordinate scale_size;
  double scl;
  
  if(!Papr.IsCustomPaperLabel){
   Format=(OPaperInfoMiniPriceTag2)Papr.AdditionalInfo;
   RowsCount=Format.RowsCount;
   ColumnsCount=Format.ColumnsCount;
  }
  else{
   RowsCount=1;
   ColumnsCount=(int)((LabelWidth-2*MarginHorizontal)/TextWidth); if(ColumnsCount>ColumnsCountMax){ColumnsCount=ColumnsCountMax;}
   BoxSize=getDimensionByCharacters(Fon, RowsCount, ColumnsCount, MarginHorizontal, MarginVertical, TextLineSpacing);
   scale_size=PGraphics.calculateCoordinate(LabelWidth, LabelHeight, BoxSize.getWidth(), BoxSize.getHeight(), 1, CGraph.Rotate_000Degree, true, true, null, false, false);
   scl=scale_size.Width/BoxSize.getWidth();
   rowcol_count=PGraphics.calculateLabelColumnAndRowCount(LabelWidth-2*(MarginHorizontal*scl), LabelHeight-2*(MarginVertical*scl),
    0, 0, TextLineSpacing*scl, TextWidth*scl, TextHeight*scl, false);
   RowsCount=rowcol_count.RowsCount;
   ColumnsCount=rowcol_count.ColumnsCount;
   if(RowsCount==0 || ColumnsCount==0){return false;}
  }
  
  BoxSize=getDimensionByCharacters(Fon, RowsCount, ColumnsCount, MarginHorizontal, MarginVertical, TextLineSpacing);
  BoxWidth=BoxSize.getWidth();
  BoxHeight=BoxSize.getHeight();
  
  return ret;
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  OLabelDataItem Data;
  Vector<String> strv;
  String str;
  int temp, count;
  double CurrY;
  
  g.setFont(Fon);
  
  Data=(OLabelDataItem)LabelData;
  str="("+Data.ItemId+") "+Data.ItemName+" - "+PText.priceToString(Data.ItemSellPrice)+
   PText.getString(Data.PromoComment, "", " ("+Data.PromoComment+")", true);
  if(RowsCount==1){
   strv=PCore.vect(PText.fitString(str, ColumnsCount, true, ColumnsCount/2, 1, '~'));
  }
  else{
   strv=PText.fitMultiLine(PText.multiLine(str, ColumnsCount), RowsCount, true, RowsCount/2, ColumnsCount, true, ColumnsCount/2, 1, '~');
  }
  
  count=strv.size();
  CurrY=MarginVertical+(PGraphics.getInsetY(AreaHeight, Fon, count, TextLineSpacing, OAlignment.VerticalCenter));
  temp=0;
  do{
   if(temp!=0){CurrY=CurrY+TextLineSpacing;}
   
   str=strv.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+TextAscent));
   CurrY=CurrY+TextHeight;
   
   temp=temp+1;
  }while(temp!=count);
 }
 
 
 
 
 
}