import java.util.Date;

public class OInfoItemVariant {
 
 String Variant;
 
 boolean IsActive;
 double BuyPrice;
 String BuyComment;
 Date BuyUpdate;
 String Comment;
 String PictureFile;

}