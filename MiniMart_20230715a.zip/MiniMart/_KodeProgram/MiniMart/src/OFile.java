import java.io.File;

public class OFile{
 public File File_;
 public boolean IsDirectory;
 public OFile(File File_, boolean IsDirectory){
  this.File_=File_;
  this.IsDirectory=IsDirectory;
 }
 public OFile(OFile OFile_){
  if(OFile_!=null){
   File_=OFile_.File_;
   IsDirectory=OFile_.IsDirectory;
  }
 }
}