public class OBarcodePatternizerEAN13 extends OBarcodePatternizer {
 
 /*
  EAN-13 encoding process's example :
  
  barcode : 1-234567-890128
 
  > check whether 'the last digit' is valid or not with checksum (this step is optional)
  
  > add start marker : 101
  
  > get left pattern rule from 'digit 1st' : 1 -> 001011 or AABABB
 
  > translate 'digit 2nd .. digit 7th' using left pattern rule AABABB
    2 -> 0010011
    3 -> 0111101
    4 -> 0011101
    5 -> 0110001
    6 -> 0000101
    7 -> 0010001
 
  > add center marker : 01010
 
  > translate 'digit 8th .. digit 13th' using right pattern
    8 -> 1001000
    9 -> 1110100
    0 -> 1110010
    1 -> 1100110
    2 -> 1101100
    8 -> 0010001 (here, the last digit is the checksum)
 
  > add end marker : 101
 
 */
 
 String[] LeftPatternsRuleFromFirstDigit;
 String[] LeftPatternsA;
 String[] LeftPatternsB;
 String[] RightPatterns;
 String StartEndMarker;
 String CenterMarker;
 
 public OBarcodePatternizerEAN13(){
  LeftPatternsRuleFromFirstDigit=OBarcodePatternsEAN13.getLeftPatternsRuleFromFirstDigit();
  LeftPatternsA=OBarcodePatternsEAN.getLeftPatternsA();
  LeftPatternsB=OBarcodePatternsEAN13.getLeftPatternsB();
  RightPatterns=OBarcodePatternsEAN.getRightPatterns();
  StartEndMarker=OBarcodePatternsEAN.getStartEndMarker();
  CenterMarker=OBarcodePatternsEAN.getCenterMarker();
 }
 
 protected OBarcodePatterns patternizing(){
  // max digit of Number <= 18, MinimalDigitCount >=1 && <=18
  String[] ret=null;
  String Code;
  int temp;
  String LeftPatternRule;
  
  Code=PText.paddingNumber(Number, OBarcodeGeneratorEAN.Ean13_Length);
  if(OBarcodeGeneratorEAN.checkCodeValidity(Code, OBarcodeGeneratorEAN.Ean13_Length)==false){return null;}
  
  ret=new String[15];
  
  ret[0]=StartEndMarker;
  
  LeftPatternRule=getLeftPatternRule(Code);
  temp=0;
  do{
   ret[1+temp]=getLeftPattern(LeftPatternRule, Code, 1+temp);
   temp=temp+1;
  }while(temp!=6);
  
  ret[7]=CenterMarker;
  
  temp=0;
  do{
   ret[8+temp]=getRightPattern(Code, 7+temp);
   temp=temp+1;
  }while(temp!=6);
  
  ret[14]=StartEndMarker;
  
  return new OBarcodePatterns(ret, OBarcodePatternsEAN13.getStandardSpecification());
 }
 
 private String getLeftPatternRule(String Code){return LeftPatternsRuleFromFirstDigit[Code.charAt(0)-48];}
 private String getLeftPattern(String LeftPatternRule, String Code, int CodeIndex){
  String[] LeftPatterns;
  if(LeftPatternRule.charAt(CodeIndex-1)=='A'){LeftPatterns=LeftPatternsA;}else{LeftPatterns=LeftPatternsB;}
  return LeftPatterns[Code.charAt(CodeIndex)-48];
 }
 private String getRightPattern(String Code, int CodeIndex){
  return RightPatterns[Code.charAt(CodeIndex)-48];
 }

}