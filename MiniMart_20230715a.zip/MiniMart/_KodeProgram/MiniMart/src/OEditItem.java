import java.util.Date;

public class OEditItem {
 
 boolean EditId; boolean IdSingleItem; Long EditedId; int IdOption;
 boolean EditName; boolean ReplaceSubName; String SubName; String EditedName;
 boolean EditIsActive; Boolean EditedIsActive;
 boolean EditComment; boolean ReplaceSubComment; String SubComment; String EditedComment;
 boolean EditStockUnit; Integer EditedStockUnitId; String EditedStockUnitName;
 boolean EditStock; Double EditedStock;
 boolean EditUpdateStock; Boolean EditedUpdateStock;
 boolean EditMinStock; Double EditedMinStock;
 boolean EditMaxStock; Double EditedMaxStock;
 boolean EditIsOpname; Boolean EditedIsOpname;
 boolean EditIsReorder; Boolean EditedIsReorder;
 boolean EditOrderPackQty; Double EditedOrderPackQty;
 boolean EditOrderPackThreshold; Double EditedOrderPackThreshold;
 boolean EditOrderMinPack; Double EditedOrderMinPack;
 boolean EditExp; Boolean EditedExp;
 boolean EditExpCheckPeriod; Integer EditedExpCheckPeriod;
 boolean EditExpThreshold; Integer EditedExpThreshold;
 boolean EditSellPrice; Double EditedSellPrice;
 boolean EditSellComment; boolean ReplaceSubSellComment; String SubSellComment; String EditedSellComment;
 boolean EditSellUpdate; Date EditedSellUpdate;
 boolean EditBuyPrice; Double EditedBuyPrice;
 boolean EditBuyComment; boolean ReplaceSubBuyComment; String SubBuyComment; String EditedBuyComment;
 boolean EditBuyUpdate; Date EditedBuyUpdate;
 boolean EditOpStock; Double EditedOpStock;
 boolean EditOpExp; Date EditedOpExp;
 boolean EditOrderQty; Double EditedOrderQty;
 
 public OEditItem(){clearAll();}
 
 OEditItem clearAll(){
  init(
   false, true, -1, -1,
   false, false, null, null,
   false, false,
   false, false, null, null,
   false, -1, null,
   false, -1,
   false, false,
   false, -1,
   false, -1,
   false, false,
   false, false,
   false, -1,
   false, -1,
   false, -1,
   false, false,
   false, -1,
   false, -1,
   false, -1,
   false, false, null, null,
   false, null,
   false, -1,
   false, false, null, null,
   false, null,
   false, null,
   false, null,
   false, -1);
  
  return this;
 }
 OEditItem init(
  boolean EditId, boolean IdSingleItem, long EditedId, int IdOption,
  boolean EditName, boolean ReplaceSubName, String SubName, String EditedName,
  boolean EditIsActive, boolean EditedIsActive,
  boolean EditComment, boolean ReplaceSubComment, String SubComment, String EditedComment,
  boolean EditStockUnit, int EditedStockUnitId, String EditedStockUnitName,
  boolean EditStock, double EditedStock,
  boolean EditUpdateStock, boolean EditedUpdateStock,
  boolean EditMinStock, double EditedMinStock,
  boolean EditMaxStock, double EditedMaxStock,
  boolean EditIsOpname, boolean EditedIsOpname,
  boolean EditIsReorder, boolean EditedIsReorder,
  boolean EditOrderPackQty, double EditedOrderPackQty,
  boolean EditOrderPackThreshold, double EditedOrderPackThreshold,
  boolean EditOrderMinPack, double EditedOrderMinPack,
  boolean EditExp, boolean EditedExp,
  boolean EditExpCheckPeriod, int EditedExpCheckPeriod,
  boolean EditExpThreshold, int EditedExpThreshold,
  boolean EditSellPrice, double EditedSellPrice,
  boolean EditSellComment, boolean ReplaceSubSellComment, String SubSellComment, String EditedSellComment,
  boolean EditSellUpdate, Date EditedSellUpdate,
  boolean EditBuyPrice, double EditedBuyPrice,
  boolean EditBuyComment, boolean ReplaceSubBuyComment, String SubBuyComment, String EditedBuyComment,
  boolean EditBuyUpdate, Date EditedBuyUpdate,
  boolean EditOpStock, Double EditedOpStock,
  boolean EditOpExp, Date EditedOpExp,
  boolean EditOrderQty, double EditedOrderQty){
  
  this.EditId = EditId; this.IdSingleItem = IdSingleItem; this.EditedId = EditedId; this.IdOption = IdOption;
  this.EditName = EditName; this.ReplaceSubName = ReplaceSubName; this.SubName = SubName; this.EditedName = EditedName;
  this.EditIsActive = EditIsActive; this.EditedIsActive = EditedIsActive;
  this.EditComment = EditComment; this.ReplaceSubComment = ReplaceSubComment; this.SubComment = SubComment; this.EditedComment = EditedComment;
  this.EditStockUnit = EditStockUnit; this.EditedStockUnitId = EditedStockUnitId; this.EditedStockUnitName = EditedStockUnitName;
  this.EditStock = EditStock; this.EditedStock = EditedStock;
  this.EditUpdateStock = EditUpdateStock; this.EditedUpdateStock = EditedUpdateStock;
  this.EditMinStock = EditMinStock; this.EditedMinStock = EditedMinStock;
  this.EditMaxStock = EditMaxStock; this.EditedMaxStock = EditedMaxStock;
  this.EditIsOpname = EditIsOpname; this.EditedIsOpname = EditedIsOpname;
  this.EditIsReorder = EditIsReorder; this.EditedIsReorder = EditedIsReorder;
  this.EditOrderPackQty = EditOrderPackQty; this.EditedOrderPackQty = EditedOrderPackQty;
  this.EditOrderPackThreshold = EditOrderPackThreshold; this.EditedOrderPackThreshold = EditedOrderPackThreshold;
  this.EditOrderMinPack = EditOrderMinPack; this.EditedOrderMinPack = EditedOrderMinPack;
  this.EditExp = EditExp; this.EditedExp = EditedExp;
  this.EditExpCheckPeriod = EditExpCheckPeriod; this.EditedExpCheckPeriod = EditedExpCheckPeriod;
  this.EditExpThreshold = EditExpThreshold; this.EditedExpThreshold = EditedExpThreshold;
  this.EditSellPrice = EditSellPrice; this.EditedSellPrice = EditedSellPrice;
  this.EditSellComment = EditSellComment; this.ReplaceSubSellComment = ReplaceSubSellComment; this.SubSellComment = SubSellComment; this.EditedSellComment = EditedSellComment;
  this.EditSellUpdate = EditSellUpdate; this.EditedSellUpdate = EditedSellUpdate;
  this.EditBuyPrice = EditBuyPrice; this.EditedBuyPrice = EditedBuyPrice;
  this.EditBuyComment = EditBuyComment; this.ReplaceSubBuyComment = ReplaceSubBuyComment; this.SubBuyComment = SubBuyComment; this.EditedBuyComment = EditedBuyComment;
  this.EditBuyUpdate = EditBuyUpdate; this.EditedBuyUpdate = EditedBuyUpdate;
  this.EditOpStock = EditOpStock; this.EditedOpStock = EditedOpStock;
  this.EditOpExp = EditOpExp; this.EditedOpExp = EditedOpExp;
  this.EditOrderQty = EditOrderQty; this.EditedOrderQty = EditedOrderQty;
 
  return this;
 }
 
}