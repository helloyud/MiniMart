public class VLong {

 long Value;

 public VLong() {}
 public VLong(long Value) {this.Value = Value;}

}