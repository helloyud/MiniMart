import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

public class XImgPanel extends JPanel{
 
 BufferedImage MemImg;
 boolean PaintImg;
 double PaintX, PaintY, PaintWidth, PaintHeight;
 
 XImgPanel(){
  super();
  
  MemImg=null;
  PaintImg=false;
 }
 
 void setPaintParameters(double X, double Y, double Width, double Height){
  PaintX=X;
  PaintY=Y;
  PaintWidth=Width;
  PaintHeight=Height;
 }
 
 @Override
 public void paint(Graphics g) {
  // erase
  super.paint(g);
  
  // draw
  if(PaintImg){
   if(MemImg!=null){paintImage(g);}
   else{paintError(g);}
  }
 }
 private void paintImage(Graphics g){
  if(PaintWidth!=0 && PaintHeight!=0){
   g.drawImage(MemImg, PMath.round(PaintX, 0), PMath.round(PaintY, 0), PMath.round(PaintWidth, 0), PMath.round(PaintHeight, 0), null);
  }
 }
 private void paintError(Graphics g){
  g.drawChars(new String("Error").toCharArray(), 0, 5, (getWidth()/2)-4, (getHeight()/2)-4);
 }
}