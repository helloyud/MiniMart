import java.util.Vector;

public class OCsvImportValues extends OCsvImportValue {
 
 Vector<String> Separators;
 Vector<OCsvImportValue> Values;

 public OCsvImportValues(){}
 public OCsvImportValues(Vector<String> Separators, Vector<OCsvImportValue> Values) {
  initVariables(Separators, Values);
 }
 
 protected void initVariables(Vector<String> Separators, Vector<OCsvImportValue> Values){
  this.Separators=Separators;
  this.Values=Values;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  int temp, length;
  
  preGenerateSQLValue(LastReadRecordFromFile);
  
  length=Values.size();
  temp=0;
  do{
   Values.elementAt(temp).prepareGenerateSQLValue(LastReadRecordFromFile);
   temp=temp+1;
  }while(temp!=length);
 }
 
 public OGeneratedSQLValue generateSQLValue(){
  OGeneratedSQLValue ret=new OGeneratedSQLValue();
  int temp, length;
  OGeneratedSQLValue AColumnValue;
  StringBuilder strb;
  
  strb=new StringBuilder();
  length=Values.size();
  temp=0;
  do{
   AColumnValue=Values.elementAt(temp).generateSQLValue();
   if(!AColumnValue.isGenerated()){break;}
   
   if(temp!=0){strb.append(Separators.elementAt(temp));}
   strb.append(AColumnValue.getGeneratedSQLValue());
   
   temp=temp+1;
  }while(temp!=length);
  if(temp==length){ret.setGeneratedSQLValue(strb.toString());}
  
  return ret;
 }
 
}