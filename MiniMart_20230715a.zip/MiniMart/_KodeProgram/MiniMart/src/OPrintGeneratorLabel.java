import java.util.LinkedList;

public class OPrintGeneratorLabel extends OPrintGenerator {
 
 /*
  printing characteristic
  - all of labels's format must be same
  - print in the way : padding label from left->right, then ("down" + left->right), and so on ....
 */

 // additional printing properties
 LinkedList<OPrintInfoLabel> Labels;
 OLabelCreator LabelCreator;
 boolean IsLabelRotated;
 
 int CurrColumn, CurrRow, EndRow;
 OPrintInfoLabel CurrLabel;
 int CurrLabelPrintRemaining;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 double SingleLabelWidth, SingleLabelHeight;
 double LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB;
 /* start from index 1, example "FirstPageStartAtLabelX=1 && FirstPageStartAtLabelY=2" means
    in the firt page, the printing will be started at 1st column && 2nd row */
 int FirstPageStartAtLabelX, FirstPageStartAtLabelY, FirstPageMaxRows;
 final double CutLineWidth=OUnit.mm_to_pixel(1.0);
 
 OPrintGeneratorLabel(){super(null);}
 
 public void setPrintVariables(OPaperLabel PaperLabel,
  OLabelCreator LabelCreator, LinkedList<OPrintInfoLabel> Labels,
  int FirstPageStartAtLabelX, int FirstPageStartAtLabelY, int FirstPageMaxRows){
  this.PaperType=PaperLabel;
  this.LabelCreator=LabelCreator;
  this.Labels=Labels;
  this.FirstPageStartAtLabelX=FirstPageStartAtLabelX;
  this.FirstPageStartAtLabelY=FirstPageStartAtLabelY;
  this.FirstPageMaxRows=FirstPageMaxRows;
  
  PaprWidth=PaperLabel.RealWidth;
  PaprHeight=PaperLabel.RealHeight;
  PaprImageableX=PaperLabel.RealImageableX;
  PaprImageableY=PaperLabel.RealImageableY;
  PaprImageableWidth=PaperLabel.RealImageableWidth;
  PaprImageableHeight=PaperLabel.RealImageableHeight;
  
  SingleLabelWidth=PaperLabel.LabelWidth;
  SingleLabelHeight=PaperLabel.LabelHeight;
  LabelSpacingHorizontal=PaperLabel.LabelSpacingHorizontal;
  LabelSpacingVerticalA=PaperLabel.LabelSpacingVerticalA;
  LabelSpacingVerticalB=PaperLabel.LabelSpacingVerticalB;
 }
 
	protected boolean hasHeader(){return false;}
 protected boolean hasFooter(){return false;}
 protected boolean isFooterWithLine(){return false;}
 protected boolean isHeaderWithLine(){return false;}
 protected boolean calculateLayoutPaper(){return false;}
 protected boolean calculateLayoutForCommonDrawing(){return false;}
 protected void nullifyLayout(){}
 protected boolean checkLastUsedLayout(){return false;}
 protected void updateLastUsedLayout(){}
 protected OFontLayout getFontStandardLayout(){return null;}
 
 protected void calculateLayoutVar() throws Exception{
  
  LabelCreator.setPaper((OPaperLabel)PaperType);
  if(!LabelCreator.generateLayoutVariables()){throw new Exception();}
  IsLabelRotated=LabelCreator.IsLabelRotated;
  
 }
 protected void prepareFirstPageData() throws Exception{
  getCurrLabel();
  if(CurrLabel==null){throw new Exception();}
  
  // calculate Start Printing Coordinate for first page
  CurrColumn=FirstPageStartAtLabelX-1;
  CurrRow=FirstPageStartAtLabelY-1;
  EndRow=FirstPageMaxRows-1;
 }
 protected void addHeader() throws Exception{}
 protected boolean addColumnar() throws Exception{
  OPaperLabel PaperLabel=(OPaperLabel)PaperType;
  
  CurrX=CurrColumn*(SingleLabelWidth+LabelSpacingHorizontal);
  CurrY=CurrRow*(LabelSpacingVerticalA+SingleLabelHeight+LabelSpacingVerticalB);
  
  // print vertically
  do{
   
   // print horizontally
   do{
    
    DrawComponents.addElement(new ODrawComponentLabel(
     BaseX+CurrX, BaseY+CurrY+LabelSpacingVerticalA, LabelCreator, CurrLabel.LabelData, IsLabelRotated));
    
    CurrColumn=CurrColumn+1;
    CurrX=CurrX+SingleLabelWidth+LabelSpacingHorizontal;
    CurrLabelPrintRemaining=CurrLabelPrintRemaining-1;
    if(CurrLabelPrintRemaining==0){getCurrLabel();}
   
   }while(CurrLabel!=null && CurrColumn!=PaperLabel.ColumnCount);
   
   CurrRow=CurrRow+1;
   CurrY=CurrY+LabelSpacingVerticalA+SingleLabelHeight+LabelSpacingVerticalB;
   CurrColumn=0; CurrX=0;
   
   if(!isCurrentPaperIsRollPaper()){
    if(CurrRow-1==EndRow){break;}
   }
   else{
    if(OrientedPaprImageableY+BaseY+CurrY+(LabelSpacingVerticalA+SingleLabelHeight+LabelSpacingVerticalB)+OrientedPaprMarginBottom>CPrint.PaperHeightMax){break;}
   }
   
  }while(CurrLabel!=null);
  
  addCutLine();
  
  return false;
 }
 protected void addFooter() throws Exception{}
 protected boolean isCurrentPaperIsRollPaper(){return PaperType.IsRollPaper;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprImageableY+BaseY+CurrY+OrientedPaprMarginBottom;}
 protected double getCurrentRollPaperImageableHeight(){return BaseY+CurrY-LabelSpacingVerticalB;}
 protected boolean prepareNextPage() throws Exception{
  OPaperLabel PaperLabel=(OPaperLabel)PaperType;
  
  CurrColumn=0; CurrRow=0;
  EndRow=PaperLabel.RowCount-1;
  
  return CurrLabel!=null;
 }
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected void clearVar(){
  Labels=null;
  LabelCreator=null;
  CurrLabel=null;
 }
 
 private void addCutLine(){
  OPaperLabel PaperLabel=(OPaperLabel)PaperType;
  double DrawLineThickness=OUnit.mm_to_pixel(0.5);
  
  if(PaperLabel.IsRollPaper || !PaperLabel.DrawCutLine){return;}
  if(CurrColumnar!=ColumnarCount){return;}
  
  DrawComponents.addElement(new ODrawComponentLine(0, BaseY+(CurrY-LabelSpacingVerticalB), CutLineWidth, BaseY+(CurrY-LabelSpacingVerticalB)+DrawLineThickness));
  DrawComponents.addElement(new ODrawComponentLine(OrientedPaprImageableWidth-CutLineWidth, BaseY+(CurrY-LabelSpacingVerticalB), OrientedPaprImageableWidth, BaseY+(CurrY-LabelSpacingVerticalB)+DrawLineThickness));
 }
 private void getCurrLabel(){
  if(Labels.isEmpty()){CurrLabel=null;}
  else{
   CurrLabel=Labels.pop();
   CurrLabelPrintRemaining=CurrLabel.PrintCount;
  }
 }
 
}