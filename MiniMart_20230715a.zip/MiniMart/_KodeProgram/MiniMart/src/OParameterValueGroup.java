import java.util.Vector;

public class OParameterValueGroup {

 Vector<OParameterValue> Data;

 public OParameterValueGroup() {Data=new Vector();}
 public OParameterValueGroup(Vector<OParameterValue> Data) {this.Data = Data;}

 //
 public String[] toStringParameters(){
  String[] ret=null;
  int temp, count;
  
  count=Data.size();
  if(count==0){return ret;}
  
  ret=new String[count];
  temp=0;
  do{
   ret[temp]=Data.elementAt(temp).Parameter;
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 public OParameterValue getParameterValue(String LookupForParameter){
  int foundindex=findIndex(LookupForParameter);
  if(foundindex==-1){return null;}
  else{return Data.elementAt(foundindex);}
 }
 public Object getValue(String Parameter, boolean IsGetValueDefault, int GetValueIfNotIsAlreadyReturn){
  int foundindex=findIndex(Parameter);
  if(foundindex==-1){return null;}
  else{return Data.elementAt(foundindex).getValue(IsGetValueDefault, GetValueIfNotIsAlreadyReturn);}
 }
 public boolean setValue(String Parameter, Object Value, boolean IsSetValueDefault){
  int foundindex=findIndex(Parameter);
  if(foundindex==-1){return false;}
  else{Data.elementAt(foundindex).setValue(Value, IsSetValueDefault); return true;}
 }
 public int findIndex(String LookupForParameter){
  int ret=-1;
  int temp, count;
  
  count=Data.size();
  if(count==0){return ret;}
  
  temp=0;
  do{
   if(PText.compare(Data.elementAt(temp).Parameter, LookupForParameter, false)){ret=temp; break;}
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }

 // emulate Vector's methods
 public int size(){return Data.size();}
 public void addElement(OParameterValue Element){Data.addElement(Element);}
 public OParameterValue elementAt(int Index){return Data.elementAt(Index);}

}