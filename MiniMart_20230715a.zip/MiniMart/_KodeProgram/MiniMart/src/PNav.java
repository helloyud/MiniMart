import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.ListModel;
import javax.swing.SwingConstants;
import javax.swing.table.TableModel;

/* procedures of keyboard's navigation inside the GUI form */

public class PNav {
 
 //
 public static void parseFormComponents(Window Form,
  boolean SetKeyListener, Object[] SetKeyListener_ExcludeComponents,
  boolean SetFocusTraversal, boolean SetFocusTraversal_Value){
  parseMultiComponents(extractComponentsFromWindow(Form), Form, SetKeyListener, SetKeyListener_ExcludeComponents, SetFocusTraversal, SetFocusTraversal_Value);
 }
 public static Component[] extractComponentsFromWindow(Window Form){
  Component[] ret=null; // Component[] = container with n components
  JDialog FDialog;
  JFrame FFrame;
  
  do{
   if(Form instanceof JDialog){FDialog=(JDialog)Form; ret=FDialog.getContentPane().getComponents(); break;}
   if(Form instanceof JFrame){FFrame=(JFrame)Form; ret=FFrame.getContentPane().getComponents(); break;}
  }while(false);
  
  return ret;
 }
 public static void parseMultiComponents(Component[] Cmps, Window Form,
  boolean SetKeyListener, Object[] SetKeyListener_ExcludeComponents,
  boolean SetFocusTraversal, boolean SetFocusTraversal_Value){
  
  int count, temp;
  Component Cmp;
  Component[] CmpsExtracted=null;
  
  count=0; if(Cmps!=null){count=Cmps.length;} if(count==0){return;}
  
  temp=0;
  do{
   Cmp=Cmps[temp];
   CmpsExtracted=extractComponentsFromContainer(Cmp);
   
   if(CmpsExtracted!=null){parseMultiComponents(CmpsExtracted, Form, SetKeyListener, SetKeyListener_ExcludeComponents, SetFocusTraversal, SetFocusTraversal_Value);}
   else{parseSingleComponent(Cmp, Form, SetKeyListener, SetKeyListener_ExcludeComponents, SetFocusTraversal, SetFocusTraversal_Value);}
   
   temp=temp+1;
  }while(temp!=count);
  
 }
 public static Component[] extractComponentsFromContainer(Component Cont){
  Component[] ret=null; // null = not container, Component[] = container with n components
  
  if(Cont==null){return ret;}
  
  do{
   if(Cont instanceof JTabbedPane){ret=((JTabbedPane)Cont).getComponents(); break;}
   if(Cont instanceof JPanel){ret=((JPanel)Cont).getComponents(); break;}
   if(Cont instanceof JScrollPane){ret=((JScrollPane)Cont).getViewport().getComponents(); break;}
  }while(false);
  
  return ret;
 }
 public static void parseSingleComponent(Component Cmp, Window Form,
  boolean SetKeyListener, Object[] SetKeyListener_ExcludeComponents,
  boolean SetFocusTraversal, boolean SetFocusTraversal_Value){
  
  if(isComponentFocusCompatible(Cmp)){
   if(SetKeyListener){Cmp.addKeyListener(new OKeyAdapterNav(Cmp, Form, SetKeyListener_ExcludeComponents));}
   if(SetFocusTraversal){Cmp.setFocusTraversalKeysEnabled(SetFocusTraversal_Value);}
  }
  
 }
 public static boolean isComponentFocusCompatible(Component Cmp){
  boolean ret;
  
  if(Cmp==null){return false;}
  
  ret=true;
  do{
   if(Cmp instanceof JLabel){break;}
   if(Cmp instanceof JTextField){break;}
   if(Cmp instanceof JTextArea){break;}
   if(Cmp instanceof JComboBox){break;}
   if(Cmp instanceof JSpinner){break;}
   if(Cmp instanceof JCheckBox){break;}
   if(Cmp instanceof JRadioButton){break;}
   if(Cmp instanceof JToggleButton){break;}
   if(Cmp instanceof JButton){break;}
   if(Cmp instanceof XSlider){break;}
   if(Cmp instanceof XList){break;}
   if(Cmp instanceof XTable){break;}
   ret=false;
  }while(false);
  
  return ret;
 }
 
 //
 public static Component getChildComponent(Component Cont, boolean IsFirstChild, boolean FocusCompatible, boolean IfContIsCmp_ReturnCmp){
  Component ret=null; // null = no child or empty container , Component = first/last child of the Component
  Component Cmp;
  Component[] CmpsExtracted=null, CmpsExtractedEach;
  int count=0, start=0, end=0, add=0;
  boolean MultiComponents;
  
  MultiComponents=false;
  do{
   if(Cont==null){break;}
   
   CmpsExtracted=extractComponentsFromContainer(Cont);
   
   if(CmpsExtracted==null){
    if(IfContIsCmp_ReturnCmp){
     if(!FocusCompatible){ret=Cont;}
     else{if(isComponentFocusCompatible(Cont)){ret=Cont;}}
    }
    break;
   }
   
   count=CmpsExtracted.length; if(count==0){break;}
   
   MultiComponents=true;
  }while(false);
  
  if(!MultiComponents){return ret;}
   
  if(IsFirstChild){start=0; end=count; add=1;}
  else{start=count-1; end=-1; add=-1;}
  
  do{
   Cmp=CmpsExtracted[start];
   
   MultiComponents=false;
   do{
    if(Cmp==null){break;}
    
    CmpsExtractedEach=extractComponentsFromContainer(Cmp);
    
    if(CmpsExtractedEach==null){
     if(!FocusCompatible){ret=Cmp;}
     else{if(isComponentFocusCompatible(Cmp)){ret=Cmp;}}
     break;
    }
    
    count=CmpsExtractedEach.length; if(count==0){break;}
    
    MultiComponents=true;
   }while(false);
   
   if(MultiComponents){
    Cmp=getChildComponent(Cmp, IsFirstChild, FocusCompatible, IfContIsCmp_ReturnCmp); if(Cmp!=null){ret=Cmp;}
   }
   
   if(ret!=null){break;}
   
   start=start+add;
  }while(start!=end);
  
  return ret;
 }
 public static boolean transferFocus(Window Form, Component Cmp, boolean IsForward){
  boolean ret=false;
  
  Component CmpFocus, CmpFocusNext, CmpTemp;
  int LoopMax, LoopCount;
  boolean FocusCompatibleFounded, Refocus;
  
  if(Cmp==null){return ret;}
  
  /*
  LoopCount=0; LoopMax=1000; FocusCompatibleFounded=false; CmpFocus=Cmp;
  do{
   if(IsForward){CmpFocus.transferFocus();}
   else{CmpFocus.transferFocusBackward();}
   
   CmpFocusNext=Form.getMostRecentFocusOwner(); Refocus=false;
   if(CmpFocusNext==null || CmpFocusNext==CmpFocus){break;}
   CmpTemp=getChildComponent(CmpFocusNext, IsForward, true, false); if(CmpTemp!=null){CmpFocusNext=CmpTemp; Refocus=true;}
   if(isComponentFocusCompatible(CmpFocusNext)){FocusCompatibleFounded=true; break;}
   
   CmpFocus=CmpFocusNext;
   LoopCount=LoopCount+1;
  }while(LoopCount!=LoopMax);
  
  if(!FocusCompatibleFounded){PGUI.requestFocusInWindow(Cmp);}
  else{if(Refocus){PGUI.requestFocusInWindow(CmpFocusNext);}}
  */
  
  if(IsForward){Cmp.transferFocus();}
  else{Cmp.transferFocusBackward();}
  ret=true;
  
  return ret;
 }
 public static int getListenerKeyCount(Component Cmp){
  int ret=0;
  KeyListener[] ListenerKey;
  
  if(Cmp==null){return ret;}
  ListenerKey=Cmp.getKeyListeners(); if(ListenerKey==null){return ret;}
  ret=ListenerKey.length;
  
  return ret;
 }
 public static boolean getFocusTraversalKeysEnabled(Component Cmp){
  if(Cmp==null){return false;}
  return Cmp.getFocusTraversalKeysEnabled();
 }
 public static void setFocusTraversalKeysEnabled(Component Cmp, boolean Value){
  if(Cmp!=null){Cmp.setFocusTraversalKeysEnabled(Value);}
 }
 public static void setFocusTraversalKeysEnabled(Component[] Cmps, boolean Value){
  int temp, count;
  Component Cmp;
  
  count=0; if(Cmps!=null){count=Cmps.length;} if(count==0){return;}
  
  temp=0;
  do{
   Cmp=Cmps[temp];
   
   setFocusTraversalKeysEnabled(Cmp, Value);
   
   temp=temp+1;
  }while(temp!=count);
 }
 public static void setFocusTraversalKeysEnabled(Object[] V_Cmps, boolean Value){
  int temp, count;
  Object obj;
  Component Cmp;
  Component[] Cmps;
  Object[] V_Cmps2;
  
  count=0; if(V_Cmps!=null){count=V_Cmps.length;} if(count==0){return;}
  
  temp=0;
  do{
   obj=V_Cmps[temp];
   
   if(obj!=null){
    
    if(obj instanceof Component){
     Cmp=(Component)obj;
     setFocusTraversalKeysEnabled(Cmp, Value);
    }
    else if(obj instanceof Component[]){
     Cmps=(Component[])obj;
     setFocusTraversalKeysEnabled(Cmps, Value);
    }
    else if(obj instanceof Object[]){
     V_Cmps2=(Object[])obj;
     setFocusTraversalKeysEnabled(V_Cmps2, Value);
    }
    
   }
   
   temp=temp+1;
  }while(temp!=count);
 }
 public static boolean executeListenerAction(Component Cmp, ActionListener[] ListenerAction){
  boolean ret;
  int length, temp;
  
  ret=false;
  do{
   if(Cmp!=null){
    if(!PGUI.isEnabled(Cmp)){break;}
   }
   
   length=0; if(ListenerAction!=null){length=ListenerAction.length;} if(length==0){break;}
   
   temp=0;
   do{
    executeListenerAction(Cmp, ListenerAction[temp]);
    temp=temp+1;
   }while(temp!=length);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean executeListenerAction(Component Cmp, ActionListener ListenerAction){
  boolean ret;
  
  ret=false;
  do{
   if(Cmp!=null){
    if(!PGUI.isEnabled(Cmp)){break;}
   }
   
   if(ListenerAction==null){break;}
   ListenerAction.actionPerformed(null);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean executeAbstractAction(Component Cmp, AbstractAction Action){
  boolean ret;
  
  ret=false;
  do{
   if(Cmp!=null){
    if(!PGUI.isEnabled(Cmp)){break;}
   }
   
   if(Action==null){break;}
   Action.actionPerformed(null);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean isKeyArrow(int KeyCode){
  return (KeyCode==KeyEvent.VK_UP || KeyCode==KeyEvent.VK_DOWN || KeyCode==KeyEvent.VK_LEFT || KeyCode==KeyEvent.VK_RIGHT);
 }
 
 //
 public static void registerCommonNavigationCharacters(
  Window Form, InputMap inp, ActionMap act,
  Object[] DisableFocusTraversalComponents,
  Object[] ExcludeComponents){
  
  /*
   the difference between DisableFocusTraversalComponents & ExcludeComponents is :
   - DisableFocusTraversalComponents : only execute half action (only common action & not specific action)
   - ExcludeComponents : completely not execute any action (nor common action & specific action)
  */
  
  /*  
  KeyCode=KeyEvent.VK_UP; KeyModifier=0;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "up");
  act.put("up", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  
  KeyCode=KeyEvent.VK_DOWN; KeyModifier=0;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "dwn");
  act.put("dwn", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  
  KeyCode=KeyEvent.VK_LEFT; KeyModifier=0;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "lft");
  act.put("lft", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  
  KeyCode=KeyEvent.VK_RIGHT; KeyModifier=0;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "rgh");
  act.put("rgh", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  
  KeyCode=KeyEvent.VK_ENTER; KeyModifier=0;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "etr");
  act.put("etr", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  
  KeyCode=KeyEvent.VK_ENTER; KeyModifier=InputEvent.SHIFT_DOWN_MASK;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "s_etr");
  act.put("s_etr", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  
  KeyCode=KeyEvent.VK_SPACE; KeyModifier=0;
  evt=new KeyEvent(Form, 0, 0, KeyModifier, KeyCode, (char)KeyCode);
  inp.put(KeyStroke.getKeyStroke(evt.getKeyCode(), evt.getModifiersEx(), false), "spc");
  act.put("spc", new OActionNav(Form, inp, act, ExcludeComponents, evt));
  */
  
  /*  */
  parseFormComponents(Form, true, ExcludeComponents, true, true);
  
  // 
  setFocusTraversalKeysEnabled(DisableFocusTraversalComponents, false);
 }
 
 //
 public static int actionNavDefault(Component Cmp, int StateKey, KeyEvent evt,
  
  Window Form, Object[] ExcludeComponents) {
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  int[] found;
  XList List;
  XTable Tbl;
  XSlider Slider;
  
  // check : focus owner is still need to use this procedure, or not
  Next=false;
  do{
   if(Cmp==null){break;}
   
   // the component is listed in ExcludeComponents
   found=PGUI.findComponent(ExcludeComponents, Cmp); if(found[0]!=-1){break;}
   
   Next=true;
  }while(false);
  if(!Next){return ret;}
  
  // execute this procedure : focus is still stay in focus owner, execute self-action, execute custom action, switch focus
  do{
   
   if(StateKey==CNav.StateKey_Universal || StateKey==CNav.StateKey_Pressed){
    
    if(Cmp instanceof JLabel){
     ret=onKey_Lbl(
      Form, (JLabel)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  CNav.A_ActSelf_Et.init(),
      /* Space */  CNav.A_ActSelf_Sp.init());

     break;
    }

    if(Cmp instanceof JTextField){
     ret=onKey_TF(
      Form, (JTextField)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  null,
      /* S-Etr */  null,
      /* Space */  null);

     break;
    }

    if(Cmp instanceof JTextArea){
     ret=onKey_TA(
      Form, (JTextArea)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  null,
      /* S-Etr */  null,
      /* Space */  null);

     break;
    }

    if(Cmp instanceof JComboBox){
     ret=onKey_CmB(
      Form, (JComboBox)Cmp, true, true, true, StateKey, evt,

      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Space */  null);

     break;
    }

    if(Cmp instanceof JSpinner){
     ret=onKey_Spin(
      Form, (JSpinner)Cmp, true, true, true, StateKey, evt,

      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  CNav.A_FcsAuto_Et.init(true),
      /* S-Etr */  CNav.A_FcsAuto_SE.init(false),
      /* Space */  null);

     break;
    }

    if(Cmp instanceof JCheckBox){
     ret=onKey_CB(
      Form, (JCheckBox)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true));

     break;
    }

    if(Cmp instanceof JRadioButton){
     ret=onKey_RB(
      Form, (JRadioButton)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true));

     break;
    }

    if(Cmp instanceof JToggleButton){
     ret=onKey_TG(
      Form, (JToggleButton)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true));

     break;
    }

    if(Cmp instanceof JButton){
     ret=onKey_Btn(
      Form, (JButton)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true));

     break;
    }
    
    if(Cmp instanceof XList){break;}
    if(Cmp instanceof XTable){break;}
    if(Cmp instanceof XSlider){break;}
    
    ret=onKey_Unknown(
     Form, Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  CNav.A_FcsAuto_Et.init(true),
      /* S-Etr */  CNav.A_FcsAuto_SE.init(false),
      /* Space */  null);
    
    break;
   }
   
   if(StateKey==CNav.StateKey_Universal || StateKey==CNav.StateKey_Released){
    
    if(Cmp instanceof XList){
     List=(XList)Cmp;
     ret=onKey_List(
      Form, List, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  null,
      /* Space */  null);

     break;
    }

    if(Cmp instanceof XTable){
     Tbl=(XTable)Cmp;
     ret=onKey_Tbl(
      Form, Tbl, true, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up.init(false),
      /* Down  */  CNav.A_FcsAuto_Dw.init(true),
      /* Left  */  CNav.A_FcsAuto_Lf.init(false),
      /* Right */  CNav.A_FcsAuto_Rg.init(true),

      /* Enter */  null,
      /* Space */  null);

     break;
    }

    if(Cmp instanceof XSlider){
     Slider=(XSlider)Cmp;
     if(Slider.getOrientation()==SwingConstants.HORIZONTAL){
      /* Up    */  CNav.A_FcsAuto_Up.init(false);
      /* Down  */  CNav.A_FcsAuto_Dw.init(true);
      /* Left  */  CNav.A_FcsAuto_Lf.init(false);
      /* Right */  CNav.A_FcsAuto_Rg.init(true);
     }
     else{
      /* Up    */  CNav.A_FcsAuto_Up.init(true);
      /* Down  */  CNav.A_FcsAuto_Dw.init(false);
      /* Left  */  CNav.A_FcsAuto_Lf.init(false);
      /* Right */  CNav.A_FcsAuto_Rg.init(true);
     }
     
     ret=onKey_Slider(
      Form, (XSlider)Cmp, true, true, true, StateKey, evt,

      /* Up    */  CNav.A_FcsAuto_Up,
      /* Down  */  CNav.A_FcsAuto_Dw,
      /* Left  */  CNav.A_FcsAuto_Lf,
      /* Right */  CNav.A_FcsAuto_Rg,

      /* Enter */  null,
      /* S-Etr */  null,
      /* Space */  null);

     break;
    }
    
    break;
   }
   
  }while(false);
 
  return ret;
 }
 
 //
 public static int onKey(
  Window Form, Component Cmp, int StateKey, KeyEvent evt,
  
  boolean KeyEvent_ConsumeAnyway,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  
  switch(evt.getKeyCode()){
   
   case KeyEvent.VK_UP     :  if(Up!=null){Up.init(Form, Cmp, evt); ret=Up.doAction();} break;
   case KeyEvent.VK_DOWN   :  if(Down!=null){Down.init(Form, Cmp, evt); ret=Down.doAction();} break;
   case KeyEvent.VK_LEFT   :  if(Left!=null){Left.init(Form, Cmp, evt); ret=Left.doAction();} break;
   case KeyEvent.VK_RIGHT  :  if(Right!=null){Right.init(Form, Cmp, evt); ret=Right.doAction();} break;
   
   case KeyEvent.VK_ENTER  :  
    if(!evt.isShiftDown()){
     if(Enter!=null){Enter.init(Form, Cmp, evt); ret=Enter.doAction();}
    }
    else{
     if(ShiftEnter!=null){ShiftEnter.init(Form, Cmp, evt); ret=ShiftEnter.doAction();}
    }
    break;
   case KeyEvent.VK_SPACE  :  if(Space!=null){Space.init(Form, Cmp, evt); ret=Space.doAction();} break;
  
  }
  
  if(ret!=CNav.Ret_Unconsumed || KeyEvent_ConsumeAnyway){evt.consume();}
  
  return ret;
 }
 
 //
 public static int onKey_Unknown(
  Window Form, Component Cmp,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(Cmp)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, Cmp, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,

   Enter,
   ShiftEnter,
   Space);
  
  return ret;
  
 }
 public static int onKey_Lbl(
  Window Form, JLabel Lbl,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(Lbl)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, Lbl, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   Enter,
   null,
   Space);
  
  return ret;
  
 }
 public static int onKey_Lbl(
  Window Form, JLabel Lbl,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  return onKey_Lbl(
   Form, Lbl,

   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,

   StateKey, evt,

   Up,
   Down,
   Left,
   Right,

   null,
   null);
  
 }
 public static int onKey_TF(
  Window Form, JTextField TF,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  int DocLength;
  int CaretPos;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   DocLength=TF.getDocument().getLength();
   CaretPos=TF.getCaretPosition();

   switch(evt.getKeyCode()){
    case KeyEvent.VK_LEFT   :  if(CaretPos!=0 || !PText.isEmptyString(TF.getSelectedText(), false, true)){Next=false;} break;
    case KeyEvent.VK_RIGHT  :  if(CaretPos!=DocLength || !PText.isEmptyString(TF.getSelectedText(), false, true)){Next=false;} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(TF)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, TF, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   Enter,
   ShiftEnter,
   Space);
  
  return ret;
  
 }
 public static int onKey_TF(
  Window Form, JTextField TF, boolean EnableNavigationByEnter,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  OActionKey Enter=null;
  OActionKey ShiftEnter=null;
  
  if(EnableNavigationByEnter){
   Enter=Down;
   ShiftEnter=Up;
  }
  
  return onKey_TF(
   Form, TF,

   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,

   StateKey, evt,

   Up,
   Down,
   Left,
   Right,

   Enter,
   ShiftEnter,
   null);
  
 }
 public static int onKey_TA(
  Window Form, JTextArea TA,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  int DocLength;
  int LineCount;
  int CaretPos;
  int CaretPosInLineRow;
  int CaretPosInLineCol;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   DocLength=TA.getDocument().getLength();
   CaretPos=TA.getCaretPosition();
   LineCount=TA.getLineCount();
   try{CaretPosInLineRow=TA.getLineOfOffset(CaretPos);}catch(Exception E){CaretPosInLineRow=0;}
   try{CaretPosInLineCol=CaretPos-TA.getLineStartOffset(CaretPosInLineRow);}catch(Exception E){CaretPosInLineCol=0;}

   switch(evt.getKeyCode()){
    case KeyEvent.VK_UP     :  if(CaretPosInLineRow!=0 || !PText.isEmptyString(TA.getSelectedText(), false, true)){Next=false;} break;
    case KeyEvent.VK_DOWN   :  if(CaretPosInLineRow!=LineCount-1 || !PText.isEmptyString(TA.getSelectedText(), false, true)){Next=false;} break;
    case KeyEvent.VK_LEFT   :  if(CaretPos!=0 || !PText.isEmptyString(TA.getSelectedText(), false, true)){Next=false;} break;
    case KeyEvent.VK_RIGHT  :  if(CaretPos!=DocLength || !PText.isEmptyString(TA.getSelectedText(), false, true)){Next=false;} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(TA)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, TA, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   Enter,
   ShiftEnter,
   Space);
  
  return ret;
  
 }
 public static int onKey_TA(
  Window Form, JTextArea TA,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  return onKey_TA(
   Form, TA,

   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,

   StateKey, evt,

   Up,
   Down,
   Left,
   Right,

   null,
   null,
   null);
  
 }
 public static int onKey_CmB(
  Window Form, JComboBox CmB,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(CmB)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, CmB, StateKey, evt, false,
   
   null,
   null,
   Left,
   Right,
   
   null,
   null,
   Space);
  
  return ret;
  
 }
 public static int onKey_CmB(
  Window Form, JComboBox CmB,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Left,
  OActionKey Right){
  
  return onKey_CmB(
   Form, CmB,

   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,

   StateKey, evt,

   Left,
   Right,

   null);
  
 }
 public static int onKey_Spin(
  Window Form, JSpinner Spin,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_UP    :  if(PGUI.isEnabled(Spin)){Spin.setValue(Spin.getNextValue()); ret=CNav.Ret_Consumed;} Next=false; break;
    case KeyEvent.VK_DOWN  :  if(PGUI.isEnabled(Spin)){Spin.setValue(Spin.getPreviousValue()); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(Spin)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, Spin, StateKey, evt, false,
   
   null,
   null,
   Left,
   Right,
   
   Enter,
   ShiftEnter,
   Space);
  
  return ret;
  
 }
 public static int onKey_Spin(
  Window Form, JSpinner Spin,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter){
  
  return onKey_Spin(
   Form, Spin,

   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,

   StateKey, evt,

   Left,
   Right,

   Enter,
   ShiftEnter,
   null);
  
 }
 public static int onKey_CB(
  Window Form, JCheckBox CB,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(CB)){CB.doClick(); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(CB)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, CB, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   null,
   null,
   null);
  
  return ret;
  
 }
 public static int onKey_RB(
  Window Form, JRadioButton RB,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  int Key;
  boolean KeyIsRBInternalAutoMove;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(RB)){RB.doClick(); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(RB)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  Key=evt.getKeyCode();
  KeyIsRBInternalAutoMove=
   (Key==KeyEvent.VK_UP || Key==KeyEvent.VK_DOWN || Key==KeyEvent.VK_LEFT || Key==KeyEvent.VK_RIGHT);
  
  ret=onKey(
   Form, RB, StateKey, evt, KeyIsRBInternalAutoMove,
   
   Up,
   Down,
   Left,
   Right,
   
   null,
   null,
   null);
  
  return ret;
  
 }
 public static int onKey_TG(
  Window Form, JToggleButton TG,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(TG)){TG.doClick(); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(TG)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, TG, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   null,
   null,
   null);
  
  return ret;
  
 }
 public static int onKey_Btn(
  Window Form, JButton Btn,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(Btn)){Btn.doClick(); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(Btn)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, Btn, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   null,
   null,
   null);
  
  return ret;
  
 }
 public static int onKey_Slider(
  Window Form, XSlider Slider,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey ShiftEnter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(Slider.FocusState!=CGUI.FocusState_Work){return ret;}
  if(DoActionCommon_StayFocus){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_DOWN   :  if(Slider.getOrientation()==SwingConstants.VERTICAL){if(Slider.OnKeyPress_SliderValue>Slider.getMinimum()){Next=false;}} break;
    case KeyEvent.VK_UP     :  if(Slider.getOrientation()==SwingConstants.VERTICAL){if(Slider.OnKeyPress_SliderValue<Slider.getMaximum()){Next=false;}} break;
    case KeyEvent.VK_LEFT   :  if(Slider.getOrientation()==SwingConstants.HORIZONTAL){if(Slider.OnKeyPress_SliderValue>Slider.getMinimum()){Next=false;}} break;
    case KeyEvent.VK_RIGHT  :  if(Slider.getOrientation()==SwingConstants.HORIZONTAL){if(Slider.OnKeyPress_SliderValue<Slider.getMaximum()){Next=false;}} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(Slider)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, Slider, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   Enter,
   ShiftEnter,
   Space);
  
  return ret;
  
 }
 public static int onKey_Slider(
  Window Form, XSlider Slider, boolean EnableNavigationByEnter,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  OActionKey Enter=null;
  OActionKey ShiftEnter=null;
  
  if(EnableNavigationByEnter){
   if(Slider.getOrientation()==SwingConstants.HORIZONTAL){Enter=Down; ShiftEnter=Up;}
   else{Enter=Right; ShiftEnter=Left;}
  }
  
  return onKey_Slider(
   Form, Slider,

   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,

   StateKey, evt,

   Up,
   Down,
   Left,
   Right,

   Enter,
   ShiftEnter,
   null);
  
 }
 public static int onKey_List(
  Window Form, XList List,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey Space){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  ListModel ListMdl;
  int RowCount;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(List.FocusState!=CGUI.FocusState_Work){return ret;}
  if(StateKey==CNav.StateKey_Released && (List.FocusState==CGUI.FocusState_Work && List.IsSelecting)){List.setIsSelecting(false); return ret;}
  if(DoActionCommon_StayFocus){
   ListMdl=List.getModel();
   RowCount=ListMdl.getSize();

   switch(evt.getKeyCode()){
    case KeyEvent.VK_UP     :  if(RowCount!=0 && List.OnKeyPress_PosRow>0){Next=false;} break;
    case KeyEvent.VK_DOWN   :  if(RowCount!=0 && List.OnKeyPress_PosRow<RowCount-1){Next=false;} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(List)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, List, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   Enter,
   null,
   Space);
  
  return ret;
  
 }
 public static int onKey_List(
  Window Form, XList List,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  return onKey_List(
   Form, List,
   
   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,
   
   StateKey, evt,
   
   Up,
   Down,
   Left,
   Right,
   
   null,
   null);
  
 }
 public static int onKey_Tbl(
  Window Form, XTable Tbl,
  boolean EnableCheckCol,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right,
  
  OActionKey Enter,
  OActionKey Space){
  
  boolean Next;
  
  TableModel TableMdl;
  int RowCount;
  int ColCount;
  
  int ret=CNav.Ret_Unconsumed;
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(Tbl.FocusState!=CGUI.FocusState_Work){return ret;}
  if(StateKey==CNav.StateKey_Released && (Tbl.FocusState==CGUI.FocusState_Work && Tbl.IsSelecting)){Tbl.setIsSelecting(false); return ret;}
  if(DoActionCommon_StayFocus){
   TableMdl=Tbl.getModel();
   RowCount=TableMdl.getRowCount();
   ColCount=TableMdl.getColumnCount();

   switch(evt.getKeyCode()){
    case KeyEvent.VK_UP     :  if(RowCount!=0 && Tbl.OnKeyPress_PosRow>0){Next=false;} break;
    case KeyEvent.VK_DOWN   :  if(RowCount!=0 && Tbl.OnKeyPress_PosRow<RowCount-1){Next=false;} break;
    case KeyEvent.VK_LEFT   :  if(EnableCheckCol){if(RowCount!=0 && Tbl.OnKeyPress_PosCol>0){Next=false;}} break;
    case KeyEvent.VK_RIGHT  :  if(EnableCheckCol){if(RowCount!=0 && Tbl.OnKeyPress_PosCol<ColCount-1){Next=false;}} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){}
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(Tbl)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, Tbl, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   Right,
   
   Enter,
   null,
   Space);
  
  return ret;
  
 }
 public static int onKey_Tbl(
  Window Form, XTable Tbl,
  boolean EnableCheckCol,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left,
  OActionKey Right){
  
  return onKey_Tbl(
   Form, Tbl,
   EnableCheckCol,
   
   DoActionCommon_StayFocus, DoActionCommon_SelfAction, SenseFocusTraversal,
   
   StateKey, evt,
   
   Up,
   Down,
   Left,
   Right,
   
   null,
   null);
  
 }
 
 //
 public static int onKey_Query_TF(
  Window Form, JCheckBox CB_Q, JTextField TF_Q, JButton Btn_Q, AbstractAction Right_Action,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  int DocLength;
  int CaretPos;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   DocLength=TF_Q.getDocument().getLength();
   CaretPos=TF_Q.getCaretPosition();

   switch(evt.getKeyCode()){
    case KeyEvent.VK_LEFT   :  if(CaretPos!=0){Next=false;} break;
    case KeyEvent.VK_RIGHT  :  if(CaretPos!=DocLength){Next=false;} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(CB_Q)){CB_Q.setSelected(true); executeListenerAction(Btn_Q, Btn_Q.getActionListeners()); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(TF_Q)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, TF_Q, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   CNav.B_ActCstm_Rg.init(Right_Action),
   
   null,
   null,
   null);
  
  return ret;
  
 }
 public static int onKey_Query_TF1(
  Window Form, JCheckBox CB_Q, JTextField TF_Q1, JTextField TF_Q2, JButton Btn_Q,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down,
  OActionKey Left){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  int DocLength;
  int CaretPos;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   DocLength=TF_Q1.getDocument().getLength();
   CaretPos=TF_Q1.getCaretPosition();

   switch(evt.getKeyCode()){
    case KeyEvent.VK_LEFT   :  if(CaretPos!=0){Next=false;} break;
    case KeyEvent.VK_RIGHT  :  if(CaretPos!=DocLength){Next=false;} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(CB_Q)){CB_Q.setSelected(true); executeListenerAction(Btn_Q, Btn_Q.getActionListeners()); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(TF_Q1)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, TF_Q1, StateKey, evt, false,
   
   Up,
   Down,
   Left,
   CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Q2)),
   
   null,
   null,
   null);
  
  return ret;
  
 }
 public static int onKey_Query_TF2(
  Window Form, JCheckBox CB_Q, JTextField TF_Q1, JTextField TF_Q2, JButton Btn_Q, AbstractAction Right_Action,
  
  boolean DoActionCommon_StayFocus, boolean DoActionCommon_SelfAction, boolean SenseFocusTraversal,
  
  int StateKey, KeyEvent evt,
  
  OActionKey Up,
  OActionKey Down){
  
  int ret=CNav.Ret_Unconsumed;
  boolean Next;
  
  int DocLength;
  int CaretPos;
  
  Next=true;
  
  // common action : focus is still stay in focus owner, execute self-action
  if(DoActionCommon_StayFocus){
   DocLength=TF_Q2.getDocument().getLength();
   CaretPos=TF_Q2.getCaretPosition();

   switch(evt.getKeyCode()){
    case KeyEvent.VK_LEFT   :  if(CaretPos!=0){Next=false;} break;
    case KeyEvent.VK_RIGHT  :  if(CaretPos!=DocLength){Next=false;} break;
   }
   if(!Next){return ret;}
  }
  if(DoActionCommon_SelfAction){
   switch(evt.getKeyCode()){
    case KeyEvent.VK_ENTER  :  if(PGUI.isEnabled(CB_Q)){CB_Q.setSelected(true); executeListenerAction(Btn_Q, Btn_Q.getActionListeners()); ret=CNav.Ret_Consumed;} Next=false; break;
   }
   if(!Next){return ret;}
  }

  // sense some indicator variables whether to do or ignore specific action
  if(SenseFocusTraversal){
   if(!getFocusTraversalKeysEnabled(TF_Q2)){return ret;}
  }
  
  // specific action : execute custom action, switch focus
  ret=onKey(
   Form, TF_Q2, StateKey, evt, false,
   
   Up,
   Down,
   CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Q1)),
   CNav.B_ActCstm_Rg.init(Right_Action),
   
   null,
   null,
   null);
  
  return ret;
  
 }
 
}