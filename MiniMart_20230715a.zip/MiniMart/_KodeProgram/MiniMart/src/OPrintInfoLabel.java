public class OPrintInfoLabel {
 
 OLabelData LabelData;
 int PrintCount;

 public OPrintInfoLabel(OLabelData LabelData, int PrintCount) {
  this.LabelData = LabelData;
  this.PrintCount = PrintCount;
 }
 
}
