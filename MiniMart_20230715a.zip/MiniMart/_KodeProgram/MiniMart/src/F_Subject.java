import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableColumnModel;

public class F_Subject extends XFormDialog{
 
 // set
 int wMode; // 0 Normal (New, Edit, Remove), 1 Choose (Choose)
 boolean wDialogWithFItem;
 boolean wAllowMultipleSelection;
 
 // get
 Long[] ChoosedId;
 String[] ChoosedName;
 String[] ChoosedPictureFile;
 Vector<Object[]> ChoosedAddress;
 Vector<Object[]> ChoosedContact;
 Vector<Object[]> ChoosedBankAccount;
 
 // Index of Subject Information (det, cat, addr, cont, item)
  // requery sign
 boolean SIEmptyAll;
 boolean SIDet;
 boolean SIEtc;
 boolean SIPic;
 boolean SIBio;
 boolean SISupp;
 boolean SITrans;
  // contents cleared sign
 boolean SIDetClear;
 boolean SIEtcClear;
 boolean SIPicClear;
 boolean SIBioClear;
 boolean SISuppClear;
 boolean SITransClear;
 
 // Table Subject
 OCustomTableModel ListMdlSubject;
 int LastSelectedRow;
	
	String[] TableSubjectColsName;
	int[] TableSubjectColsType, TableSubjectColsShowOption, TableSubjectColsVisible, TableSubjectColsWidth;
	boolean[] TableSubjectColsEditable;
 
 boolean LastQueryDefined;
 int LastQueryOperationBy;
 int LQ_Limit;
 // Static Filter
	String LQ_StaticSourceTable, LQ_StaticCondition, LQ_StaticPostCondition;
 boolean LQ_StaticConditionDefined, LQ_StaticPostConditionDefined;
 // Dynamic Filter
 int LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
 // Additional Filter
 boolean LQ_WithAdditionalFilter;
 // Order By
 String LQ_OrderBy;
 
 String QHavingTbl;
 
 int LastResultFilterSubset;
 
 OInfoSubject InfoSubject;
 
 // Tab Search
 OCustomListModel ListMdlQCity;
 OCustomListModel ListMdlQContactType;
 OCustomListModel ListMdlQBankPlatform;
 OCustomListModel ListMdlQCat;
 OCustomListModel ListMdlQTag;
 OCustomListModel ListMdlQPic;
 OCustomTableModel TableMdlQSup;
 Component LastFocusedCmpSearch;
 // Tab Category
 OCustomListModel ListMdlCat;
 boolean ListMdlCatFilled;
 int LastSelectedRowCat;
 int LastSelectedCatQueryType;
 boolean CatQueryWithCheck;
 boolean CatQueryWithoutCheckByTempList;
 // Tab etc
 OCustomListModel ListMdlSubCat;
 OCustomListModel ListMdlSubTag;
 // Tab pic
 OCustomListModel ListMdlSubPic;
 int LastSelectedRowPic;
 boolean PanelImageClear;
 // Tab addr
 boolean SIAddrClear;
 OCustomTableModel TableMdlAddr;
	String[] TableMdlAddrColsName;
	int[] TableMdlAddrColsType, TableMdlAddrColsShowOption, TableMdlAddrColsVisible, TableAddrColsWidth;
	boolean[] TableMdlAddrColsEditable;
 int LastSelectedRowAddr;
 boolean InfoAddrClear;
 // Tab cont
 boolean SIContClear;
 OCustomTableModel TableMdlCont;
	String[] TableMdlContColsName;
	int[] TableMdlContColsType, TableMdlContColsShowOption, TableMdlContColsVisible, TableContColsWidth;
	boolean[] TableMdlContColsEditable;
 int LastSelectedRowCont;
 boolean InfoContClear;
 // Tab acc
 boolean SIAccClear;
 OCustomTableModel TableMdlAcc;
	String[] TableMdlAccColsName;
	int[] TableMdlAccColsType, TableMdlAccColsShowOption, TableMdlAccColsVisible, TableAccColsWidth;
	boolean[] TableMdlAccColsEditable;
 int LastSelectedRowAcc;
 boolean InfoAccClear;
 // Tab supp
 OCustomTableModel TableMdlSupp;
	String[] TableMdlSuppColsName;
	int[] TableMdlSuppColsType, TableMdlSuppColsShowOption, TableMdlSuppColsVisible, TableSuppColsWidth;
	boolean[] TableMdlSuppColsEditable;
 int LastSelectedRowSupp;
 boolean InfoSuppClear;
 // Tab trans
 boolean IsQueryTransComponentsInitialized;
 
 boolean LastSelectedIsPreTrans;
 
 OCustomComboBoxModel ComboMdlTransType;
 int LastSelectedRowTransType;
 
 OCustomComboBoxModel ComboMdlTransItem;
 int LastSelectedRowTransItem;
 
 int QueryTransLimit;
 
 OCustomTableModel TableMdlTransIn;
	String[] TableTransInColsName;
	int[] TableTransInColsType, TableTransInColsShowOption, TableTransInColsVisible, TableTransInColsWidth;
 String QueryTransInOrderBy, QueryTransInTbHaving;
 int LastSelectedRowTransIn;
 boolean InfoTransInClear;
 
 OCustomTableModel TableMdlTransOut;
	String[] TableTransOutColsName;
	int[] TableTransOutColsType, TableTransOutColsShowOption, TableTransOutColsVisible, TableTransOutColsWidth;
 String QueryTransOutOrderBy, QueryTransOutTbHaving;
 int LastSelectedRowTransOut;
 boolean InfoTransOutClear;
 
 //
 OQuickListOfLong TempList;
 boolean ShowBuyPrice;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 public F_Subject(MInterFormVariables IFV_) {
  String[] ColumnsName;
  int[] ColumnsType;
  int[] ColumnsVisible;
  int[] Editable;
  TableColumnModel ColMdl;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();

  // Tab Search
  TableMdlQSup=new OCustomTableModel(); // Item_id, Item_name
  TableMdlQSup.setColumnsInfo(
   PCore.refArr("Id", "Nama"),
   PCore.primArr(CCore.TypeLong, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(2, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(0, 1));
  Tbl_QSup.setModel(TableMdlQSup);
  PGUI.resizeTableColumn(Tbl_QSup, PCore.primArr(CGUI.ColNum13, CGUI.ColTextLrg));
  Tbl_QSup.moveColumn(1, 0);
  
  ListMdlQCat=new OCustomListModel(false); // CategoryOfSubject_id, CategoryOfSubject_name
  ListMdlQCat.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QCat.setModel(ListMdlQCat);
  
  ListMdlQTag=new OCustomListModel(false); // TagOfSubject_id, TagOfSubject_name
  ListMdlQTag.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QTag.setModel(ListMdlQTag);
  
  ListMdlQPic=new OCustomListModel(false);
  ListMdlQPic.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  List_QPic.setModel(ListMdlQPic);
  
  ListMdlQCity=new OCustomListModel(false); // City_id, City_name
  ListMdlQCity.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QCity.setModel(ListMdlQCity);
  
  ListMdlQContactType=new OCustomListModel(false); // ContactType_id, ContactType_name
  ListMdlQContactType.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QContactType.setModel(ListMdlQContactType);
  
  ListMdlQBankPlatform=new OCustomListModel(false); // BankPlatform_id, BankPlatform_name
  ListMdlQBankPlatform.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QBankPlatform.setModel(ListMdlQBankPlatform);
  
  // Tab Category
  ListMdlCat=new OCustomListModel(true, false, "~ ~  ", "");
  ColumnsType=new int[2]; // CategoryOfSubject_id, CategoryOfSubject_name
  ColumnsType[0]=2;
  ColumnsType[1]=1;
  ListMdlCat.setColumnsInfo(ColumnsType, 1);
  ListMdlCat.setAdditinalRows(2);
  List_Category.setModel(ListMdlCat);
  LastSelectedRowCat=-1;
  
  setCatQueryTypeNewState();
  
  ListMdlCatFilled=false;
  
  // List Subject
  ListMdlSubject=new OCustomTableModel(true, false, true);
  List_Subject.setModel(ListMdlSubject);
  LastSelectedRow=-1;
  
		TableSubjectColsName=PCore.refArr(
   "Id", "Nama", "Tgl Lahir", "File Gambar");
		TableSubjectColsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeString, CCore.TypeDate, CCore.TypeString);
  TableSubjectColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableSubjectColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(-1);
  TableSubjectColsEditable=PCore.changeValue(PCore.newBooleanArray(TableSubjectColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
  
  QHavingTbl="tb1";
  
  List_Subject.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingListSubject();}
   };
  
  List_Subject.setTableHeader(null); SPList_Subject.setColumnHeaderView(null);
  
  buildTableSubjectViewStructure(true, true);
  updateTableSubjectView(false);
  
  SIEmptyAll=true;
  SIDet=false; SIDetClear=true;
  SIEtc=false; SIEtcClear=true;
  SIPic=false; SIPicClear=true;
  SIBio=false; SIBioClear=true;
  SISupp=false; SISuppClear=true;
  SITrans=false; SITransClear=true;
  
  updateQueryCount();
  clearLastQuery();
  
  LastResultFilterSubset=CmB_ResultFilterSubset.getSelectedIndex();
  Pnl_InfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Tab etc
  ListMdlSubCat=new OCustomListModel(false);
  ColumnsType=new int[2]; // (subject_id), cat_id, cat_name
  ColumnsType[0]=2;
  ColumnsType[1]=1;
  ListMdlSubCat.setColumnsInfo(ColumnsType, 1);
  List_SubCategory.setModel(ListMdlSubCat);
  
  ListMdlSubTag=new OCustomListModel(false);
  ColumnsType=new int[2]; // (subject_id), tag_id, tag_name
  ColumnsType[0]=2;
  ColumnsType[1]=1;
  ListMdlSubTag.setColumnsInfo(ColumnsType, 1);
  List_SubTag.setModel(ListMdlSubTag);
  
  // Tab pic
  ListMdlSubPic=new OCustomListModel(false);
  ColumnsType=new int[1]; // (subject_id), filename
  ColumnsType[0]=1;
  ListMdlSubPic.setColumnsInfo(ColumnsType, 0);
  List_SubPicture.setModel(ListMdlSubPic);
  
  LastSelectedRowPic=-1;
  PanelImageClear=true;
  
  // Tab addr
  SIAddrClear=true;
  
  TableMdlAddr=new OCustomTableModel();
  Tbl_Addr.setModel(TableMdlAddr);
  
  TableMdlAddrColsName=PMyShop.getSubjectAddr_ColumnsName();
  TableMdlAddrColsType=PMyShop.getSubjectAddr_ColumnsType();
  TableMdlAddrColsShowOption=PMyShop.getSubjectAddr_ColumnsShowOption();
  TableMdlAddrColsEditable=PMyShop.getSubjectAddr_ColumnsEditable(false, true);
  LastSelectedRowAddr=-1;
  InfoAddrClear=true;
  
  PGUI.setSelected(true, CB_AddrViewCity, CB_AddrViewComment);
  
  buildTableAddrViewStructure(true, true);
  updateTableAddrView(false);
  
  Tbl_Addr.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableAddr();}
   };
  
  // Tab cont
  SIContClear=true;
  
  TableMdlCont=new OCustomTableModel();
  Tbl_Cont.setModel(TableMdlCont);
  
  TableMdlContColsName=PMyShop.getSubjectCont_ColumnsName();
  TableMdlContColsType=PMyShop.getSubjectCont_ColumnsType();
  TableMdlContColsShowOption=PMyShop.getSubjectCont_ColumnsShowOption();
  TableMdlContColsEditable=PMyShop.getSubjectCont_ColumnsEditable(false, true);
  LastSelectedRowCont=-1;
  InfoContClear=true;
  
  PGUI.setSelected(true, CB_ContViewContactType, CB_ContViewComment);
  
  buildTableContViewStructure(true, true);
  updateTableContView(false);
  
  Tbl_Cont.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableCont();}
   };
  
  // Tab acc
  SIAccClear=true;
  
  TableMdlAcc=new OCustomTableModel();
  Tbl_Acc.setModel(TableMdlAcc);
  
  TableMdlAccColsName=PMyShop.getSubjectAcc_ColumnsName();
  TableMdlAccColsType=PMyShop.getSubjectAcc_ColumnsType();
  TableMdlAccColsShowOption=PMyShop.getSubjectAcc_ColumnsShowOption();
  TableMdlAccColsEditable=PMyShop.getSubjectAcc_ColumnsEditable(false, true);
  LastSelectedRowAcc=-1;
  InfoAccClear=true;
  
  PGUI.setSelected(true, CB_AccViewBankPlatform, CB_AccViewComment);
  
  buildTableAccViewStructure(true, true);
  updateTableAccView(false);
  
  Tbl_Acc.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableAcc();}
   };
  
  // Tab supp
  SISuppClear=true;
  
  TableMdlSupp=new OCustomTableModel();
  Tbl_Supp.setModel(TableMdlSupp);
  
  TableMdlSuppColsName=PMyShop.getItemSupp_ColumnsName(false);
  TableMdlSuppColsType=PMyShop.getItemSupp_ColumnsType();
  TableMdlSuppColsShowOption=PMyShop.getItemSupp_ColumnsShowOption();
  TableMdlSuppColsEditable=PMyShop.getItemSupp_ColumnsEditable(true, true, true);
  LastSelectedRowSupp=-1;
  InfoSuppClear=true;
  
  CB_SuppViewCategorized.setSelected(IFV.Conf.ItemCategorized);
  PGUI.setSelected(true, CB_SuppViewBuyPrc, CB_SuppViewBuyComment);
  
  buildTableSuppViewStructure(true, true);
  updateTableSuppView(false);
  
  Tbl_Supp.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableSupp();}
   };
  
  CmB_SuppFind.setSelectedIndex(1);
  
  Pnl_SuppInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Tab trans
  IFV.PreventAutoFire.doPrevent(true); RB_TransIsPreTransN.setSelected(true);
  LastSelectedIsPreTrans=RB_TransIsPreTransY.isSelected();
  
  ComboMdlTransType=new OCustomComboBoxModel();
  ComboMdlTransType.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_TransType.setModel(ComboMdlTransType);
  LastSelectedRowTransType=-1;
  
  ComboMdlTransItem=new OCustomComboBoxModel();
  ComboMdlTransItem.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeString), 1);
  CmB_TransItem.setModel(ComboMdlTransItem);
  LastSelectedRowTransItem=-1;
  
  QueryTransLimit=CApp.FormQueryLimit;
  
  IsQueryTransComponentsInitialized=false;
  
   // trans in
  TableMdlTransIn=new OCustomTableModel();
  Tbl_TransIn.setModel(TableMdlTransIn);
  TableTransInColsName=PCore.refArr(
   "Tgl", "Jenis Trans", "Id Subjek", "Subjek", "Id Sales", "Sales", "Id Trans", "{Id-Ext}",
   "Id Barang", "Nm Brg", "Nama Barang", "File Gambar", "Kategori Barang",
   "Qty", "Satuan Stok", "Hrg Sat.", "Hrg Total", "Komentar");
	 TableTransInColsType=PCore.primArr(
   CCore.TypeDate, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeString, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString);
  TableTransInColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableTransInColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(6, 8), PCore.newIntegerArray(2, OCustomTableModel.ShowOptionObject));
  QueryTransInTbHaving="tb2";
  
  LastSelectedRowTransIn=-1;
  InfoTransInClear=true;
  
  PGUI.setSelected(true, CB_TransInDate, CB_TransInType, CB_TransInItem, CB_TransInPriceUnit);
  buildTableTransInViewStructure(true, true);
  updateTableTransInView(false);
  
  CmB_TransInFind.setSelectedIndex(0);
  
  ImgBox_TransInInfoItemPic.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
   // trans out
  TableMdlTransOut=new OCustomTableModel();
  Tbl_TransOut.setModel(TableMdlTransOut);
  TableTransOutColsName=PCore.refArr(
   "Tgl", "Jenis Trans", "Id Subjek", "Subjek", "Id Sales", "Sales", "Id Trans", "{Id-Ext}",
   "Id Barang", "Nm Brg", "Nama Barang", "File Gambar", "Kategori Barang",
   "Qty", "Satuan Stok", "Hrg Sat.", "Hrg Total", "Komentar", "H-Beli Sat.", "HPP");
	 TableTransOutColsType=PCore.primArr(
   CCore.TypeDate, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeString, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble);
  TableTransOutColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableTransOutColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(6, 8), PCore.newIntegerArray(2, OCustomTableModel.ShowOptionObject));
  QueryTransOutTbHaving="tb2";
  
  LastSelectedRowTransOut=-1;
  InfoTransOutClear=true;
  
  PGUI.setSelected(true, CB_TransOutDate, CB_TransOutType, CB_TransOutItem, CB_TransOutPriceUnit);
  buildTableTransOutViewStructure(true, true);
  updateTableTransOutView(false);
  
  CmB_TransOutFind.setSelectedIndex(0);
  
  ImgBox_TransOutInfoItemPic.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Tabbed Pane
  TabbedPane.addChangeListener(new ChangeListener(){
    public void stateChanged(ChangeEvent e) {onTabbedPaneChanged();}
   });
  TabbedPane.setSelectedIndex(0);
  
  //
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  clearTempList();
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
  Btn_Query.setToolTipText("hasil pencarian terbatas hingga "+PText.intToString(CApp.FormQueryLimit)+" data");
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Query,
    
    CB_QName, TF_QName,
    CB_QBirthDate, TF_QBirthStartYear, CmB_QBirthStartMonth, CmB_QBirthStartDay, TF_QBirthEndYear, CmB_QBirthEndMonth, CmB_QBirthEndDay,
    CB_QComment, TF_QComment,
    CB_QAddress, TF_QAddress,
    CB_QContact, TF_QContact,
    CB_QBankAccount, TF_QBankAccount,
    CB_QCity, CB_QCityUndefined, List_QCity, Btn_QCityAdd, Btn_QCityRemove,
    CB_QContactType, CB_QContactTypeUndefined, List_QContactType, Btn_QContactTypeAdd, Btn_QContactTypeRemove,
    CB_QBankPlatform, CB_QBankPlatformUndefined, List_QBankPlatform, Btn_QBankPlatformAdd, Btn_QBankPlatformRemove,
    CB_QCat, CB_QCatNon, List_QCat, Btn_QCatAdd, Btn_QCatRemove,
    CB_QTag, CB_QTagNon, List_QTag, Btn_QTagAdd, Btn_QTagRemove,
    CB_QPic, CB_QPicNon, List_QPic, Btn_QPicAdd, Btn_QPicRemove,
    CB_QSup, CB_QSupNon, Tbl_QSup, Btn_QSupAdd, Btn_QSupRemove,
    
    TF_Find, List_Subject,
    
    Btn_CatRefresh, CmB_CatQueryType, Btn_TempListAddByCategory, Btn_TempListRemoveByCategory,
    List_Category,
    TF_FindCategory, Btn_FCatBefore, Btn_FCatNext, Btn_CatAdd, Btn_CatEdit, Btn_CatRemove,
    
    TF_SuppFind, Tbl_Supp,
    
    TF_TransInFind, Tbl_TransIn,
    TF_TransOutFind, Tbl_TransOut),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_NewActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
  
  // f4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0, true), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     if(TabbedPane.getSelectedIndex()==6){
      
     }
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 0 :
       Btn_QueryActionPerformed(null);
       break;
      case 1 :
       Btn_CatAddActionPerformed(null);
       break;
      case 4 :
       Btn_SubPictureAddActionPerformed(null);
       break;
      case 6 :
       Btn_SuppAddActionPerformed(null);
       break;
     }
    }
   });
  
  // f7
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0, true), "f7");
  act.put("f7", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 1 :
       Btn_CatEditActionPerformed(null);
       break;
      case 6 :
       Btn_SuppEditActionPerformed(null);
       break;
     }
    }
   });
  
  // f8
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F8, 0, true), "f8");
  act.put("f8", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 1 :
       Btn_CatRemoveActionPerformed(null);
       break;
      case 4 :
       Btn_SubPictureRemoveActionPerformed(null);
       break;
      case 6 :
       Btn_SuppRemoveActionPerformed(null);
       break;
     }
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // cancel table editing
  List_Subject.editingCanceled(null);
  Tbl_Supp.editingCanceled(null);
  
  // Tab Search
  CB_QName.setSelected(false); TF_QName.setText("");
  CB_QComment.setSelected(false); TF_QComment.setText("");
  CB_QAddress.setSelected(false); TF_QAddress.setText("");
  CB_QContact.setSelected(false); TF_QContact.setText("");
  CB_QBankAccount.setSelected(false); TF_QBankAccount.setText("");
  CB_QBirthDate.setSelected(false); TF_QBirthStartYear.setText(""); TF_QBirthEndYear.setText("");
  CB_QCat.setSelected(false); CB_QCatNon.setSelected(false); ListMdlQCat.removeAll();
  CB_QTag.setSelected(false); CB_QTagNon.setSelected(false); ListMdlQTag.removeAll();
  CB_QPic.setSelected(false); CB_QPicNon.setSelected(false); ListMdlQPic.removeAll();
  CB_QCity.setSelected(false); CB_QCityUndefined.setSelected(false); ListMdlQCity.removeAll();
  CB_QContactType.setSelected(false); CB_QContactTypeUndefined.setSelected(false); ListMdlQContactType.removeAll();
  CB_QBankPlatform.setSelected(false); CB_QBankPlatformUndefined.setSelected(false); ListMdlQBankPlatform.removeAll();
  CB_QSup.setSelected(false); CB_QSupNon.setSelected(false); TableMdlQSup.removeAll();
  
  // Tab Category
  TF_FindCategory.setText("");
  clearListModelCategory(false);
  
  // List Subject
  clearListSubject();
  clearLastQuery();
  TF_Find.setText("");
  
  // Tab det, cat, addr, cont, item, trans
  clearDet();
  clearEtc();
  clearPic();
  clearBio();
  clearSupp();
  clearTrans(); clearTransQueryComponents();
  
  // TabbedPane
  TabbedPane.setSelectedIndex(0);
 }
 void initTransQueryComponents(){
  if(IsQueryTransComponentsInitialized==true){return;}
  
  PDatabase.queryToComboBox(IFV.Stm,
   "select Id, Name from TransType order by Name asc;", ComboMdlTransType, true, PCore.refArr("Semua"));
  IFV.PreventAutoFire.doPrevent(true); CmB_TransType.setSelectedIndex(0); LastSelectedRowTransType=CmB_TransType.getSelectedIndex();
  
  PDatabase.queryToComboBox(IFV.Stm,
   "select Id, concat('{', Id,'} ', Name) from Item order by Name asc;", ComboMdlTransItem, true, PCore.refArr("Semua"));
  IFV.PreventAutoFire.doPrevent(true); CmB_TransItem.setSelectedIndex(0); LastSelectedRowTransItem=CmB_TransItem.getSelectedIndex();
  
  IsQueryTransComponentsInitialized=true;
 }
 void clearTransQueryComponents(){
  if(IsQueryTransComponentsInitialized==false){return;}
  
  ComboMdlTransType.removeAll(); LastSelectedRowTransType=-1;
  ComboMdlTransItem.removeAll(); LastSelectedRowTransItem=-1;
  
  IsQueryTransComponentsInitialized=false;
 }
 
 void updateTableSubjectView(boolean Requery){
  ListMdlSubject.updateColumnsInfo(TableSubjectColsName, TableSubjectColsType, TableSubjectColsShowOption, TableSubjectColsVisible, TableSubjectColsEditable, Requery);
  PGUI.resizeTableColumn(List_Subject, TableSubjectColsWidth);
  if(!Requery){onListSubjectSelectedRowChanged(false);}else{fillListSubject();}
 }
 void buildTableSubjectViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  int temp;
  
  // Check Sign Of TempList
  ColsWidth.addElement(CGUI.ColCheck);
  
  TableSubjectColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableSubjectColsWidth=PCore.primArr_VectInt(ColsWidth);
  
  // Name
  temp=List_Subject.getWidth()-PMath.sumInt(TableSubjectColsWidth);
  TableSubjectColsVisible=PCore.insert(TableSubjectColsVisible, 0, 1);
  TableSubjectColsWidth=PCore.insert(TableSubjectColsWidth, 1, temp);
 }
 void buildTableSubjectColumns(){
  buildTableSubjectViewColumnsByNormalMode();
 }
 void buildTableSubjectOrderBy(){
  LQ_OrderBy=" order by "+QHavingTbl+".Name asc";
 }
 void buildTableSubjectViewStructure(boolean RefreshTableColumns, boolean RefreshOrderBy){
  if(RefreshTableColumns){buildTableSubjectColumns();}
  if(RefreshOrderBy){buildTableSubjectOrderBy();}
 }
 void changeTableSubjectViewByNormalMode(){
  buildTableSubjectViewStructure(true, false);
  updateTableSubjectView(false);
 }
 
 void updateTableTransInView(boolean Requery){
  long SubjectId;
  int RowSubject;
  
  TableMdlTransIn.updateColumnsInfo(TableTransInColsName, TableTransInColsType, TableTransInColsShowOption, TableTransInColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_TransIn, TableTransInColsWidth);
  if(!Requery){onTableTransInSelectedRowChanged(false);}
  else{
   SubjectId=-1; RowSubject=List_Subject.getSelectedRow(); if(RowSubject!=-1){SubjectId=(Long)ListMdlSubject.Mdl.Rows.elementAt(RowSubject)[0];}
   fillTransIn(SubjectId);
  }
 }
 void buildTableTransInViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  if(CB_TransInDate.isSelected()){ColsVisible.addElement(0); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_TransInType.isSelected()){ColsVisible.addElement(1); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInSubject.isSelected()){ColsVisible.addElement(3); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInSalesman.isSelected()){ColsVisible.addElement(5); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInId.isSelected()){ColsVisible.addElement(6); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInIdExternal.isSelected()){ColsVisible.addElement(7); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInItem.isSelected()){
   ColsVisible.addElement(10); ColsWidth.addElement(CGUI.ColTextMed);
   ColsVisible.addElement(8); ColsWidth.addElement(CGUI.ColNum13);
  }
  if(CB_TransInItemComment.isSelected()){ColsVisible.addElement(17); ColsWidth.addElement(CGUI.ColTextSml);}
  ColsVisible.addElement(13); ColsWidth.addElement(CGUI.ColNumSep04); // Qty
  if(CB_TransInItemStockUnit.isSelected()){ColsVisible.addElement(14); ColsWidth.addElement(CGUI.ColTextTiny);}
  if(CB_TransInPriceUnit.isSelected()){ColsVisible.addElement(15); ColsWidth.addElement(CGUI.ColNumSep09);}
  if(CB_TransInPriceTotal.isSelected()){ColsVisible.addElement(16); ColsWidth.addElement(CGUI.ColNumSep09_a);}
  
  TableTransInColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableTransInColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableTransInColumns(){
  buildTableTransInViewColumnsByNormalMode();
 }
 void buildTableTransInOrderBy(){
  QueryTransInOrderBy=" order by TransDate desc, TransTypeName asc, SubjectName asc, SalesmanName asc, TransId desc, ItemName asc";
 }
 void buildTableTransInViewStructure(boolean RefreshTableColumns, boolean RefreshOrderBy){
  if(RefreshTableColumns){buildTableTransInColumns();}
  if(RefreshOrderBy){buildTableTransInOrderBy();}
 }
 void changeTableTransInViewByNormalMode(){
  buildTableTransInViewStructure(true, false);
  updateTableTransInView(false);
 }
 
 void updateTableTransOutView(boolean Requery){
  long SubjectId;
  int RowSubject;
  
  TableMdlTransOut.updateColumnsInfo(TableTransOutColsName, TableTransOutColsType, TableTransOutColsShowOption, TableTransOutColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_TransOut, TableTransOutColsWidth);
  if(!Requery){onTableTransOutSelectedRowChanged(false);}
  else{
   SubjectId=-1; RowSubject=List_Subject.getSelectedRow(); if(RowSubject!=-1){SubjectId=(Long)ListMdlSubject.Mdl.Rows.elementAt(RowSubject)[0];}
   fillTransOut(SubjectId);
  }
 }
 void buildTableTransOutViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  if(CB_TransOutDate.isSelected()){ColsVisible.addElement(0); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_TransOutType.isSelected()){ColsVisible.addElement(1); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutSubject.isSelected()){ColsVisible.addElement(3); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutSalesman.isSelected()){ColsVisible.addElement(5); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutId.isSelected()){ColsVisible.addElement(6); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutIdExternal.isSelected()){ColsVisible.addElement(7); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutItem.isSelected()){
   ColsVisible.addElement(10); ColsWidth.addElement(CGUI.ColTextMed);
   ColsVisible.addElement(8); ColsWidth.addElement(CGUI.ColNum13);
  }
  if(CB_TransOutItemComment.isSelected()){ColsVisible.addElement(17); ColsWidth.addElement(CGUI.ColTextSml);}
  ColsVisible.addElement(13); ColsWidth.addElement(CGUI.ColNumSep04); // Qty
  if(CB_TransOutItemStockUnit.isSelected()){ColsVisible.addElement(14); ColsWidth.addElement(CGUI.ColTextTiny);}
  if(CB_TransOutPriceUnit.isSelected()){ColsVisible.addElement(15); ColsWidth.addElement(CGUI.ColNumSep09);}
  if(CB_TransOutPriceTotal.isSelected()){ColsVisible.addElement(16); ColsWidth.addElement(CGUI.ColNumSep09_a);}
  if(CB_TransOutPriceBasic.isSelected()){ColsVisible.addElement(19); ColsWidth.addElement(CGUI.ColNumSep09_a);}
  
  TableTransOutColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableTransOutColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableTransOutColumns(){
  buildTableTransOutViewColumnsByNormalMode();
 }
 void buildTableTransOutOrderBy(){
  QueryTransOutOrderBy=" order by TransDate desc, TransTypeName asc, SubjectName asc, SalesmanName asc, TransId desc, ItemName asc";
 }
 void buildTableTransOutViewStructure(boolean RefreshTableColumns, boolean RefreshOrderBy){
  if(RefreshTableColumns){buildTableTransOutColumns();}
  if(RefreshOrderBy){buildTableTransOutOrderBy();}
 }
 void changeTableTransOutViewByNormalMode(){
  buildTableTransOutViewStructure(true, false);
  updateTableTransOutView(false);
 }
 
 void dialogWithFItem(boolean Enable){
  Btn_QSupAdd.setEnabled(Enable);
  Btn_SuppAdd.setEnabled(Enable);
  Btn_SuppEdit.setEnabled(Enable);
  Btn_MultipleSubjectsItemAdd.setEnabled(Enable);
  Btn_MultipleSubjectsItemRemove.setEnabled(Enable);
 }
 
 void setLastQuery(int LastQueryOperationBy, int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConditionDefined, String StaticPostCondition, boolean StaticPostConDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  this.LastQueryOperationBy=LastQueryOperationBy;
  
  LQ_Limit=Limit;
		
  LQ_StaticSourceTable=StaticSourceTable;
		LQ_StaticCondition=StaticCondition; LQ_StaticConditionDefined=StaticConditionDefined;
		LQ_StaticPostCondition=StaticPostCondition; LQ_StaticPostConditionDefined=StaticPostConDefined;
  
  LQ_DynamicTempList=DynamicTempList;
  
  LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  LastQueryDefined=true;
 }
 void clearLastQuery(){
  LastQueryDefined=false;
 }
 
 void onTabbedPaneChanged(){
  int CurrTab=TabbedPane.getSelectedIndex();
  int row;
  if(CurrTab!=0 && CurrTab!=1){
   if(CurrTab==7){initTransQueryComponents();}
   
   row=List_Subject.getSelectedRow();
   if(row!=-1){
    fillAnActiveTab(CurrTab, ((Long)ListMdlSubject.Mdl.Rows.elementAt(row)[0]).longValue());
   }
   else{
    clearAnActiveTab(CurrTab);
   }
  }
  else{
   if(CurrTab==1){fillListModelCategory(1);}
   
   if(CurrTab==0){focusQuery();}
   else if(CurrTab==1){PGUI.requestFocusInWindow(TF_FindCategory);}
  }
 }
 void onListSubjectSelectedRowChanged(boolean UpdateAnyway){
  int row=List_Subject.getSelectedRow();
  int tab;
  if(row!=LastSelectedRow || UpdateAnyway){
   LastSelectedRow=row;
   clearSubjectInformationIndex();
   
   tab=TabbedPane.getSelectedIndex();
   if(tab!=0 && tab!=1){
    if(row!=-1){
     fillAnActiveTab(tab, ((Long)ListMdlSubject.Mdl.Rows.elementAt(row)[0]).longValue());
    }
    else{
     clearAnActiveTab(tab);
    }
   }
   
   if(row!=-1){fillInfoSubject(row);}
   else{clearInfoSubject();}
  }
 }
 void onListCategoryRowSelected(){
  int row=List_Category.getSelectedIndex();
  boolean QueryFromAdditionalRows;
  int QueryRow;
  StringBuilder SourceTable;
  StringBuilder Condition;
  
  if(LastSelectedRowCat!=row || LastQueryOperationBy!=2){
   LastSelectedRowCat=row;
   if(row==-1){return;}
   
   SourceTable=new StringBuilder();
   Condition=new StringBuilder(" where");
   
   QueryRow=row;
   QueryFromAdditionalRows=false;
   if(ListMdlCat.DisplayAdditionalRows){
    if(QueryRow<ListMdlCat.AdditionalRowsCount){QueryFromAdditionalRows=true;}
    else{QueryRow=QueryRow-ListMdlCat.AdditionalRowsCount;}
   }
   
   if(QueryFromAdditionalRows){
    if(QueryRow==0){Condition.append(" (left(Subject.Name, 1) not between 'A' and 'Z')");}
    else{Condition.append(" Subject.Name like '"+ListMdlCat.getNativeElementAt(QueryRow)+"%'");}
   }
   else{
    SourceTable.append(", SubjectXCategory");
    Condition.append(" Subject.Id=SubjectXCategory.Subject and SubjectXCategory.CategoryOfSubject="+ListMdlCat.Mdl.Rows.elementAt(QueryRow)[0]);
   }
   setLastQuery(2, 0, SourceTable.toString(), Condition.toString(), true, "", false, 0, true);
   
   fillListSubject();
  }
 }
 void onListPicRowSelected(boolean UpdateAnyway){
  int row=List_SubPicture.getSelectedIndex();
  if(LastSelectedRowPic!=row || UpdateAnyway){
   LastSelectedRowPic=row;
   if(row!=-1){fillPanelImage(ListMdlSubPic.getElementAt(row));}
   else{clearPanelImage();}
   Panel_Image.repaint();
  }
 }
 void onTableTransInSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_TransIn.getSelectedRow();
  
  if(!UpdateAnyway && LastSelectedRowTransIn==row){return;}
  
  LastSelectedRowTransIn=row;
  if(row!=-1){fillInfoTransIn(LastSelectedRowTransIn);}
  else{clearInfoTransIn();}
 }
 void onTableTransOutSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_TransOut.getSelectedRow();
  
  if(!UpdateAnyway && LastSelectedRowTransOut==row){return;}
  
  LastSelectedRowTransOut=row;
  if(row!=-1){fillInfoTransOut(LastSelectedRowTransOut);}
  else{clearInfoTransOut();}
 }
 void onQueryTransComponentsChanged(){
  boolean SelectedIsPreTrans=RB_TransIsPreTransY.isSelected();
  int SelectedTransType=CmB_TransType.getSelectedIndex();
  int SelectedTransItem=CmB_TransItem.getSelectedIndex();
  
  long SubjectId; int SubjectRow;
  
  if(
   LastSelectedIsPreTrans==SelectedIsPreTrans &&
   LastSelectedRowTransType==SelectedTransType &&
   LastSelectedRowTransItem==SelectedTransItem){
   return;
  }
  
  LastSelectedIsPreTrans=SelectedIsPreTrans;
  LastSelectedRowTransType=SelectedTransType;
  LastSelectedRowTransItem=SelectedTransItem;
  
  SubjectRow=List_Subject.getSelectedRow();
  if(SubjectRow==-1){return;}
  
  SubjectId=(Long)ListMdlSubject.Mdl.Rows.elementAt(SubjectRow)[0];
  fillTrans(SubjectId);
 }
 
 void onEditingListSubject(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=List_Subject.Editing_Row;
  Col=ListMdlSubject.convertColumnIndexFromViewToModel(List_Subject.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(ListMdlSubject.Mdl.ColumnsType[Col], null, List_Subject.Editing_ValueOld, true, null, List_Subject.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingListSubject_Check(Row); break;}
   result=onEditingListSubject_Subject(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut subjek !");}
 }
 int onEditingListSubject_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  fillTempList(PGUI.getIdsFromSelectedRows(ListMdlSubject, PCore.primArr(Row), 0), PCore.objBoolean(List_Subject.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingListSubject_Subject(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  boolean valid, FetchDataOld;
  OEditSubject Edit;
  
  do{
   Edit=new OEditSubject();
   FetchDataOld=false;
   valid=true;
   switch(Col){
    // date null
    case 2 : Edit.EditBirthday=true; Edit.EditedBirthday=PCore.objDate(List_Subject.Editing_ValueNew, null); break;
   }
   if(!valid){ret=-2; break;}

   if(editSubject(PCore.primArr(Row), FetchDataOld, null, Edit, false)!=0){ret=-1; break;}
  }while(false);
  
  return ret;
 }

 void clearSubjectInformationIndex(){
  if(SIEmptyAll==false){
   SIDet=false;
   SIEtc=false;
   SIPic=false;
   SIBio=false;
   SISupp=false;
   SITrans=false;
   SIEmptyAll=true;
  }
 }
 
 void updateTempListQuantity(){TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));}
 void fillTempList(long[] Data, boolean IsAdd){
  long[] AffectData;
  
  if(Data.length==0){return;}
  
  AffectData=PCore.subArr(Data, TempList.addElements(Data, IsAdd));
  if(AffectData.length==0){return;}
  
  updateTempListQuantity();
  fillSignData(AffectData, IsAdd);
  fillSignCategories(AffectData, IsAdd, false);
 }
 void fillTempListByCategory(String[] Alphabets, long[] Categories, boolean IsAdd){
  long[] Subjects;
  StringBuilder SourceTables;
  StringBuilder Conditions;
  boolean con_defined;
  boolean first;
  int temp, length;
  
  SourceTables=new StringBuilder(); Conditions=new StringBuilder(); con_defined=false;
  
  if(Alphabets.length!=0){
   if(!con_defined){con_defined=true; Conditions.append(" where");}else{Conditions.append(" or");}
   Conditions.append(" (");
   temp=0; length=Alphabets.length; first=true;
   do{
    if(first){first=false;}else{Conditions.append(" or");}
    
    if(!PText.compare(Alphabets[temp], "#", false)){Conditions.append(" Subject.Name like '"+Alphabets[temp]+"%'");}
    else{Conditions.append(" (left(Subject.Name, 1) not between 'A' and 'Z')");}
    
    temp=temp+1;
   }while(temp!=length);
   Conditions.append(")");
  }
  
  if(Categories.length!=0){
   if(!con_defined){con_defined=true; Conditions.append(" where");}else{Conditions.append(" or");}
   SourceTables.append(", (select Subject from SubjectXCategory where CategoryOfSubject in ("+
    PText.toString(Categories, 0, Categories.length, ",")+") group by Subject) as SubjectFromCategories");
   Conditions.append(" Subject.Id=SubjectFromCategories.Subject");
  }
  
  Subjects=PCore.primArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm,
   "select Id from Subject"+SourceTables+Conditions+" group by Id", CCore.TypeLong, false, null));
  
  if(Subjects==null){
   JOptionPane.showMessageDialog(null, "Gagal "+PText.getString(IsAdd, "menambah", "mengurangi")+" subjek2 pada kategori2 yg dipilih "+
    PText.getString(IsAdd, "ke", "dari")+" \"DaftarKu\"");
   return;
  }
  
  fillTempList(Subjects, IsAdd);
 }
 void clearTempList(){
  TempList.removeAll();
  updateTempListQuantity();
  
  clearSignData();
  clearSignCategories(false);
 }
 void updateQueryCount(){TF_QueryCount.setText(PText.intToString(ListMdlSubject.getRowCount()));}
 void fillListSubject(){
  String Query, Limit;
  long[] tlist;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  boolean con_defined, conpost_defined;
  
  clearListSubject();
  
  if(!LastQueryDefined){return;}
  
  Query=null;
  do{
   con_defined=LQ_StaticConditionDefined; conpost_defined=LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   if(LQ_DynamicTempList!=0){
    if(TempList.ElementsCount==0){if(LQ_DynamicTempList==1){break;}}
    else{
     if(!con_defined){con_defined=true; DynamicCondition.append(" where");}else{DynamicCondition.append(" and");}
     tlist=TempList.getElements();
     DynamicCondition.append(" Subject.Id"+PText.getString(LQ_DynamicTempList, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
    }
   }
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   if(LQ_WithAdditionalFilter){
    if(LastResultFilterSubset!=0){
     if(LastResultFilterSubset!=LQ_DynamicTempList){
      if(LQ_DynamicTempList!=0){break;}
      if(TempList.ElementsCount==0){if(LastResultFilterSubset==1){break;}}
      else{
       if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
       tlist=TempList.getElements();
       AdditionalCondition.append(" Subject.Id"+PText.getString(LastResultFilterSubset, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
      }
     }
    }
   }
   
    // finally, build query
   Limit=PText.getString(LQ_Limit, 0, " limit "+LQ_Limit, "");
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
   Query=
    "select tb1.*, Min(SubjectXPicture.FileName) as 'PictureFile' from "+
     "(select Subject.Id, Subject.Name, Subject.Birthday from Subject"+
      LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
      LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+") as tb1 "+
    "left join SubjectXPicture on tb1.Id=SubjectXPicture.Subject group by tb1.Id"+
    LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+
				LQ_OrderBy+Limit;
  }while(false);
  
  if(Query==null){return;}
  if(PDatabase.queryToTable(IFV.Stm, Query, ListMdlSubject, false, true, TempList, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil data dari database !");
  }
  updateQueryCount();
  updateQueryTempListCount();
 }
 void clearListSubject(){
  ListMdlSubject.removeAll();
  onListSubjectSelectedRowChanged(true);
  
  updateQueryCount();
  updateQueryTempListCount();
 }
 void updateQueryTempListCount(){TF_QueryTempListCount.setText("( "+PText.intToString(ListMdlSubject.getCheckedCount())+" )");}
 void fillSignData(long[] Data, boolean SignValue){
  ListMdlSubject.check(Data, SignValue, 0);
  updateQueryTempListCount();
 }
 void clearSignData(){
  ListMdlSubject.checkAll(false);
  updateQueryTempListCount();
 }
 void setCatQueryTypeNewState(){
  boolean DisplayData;
  boolean DisplayAdditionalRows;
  
  // set new state of CatQueryType
  LastSelectedCatQueryType=CmB_CatQueryType.getSelectedIndex();
  switch(LastSelectedCatQueryType){
   case 0  : DisplayData=true; DisplayAdditionalRows=true; CatQueryWithCheck=true; break;
   case 1  : DisplayData=false; DisplayAdditionalRows=true; CatQueryWithCheck=true; break;
   case 2  : DisplayData=true; DisplayAdditionalRows=false; CatQueryWithCheck=true; break;
   case 3  : DisplayData=true; DisplayAdditionalRows=false; CatQueryWithCheck=false; CatQueryWithoutCheckByTempList=true; break;
   case 4  : DisplayData=true; DisplayAdditionalRows=false; CatQueryWithCheck=false; CatQueryWithoutCheckByTempList=false; break;
   default : DisplayData=true; DisplayAdditionalRows=true; CatQueryWithCheck=true; break;
  }
  ListMdlCat.changeDisplay(DisplayData, DisplayAdditionalRows);
  updateCategoryCount();
 }
 void updateCatQueryType(){
  // clearing current CatQueryType's components state
  if(ListMdlCat.DisplayData){
   ListMdlCat.removeAll(); LastSelectedRowCat=-1;
   updateCategoryCount(); if(CatQueryWithCheck){updateCategoryCheckedCount();}
  }
  
  setCatQueryTypeNewState();
 }
 void updateCategoryCount(){TF_CatCount.setText(PText.intToString(ListMdlCat.getSize()));}
 String genQueryCat(boolean TempListMode, boolean ByTempList, boolean WithCategoryName){
  String ret=null;
  boolean buildquery;
  StringBuilder sourcetable;
  StringBuilder con;
  long[] tlist;
  
  buildquery=true;
  sourcetable=new StringBuilder();
  con=new StringBuilder();
  do{
   if(!TempListMode){break;}
   if(TempList.ElementsCount==0){
    if(ByTempList){buildquery=false;}
    break;
   }
   tlist=TempList.getElements();
   /*
   sourcetable.append(", "+
    "(select CategoryOfSubject from SubjectXCategory, "+
     "(select Id from Subject where Id "+PText.getString(CatQueryWithoutCheckByTempList, "in", "not in")+" ("+PText.toString(tlist, 0, tlist.length, ",")+")) as SubjectList "+
    "where SubjectList.Id=SubjectXCategory.Subject group by CategoryOfSubject) as Cat_SubjectList");
   
   con.append(" where CategoryOfSubject.Id=Cat_SubjectList.CategoryOfSubject");
   */
   sourcetable.append(" "+
    "left join "+
     "(select CategoryOfSubject from SubjectXCategory where Subject in ("+PText.toString(tlist, 0, tlist.length, ",")+") group by CategoryOfSubject) as Cat_SubjectList "+
    "on CategoryOfSubject.Id=Cat_SubjectList.CategoryOfSubject");
   
   con.append(" where Cat_SubjectList.CategoryOfSubject "+PText.getString(ByTempList, "is not", "is")+" "+CCore.vNull);
  }while(false);
  
  if(buildquery){
   ret=
    "select Id"+PText.getString(WithCategoryName, ", Name", "")+" from CategoryOfSubject"+sourcetable.toString()+con.toString()+
    PText.getString(WithCategoryName, " order by Name asc", "");
  }
  
  return ret;
 }
 void fillListModelCategory(int FillMode){
  switch(FillMode){
   case 1 : if(ListMdlCatFilled){return;} break;
   case 2 :
    if(LastSelectedCatQueryType==CmB_CatQueryType.getSelectedIndex()){return;}
    updateCatQueryType(); break;
  }
  
  if(ListMdlCat.DisplayData){
   clearListModelCategory(true);
   fillQueryToCategory();
  }
  
  ListMdlCatFilled=true;
 }
 void fillQueryToCategory(){
  String Query;
  
  Query=genQueryCat(!CatQueryWithCheck, CatQueryWithoutCheckByTempList, true);
  if(Query==null){return;}
  
  if(PDatabase.queryToList(IFV.Stm, Query, ListMdlCat, false, null, -1, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil Kategori Subjek dari database !");
  }
  updateCategoryCount();
  if(CatQueryWithCheck){fillSignCategories(TempList.getElements(), true, true);}
 }
 void clearListModelCategory(boolean ClearAnyway){
  if(!ListMdlCatFilled && !ClearAnyway){return;}
  
  if(ListMdlCat.DisplayData){
   ListMdlCat.removeAll(); LastSelectedRowCat=-1;
   updateCategoryCount(); updateCategoryCheckedCount();
  }

  ListMdlCatFilled=false;
 }
 void updateCategoryCheckedCount(){TF_CategoryCheckedCount.setText("( "+PText.intToString(ListMdlCat.getCheckedCount())+" )");}
 void fillSignCategories(long[] AffectedData, boolean TempListIsAdd, boolean FillAnyway){
  String Query=null;
  long[] ids;
  int[] index;
  Vector<Object[]> data;
  int temp, length;
  Object[] Objs;
		int insert_index;
  String query_cat;
  boolean SignValue;
  int query_type=0;
  
  if(!ListMdlCatFilled && !FillAnyway){return;}
  
  SignValue=(Boolean)PCore.subtituteBool(CatQueryWithCheck, TempListIsAdd, (CatQueryWithoutCheckByTempList && TempListIsAdd) || (!CatQueryWithoutCheckByTempList && !TempListIsAdd));
  
  if(AffectedData.length==0 || (!SignValue && ListMdlCat.Mdl.Rows.size()==0)){return;}
  
  if(!SignValue){query_type=3;}
  else{
   if(!CatQueryWithCheck && !CatQueryWithoutCheckByTempList){query_type=1;}
   else{query_type=2;}
  }
  
  if(query_type==1){Query=genQueryCat(true, (Boolean)PCore.subtituteBool(CatQueryWithCheck, true, CatQueryWithoutCheckByTempList), false);}
  else{
   Query="select CategoryOfSubject from SubjectXCategory where Subject in ("+PText.toString(AffectedData, 0, AffectedData.length, ",")+") group by CategoryOfSubject";
   if(query_type==3){
    query_cat=genQueryCat(true, (Boolean)PCore.subtituteBool(CatQueryWithCheck, true, CatQueryWithoutCheckByTempList), false);
    if(query_cat!=null){
     Query=
     // columns in source tables
     "select tb1.CategoryOfSubject from "+
       // source tables : comes from join operation between tables
         "("+Query+") as tb1 "+
       "left join "+
         "("+query_cat+") as tb2 "+
       "on tb1.CategoryOfSubject=tb2.Id "+
     // conditions
     "where tb2.Id is "+CCore.vNull;
    }
   }
  }

  ids=PCore.primArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm, Query, CCore.TypeLong, false, null));
  if(ids==null){
   JOptionPane.showMessageDialog(null, "Terjadi error dalam proses mencentang kategori !");
   return;
  }

  if(ids.length==0){return;}
  
  if(CatQueryWithCheck){
   ListMdlCat.check(ids, SignValue, 0);
   updateCategoryCheckedCount();
   return;
  }
  
  if(SignValue){
   ids=PCore.subArr(ids, PGUI.inspectLong(ids, ListMdlCat, 0, false, false));
   if(ids.length==0){return;}
   data=new Vector();
   PDatabase.queryToRows(IFV.Stm, "select Id, Name from CategoryOfSubject where Id in ("+
    PText.toString(ids, 0, ids.length, ",")+")", data, ListMdlCat.getColumnsType());
   length=data.size();
   if(length==0){return;}
   temp=0;
   do{
    Objs=data.elementAt(temp);
    ListMdlCat.insert(PGUI.findInsertPos(ListMdlCat, 1, (String)Objs[1], false, true, true), Objs);
    temp=temp+1;
   }while(temp!=length);
  }
  else{
   index=PGUI.inspectLong(ids, ListMdlCat, 0, true, true);
   if(index.length==0){return;}
   PCore.sort(index, index.length);
   ListMdlCat.remove(index);
  }
  if(LastSelectedRowCat!=-1){LastSelectedRowCat=-1;}
  updateCategoryCount();
 }
 void clearSignCategories(boolean ClearAnyway){
  if(!ListMdlCatFilled && !ClearAnyway){return;}
  
  if(!ListMdlCat.DisplayData){return;}
  
  if(CatQueryWithCheck){
   ListMdlCat.checkAll(false);
   updateCategoryCheckedCount();
   return;
  }
  
  ListMdlCat.removeAll(); LastSelectedRowCat=-1;
  updateCategoryCount();
  fillQueryToCategory();
 }
 void fillInfoSubject(int row){
  InfoSubject=PMyShop.getSubjectInfo(IFV.Stm, (Long)ListMdlSubject.Mdl.Rows.elementAt(row)[0], true);
  if(InfoSubject==null){return;}
  
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirSubject, InfoSubject.PictureFile);
  fillInfoSubjectBio();
 }
 void clearInfoSubject(){
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirSubject, null);
  TA_InfoBio.setText("");
 }
 void fillInfoSubjectBio(){
  StringBuilder strb;
  String str;
  boolean first;
  
  strb=new StringBuilder(); first=true;
  
  str=generateInfoSubjectBio_Address();
  if(str!=null){
   if(first){first=false;}else{strb.append("\n\n");}
   strb.append(str);
  }
  
  str=generateInfoSubjectBio_Contact();
  if(str!=null){
   if(first){first=false;}else{strb.append("\n\n");}
   strb.append(str);
  }
  
  TA_InfoBio.setText(strb.toString());
 }
 String generateInfoSubjectBio_Address(){
  StringBuilder strb;
  Object[] Row;
  boolean group_firstdata;
  int GroupIdBef, GroupIdCurr, temp;
  
  if(InfoSubject.ListAddressCount==0){return null;}
  
  strb=new StringBuilder("@"); GroupIdBef=-2; group_firstdata=true;
  
  temp=0;
  do{
   Row=InfoSubject.ListAddress.elementAt(temp);
   
   GroupIdCurr=PCore.objInteger(Row[1], -1);
   if(GroupIdCurr!=GroupIdBef){
    strb.append("    {"+PText.getString(GroupIdCurr, -1, PCore.objString(Row[2], ""), " - ")+"}");
    group_firstdata=true;
   }
   GroupIdBef=GroupIdCurr;
   
   if(group_firstdata){group_firstdata=false;}else{strb.append("  ;");}
   strb.append("  "+PText.singleLine(PCore.objString(Row[3], ""), '~'));
   
   temp=temp+1;
  }while(temp!=InfoSubject.ListAddressCount);
  
  return strb.toString();
 }
 String generateInfoSubjectBio_Contact(){
  StringBuilder strb;
  Object[] Row;
  boolean group_firstdata;
  int GroupIdBef, GroupIdCurr, temp;
  
  if(InfoSubject.ListContactCount==0){return null;}
  
  strb=new StringBuilder("#"); GroupIdBef=-2; group_firstdata=true;
  
  temp=0;
  do{
   Row=InfoSubject.ListContact.elementAt(temp);
   
   GroupIdCurr=PCore.objInteger(Row[1], -1);
   if(GroupIdCurr!=GroupIdBef){
    strb.append("    {"+PText.getString(GroupIdCurr, -1, PCore.objString(Row[2], ""), " - ")+"}");
    group_firstdata=true;
   }
   GroupIdBef=GroupIdCurr;
   
   if(group_firstdata){group_firstdata=false;}else{strb.append("  ;");}
   strb.append("  "+PText.singleLine(PCore.objString(Row[3], ""), '~'));
   
   temp=temp+1;
  }while(temp!=InfoSubject.ListContactCount);
  
  return strb.toString();
 }
 void fillDet(long Id){
  OInfoSubject InfoSubject;
  
  if(Id==-1){clearDet(); return;}
  
  InfoSubject=PMyShop.getSubjectInfo(IFV.Stm, Id);
  if(InfoSubject!=null){
   TF_DetName.setText(InfoSubject.Name);
   if(InfoSubject.Birthday!=null){
    TF_DetBirthday.setText(PText.dateToString(InfoSubject.Birthday, 2));
   }
   else{TF_DetBirthday.setText("");}
   if(InfoSubject.Comment!=null){
    TA_DetComment.setText(InfoSubject.Comment);
   }
   else{TA_DetComment.setText("");}
   SIDet=true;
   SIDetClear=false;
   if(SIEmptyAll==true){SIEmptyAll=false;}
  }
  else{
   JOptionPane.showMessageDialog(null, "Gagal mengambil keterangan subjek dari database !");
   clearDet();
  }
 }
 void clearDet(){
  if(SIDetClear==false){
   TF_DetName.setText("");
   TF_DetBirthday.setText("");
   TA_DetComment.setText("");
   SIDetClear=true;
  }
 }
 void fillEtc(long Id){
  boolean error;
  
  // clear list and list index, but not other components and index
  if(SIEtcClear==false){
   ListMdlSubCat.removeAll();
   ListMdlSubTag.removeAll();
  }
  
  // fetch list data
  error=true;
  do{
   if(PDatabase.queryToList(IFV.Stm,
    "select SubjectXCategory.CategoryOfSubject, CategoryOfSubject.Name from SubjectXCategory, CategoryOfSubject where "+
    "SubjectXCategory.Subject="+Id+" and SubjectXCategory.CategoryOfSubject=CategoryOfSubject.Id order by CategoryOfSubject.Name asc;",
    ListMdlSubCat, false, null, -1, false, -1)==-1){break;}
   
   if(PDatabase.queryToList(IFV.Stm,
    "select SubjectXTag.TagOfSubject, TagOfSubject.Name from SubjectXTag, TagOfSubject where "+
    "SubjectXTag.Subject="+Id+" and SubjectXTag.TagOfSubject=TagOfSubject.Id order by TagOfSubject.Name asc;",
    ListMdlSubTag, false, null, -1, false, -1)==-1){break;}
   
   error=false;
  }while(false);
  SIEtcClear=false;
  
  if(error==false){
   SIEtc=true; if(SIEmptyAll==true){SIEmptyAll=false;}
  }
  else{
   clearEtc();
   JOptionPane.showMessageDialog(null, "Gagal mengambil data-data dari database !");
  }
 }
 void clearEtc(){
  if(SIEtcClear==false){
   ListMdlSubCat.removeAll();
   ListMdlSubTag.removeAll();
   SIEtcClear=true;
  }
 }
 void fillPanelImage(String FileName){
  Panel_Image.setImageSource(IFV.Conf.ImageDirSubject+FileName);
  PanelImageClear=false;
 }
 void fillPic(long Id){
  int datacount;
  // clear list and list index, but not other components and index
  if(SIPicClear==false){
   ListMdlSubPic.removeAll();
   LastSelectedRowPic=-1;
  }
  // fetch list data
  datacount=PDatabase.queryToList(IFV.Stm,
   "select SubjectXPicture.FileName from SubjectXPicture where "+
   "SubjectXPicture.Subject="+Id+" order by SubjectXPicture.FileName asc;", ListMdlSubPic, false, null, -1, false, -1);
  SIPicClear=false;
  if(datacount!=-1){
   SIPic=true;
   if(SIEmptyAll==true){SIEmptyAll=false;}
   if(datacount>0){
    List_SubPicture.setSelectedIndex(0);
    onListPicRowSelected(false);
   }
   else{
    clearPanelImage();
    Panel_Image.repaint();
   }
  }
  else{
   clearPic();
   Panel_Image.repaint();
   JOptionPane.showMessageDialog(null, "Gagal mengambil daftar gambar subjek dari database !");
  }
 }
 void clearPanelImage(){
  if(PanelImageClear==false){
   // clear
   Panel_Image.setImageSource(null);
   PanelImageClear=true;
  }
 }
 void clearPic(){
  if(SIPicClear==false){
   ListMdlSubPic.removeAll();
   LastSelectedRowPic=-1;
   clearPanelImage();
   SIPicClear=true;
  }
 }
 void fillTrans(long Id){
  boolean success;
  
  clearTrans();
  
  do{
   success=fillTransIn(Id); if(!success){break;}
   success=fillTransOut(Id); if(!success){break;}
  }while(false);
  SITransClear=false;
  
  if(!success){
   clearTrans();
   JOptionPane.showMessageDialog(null, "Gagal mengambil daftar transaksi barang dari database !");
   return;
  }
  
  SITrans=true; SIEmptyAll=false;
 }
 void clearTrans(){
  if(SITransClear==true){return;}
  
  clearTransIn();
  clearTransOut();
  
  SITransClear=true;
 }
 String getQueryOfItemTrans(
  int Limit, boolean IsItemIn,
  long SubjectId,
  boolean IsPreTrans, int TransType, long[] Item){
  String ret=null;
  String QLimit, TblTransItem, TblTrans, OrderBy;
  StringBuilder Con_TblTransItem, Con_TblTrans;
  boolean confirst_TblTransItem, confirst_TblTrans;
  
  //
  QLimit=PText.getString(Limit, 0, " limit "+Limit, "");
  
  TblTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  TblTransItem=TblTrans+"XItem"+PText.getString(IsItemIn, "In", "Out");
  
  OrderBy=PText.getString(IsItemIn, QueryTransInOrderBy, QueryTransOutOrderBy);
  
  //
  Con_TblTransItem=new StringBuilder(); confirst_TblTransItem=true;
  
  if(!PCore.isArrayEmpty(Item, true)){
   if(confirst_TblTransItem){Con_TblTransItem.append(" where"); confirst_TblTransItem=false;}else{Con_TblTransItem.append(" and");}
   Con_TblTransItem.append(" Item in ("+PText.toString(Item, 0, Item.length, ",")+")");
  }
  
  //
  Con_TblTrans=new StringBuilder(); confirst_TblTrans=true;
  
  if(TransType!=-1){
   if(confirst_TblTrans){Con_TblTrans.append(" where"); confirst_TblTrans=false;}else{Con_TblTrans.append(" and");}
   Con_TblTrans.append(" TransType="+TransType);
  }
  
  if(confirst_TblTrans){Con_TblTrans.append(" where"); confirst_TblTrans=false;}else{Con_TblTrans.append(" and");}
  Con_TblTrans.append(" (Subject="+SubjectId+" or Salesman="+SubjectId+")");
  
  //
  ret=
   "select TransDate, TransTypeName, SubjectId, SubjectName, SalesmanId, SalesmanName, TransId, InfoIdExternal, "+
    "ItemId, ItemName, ItemNm, PictureFile, CategoryOfItemName, "+
    "Qty, StockUnitName, PriceUnit, PriceTotal, TransItemComment, BuyPriceEstimation, PriceTotalBasic from "+
    "(select tb2d.*, StockUnit.Name as 'StockUnitName' from "+
     "(select tb2c.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit as 'StockUnitId', BuyPriceEstimation, Qty*BuyPriceEstimation as 'PriceTotalBasic', "+
     "ItemPicture.PictureFile, ItemCategory.CategoryOfItemName from "+
      "(select tb2b.*, Subject.Name as 'SalesmanName' from "+
       "(select tb2a.*, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName' from "+
        "(select tb1.*, Item as 'ItemId', Stock as 'Qty', Price/Stock as 'PriceUnit', Price as 'PriceTotal', Comment as 'TransItemComment' from "+
         "(select Id as 'TransId', InfoIdExternal, TransDate, TransType as 'TransTypeId', Subject as 'SubjectId', Salesman as 'SalesmanId' from "+TblTrans+Con_TblTrans.toString()+") as tb1 "+
        "inner join "+TblTransItem+" on tb1.TransId="+TblTransItem+"."+TblTrans+Con_TblTransItem.toString()+") as tb2a "+
       "left join TransType on tb2a.TransTypeId=TransType.Id left join Subject on tb2a.SubjectId=Subject.Id) as tb2b "+
      "left join Subject on tb2b.SalesmanId=Subject.Id) as tb2c "+
     "inner join Item on tb2c.ItemId=Item.Id "+
     "inner join ("+PMyShop.getQueryOfItem_Picture("ItemPicture", Item)+") as ItemPicture on tb2c.ItemId=ItemPicture.ItemId "+
     "inner join ("+PMyShop.getQueryOfItem_Category("ItemCategory", Item)+") as ItemCategory on tb2c.ItemId=ItemCategory.ItemId) as tb2d "+
    "left join StockUnit on tb2d.StockUnitId=StockUnit.Id) as tb2"+
   OrderBy+QLimit;
  
  return ret;
 }
 boolean fillTransIn(long SubjectId){
  boolean ret=false;
  boolean IsPreTrans;
  int TransType;
  long Item;
  long[] Items;
  int datacount;
  
  IsPreTrans=RB_TransIsPreTransY.isSelected();
  TransType=PCore.objInteger(ComboMdlTransType.Mdl.Rows.elementAt(CmB_TransType.getSelectedIndex())[0], -1);
  Item=PCore.objLong(ComboMdlTransItem.Mdl.Rows.elementAt(CmB_TransItem.getSelectedIndex())[0], -1L);
  Items=null; if(Item!=-1){Items=PCore.primArr(Item);}
  
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, getQueryOfItemTrans(QueryTransLimit, true, SubjectId, IsPreTrans, TransType, Items),
    TableMdlTransIn, false, false, null, -1, false, -1);
   if(datacount==-1){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void clearTransIn(){
  TableMdlTransIn.removeAll();
  LastSelectedRowTransIn=-1;
  clearInfoTransIn();
 }
 void fillInfoTransIn(int RowIndex){
  Object[] Objs;
  
  if(RowIndex==-1){return;}
  
  Objs=TableMdlTransIn.Mdl.Rows.elementAt(RowIndex);
  TA_TransInInfoItemCategory.setText(PCore.objString(Objs[12], ""));
  TA_TransInInfoItemIdName.setText("("+PText.separate(Objs[8].toString(), " - ", 5)+") "+(String)Objs[10]);
  PGUI.fillPanelPictureURL(ImgBox_TransInInfoItemPic, IFV.Conf.ImageDirItem, Objs[11]);
  
  InfoTransInClear=false;
 }
 void clearInfoTransIn(){
  if(InfoTransInClear==true){return;}
  
  TA_TransInInfoItemCategory.setText("");
  TA_TransInInfoItemIdName.setText("");
  PGUI.fillPanelPictureURL(ImgBox_TransInInfoItemPic, IFV.Conf.ImageDirItem, null);
  
  InfoTransInClear=true;
 }
 boolean fillTransOut(long SubjectId){
  boolean ret=false;
  boolean IsPreTrans;
  int TransType;
  long Item;
  long[] Items;
  int datacount;
  
  IsPreTrans=RB_TransIsPreTransY.isSelected();
  TransType=PCore.objInteger(ComboMdlTransType.Mdl.Rows.elementAt(CmB_TransType.getSelectedIndex())[0], -1);
  Item=PCore.objLong(ComboMdlTransItem.Mdl.Rows.elementAt(CmB_TransItem.getSelectedIndex())[0], -1L);
  Items=null; if(Item!=-1){Items=PCore.primArr(Item);}
  
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, getQueryOfItemTrans(QueryTransLimit, false, SubjectId, IsPreTrans, TransType, Items),
    TableMdlTransOut, false, false, null, -1, false, -1);
   if(datacount==-1){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void clearTransOut(){
  TableMdlTransOut.removeAll();
  LastSelectedRowTransOut=-1;
  clearInfoTransOut();
 }
 void fillInfoTransOut(int RowIndex){
  Object[] Objs;
  
  if(RowIndex==-1){return;}
  
  Objs=TableMdlTransOut.Mdl.Rows.elementAt(RowIndex);
  TA_TransOutInfoItemCategory.setText(PCore.objString(Objs[12], ""));
  TA_TransOutInfoItemIdName.setText("("+PText.separate(Objs[8].toString(), " - ", 5)+") "+(String)Objs[10]);
  PGUI.fillPanelPictureURL(ImgBox_TransOutInfoItemPic, IFV.Conf.ImageDirItem, Objs[11]);
  
  InfoTransOutClear=false;
 }
 void clearInfoTransOut(){
  if(InfoTransOutClear==true){return;}
  
  TA_TransOutInfoItemCategory.setText("");
  TA_TransOutInfoItemIdName.setText("");
  PGUI.fillPanelPictureURL(ImgBox_TransOutInfoItemPic, IFV.Conf.ImageDirItem, null);
  
  InfoTransOutClear=true;
 }

 void fillAnActiveTab(int tab, long Id){
  switch(tab){
   case 2 : if(SIDet==false){fillDet(Id);} break; // tab det
   case 3 : if(SIEtc==false){fillEtc(Id);} break; // tab etc
   case 4 : if(SIPic==false){fillPic(Id);} break; // tab pic
   case 5 : if(SIBio==false){fillBio(Id);} break; // tab bio
   case 6 : if(SISupp==false){fillSupp(Id);} break; // tab sup
   case 7 : if(SITrans==false){fillTrans(Id);} break; // tab trans
  }
 }
 void clearAnActiveTab(int tab){
  switch(tab){
   case 2 : clearDet(); break; // tab det
   case 3 : clearEtc(); break; // tab etc
   case 4 : clearPic(); break; // tab pic
   case 5 : clearBio(); break;// tab bio
   case 6 : clearSupp(); break; // tab item
   case 7 : clearTrans(); break; // tab trans
  }
 }
 
 void runQuery(){
  boolean input_valid, list_defined, confirst;
  Date DateStart, DateEnd;
  
  boolean query_defined;
  VBoolean stc_con_defined;
  VBoolean stc_conpost_defined;
  StringBuilder StcSourceTable;
  StringBuilder StcCondition;
  StringBuilder StcPostConditions;
  
  // validate input
  input_valid=false;
  do{
   if(CB_QName.isSelected()){if(!PText.checkInput(TF_QName.getText(), false, 0, 0, 0, 0, 0)){break;}}
   if(CB_QComment.isSelected()){if(!PText.checkInput(TF_QComment.getText(), false, 0, 0, 0, 0, 0)){break;}}
   if(CB_QAddress.isSelected()){if(!PText.checkInput(TF_QAddress.getText(), false, 0, 0, 0, 0, 0)){break;}}
   if(CB_QContact.isSelected()){if(!PText.checkInput(TF_QContact.getText(), false, 0, 0, 0, 0, 0)){break;}}
   if(CB_QBankAccount.isSelected()){if(!PText.checkInput(TF_QBankAccount.getText(), false, 0, 0, 0, 0, 0)){break;}}

   if(CB_QBirthDate.isSelected()){
    DateStart=PGUI.valueOfDateComponent(TF_QBirthStartYear, CmB_QBirthStartMonth, CmB_QBirthStartDay);
    DateEnd=PGUI.valueOfDateComponent(TF_QBirthEndYear, CmB_QBirthEndMonth, CmB_QBirthEndDay);
    if(DateStart==null && DateEnd==null){break;}
   }

   if(CB_QCat.isSelected()){if(ListMdlQCat.getSize()==0 && !CB_QCatNon.isSelected()){break;}}
   if(CB_QTag.isSelected()){if(ListMdlQTag.getSize()==0 && !CB_QTagNon.isSelected()){break;}}
   if(CB_QPic.isSelected()){if(ListMdlQPic.getSize()==0 && !CB_QPicNon.isSelected()){break;}}
   if(CB_QCity.isSelected()){if(ListMdlQCity.getSize()==0 && !CB_QCityUndefined.isSelected()){break;}}
   if(CB_QContactType.isSelected()){if(ListMdlQContactType.getSize()==0 && !CB_QContactTypeUndefined.isSelected()){break;}}
   if(CB_QBankPlatform.isSelected()){if(ListMdlQBankPlatform.getSize()==0 && !CB_QBankPlatformUndefined.isSelected()){break;}}
   if(CB_QSup.isSelected()){if(TableMdlQSup.getRowCount()==0 && !CB_QSupNon.isSelected()){break;}}

   input_valid=true;
  }while(false);
  if(!input_valid){
   JOptionPane.showMessageDialog(null, "Tidak dapat mencari !\n"+
    "Masukan masih salah / belum lengkap !");
   return;
  }
  
  if(!IFV.canAccessGUI(3, true,
    (
    
      ( !IFV.PrivGUIShowItemSupplierList && CB_QSup.isSelected() ) /* PrivGUI - Item Supplier List */
    
    )==false
  )){return;}
  
  // build query
  query_defined=true;
  
  stc_con_defined=new VBoolean(false);
  stc_conpost_defined=new VBoolean(false);
  
  StcSourceTable=new StringBuilder();
  StcCondition=new StringBuilder();
  StcPostConditions=new StringBuilder();
  
  if(CB_QName.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" "+PSql.genCheckWord("Subject.Name", TF_QName.getText(), true, true));
  }
  if(CB_QComment.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" "+PSql.genCheckWord("Comment", TF_QComment.getText(), true, true));
  }
  if(CB_QAddress.isSelected()){
   StcSourceTable.append(", (select Subject from SubjectXAddress where "+PSql.genCheckWord("Address", TF_QAddress.getText(), true, true)+" group by Subject) as address");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=address.Subject");
  }
  if(CB_QContact.isSelected()){
   StcSourceTable.append(", (select Subject from SubjectXContact where "+PSql.genCheckWord("Contact", TF_QContact.getText(), true, true)+" group by Subject) as contact");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=contact.Subject");
  }
  if(CB_QBankAccount.isSelected()){
   StcSourceTable.append(", (select Subject from SubjectXBankAccount where "+PSql.genCheckWord("BankAccount", TF_QBankAccount.getText(), true, true)+" group by Subject) as bankaccount");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=bankaccount.Subject");
  }
  if(CB_QBirthDate.isSelected()){
   DateStart=PGUI.valueOfDateComponent(TF_QBirthStartYear, CmB_QBirthStartMonth, CmB_QBirthStartDay);
   DateEnd=PGUI.valueOfDateComponent(TF_QBirthEndYear, CmB_QBirthEndMonth, CmB_QBirthEndDay);
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" ("); confirst=true;
   if(DateStart!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" Birthday>=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(DateStart, DateEnd, true), false)+" as Date)");
   }
   if(DateEnd!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" Birthday<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(DateStart, DateEnd, false), true)+" as Date)");
   }
   StcCondition.append(")");
  }
  if(CB_QCity.isSelected()){
   StcSourceTable.append(", (select Subject from SubjectXAddress where");
   list_defined=false;
   if(ListMdlQCity.getSize()!=0){
    StcSourceTable.append(" City in ("+PGUI.getElementList(ListMdlQCity.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QCityUndefined.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" City is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Subject) as City");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=City.Subject");
  }
  if(CB_QContactType.isSelected()){
   StcSourceTable.append(", (select Subject from SubjectXContact where");
   list_defined=false;
   if(ListMdlQContactType.getSize()!=0){
    StcSourceTable.append(" ContactType in ("+PGUI.getElementList(ListMdlQContactType.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QContactTypeUndefined.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" ContactType is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Subject) as ContactType");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=ContactType.Subject");
  }
  if(CB_QBankPlatform.isSelected()){
   StcSourceTable.append(", (select Subject from SubjectXBankAccount where");
   list_defined=false;
   if(ListMdlQBankPlatform.getSize()!=0){
    StcSourceTable.append(" BankPlatform in ("+PGUI.getElementList(ListMdlQBankPlatform.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QBankPlatformUndefined.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" BankPlatform is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Subject) as BankPlatform");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=BankPlatform.Subject");
  }
  if(CB_QCat.isSelected()){
   StcSourceTable.append(", (select Id from Subject left join SubjectXCategory on Subject.Id=SubjectXCategory.Subject where");
   list_defined=false;
   if(ListMdlQCat.getSize()!=0){
    StcSourceTable.append(" CategoryOfSubject in ("+PGUI.getElementList(ListMdlQCat.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QCatNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" SubjectXCategory.Subject is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as Cat");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=Cat.Id");
  }
  if(CB_QTag.isSelected()){
   StcSourceTable.append(", (select Id from Subject left join SubjectXTag on Subject.Id=SubjectXTag.Subject where");
   list_defined=false;
   if(ListMdlQTag.getSize()!=0){
    StcSourceTable.append(" TagOfSubject in ("+PGUI.getElementList(ListMdlQTag.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QTagNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" SubjectXTag.Subject is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as Tag");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=Tag.Id");
  }
  if(CB_QPic.isSelected()){
   StcSourceTable.append(", (select Id from Subject left join SubjectXPicture on Subject.Id=SubjectXPicture.Subject where");
   list_defined=false;
   if(ListMdlQPic.getSize()!=0){
    StcSourceTable.append(" FileName in ("+PGUI.getElementList(ListMdlQPic.Mdl.Rows, 0, ",", "'", true)+")"); list_defined=true;
   }
   if(CB_QPicNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" SubjectXPicture.Subject is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as Pic");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=Pic.Id");
  }
  if(CB_QSup.isSelected()){
   StcSourceTable.append(", (select Id from Subject left join ItemXSupplier on Subject.Id=ItemXSupplier.Supplier where");
   list_defined=false;
   if(TableMdlQSup.getRowCount()!=0){
    StcSourceTable.append(" Item in ("+PGUI.getElementList(TableMdlQSup.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QSupNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" ItemXSupplier.Supplier is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as Supplier");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Subject.Id=Supplier.Id");
  }
   
  // run query
  if(query_defined){
   setLastQuery(1, CApp.FormQueryLimit,
    StcSourceTable.toString(), StcCondition.toString(), stc_con_defined.Value, StcPostConditions.toString(), stc_conpost_defined.Value,
    0, true);
  }
  else{
   clearLastQuery();
  }
  fillListSubject();
 }
 
 void findSubjectInList(int Mode){
  int Selected, FindIndex;
  int Col;
  String str=TF_Find.getText();
  if(str.length()!=0){
   if(ListMdlSubject.Mdl.Rows.size()!=0){
    Col=1;
    Selected=List_Subject.getSelectedRow();
    FindIndex=PGUI.searchInTable(ListMdlSubject, Col, ListMdlSubject.Mdl.ColumnsType[Col], str, Selected, Mode);
    if(FindIndex!=-1){
     if(FindIndex!=Selected){
      List_Subject.changeSelection(FindIndex, 0, false, false);
      onListSubjectSelectedRowChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di daftar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Daftar dalam keadaan kosong !");
   }
  }
 }
 void findCategoryInList(int Mode){
  int Selected, FindIndex;
  String str=TF_FindCategory.getText();
  if(str.length()!=0){
   Selected=List_Category.getSelectedIndex();
   FindIndex=PGUI.searchInlist(ListMdlCat, str, Selected, Mode);
   if(FindIndex!=-1){
    if(FindIndex!=Selected){
     List_Category.setSelectedIndex(FindIndex);
     List_Category.ensureIndexIsVisible(FindIndex);
     onListCategoryRowSelected();
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di daftar !");
   }
  }
 }
 void findTransIn(int Mode){
  int Selected, FindIndex;
  int Column;
  int ColumnType;
  String str=TF_TransInFind.getText();
  if(str.length()!=0){
   if(TableMdlTransIn.Mdl.Rows.size()!=0){
    switch(CmB_TransInFind.getSelectedIndex()){
     case 1 : Column=3; break;
     case 2 : Column=5; break;
     case 3 : Column=6; break;
     case 4 : Column=7; break;
     case 5 : Column=8; break;
     case 6 : Column=10; break;
     case 7 : Column=17; break;
     case 8 : Column=14; break;
     default : Column=1; break;
    }
    ColumnType=TableMdlTransIn.Mdl.ColumnsType[Column];
    Selected=Tbl_TransIn.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlTransIn, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_TransIn.changeSelection(FindIndex, 0, false, false);
      onTableTransInSelectedRowChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang masuk !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang masuk dalam keadaan kosong !");
   }
  }
 }
 void findTransOut(int Mode){
  int Selected, FindIndex;
  int Column;
  int ColumnType;
  String str=TF_TransOutFind.getText();
  if(str.length()!=0){
   if(TableMdlTransOut.Mdl.Rows.size()!=0){
    switch(CmB_TransOutFind.getSelectedIndex()){
     case 1 : Column=3; break;
     case 2 : Column=5; break;
     case 3 : Column=6; break;
     case 4 : Column=7; break;
     case 5 : Column=8; break;
     case 6 : Column=10; break;
     case 7 : Column=17; break;
     case 8 : Column=14; break;
     default : Column=1; break;
    }
    ColumnType=TableMdlTransOut.Mdl.ColumnsType[Column];
    Selected=Tbl_TransOut.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlTransOut, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_TransOut.changeSelection(FindIndex, 0, false, false);
      onTableTransOutSelectedRowChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang keluar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang keluar dalam keadaan kosong !");
   }
  }
 }
 void printReport(){
  int temp, temp_;
  LinkedList<Long> Id;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  boolean CategorizedPrinting;
  do{
   temp=ListMdlSubject.Mdl.Rows.size();
   if(temp==0){break;}
   
   IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
   IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
   IFV.FPrintDialog.wPrintSettingMode=2;
			IFV.FPrintDialog.wEnableOption=true;
			IFV.FPrintDialog.wEnableColumnar=true;
			IFV.FPrintDialog.wMaxColumnarCount=3;
			IFV.FPrintDialog.wColumnarCount=2;
   IFV.FPrintDialog.wEnableSimplePrint=true;
   IFV.FPrintDialog.wSimplePrint=false;
   IFV.FPrintDialog.wEnableAllowRedundant=false;
   IFV.FPrintDialog.wEnablePrintResultPresentation=true;
   IFV.FPrintDialog.wPrintResultPresentation=1;
   IFV.FPrintDialog.wNormalPrintingText="Urut abjad";
   IFV.FPrintDialog.wCategorizedPrintingText="Organisasikan berdasarkan abjad, lalu urut abjad";
   IFV.FPrintDialog.wEnablePagination=false;
   
   if(IFV.FPrintDialog.showForm()==false){return;}
   if(IFV.FPrintDialog.DialogResult!=1){break;}
   PaperType=IFV.FPrintDialog.PaperType;
   Printer=IFV.FPrintDialog.Printer;
   CategorizedPrinting=(IFV.FPrintDialog.PrintResultPresentation!=1);
   
   TempRows=ListMdlSubject.Mdl.Rows;
   Id=new LinkedList();
   temp_=0;
   do{
    Id.addLast((Long)TempRows.elementAt(temp_)[0]);
    temp_=temp_+1;
   }while(temp_!=temp);

   IFV.PrintGenSubject.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Id, CategorizedPrinting, !IFV.FPrintDialog.SimplePrint, IFV.FPrintDialog.ColumnarCount);
   IFV.FSplashScreen.appear(this, "Membuat Data Print");
   bk=IFV.PrintGenSubject.generateBook(IFV.FSplashScreen);
   IFV.FSplashScreen.disappear();
   if(bk==null){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
    break;
   }
   
   if(IFV.FPrintDialog.ChoosePage){
    IFV.FPrintPage.wBook=bk;
    
    if(IFV.FPrintPage.showForm()==false){return;}
    if(IFV.FPrintPage.DialogResult!=1){break;}
    if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
   }
    

   if(!PPrint.print(bk, Printer, "LapSbj_"+PText.dateToString(new Date(), 101), false)){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
    break;
   }
  }while(false);
 }
 void printCSV(){
  F_PrintSubjectCSV fm1=IFV.FPrintSubjectCSV;
  F_CsvWriteOption fm2=IFV.FCsvWriteOption;
  File f;
  long OperationResult;
  long[] Ids;
  
  if(ListMdlSubject.Mdl.Rows.size()==0){return;}
  
  if(fm1.showForm()==false){return;}
  if(fm1.DialogResult!=1){return;}
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm2.showForm()==false){return;}
  if(fm2.DialogResult!=1){return;}
  
  Ids=ListMdlSubject.getIds(0, PCore.newIntegerArrayInOrderedSequence(ListMdlSubject.Mdl.Rows.size(), 0, 1));
  
  IFV.FSplashScreen.appear(this, "Print Data Ke File CSV");
  OperationResult=PMyShop.printSubjectCSV(
   IFV.FSplashScreen, IFV.Stm, f, fm2.FieldDelimiter, fm2.FieldsSeparator, CCore.CsvDefaultRecordsSeparator, Ids,
   
   fm1.OptCategory, fm1.OptPictureFile, fm1.OptBirthday, fm1.OptComment,
   fm1.OptListCategory, fm1.OptListTag, fm1.OptListPicture,
   fm1.OptListAddress, fm1.OptListContact, fm1.OptListBankAccount, fm1.OptListItem, fm1.OptListItemCategorized,
   
   IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice,
   IFV.CurrentUserIsAdmin || IFV.PrivGUIShowItemSupplierList);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses print data ke file CSV !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Operasi berhasil !\n"+
   "Total data yg di-print ke file CSV = "+PText.intToString(OperationResult));
  */
 }
 int editSubject(int[] Rows, boolean FetchDataOld, OInfoSubject DataOld, OEditSubject Edit, boolean WithSplashScreen){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Subject-Name has already exist
  long Id=0;
  OInfoSubject InfoSubject=null;
  boolean first, error, started;
  Object[] RowData;
  StringBuilder col;
  int Row, count, MaxList, curridx, currlistcount;
  String columns;
  Vector<OTableCellUpdater> Values, PostValues;
  
  long[] ids;
  boolean op_query;
  double progress_inc=0;
  int progress_inc_times;
  boolean IsCheckWithOldValue;
  
  do{
   count=Rows.length;
   op_query=false;

   if(count==1){
    RowData=ListMdlSubject.Mdl.Rows.elementAt(Rows[0]);
    Id=(Long)RowData[0];
    InfoSubject=DataOld; if(InfoSubject==null && FetchDataOld){InfoSubject=PMyShop.getSubjectInfo(IFV.Stm, Id);}
   }
   IsCheckWithOldValue=(count==1 && InfoSubject!=null);

   Values=new Vector(); PostValues=new Vector();
   col=new StringBuilder();
   first=true;
   
   if(Edit.EditName){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubName){
     col.append("Name="+PText.getStringWithQuote(PSql.norm(Edit.EditedName), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedName, null, true)));
    }
    else{
     col.append("Name=replace(Name, '"+PSql.norm(Edit.SubName)+"', '"+PSql.norm(Edit.EditedName)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(1, true, Edit.SubName, Edit.EditedName));
    }
    op_query=true;
   }
   if(Edit.EditComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubComment){
     col.append("Comment="+PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(-1, PText.getString(Edit.EditedComment, null, true)));
    }
    else{
     col.append("Comment=replace(Comment, '"+PSql.norm(Edit.SubComment)+"', '"+PSql.norm(Edit.EditedComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(-1, true, Edit.SubComment, Edit.EditedComment));
    }
    op_query=true;
   }
   if(Edit.EditBirthday){
    if(first){first=false;}else{col.append(',');}
    col.append("Birthday="+PDatabase.dateToSQLStringFormat(Edit.EditedBirthday));
    Values.addElement(new OTableCellUpdaterByObject(2, Edit.EditedBirthday));
    op_query=true;
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)

   // update
   if(WithSplashScreen){IFV.FSplashScreen.appear(this, "Mengubah Data Subjek");}
   
   if(WithSplashScreen){IFV.FSplashScreen.inform(0, "Mengubah "+PText.intToString(count)+" data subjek, harap menunggu ...", null);}
   
   error=false;
   MaxList=1000;
   do{
    if(WithSplashScreen){
     IFV.FSplashScreen.setProgressIncreasePercentage(75);
     progress_inc_times=PMath.round((double)count/(double)MaxList, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    columns=col.toString();
    
    curridx=0;
    started=false;
    do{
     try{
      IFV.Stm.executeUpdate("start transaction;");
      started=true;

      do{
       currlistcount=MaxList;
       if(curridx+currlistcount>count){currlistcount=count-curridx;}
       ids=ListMdlSubject.getIds(0, PCore.subArr(Rows, curridx, currlistcount));

       if(op_query){
        IFV.Stm.executeUpdate("update Subject set "+columns+" where Id in("+PText.toString(ids, 0, ids.length, ",")+");");
       }
       
       if(WithSplashScreen){IFV.FSplashScreen.inform(progress_inc, null, null);}

       curridx=curridx+currlistcount;
      }while(curridx!=count);
      if(error){break;}

      IFV.Stm.executeUpdate("commit;");
     }
     catch(Exception E){error=true; break;}
    }while(false);
    if(error){
     if(started){try{IFV.Stm.executeUpdate("rollback;");}catch(Exception E){}}
     break;
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(100);}

    // post-update

     // update table
    PGUI.changeElements(ListMdlSubject, Rows, Values);
    PGUI.changeElements(ListMdlSubject, Rows, PostValues);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(20, null, null);}

     // update detail
    Id=-1; Row=List_Subject.getSelectedRow(); if(Row!=-1){Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(Row)[0];}

    if(TabbedPane.getSelectedIndex()==2 || SIDet==true){
     fillDet(Id);
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(5, null, null);}
   }while(false);
   if(WithSplashScreen){IFV.FSplashScreen.disappear();}
   
   if(error){break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 void editSingle(int Row){
  long Id;
  OInfoSubject InfoSubject;
  Object[] RowData;
  OEditSubject Edit;
  int result;
  F_SubjectModify fm=IFV.FSubjectModify;
  Date Birthday;
  
  RowData=ListMdlSubject.Mdl.Rows.elementAt(Row);
  Id=(Long)RowData[0];
  InfoSubject=PMyShop.getSubjectInfo(IFV.Stm, Id);
  if(InfoSubject==null){
   JOptionPane.showMessageDialog(null, "Gagal mengubah : terjadi kesalahan ketika mengambil keterangan subjek dari database !");
   return;
  }
  
  fm.wMode=1;
  fm.wInfoSubject=InfoSubject;
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  Birthday=null; if(fm.Birthday!=null){Birthday=fm.Birthday.getTime();}
  
  Edit=new OEditSubject();
  Edit.init(
   true, false, null, fm.Name,
   true, Birthday,
   true, false, null, fm.Comment);

  result=editSubject(PCore.primArr(Row), false, InfoSubject, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi, mungkin dikarenakan :\n"+
   "- Nama subjek sudah ada.");}
  else if(result==-2){}
 }
 void editMultiple(int[] Rows){
  int count=Rows.length;
  F_SubjectModifyMulti fm;
  OEditSubject Edit;
  int result;
  
  fm=IFV.FSubjectModifyMulti;
  fm.wDataCount=count;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  Edit=new OEditSubject();
  Edit.init(
   fm.ChangeName, true, fm.NameFind, fm.NameReplace,
   fm.ChangeBirthday, fm.Birthday,
   fm.ChangeComment, fm.ChangeCommentSub, fm.CommentSub, fm.Comment);
  
  result=editSubject(Rows, false, null, Edit, true);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi, mungkin dikarenakan :\n"+
   "- Terdapat nama subjek yang terduplikasi.");}
  else if(result==-2){}
 }
 void chooseData(){
  int[] row=List_Subject.getSelectedRows();
  int temp, temp_;
  Object[] objs;
  
  temp=row.length;
  if(temp==0){
   JOptionPane.showMessageDialog(null, "Anda harus memilih sebuah subjek pada daftar !");
   return;
  }
  
  ChoosedId=new Long[temp];
  ChoosedName=new String[temp];
  ChoosedPictureFile=new String[temp];
  temp_=0;
  do{
   objs=ListMdlSubject.Mdl.Rows.elementAt(row[temp_]);
   ChoosedId[temp_]=(Long)objs[0];
   ChoosedName[temp_]=(String)objs[1];
   ChoosedPictureFile[temp_]=PCore.objString(objs[3], null);
   temp_=temp_+1;
  }while(temp_!=temp);

  ChoosedAddress=null;
  ChoosedContact=null;
  ChoosedBankAccount=null;
  if(SIBio){
   ChoosedAddress=TableMdlAddr.subData(PCore.primArr(0, 1, 2, 3), Tbl_Addr.getSelectedRows());
   ChoosedContact=TableMdlCont.subData(PCore.primArr(0, 1, 2, 3), Tbl_Cont.getSelectedRows());
   ChoosedBankAccount=TableMdlAcc.subData(PCore.primArr(0, 1, 2, 3), Tbl_Acc.getSelectedRows());
  }
  
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }
 void csvImportExport(){
  IFV.FCsvImportExport.setEnableImport(true, false);
  IFV.FCsvImportExport.wImportOption=1;
  IFV.FCsvImportExport.setEnableExport(true, true, true);
  IFV.FCsvImportExport.wExportOption=2;
  IFV.FCsvImportExport.wIsImport=false;
  
  if(IFV.FCsvImportExport.showForm()==false){return;}
  if(IFV.FCsvImportExport.DialogResult!=1){return;}
  
  if(IFV.FCsvImportExport.IsImport){
   switch(IFV.FCsvImportExport.ImportOption){
    case 1 : csvImportAdd(); break;
   }
   return;
  }
  else{
   switch(IFV.FCsvImportExport.ExportOption){
    case 1 : csvExportDb(false); break;
    case 2 : csvExportDb(true); break;
    case 3 : csvExportSample(); break;
   }
   return;
  }
 }
 void csvImportAdd(){
  Vector<String> PKCols;
  Vector<OCsvImportValue> PKColsValue;
  Vector<String> NonPKCols;
  Vector<OCsvImportValue> NonPKColsValue;
  F_SubjectImportAdd fm;
  OCsvImportValue ColValue;
  OCsvImportValue ColErrorValue;
  OCsvImportValue ColEmptyValue;
  int FileField;
  Object[] ImportResult;
  OCsvImportValue ColValueNull;
  Vector<OCsvImportValue> ColsValueTemp;
  OCsvImportValueCheckable ColValueCheckable;
  
  fm=IFV.FSubjectImportAdd;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  // build primary keys
  PKCols=new Vector(); PKColsValue=new Vector();
  
  ColValueNull=new OCsvImportValueObject(CCore.vNull);
  
  ColValue=new OCsvImportValueAutoId(null, IFV.Stm, "select Id from Subject order by Id asc;");
  PKCols.addElement("Id"); PKColsValue.addElement(ColValue);
  
  // build non primary keys
  NonPKCols=new Vector(); NonPKColsValue=new Vector();
  
  FileField=fm.NameFileField.Value;
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeString), null, null, null);
  NonPKCols.addElement("Name"); NonPKColsValue.addElement(ColValue);
  
  // date can be null
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.Birthday.Value, CCore.TypeDate, CCore.vNull, false));
  FileField=-1; if(fm.BirthdayByFile.Value){FileField=fm.BirthdayFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDate), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("Birthday"); NonPKColsValue.addElement(ColValue);
  
  // string
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.Comment.Value, CCore.TypeString, CCore.vNull, false));
  FileField=-1; if(fm.CommentByFile.Value){FileField=fm.CommentFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeString), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("Comment"); NonPKColsValue.addElement(ColValue);
  
  IFV.FSplashScreen.appear(this, "Mengimpor-Tambah Data Subjek");
  ImportResult=PEtc.csvImportAdd(IFV.FSplashScreen, fm.FileCsv, IFV.Stm, CApp.getTable(CApp.TblSubject),
   PKCols, new OCsvImportValuesForInsert(PKColsValue), NonPKCols, new OCsvImportValuesForInsert(NonPKColsValue), false);
  IFV.FSplashScreen.disappear();
  
  if(ImportResult==null){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan pada saat mengimpor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Berhasil mengimpor-tambah data subjek !"+"\n"+
   "Data yg dibaca : "+PText.intToString((Long)ImportResult[0])+"\n"+
   "Data yg ditambah : "+PText.intToString((Long)ImportResult[1]));
  */
 }
 void csvExportDb(boolean FromListInTheForm){
  String title;
  File f;
  long OperationResult;
  long[] Ids;
  F_CsvWriteOption fm=IFV.FCsvWriteOption;
  String[] Header;
  
  if(FromListInTheForm){
   if(ListMdlSubject.Mdl.Rows.size()==0){
    JOptionPane.showMessageDialog(null,
     "Tidak dapat mengekspor !\n"+
     "Daftar subjek dalam keadaan kosong !");
    return;
   }
  }
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  if(!FromListInTheForm){
   title="Semua Data Subjek";
   Ids=null;
  }
  else{
   title="Data Subjek Pd Form";
   Ids=ListMdlSubject.getIds(0, PCore.newIntegerArrayInOrderedSequence(ListMdlSubject.Mdl.Rows.size(), 0, 1));
  }
  
  IFV.FSplashScreen.appear(this, "Mengekspor "+title);
  Header=CApp.getExportColumnsHeader(CApp.TblSubject, fm.FieldDelimiter);
  OperationResult=PEtc.csvExport(
   IFV.FSplashScreen,
   IFV.Stm, CApp.getExportQuery(CApp.TblSubject, Ids), CApp.getExportColumnsType(CApp.TblSubject), Header, PCore.newIntegerArrayInOrderedSequence(Header.length, 0, 1),
   f, fm.FieldDelimiter, fm.FieldsSeparator, CCore.CsvDefaultRecordsSeparator);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengekspor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Sukses mengekspor data !\n"+
   "Total data yg diekspor = "+PText.intToString(OperationResult));
  */
 }
 void csvExportSample(){
  File f;
  long OperationResult;
  F_CsvWriteOption fm=IFV.FCsvWriteOption;
  String[] Header;
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Mengekspor Sampel Data Subjek");
  Header=CApp.getExportColumnsHeader(CApp.TblSubject, fm.FieldDelimiter);
  OperationResult=PEtc.csvExport(
   IFV.FSplashScreen,
   CApp.getExportSample(CApp.TblSubject), CApp.getExportColumnsType(CApp.TblSubject), Header, PCore.newIntegerArrayInOrderedSequence(Header.length, 0, 1),
   f, fm.FieldDelimiter, fm.FieldsSeparator, CCore.CsvDefaultRecordsSeparator);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengekspor sampel data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Sukses mengekspor sampel data !\n"+
   "Total sampel data yg diekspor = "+PText.intToString(OperationResult));
  */
 }
 void getListCategoryData(int[] SelectedCategoryRows, Vector<String> Alphabets, Vector<Long> Categories){
  int temp, length;
  int row, type;
  
  length=SelectedCategoryRows.length;
  if(length==0){return;}
  
  temp=0;
  do{
   type=2; row=SelectedCategoryRows[temp];
   if(ListMdlCat.DisplayAdditionalRows){
    if(row<ListMdlCat.AdditionalRowsCount){type=1;}
    else{row=row-ListMdlCat.AdditionalRowsCount;}
   }
   
   switch(type){
    case 1 : Alphabets.addElement(ListMdlCat.getNativeElementAt(row)); break;
    case 2 : Categories.addElement(new Long((Integer)ListMdlCat.Mdl.Rows.elementAt(row)[0])); break;
   }
   
   temp=temp+1;
  }while(temp!=length);
 }
 
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF.getCaretPosition()==QTF.getDocument().getLength()){
     if(!ListMdlSubject.Mdl.Rows.isEmpty()){
      if(List_Subject.getSelectedRow()==-1){List_Subject.changeSelection(0, 0, false, false); onListSubjectSelectedRowChanged(false);}
      List_Subject.requestFocusInWindow();
     }
    }
    break;
  }
 }
 
 void initPrivGUIShow(){
  boolean ShowData;
  boolean ShowTrans, ShowPreTrans, ShowTransIn, ShowTransOut, ShowBuyPrice;
  int tab;
  
  // Buy Price
  ShowData=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;
  this.ShowBuyPrice=ShowData;
  
  PGUI.setEnabled(ShowData, CB_SuppViewBuyPrc, CB_SuppViewBuyComment, CB_SuppViewBuyUpdate);
  if(!ShowData && (CB_SuppViewBuyPrc.isSelected() || CB_SuppViewBuyComment.isSelected() || CB_SuppViewBuyUpdate.isSelected())){
   PGUI.setSelected(false, CB_SuppViewBuyPrc, CB_SuppViewBuyComment, CB_SuppViewBuyUpdate); changeSuppViewByNormal();}
  
  PGUI.setEnabled(ShowData, Btn_SuppEdit);
  
  // Item-Supplier List
  ShowData=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowItemSupplierList;
  
  tab=6;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
  
  PGUI.setEnabled(ShowData, CB_QSup);
  if(!ShowData && CB_QSup.isSelected()){CB_QSup.setSelected(false);}
  
  // Trans List
  do{
   ShowTrans=IFV.CurrentUserIsAdmin || (IFV.PrivGUIShowTransList && (IFV.PrivGUIShowTransItemIn || IFV.PrivGUIShowTransItemOut));
   
   ShowPreTrans=IFV.CurrentUserIsAdmin || (IFV.PrivGUIShowPreTransList && (IFV.PrivGUIShowPreTransItemIn || IFV.PrivGUIShowPreTransItemOut));
   
   ShowBuyPrice=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;
   
   ShowTransIn=IFV.CurrentUserIsAdmin || (
    ((IFV.PrivGUIShowTransList && IFV.PrivGUIShowTransItemIn) || (IFV.PrivGUIShowPreTransList && IFV.PrivGUIShowPreTransItemIn)) &&
    IFV.PrivGUIShowBuyPrice
    );

   ShowTransOut=IFV.CurrentUserIsAdmin || (
    ((IFV.PrivGUIShowTransList && IFV.PrivGUIShowTransItemOut) || (IFV.PrivGUIShowPreTransList && IFV.PrivGUIShowPreTransItemOut))
    );

   ShowData=IFV.CurrentUserIsAdmin || (ShowTransIn || ShowTransOut);
   
   tab=7;
   TabbedPane.setEnabledAt(tab, ShowData);
   if(!ShowData){
    if(TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
    break;
   }
   
   RB_TransIsPreTransN.setEnabled(ShowTrans);
   if(!ShowTrans){IFV.PreventAutoFire.doPrevent(true); RB_TransIsPreTransY.setSelected(true);}
   
   RB_TransIsPreTransY.setEnabled(ShowPreTrans);
   if(!ShowPreTrans){IFV.PreventAutoFire.doPrevent(true); RB_TransIsPreTransN.setSelected(true);}
   
   tab=0;
   TabbedPane_TransList.setEnabledAt(tab, ShowTransIn);
   if(!ShowTransIn && TabbedPane_TransList.getSelectedIndex()==tab){TabbedPane_TransList.setSelectedIndex(1);}
   
   tab=1;
   TabbedPane_TransList.setEnabledAt(tab, ShowTransOut);
   if(!ShowTransOut && TabbedPane_TransList.getSelectedIndex()==tab){TabbedPane_TransList.setSelectedIndex(0);}
   
   PGUI.setEnabled(ShowBuyPrice, CB_TransOutPriceBasic);
   if(!ShowBuyPrice && CB_TransOutPriceBasic.isSelected()){CB_TransOutPriceBasic.setSelected(false); CB_TransOutPriceBasicActionPerformed(null);}
  }while(false);
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }
 
 // Supp
 void onSelectedRowSuppChanged(boolean UpdateAnyway){
  int row=Tbl_Supp.getSelectedRow();
  if(LastSelectedRowSupp==row && !UpdateAnyway){return;}
  LastSelectedRowSupp=row;
  if(row==-1){clearInfoSupp(); return;}
  fillInfoSupp(row);
 }
 
 void fillSupp(long MainId){
  boolean ret=false;
  int datacount;
  
  clearSupp();
  if(MainId==-1){return;}
  
  SISuppClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getItemSupp_Query(false, PCore.primArr(MainId), false, null, false, -1, null, CB_SuppViewCategorized.isSelected(), false),
    TableMdlSupp, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Supp.changeSelection(0, 0, false, false); onSelectedRowSuppChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearSupp(); return;}
  
  SISupp=true; if(SIEmptyAll==true){SIEmptyAll=false;}
 }
 void clearSupp(){
  if(SISuppClear){return;}
  
  TableMdlSupp.removeAll();
  LastSelectedRowSupp=-1;
  clearInfoSupp();
  
  SISuppClear=true;
 }
 void fillInfoSupp(int row){
  Object[] objs;
  long Id;
  String Name, BuyComment, PictureFile, Category, str;
  double BuyPrice;
  Date BuyUpdate;
  boolean IsActive;
  
  if(row==-1){return;}
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  objs=TableMdlSupp.Mdl.Rows.elementAt(row);
  Id=PCore.objLong(objs[0], -1L);
  Name=PCore.objString(objs[1], null);
  BuyPrice=PCore.objDouble(objs[2], 0D);
  BuyComment=PCore.objString(objs[3], null);
  BuyUpdate=PCore.objDate(objs[4], null);
  IsActive=PCore.objBoolean(objs[5], false);
  PictureFile=PCore.objString(objs[6], null);
  Category=PCore.objString(objs[7], null);
  
  TA_SuppInfoName.setText("("+PText.separate(String.valueOf(Id), " - ", 5)+") "+Name); TF_SuppInfoCategory.setText(PText.getString(Category, "", Category, true));
  CB_SuppInfoActive.setSelected(IsActive);
  str=null;
  if(ShowBuyPrice){
   str=
    PText.getStringObj(BuyUpdate, "", "~ "+PText.dateToString(BuyUpdate, 2)+" ~\n", false)+
    PText.priceToString(BuyPrice)+
    PText.getString(BuyComment, "", "   { "+BuyComment+" }", true);
  }
  TA_SuppInfoBuy.setText(PText.getString(str, "", true));
  PGUI.fillPanelPictureURL(Pnl_SuppInfoPreview, IFV.Conf.ImageDirItem, PictureFile);
  
  InfoSuppClear=false;
 }
 void clearInfoSupp(){
  if(InfoSuppClear){return;}
  
  PGUI.clearText(TA_SuppInfoName, TF_SuppInfoCategory, TA_SuppInfoBuy);
  CB_SuppInfoActive.setSelected(false);
  PGUI.fillPanelPictureURL(Pnl_SuppInfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoSuppClear=true;
 }
 
 void updateTableSuppView(boolean Requery){
  long MainId;
  int RowMain;
  
  TableMdlSupp.updateColumnsInfo(TableMdlSuppColsName, TableMdlSuppColsType, TableMdlSuppColsShowOption,
   TableMdlSuppColsVisible, TableMdlSuppColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Supp, TableSuppColsWidth);
  if(!Requery){onSelectedRowSuppChanged(false);}
  else{
   MainId=-1; RowMain=List_Subject.getSelectedRow(); if(RowMain!=-1){MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(RowMain)[0];}
   fillSupp(MainId);
  }
 }
 void buildTableSuppColumns(){
  TableMdlSuppColsVisible=PMyShop.getItemSupp_ColumnsVisible(false, CB_SuppViewCategorized.isSelected(),
   CB_SuppViewBuyPrc.isSelected(), CB_SuppViewBuyComment.isSelected(), CB_SuppViewBuyUpdate.isSelected());
  TableSuppColsWidth=PMyShop.getItemSupp_ColumnsWidth(false, CB_SuppViewCategorized.isSelected(),
   CB_SuppViewBuyPrc.isSelected(), CB_SuppViewBuyComment.isSelected(), CB_SuppViewBuyUpdate.isSelected());
 }
 void buildTableSuppOrderBy(){}
 void buildTableSuppViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableSuppColumns();}
  if(RebuildOrderBy){buildTableSuppOrderBy();}
 }
 void changeSuppViewByNormal(){
  buildTableSuppViewStructure(true, false);
  updateTableSuppView(false);
 }
 void changeSuppViewByCategorized(){
  buildTableSuppViewStructure(true, false);
  updateTableSuppView(true);
 }
 
 void onEditingTableSupp(){
  int SuppRow, SuppCol;
  int result=0;
  boolean IsSame;
  
  SuppRow=Tbl_Supp.Editing_Row;
  SuppCol=TableMdlSupp.convertColumnIndexFromViewToModel(Tbl_Supp.Editing_Col);
  
  if(SuppCol!=-1){
   IsSame=PCore.grading(TableMdlSupp.Mdl.ColumnsType[SuppCol], null, Tbl_Supp.Editing_ValueOld, true, null, Tbl_Supp.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(SuppCol==-1){result=0; break;}
   result=onEditingTableSupp_Supp(SuppRow, SuppCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang suplai !");}
 }
 int onEditingTableSupp_Supp(int SuppRow, int SuppCol){
  int ret=0;
  
  boolean valid;
  int MainRow;
  OEditItemSupplier Edit;
  
  do{
   MainRow=List_Subject.getSelectedRow(); if(MainRow==-1){break;}
   
   /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
   
   Edit=new OEditItemSupplier();
   valid=true;
   switch(SuppCol){
    // double not null, positive only, >=0
    case  2 :
     Edit.EditBuyPrc=true; Edit.EditBuyPrcMode=0; Edit.EditedBuyPrc=PCore.objDouble(Tbl_Supp.Editing_ValueNew, -1D); if(Edit.EditedBuyPrc<0){valid=false;}
     Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(PDate.generateDate(new Date(), false), null);
     break;
     
    // String null
    case 3 :
     Edit.EditBuyComment=true; Edit.EditBuyCommentMode=0; Edit.EditBuyCommentSub=false; Edit.EditedBuyComment=PCore.objString(Tbl_Supp.Editing_ValueNew, null);
     Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(PDate.generateDate(new Date(), false), null);
     break;
    
    // date null
    case 4 : Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(Tbl_Supp.Editing_ValueNew, null); break;
   }
   if(!valid){ret=-2; break;}

   if(!editSupp(PCore.primArr(MainRow), MainRow, 1, PCore.primArr(SuppRow), null, null, Edit, null)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void addSupp(){
  int MainRow;
  long MainId;
  String MainName;
  Date Update=null;
  Object[] NewSupp;
  OInfoItem InfoItem;
  F_ItemSupplierModify fm=IFV.FItemSupplierModify;
  
  MainRow=List_Subject.getSelectedRow();
  if(!PGUI.isEnabled(Btn_SuppAdd) || !SISupp || MainRow==-1){return;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
  
  fm.wMode=2;
  fm.wId=MainId;
  fm.wName=MainName;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  if(fm.Update==null){Update=PDate.generateDate(new Date(), false);}else{Update=fm.Update.getTime();}
  InfoItem=PMyShop.getItemInfo(IFV.Stm, MainId, false); if(InfoItem==null){InfoItem=new OInfoItem();}
  
  NewSupp=PCore.objArrVariant(
   fm.ChooseId, fm.ChooseName, fm.BuyPrc, PText.getString(fm.BuyPriceComment, null, true), Update, fm.Active, InfoItem.PictureFile, InfoItem.CategoryName);
  
  if(!addSupp(false, PCore.primArr(MainRow), MainRow, PCore.toMultiRows2(NewSupp), null)){
   JOptionPane.showMessageDialog(null, "Gagal menambah barang suplai, mungkin dikarenakan :\n"+
    "Barang sudah ada pada daftar barang suplai."); return;
  }
 }
 boolean addSupp(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Supps, OFormInformProgress Progress){
  boolean ret=false;
  int result;
  
  if(Progress!=null){Progress.appear(this, "Menambah Barang Suplai");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   result=addSupp_(StmIgnore, MainRows, MainRow, Supps, Progress); if(result==-2){break;}
   
   if(result!=-1){
    Tbl_Supp.changeSelection(result, 0, false, false); onSelectedRowSuppChanged(true);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 int addSupp_(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Supps, OFormInformProgress Progress){
  int ret=-2; // -2 error, -1 success & not added, >=0 success & added
  long[] MainIds=ListMdlSubject.getIds(0, MainRows);
  
  do{
   if(!PMyShop.itemSuppAdd(IFV.Stm, StmIgnore, false, MainIds, Supps, Progress)){break;}
   ret=addSupp_GUI(MainRow, Supps);
  }while(false);
  
  return ret;
 }
 int addSupp_GUI(int MainRow, Vector<Object[]> Supps){
  int ret=-1;
  int temp, count;
  long MainId;
  long[] CompIds;
  int[] coltype, colcheck, AllRows;
  Object[] Supp;
  Vector<Object[]> Data, QSupps;
  
  coltype=TableMdlSupp.getColumnsType();
  colcheck=PCore.primArr(0);
  Data=TableMdlSupp.getRows();
  AllRows=PCore.newIntegerArrayInOrderedSequence(Supps.size(), 0, 1);
  
  if(MainRow==-1 || !SISupp){return ret;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  CompIds=PTable.subDataOfIds(Supps, coltype, AllRows, 0);
  
  QSupps=PMyShop.getItemSupp(IFV.Stm, false, MainId, CompIds, false);
  count=0; if(QSupps!=null){count=QSupps.size();} if(count==0){return ret;}
  
  temp=0;
  do{
   Supp=QSupps.elementAt(temp);
   
   if(PTable.findData(coltype, true, Data, colcheck, Supp, colcheck)==-1){
    // add to list supp
    ret=Data.size();
    TableMdlSupp.insert(ret, Supp);
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 Vector<Object[]> getSuppChecksData(long[] ByIds_CompIds){
  Vector<Object[]> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(PCore.objArr_PrimArr(ByIds_CompIds));
  }
  
  return ret;
 }
 Vector<Integer> getSuppChecksColumn(long[] ByIds_CompIds){
  Vector<Integer> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(0);
  }
  
  return ret;
 }
 void editSupp(){
  boolean bool;
  int MainRow;
  long MainId;
  String MainName;
  int[] CompRows;
  long CompId;
  String CompName;
  Date Update=null;
  OInfoItemSupplier InfoItemSupp=null;
  OEditItemSupplier Edit=new OEditItemSupplier();
  F_ItemSupplierModify fm1=IFV.FItemSupplierModify;
  F_ItemSupplierModifyMulti fm2=IFV.FItemSupplierModifyMulti;
  
  MainRow=List_Subject.getSelectedRow();
  CompRows=Tbl_Supp.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SuppEdit) || !SISupp || MainRow==-1 || CompRows.length==0){return;}
  
  if(CompRows.length==1){
   bool=false;
   do{
    MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
    MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
    CompId=(Long)TableMdlSupp.Mdl.Rows.elementAt(CompRows[0])[0];
    CompName=(String)TableMdlSupp.Mdl.Rows.elementAt(CompRows[0])[1];
    InfoItemSupp=PMyShop.getItemSupplierInfo(IFV.Stm, false, MainId, CompId); if(InfoItemSupp==null){break;}

    bool=true;
   }while(false);
   if(!bool){JOptionPane.showMessageDialog(null, "Gagal mengambil info barang suplai !"); return;}

   fm1.wMode=3;
   fm1.wId=MainId;
   fm1.wName=MainName;
   fm1.wChooseId=CompId;
   fm1.wChooseName=CompName;
   fm1.wBuyPrc=InfoItemSupp.BuyPrc;
   fm1.wBuyPriceComment=InfoItemSupp.BuyComment;
   fm1.wUpdate=InfoItemSupp.Update;
   fm1.wActive=InfoItemSupp.IsActive;

   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}

   if(fm1.Update==null){Update=PDate.generateDate(new Date(), false);}else{Update=PDate.generateDate(fm1.Update.getTime(), false);}
   
   Edit.init(
    true, fm1.ChooseId, fm1.ChooseName,
    true, 0, fm1.BuyPrc,
    true, 0, false, null, PText.getString(fm1.BuyPriceComment, null, true),
    true, 0, Update,
    true, 0, fm1.Active);
  }
  else{
   fm2.wDataCount=CompRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Update=fm2.Update; if(Update==null){Update=PDate.generateDate(new Date(), false);}
   
   Edit.init(
    false, -1, null,
    fm2.ChangeBuyPrc, 0, fm2.BuyPrc,
    fm2.ChangeBuyPriceComment, 0, fm2.ChangeBuyPriceCommentSub, fm2.BuyPriceCommentSub, fm2.BuyPriceComment,
    fm2.ChangeUpdate, 0, Update,
    fm2.ChangeActive, 0, fm2.Active);
  }
  
  if(!editSupp(PCore.primArr(MainRow), MainRow, 1, CompRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data barang suplai, mungkin dikarenakan :\n"+
    "Barang sudah ada pada daftar barang suplai.");
   return;
  }
 }
 boolean editSupp(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_SuppRows,
   Vector<Object[]> ByVect_Data,
   long[] ByIds_CompIds,
  OEditItemSupplier Edit, OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  int SuppRow;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null;
  OCustomListModel List;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  long[] ByIds=null;
  
  OInfoItem InfoItem;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlSupp.getRows(), ByTable_SuppRows, PCore.newIntegerArrayInOrderedSequence(TableMdlSupp.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_SuppRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), getSuppChecksData(ByIds_CompIds),
      getSuppChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Mengubah Barang Suplai");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  do{
   Updater=new Vector();
   
   List=new OCustomListModel(false); List.setColumnsInfo(TableMdlSupp.getColumnsType(), 1); if(ByVect!=null){List.append(ByVect);}
   
   // Updater
   if(Edit.EditComp){
    InfoItem=PMyShop.getItemInfo(IFV.Stm, Edit.EditedCompId, false); if(InfoItem==null){InfoItem=new OInfoItem();}
    
    Updater.addElement(new OTableCellUpdaterByObject(0, Edit.EditedCompId));
    Updater.addElement(new OTableCellUpdaterByObject(1, Edit.EditedCompName));
    Updater.addElement(new OTableCellUpdaterByObject(6, InfoItem.PictureFile));
    Updater.addElement(new OTableCellUpdaterByObject(7, InfoItem.CategoryName));
   }
   if(Edit.EditBuyPrc){
    switch(Edit.EditBuyPrcMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(2, Edit.EditedBuyPrc); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(2, PCore.primArr(0), List, PCore.primArr(0), 2, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyComment){
    if(!Edit.EditBuyCommentSub){
     switch(Edit.EditBuyCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedBuyComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(3, PCore.primArr(0), List, PCore.primArr(0), 3, false, null); break;
     }
    }
    else{
     switch(Edit.EditBuyCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(3, true, Edit.EditedBuyCommentSub, Edit.EditedBuyComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyUpdate){
    switch(Edit.EditBuyUpdateMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(4, Edit.EditedBuyUpdate); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(4, PCore.primArr(0), List, PCore.primArr(0), 4, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditIsActive){
    switch(Edit.EditIsActiveMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(5, Edit.EditedIsActive); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(5, PCore.primArr(0), List, PCore.primArr(0), 5, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   
   if(!PMyShop.itemSuppEdit(IFV.Stm, false, MainIds, IsByVect, ByVect, ByIds, Edit, Progress)){break;}
   
   PGUI.changeElements(TableMdlSupp, TableRows, Updater);
   
   if(SISupp){
    SuppRow=Tbl_Supp.getSelectedRow();
    fillInfoSupp(SuppRow);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 void removeSupp(){
  int MainRow;
  int[] SuppRows;
  
  MainRow=List_Subject.getSelectedRow();
  SuppRows=Tbl_Supp.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SuppRemove) || !SISupp || MainRow==-1 || SuppRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+SuppRows.length+" barang suplai yang dipilih ?",
   "Konfirmasi Penghapusan Barang Suplai", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!removeSupp(PCore.primArr(MainRow), MainRow, 1, SuppRows, null, null, null)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data barang suplai !"); return;}
 }
 boolean removeSupp(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_SuppRows,
   Vector<Object[]> ByVect_Data,
   long[] ByIds_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  long[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlSupp.getRows(), ByTable_SuppRows, PCore.newIntegerArrayInOrderedSequence(TableMdlSupp.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_SuppRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), getSuppChecksData(ByIds_CompIds),
      getSuppChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Menghapus Barang Suplai");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   if(!PMyShop.itemSuppRemove(IFV.Stm, true, false, MainIds, IsByVect, ByVect, ByIds, Progress)){break;}
   
   TableMdlSupp.remove(TableRows); onSelectedRowSuppChanged(true);
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 void findSupp(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str;
  
  str=TF_SuppFind.getText();
  if(str.length()==0){return;}
  
  if(TableMdlSupp.Mdl.Rows.size()==0){
   JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !");
   return;
  }
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  switch(CmB_SuppFind.getSelectedIndex()){
   case 1 : Column=1;  break;
   case 2 : Column=7;  break;
   case 3 : Column=3;  break;
   default : Column=0; break;
  }
  ColumnType=TableMdlSupp.getColumnsType()[Column];
  Selected=Tbl_Supp.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlSupp, Column, ColumnType, str, Selected, Mode);
  
  if(FindIndex==-1){
   JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !");
   return;
  }
  
  if(Selected==FindIndex){return;}
  
  Tbl_Supp.changeSelection(FindIndex, 0, false, false);
  onSelectedRowSuppChanged(false);
 }
 
 void setItemSuppActive(boolean ActiveValue){
  int MainRow=List_Subject.getSelectedRow();
  int[] SuppRows=Tbl_Supp.getSelectedRows();
  OEditItemSupplier Edit;
  
  if(MainRow==-1 || SuppRows.length==0){return;}
  
  Edit=new OEditItemSupplier();
  Edit.EditIsActive=true; Edit.EditIsActiveMode=0; Edit.EditedIsActive=ActiveValue;
  
  if(!editSupp(PCore.primArr(MainRow), MainRow, 1, SuppRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !"); return;}
 }
 
 // Bio
 void fillBio(long Id){
  boolean error;
  
  // clear list and list index, but not other components and index
  if(!SIBioClear){
   clearAddr();
   clearCont();
   clearAcc();
  }
  
  // fetch list data
  SIBioClear=false;
  
  error=true;
  do{
   if(!fillAddr(Id)){break;}
   if(!fillCont(Id)){break;}
   if(!fillAcc(Id)){break;}
   
   error=false;
  }while(false);
  
  if(error){
   clearBio();
   JOptionPane.showMessageDialog(null, "Gagal mengambil daftar biodata subjek dari database !");
   return;
  }
  
  SIBio=true; if(SIEmptyAll==true){SIEmptyAll=false;}
 }
 void clearBio(){
  if(SIBioClear){return;}
  
  clearAddr();
  clearCont();
  clearAcc();

  SIBioClear=true;
 }
 
 // Address
 void onSelectedRowAddrChanged(boolean UpdateAnyway){
  int row=Tbl_Addr.getSelectedRow();
  if(LastSelectedRowAddr==row && !UpdateAnyway){return;}
  LastSelectedRowAddr=row;
  if(row==-1){clearInfoAddr(); return;}
  fillInfoAddr(row);
 }
 
 boolean fillAddr(long MainId){
  boolean ret=false;
  int datacount;
  
  clearAddr();
  if(MainId==-1){return true;}
  
  SIAddrClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getSubjectAddr_Query(PCore.primArr(MainId), false, null, false, -1, null, false),
    TableMdlAddr, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Addr.changeSelection(0, 0, false, false); onSelectedRowAddrChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearAddr();}
  
  return ret;
 }
 void clearAddr(){
  if(SIAddrClear){return;}
  
  TableMdlAddr.removeAll();
  LastSelectedRowAddr=-1;
  clearInfoAddr();
  
  SIAddrClear=true;
 }
 void fillInfoAddr(int row){
  Object[] objs;
  String City, Address, Comment;
  
  if(row==-1){return;}
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  objs=TableMdlAddr.Mdl.Rows.elementAt(row);
  City=PCore.objString(objs[2], null);
  Address=PCore.objString(objs[3], null);
  Comment=PCore.objString(objs[4], null);
  
  TF_SubCity.setText(PText.getString(City, "", false));
  TA_SubAddress.setText(
   PText.getString(Address, "", false)+
   PText.getString(Comment, "", "\n{ "+Comment+" }", true));
  
  InfoAddrClear=false;
 }
 void clearInfoAddr(){
  if(InfoAddrClear){return;}
  
  PGUI.clearText(TF_SubCity, TA_SubAddress);
  
  InfoAddrClear=true;
 }
 
 void updateTableAddrView(boolean Requery){
  long MainId;
  int RowMain;
  
  TableMdlAddr.updateColumnsInfo(TableMdlAddrColsName, TableMdlAddrColsType, TableMdlAddrColsShowOption,
   TableMdlAddrColsVisible, TableMdlAddrColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Addr, TableAddrColsWidth);
  if(!Requery){onSelectedRowAddrChanged(false);}
  else{
   MainId=-1; RowMain=List_Subject.getSelectedRow(); if(RowMain!=-1){MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(RowMain)[0];}
   fillAddr(MainId);
  }
 }
 void buildTableAddrColumns(){
  TableMdlAddrColsVisible=PMyShop.getSubjectAddr_ColumnsVisible(CB_AddrViewCity.isSelected(), CB_AddrViewComment.isSelected());
  TableAddrColsWidth=PMyShop.getSubjectAddr_ColumnsWidth(CB_AddrViewCity.isSelected(), CB_AddrViewComment.isSelected());
 }
 void buildTableAddrOrderBy(){}
 void buildTableAddrViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableAddrColumns();}
  if(RebuildOrderBy){buildTableAddrOrderBy();}
 }
 void changeAddrViewByNormal(){
  buildTableAddrViewStructure(true, false);
  updateTableAddrView(false);
 }
 
 void onEditingTableAddr(){
  int AddrRow, AddrCol;
  int result=0;
  boolean IsSame;
  
  AddrRow=Tbl_Addr.Editing_Row;
  AddrCol=TableMdlAddr.convertColumnIndexFromViewToModel(Tbl_Addr.Editing_Col);
  
  if(AddrCol!=-1){
   IsSame=PCore.grading(TableMdlAddr.Mdl.ColumnsType[AddrCol], null, Tbl_Addr.Editing_ValueOld, true, null, Tbl_Addr.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(AddrCol==-1){result=0; break;}
   result=onEditingTableAddr_Addr(AddrRow, AddrCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut alamat !");}
 }
 int onEditingTableAddr_Addr(int AddrRow, int AddrCol){
  int ret=0;
  
  boolean valid;
  int MainRow;
  OEditSubjectAddress Edit;
  String str;
  
  do{
   MainRow=List_Subject.getSelectedRow(); if(MainRow==-1){break;}
   
   /* "enumeration", "city_id", "city_name", "address", "comment" */
   
   Edit=new OEditSubjectAddress();
   valid=true;
   switch(AddrCol){
     
    // String null
    case 4 :
     Edit.EditComment=true; Edit.EditCommentMode=0; Edit.EditCommentSub=false; str=PCore.objString(Tbl_Addr.Editing_ValueNew, null);
     Edit.EditedComment=PText.getString(str, null, true);
     break;
    
    // String not null
    case 3 :
     Edit.EditAddr=true; Edit.EditAddrMode=0; Edit.EditAddrSub=false; str=PCore.objString(Tbl_Addr.Editing_ValueNew, "");
     valid=PText.checkInput(str, false, CApp.DbVarcharMaxSize, 0, 1, 1, 0); if(valid){Edit.EditedAddr=str;}
     break;
   }
   if(!valid){ret=-2; break;}

   if(!editAddr(PCore.primArr(MainRow), MainRow, 1, PCore.primArr(AddrRow), null, null, Edit, null)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void addAddr(){
  int MainRow;
  long MainId;
  String MainName;
  Object[] NewAddr;
  F_AddressModify fm=IFV.FAddressModify;
  
  MainRow=List_Subject.getSelectedRow();
  if(!PGUI.isEnabled(Btn_SubAddressAdd) || !SIBio || MainRow==-1){return;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
  
  fm.wMode=0;
  fm.wName=MainName;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  NewAddr=PCore.objArrVariant(
   null,
   PCore.subtituteLong(fm.CityId, -1, fm.CityId, null), PCore.subtituteLong(fm.CityId, -1, fm.CityName, null),
   fm.Address, PText.getString(fm.Comment, null, true));
  
  if(!addAddr(false, PCore.primArr(MainRow), MainRow, PCore.toMultiRows2(NewAddr), null)){
   JOptionPane.showMessageDialog(null, "Gagal menambah alamat, mungkin dikarenakan :\n"+
    "Alamat sudah ada pada daftar alamat."); return;
  }
 }
 boolean addAddr(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Addrs, OFormInformProgress Progress){
  boolean ret=false;
  int result;
  
  if(Progress!=null){Progress.appear(this, "Menambah Alamat");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   result=addAddr_(StmIgnore, MainRows, MainRow, Addrs, Progress); if(result==-2){break;}
   
   if(result!=-1){
    Tbl_Addr.changeSelection(result, 0, false, false); onSelectedRowAddrChanged(true);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 int addAddr_(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Addrs, OFormInformProgress Progress){
  int ret=-2; // -2 error, -1 success & not added, >=0 success & added
  long[] MainIds=ListMdlSubject.getIds(0, MainRows);
  
  do{
   if(!PMyShop.subjectAddrAdd(IFV.Stm, StmIgnore, MainIds, Addrs, Progress)){break;}
   ret=addAddr_GUI(MainRow, Addrs);
  }while(false);
  
  return ret;
 }
 int addAddr_GUI(int MainRow, Vector<Object[]> Addrs){
  int ret=-1;
  int temp, count;
  long MainId;
  int[] CompIds;
  int[] coltype, colcheck, AllRows;
  Object[] Addr;
  Vector<Object[]> Data, QAddrs;
  
  coltype=TableMdlAddr.getColumnsType();
  colcheck=PCore.primArr(0);
  Data=TableMdlAddr.getRows();
  AllRows=PCore.newIntegerArrayInOrderedSequence(Addrs.size(), 0, 1);
  
  if(MainRow==-1 || !SIBio){return ret;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  CompIds=PCore.convertPrimArrLongToInt(PTable.subDataOfIds(Addrs, coltype, AllRows, 0));
  
  QAddrs=PMyShop.getSubjectAddr(IFV.Stm, MainId, CompIds);
  count=0; if(QAddrs!=null){count=QAddrs.size();} if(count==0){return ret;}
  
  temp=0;
  do{
   Addr=QAddrs.elementAt(temp);
   
   if(PTable.findData(coltype, true, Data, colcheck, Addr, colcheck)==-1){
    // add to list addr
    ret=Data.size();
    TableMdlAddr.insert(ret, Addr);
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 Vector<Object[]> getAddrChecksData(int[] ByIds_CompIds){
  Vector<Object[]> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(PCore.objArr_PrimArr(ByIds_CompIds));
  }
  
  return ret;
 }
 Vector<Integer> getAddrChecksColumn(int[] ByIds_CompIds){
  Vector<Integer> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(0);
  }
  
  return ret;
 }
 void editAddr(){
  boolean bool;
  int MainRow;
  long MainId;
  String MainName;
  int[] CompRows;
  int CompId;
  OInfoSubjectAddress InfoSubjectAddress=null;
  OEditSubjectAddress Edit=new OEditSubjectAddress();
  F_AddressModify fm1=IFV.FAddressModify;
  F_AddressModifyMulti fm2=IFV.FAddressModifyMulti;
  
  MainRow=List_Subject.getSelectedRow();
  CompRows=Tbl_Addr.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SubAddressEdit) || !SIBio || MainRow==-1 || CompRows.length==0){return;}
  
  if(CompRows.length==1){
   bool=false;
   do{
    MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
    MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
    CompId=(Integer)TableMdlAddr.Mdl.Rows.elementAt(CompRows[0])[0];
    InfoSubjectAddress=PMyShop.getSubjectAddrInfo(IFV.Stm, MainId, CompId); if(InfoSubjectAddress==null){break;}

    bool=true;
   }while(false);
   if(!bool){JOptionPane.showMessageDialog(null, "Gagal mengambil info alamat !"); return;}

   fm1.wMode=1;
   fm1.wName=MainName;
   fm1.wCityId=InfoSubjectAddress.CityId; fm1.wCityName=InfoSubjectAddress.CityName;
   fm1.wAddress=InfoSubjectAddress.Address;
   fm1.wComment=InfoSubjectAddress.Comment;

   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}
   
   Edit.init(
    true, 0, fm1.CityId, fm1.CityName,
    true, 0, false, null, PText.getString(fm1.Address, null, true),
    true, 0, false, null, PText.getString(fm1.Comment, null, true));
  }
  else{
   fm2.wDataCount=CompRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    false, 0, -1, null,
    false, 0, false, null, null,
    fm2.ChangeComment, 0, fm2.ChangeCommentSub, fm2.CommentSub, fm2.Comment);
  }
  
  if(!editAddr(PCore.primArr(MainRow), MainRow, 1, CompRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data alamat, mungkin dikarenakan :\n"+
    "Alamat sudah ada pada daftar alamat.");
   return;
  }
 }
 boolean editAddr(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_AddrRows,
   Vector<Object[]> ByVect_Data,
   int[] ByIds_CompIds,
  OEditSubjectAddress Edit, OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  int AddrRow;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null, CellUpdater2=null;
  OCustomListModel List;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  int[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlAddr.getRows(), ByTable_AddrRows, PCore.newIntegerArrayInOrderedSequence(TableMdlAddr.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_AddrRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAddr.getRows(), TableMdlAddr.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAddr.getRows(), TableMdlAddr.getColumnsType(), getAddrChecksData(ByIds_CompIds),
      getAddrChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Mengubah Alamat");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  do{
   Updater=new Vector();
   
   List=new OCustomListModel(false); List.setColumnsInfo(TableMdlAddr.getColumnsType(), 1); if(ByVect!=null){List.append(ByVect);}
   
   // Updater
   if(Edit.EditCity){
    switch(Edit.EditCityMode){
     case 0 :
      CellUpdater=new OTableCellUpdaterByObject(1, PCore.subtituteLong(Edit.EditedCityId, -1, Edit.EditedCityId, null));
      CellUpdater2=new OTableCellUpdaterByObject(2, PCore.subtituteLong(Edit.EditedCityId, -1, Edit.EditedCityName, null));
      break;
     case 3 :
      CellUpdater=new OTableCellUpdaterByList(1, PCore.primArr(0), List, PCore.primArr(0), 1, false, null);
      CellUpdater2=new OTableCellUpdaterByList(2, PCore.primArr(0), List, PCore.primArr(0), 2, false, null);
      break;
    }
    Updater.addElement(CellUpdater);
    Updater.addElement(CellUpdater2);
   }
   if(Edit.EditAddr){
    if(!Edit.EditAddrSub){
     switch(Edit.EditAddrMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedAddr, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(3, PCore.primArr(0), List, PCore.primArr(0), 3, false, null); break;
     }
    }
    else{
     switch(Edit.EditAddrMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(3, true, Edit.EditedAddrSub, Edit.EditedAddr); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditComment){
    if(!Edit.EditCommentSub){
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(4, PText.getString(Edit.EditedComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(4, PCore.primArr(0), List, PCore.primArr(0), 4, false, null); break;
     }
    }
    else{
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(4, true, Edit.EditedCommentSub, Edit.EditedComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   
   if(!PMyShop.subjectAddrEdit(IFV.Stm, MainIds, IsByVect, ByVect, ByIds, Edit, Progress)){break;}
   
   PGUI.changeElements(TableMdlAddr, TableRows, Updater);
   
   if(SIBio){
    AddrRow=Tbl_Addr.getSelectedRow();
    fillInfoAddr(AddrRow);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 void removeAddr(){
  int MainRow;
  int[] AddrRows;
  
  MainRow=List_Subject.getSelectedRow();
  AddrRows=Tbl_Addr.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SubAddressRemove) || !SIBio || MainRow==-1 || AddrRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+AddrRows.length+" alamat yang dipilih ?",
   "Konfirmasi Penghapusan Alamat", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!removeAddr(PCore.primArr(MainRow), MainRow, 1, AddrRows, null, null, null)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data alamat !"); return;}
 }
 boolean removeAddr(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_AddrRows,
   Vector<Object[]> ByVect_Data,
   int[] ByIds_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  int[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlAddr.getRows(), ByTable_AddrRows, PCore.newIntegerArrayInOrderedSequence(TableMdlAddr.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_AddrRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAddr.getRows(), TableMdlAddr.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAddr.getRows(), TableMdlAddr.getColumnsType(), getAddrChecksData(ByIds_CompIds),
      getAddrChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Menghapus Alamat");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   if(!PMyShop.subjectAddrRemove(IFV.Stm, true, MainIds, IsByVect, ByVect, ByIds, Progress)){break;}
   
   TableMdlAddr.remove(TableRows); onSelectedRowAddrChanged(true);
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 // Contact
 void onSelectedRowContChanged(boolean UpdateAnyway){
  int row=Tbl_Cont.getSelectedRow();
  if(LastSelectedRowCont==row && !UpdateAnyway){return;}
  LastSelectedRowCont=row;
  if(row==-1){clearInfoCont(); return;}
  fillInfoCont(row);
 }
 
 boolean fillCont(long MainId){
  boolean ret=false;
  int datacount;
  
  clearCont();
  if(MainId==-1){return true;}
  
  SIContClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getSubjectCont_Query(PCore.primArr(MainId), false, null, false, -1, null, false),
    TableMdlCont, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Cont.changeSelection(0, 0, false, false); onSelectedRowContChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearCont();}
  
  return ret;
 }
 void clearCont(){
  if(SIContClear){return;}
  
  TableMdlCont.removeAll();
  LastSelectedRowCont=-1;
  clearInfoCont();
  
  SIContClear=true;
 }
 void fillInfoCont(int row){
  Object[] objs;
  String ContactType, Contact, Comment;
  
  if(row==-1){return;}
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  objs=TableMdlCont.Mdl.Rows.elementAt(row);
  ContactType=PCore.objString(objs[2], null);
  Contact=PCore.objString(objs[3], null);
  Comment=PCore.objString(objs[4], null);
  
  TF_SubContactType.setText(PText.getString(ContactType, "", false));
  TA_SubContact.setText(
   PText.getString(Contact, "", false)+
   PText.getString(Comment, "", "\n{ "+Comment+" }", true));
  
  InfoContClear=false;
 }
 void clearInfoCont(){
  if(InfoContClear){return;}
  
  PGUI.clearText(TF_SubContactType, TA_SubContact);
  
  InfoContClear=true;
 }
 
 void updateTableContView(boolean Requery){
  long MainId;
  int RowMain;
  
  TableMdlCont.updateColumnsInfo(TableMdlContColsName, TableMdlContColsType, TableMdlContColsShowOption,
   TableMdlContColsVisible, TableMdlContColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Cont, TableContColsWidth);
  if(!Requery){onSelectedRowContChanged(false);}
  else{
   MainId=-1; RowMain=List_Subject.getSelectedRow(); if(RowMain!=-1){MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(RowMain)[0];}
   fillCont(MainId);
  }
 }
 void buildTableContColumns(){
  TableMdlContColsVisible=PMyShop.getSubjectCont_ColumnsVisible(CB_ContViewContactType.isSelected(), CB_ContViewComment.isSelected());
  TableContColsWidth=PMyShop.getSubjectCont_ColumnsWidth(CB_ContViewContactType.isSelected(), CB_ContViewComment.isSelected());
 }
 void buildTableContOrderBy(){}
 void buildTableContViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableContColumns();}
  if(RebuildOrderBy){buildTableContOrderBy();}
 }
 void changeContViewByNormal(){
  buildTableContViewStructure(true, false);
  updateTableContView(false);
 }
 
 void onEditingTableCont(){
  int ContRow, ContCol;
  int result=0;
  boolean IsSame;
  
  ContRow=Tbl_Cont.Editing_Row;
  ContCol=TableMdlCont.convertColumnIndexFromViewToModel(Tbl_Cont.Editing_Col);
  
  if(ContCol!=-1){
   IsSame=PCore.grading(TableMdlCont.Mdl.ColumnsType[ContCol], null, Tbl_Cont.Editing_ValueOld, true, null, Tbl_Cont.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(ContCol==-1){result=0; break;}
   result=onEditingTableCont_Cont(ContRow, ContCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut kontak !");}
 }
 int onEditingTableCont_Cont(int ContRow, int ContCol){
  int ret=0;
  
  boolean valid;
  int MainRow;
  OEditSubjectContact Edit;
  String str;
  
  do{
   MainRow=List_Subject.getSelectedRow(); if(MainRow==-1){break;}
   
   /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
   
   Edit=new OEditSubjectContact();
   valid=true;
   switch(ContCol){
     
    // String null
    case 4 :
     Edit.EditComment=true; Edit.EditCommentMode=0; Edit.EditCommentSub=false; str=PCore.objString(Tbl_Cont.Editing_ValueNew, null);
     Edit.EditedComment=PText.getString(str, null, true);
     break;
    
    // String not null
    case 3 :
     Edit.EditCont=true; Edit.EditContMode=0; Edit.EditContSub=false; str=PCore.objString(Tbl_Cont.Editing_ValueNew, "");
     valid=PText.checkInput(str, false, 150, 0, 1, 1, 0); if(valid){Edit.EditedCont=str;}
     break;
   }
   if(!valid){ret=-2; break;}

   if(!editCont(PCore.primArr(MainRow), MainRow, 1, PCore.primArr(ContRow), null, null, Edit, null)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void addCont(){
  int MainRow;
  long MainId;
  String MainName;
  Object[] NewCont;
  F_ContactModify fm=IFV.FContactModify;
  
  MainRow=List_Subject.getSelectedRow();
  if(!PGUI.isEnabled(Btn_SubContactAdd) || !SIBio || MainRow==-1){return;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
  
  fm.wMode=0;
  fm.wName=MainName;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  NewCont=PCore.objArrVariant(
   null,
   PCore.subtituteLong(fm.ContactTypeId, -1, fm.ContactTypeId, null), PCore.subtituteLong(fm.ContactTypeId, -1, fm.ContactTypeName, null),
   fm.Contact, PText.getString(fm.Comment, null, true));
  
  if(!addCont(false, PCore.primArr(MainRow), MainRow, PCore.toMultiRows2(NewCont), null)){
   JOptionPane.showMessageDialog(null, "Gagal menambah kontak, mungkin dikarenakan :\n"+
    "Kontak sudah ada pada daftar kontak."); return;
  }
 }
 boolean addCont(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Conts, OFormInformProgress Progress){
  boolean ret=false;
  int result;
  
  if(Progress!=null){Progress.appear(this, "Menambah Kontak");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   result=addCont_(StmIgnore, MainRows, MainRow, Conts, Progress); if(result==-2){break;}
   
   if(result!=-1){
    Tbl_Cont.changeSelection(result, 0, false, false); onSelectedRowContChanged(true);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 int addCont_(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Conts, OFormInformProgress Progress){
  int ret=-2; // -2 error, -1 success & not added, >=0 success & added
  long[] MainIds=ListMdlSubject.getIds(0, MainRows);
  
  do{
   if(!PMyShop.subjectContAdd(IFV.Stm, StmIgnore, MainIds, Conts, Progress)){break;}
   ret=addCont_GUI(MainRow, Conts);
  }while(false);
  
  return ret;
 }
 int addCont_GUI(int MainRow, Vector<Object[]> Conts){
  int ret=-1;
  int temp, count;
  long MainId;
  int[] CompIds;
  int[] coltype, colcheck, AllRows;
  Object[] Cont;
  Vector<Object[]> Data, QConts;
  
  coltype=TableMdlCont.getColumnsType();
  colcheck=PCore.primArr(0);
  Data=TableMdlCont.getRows();
  AllRows=PCore.newIntegerArrayInOrderedSequence(Conts.size(), 0, 1);
  
  if(MainRow==-1 || !SIBio){return ret;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  CompIds=PCore.convertPrimArrLongToInt(PTable.subDataOfIds(Conts, coltype, AllRows, 0));
  
  QConts=PMyShop.getSubjectCont(IFV.Stm, MainId, CompIds);
  count=0; if(QConts!=null){count=QConts.size();} if(count==0){return ret;}
  
  temp=0;
  do{
   Cont=QConts.elementAt(temp);
   
   if(PTable.findData(coltype, true, Data, colcheck, Cont, colcheck)==-1){
    // add to list cont
    ret=Data.size();
    TableMdlCont.insert(ret, Cont);
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 Vector<Object[]> getContChecksData(int[] ByIds_CompIds){
  Vector<Object[]> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(PCore.objArr_PrimArr(ByIds_CompIds));
  }
  
  return ret;
 }
 Vector<Integer> getContChecksColumn(int[] ByIds_CompIds){
  Vector<Integer> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(0);
  }
  
  return ret;
 }
 void editCont(){
  boolean bool;
  int MainRow;
  long MainId;
  String MainName;
  int[] CompRows;
  int CompId;
  OInfoSubjectContact InfoSubjectContact=null;
  OEditSubjectContact Edit=new OEditSubjectContact();
  F_ContactModify fm1=IFV.FContactModify;
  F_ContactModifyMulti fm2=IFV.FContactModifyMulti;
  
  MainRow=List_Subject.getSelectedRow();
  CompRows=Tbl_Cont.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SubContactEdit) || !SIBio || MainRow==-1 || CompRows.length==0){return;}
  
  if(CompRows.length==1){
   bool=false;
   do{
    MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
    MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
    CompId=(Integer)TableMdlCont.Mdl.Rows.elementAt(CompRows[0])[0];
    InfoSubjectContact=PMyShop.getSubjectContInfo(IFV.Stm, MainId, CompId); if(InfoSubjectContact==null){break;}

    bool=true;
   }while(false);
   if(!bool){JOptionPane.showMessageDialog(null, "Gagal mengambil info kontak !"); return;}

   fm1.wMode=1;
   fm1.wName=MainName;
   fm1.wContactTypeId=InfoSubjectContact.ContactTypeId; fm1.wContactTypeName=InfoSubjectContact.ContactTypeName;
   fm1.wContact=InfoSubjectContact.Cont;
   fm1.wComment=InfoSubjectContact.Comment;

   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}
   
   Edit.init(
    true, 0, fm1.ContactTypeId, fm1.ContactTypeName,
    true, 0, false, null, PText.getString(fm1.Contact, null, true),
    true, 0, false, null, PText.getString(fm1.Comment, null, true));
  }
  else{
   fm2.wDataCount=CompRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    false, 0, -1, null,
    false, 0, false, null, null,
    fm2.ChangeComment, 0, fm2.ChangeCommentSub, fm2.CommentSub, fm2.Comment);
  }
  
  if(!editCont(PCore.primArr(MainRow), MainRow, 1, CompRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data kontak, mungkin dikarenakan :\n"+
    "Kontak sudah ada pada daftar kontak.");
   return;
  }
 }
 boolean editCont(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_ContRows,
   Vector<Object[]> ByVect_Data,
   int[] ByIds_CompIds,
  OEditSubjectContact Edit, OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  int ContRow;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null, CellUpdater2=null;
  OCustomListModel List;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  int[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlCont.getRows(), ByTable_ContRows, PCore.newIntegerArrayInOrderedSequence(TableMdlCont.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_ContRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlCont.getRows(), TableMdlCont.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlCont.getRows(), TableMdlCont.getColumnsType(), getContChecksData(ByIds_CompIds),
      getContChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Mengubah Kontak");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  do{
   Updater=new Vector();
   
   List=new OCustomListModel(false); List.setColumnsInfo(TableMdlCont.getColumnsType(), 1); if(ByVect!=null){List.append(ByVect);}
   
   // Updater
   if(Edit.EditContactType){
    switch(Edit.EditContactTypeMode){
     case 0 :
      CellUpdater=new OTableCellUpdaterByObject(1, PCore.subtituteLong(Edit.EditedContactTypeId, -1, Edit.EditedContactTypeId, null));
      CellUpdater2=new OTableCellUpdaterByObject(2, PCore.subtituteLong(Edit.EditedContactTypeId, -1, Edit.EditedContactTypeName, null));
      break;
     case 3 :
      CellUpdater=new OTableCellUpdaterByList(1, PCore.primArr(0), List, PCore.primArr(0), 1, false, null);
      CellUpdater2=new OTableCellUpdaterByList(2, PCore.primArr(0), List, PCore.primArr(0), 2, false, null);
      break;
    }
    Updater.addElement(CellUpdater);
    Updater.addElement(CellUpdater2);
   }
   if(Edit.EditCont){
    if(!Edit.EditContSub){
     switch(Edit.EditContMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedCont, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(3, PCore.primArr(0), List, PCore.primArr(0), 3, false, null); break;
     }
    }
    else{
     switch(Edit.EditContMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(3, true, Edit.EditedContSub, Edit.EditedCont); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditComment){
    if(!Edit.EditCommentSub){
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(4, PText.getString(Edit.EditedComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(4, PCore.primArr(0), List, PCore.primArr(0), 4, false, null); break;
     }
    }
    else{
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(4, true, Edit.EditedCommentSub, Edit.EditedComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   
   if(!PMyShop.subjectContEdit(IFV.Stm, MainIds, IsByVect, ByVect, ByIds, Edit, Progress)){break;}
   
   PGUI.changeElements(TableMdlCont, TableRows, Updater);
   
   if(SIBio){
    ContRow=Tbl_Cont.getSelectedRow();
    fillInfoCont(ContRow);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 void removeCont(){
  int MainRow;
  int[] ContRows;
  
  MainRow=List_Subject.getSelectedRow();
  ContRows=Tbl_Cont.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SubContactRemove) || !SIBio || MainRow==-1 || ContRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+ContRows.length+" kontak yang dipilih ?",
   "Konfirmasi Penghapusan Kontak", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!removeCont(PCore.primArr(MainRow), MainRow, 1, ContRows, null, null, null)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data kontak !"); return;}
 }
 boolean removeCont(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_ContRows,
   Vector<Object[]> ByVect_Data,
   int[] ByIds_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  int[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlCont.getRows(), ByTable_ContRows, PCore.newIntegerArrayInOrderedSequence(TableMdlCont.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_ContRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlCont.getRows(), TableMdlCont.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlCont.getRows(), TableMdlCont.getColumnsType(), getContChecksData(ByIds_CompIds),
      getContChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Menghapus Kontak");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   if(!PMyShop.subjectContRemove(IFV.Stm, true, MainIds, IsByVect, ByVect, ByIds, Progress)){break;}
   
   TableMdlCont.remove(TableRows); onSelectedRowContChanged(true);
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 // Bank Account
 void onSelectedRowAccChanged(boolean UpdateAnyway){
  int row=Tbl_Acc.getSelectedRow();
  if(LastSelectedRowAcc==row && !UpdateAnyway){return;}
  LastSelectedRowAcc=row;
  if(row==-1){clearInfoAcc(); return;}
  fillInfoAcc(row);
 }
 
 boolean fillAcc(long MainId){
  boolean ret=false;
  int datacount;
  
  clearAcc();
  if(MainId==-1){return true;}
  
  SIAccClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getSubjectAcc_Query(PCore.primArr(MainId), false, null, false, -1, null, false),
    TableMdlAcc, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Acc.changeSelection(0, 0, false, false); onSelectedRowAccChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearAcc();}
  
  return ret;
 }
 void clearAcc(){
  if(SIAccClear){return;}
  
  TableMdlAcc.removeAll();
  LastSelectedRowAcc=-1;
  clearInfoAcc();
  
  SIAccClear=true;
 }
 void fillInfoAcc(int row){
  Object[] objs;
  String BankPlatform, BankAccount, Comment;
  
  if(row==-1){return;}
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  objs=TableMdlAcc.Mdl.Rows.elementAt(row);
  BankPlatform=PCore.objString(objs[2], null);
  BankAccount=PCore.objString(objs[3], null);
  Comment=PCore.objString(objs[4], null);
  
  TF_SubBankPlatform.setText(PText.getString(BankPlatform, "", false));
  TA_SubBankAccount.setText(
   PText.getString(BankAccount, "", false)+
   PText.getString(Comment, "", "\n{ "+Comment+" }", true));
  
  InfoAccClear=false;
 }
 void clearInfoAcc(){
  if(InfoAccClear){return;}
  
  PGUI.clearText(TF_SubBankPlatform, TA_SubBankAccount);
  
  InfoAccClear=true;
 }
 
 void updateTableAccView(boolean Requery){
  long MainId;
  int RowMain;
  
  TableMdlAcc.updateColumnsInfo(TableMdlAccColsName, TableMdlAccColsType, TableMdlAccColsShowOption,
   TableMdlAccColsVisible, TableMdlAccColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Acc, TableAccColsWidth);
  if(!Requery){onSelectedRowAccChanged(false);}
  else{
   MainId=-1; RowMain=List_Subject.getSelectedRow(); if(RowMain!=-1){MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(RowMain)[0];}
   fillAcc(MainId);
  }
 }
 void buildTableAccColumns(){
  TableMdlAccColsVisible=PMyShop.getSubjectAcc_ColumnsVisible(CB_AccViewBankPlatform.isSelected(), CB_AccViewComment.isSelected());
  TableAccColsWidth=PMyShop.getSubjectAcc_ColumnsWidth(CB_AccViewBankPlatform.isSelected(), CB_AccViewComment.isSelected());
 }
 void buildTableAccOrderBy(){}
 void buildTableAccViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableAccColumns();}
  if(RebuildOrderBy){buildTableAccOrderBy();}
 }
 void changeAccViewByNormal(){
  buildTableAccViewStructure(true, false);
  updateTableAccView(false);
 }
 
 void onEditingTableAcc(){
  int AccRow, AccCol;
  int result=0;
  boolean IsSame;
  
  AccRow=Tbl_Acc.Editing_Row;
  AccCol=TableMdlAcc.convertColumnIndexFromViewToModel(Tbl_Acc.Editing_Col);
  
  if(AccCol!=-1){
   IsSame=PCore.grading(TableMdlAcc.Mdl.ColumnsType[AccCol], null, Tbl_Acc.Editing_ValueOld, true, null, Tbl_Acc.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(AccCol==-1){result=0; break;}
   result=onEditingTableAcc_Acc(AccRow, AccCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut rekening !");}
 }
 int onEditingTableAcc_Acc(int AccRow, int AccCol){
  int ret=0;
  
  boolean valid;
  int MainRow;
  OEditSubjectBankAccount Edit;
  String str;
  
  do{
   MainRow=List_Subject.getSelectedRow(); if(MainRow==-1){break;}
   
   /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
   
   Edit=new OEditSubjectBankAccount();
   valid=true;
   switch(AccCol){
     
    // String null
    case 4 :
     Edit.EditComment=true; Edit.EditCommentMode=0; Edit.EditCommentSub=false; str=PCore.objString(Tbl_Acc.Editing_ValueNew, null);
     Edit.EditedComment=PText.getString(str, null, true);
     break;
    
    // String not null
    case 3 :
     Edit.EditAcc=true; Edit.EditAccMode=0; Edit.EditAccSub=false; str=PCore.objString(Tbl_Acc.Editing_ValueNew, "");
     valid=PText.checkInput(str, false, 150, 0, 1, 1, 0); if(valid){Edit.EditedAcc=str;}
     break;
   }
   if(!valid){ret=-2; break;}

   if(!editAcc(PCore.primArr(MainRow), MainRow, 1, PCore.primArr(AccRow), null, null, Edit, null)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void addAcc(){
  int MainRow;
  long MainId;
  String MainName;
  Object[] NewAcc;
  F_BankAccountModify fm=IFV.FBankAccountModify;
  
  MainRow=List_Subject.getSelectedRow();
  if(!PGUI.isEnabled(Btn_SubAccountAdd) || !SIBio || MainRow==-1){return;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
  
  fm.wMode=0;
  fm.wName=MainName;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  NewAcc=PCore.objArrVariant(
   null,
   PCore.subtituteLong(fm.BankPlatformId, -1, fm.BankPlatformId, null), PCore.subtituteLong(fm.BankPlatformId, -1, fm.BankPlatformName, null),
   fm.BankAccount, PText.getString(fm.Comment, null, true));
  
  if(!addAcc(false, PCore.primArr(MainRow), MainRow, PCore.toMultiRows2(NewAcc), null)){
   JOptionPane.showMessageDialog(null, "Gagal menambah rekening, mungkin dikarenakan :\n"+
    "Rekening sudah ada pada daftar rekening."); return;
  }
 }
 boolean addAcc(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Accs, OFormInformProgress Progress){
  boolean ret=false;
  int result;
  
  if(Progress!=null){Progress.appear(this, "Menambah Rekening");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   result=addAcc_(StmIgnore, MainRows, MainRow, Accs, Progress); if(result==-2){break;}
   
   if(result!=-1){
    Tbl_Acc.changeSelection(result, 0, false, false); onSelectedRowAccChanged(true);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 int addAcc_(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Accs, OFormInformProgress Progress){
  int ret=-2; // -2 error, -1 success & not added, >=0 success & added
  long[] MainIds=ListMdlSubject.getIds(0, MainRows);
  
  do{
   if(!PMyShop.subjectAccAdd(IFV.Stm, StmIgnore, MainIds, Accs, Progress)){break;}
   ret=addAcc_GUI(MainRow, Accs);
  }while(false);
  
  return ret;
 }
 int addAcc_GUI(int MainRow, Vector<Object[]> Accs){
  int ret=-1;
  int temp, count;
  long MainId;
  int[] CompIds;
  int[] coltype, colcheck, AllRows;
  Object[] Acc;
  Vector<Object[]> Data, QAccs;
  
  coltype=TableMdlAcc.getColumnsType();
  colcheck=PCore.primArr(0);
  Data=TableMdlAcc.getRows();
  AllRows=PCore.newIntegerArrayInOrderedSequence(Accs.size(), 0, 1);
  
  if(MainRow==-1 || !SIBio){return ret;}
  
  MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
  CompIds=PCore.convertPrimArrLongToInt(PTable.subDataOfIds(Accs, coltype, AllRows, 0));
  
  QAccs=PMyShop.getSubjectAcc(IFV.Stm, MainId, CompIds);
  count=0; if(QAccs!=null){count=QAccs.size();} if(count==0){return ret;}
  
  temp=0;
  do{
   Acc=QAccs.elementAt(temp);
   
   if(PTable.findData(coltype, true, Data, colcheck, Acc, colcheck)==-1){
    // add to list acc
    ret=Data.size();
    TableMdlAcc.insert(ret, Acc);
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 Vector<Object[]> getAccChecksData(int[] ByIds_CompIds){
  Vector<Object[]> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(PCore.objArr_PrimArr(ByIds_CompIds));
  }
  
  return ret;
 }
 Vector<Integer> getAccChecksColumn(int[] ByIds_CompIds){
  Vector<Integer> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(0);
  }
  
  return ret;
 }
 void editAcc(){
  boolean bool;
  int MainRow;
  long MainId;
  String MainName;
  int[] CompRows;
  int CompId;
  OInfoSubjectBankAccount InfoSubjectBankAccount=null;
  OEditSubjectBankAccount Edit=new OEditSubjectBankAccount();
  F_BankAccountModify fm1=IFV.FBankAccountModify;
  F_BankAccountModifyMulti fm2=IFV.FBankAccountModifyMulti;
  
  MainRow=List_Subject.getSelectedRow();
  CompRows=Tbl_Acc.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SubAccountEdit) || !SIBio || MainRow==-1 || CompRows.length==0){return;}
  
  if(CompRows.length==1){
   bool=false;
   do{
    MainId=(Long)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[0];
    MainName=(String)ListMdlSubject.Mdl.Rows.elementAt(MainRow)[1];
    CompId=(Integer)TableMdlAcc.Mdl.Rows.elementAt(CompRows[0])[0];
    InfoSubjectBankAccount=PMyShop.getSubjectAccInfo(IFV.Stm, MainId, CompId); if(InfoSubjectBankAccount==null){break;}

    bool=true;
   }while(false);
   if(!bool){JOptionPane.showMessageDialog(null, "Gagal mengambil info rekening !"); return;}

   fm1.wMode=1;
   fm1.wName=MainName;
   fm1.wBankPlatformId=InfoSubjectBankAccount.BankPlatformId; fm1.wBankPlatformName=InfoSubjectBankAccount.BankPlatformName;
   fm1.wBankAccount=InfoSubjectBankAccount.Acc;
   fm1.wComment=InfoSubjectBankAccount.Comment;

   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}
   
   Edit.init(
    true, 0, fm1.BankPlatformId, fm1.BankPlatformName,
    true, 0, false, null, PText.getString(fm1.BankAccount, null, true),
    true, 0, false, null, PText.getString(fm1.Comment, null, true));
  }
  else{
   fm2.wDataCount=CompRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    false, 0, -1, null,
    false, 0, false, null, null,
    fm2.ChangeComment, 0, fm2.ChangeCommentSub, fm2.CommentSub, fm2.Comment);
  }
  
  if(!editAcc(PCore.primArr(MainRow), MainRow, 1, CompRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data rekening, mungkin dikarenakan :\n"+
    "Rekening sudah ada pada daftar rekening.");
   return;
  }
 }
 boolean editAcc(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_AccRows,
   Vector<Object[]> ByVect_Data,
   int[] ByIds_CompIds,
  OEditSubjectBankAccount Edit, OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  int AccRow;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null, CellUpdater2=null;
  OCustomListModel List;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  int[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlAcc.getRows(), ByTable_AccRows, PCore.newIntegerArrayInOrderedSequence(TableMdlAcc.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_AccRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAcc.getRows(), TableMdlAcc.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAcc.getRows(), TableMdlAcc.getColumnsType(), getAccChecksData(ByIds_CompIds),
      getAccChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Mengubah Rekening");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  do{
   Updater=new Vector();
   
   List=new OCustomListModel(false); List.setColumnsInfo(TableMdlAcc.getColumnsType(), 1); if(ByVect!=null){List.append(ByVect);}
   
   // Updater
   if(Edit.EditBankPlatform){
    switch(Edit.EditBankPlatformMode){
     case 0 :
      CellUpdater=new OTableCellUpdaterByObject(1, PCore.subtituteLong(Edit.EditedBankPlatformId, -1, Edit.EditedBankPlatformId, null));
      CellUpdater2=new OTableCellUpdaterByObject(2, PCore.subtituteLong(Edit.EditedBankPlatformId, -1, Edit.EditedBankPlatformName, null));
      break;
     case 3 :
      CellUpdater=new OTableCellUpdaterByList(1, PCore.primArr(0), List, PCore.primArr(0), 1, false, null);
      CellUpdater2=new OTableCellUpdaterByList(2, PCore.primArr(0), List, PCore.primArr(0), 2, false, null);
      break;
    }
    Updater.addElement(CellUpdater);
    Updater.addElement(CellUpdater2);
   }
   if(Edit.EditAcc){
    if(!Edit.EditAccSub){
     switch(Edit.EditAccMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedAcc, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(3, PCore.primArr(0), List, PCore.primArr(0), 3, false, null); break;
     }
    }
    else{
     switch(Edit.EditAccMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(3, true, Edit.EditedAccSub, Edit.EditedAcc); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditComment){
    if(!Edit.EditCommentSub){
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(4, PText.getString(Edit.EditedComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(4, PCore.primArr(0), List, PCore.primArr(0), 4, false, null); break;
     }
    }
    else{
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(4, true, Edit.EditedCommentSub, Edit.EditedComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   
   if(!PMyShop.subjectAccEdit(IFV.Stm, MainIds, IsByVect, ByVect, ByIds, Edit, Progress)){break;}
   
   PGUI.changeElements(TableMdlAcc, TableRows, Updater);
   
   if(SIBio){
    AccRow=Tbl_Acc.getSelectedRow();
    fillInfoAcc(AccRow);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 void removeAcc(){
  int MainRow;
  int[] AccRows;
  
  MainRow=List_Subject.getSelectedRow();
  AccRows=Tbl_Acc.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SubAccountRemove) || !SIBio || MainRow==-1 || AccRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+AccRows.length+" rekening yang dipilih ?",
   "Konfirmasi Penghapusan Rekening", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!removeAcc(PCore.primArr(MainRow), MainRow, 1, AccRows, null, null, null)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data rekening !"); return;}
 }
 boolean removeAcc(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_AccRows,
   Vector<Object[]> ByVect_Data,
   int[] ByIds_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  int[] ByIds=null;
  
  MainIds=ListMdlSubject.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlAcc.getRows(), ByTable_AccRows, PCore.newIntegerArrayInOrderedSequence(TableMdlAcc.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_AccRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAcc.getRows(), TableMdlAcc.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(SIBio){
     TableRows=PTable.findAll(TableMdlAcc.getRows(), TableMdlAcc.getColumnsType(), getAccChecksData(ByIds_CompIds),
      getAccChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Menghapus Rekening");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   if(!PMyShop.subjectAccRemove(IFV.Stm, true, MainIds, IsByVect, ByVect, ByIds, Progress)){break;}
   
   TableMdlAcc.remove(TableRows); onSelectedRowAccChanged(true);
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 //
 void categoryEdit(){
  int[] Rows;
  int row, type, result, temp, count;
  boolean FetchDataOld;
  Object[] UpdateData;
  OInfoIdName InfoIdName;
  OEditIdName Edit;
  OFormInformProgress Progress;
  F_EditName fm1=IFV.FEditName;
  F_IdNameModifyMulti fm2=IFV.FIdNameModifyMulti;
  
  if(!PGUI.isEnabled(Btn_Edit)){return;}
  
  Rows=List_Category.getSelectedIndices();
  count=Rows.length; if(count==0){return;}
  
  /* test if the selection rows is in the additional data, or not */
  row=Rows[0]; type=2;
  if(ListMdlCat.DisplayAdditionalRows){
   if(row<ListMdlCat.AdditionalRowsCount){type=1;}
  }
  
  if(type==1){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah data kategori, jika terdapat baris alfabet !"); return;}
  /**/
  
  /* convert the selection rows into the model's vector rows */
  if(ListMdlCat.DisplayAdditionalRows){
   temp=0;
   do{
    Rows[temp]=Rows[temp]-ListMdlCat.AdditionalRowsCount;
    temp=temp+1;
   }while(temp!=count);
  }
  /**/
  
  Edit=new OEditIdName();
  if(count==1){
   UpdateData=ListMdlCat.Mdl.Rows.elementAt(Rows[0]);
   fm1.wTitle="Ubah nilai Kategori Subjek";
   fm1.wCurrValue=PCore.objString(UpdateData[1], null);
   fm1.wCheckEmpty=false;
   fm1.wCheckLength=150;
   fm1.wCheckAll=0;
   fm1.wCheckFirst=1;
   fm1.wCheckLast=1;
   fm1.wCheckOther=0;
   
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}
   
   FetchDataOld=true;
   InfoIdName=new OInfoIdName(true, PCore.getValueIntLong(UpdateData[0], true, -1), PCore.objString(UpdateData[1], null));
   Edit.init(true, false, null, fm1.UpdateValue);
   Progress=null;
  }
  else{
   fm2.wDataCount=count;
   
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   FetchDataOld=false;
   InfoIdName=null;
   Edit.init(true, true, fm2.NameFind, fm2.NameReplace);
   Progress=IFV.FSplashScreen;
  }
  
  result=categoryEdit(Rows, FetchDataOld, InfoIdName, Edit, Progress);
  if(result==-1){JOptionPane.showMessageDialog(null,
   "Terjadi error ketika melakukan operasi, mungkin dikarenakan :"+
   "\n- Nama kategori sudah ada."+
   "\n- Nama kategori melebihi batasan panjang kata yang diperbolehkan.");}
  else if(result==-2){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : Nama kategori sudah ada !");}
 }
 int categoryEdit(int[] Rows, boolean FetchDataOld, OInfoIdName DataOld, OEditIdName Edit, OFormInformProgress Progress){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Name has already exist
  int insertrow, idx, temp, count;
  
  Vector<OTableCellUpdater> Updater, UpdaterSubCat;
  OTableCellUpdater CellUpdater=null;
  OTableCellUpdaterSelectCheckerKey CellUpdaterSubCat_Checker=null;
  
  long[] Ids;
  Object[] objs;
  boolean Checked;
  String Name;
  
  Vector<Object[]> Edited_Data; Vector<Boolean> Edited_Checked;
  
  int increase_n_times=0;
  long increase_every_n_records=0;
  double increase_size=0;
  
  if(Progress!=null){Progress.appear(this, "Mengubah Kategori");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  do{
   // pre-processing
   count=Rows.length;
   
   Updater=new Vector(); UpdaterSubCat=new Vector();
   
   if(Edit.EditName){
    if(!Edit.ReplaceSubName){
     CellUpdater=new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedName, null, true));
    }
    else{
     CellUpdater=new OTableCellUpdaterBySubString(1, true, Edit.SubName, Edit.EditedName);
    }
    Updater.addElement(CellUpdater);
    
    CellUpdaterSubCat_Checker=new OTableCellUpdaterSelectCheckerKey(PCore.primArr(0), null, PCore.primArr(0));
    UpdaterSubCat.addElement(new OTableCellUpdaterSelect(CellUpdaterSubCat_Checker, CellUpdater, new OTableCellUpdaterByNone(1)));
   }
   
   // process : update in database
   if(Progress!=null){Progress.setProgressIncreasePercentage(65);}
   
   Ids=ListMdlCat.getIds(0, Rows);
   if(!PDatabase.editRecordsIdName(IFV.Stm, "CategoryOfSubject", Ids, Edit, Progress)){break;}
   
   if(Progress!=null){Progress.setProgressIncreasePercentage(100);}
   
   // process : update GUI
   if(Progress!=null){
    increase_n_times=10;
    increase_every_n_records=count/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=count;}
    increase_size=(100-Progress.getProgress())/increase_n_times;
   }
   
   PGUI.changeElements(ListMdlCat, Rows, Updater);
   
   Edited_Data=PTable.subData(ListMdlCat.getRows(), Rows, PCore.newIntegerArrayInOrderedSequence(ListMdlCat.getColumnsCount(), 0, 1));
   Edited_Checked=ListMdlCat.getCheckList(Rows);
   
   CellUpdaterSubCat_Checker.Key=Edited_Data;
   
   ListMdlCat.remove(Rows);
   
   temp=0;
   do{
    objs=Edited_Data.elementAt(temp); Checked=Edited_Checked.elementAt(temp);
    Name=PCore.objString(objs[1], null);
    
    insertrow=PGUI.findInsertPos(ListMdlCat, 1, Name, false, true, true);
    ListMdlCat.insert(insertrow, objs); ListMdlCat.setChecked(insertrow, Checked);
    
    temp=temp+1;
    if(Progress!=null){
     if(temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
    }
   }while(temp!=count);
   
   idx=insertrow; if(ListMdlCat.DisplayAdditionalRows){idx=ListMdlCat.AdditionalRowsCount+idx;}
   List_Category.setSelectedIndex(idx); List_Category.ensureIndexIsVisible(idx);
   
   if(LastSelectedRowCat!=-1){
    LastSelectedRowCat=PCore.subtBool_Int(count==1, idx, -1);
   }
   
   // optional operation, just to update another related data with this operation
   if(TabbedPane.getSelectedIndex()==3 || SIEtc){
    PGUI.changeElements(ListMdlSubCat, PCore.newIntegerArrayInOrderedSequence(ListMdlSubCat.Mdl.Rows.size(), 0, 1), UpdaterSubCat);
   }
   
   //
   ret=0;
  }while(false);
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 //
 void focusQueryResult(){
  if(!ListMdlSubject.Mdl.Rows.isEmpty()){
   if(List_Subject.getSelectedRow()==-1){List_Subject.changeSelection(0, 0, false, false); onListSubjectSelectedRowChanged(false);}
   List_Subject.requestFocusInWindow();
  }
 }
 void focusQuery(){
  if(LastFocusedCmpSearch==null){LastFocusedCmpSearch=TF_QName;}
  LastFocusedCmpSearch.requestFocusInWindow();
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Query = new javax.swing.ButtonGroup();
  RG_QueryBy = new javax.swing.ButtonGroup();
  RG_TransIsPreTrans = new javax.swing.ButtonGroup();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_Query = new javax.swing.JPanel();
  Btn_Query = new javax.swing.JButton();
  TF_QName = new javax.swing.JTextField();
  Lbl_QNameHelp = new javax.swing.JLabel();
  Btn_QSupAdd = new javax.swing.JButton();
  Btn_QSupRemove = new javax.swing.JButton();
  Btn_QCatAdd = new javax.swing.JButton();
  Btn_QCatRemove = new javax.swing.JButton();
  CB_QName = new javax.swing.JCheckBox();
  CB_QSup = new javax.swing.JCheckBox();
  CB_QCat = new javax.swing.JCheckBox();
  TF_QComment = new javax.swing.JTextField();
  CB_QComment = new javax.swing.JCheckBox();
  Lbl_QCommentHelp = new javax.swing.JLabel();
  CB_QBirthDate = new javax.swing.JCheckBox();
  Lbl_QBirthDateHelp = new javax.swing.JLabel();
  TF_QBirthStartYear = new javax.swing.JTextField();
  CmB_QBirthStartMonth = new javax.swing.JComboBox<>();
  CmB_QBirthStartDay = new javax.swing.JComboBox<>();
  jLabel8 = new javax.swing.JLabel();
  TF_QBirthEndYear = new javax.swing.JTextField();
  CmB_QBirthEndMonth = new javax.swing.JComboBox<>();
  CmB_QBirthEndDay = new javax.swing.JComboBox<>();
  CB_QAddress = new javax.swing.JCheckBox();
  Lbl_QAddressHelp = new javax.swing.JLabel();
  TF_QAddress = new javax.swing.JTextField();
  CB_QContact = new javax.swing.JCheckBox();
  Lbl_QContactHelp = new javax.swing.JLabel();
  TF_QContact = new javax.swing.JTextField();
  CB_QCity = new javax.swing.JCheckBox();
  Btn_QCityAdd = new javax.swing.JButton();
  CB_QContactType = new javax.swing.JCheckBox();
  Btn_QCityRemove = new javax.swing.JButton();
  Btn_QContactTypeAdd = new javax.swing.JButton();
  Btn_QContactTypeRemove = new javax.swing.JButton();
  CB_QCityUndefined = new javax.swing.JCheckBox();
  CB_QContactTypeUndefined = new javax.swing.JCheckBox();
  CB_QCatNon = new javax.swing.JCheckBox();
  CB_QSupNon = new javax.swing.JCheckBox();
  jLabel5 = new javax.swing.JLabel();
  Btn_QTagAdd = new javax.swing.JButton();
  Btn_QTagRemove = new javax.swing.JButton();
  Btn_QPicAdd = new javax.swing.JButton();
  Btn_QPicRemove = new javax.swing.JButton();
  CB_QTag = new javax.swing.JCheckBox();
  CB_QTagNon = new javax.swing.JCheckBox();
  CB_QPic = new javax.swing.JCheckBox();
  CB_QPicNon = new javax.swing.JCheckBox();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_QSup = new XTable();
  jScrollPane11 = new javax.swing.JScrollPane();
  List_QCity = new XList();
  jScrollPane27 = new javax.swing.JScrollPane();
  List_QContactType = new XList();
  jScrollPane13 = new javax.swing.JScrollPane();
  List_QCat = new XList();
  jScrollPane5 = new javax.swing.JScrollPane();
  List_QTag = new XList();
  jScrollPane14 = new javax.swing.JScrollPane();
  List_QPic = new XList();
  TF_QBankAccount = new javax.swing.JTextField();
  CB_QBankAccount = new javax.swing.JCheckBox();
  Lbl_QBankAccountHelp = new javax.swing.JLabel();
  CB_QBankPlatform = new javax.swing.JCheckBox();
  CB_QBankPlatformUndefined = new javax.swing.JCheckBox();
  Btn_QBankPlatformAdd = new javax.swing.JButton();
  Btn_QBankPlatformRemove = new javax.swing.JButton();
  jScrollPane29 = new javax.swing.JScrollPane();
  List_QBankPlatform = new XList();
  Panel_CategorizedView = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  Btn_FCatNext = new javax.swing.JButton();
  Btn_FCatBefore = new javax.swing.JButton();
  TF_FindCategory = new javax.swing.JTextField();
  jPanel10 = new javax.swing.JPanel();
  Btn_CatAdd = new javax.swing.JButton();
  Btn_CatEdit = new javax.swing.JButton();
  Btn_CatRemove = new javax.swing.JButton();
  jPanel6 = new javax.swing.JPanel();
  TF_CatCount = new javax.swing.JTextField();
  CmB_CatQueryType = new javax.swing.JComboBox<>();
  TF_CategoryCheckedCount = new javax.swing.JTextField();
  Btn_CatRefresh = new javax.swing.JButton();
  Btn_TempListRemoveByCategory = new javax.swing.JButton();
  Btn_TempListAddByCategory = new javax.swing.JButton();
  jScrollPane23 = new javax.swing.JScrollPane();
  List_Category = new XList();
  Panel_SubjectDetail = new javax.swing.JPanel();
  TF_DetName = new javax.swing.JTextField();
  jLabel6 = new javax.swing.JLabel();
  TF_DetBirthday = new javax.swing.JTextField();
  jLabel3 = new javax.swing.JLabel();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_DetComment = new javax.swing.JTextArea();
  jLabel2 = new javax.swing.JLabel();
  Panel_SubjectEtc = new javax.swing.JPanel();
  jPanel1 = new javax.swing.JPanel();
  Btn_SubCategoryAdd = new javax.swing.JButton();
  Btn_SubCategoryRemove = new javax.swing.JButton();
  jLabel11 = new javax.swing.JLabel();
  Btn_SubjectTagRemove = new javax.swing.JButton();
  Btn_SubjectTagAdd = new javax.swing.JButton();
  jLabel24 = new javax.swing.JLabel();
  jScrollPane4 = new javax.swing.JScrollPane();
  List_SubCategory = new XList();
  jScrollPane24 = new javax.swing.JScrollPane();
  List_SubTag = new XList();
  Panel_SubjectPicture = new javax.swing.JPanel();
  Panel_Image = new XImgBoxURL();
  Btn_SubPictureRemove = new javax.swing.JButton();
  Btn_SubPictureAdd = new javax.swing.JButton();
  jScrollPane7 = new javax.swing.JScrollPane();
  List_SubPicture = new XList();
  Panel_SubjectContact = new javax.swing.JPanel();
  jPanel8 = new javax.swing.JPanel();
  Btn_SubAddressRemove = new javax.swing.JButton();
  Btn_SubAddressEdit = new javax.swing.JButton();
  Btn_SubAddressAdd = new javax.swing.JButton();
  jLabel12 = new javax.swing.JLabel();
  TF_SubCity = new javax.swing.JTextField();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_SubAddress = new javax.swing.JTextArea();
  jScrollPane26 = new javax.swing.JScrollPane();
  Tbl_Addr = new XTable();
  CB_AddrViewComment = new javax.swing.JToggleButton();
  CB_AddrViewCity = new javax.swing.JToggleButton();
  jPanel9 = new javax.swing.JPanel();
  Btn_SubContactRemove = new javax.swing.JButton();
  Btn_SubContactEdit = new javax.swing.JButton();
  Btn_SubContactAdd = new javax.swing.JButton();
  jLabel13 = new javax.swing.JLabel();
  TF_SubContactType = new javax.swing.JTextField();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_SubContact = new javax.swing.JTextArea();
  jScrollPane9 = new javax.swing.JScrollPane();
  Tbl_Cont = new XTable();
  CB_ContViewComment = new javax.swing.JToggleButton();
  CB_ContViewContactType = new javax.swing.JToggleButton();
  jPanel27 = new javax.swing.JPanel();
  Btn_SubAccountRemove = new javax.swing.JButton();
  Btn_SubAccountEdit = new javax.swing.JButton();
  Btn_SubAccountAdd = new javax.swing.JButton();
  jLabel28 = new javax.swing.JLabel();
  jScrollPane21 = new javax.swing.JScrollPane();
  Tbl_Acc = new XTable();
  jScrollPane22 = new javax.swing.JScrollPane();
  TA_SubBankAccount = new javax.swing.JTextArea();
  TF_SubBankPlatform = new javax.swing.JTextField();
  CB_AccViewComment = new javax.swing.JToggleButton();
  CB_AccViewBankPlatform = new javax.swing.JToggleButton();
  Panel_SubjectSupp = new javax.swing.JPanel();
  jPanel11 = new javax.swing.JPanel();
  Btn_SuppAdd = new javax.swing.JButton();
  Btn_SuppEdit = new javax.swing.JButton();
  Btn_SuppRemove = new javax.swing.JButton();
  CB_SuppViewCategorized = new javax.swing.JToggleButton();
  jPanel12 = new javax.swing.JPanel();
  Btn_SuppFindNext = new javax.swing.JButton();
  Btn_SuppFindBef = new javax.swing.JButton();
  TF_SuppFind = new javax.swing.JTextField();
  CmB_SuppFind = new javax.swing.JComboBox<>();
  Btn_SuppTempListRemove = new javax.swing.JButton();
  Btn_SuppTempListAdd = new javax.swing.JButton();
  jLabel7 = new javax.swing.JLabel();
  Btn_SuppActiveRemove = new javax.swing.JButton();
  Btn_SuppActiveAdd = new javax.swing.JButton();
  jLabel20 = new javax.swing.JLabel();
  jScrollPane16 = new javax.swing.JScrollPane();
  Tbl_Supp = new XTable();
  jPanel17 = new javax.swing.JPanel();
  Pnl_SuppInfoPreview = new XImgBoxURL();
  jPanel26 = new javax.swing.JPanel();
  jPanel24 = new javax.swing.JPanel();
  TF_SuppInfoCategory = new javax.swing.JTextField();
  jScrollPane15 = new javax.swing.JScrollPane();
  TA_SuppInfoName = new javax.swing.JTextArea();
  CB_SuppInfoActive = new javax.swing.JCheckBox();
  jScrollPane8 = new javax.swing.JScrollPane();
  TA_SuppInfoBuy = new javax.swing.JTextArea();
  jPanel25 = new javax.swing.JPanel();
  CB_SuppViewBuyPrc = new javax.swing.JToggleButton();
  CB_SuppViewBuyComment = new javax.swing.JToggleButton();
  CB_SuppViewBuyUpdate = new javax.swing.JToggleButton();
  Panel_Trans = new javax.swing.JPanel();
  jPanel14 = new javax.swing.JPanel();
  CmB_TransType = new javax.swing.JComboBox<>();
  jLabel1 = new javax.swing.JLabel();
  jLabel23 = new javax.swing.JLabel();
  RB_TransIsPreTransN = new javax.swing.JRadioButton();
  RB_TransIsPreTransY = new javax.swing.JRadioButton();
  jLabel26 = new javax.swing.JLabel();
  CmB_TransItem = new javax.swing.JComboBox<>();
  Btn_TransItemInfo = new javax.swing.JButton();
  TabbedPane_TransList = new javax.swing.JTabbedPane();
  Panel_TransIn = new javax.swing.JPanel();
  jScrollPane17 = new javax.swing.JScrollPane();
  Tbl_TransIn = new XTable();
  jPanel21 = new javax.swing.JPanel();
  Btn_TransInFindNext = new javax.swing.JButton();
  Btn_TransInFindBef = new javax.swing.JButton();
  TF_TransInFind = new javax.swing.JTextField();
  CmB_TransInFind = new javax.swing.JComboBox<>();
  jPanel19 = new javax.swing.JPanel();
  ImgBox_TransInInfoItemPic = new XImgBoxURL();
  jScrollPane18 = new javax.swing.JScrollPane();
  TA_TransInInfoItemCategory = new javax.swing.JTextArea();
  jScrollPane20 = new javax.swing.JScrollPane();
  TA_TransInInfoItemIdName = new javax.swing.JTextArea();
  jPanel20 = new javax.swing.JPanel();
  CB_TransInDate = new javax.swing.JToggleButton();
  CB_TransInType = new javax.swing.JToggleButton();
  CB_TransInSubject = new javax.swing.JToggleButton();
  CB_TransInSalesman = new javax.swing.JToggleButton();
  CB_TransInId = new javax.swing.JToggleButton();
  CB_TransInIdExternal = new javax.swing.JToggleButton();
  CB_TransInItem = new javax.swing.JToggleButton();
  CB_TransInItemComment = new javax.swing.JToggleButton();
  CB_TransInPriceUnit = new javax.swing.JToggleButton();
  CB_TransInPriceTotal = new javax.swing.JToggleButton();
  CB_TransInItemStockUnit = new javax.swing.JToggleButton();
  jPanel22 = new javax.swing.JPanel();
  Btn_TransInSalesmanTempListRemove = new javax.swing.JButton();
  Btn_TransInSalesmanTempListAdd = new javax.swing.JButton();
  jLabel14 = new javax.swing.JLabel();
  Btn_TransInSubjectTempListRemove = new javax.swing.JButton();
  Btn_TransInSubjectTempListAdd = new javax.swing.JButton();
  jLabel16 = new javax.swing.JLabel();
  Btn_TransInItemTempListRemove = new javax.swing.JButton();
  Btn_TransInItemTempListAdd = new javax.swing.JButton();
  jLabel17 = new javax.swing.JLabel();
  Btn_TransInSalesmanInfo = new javax.swing.JButton();
  Btn_TransInSubjectInfo = new javax.swing.JButton();
  Btn_TransInTransInfo = new javax.swing.JButton();
  Btn_TransInTransTempListRemove = new javax.swing.JButton();
  Btn_TransInTransTempListAdd = new javax.swing.JButton();
  jLabel25 = new javax.swing.JLabel();
  Panel_TransOut = new javax.swing.JPanel();
  jScrollPane19 = new javax.swing.JScrollPane();
  Tbl_TransOut = new XTable();
  jPanel18 = new javax.swing.JPanel();
  Btn_TransOutFindNext = new javax.swing.JButton();
  Btn_TransOutFindBef = new javax.swing.JButton();
  CmB_TransOutFind = new javax.swing.JComboBox<>();
  TF_TransOutFind = new javax.swing.JTextField();
  jPanel13 = new javax.swing.JPanel();
  ImgBox_TransOutInfoItemPic = new XImgBoxURL();
  jScrollPane10 = new javax.swing.JScrollPane();
  TA_TransOutInfoItemCategory = new javax.swing.JTextArea();
  jScrollPane12 = new javax.swing.JScrollPane();
  TA_TransOutInfoItemIdName = new javax.swing.JTextArea();
  jPanel15 = new javax.swing.JPanel();
  CB_TransOutDate = new javax.swing.JToggleButton();
  CB_TransOutType = new javax.swing.JToggleButton();
  CB_TransOutSubject = new javax.swing.JToggleButton();
  CB_TransOutSalesman = new javax.swing.JToggleButton();
  CB_TransOutId = new javax.swing.JToggleButton();
  CB_TransOutIdExternal = new javax.swing.JToggleButton();
  CB_TransOutItem = new javax.swing.JToggleButton();
  CB_TransOutItemComment = new javax.swing.JToggleButton();
  CB_TransOutPriceUnit = new javax.swing.JToggleButton();
  CB_TransOutPriceTotal = new javax.swing.JToggleButton();
  CB_TransOutPriceBasic = new javax.swing.JToggleButton();
  CB_TransOutItemStockUnit = new javax.swing.JToggleButton();
  jPanel23 = new javax.swing.JPanel();
  Btn_TransOutSalesmanTempListRemove = new javax.swing.JButton();
  Btn_TransOutSalesmanTempListAdd = new javax.swing.JButton();
  jLabel15 = new javax.swing.JLabel();
  Btn_TransOutSubjectTempListRemove = new javax.swing.JButton();
  Btn_TransOutSubjectTempListAdd = new javax.swing.JButton();
  jLabel18 = new javax.swing.JLabel();
  Btn_TransOutItemTempListRemove = new javax.swing.JButton();
  Btn_TransOutItemTempListAdd = new javax.swing.JButton();
  jLabel19 = new javax.swing.JLabel();
  Btn_TransOutSalesmanInfo = new javax.swing.JButton();
  Btn_TransOutSubjectInfo = new javax.swing.JButton();
  Btn_TransOutTransInfo = new javax.swing.JButton();
  Btn_TransOutTransTempListRemove = new javax.swing.JButton();
  Btn_TransOutTransTempListAdd = new javax.swing.JButton();
  jLabel27 = new javax.swing.JLabel();
  jPanel3 = new javax.swing.JPanel();
  jPanel2 = new javax.swing.JPanel();
  TF_QueryCount = new javax.swing.JTextField();
  TF_QueryTempListCount = new javax.swing.JTextField();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel4 = new javax.swing.JLabel();
  CmB_ResultFilterSubset = new javax.swing.JComboBox<>();
  Btn_QueryRefresh = new javax.swing.JButton();
  Btn_TempListClear = new javax.swing.JButton();
  jPanel4 = new javax.swing.JPanel();
  Btn_Choose = new javax.swing.JButton();
  Lbl_MultipleSelection = new javax.swing.JLabel();
  Btn_New = new javax.swing.JButton();
  Btn_Edit = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  Btn_Report = new javax.swing.JButton();
  CmB_ReportType = new javax.swing.JComboBox<>();
  jPanel7 = new javax.swing.JPanel();
  Pnl_InfoPreview = new XImgBoxURL();
  jScrollPane25 = new javax.swing.JScrollPane();
  TA_InfoBio = new javax.swing.JTextArea();
  SPList_Subject = new javax.swing.JScrollPane();
  List_Subject = new XTable();
  jPanel16 = new javax.swing.JPanel();
  TF_Find = new javax.swing.JTextField();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBefore = new javax.swing.JButton();
  Btn_MultipleSubjectsItemRemove = new javax.swing.JButton();
  Btn_MultipleSubjectsItemAdd = new javax.swing.JButton();
  jLabel10 = new javax.swing.JLabel();
  Btn_MultipleSubjectsPicRemove = new javax.swing.JButton();
  Btn_MultipleSubjectsPicAdd = new javax.swing.JButton();
  jLabel22 = new javax.swing.JLabel();
  Btn_MultipleSubjectsTagRemove = new javax.swing.JButton();
  Btn_MultipleSubjectsTagAdd = new javax.swing.JButton();
  jLabel21 = new javax.swing.JLabel();
  Btn_MultipleSubjectsCategoryRemove = new javax.swing.JButton();
  Btn_MultipleSubjectsCategoryAdd = new javax.swing.JButton();
  jLabel9 = new javax.swing.JLabel();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TabbedPane.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
  TabbedPane.setToolTipText("");
  TabbedPane.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setToolTipText("");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });
  Btn_Query.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QueryKeyPressed(evt);
   }
  });

  TF_QName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QNameFocusGained(evt);
   }
  });
  TF_QName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QNameKeyPressed(evt);
   }
  });

  Lbl_QNameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QNameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QNameHelp.setText("(?)");
  Lbl_QNameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QNameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QNameHelpMouseClicked(evt);
   }
  });

  Btn_QSupAdd.setText("+");
  Btn_QSupAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSupAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSupAddActionPerformed(evt);
   }
  });
  Btn_QSupAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSupAddKeyPressed(evt);
   }
  });

  Btn_QSupRemove.setText("-");
  Btn_QSupRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSupRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSupRemoveActionPerformed(evt);
   }
  });
  Btn_QSupRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSupRemoveKeyPressed(evt);
   }
  });

  Btn_QCatAdd.setText("+");
  Btn_QCatAdd.setToolTipText("");
  Btn_QCatAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCatAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCatAddActionPerformed(evt);
   }
  });
  Btn_QCatAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCatAddKeyPressed(evt);
   }
  });

  Btn_QCatRemove.setText("-");
  Btn_QCatRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCatRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCatRemoveActionPerformed(evt);
   }
  });
  Btn_QCatRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCatRemoveKeyPressed(evt);
   }
  });

  CB_QName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QName.setText("Nama");
  CB_QName.setToolTipText("");
  CB_QName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QNameKeyPressed(evt);
   }
  });

  CB_QSup.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QSup.setText("Brg Suply...");
  CB_QSup.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSup.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSupKeyPressed(evt);
   }
  });

  CB_QCat.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QCat.setText("Ktgr...");
  CB_QCat.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCat.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCatKeyPressed(evt);
   }
  });

  TF_QComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QCommentFocusGained(evt);
   }
  });
  TF_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QCommentKeyPressed(evt);
   }
  });

  CB_QComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QComment.setText("Komntr");
  CB_QComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCommentKeyPressed(evt);
   }
  });

  Lbl_QCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QCommentHelp.setText("(?)");
  Lbl_QCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QCommentHelpMouseClicked(evt);
   }
  });

  CB_QBirthDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QBirthDate.setText("Tgl Lahir");
  CB_QBirthDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QBirthDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QBirthDateKeyPressed(evt);
   }
  });

  Lbl_QBirthDateHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QBirthDateHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QBirthDateHelp.setText("(?)");
  Lbl_QBirthDateHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QBirthDateHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QBirthDateHelpMouseClicked(evt);
   }
  });

  TF_QBirthStartYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QBirthStartYearFocusGained(evt);
   }
  });
  TF_QBirthStartYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QBirthStartYearKeyPressed(evt);
   }
  });

  CmB_QBirthStartMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QBirthStartMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBirthStartMonthKeyPressed(evt);
   }
  });

  CmB_QBirthStartDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QBirthStartDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBirthStartDayKeyPressed(evt);
   }
  });

  jLabel8.setText("-");

  TF_QBirthEndYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QBirthEndYearFocusGained(evt);
   }
  });
  TF_QBirthEndYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QBirthEndYearKeyPressed(evt);
   }
  });

  CmB_QBirthEndMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QBirthEndMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBirthEndMonthKeyPressed(evt);
   }
  });

  CmB_QBirthEndDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QBirthEndDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBirthEndDayKeyPressed(evt);
   }
  });

  CB_QAddress.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QAddress.setText("Alamat");
  CB_QAddress.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QAddress.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QAddressKeyPressed(evt);
   }
  });

  Lbl_QAddressHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QAddressHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QAddressHelp.setText("(?)");
  Lbl_QAddressHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QAddressHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QAddressHelpMouseClicked(evt);
   }
  });

  TF_QAddress.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QAddressFocusGained(evt);
   }
  });
  TF_QAddress.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QAddressKeyPressed(evt);
   }
  });

  CB_QContact.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QContact.setText("Kontak");
  CB_QContact.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QContact.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QContactKeyPressed(evt);
   }
  });

  Lbl_QContactHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QContactHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QContactHelp.setText("(?)");
  Lbl_QContactHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QContactHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QContactHelpMouseClicked(evt);
   }
  });

  TF_QContact.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QContactFocusGained(evt);
   }
  });
  TF_QContact.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QContactKeyPressed(evt);
   }
  });

  CB_QCity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QCity.setText("Kota...");
  CB_QCity.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCityKeyPressed(evt);
   }
  });

  Btn_QCityAdd.setText("+");
  Btn_QCityAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCityAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCityAddActionPerformed(evt);
   }
  });
  Btn_QCityAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCityAddKeyPressed(evt);
   }
  });

  CB_QContactType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QContactType.setText("Tp Kontk...");
  CB_QContactType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QContactType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QContactTypeKeyPressed(evt);
   }
  });

  Btn_QCityRemove.setText("-");
  Btn_QCityRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCityRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCityRemoveActionPerformed(evt);
   }
  });
  Btn_QCityRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCityRemoveKeyPressed(evt);
   }
  });

  Btn_QContactTypeAdd.setText("+");
  Btn_QContactTypeAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QContactTypeAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QContactTypeAddActionPerformed(evt);
   }
  });
  Btn_QContactTypeAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QContactTypeAddKeyPressed(evt);
   }
  });

  Btn_QContactTypeRemove.setText("-");
  Btn_QContactTypeRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QContactTypeRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QContactTypeRemoveActionPerformed(evt);
   }
  });
  Btn_QContactTypeRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QContactTypeRemoveKeyPressed(evt);
   }
  });

  CB_QCityUndefined.setText("ksg");
  CB_QCityUndefined.setToolTipText("centang utk mengikutsertakan subjek yg memiliki daftar alamat dgn kota yg tdk didefenisikan");
  CB_QCityUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCityUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCityUndefinedKeyPressed(evt);
   }
  });

  CB_QContactTypeUndefined.setText("ksg");
  CB_QContactTypeUndefined.setToolTipText("centang utk mengikutsertakan subjek yg memiliki daftar kontak dgn tipe kontak yg tdk didefenisikan");
  CB_QContactTypeUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QContactTypeUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QContactTypeUndefinedKeyPressed(evt);
   }
  });

  CB_QCatNon.setText("non");
  CB_QCatNon.setToolTipText("centang utk mengikutsertakan subjek yg tdk memiliki daftar kategori");
  CB_QCatNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCatNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCatNonKeyPressed(evt);
   }
  });

  CB_QSupNon.setText("non");
  CB_QSupNon.setToolTipText("centang utk mengikutsertakan subjek yg tdk memiliki daftar barang yg disuplai");
  CB_QSupNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSupNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSupNonKeyPressed(evt);
   }
  });

  jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel5.setText("-- Filter (kosongkan smua utk cari smua)");

  Btn_QTagAdd.setText("+");
  Btn_QTagAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QTagAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QTagAddActionPerformed(evt);
   }
  });
  Btn_QTagAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QTagAddKeyPressed(evt);
   }
  });

  Btn_QTagRemove.setText("-");
  Btn_QTagRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QTagRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QTagRemoveActionPerformed(evt);
   }
  });
  Btn_QTagRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QTagRemoveKeyPressed(evt);
   }
  });

  Btn_QPicAdd.setText("+");
  Btn_QPicAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QPicAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QPicAddActionPerformed(evt);
   }
  });
  Btn_QPicAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QPicAddKeyPressed(evt);
   }
  });

  Btn_QPicRemove.setText("-");
  Btn_QPicRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QPicRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QPicRemoveActionPerformed(evt);
   }
  });
  Btn_QPicRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QPicRemoveKeyPressed(evt);
   }
  });

  CB_QTag.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QTag.setText("Tag...");
  CB_QTag.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QTag.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QTagKeyPressed(evt);
   }
  });

  CB_QTagNon.setText("non");
  CB_QTagNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QTagNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QTagNonKeyPressed(evt);
   }
  });

  CB_QPic.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QPic.setText("Gbr...");
  CB_QPic.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPicKeyPressed(evt);
   }
  });

  CB_QPicNon.setText("non");
  CB_QPicNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPicNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPicNonKeyPressed(evt);
   }
  });

  Tbl_QSup.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_QSup.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_QSup.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_QSup.setRowHeight(18);
  Tbl_QSup.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_QSupKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_QSup);

  List_QCity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QCityKeyReleased(evt);
   }
  });
  jScrollPane11.setViewportView(List_QCity);

  List_QContactType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QContactTypeKeyReleased(evt);
   }
  });
  jScrollPane27.setViewportView(List_QContactType);

  List_QCat.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QCatKeyReleased(evt);
   }
  });
  jScrollPane13.setViewportView(List_QCat);

  List_QTag.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QTagKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(List_QTag);

  List_QPic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QPicKeyReleased(evt);
   }
  });
  jScrollPane14.setViewportView(List_QPic);

  TF_QBankAccount.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QBankAccountFocusGained(evt);
   }
  });
  TF_QBankAccount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QBankAccountKeyPressed(evt);
   }
  });

  CB_QBankAccount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QBankAccount.setText("Rkning");
  CB_QBankAccount.setToolTipText("Rekening");
  CB_QBankAccount.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QBankAccount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QBankAccountKeyPressed(evt);
   }
  });

  Lbl_QBankAccountHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QBankAccountHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QBankAccountHelp.setText("(?)");
  Lbl_QBankAccountHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QBankAccountHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QBankAccountHelpMouseClicked(evt);
   }
  });

  CB_QBankPlatform.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QBankPlatform.setText("Bank...");
  CB_QBankPlatform.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QBankPlatform.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QBankPlatformKeyPressed(evt);
   }
  });

  CB_QBankPlatformUndefined.setText("ksg");
  CB_QBankPlatformUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QBankPlatformUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QBankPlatformUndefinedKeyPressed(evt);
   }
  });

  Btn_QBankPlatformAdd.setText("+");
  Btn_QBankPlatformAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QBankPlatformAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QBankPlatformAddActionPerformed(evt);
   }
  });
  Btn_QBankPlatformAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QBankPlatformAddKeyPressed(evt);
   }
  });

  Btn_QBankPlatformRemove.setText("-");
  Btn_QBankPlatformRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QBankPlatformRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QBankPlatformRemoveActionPerformed(evt);
   }
  });
  Btn_QBankPlatformRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QBankPlatformRemoveKeyPressed(evt);
   }
  });

  List_QBankPlatform.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QBankPlatformKeyReleased(evt);
   }
  });
  jScrollPane29.setViewportView(List_QBankPlatform);

  javax.swing.GroupLayout Panel_QueryLayout = new javax.swing.GroupLayout(Panel_Query);
  Panel_Query.setLayout(Panel_QueryLayout);
  Panel_QueryLayout.setHorizontalGroup(
   Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addComponent(jLabel5)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QName)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QNameHelp))
     .addComponent(CB_QCat)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QCommentHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QAddress)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QAddressHelp))
     .addComponent(CB_QCity)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QContact)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QContactHelp))
     .addComponent(CB_QContactType)
     .addComponent(CB_QSup)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QBirthDate)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QBirthDateHelp))
     .addComponent(CB_QTag)
     .addComponent(CB_QPic)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QBankAccount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QBankAccountHelp))
     .addComponent(CB_QBankPlatform)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
        .addComponent(CB_QCatNon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(CB_QSupNon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(CB_QCityUndefined)
        .addComponent(CB_QContactTypeUndefined))
       .addComponent(CB_QTagNon)
       .addComponent(CB_QPicNon)
       .addComponent(CB_QBankPlatformUndefined))))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_QBankAccount)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane11)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QCityAdd)
       .addComponent(Btn_QCityRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QSupAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Btn_QSupRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addComponent(TF_QName)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(TF_QBirthStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBirthStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBirthStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(jLabel8)
      .addGap(3, 3, 3)
      .addComponent(TF_QBirthEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBirthEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBirthEndDay, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addComponent(TF_QComment)
     .addComponent(TF_QAddress)
     .addComponent(TF_QContact)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jScrollPane13)
       .addComponent(jScrollPane5))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QCatAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QTagAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QCatRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Btn_QTagRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane14)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QPicAdd)
       .addComponent(Btn_QPicRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jScrollPane27)
       .addComponent(jScrollPane29))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QContactTypeAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QBankPlatformAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QContactTypeRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Btn_QBankPlatformRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))))
  );
  Panel_QueryLayout.setVerticalGroup(
   Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Query)
     .addComponent(jLabel5))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(CB_QName)
      .addComponent(Lbl_QNameHelp))
     .addComponent(TF_QName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QBirthDate)
     .addComponent(Lbl_QBirthDateHelp)
     .addComponent(TF_QBirthStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBirthStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBirthStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel8)
     .addComponent(TF_QBirthEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBirthEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBirthEndDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QComment)
     .addComponent(Lbl_QCommentHelp))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QAddress)
     .addComponent(Lbl_QAddressHelp)
     .addComponent(TF_QAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QContact)
     .addComponent(Lbl_QContactHelp)
     .addComponent(TF_QContact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QBankAccount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QBankAccount)
     .addComponent(Lbl_QBankAccountHelp))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QCity)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QCityUndefined))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QCityAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QCityRemove))
     .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QContactType)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QContactTypeUndefined))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QContactTypeAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QContactTypeRemove))
     .addComponent(jScrollPane27, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QBankPlatform)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QBankPlatformUndefined))
       .addComponent(jScrollPane29, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QCatAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QCatRemove))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QCat)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QCatNon))
       .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QTagAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QTagRemove))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QTag)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QTagNon))
       .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QPicAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QPicRemove))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QPic)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QPicNon))
       .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(Panel_QueryLayout.createSequentialGroup()
          .addComponent(CB_QSup)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(CB_QSupNon))
         .addGroup(Panel_QueryLayout.createSequentialGroup()
          .addComponent(Btn_QSupAdd)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(Btn_QSupRemove)))
        .addContainerGap(59, Short.MAX_VALUE))
       .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QBankPlatformAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QBankPlatformRemove)
      .addGap(0, 0, Short.MAX_VALUE))))
  );

  TabbedPane.addTab("Cari", null, Panel_Query, "Cari subjek berdasarkan parameter tertentu");

  jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_FCatNext.setText(">");
  Btn_FCatNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatNextActionPerformed(evt);
   }
  });
  Btn_FCatNext.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatNextKeyPressed(evt);
   }
  });

  Btn_FCatBefore.setText("<");
  Btn_FCatBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatBeforeActionPerformed(evt);
   }
  });
  Btn_FCatBefore.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatBeforeKeyPressed(evt);
   }
  });

  TF_FindCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindCategoryKeyPressed(evt);
   }
  });

  Btn_CatAdd.setText("B");
  Btn_CatAdd.setToolTipText("Buat Baru Kategori Subjek {F6}");
  Btn_CatAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatAddActionPerformed(evt);
   }
  });
  Btn_CatAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatAddKeyPressed(evt);
   }
  });

  Btn_CatEdit.setText("U");
  Btn_CatEdit.setToolTipText("Ubah Kategori Subjek yg dipilih pada daftar {F7}");
  Btn_CatEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatEditActionPerformed(evt);
   }
  });
  Btn_CatEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatEditKeyPressed(evt);
   }
  });

  Btn_CatRemove.setText("H");
  Btn_CatRemove.setToolTipText("Hapus Kategori Subjek yg dipilih pada daftar {F8}");
  Btn_CatRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatRemoveActionPerformed(evt);
   }
  });
  Btn_CatRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatRemoveKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addComponent(Btn_CatAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CatEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CatRemove))
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_CatAdd)
    .addComponent(Btn_CatEdit)
    .addComponent(Btn_CatRemove))
  );

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(TF_FindCategory)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatBefore)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FCatNext)
    .addComponent(Btn_FCatBefore)
    .addComponent(TF_FindCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
  );

  TF_CatCount.setEditable(false);
  TF_CatCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_CatCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CatCount.setToolTipText("jumlah kategori");
  TF_CatCount.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

  CmB_CatQueryType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alfabet & Kategori", "Hanya Alfabet", "Hanya Kategori", "Kategori DaftarKu", "Kategori ~DaftarKu" }));
  CmB_CatQueryType.setToolTipText("pilih kategori yang akan ditampilkan");
  CmB_CatQueryType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_CatQueryTypeActionPerformed(evt);
   }
  });
  CmB_CatQueryType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_CatQueryTypeKeyPressed(evt);
   }
  });

  TF_CategoryCheckedCount.setEditable(false);
  TF_CategoryCheckedCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_CategoryCheckedCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CategoryCheckedCount.setToolTipText("jumlah kategori berdasarkan 'DaftarKu'");
  TF_CategoryCheckedCount.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

  Btn_CatRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_CatRefresh.setText("R");
  Btn_CatRefresh.setToolTipText("klik 'R' untuk memperbarui daftar kategori");
  Btn_CatRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatRefreshActionPerformed(evt);
   }
  });
  Btn_CatRefresh.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatRefreshKeyPressed(evt);
   }
  });

  Btn_TempListRemoveByCategory.setText("-");
  Btn_TempListRemoveByCategory.setToolTipText("mengurangi subjek2 pada kategori2 yg dipilih dari \"DaftarKu\"");
  Btn_TempListRemoveByCategory.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemoveByCategory.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveByCategoryActionPerformed(evt);
   }
  });
  Btn_TempListRemoveByCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TempListRemoveByCategoryKeyPressed(evt);
   }
  });

  Btn_TempListAddByCategory.setText("+");
  Btn_TempListAddByCategory.setToolTipText("menambahkan subjek2 pada kategori2 yg dipilih ke \"DaftarKu\"");
  Btn_TempListAddByCategory.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAddByCategory.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddByCategoryActionPerformed(evt);
   }
  });
  Btn_TempListAddByCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TempListAddByCategoryKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(TF_CatCount, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_CategoryCheckedCount, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CatRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_CatQueryType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 269, Short.MAX_VALUE)
    .addComponent(Btn_TempListAddByCategory)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemoveByCategory))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_CatCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_CatQueryType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_CategoryCheckedCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_CatRefresh)
    .addComponent(Btn_TempListRemoveByCategory)
    .addComponent(Btn_TempListAddByCategory))
  );

  List_Category.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  List_Category.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_CategoryMouseReleased(evt);
   }
  });
  List_Category.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_CategoryKeyReleased(evt);
   }
  });
  jScrollPane23.setViewportView(List_Category);

  javax.swing.GroupLayout Panel_CategorizedViewLayout = new javax.swing.GroupLayout(Panel_CategorizedView);
  Panel_CategorizedView.setLayout(Panel_CategorizedViewLayout);
  Panel_CategorizedViewLayout.setHorizontalGroup(
   Panel_CategorizedViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane23, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  Panel_CategorizedViewLayout.setVerticalGroup(
   Panel_CategorizedViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_CategorizedViewLayout.createSequentialGroup()
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane23, javax.swing.GroupLayout.DEFAULT_SIZE, 577, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("Kategori", null, Panel_CategorizedView, "Cari subjek berdasarkan kategori tertentu");

  Panel_SubjectDetail.setToolTipText("");

  TF_DetName.setEditable(false);
  TF_DetName.setBackground(new java.awt.Color(204, 255, 204));

  jLabel6.setText("Nama");
  jLabel6.setRequestFocusEnabled(false);

  TF_DetBirthday.setEditable(false);
  TF_DetBirthday.setBackground(new java.awt.Color(204, 255, 204));

  jLabel3.setText("Keterangan Tambahan");
  jLabel3.setRequestFocusEnabled(false);

  TA_DetComment.setEditable(false);
  TA_DetComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetComment.setColumns(20);
  TA_DetComment.setLineWrap(true);
  TA_DetComment.setRows(5);
  TA_DetComment.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_DetComment);

  jLabel2.setText("Tgl Lahir");
  jLabel2.setRequestFocusEnabled(false);

  javax.swing.GroupLayout Panel_SubjectDetailLayout = new javax.swing.GroupLayout(Panel_SubjectDetail);
  Panel_SubjectDetail.setLayout(Panel_SubjectDetailLayout);
  Panel_SubjectDetailLayout.setHorizontalGroup(
   Panel_SubjectDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
   .addGroup(Panel_SubjectDetailLayout.createSequentialGroup()
    .addComponent(jLabel3)
    .addContainerGap(491, Short.MAX_VALUE))
   .addGroup(Panel_SubjectDetailLayout.createSequentialGroup()
    .addGroup(Panel_SubjectDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel6)
     .addComponent(jLabel2))
    .addGap(50, 50, 50)
    .addGroup(Panel_SubjectDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_DetBirthday)
     .addComponent(TF_DetName)))
  );
  Panel_SubjectDetailLayout.setVerticalGroup(
   Panel_SubjectDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_SubjectDetailLayout.createSequentialGroup()
    .addGroup(Panel_SubjectDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel6))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_SubjectDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel2)
     .addComponent(TF_DetBirthday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel3)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE))
  );

  TabbedPane.addTab("ket", null, Panel_SubjectDetail, "keterangan dari suatu subjek");

  Panel_SubjectEtc.setToolTipText("");

  Btn_SubCategoryAdd.setText("Tambah");
  Btn_SubCategoryAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubCategoryAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubCategoryAddActionPerformed(evt);
   }
  });

  Btn_SubCategoryRemove.setText("Hapus");
  Btn_SubCategoryRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubCategoryRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubCategoryRemoveActionPerformed(evt);
   }
  });

  jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel11.setText("- - Kategori");

  Btn_SubjectTagRemove.setText("Hapus");
  Btn_SubjectTagRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubjectTagRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubjectTagRemoveActionPerformed(evt);
   }
  });

  Btn_SubjectTagAdd.setText("Tambah");
  Btn_SubjectTagAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubjectTagAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubjectTagAddActionPerformed(evt);
   }
  });

  jLabel24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel24.setText("- - Tag");

  jScrollPane4.setViewportView(List_SubCategory);

  jScrollPane24.setViewportView(List_SubTag);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel11)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_SubCategoryAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubCategoryRemove))
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel24)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_SubjectTagAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubjectTagRemove))
   .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
   .addComponent(jScrollPane24, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SubCategoryRemove)
     .addComponent(Btn_SubCategoryAdd)
     .addComponent(jLabel11))
    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SubjectTagRemove)
     .addComponent(Btn_SubjectTagAdd)
     .addComponent(jLabel24))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane24, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout Panel_SubjectEtcLayout = new javax.swing.GroupLayout(Panel_SubjectEtc);
  Panel_SubjectEtc.setLayout(Panel_SubjectEtcLayout);
  Panel_SubjectEtcLayout.setHorizontalGroup(
   Panel_SubjectEtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_SubjectEtcLayout.setVerticalGroup(
   Panel_SubjectEtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  TabbedPane.addTab("dll", null, Panel_SubjectEtc, "daftar kategori & tag dari suatu subjek");

  Btn_SubPictureRemove.setText("Hapus {F8}");
  Btn_SubPictureRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubPictureRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubPictureRemoveActionPerformed(evt);
   }
  });

  Btn_SubPictureAdd.setText("Tambah {F6}");
  Btn_SubPictureAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubPictureAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubPictureAddActionPerformed(evt);
   }
  });

  List_SubPicture.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_SubPictureMouseReleased(evt);
   }
  });
  List_SubPicture.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_SubPictureKeyReleased(evt);
   }
  });
  jScrollPane7.setViewportView(List_SubPicture);

  javax.swing.GroupLayout Panel_SubjectPictureLayout = new javax.swing.GroupLayout(Panel_SubjectPicture);
  Panel_SubjectPicture.setLayout(Panel_SubjectPictureLayout);
  Panel_SubjectPictureLayout.setHorizontalGroup(
   Panel_SubjectPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Panel_Image, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(Panel_SubjectPictureLayout.createSequentialGroup()
    .addComponent(Btn_SubPictureAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubPictureRemove)
    .addGap(0, 456, Short.MAX_VALUE))
   .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  Panel_SubjectPictureLayout.setVerticalGroup(
   Panel_SubjectPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_SubjectPictureLayout.createSequentialGroup()
    .addComponent(Panel_Image, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGroup(Panel_SubjectPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SubPictureAdd)
     .addComponent(Btn_SubPictureRemove)))
  );

  TabbedPane.addTab("gbr", null, Panel_SubjectPicture, "daftar gambar dari suatu subjek");

  Btn_SubAddressRemove.setText("Hapus");
  Btn_SubAddressRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubAddressRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubAddressRemoveActionPerformed(evt);
   }
  });

  Btn_SubAddressEdit.setText("Ubah");
  Btn_SubAddressEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubAddressEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubAddressEditActionPerformed(evt);
   }
  });

  Btn_SubAddressAdd.setText("Tambah");
  Btn_SubAddressAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubAddressAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubAddressAddActionPerformed(evt);
   }
  });

  jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel12.setText("- - Alamat");

  TF_SubCity.setEditable(false);
  TF_SubCity.setBackground(new java.awt.Color(204, 255, 204));

  TA_SubAddress.setEditable(false);
  TA_SubAddress.setBackground(new java.awt.Color(204, 255, 204));
  TA_SubAddress.setColumns(20);
  TA_SubAddress.setLineWrap(true);
  TA_SubAddress.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_SubAddress);

  Tbl_Addr.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Addr.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Addr.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Addr.setRowHeight(18);
  Tbl_Addr.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_AddrMouseReleased(evt);
   }
  });
  Tbl_Addr.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_AddrKeyReleased(evt);
   }
  });
  jScrollPane26.setViewportView(Tbl_Addr);

  CB_AddrViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_AddrViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AddrViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_AddrViewComment.setText("Ket");
  CB_AddrViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AddrViewComment.setIconTextGap(0);
  CB_AddrViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AddrViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AddrViewCommentActionPerformed(evt);
   }
  });

  CB_AddrViewCity.setBackground(new java.awt.Color(204, 204, 204));
  CB_AddrViewCity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AddrViewCity.setForeground(new java.awt.Color(102, 102, 0));
  CB_AddrViewCity.setText("Kota");
  CB_AddrViewCity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AddrViewCity.setIconTextGap(0);
  CB_AddrViewCity.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AddrViewCity.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AddrViewCityActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(jLabel12)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_AddrViewCity)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_AddrViewComment)
    .addGap(18, 18, 18)
    .addComponent(Btn_SubAddressAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubAddressEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubAddressRemove))
   .addComponent(jScrollPane26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
   .addComponent(jScrollPane2)
   .addComponent(TF_SubCity)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SubAddressRemove)
     .addComponent(Btn_SubAddressEdit)
     .addComponent(Btn_SubAddressAdd)
     .addComponent(jLabel12)
     .addComponent(CB_AddrViewComment)
     .addComponent(CB_AddrViewCity))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane26, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_SubCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_SubContactRemove.setText("Hapus");
  Btn_SubContactRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubContactRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubContactRemoveActionPerformed(evt);
   }
  });

  Btn_SubContactEdit.setText("Ubah");
  Btn_SubContactEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubContactEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubContactEditActionPerformed(evt);
   }
  });

  Btn_SubContactAdd.setText("Tambah");
  Btn_SubContactAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubContactAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubContactAddActionPerformed(evt);
   }
  });

  jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel13.setText("- - Kontak");

  TF_SubContactType.setEditable(false);
  TF_SubContactType.setBackground(new java.awt.Color(204, 255, 204));

  TA_SubContact.setEditable(false);
  TA_SubContact.setBackground(new java.awt.Color(204, 255, 204));
  TA_SubContact.setColumns(20);
  TA_SubContact.setLineWrap(true);
  TA_SubContact.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_SubContact);

  Tbl_Cont.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Cont.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Cont.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Cont.setRowHeight(18);
  Tbl_Cont.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ContMouseReleased(evt);
   }
  });
  Tbl_Cont.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ContKeyReleased(evt);
   }
  });
  jScrollPane9.setViewportView(Tbl_Cont);

  CB_ContViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ContViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ContViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ContViewComment.setText("Ket");
  CB_ContViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ContViewComment.setIconTextGap(0);
  CB_ContViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ContViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ContViewCommentActionPerformed(evt);
   }
  });

  CB_ContViewContactType.setBackground(new java.awt.Color(204, 204, 204));
  CB_ContViewContactType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ContViewContactType.setForeground(new java.awt.Color(102, 102, 0));
  CB_ContViewContactType.setText("Tipe");
  CB_ContViewContactType.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ContViewContactType.setIconTextGap(0);
  CB_ContViewContactType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ContViewContactType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ContViewContactTypeActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(jLabel13)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_ContViewContactType)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ContViewComment)
    .addGap(18, 18, 18)
    .addComponent(Btn_SubContactAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubContactEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubContactRemove))
   .addComponent(jScrollPane9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
   .addComponent(jScrollPane3)
   .addComponent(TF_SubContactType)
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SubContactRemove)
     .addComponent(Btn_SubContactEdit)
     .addComponent(Btn_SubContactAdd)
     .addComponent(jLabel13)
     .addComponent(CB_ContViewComment)
     .addComponent(CB_ContViewContactType))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_SubContactType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_SubAccountRemove.setText("Hapus");
  Btn_SubAccountRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubAccountRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubAccountRemoveActionPerformed(evt);
   }
  });

  Btn_SubAccountEdit.setText("Ubah");
  Btn_SubAccountEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubAccountEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubAccountEditActionPerformed(evt);
   }
  });

  Btn_SubAccountAdd.setText("Tambah");
  Btn_SubAccountAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SubAccountAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SubAccountAddActionPerformed(evt);
   }
  });

  jLabel28.setText("- - Rekening");

  Tbl_Acc.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Acc.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_AccMouseReleased(evt);
   }
  });
  Tbl_Acc.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_AccKeyReleased(evt);
   }
  });
  jScrollPane21.setViewportView(Tbl_Acc);

  TA_SubBankAccount.setEditable(false);
  TA_SubBankAccount.setBackground(new java.awt.Color(204, 255, 204));
  TA_SubBankAccount.setColumns(20);
  TA_SubBankAccount.setLineWrap(true);
  TA_SubBankAccount.setWrapStyleWord(true);
  jScrollPane22.setViewportView(TA_SubBankAccount);

  TF_SubBankPlatform.setEditable(false);
  TF_SubBankPlatform.setBackground(new java.awt.Color(204, 255, 204));

  CB_AccViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_AccViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AccViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_AccViewComment.setText("Ket");
  CB_AccViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AccViewComment.setIconTextGap(0);
  CB_AccViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AccViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AccViewCommentActionPerformed(evt);
   }
  });

  CB_AccViewBankPlatform.setBackground(new java.awt.Color(204, 204, 204));
  CB_AccViewBankPlatform.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AccViewBankPlatform.setForeground(new java.awt.Color(102, 102, 0));
  CB_AccViewBankPlatform.setText("Bank");
  CB_AccViewBankPlatform.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AccViewBankPlatform.setIconTextGap(0);
  CB_AccViewBankPlatform.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AccViewBankPlatform.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AccViewBankPlatformActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
  jPanel27.setLayout(jPanel27Layout);
  jPanel27Layout.setHorizontalGroup(
   jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel27Layout.createSequentialGroup()
    .addComponent(jLabel28)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_AccViewBankPlatform)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_AccViewComment)
    .addGap(18, 18, 18)
    .addComponent(Btn_SubAccountAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubAccountEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SubAccountRemove))
   .addComponent(jScrollPane21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
   .addComponent(jScrollPane22)
   .addComponent(TF_SubBankPlatform)
  );
  jPanel27Layout.setVerticalGroup(
   jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel27Layout.createSequentialGroup()
    .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SubAccountRemove)
     .addComponent(Btn_SubAccountEdit)
     .addComponent(Btn_SubAccountAdd)
     .addComponent(jLabel28)
     .addComponent(CB_AccViewComment)
     .addComponent(CB_AccViewBankPlatform))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane21, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_SubBankPlatform, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Panel_SubjectContactLayout = new javax.swing.GroupLayout(Panel_SubjectContact);
  Panel_SubjectContact.setLayout(Panel_SubjectContactLayout);
  Panel_SubjectContactLayout.setHorizontalGroup(
   Panel_SubjectContactLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_SubjectContactLayout.setVerticalGroup(
   Panel_SubjectContactLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_SubjectContactLayout.createSequentialGroup()
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("bio", null, Panel_SubjectContact, "daftar alamat & kontak dari suatu subjek");

  Btn_SuppAdd.setText("Tambah {F6}");
  Btn_SuppAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppAddActionPerformed(evt);
   }
  });

  Btn_SuppEdit.setText("Ubah {F7}");
  Btn_SuppEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppEditActionPerformed(evt);
   }
  });

  Btn_SuppRemove.setText("Hapus {F8}");
  Btn_SuppRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppRemoveActionPerformed(evt);
   }
  });

  CB_SuppViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewCategorized.setText("K");
  CB_SuppViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_SuppViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewCategorized.setIconTextGap(0);
  CB_SuppViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addComponent(Btn_SuppAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_SuppViewCategorized)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_SuppAdd)
    .addComponent(Btn_SuppEdit)
    .addComponent(Btn_SuppRemove)
    .addComponent(CB_SuppViewCategorized))
  );

  jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_SuppFindNext.setText(">");
  Btn_SuppFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppFindNextActionPerformed(evt);
   }
  });

  Btn_SuppFindBef.setText("<");
  Btn_SuppFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppFindBefActionPerformed(evt);
   }
  });

  TF_SuppFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SuppFindKeyPressed(evt);
   }
  });

  CmB_SuppFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nm Brg", "Kategori", "Ket Beli" }));

  Btn_SuppTempListRemove.setText("-");
  Btn_SuppTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_SuppTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppTempListRemoveActionPerformed(evt);
   }
  });

  Btn_SuppTempListAdd.setText("+");
  Btn_SuppTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_SuppTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppTempListAddActionPerformed(evt);
   }
  });

  jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel7.setText("*");

  Btn_SuppActiveRemove.setText("-");
  Btn_SuppActiveRemove.setToolTipText("menghilangkan tanda atribut aktif pada brg-brg suplai yg dipilih di dlm daftar");
  Btn_SuppActiveRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppActiveRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppActiveRemoveActionPerformed(evt);
   }
  });

  Btn_SuppActiveAdd.setText("+");
  Btn_SuppActiveAdd.setToolTipText("menandai atribut aktif pada brg-brg suplai yg dipilih di dlm daftar");
  Btn_SuppActiveAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppActiveAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppActiveAddActionPerformed(evt);
   }
  });

  jLabel20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel20.setText("Atf");

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
    .addComponent(CmB_SuppFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_SuppFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppFindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel20)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppActiveAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppActiveRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel7)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppTempListRemove))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_SuppFindNext)
    .addComponent(Btn_SuppFindBef)
    .addComponent(TF_SuppFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_SuppFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_SuppTempListRemove)
    .addComponent(Btn_SuppTempListAdd)
    .addComponent(jLabel7)
    .addComponent(Btn_SuppActiveRemove)
    .addComponent(Btn_SuppActiveAdd)
    .addComponent(jLabel20))
  );

  Tbl_Supp.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Supp.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Supp.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Supp.setRowHeight(18);
  Tbl_Supp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_SuppMouseReleased(evt);
   }
  });
  Tbl_Supp.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_SuppKeyReleased(evt);
   }
  });
  jScrollPane16.setViewportView(Tbl_Supp);

  Pnl_SuppInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_SuppInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_SuppInfoPreviewMouseClicked(evt);
   }
  });

  jPanel26.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_SuppInfoCategory.setEditable(false);
  TF_SuppInfoCategory.setBackground(new java.awt.Color(204, 255, 204));

  TA_SuppInfoName.setEditable(false);
  TA_SuppInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_SuppInfoName.setColumns(20);
  TA_SuppInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_SuppInfoName.setLineWrap(true);
  TA_SuppInfoName.setWrapStyleWord(true);
  jScrollPane15.setViewportView(TA_SuppInfoName);

  CB_SuppInfoActive.setText(" ");
  CB_SuppInfoActive.setEnabled(false);
  CB_SuppInfoActive.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TA_SuppInfoBuy.setEditable(false);
  TA_SuppInfoBuy.setBackground(new java.awt.Color(204, 255, 204));
  TA_SuppInfoBuy.setColumns(20);
  TA_SuppInfoBuy.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_SuppInfoBuy.setLineWrap(true);
  TA_SuppInfoBuy.setWrapStyleWord(true);
  jScrollPane8.setViewportView(TA_SuppInfoBuy);

  javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
  jPanel24.setLayout(jPanel24Layout);
  jPanel24Layout.setHorizontalGroup(
   jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane15)
   .addComponent(jScrollPane8)
   .addGroup(jPanel24Layout.createSequentialGroup()
    .addComponent(TF_SuppInfoCategory)
    .addGap(0, 0, 0)
    .addComponent(CB_SuppInfoActive))
  );
  jPanel24Layout.setVerticalGroup(
   jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel24Layout.createSequentialGroup()
    .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SuppInfoCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SuppInfoActive))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel25.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_SuppViewBuyPrc.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewBuyPrc.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewBuyPrc.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewBuyPrc.setText("H-Beli");
  CB_SuppViewBuyPrc.setToolTipText("Harga Beli");
  CB_SuppViewBuyPrc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewBuyPrc.setIconTextGap(0);
  CB_SuppViewBuyPrc.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewBuyPrc.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewBuyPrcActionPerformed(evt);
   }
  });

  CB_SuppViewBuyComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewBuyComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewBuyComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewBuyComment.setText("Ket H-Beli");
  CB_SuppViewBuyComment.setToolTipText("Keterangan Harga Beli");
  CB_SuppViewBuyComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewBuyComment.setIconTextGap(0);
  CB_SuppViewBuyComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewBuyComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewBuyCommentActionPerformed(evt);
   }
  });

  CB_SuppViewBuyUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewBuyUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewBuyUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewBuyUpdate.setText("Tgl");
  CB_SuppViewBuyUpdate.setToolTipText("Tanggal Pembaruan");
  CB_SuppViewBuyUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewBuyUpdate.setIconTextGap(0);
  CB_SuppViewBuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewBuyUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewBuyUpdateActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
  jPanel25.setLayout(jPanel25Layout);
  jPanel25Layout.setHorizontalGroup(
   jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
    .addComponent(CB_SuppViewBuyPrc)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_SuppViewBuyComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_SuppViewBuyUpdate)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel25Layout.setVerticalGroup(
   jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_SuppViewBuyPrc)
    .addComponent(CB_SuppViewBuyComment)
    .addComponent(CB_SuppViewBuyUpdate))
  );

  javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
  jPanel26.setLayout(jPanel26Layout);
  jPanel26Layout.setHorizontalGroup(
   jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel25, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel26Layout.setVerticalGroup(
   jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel26Layout.createSequentialGroup()
    .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
  jPanel17.setLayout(jPanel17Layout);
  jPanel17Layout.setHorizontalGroup(
   jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel17Layout.createSequentialGroup()
    .addComponent(Pnl_SuppInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel17Layout.setVerticalGroup(
   jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Pnl_SuppInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout Panel_SubjectSuppLayout = new javax.swing.GroupLayout(Panel_SubjectSupp);
  Panel_SubjectSupp.setLayout(Panel_SubjectSuppLayout);
  Panel_SubjectSuppLayout.setHorizontalGroup(
   Panel_SubjectSuppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
   .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_SubjectSuppLayout.setVerticalGroup(
   Panel_SubjectSuppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_SubjectSuppLayout.createSequentialGroup()
    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 397, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("brg", null, Panel_SubjectSupp, "daftar barang yg disuplai oleh suatu subjek");

  CmB_TransType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_TransTypeActionPerformed(evt);
   }
  });

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("Jenis Trans");

  jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel23.setText("Transaksi");

  RG_TransIsPreTrans.add(RB_TransIsPreTransN);
  RB_TransIsPreTransN.setText("Transaksi");
  RB_TransIsPreTransN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_TransIsPreTransN.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    RB_TransIsPreTransNActionPerformed(evt);
   }
  });

  RG_TransIsPreTrans.add(RB_TransIsPreTransY);
  RB_TransIsPreTransY.setText("Pra-Transaksi");
  RB_TransIsPreTransY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_TransIsPreTransY.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    RB_TransIsPreTransYActionPerformed(evt);
   }
  });

  jLabel26.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel26.setText("Barang");

  CmB_TransItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_TransItemActionPerformed(evt);
   }
  });

  Btn_TransItemInfo.setText("i");
  Btn_TransItemInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransItemInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransItemInfoActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel1)
     .addComponent(jLabel26)
     .addComponent(jLabel23))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(CmB_TransType, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel14Layout.createSequentialGroup()
      .addComponent(RB_TransIsPreTransN)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(RB_TransIsPreTransY)
      .addGap(0, 0, Short.MAX_VALUE))
     .addGroup(jPanel14Layout.createSequentialGroup()
      .addComponent(CmB_TransItem, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_TransItemInfo))))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createSequentialGroup()
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_TransIsPreTransN)
     .addComponent(RB_TransIsPreTransY)
     .addComponent(jLabel23))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_TransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_TransItem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel26)
     .addComponent(Btn_TransItemInfo)))
  );

  Tbl_TransIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_TransIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_TransIn.setRowHeight(17);
  Tbl_TransIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_TransInMouseReleased(evt);
   }
  });
  Tbl_TransIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_TransInKeyReleased(evt);
   }
  });
  jScrollPane17.setViewportView(Tbl_TransIn);

  jPanel21.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TransInFindNext.setText(">");
  Btn_TransInFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInFindNextActionPerformed(evt);
   }
  });

  Btn_TransInFindBef.setText("<");
  Btn_TransInFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInFindBefActionPerformed(evt);
   }
  });

  TF_TransInFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransInFindKeyPressed(evt);
   }
  });

  CmB_TransInFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jenis Trans", "Subjek", "Sales", "Id Trans", "Id Ext", "Id Brg", "Nama Brg", "Komentar", "Satuan" }));

  javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
  jPanel21.setLayout(jPanel21Layout);
  jPanel21Layout.setHorizontalGroup(
   jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
    .addComponent(CmB_TransInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TransInFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInFindNext))
  );
  jPanel21Layout.setVerticalGroup(
   jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransInFindNext)
    .addComponent(Btn_TransInFindBef)
    .addComponent(TF_TransInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_TransInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  ImgBox_TransInInfoItemPic.setToolTipText("klik utk melihat keterangan barang");
  ImgBox_TransInInfoItemPic.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    ImgBox_TransInInfoItemPicMouseClicked(evt);
   }
  });

  TA_TransInInfoItemCategory.setEditable(false);
  TA_TransInInfoItemCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_TransInInfoItemCategory.setColumns(1);
  TA_TransInInfoItemCategory.setLineWrap(true);
  TA_TransInInfoItemCategory.setRows(1);
  TA_TransInInfoItemCategory.setWrapStyleWord(true);
  jScrollPane18.setViewportView(TA_TransInInfoItemCategory);

  TA_TransInInfoItemIdName.setEditable(false);
  TA_TransInInfoItemIdName.setBackground(new java.awt.Color(204, 255, 204));
  TA_TransInInfoItemIdName.setColumns(20);
  TA_TransInInfoItemIdName.setLineWrap(true);
  TA_TransInInfoItemIdName.setRows(1);
  TA_TransInInfoItemIdName.setWrapStyleWord(true);
  jScrollPane20.setViewportView(TA_TransInInfoItemIdName);

  jPanel20.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_TransInDate.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInDate.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInDate.setText("Tg");
  CB_TransInDate.setToolTipText("Tanggal Transaksi");
  CB_TransInDate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInDate.setIconTextGap(0);
  CB_TransInDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInDate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInDateActionPerformed(evt);
   }
  });

  CB_TransInType.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInType.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInType.setText("Jn");
  CB_TransInType.setToolTipText("Jenis Transaksi");
  CB_TransInType.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInType.setIconTextGap(0);
  CB_TransInType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInTypeActionPerformed(evt);
   }
  });

  CB_TransInSubject.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInSubject.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInSubject.setText("Sb");
  CB_TransInSubject.setToolTipText("Subjek");
  CB_TransInSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInSubject.setIconTextGap(0);
  CB_TransInSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInSubjectActionPerformed(evt);
   }
  });

  CB_TransInSalesman.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInSalesman.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInSalesman.setText("Sl");
  CB_TransInSalesman.setToolTipText("Sales");
  CB_TransInSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInSalesman.setIconTextGap(0);
  CB_TransInSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInSalesmanActionPerformed(evt);
   }
  });

  CB_TransInId.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInId.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInId.setText("Id");
  CB_TransInId.setToolTipText("Id Transaksi");
  CB_TransInId.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInId.setIconTextGap(0);
  CB_TransInId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInIdActionPerformed(evt);
   }
  });

  CB_TransInIdExternal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInIdExternal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInIdExternal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInIdExternal.setText("{E}");
  CB_TransInIdExternal.setToolTipText("{Id-External}");
  CB_TransInIdExternal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInIdExternal.setIconTextGap(0);
  CB_TransInIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInIdExternal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInIdExternalActionPerformed(evt);
   }
  });

  CB_TransInItem.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInItem.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInItem.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInItem.setText("Brg");
  CB_TransInItem.setToolTipText("Barang");
  CB_TransInItem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInItem.setIconTextGap(0);
  CB_TransInItem.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInItemActionPerformed(evt);
   }
  });

  CB_TransInItemComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInItemComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInItemComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInItemComment.setText("C");
  CB_TransInItemComment.setToolTipText("Komentar");
  CB_TransInItemComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInItemComment.setIconTextGap(0);
  CB_TransInItemComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInItemComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInItemCommentActionPerformed(evt);
   }
  });

  CB_TransInPriceUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInPriceUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInPriceUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInPriceUnit.setText("HS");
  CB_TransInPriceUnit.setToolTipText("Harga Satuan");
  CB_TransInPriceUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInPriceUnit.setIconTextGap(0);
  CB_TransInPriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInPriceUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInPriceUnitActionPerformed(evt);
   }
  });

  CB_TransInPriceTotal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInPriceTotal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInPriceTotal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInPriceTotal.setText("HT");
  CB_TransInPriceTotal.setToolTipText("Harga Total");
  CB_TransInPriceTotal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInPriceTotal.setIconTextGap(0);
  CB_TransInPriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInPriceTotal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInPriceTotalActionPerformed(evt);
   }
  });

  CB_TransInItemStockUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInItemStockUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInItemStockUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInItemStockUnit.setText("U");
  CB_TransInItemStockUnit.setToolTipText("Satuan Stok");
  CB_TransInItemStockUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInItemStockUnit.setIconTextGap(0);
  CB_TransInItemStockUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInItemStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInItemStockUnitActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
  jPanel20.setLayout(jPanel20Layout);
  jPanel20Layout.setHorizontalGroup(
   jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
    .addComponent(CB_TransInDate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInType)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInSubject)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInSalesman)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInIdExternal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInItem)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInItemComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInItemStockUnit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInPriceUnit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInPriceTotal)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel20Layout.setVerticalGroup(
   jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_TransInDate)
    .addComponent(CB_TransInType)
    .addComponent(CB_TransInSubject)
    .addComponent(CB_TransInSalesman)
    .addComponent(CB_TransInId)
    .addComponent(CB_TransInIdExternal)
    .addComponent(CB_TransInItem)
    .addComponent(CB_TransInItemComment)
    .addComponent(CB_TransInPriceUnit)
    .addComponent(CB_TransInPriceTotal)
    .addComponent(CB_TransInItemStockUnit))
  );

  javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
  jPanel19.setLayout(jPanel19Layout);
  jPanel19Layout.setHorizontalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel19Layout.createSequentialGroup()
    .addComponent(ImgBox_TransInInfoItemPic, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane18)
     .addComponent(jScrollPane20)
     .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
  );
  jPanel19Layout.setVerticalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel19Layout.createSequentialGroup()
    .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane20, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addComponent(ImgBox_TransInInfoItemPic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  Btn_TransInSalesmanTempListRemove.setText("-");
  Btn_TransInSalesmanTempListRemove.setToolTipText("kurangi sales2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransInSalesmanTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSalesmanTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSalesmanTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInSalesmanTempListAdd.setText("+");
  Btn_TransInSalesmanTempListAdd.setToolTipText("tambahkan sales2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransInSalesmanTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSalesmanTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSalesmanTempListAddActionPerformed(evt);
   }
  });

  jLabel14.setText("Sales*");

  Btn_TransInSubjectTempListRemove.setText("-");
  Btn_TransInSubjectTempListRemove.setToolTipText("kurangi subjek2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransInSubjectTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSubjectTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSubjectTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInSubjectTempListAdd.setText("+");
  Btn_TransInSubjectTempListAdd.setToolTipText("tambahkan subjek2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransInSubjectTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSubjectTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSubjectTempListAddActionPerformed(evt);
   }
  });

  jLabel16.setText("Subjek*");

  Btn_TransInItemTempListRemove.setText("-");
  Btn_TransInItemTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_TransInItemTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInItemTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInItemTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInItemTempListAdd.setText("+");
  Btn_TransInItemTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_TransInItemTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInItemTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInItemTempListAddActionPerformed(evt);
   }
  });

  jLabel17.setText("Barang*");

  Btn_TransInSalesmanInfo.setText("i");
  Btn_TransInSalesmanInfo.setToolTipText("lihat keterangan sales yg dipilih pd daftar");
  Btn_TransInSalesmanInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSalesmanInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSalesmanInfoActionPerformed(evt);
   }
  });

  Btn_TransInSubjectInfo.setText("i");
  Btn_TransInSubjectInfo.setToolTipText("lihat keterangan subjek yg dipilih pd daftar");
  Btn_TransInSubjectInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSubjectInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSubjectInfoActionPerformed(evt);
   }
  });

  Btn_TransInTransInfo.setText("i");
  Btn_TransInTransInfo.setToolTipText("lihat keterangan transaksi yg dipilih pd daftar");
  Btn_TransInTransInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInTransInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInTransInfoActionPerformed(evt);
   }
  });

  Btn_TransInTransTempListRemove.setText("-");
  Btn_TransInTransTempListRemove.setToolTipText("kurangi transaksi2 yg dipilih dari 'DaftarKu' pd form Transaksi");
  Btn_TransInTransTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInTransTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInTransTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInTransTempListAdd.setText("+");
  Btn_TransInTransTempListAdd.setToolTipText("tambahkan transaksi2 yg dipilih ke 'DaftarKu' pd form Transaksi");
  Btn_TransInTransTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInTransTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInTransTempListAddActionPerformed(evt);
   }
  });

  jLabel25.setText("Trans*");

  javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
  jPanel22.setLayout(jPanel22Layout);
  jPanel22Layout.setHorizontalGroup(
   jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
    .addContainerGap(121, Short.MAX_VALUE)
    .addComponent(jLabel25)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInTransTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInTransTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInTransInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel17)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInItemTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInItemTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel16)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSubjectTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSubjectTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSubjectInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel14)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSalesmanTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSalesmanTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSalesmanInfo))
  );
  jPanel22Layout.setVerticalGroup(
   jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransInSalesmanTempListRemove)
    .addComponent(Btn_TransInSalesmanTempListAdd)
    .addComponent(jLabel14)
    .addComponent(Btn_TransInSubjectTempListRemove)
    .addComponent(Btn_TransInSubjectTempListAdd)
    .addComponent(jLabel16)
    .addComponent(Btn_TransInItemTempListRemove)
    .addComponent(Btn_TransInItemTempListAdd)
    .addComponent(jLabel17)
    .addComponent(Btn_TransInSalesmanInfo)
    .addComponent(Btn_TransInSubjectInfo)
    .addComponent(Btn_TransInTransInfo)
    .addComponent(Btn_TransInTransTempListRemove)
    .addComponent(Btn_TransInTransTempListAdd)
    .addComponent(jLabel25))
  );

  javax.swing.GroupLayout Panel_TransInLayout = new javax.swing.GroupLayout(Panel_TransIn);
  Panel_TransIn.setLayout(Panel_TransInLayout);
  Panel_TransInLayout.setHorizontalGroup(
   Panel_TransInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane17, javax.swing.GroupLayout.DEFAULT_SIZE, 615, Short.MAX_VALUE)
   .addComponent(jPanel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_TransInLayout.setVerticalGroup(
   Panel_TransInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_TransInLayout.createSequentialGroup()
    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane17, javax.swing.GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane_TransList.addTab("Barang Masuk", Panel_TransIn);

  Tbl_TransOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_TransOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_TransOut.setRowHeight(17);
  Tbl_TransOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_TransOutMouseReleased(evt);
   }
  });
  Tbl_TransOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_TransOutKeyReleased(evt);
   }
  });
  jScrollPane19.setViewportView(Tbl_TransOut);

  jPanel18.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TransOutFindNext.setText(">");
  Btn_TransOutFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutFindNextActionPerformed(evt);
   }
  });

  Btn_TransOutFindBef.setText("<");
  Btn_TransOutFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutFindBefActionPerformed(evt);
   }
  });

  CmB_TransOutFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jenis Trans", "Subjek", "Sales", "Id Trans", "Id Ext", "Id Brg", "Nama Brg", "Komentar", "Satuan" }));

  TF_TransOutFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransOutFindKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
  jPanel18.setLayout(jPanel18Layout);
  jPanel18Layout.setHorizontalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
    .addComponent(CmB_TransOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TransOutFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutFindNext))
  );
  jPanel18Layout.setVerticalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransOutFindNext)
    .addComponent(Btn_TransOutFindBef)
    .addComponent(CmB_TransOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_TransOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  ImgBox_TransOutInfoItemPic.setToolTipText("klik utk melihat keterangan barang");
  ImgBox_TransOutInfoItemPic.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    ImgBox_TransOutInfoItemPicMouseClicked(evt);
   }
  });

  TA_TransOutInfoItemCategory.setEditable(false);
  TA_TransOutInfoItemCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_TransOutInfoItemCategory.setColumns(1);
  TA_TransOutInfoItemCategory.setLineWrap(true);
  TA_TransOutInfoItemCategory.setRows(1);
  TA_TransOutInfoItemCategory.setWrapStyleWord(true);
  jScrollPane10.setViewportView(TA_TransOutInfoItemCategory);

  TA_TransOutInfoItemIdName.setEditable(false);
  TA_TransOutInfoItemIdName.setBackground(new java.awt.Color(204, 255, 204));
  TA_TransOutInfoItemIdName.setColumns(1);
  TA_TransOutInfoItemIdName.setLineWrap(true);
  TA_TransOutInfoItemIdName.setRows(1);
  TA_TransOutInfoItemIdName.setWrapStyleWord(true);
  jScrollPane12.setViewportView(TA_TransOutInfoItemIdName);

  jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_TransOutDate.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutDate.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutDate.setText("Tg");
  CB_TransOutDate.setToolTipText("Tanggal Transaksi");
  CB_TransOutDate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutDate.setIconTextGap(0);
  CB_TransOutDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutDate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutDateActionPerformed(evt);
   }
  });

  CB_TransOutType.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutType.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutType.setText("Jn");
  CB_TransOutType.setToolTipText("Jenis Transaksi");
  CB_TransOutType.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutType.setIconTextGap(0);
  CB_TransOutType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutTypeActionPerformed(evt);
   }
  });

  CB_TransOutSubject.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutSubject.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutSubject.setText("Sb");
  CB_TransOutSubject.setToolTipText("Subjek");
  CB_TransOutSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutSubject.setIconTextGap(0);
  CB_TransOutSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutSubjectActionPerformed(evt);
   }
  });

  CB_TransOutSalesman.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutSalesman.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutSalesman.setText("Sl");
  CB_TransOutSalesman.setToolTipText("Sales");
  CB_TransOutSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutSalesman.setIconTextGap(0);
  CB_TransOutSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutSalesmanActionPerformed(evt);
   }
  });

  CB_TransOutId.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutId.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutId.setText("Id");
  CB_TransOutId.setToolTipText("Id Transaksi");
  CB_TransOutId.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutId.setIconTextGap(0);
  CB_TransOutId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutIdActionPerformed(evt);
   }
  });

  CB_TransOutIdExternal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutIdExternal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutIdExternal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutIdExternal.setText("{E}");
  CB_TransOutIdExternal.setToolTipText("{Id-External}");
  CB_TransOutIdExternal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutIdExternal.setIconTextGap(0);
  CB_TransOutIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutIdExternal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutIdExternalActionPerformed(evt);
   }
  });

  CB_TransOutItem.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutItem.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutItem.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutItem.setText("Brg");
  CB_TransOutItem.setToolTipText("Barang");
  CB_TransOutItem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutItem.setIconTextGap(0);
  CB_TransOutItem.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutItemActionPerformed(evt);
   }
  });

  CB_TransOutItemComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutItemComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutItemComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutItemComment.setText("C");
  CB_TransOutItemComment.setToolTipText("Komentar");
  CB_TransOutItemComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutItemComment.setIconTextGap(0);
  CB_TransOutItemComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutItemComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutItemCommentActionPerformed(evt);
   }
  });

  CB_TransOutPriceUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutPriceUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutPriceUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutPriceUnit.setText("HS");
  CB_TransOutPriceUnit.setToolTipText("Harga Satuan");
  CB_TransOutPriceUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutPriceUnit.setIconTextGap(0);
  CB_TransOutPriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutPriceUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutPriceUnitActionPerformed(evt);
   }
  });

  CB_TransOutPriceTotal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutPriceTotal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutPriceTotal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutPriceTotal.setText("HT");
  CB_TransOutPriceTotal.setToolTipText("Harga Total");
  CB_TransOutPriceTotal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutPriceTotal.setIconTextGap(0);
  CB_TransOutPriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutPriceTotal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutPriceTotalActionPerformed(evt);
   }
  });

  CB_TransOutPriceBasic.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutPriceBasic.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutPriceBasic.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutPriceBasic.setText("HPP");
  CB_TransOutPriceBasic.setToolTipText("Harga Pokok Penjualan");
  CB_TransOutPriceBasic.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutPriceBasic.setIconTextGap(0);
  CB_TransOutPriceBasic.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutPriceBasic.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutPriceBasicActionPerformed(evt);
   }
  });

  CB_TransOutItemStockUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutItemStockUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutItemStockUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutItemStockUnit.setText("U");
  CB_TransOutItemStockUnit.setToolTipText("Satuan Stok");
  CB_TransOutItemStockUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutItemStockUnit.setIconTextGap(0);
  CB_TransOutItemStockUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutItemStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutItemStockUnitActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
    .addComponent(CB_TransOutDate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutType)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutSubject)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutSalesman)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutIdExternal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutItem)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutItemComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutItemStockUnit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutPriceUnit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutPriceTotal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutPriceBasic)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_TransOutDate)
    .addComponent(CB_TransOutType)
    .addComponent(CB_TransOutSubject)
    .addComponent(CB_TransOutSalesman)
    .addComponent(CB_TransOutId)
    .addComponent(CB_TransOutIdExternal)
    .addComponent(CB_TransOutItem)
    .addComponent(CB_TransOutItemComment)
    .addComponent(CB_TransOutPriceUnit)
    .addComponent(CB_TransOutPriceTotal)
    .addComponent(CB_TransOutPriceBasic)
    .addComponent(CB_TransOutItemStockUnit))
  );

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(ImgBox_TransOutInfoItemPic, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane10)
     .addComponent(jScrollPane12)
     .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addComponent(ImgBox_TransOutInfoItemPic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  Btn_TransOutSalesmanTempListRemove.setText("-");
  Btn_TransOutSalesmanTempListRemove.setToolTipText("kurangi sales2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransOutSalesmanTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSalesmanTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSalesmanTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutSalesmanTempListAdd.setText("+");
  Btn_TransOutSalesmanTempListAdd.setToolTipText("tambahkan sales2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransOutSalesmanTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSalesmanTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSalesmanTempListAddActionPerformed(evt);
   }
  });

  jLabel15.setText("Sales*");

  Btn_TransOutSubjectTempListRemove.setText("-");
  Btn_TransOutSubjectTempListRemove.setToolTipText("kurangi subjek2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransOutSubjectTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSubjectTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSubjectTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutSubjectTempListAdd.setText("+");
  Btn_TransOutSubjectTempListAdd.setToolTipText("tambahkan subjek2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransOutSubjectTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSubjectTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSubjectTempListAddActionPerformed(evt);
   }
  });

  jLabel18.setText("Subjek*");

  Btn_TransOutItemTempListRemove.setText("-");
  Btn_TransOutItemTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_TransOutItemTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutItemTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutItemTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutItemTempListAdd.setText("+");
  Btn_TransOutItemTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_TransOutItemTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutItemTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutItemTempListAddActionPerformed(evt);
   }
  });

  jLabel19.setText("Barang*");

  Btn_TransOutSalesmanInfo.setText("i");
  Btn_TransOutSalesmanInfo.setToolTipText("lihat keterangan sales yg dipilih pd daftar");
  Btn_TransOutSalesmanInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSalesmanInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSalesmanInfoActionPerformed(evt);
   }
  });

  Btn_TransOutSubjectInfo.setText("i");
  Btn_TransOutSubjectInfo.setToolTipText("lihat keterangan subjek yg dipilih pd daftar");
  Btn_TransOutSubjectInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSubjectInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSubjectInfoActionPerformed(evt);
   }
  });

  Btn_TransOutTransInfo.setText("i");
  Btn_TransOutTransInfo.setToolTipText("lihat keterangan transaksi yg dipilih pd daftar");
  Btn_TransOutTransInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutTransInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutTransInfoActionPerformed(evt);
   }
  });

  Btn_TransOutTransTempListRemove.setText("-");
  Btn_TransOutTransTempListRemove.setToolTipText("kurangi transaksi2 yg dipilih dari 'DaftarKu' pd form Transaksi");
  Btn_TransOutTransTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutTransTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutTransTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutTransTempListAdd.setText("+");
  Btn_TransOutTransTempListAdd.setToolTipText("tambahkan transaksi2 yg dipilih ke 'DaftarKu' pd form Transaksi");
  Btn_TransOutTransTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutTransTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutTransTempListAddActionPerformed(evt);
   }
  });

  jLabel27.setText("Trans*");

  javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
  jPanel23.setLayout(jPanel23Layout);
  jPanel23Layout.setHorizontalGroup(
   jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
    .addGap(0, 121, Short.MAX_VALUE)
    .addComponent(jLabel27)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutTransTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutTransTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutTransInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel19)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutItemTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutItemTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel18)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSubjectTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSubjectTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSubjectInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel15)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSalesmanTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSalesmanTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSalesmanInfo))
  );
  jPanel23Layout.setVerticalGroup(
   jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransOutSalesmanTempListRemove)
    .addComponent(Btn_TransOutSalesmanTempListAdd)
    .addComponent(jLabel15)
    .addComponent(Btn_TransOutSubjectTempListRemove)
    .addComponent(Btn_TransOutSubjectTempListAdd)
    .addComponent(jLabel18)
    .addComponent(Btn_TransOutItemTempListRemove)
    .addComponent(Btn_TransOutItemTempListAdd)
    .addComponent(jLabel19)
    .addComponent(Btn_TransOutSalesmanInfo)
    .addComponent(Btn_TransOutSubjectInfo)
    .addComponent(Btn_TransOutTransInfo)
    .addComponent(Btn_TransOutTransTempListRemove)
    .addComponent(Btn_TransOutTransTempListAdd)
    .addComponent(jLabel27))
  );

  javax.swing.GroupLayout Panel_TransOutLayout = new javax.swing.GroupLayout(Panel_TransOut);
  Panel_TransOut.setLayout(Panel_TransOutLayout);
  Panel_TransOutLayout.setHorizontalGroup(
   Panel_TransOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 615, Short.MAX_VALUE)
   .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_TransOutLayout.setVerticalGroup(
   Panel_TransOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_TransOutLayout.createSequentialGroup()
    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 339, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane_TransList.addTab("Barang Keluar", Panel_TransOut);

  javax.swing.GroupLayout Panel_TransLayout = new javax.swing.GroupLayout(Panel_Trans);
  Panel_Trans.setLayout(Panel_TransLayout);
  Panel_TransLayout.setHorizontalGroup(
   Panel_TransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(TabbedPane_TransList)
  );
  Panel_TransLayout.setVerticalGroup(
   Panel_TransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_TransLayout.createSequentialGroup()
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(TabbedPane_TransList))
  );

  TabbedPane.addTab("trans", null, Panel_Trans, "riwayat aktivitas barang masuk & keluar dari suatu subjek pada transaksi-transaksi");

  TF_QueryCount.setEditable(false);
  TF_QueryCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_QueryCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_QueryCount.setToolTipText("Jumlah data subjek di daftar");

  TF_QueryTempListCount.setEditable(false);
  TF_QueryTempListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryTempListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_QueryTempListCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_QueryTempListCount.setToolTipText("Jumlah data 'DaftarKu' di daftar");

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi subjek2 yg dipilih dari 'Daftarku'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan subjek2 yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu' (klik kiri - lihat DaftarKu ; klik kanan - lihat ~DaftarKu)");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TempListQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TempListQuantityMouseClicked(evt);
   }
  });

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("*DaftarKu");

  CmB_ResultFilterSubset.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "*Semua", "*DaftarKu", "*~DftarKu" }));
  CmB_ResultFilterSubset.setToolTipText("Filter \"DaftarKu\"");
  CmB_ResultFilterSubset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterSubsetActionPerformed(evt);
   }
  });

  Btn_QueryRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_QueryRefresh.setText("R");
  Btn_QueryRefresh.setToolTipText("klik 'R' utk menyegarkan daftar subjek");
  Btn_QueryRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_QueryRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryRefreshActionPerformed(evt);
   }
  });

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(4, 4, 4)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_QueryRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
    .addComponent(jLabel4)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(4, 4, 4)
    .addComponent(Btn_TempListAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_TempListRemove)
    .addGap(4, 4, 4)
    .addComponent(Btn_TempListSave)
    .addGap(4, 4, 4)
    .addComponent(Btn_TempListLoad)
    .addGap(4, 4, 4)
    .addComponent(Btn_TempListClear))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_TempListLoad)
    .addComponent(Btn_TempListSave)
    .addComponent(Btn_TempListRemove)
    .addComponent(Btn_TempListAdd)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel4)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_QueryRefresh)
    .addComponent(Btn_TempListClear))
  );

  Btn_Choose.setText("Im-Ex / Pilih {F11}");
  Btn_Choose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Choose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseActionPerformed(evt);
   }
  });

  Lbl_MultipleSelection.setText("{Boleh > 1}");
  Lbl_MultipleSelection.setRequestFocusEnabled(false);

  Btn_New.setText("Buat Baru {F1}");
  Btn_New.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_New.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_NewActionPerformed(evt);
   }
  });

  Btn_Edit.setText("Ubah {F2}");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Remove.setText("Hpus {F3}");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  Btn_Report.setText("Ctak");
  Btn_Report.setToolTipText("Cetak laporan dari daftar subjek");
  Btn_Report.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Report.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReportActionPerformed(evt);
   }
  });

  CmB_ReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laporan", "File CSV" }));

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(Btn_New)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Edit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Remove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Report)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Lbl_MultipleSelection)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Choose))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Choose)
    .addComponent(Lbl_MultipleSelection)
    .addComponent(Btn_New)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Remove)
    .addComponent(Btn_Report)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Pnl_InfoPreview.setToolTipText("klik utk melihat keterangan subjek");
  Pnl_InfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_InfoPreviewMouseClicked(evt);
   }
  });

  TA_InfoBio.setEditable(false);
  TA_InfoBio.setBackground(new java.awt.Color(204, 255, 204));
  TA_InfoBio.setColumns(5);
  TA_InfoBio.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_InfoBio.setLineWrap(true);
  TA_InfoBio.setRows(1);
  TA_InfoBio.setWrapStyleWord(true);
  jScrollPane25.setViewportView(TA_InfoBio);

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(Pnl_InfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane25))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_InfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane25, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
  );

  List_Subject.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  List_Subject.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  List_Subject.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  List_Subject.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  List_Subject.setIntercellSpacing(new java.awt.Dimension(0, 0));
  List_Subject.setRowHeight(20);
  List_Subject.setShowHorizontalLines(false);
  List_Subject.setShowVerticalLines(false);
  List_Subject.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_SubjectMouseReleased(evt);
   }
  });
  List_Subject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    List_SubjectKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_SubjectKeyReleased(evt);
   }
  });
  SPList_Subject.setViewportView(List_Subject);

  jPanel16.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_FindBefore.setText("<");
  Btn_FindBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBeforeActionPerformed(evt);
   }
  });

  Btn_MultipleSubjectsItemRemove.setText("-");
  Btn_MultipleSubjectsItemRemove.setToolTipText("menghapus 'brg yg disuplai' dari subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsItemRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsItemRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsItemRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleSubjectsItemAdd.setText("+");
  Btn_MultipleSubjectsItemAdd.setToolTipText("menambah 'brg yg disuplai' pada subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsItemAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsItemAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsItemAddActionPerformed(evt);
   }
  });

  jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel10.setText("Br");

  Btn_MultipleSubjectsPicRemove.setText("-");
  Btn_MultipleSubjectsPicRemove.setToolTipText("menghapus gambar dari subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsPicRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsPicRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsPicRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleSubjectsPicAdd.setText("+");
  Btn_MultipleSubjectsPicAdd.setToolTipText("menambah gambar pada subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsPicAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsPicAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsPicAddActionPerformed(evt);
   }
  });

  jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel22.setText("Gb");

  Btn_MultipleSubjectsTagRemove.setText("-");
  Btn_MultipleSubjectsTagRemove.setToolTipText("menghapus tag dari subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsTagRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsTagRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsTagRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleSubjectsTagAdd.setText("+");
  Btn_MultipleSubjectsTagAdd.setToolTipText("menambah tag pada subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsTagAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsTagAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsTagAddActionPerformed(evt);
   }
  });

  jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel21.setText("Tg");

  Btn_MultipleSubjectsCategoryRemove.setText("-");
  Btn_MultipleSubjectsCategoryRemove.setToolTipText("menghapus kategori dari subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsCategoryRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsCategoryRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsCategoryRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleSubjectsCategoryAdd.setText("+");
  Btn_MultipleSubjectsCategoryAdd.setToolTipText("menambah kategori pada subjek-subjek yg dipilih di dlm daftar");
  Btn_MultipleSubjectsCategoryAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleSubjectsCategoryAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleSubjectsCategoryAddActionPerformed(evt);
   }
  });

  jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel9.setText("Kg");

  javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
  jPanel16.setLayout(jPanel16Layout);
  jPanel16Layout.setHorizontalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
    .addComponent(TF_Find)
    .addGap(4, 4, 4)
    .addComponent(Btn_FindBefore)
    .addGap(4, 4, 4)
    .addComponent(Btn_FindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel9)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsCategoryAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsCategoryRemove)
    .addGap(9, 9, 9)
    .addComponent(jLabel21)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsTagAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsTagRemove)
    .addGap(9, 9, 9)
    .addComponent(jLabel22)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsPicAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsPicRemove)
    .addGap(9, 9, 9)
    .addComponent(jLabel10)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsItemAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_MultipleSubjectsItemRemove))
  );
  jPanel16Layout.setVerticalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_FindBefore)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_MultipleSubjectsItemRemove)
    .addComponent(Btn_MultipleSubjectsItemAdd)
    .addComponent(jLabel10)
    .addComponent(Btn_MultipleSubjectsPicRemove)
    .addComponent(Btn_MultipleSubjectsPicAdd)
    .addComponent(jLabel22)
    .addComponent(Btn_MultipleSubjectsTagRemove)
    .addComponent(Btn_MultipleSubjectsTagAdd)
    .addComponent(jLabel21)
    .addComponent(Btn_MultipleSubjectsCategoryRemove)
    .addComponent(Btn_MultipleSubjectsCategoryAdd)
    .addComponent(jLabel9))
  );

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(SPList_Subject)
   .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(SPList_Subject)
    .addGap(0, 0, 0)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(TabbedPane)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 656, Short.MAX_VALUE)
     .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  int[] rows;
  int temp, removcount;
  boolean bool;
  boolean[] IsRemove;
  double progress_inc;
  
  if(!PGUI.isEnabled(Btn_Remove)){return;}
  
  rows=List_Subject.getSelectedRows();
  if(rows.length!=0){
   if(JOptionPane.showConfirmDialog(null, "Hapus "+PText.intToString(rows.length)+" subjek yg dipilih pada daftar subjek ?"+
    "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
    "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
    
    IFV.FSplashScreen.appear(this, "Menghapus Data Subjek");
    
    IFV.FSplashScreen.inform(0, "Menghapus "+PText.intToString(rows.length)+" data subjek, harap menunggu ...", "-");
    
    IsRemove=PCore.newBooleanArray(rows.length, false);
    removcount=0;
    progress_inc=(double)100/(double)rows.length;
    temp=0;
    do{
     // IFV.FSplashScreen.inform(0, null, "Menghapus data ke-"+PText.intToString(temp+1));
     bool=true;
     try{
      IFV.Stm.executeUpdate("delete from Subject where Id="+(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[temp])[0]+";");
     }
     catch(Exception E){bool=false;}
     if(bool==true){
      removcount=removcount+1;
      IsRemove[temp]=true;
     }
     temp=temp+1;
     IFV.FSplashScreen.inform(progress_inc, null, null);
    }while(temp!=rows.length);
    
    IFV.FSplashScreen.disappear();
    
    if(removcount!=0){
     ListMdlSubject.remove(rows, IsRemove);
     onListSubjectSelectedRowChanged(true);
     updateQueryCount();
     updateQueryTempListCount();
    }
    if(removcount!=rows.length){
     JOptionPane.showMessageDialog(null, "Gagal menghapus "+(rows.length-removcount)+" data !");
    }
   }
  }
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   if(wMode==0){
    setTitle("Subjek");
    Btn_Report.setVisible(true); CmB_ReportType.setVisible(true);
    Btn_Choose.setText("Impor-Ekspor {F11}");
   }
   else{
    setTitle("Pilih Subjek");
    Btn_Report.setVisible(false); CmB_ReportType.setVisible(false);
    Btn_Choose.setText("Pilih {F11}");
   }
   dialogWithFItem(wDialogWithFItem);
   if(wAllowMultipleSelection==false){
    List_Subject.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
   }
   else{
    List_Subject.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
   }
   Lbl_MultipleSelection.setVisible(wAllowMultipleSelection && wMode!=0);
   
   initPrivGUIShow();
   
   onTabbedPaneChanged();
   
   TF_QName.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void Btn_NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_NewActionPerformed
  boolean bool;
  Long Id;
  String UBirthday=null;
  String UComment=null;
  Object[] NewRow;
  int insertpos;
  F_SubjectModify fm=IFV.FSubjectModify;
  Date Birthday=null;
  
  if(!PGUI.isEnabled(Btn_New)){return;}
  IFV.FSubjectModify.wMode=0;
  
  if(IFV.FSubjectModify.showForm()==false){return;}
  if(IFV.FSubjectModify.DialogResult==1){
   // Convert some of columns's value to string (only if the column's type need to be converted to String)
   Birthday=null; if(IFV.FSubjectModify.Birthday!=null){Birthday=IFV.FSubjectModify.Birthday.getGregorianChange();}
   UBirthday=PDatabase.dateToSQLStringFormat(Birthday);
   if(IFV.FSubjectModify.Comment==null){UComment=CCore.vNull;}
   else{UComment="'"+PSql.norm(IFV.FSubjectModify.Comment)+"'";}
   // Insert new record to database
   bool=true;
   Id=PDatabase.generateNewId(null, IFV.Stm, "select id from Subject order by id asc;");
   if(Id!=null){
    try{
     IFV.Stm.executeUpdate("insert into Subject (Id, Name, Birthday, Comment) values("+
      Id+",'"+PSql.norm(IFV.FSubjectModify.Name)+"',"+UBirthday+","+UComment+");");
    }
    catch(Exception E){bool=false;}
   }
   else{bool=false;}
   if(bool==true){
    NewRow=new Object[4];
    NewRow[0]=Id;
    NewRow[1]=IFV.FSubjectModify.Name;
    NewRow[2]=Birthday;
    NewRow[3]=null;
    insertpos=PGUI.findInsertPos(ListMdlSubject, 1, IFV.FSubjectModify.Name, false, true, true);
    ListMdlSubject.insert(insertpos, NewRow); updateQueryCount();
    ListMdlSubject.setChecked(insertpos, TempList.checkElement(Id)>=0); updateQueryTempListCount();
    List_Subject.changeSelection(insertpos, 0, false, false); onListSubjectSelectedRowChanged(true);
   }
   else{
    JOptionPane.showMessageDialog(null, "Gagal menambah !"+
     "\nMungkin disebabkan : nama subjek sudah ada !");
   }
  }
 }//GEN-LAST:event_Btn_NewActionPerformed

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  int[] rows=List_Subject.getSelectedRows();
  if(!PGUI.isEnabled(Btn_Edit)){return;}
  if(rows.length==0){return;}
  if(rows.length==1){editSingle(rows[0]); return;}
  if(rows.length>1){editMultiple(rows); return;}
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_ChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseActionPerformed
  if(!PGUI.isEnabled(Btn_Choose)){return;}
  if(wMode==0){csvImportExport();}
  else{chooseData();}
 }//GEN-LAST:event_Btn_ChooseActionPerformed

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  if(wMode==1){DialogResult=0;}
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_SubCategoryAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubCategoryAddActionPerformed
  boolean firstinsert, error;
  int row;
  int MaxEachInsert, CurrInsertCount;
  int currcat, catlength;
  long Id;
  Object[] RowData;
  StringBuilder Values;
  int insertpos;
  
  row=List_Subject.getSelectedRow();
  if(row==-1){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfSubject;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Tambah Kategori Pada Subjek";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(row)[0];
  MaxEachInsert=1000;
  catlength=IFV.FDataIdName.DataId.length;
  currcat=0;
  error=false;
  do{
   Values=new StringBuilder();
   
   CurrInsertCount=0;
   firstinsert=true;
   do{
    if(firstinsert){firstinsert=false;}else{Values.append(',');}
    Values.append("("+Id+","+IFV.FDataIdName.DataId[currcat]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currcat=currcat+1;
   }while(currcat!=catlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into SubjectXCategory(Subject, CategoryOfSubject) values "+Values.toString());}
   catch(Exception E){error=true;}
  }while(currcat!=catlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  currcat=0;
  insertpos=-1;
  do{
   if(PGUI.findLong(ListMdlSubCat, 0, IFV.FDataIdName.DataId[currcat])==-1){
    RowData=new Object[2];
    RowData[0]=(int)IFV.FDataIdName.DataId[currcat];
    RowData[1]=IFV.FDataIdName.DataName[currcat];
    insertpos=PGUI.findInsertPos(ListMdlSubCat, 1, IFV.FDataIdName.DataName[currcat], false, true, true);
    ListMdlSubCat.insert(insertpos, RowData);
   }
   currcat=currcat+1;
  }while(currcat!=catlength);
  if(insertpos!=-1){
   List_SubCategory.setSelectedIndex(insertpos); List_SubCategory.ensureIndexIsVisible(insertpos);
  }
  SIEtc=true; SIEtcClear=false; SIEmptyAll=false;
 }//GEN-LAST:event_Btn_SubCategoryAddActionPerformed

 private void Btn_FCatNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatNextActionPerformed
  findCategoryInList(1);
 }//GEN-LAST:event_Btn_FCatNextActionPerformed

 private void Btn_FCatBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatBeforeActionPerformed
  findCategoryInList(2);
 }//GEN-LAST:event_Btn_FCatBeforeActionPerformed

 private void Btn_FindBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBeforeActionPerformed
  findSubjectInList(2);
 }//GEN-LAST:event_Btn_FindBeforeActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findSubjectInList(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void Btn_SubCategoryRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubCategoryRemoveActionPerformed
  int[] rows=List_SubCategory.getSelectedIndices();
  int rowSbj=List_Subject.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currcat, currcatlistcount, catlength;
  String CatList;
  
  if(rows.length==0 || rowSbj==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" kategori yg dipilih dari daftar kategori subjek ?",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rowSbj)[0];
  MaxList=1000;
  error=false;
  catlength=rows.length;
  currcat=0;
  do{
   currcatlistcount=MaxList;
   if(currcat+currcatlistcount>catlength){currcatlistcount=catlength-currcat;}
   CatList=PGUI.getElementList(ListMdlSubCat.Mdl.Rows, PCore.subArr(rows, currcat, currcatlistcount), 0, ",", "", false);
   
   try{IFV.Stm.execute("delete ignore from SubjectXCategory where Subject="+Id+" and CategoryOfSubject in("+CatList+")");}
   catch(Exception E){error=true;}
   
   currcat=currcat+currcatlistcount;
  }while(currcat!=catlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlSubCat.remove(rows);
 }//GEN-LAST:event_Btn_SubCategoryRemoveActionPerformed

 private void Btn_SubAddressAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubAddressAddActionPerformed
  addAddr();
 }//GEN-LAST:event_Btn_SubAddressAddActionPerformed

 private void Btn_SubAddressEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubAddressEditActionPerformed
  editAddr();
 }//GEN-LAST:event_Btn_SubAddressEditActionPerformed

 private void Btn_SubAddressRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubAddressRemoveActionPerformed
  removeAddr();
 }//GEN-LAST:event_Btn_SubAddressRemoveActionPerformed

 private void Btn_SubContactAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubContactAddActionPerformed
  addCont();
 }//GEN-LAST:event_Btn_SubContactAddActionPerformed

 private void Btn_SubContactEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubContactEditActionPerformed
  editCont();
 }//GEN-LAST:event_Btn_SubContactEditActionPerformed

 private void Btn_SubContactRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubContactRemoveActionPerformed
  removeCont();
 }//GEN-LAST:event_Btn_SubContactRemoveActionPerformed

 private void Btn_SuppAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppAddActionPerformed
  addSupp();
 }//GEN-LAST:event_Btn_SuppAddActionPerformed

 private void Btn_SuppEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppEditActionPerformed
  editSupp();
 }//GEN-LAST:event_Btn_SuppEditActionPerformed

 private void Btn_SuppRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppRemoveActionPerformed
  removeSupp();
 }//GEN-LAST:event_Btn_SuppRemoveActionPerformed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Subject)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void TF_FindCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindCategoryKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FindCategory, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FCatBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FCatNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindCategoryKeyPressed

 private void Btn_ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReportActionPerformed
  switch(CmB_ReportType.getSelectedIndex()){
   case 0 : printReport(); break;
   case 1 : printCSV(); break;
  }
 }//GEN-LAST:event_Btn_ReportActionPerformed

 private void Btn_MultipleSubjectsCategoryAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsCategoryAddActionPerformed
  int[] rows;
  boolean firstinsert, error;
  int currsbj, sbjlength, currcat, catlength;
  int MaxEachInsert, CurrInsertCount;
  long Id;
  Object[] RowData;
  StringBuilder records;
  int insertpos;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfSubject;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Kategori Pada Beberapa Subjek";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  sbjlength=rows.length;
  currsbj=0;
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsbj])[0];
  currcat=0;
  catlength=IFV.FDataIdName.DataId.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+","+IFV.FDataIdName.DataId[currcat]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currcat=currcat+1;
    if(currcat==catlength){
     currsbj=currsbj+1;
     if(currsbj!=sbjlength){
      Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsbj])[0];
      currcat=0;
     }
    }
   }while(currsbj!=sbjlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into SubjectXCategory(Subject, CategoryOfSubject) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(currsbj!=sbjlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  if(TabbedPane.getSelectedIndex()==3 || SIEtc){
   currcat=0;
   insertpos=-1;
   do{
    if(PGUI.findLong(ListMdlSubCat, 0, IFV.FDataIdName.DataId[currcat])==-1){
     RowData=new Object[2];
     RowData[0]=(int)IFV.FDataIdName.DataId[currcat];
     RowData[1]=IFV.FDataIdName.DataName[currcat];
     insertpos=PGUI.findInsertPos(ListMdlSubCat, 1, IFV.FDataIdName.DataName[currcat], false, true, true);
     ListMdlSubCat.insert(insertpos, RowData);
    }
    currcat=currcat+1;
   }while(currcat!=catlength);
   if(insertpos!=-1){
    List_SubCategory.setSelectedIndex(insertpos); List_SubCategory.ensureIndexIsVisible(insertpos);
   }
   SIEtc=true; SIEtcClear=false; SIEmptyAll=false;
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsCategoryAddActionPerformed

 private void Btn_MultipleSubjectsCategoryRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsCategoryRemoveActionPerformed
  int[] rows;
  boolean error;
  int MaxListCat, MaxListSbj;
  int currsbj, currsbjlistcount, sbjlength,
      currcat, currcatlistcount, catlength;
  int findindex;
  String SbjList, CatList;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfSubject;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menghapus Kategori Pada Beberapa Subjek";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}

  MaxListCat=1000;
  MaxListSbj=1000;
  
  sbjlength=rows.length;
  currsbj=0;
  catlength=IFV.FDataIdName.DataId.length;
  error=false;
  
  do{
   currsbjlistcount=MaxListSbj;
   if(currsbj+currsbjlistcount>sbjlength){currsbjlistcount=sbjlength-currsbj;}
   SbjList=PGUI.getElementList(ListMdlSubject.Mdl.Rows, PCore.subArr(rows, currsbj, currsbjlistcount), 0, ",", "", false);
   
   currcat=0;
   do{
    currcatlistcount=MaxListCat;
    if(currcat+currcatlistcount>catlength){currcatlistcount=catlength-currcat;}
    CatList=PText.toString(IFV.FDataIdName.DataId, currcat, currcatlistcount, ",");
    
    try{
     IFV.Stm.execute("delete ignore from SubjectXCategory where Subject in ("+SbjList+") and CategoryOfSubject in ("+CatList+")");
    }
    catch(Exception E){error=true;}
    
    currcat=currcat+currcatlistcount;
   }while(currcat!=catlength);
   
   currsbj=currsbj+currsbjlistcount;
  }while(currsbj!=sbjlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(SIEtc){
   currcat=0;
   do{
    findindex=PGUI.findLong(ListMdlSubCat, 0, IFV.FDataIdName.DataId[currcat]);
    if(findindex>=0){ListMdlSubCat.remove(findindex);}
    currcat=currcat+1;
   }while(currcat!=catlength);
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsCategoryRemoveActionPerformed

 private void Btn_MultipleSubjectsItemAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsItemAddActionPerformed
  int[] rows;
  boolean firstinsert, error;
  int currsbj, sbjlength, curritem, itemlength;
  int MaxEachInsert, CurrInsertCount;
  long Id;
  Object[] RowData;
  StringBuilder records;
  int insertpos;
  String FindName=null;
  int FindColumn=0;
  boolean IsCategorized=CB_SuppViewCategorized.isSelected();
  F_Item fm=IFV.FItem;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  fm.wMode=1;
  fm.wDialogWithFSubject=false;
  fm.wAllowMultipleSelection=true;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  sbjlength=rows.length;
  currsbj=0;
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsbj])[0];
  curritem=0;
  itemlength=fm.ChoosedId.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+","+fm.ChoosedId[curritem]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    curritem=curritem+1;
    if(curritem==itemlength){
     currsbj=currsbj+1;
     if(currsbj!=sbjlength){
      Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsbj])[0];
      curritem=0;
     }
    }
   }while(currsbj!=sbjlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXSupplier(Supplier, Item) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(currsbj!=sbjlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  if(TabbedPane.getSelectedIndex()==6 || SISupp){
   curritem=0; insertpos=-1; if(!IsCategorized){FindColumn=1;}else{FindColumn=7;}
   do{
    if(PGUI.findLong(TableMdlSupp, 0, fm.ChoosedId[curritem])==-1){
     RowData=PCore.objArrVariant(fm.ChoosedId[curritem], fm.ChoosedName[curritem], 0D, null, null,
      CApp.Default_ItemSupplier_Active, fm.ChoosedPicture[curritem], fm.ChoosedCategory[curritem]);
     FindName=PCore.objString(RowData[FindColumn], null);
     insertpos=PGUI.findInsertPos(TableMdlSupp, FindColumn, FindName, false, true, true);
     TableMdlSupp.insert(insertpos, RowData);
    }
    curritem=curritem+1;
   }while(curritem!=itemlength);
   if(insertpos!=-1){Tbl_Supp.changeSelection(insertpos, 0, false, false);} onSelectedRowSuppChanged(true);
   SISupp=true; SISuppClear=false; SIEmptyAll=false;
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsItemAddActionPerformed

 private void Btn_MultipleSubjectsItemRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsItemRemoveActionPerformed
  int[] rows;
  boolean error, removeintab;
  int MaxListSup, MaxListSbj;
  int currsbj, currsbjlistcount, sbjlength,
      curritem, curritemlistcount, itemlength;
  int findindex;
  String SbjList, ItemList;
  F_Item fm=IFV.FItem;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  fm.wMode=1;
  fm.wDialogWithFSubject=false;
  fm.wAllowMultipleSelection=true;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  MaxListSup=1000;
  MaxListSbj=1000;
  
  sbjlength=rows.length;
  currsbj=0;
  itemlength=fm.ChoosedId.length;
  error=false;
  
  do{
   currsbjlistcount=MaxListSbj;
   if(currsbj+currsbjlistcount>sbjlength){currsbjlistcount=sbjlength-currsbj;}
   SbjList=PGUI.getElementList(ListMdlSubject.Mdl.Rows, PCore.subArr(rows, currsbj, currsbjlistcount), 0, ",", "", false);
   
   curritem=0;
   do{
    curritemlistcount=MaxListSup;
    if(curritem+curritemlistcount>itemlength){curritemlistcount=itemlength-curritem;}
    ItemList=PText.toString(fm.ChoosedId, curritem, curritemlistcount, ",");
    
    try{
     IFV.Stm.execute("delete ignore from ItemXSupplier where Supplier in ("+SbjList+") and Item in ("+ItemList+")");
    }
    catch(Exception E){error=true;}
    
    curritem=curritem+curritemlistcount;
   }while(curritem!=itemlength);
   
   currsbj=currsbj+currsbjlistcount;
  }while(currsbj!=sbjlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(SISupp){
   curritem=0;
   removeintab=false;
   do{
    findindex=PGUI.findLong(TableMdlSupp, 0, fm.ChoosedId[curritem]);
    if(findindex>=0){TableMdlSupp.remove(findindex); removeintab=true;}
    curritem=curritem+1;
   }while(curritem!=itemlength);
   if(removeintab){onSelectedRowSuppChanged(true);}
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsItemRemoveActionPerformed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(ListMdlSubject, List_Subject.getSelectedRows(), 0), true);
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(ListMdlSubject, List_Subject.getSelectedRows(), 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  File f;
  String fstr;
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION){return;}
   
  f=IFV.FileChooser.getSelectedFile();
  if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
   JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
   return;
  }
  try{
   fstr=f.getCanonicalPath();
   if(PFile.compareIgnoreCaseExtension(fstr, "report")==false){
    f=new File(fstr+".report");
   }
  }
  catch(Exception E){
   JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !");
   return;
  }
  if(PEtc.saveIdToFile(TempList.getElements(), f, false,
   IFV.FSplashScreen, true, this, "Menulis Data DaftarKu")==false){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data report ke file !");
  }
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  File f;
  long[] tlist;
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showDialog(this, "Load")!=JFileChooser.APPROVE_OPTION){return;}
  f=IFV.FileChooser.getSelectedFile();
  if(PFile.compareIgnoreCaseExtension(f.getName(), "report")==false){
   JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+
    "Ekstensi file harus '.report'.");
   return;
  }
  tlist=PEtc.loadIdFromFile(f, false,
   IFV.FSplashScreen, true, this, "Membaca Data DaftarKu");
  if(tlist==null){
   JOptionPane.showMessageDialog(null, "Gagal membaca data report dari file !");
   return;
  }
  
  clearTempList();
  fillTempList(tlist, true);
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void CmB_CatQueryTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_CatQueryTypeActionPerformed
  fillListModelCategory(2);
 }//GEN-LAST:event_CmB_CatQueryTypeActionPerformed

 private void Btn_CatRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatRefreshActionPerformed
  fillListModelCategory(0);
 }//GEN-LAST:event_Btn_CatRefreshActionPerformed

 private void TF_TempListQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TempListQuantityMouseClicked
  int DynamicTempList=0;
  
  do{
   if(SwingUtilities.isLeftMouseButton(evt)){DynamicTempList=1; break;}
   if(SwingUtilities.isRightMouseButton(evt)){DynamicTempList=2; break;}
   DynamicTempList=-1;
  }while(false);
  if(DynamicTempList==-1){return;}
  
  setLastQuery(3, 0, "", "", false, "", false, DynamicTempList, false);
  fillListSubject();
 }//GEN-LAST:event_TF_TempListQuantityMouseClicked

 private void Btn_QContactTypeRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QContactTypeRemoveActionPerformed
  ListMdlQContactType.remove(List_QContactType.getSelectedIndices());
 }//GEN-LAST:event_Btn_QContactTypeRemoveActionPerformed

 private void Btn_QContactTypeAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QContactTypeAddActionPerformed
  int temp, temp_;
  Object[] NewData;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblContactType;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    NewData=new Object[2];
    NewData[0]=(int)IFV.FDataIdName.DataId[temp_];
    NewData[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQContactType.append(NewData);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QContactTypeAddActionPerformed

 private void Btn_QCityRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCityRemoveActionPerformed
  ListMdlQCity.remove(List_QCity.getSelectedIndices());
 }//GEN-LAST:event_Btn_QCityRemoveActionPerformed

 private void Btn_QCityAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCityAddActionPerformed
  int temp, temp_;
  Object[] NewData;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCity;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    NewData=new Object[2];
    NewData[0]=(int)IFV.FDataIdName.DataId[temp_];
    NewData[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQCity.append(NewData);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QCityAddActionPerformed

 private void TF_QContactKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QContactKeyPressed
  PNav.onKey_Query_TF(this, CB_QContact, TF_QContact, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QAddress)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QBankAccount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QContact)));
 }//GEN-LAST:event_TF_QContactKeyPressed

 private void TF_QContactFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QContactFocusGained
  LastFocusedCmpSearch=TF_QContact;
 }//GEN-LAST:event_TF_QContactFocusGained

 private void Lbl_QContactHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QContactHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QContactHelpMouseClicked

 private void TF_QAddressKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QAddressKeyPressed
  PNav.onKey_Query_TF(this, CB_QAddress, TF_QAddress, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QContact)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QAddress)));
 }//GEN-LAST:event_TF_QAddressKeyPressed

 private void TF_QAddressFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QAddressFocusGained
  LastFocusedCmpSearch=TF_QAddress;
 }//GEN-LAST:event_TF_QAddressFocusGained

 private void Lbl_QAddressHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QAddressHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QAddressHelpMouseClicked

 private void TF_QBirthEndYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QBirthEndYearFocusGained
  LastFocusedCmpSearch=TF_QBirthEndYear;
 }//GEN-LAST:event_TF_QBirthEndYearFocusGained

 private void TF_QBirthStartYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QBirthStartYearFocusGained
  LastFocusedCmpSearch=TF_QBirthStartYear;
 }//GEN-LAST:event_TF_QBirthStartYearFocusGained

 private void Lbl_QBirthDateHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QBirthDateHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Tanggal akhir >= tanggal awal\n"+
   "- Tahun hanya boleh bernilai 1 - 999999.");
 }//GEN-LAST:event_Lbl_QBirthDateHelpMouseClicked

 private void Lbl_QCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QCommentHelpMouseClicked

 private void TF_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QCommentKeyPressed
  PNav.onKey_Query_TF(this, CB_QComment, TF_QComment, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QBirthStartYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QAddress)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QComment)));
 }//GEN-LAST:event_TF_QCommentKeyPressed

 private void TF_QCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QCommentFocusGained
  LastFocusedCmpSearch=TF_QComment;
 }//GEN-LAST:event_TF_QCommentFocusGained

 private void Btn_QCatRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCatRemoveActionPerformed
  ListMdlQCat.remove(List_QCat.getSelectedIndices());
 }//GEN-LAST:event_Btn_QCatRemoveActionPerformed

 private void Btn_QCatAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCatAddActionPerformed
  int temp, temp_;
  Object[] NewData;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfSubject;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    NewData=new Object[2];
    NewData[0]=(int)IFV.FDataIdName.DataId[temp_];
    NewData[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQCat.append(NewData);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QCatAddActionPerformed

 private void Btn_QSupRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSupRemoveActionPerformed
  TableMdlQSup.remove(Tbl_QSup.getSelectedRows());
 }//GEN-LAST:event_Btn_QSupRemoveActionPerformed

 private void Btn_QSupAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSupAddActionPerformed
  int temp, temp_;
  Object[] NewData;
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=true;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult==1){
   temp=IFV.FItem.ChoosedId.length;
   temp_=0;
   do{
    NewData=new Object[2];
    NewData[0]=IFV.FItem.ChoosedId[temp_];
    NewData[1]=IFV.FItem.ChoosedName[temp_];
    TableMdlQSup.append(NewData);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QSupAddActionPerformed

 private void Lbl_QNameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QNameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QNameHelpMouseClicked

 private void TF_QNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QNameKeyPressed
  PNav.onKey_Query_TF(this, CB_QName, TF_QName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QBirthStartYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QName)));
 }//GEN-LAST:event_TF_QNameKeyPressed

 private void TF_QNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QNameFocusGained
  LastFocusedCmpSearch=TF_QName;
 }//GEN-LAST:event_TF_QNameFocusGained

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  runQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void CmB_ResultFilterSubsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterSubsetActionPerformed
  int temp=CmB_ResultFilterSubset.getSelectedIndex();
  if(LastResultFilterSubset==temp){return;}
  LastResultFilterSubset=temp;
  fillListSubject();
 }//GEN-LAST:event_CmB_ResultFilterSubsetActionPerformed

 private void Btn_QueryRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryRefreshActionPerformed
  fillListSubject();
 }//GEN-LAST:event_Btn_QueryRefreshActionPerformed

 private void Btn_TempListAddByCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddByCategoryActionPerformed
  int[] Rows=List_Category.getSelectedIndices();
  Vector<String> Alphabets;
  Vector<Long> Categories;
  
  if(Rows.length==0){return;}
  
  Alphabets=new Vector(); Categories=new Vector();
  getListCategoryData(Rows, Alphabets, Categories);
  
  fillTempListByCategory(PCore.refArr_VectStr(Alphabets), PCore.primArr_VectLong(Categories), true);
 }//GEN-LAST:event_Btn_TempListAddByCategoryActionPerformed

 private void Btn_TempListRemoveByCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveByCategoryActionPerformed
  int[] Rows=List_Category.getSelectedIndices();
  Vector<String> Alphabets;
  Vector<Long> Categories;
  
  if(Rows.length==0){return;}
  
  Alphabets=new Vector(); Categories=new Vector();
  getListCategoryData(Rows, Alphabets, Categories);
  
  fillTempListByCategory(PCore.refArr_VectStr(Alphabets), PCore.primArr_VectLong(Categories), false);
 }//GEN-LAST:event_Btn_TempListRemoveByCategoryActionPerformed

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  if(JOptionPane.showConfirmDialog(null, "Kosongkan data pada 'Daftarku' ?", "Konfirmasi Pengosongan Data Pada 'Daftarku'",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  clearTempList();
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Btn_SuppTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppTempListAddActionPerformed
  int[] rows=Tbl_Supp.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlSupp.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_SuppTempListAddActionPerformed

 private void Btn_SuppTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppTempListRemoveActionPerformed
  int[] rows=Tbl_Supp.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlSupp.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_SuppTempListRemoveActionPerformed

 private void Btn_CatAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatAddActionPerformed
  int temp, insertrow;
  Object[] UpdateData;
  String Name;
  
  IFV.FInputName.wTitle="Tambah Kategori Subjek";
  IFV.FInputName.wText="Nama Kategori Subjek yg baru :";
  IFV.FInputName.wInput="";
  IFV.FInputName.wCheckEmpty=false;
  IFV.FInputName.wCheckLength=150;
  IFV.FInputName.wCheckAll=0;
  IFV.FInputName.wCheckFirst=1;
  IFV.FInputName.wCheckLast=1;
  IFV.FInputName.wCheckOther=0;
  
  if(IFV.FInputName.showForm()==false){return;}
  if(IFV.FInputName.DialogResult!=1){return;}
  
  Name=IFV.FInputName.Input;
  temp=PDatabase.addARecordIdName(IFV.Stm, "CategoryOfSubject", Name, true, IFV.Params);
  if(temp!=0){
   if(temp==1){JOptionPane.showMessageDialog(null, "Gagal menambah : Kategori Subjek sudah ada !");}
   else if(temp==-1){JOptionPane.showMessageDialog(null, "Gagal menambah : terjadi kesalahan ketika melakukan operasi !");}
   return;
  }
  
  if(!ListMdlCat.DisplayData || (!CatQueryWithCheck && CatQueryWithoutCheckByTempList)){return;}
  
  UpdateData=new Object[2];
  UpdateData[0]=IFV.Params.Param[0];
  UpdateData[1]=Name;
  insertrow=PGUI.findInsertPos(ListMdlCat, 1, Name, false, true, true);
  ListMdlCat.insert(insertrow, UpdateData);
  LastSelectedRowCat=-1;
  updateCategoryCount();
  
  // optional operation, just to update another related data with this operation
  
 }//GEN-LAST:event_Btn_CatAddActionPerformed

 private void Btn_CatEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatEditActionPerformed
  categoryEdit();
 }//GEN-LAST:event_Btn_CatEditActionPerformed

 private void Btn_CatRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatRemoveActionPerformed
  int[] rows=List_Category.getSelectedIndices();
  Vector<Long> Categories;
  Vector<String> Alphabets;
  long[] ids;
  int curr_offset, curr_operationcount, length, maxeach;
  boolean error;
  
  length=rows.length;
  if(length==0){return;}
  
  Alphabets=new Vector(); Categories=new Vector();
  getListCategoryData(rows, Alphabets, Categories);
  length=Categories.size();
  if(length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+length+" data Kategori Subjek yg dipilih ?"+
   "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
   "Konfirmasi Penghapusan Data Kategori Subjek", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  ids=PCore.primArr_VectLong(Categories);
  
  curr_offset=0; maxeach=1000; error=false;
  do{
   curr_operationcount=maxeach; if(curr_offset+curr_operationcount>length){curr_operationcount=length-curr_offset;}
   
   try{
    IFV.Stm.executeUpdate("delete ignore from CategoryOfSubject where Id in ("+PText.toString(ids, curr_offset, curr_operationcount, ",")+")");
   }
   catch(Exception E){error=true;}
   
   curr_offset=curr_offset+curr_operationcount;
  }while(curr_offset!=length);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlCat.remove(PGUI.inspectLong(ids, ListMdlCat, 0, true, true)); updateCategoryCount(); updateCategoryCheckedCount();
  LastSelectedRowCat=-1;
  
  // optional operation, just to update another related data with this operation
  if(TabbedPane.getSelectedIndex()==3 || SIEtc){
   ListMdlSubCat.remove(PGUI.inspectLong(ids, ListMdlSubCat, 0, true, true));
  }
 }//GEN-LAST:event_Btn_CatRemoveActionPerformed

 private void TF_SuppFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SuppFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_SuppFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Supp)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SuppFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_SuppFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_SuppFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_SuppFindKeyPressed

 private void Btn_SuppFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppFindBefActionPerformed
  findSupp(2);
 }//GEN-LAST:event_Btn_SuppFindBefActionPerformed

 private void Btn_SuppFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppFindNextActionPerformed
  findSupp(1);
 }//GEN-LAST:event_Btn_SuppFindNextActionPerformed

 private void Tbl_SuppMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_SuppMouseReleased
  onSelectedRowSuppChanged(false);
 }//GEN-LAST:event_Tbl_SuppMouseReleased

 private void Tbl_SuppKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_SuppKeyReleased
  onSelectedRowSuppChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Supp, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SuppFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_SuppKeyReleased

 private void List_SubjectMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_SubjectMouseReleased
  onListSubjectSelectedRowChanged(false);
 }//GEN-LAST:event_List_SubjectMouseReleased

 private void List_SubjectKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_SubjectKeyReleased
  onListSubjectSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, List_Subject, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_LEFT :
    if(List_Subject.OnKeyPress_PosCol<=0){
     switch(TabbedPane.getSelectedIndex()){
      case 0 : focusQuery(); break;
      case 1 :
       if(ListMdlCat.getSize()!=0){
        if(List_Category.getSelectedIndex()==-1){List_Category.setSelectedIndex(0); List_Category.ensureIndexIsVisible(0);}
        onListCategoryRowSelected();
        List_Category.requestFocusInWindow();
       }
       break;
     }
    }
    break;
  }
 }//GEN-LAST:event_List_SubjectKeyReleased

 private void List_SubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_SubjectKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    if(wMode==1 && !List_Subject.isEditing()){
     if(List_Subject.getSelectedRows().length!=0){evt.consume(); Btn_ChooseActionPerformed(null);}
    }
    break;
  }
 }//GEN-LAST:event_List_SubjectKeyPressed

 private void CmB_TransTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_TransTypeActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_CmB_TransTypeActionPerformed

 private void RB_TransIsPreTransNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_TransIsPreTransNActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_RB_TransIsPreTransNActionPerformed

 private void RB_TransIsPreTransYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_TransIsPreTransYActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_RB_TransIsPreTransYActionPerformed

 private void Btn_TransInFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInFindNextActionPerformed
  findTransIn(1);
 }//GEN-LAST:event_Btn_TransInFindNextActionPerformed

 private void Btn_TransInFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInFindBefActionPerformed
  findTransIn(2);
 }//GEN-LAST:event_Btn_TransInFindBefActionPerformed

 private void Btn_TransOutFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutFindNextActionPerformed
  findTransOut(1);
 }//GEN-LAST:event_Btn_TransOutFindNextActionPerformed

 private void Btn_TransOutFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutFindBefActionPerformed
  findTransOut(2);
 }//GEN-LAST:event_Btn_TransOutFindBefActionPerformed

 private void CmB_TransItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_TransItemActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_CmB_TransItemActionPerformed

 private void Btn_TransInItemTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInItemTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlTransIn.getIds(8, rows), true);
 }//GEN-LAST:event_Btn_TransInItemTempListAddActionPerformed

 private void Btn_TransInItemTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInItemTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlTransIn.getIds(8, rows), false);
 }//GEN-LAST:event_Btn_TransInItemTempListRemoveActionPerformed

 private void Btn_TransInSubjectTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSubjectTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(2, rows), true);
 }//GEN-LAST:event_Btn_TransInSubjectTempListAddActionPerformed

 private void Btn_TransInSubjectTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSubjectTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(2, rows), false);
 }//GEN-LAST:event_Btn_TransInSubjectTempListRemoveActionPerformed

 private void Btn_TransInSalesmanTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSalesmanTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(4, rows), true);
 }//GEN-LAST:event_Btn_TransInSalesmanTempListAddActionPerformed

 private void Btn_TransInSalesmanTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSalesmanTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(4, rows), false);
 }//GEN-LAST:event_Btn_TransInSalesmanTempListRemoveActionPerformed

 private void Btn_TransOutItemTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutItemTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlTransOut.getIds(8, rows), true);
 }//GEN-LAST:event_Btn_TransOutItemTempListAddActionPerformed

 private void Btn_TransOutItemTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutItemTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlTransOut.getIds(8, rows), false);
 }//GEN-LAST:event_Btn_TransOutItemTempListRemoveActionPerformed

 private void Btn_TransOutSubjectTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSubjectTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(2, rows), true);
 }//GEN-LAST:event_Btn_TransOutSubjectTempListAddActionPerformed

 private void Btn_TransOutSubjectTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSubjectTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(2, rows), false);
 }//GEN-LAST:event_Btn_TransOutSubjectTempListRemoveActionPerformed

 private void Btn_TransOutSalesmanTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSalesmanTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(4, rows), true);
 }//GEN-LAST:event_Btn_TransOutSalesmanTempListAddActionPerformed

 private void Btn_TransOutSalesmanTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSalesmanTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(4, rows), false);
 }//GEN-LAST:event_Btn_TransOutSalesmanTempListRemoveActionPerformed

 private void Tbl_TransOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_TransOutMouseReleased
  onTableTransOutSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_TransOutMouseReleased

 private void Tbl_TransOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransOutKeyReleased
  onTableTransOutSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_TransOut, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransOutFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_TransOutKeyReleased

 private void Tbl_TransInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_TransInMouseReleased
  onTableTransInSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_TransInMouseReleased

 private void Tbl_TransInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransInKeyReleased
  onTableTransInSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_TransIn, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransInFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_TransInKeyReleased

 private void TF_TransInFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransInFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_TransInFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_TransIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_TransInFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransInFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_TransInFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_TransInFindKeyPressed

 private void TF_TransOutFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransOutFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_TransOutFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_TransOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_TransOutFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransOutFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_TransOutFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_TransOutFindKeyPressed

 private void Btn_SuppActiveAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppActiveAddActionPerformed
  setItemSuppActive(true);
 }//GEN-LAST:event_Btn_SuppActiveAddActionPerformed

 private void Btn_SuppActiveRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppActiveRemoveActionPerformed
  setItemSuppActive(false);
 }//GEN-LAST:event_Btn_SuppActiveRemoveActionPerformed

 private void Btn_QTagAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QTagAddActionPerformed
  int temp, temp_;
  Object[] row;
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfSubject;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    row=new Object[2];
    row[0]=(int)IFV.FDataIdName.DataId[temp_];
    row[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQTag.append(row);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QTagAddActionPerformed

 private void Btn_SubPictureAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubPictureAddActionPerformed
  boolean firstinsert, error;
  int row;
  int MaxEachInsert, CurrInsertCount;
  int currpic, piclength;
  long Id;
  String[] FilesName;
  Object[] RowData;
  StringBuilder Values;
  int insertpos;
  Vector<OTableCellUpdater> Updater;
  OTableCellReference[] CheckCells;
  
  row=List_Subject.getSelectedRow();
  if(row==-1){return;}
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Tambah (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(row)[0];
  MaxEachInsert=1000;
  FilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  piclength=FilesName.length;
  currpic=0;
  error=false;
  do{
   Values=new StringBuilder();
   
   CurrInsertCount=0;
   firstinsert=true;
   do{
    if(firstinsert){firstinsert=false;}else{Values.append(',');}
    Values.append("("+Id+",'"+PSql.norm(FilesName[currpic])+"')");
    CurrInsertCount=CurrInsertCount+1;
    
    currpic=currpic+1;
   }while(currpic!=piclength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into SubjectXPicture(Subject, FileName) values "+Values.toString());}
   catch(Exception E){error=true;}
  }while(currpic!=piclength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  Updater=new Vector();
  CheckCells=new OTableCellReference[1]; CheckCells[0]=new OTableCellReference(0, 0, 0, 0);
  Updater.addElement(new OTableCellUpdaterSelect(
   new OTableCellUpdaterSelectCheckerNull(true, 3, CheckCells),
   new OTableCellUpdaterByObject(3, FilesName[0]),
   new OTableCellUpdaterByNone(3)));
  PGUI.changeElements(ListMdlSubject, PCore.primArr(row), Updater);
  
  currpic=0;
  insertpos=-1;
  do{
   if(PGUI.findString(ListMdlSubPic, 0, FilesName[currpic])==-1){
    RowData=new Object[1];
    RowData[0]=FilesName[currpic];
    insertpos=PGUI.findInsertPos(ListMdlSubPic, 0, FilesName[currpic], false, true, true);
    ListMdlSubPic.insert(insertpos, RowData);
   }
   currpic=currpic+1;
  }while(currpic!=piclength);
  if(insertpos!=-1){
   List_SubPicture.setSelectedIndex(insertpos); List_SubPicture.ensureIndexIsVisible(insertpos); onListPicRowSelected(true);
  }
  SIPic=true; SIPicClear=false; SIEmptyAll=false;
 }//GEN-LAST:event_Btn_SubPictureAddActionPerformed

 private void Btn_SubPictureRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubPictureRemoveActionPerformed
  int[] rows=List_SubPicture.getSelectedIndices();
  int rowSubject=List_Subject.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currpic, currpiclistcount, piclength;
  String PicList;
  
  if(rows.length==0 || rowSubject==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" gambar yang dipilih dari daftar gambar barang ?"+
   "\n(operasi ini hanya menghapus data di database dan tidak menghapus file yang sebenarnya)",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rowSubject)[0];
  MaxList=1000;
  error=false;
  piclength=rows.length;
  currpic=0;
  do{
   currpiclistcount=MaxList;
   if(currpic+currpiclistcount>piclength){currpiclistcount=piclength-currpic;}
   PicList=PGUI.getElementList(ListMdlSubPic.Mdl.Rows, PCore.subArr(rows, currpic, currpiclistcount), 0, ",", "'", true);
   
   try{IFV.Stm.execute("delete ignore from SubjectXPicture where Subject="+Id+" and FileName in("+PicList+")");}
   catch(Exception E){error=true;}
   
   currpic=currpic+currpiclistcount;
  }while(currpic!=piclength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlSubPic.remove(rows);
  onListPicRowSelected(true);
 }//GEN-LAST:event_Btn_SubPictureRemoveActionPerformed

 private void Btn_MultipleSubjectsTagAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsTagAddActionPerformed
  int[] rows;
  boolean firstinsert, error;
  int currsubject, subjectlength, currtag, taglength;
  int MaxEachInsert, CurrInsertCount;
  long Id;
  Object[] RowData;
  StringBuilder records;
  int insertpos;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfSubject;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Tag Pada Beberapa Subjek";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  subjectlength=rows.length;
  currsubject=0;
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsubject])[0];
  currtag=0;
  taglength=IFV.FDataIdName.DataId.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+","+IFV.FDataIdName.DataId[currtag]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currtag=currtag+1;
    if(currtag==taglength){
     currsubject=currsubject+1;
     if(currsubject!=subjectlength){
      Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsubject])[0];
      currtag=0;
     }
    }
   }while(currsubject!=subjectlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into SubjectXTag(Subject, TagOfSubject) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(currsubject!=subjectlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  if(TabbedPane.getSelectedIndex()==3 || SIEtc){
   currtag=0;
   insertpos=-1;
   do{
    if(PGUI.findLong(ListMdlSubTag, 0, IFV.FDataIdName.DataId[currtag])==-1){
     RowData=new Object[2];
     RowData[0]=(int)IFV.FDataIdName.DataId[currtag];
     RowData[1]=IFV.FDataIdName.DataName[currtag];
     insertpos=PGUI.findInsertPos(ListMdlSubTag, 1, IFV.FDataIdName.DataName[currtag], false, true, true);
     ListMdlSubTag.insert(insertpos, RowData);
    }
    currtag=currtag+1;
   }while(currtag!=taglength);
   if(insertpos!=-1){
    List_SubTag.setSelectedIndex(insertpos); List_SubTag.ensureIndexIsVisible(insertpos);
   }
   SIEtc=true; SIEtcClear=false; SIEmptyAll=false;
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsTagAddActionPerformed

 private void Btn_MultipleSubjectsTagRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsTagRemoveActionPerformed
  int[] rows;
  boolean error;
  int MaxListTag, MaxListSubject;
  int currsubject, currsubjectlistcount, subjectlength,
      currtag, currtaglistcount, taglength;
  int findindex;
  String SubjectList, TagList;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfSubject;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menghapus Tag Dari Beberapa Subjek";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}

  MaxListTag=1000;
  MaxListSubject=1000;
  
  subjectlength=rows.length;
  currsubject=0;
  taglength=IFV.FDataIdName.DataId.length;
  error=false;
  
  do{
   currsubjectlistcount=MaxListSubject;
   if(currsubject+currsubjectlistcount>subjectlength){currsubjectlistcount=subjectlength-currsubject;}
   SubjectList=PGUI.getElementList(ListMdlSubject.Mdl.Rows, PCore.subArr(rows, currsubject, currsubjectlistcount), 0, ",", "", false);
   
   currtag=0;
   do{
    currtaglistcount=MaxListTag;
    if(currtag+currtaglistcount>taglength){currtaglistcount=taglength-currtag;}
    TagList=PText.toString(IFV.FDataIdName.DataId, currtag, currtaglistcount, ",");
    
    try{
     IFV.Stm.execute("delete ignore from SubjectXTag where Subject in ("+SubjectList+") and TagOfSubject in ("+TagList+")");
    }
    catch(Exception E){error=true;}
    
    currtag=currtag+currtaglistcount;
   }while(currtag!=taglength);
   
   currsubject=currsubject+currsubjectlistcount;
  }while(currsubject!=subjectlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(SIEtc){
   currtag=0;
   do{
    findindex=PGUI.findLong(ListMdlSubTag, 0, IFV.FDataIdName.DataId[currtag]);
    if(findindex>=0){ListMdlSubTag.remove(findindex);}
    currtag=currtag+1;
   }while(currtag!=taglength);
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsTagRemoveActionPerformed

 private void Btn_MultipleSubjectsPicAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsPicAddActionPerformed
  int[] rows;
  long Id;
  String[] ImgFilesName;
  Object[] RowData;
  boolean firstinsert, error;
  int currsubject, subjectlength, currpic, piclength;
  int MaxEachInsert, CurrInsertCount;
  StringBuilder records;
  int insertpos;
  Vector<OTableCellUpdater> Updater;
  OTableCellReference[] CheckCells;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Tambah (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  subjectlength=rows.length;
  currsubject=0;
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsubject])[0];
  currpic=0;
  ImgFilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  piclength=ImgFilesName.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+",'"+PSql.norm(ImgFilesName[currpic])+"')");
    CurrInsertCount=CurrInsertCount+1;
    
    currpic=currpic+1;
    if(currpic==piclength){
     currsubject=currsubject+1;
     if(currsubject!=subjectlength){
      Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rows[currsubject])[0];
      currpic=0;
     }
    }
   }while(currsubject!=subjectlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into SubjectXPicture(Subject, FileName) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(currsubject!=subjectlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  Updater=new Vector();
  CheckCells=new OTableCellReference[1]; CheckCells[0]=new OTableCellReference(0, 0, 0, 0);
  Updater.addElement(new OTableCellUpdaterSelect(
   new OTableCellUpdaterSelectCheckerNull(true, 3, CheckCells),
   new OTableCellUpdaterByObject(3, ImgFilesName[0]),
   new OTableCellUpdaterByNone(3)));
  PGUI.changeElements(ListMdlSubject, rows, Updater);
  
  if(TabbedPane.getSelectedIndex()==4 || SIPic){
   currpic=0;
   insertpos=-1;
   do{
    if(PGUI.findString(ListMdlSubPic, 0, ImgFilesName[currpic])==-1){
     RowData=new Object[1];
     RowData[0]=ImgFilesName[currpic];
     insertpos=PGUI.findInsertPos(ListMdlSubPic, 0, ImgFilesName[currpic], false, true, true);
     ListMdlSubPic.insert(insertpos, RowData);
    }
    currpic=currpic+1;
   }while(currpic!=piclength);
   if(insertpos!=-1){
    List_SubPicture.setSelectedIndex(insertpos); List_SubPicture.ensureIndexIsVisible(insertpos); onListPicRowSelected(true);
   }
   SIPic=true; SIPicClear=false; SIEmptyAll=false;
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsPicAddActionPerformed

 private void Btn_MultipleSubjectsPicRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleSubjectsPicRemoveActionPerformed
  int[] rows;
  boolean error, removeintab;
  int MaxListPic, MaxListSubject;
  int currsubject, currsubjectlistcount, subjectlength,
      currpic, currpiclistcount, piclength;
  int findindex;
  String SubjectList, PicList;
  String[] ImgFilesName;
  
  rows=List_Subject.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Hapus (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  MaxListPic=1000;
  MaxListSubject=1000;
  
  subjectlength=rows.length;
  currsubject=0;
  ImgFilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  piclength=ImgFilesName.length;
  error=false;
  
  do{
   currsubjectlistcount=MaxListSubject;
   if(currsubject+currsubjectlistcount>subjectlength){currsubjectlistcount=subjectlength-currsubject;}
   SubjectList=PGUI.getElementList(ListMdlSubject.Mdl.Rows, PCore.subArr(rows, currsubject, currsubjectlistcount), 0, ",", "", false);
   
   currpic=0;
   do{
    currpiclistcount=MaxListPic;
    if(currpic+currpiclistcount>piclength){currpiclistcount=piclength-currpic;}
    PicList=PText.toStringWithQuote(ImgFilesName, currpic, currpiclistcount, ",", "'", true);
    
    try{
     IFV.Stm.execute("delete ignore from SubjectXPicture where Subject in ("+SubjectList+") and FileName in ("+PicList+")");
    }
    catch(Exception E){error=true;}
    
    currpic=currpic+currpiclistcount;
   }while(currpic!=piclength);
   
   currsubject=currsubject+currsubjectlistcount;
  }while(currsubject!=subjectlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(SIPic){
   removeintab=false;
   currpic=0;
   do{
    findindex=PGUI.findString(ListMdlSubPic, 0, ImgFilesName[currpic]);
    if(findindex>=0){ListMdlSubPic.remove(findindex); removeintab=true;}
    currpic=currpic+1;
   }while(currpic!=piclength);
   if(removeintab){onListPicRowSelected(true);}
  }
 }//GEN-LAST:event_Btn_MultipleSubjectsPicRemoveActionPerformed

 private void Btn_QTagRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QTagRemoveActionPerformed
  ListMdlQTag.remove(List_QTag.getSelectedIndices());
 }//GEN-LAST:event_Btn_QTagRemoveActionPerformed

 private void Btn_QPicAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QPicAddActionPerformed
  int temp;
  String[] FilesName;
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Tambah (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  FilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  temp=0;
  do{
   ListMdlQPic.append(PCore.objArrVariant(FilesName[temp]));
   temp=temp+1;
  }while(temp!=FilesName.length);
 }//GEN-LAST:event_Btn_QPicAddActionPerformed

 private void Btn_QPicRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QPicRemoveActionPerformed
  ListMdlQPic.remove(List_QPic.getSelectedIndices());
 }//GEN-LAST:event_Btn_QPicRemoveActionPerformed

 private void Btn_SubjectTagAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubjectTagAddActionPerformed
  boolean firstinsert, error;
  int row;
  int MaxEachInsert, CurrInsertCount;
  int currtag, taglength;
  long Id;
  Object[] RowData;
  StringBuilder Values;
  int insertpos;
  
  row=List_Subject.getSelectedRow();
  if(row==-1){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfSubject;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Tag Pada Sebuah Subjek";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(row)[0];
  MaxEachInsert=1000;
  taglength=IFV.FDataIdName.DataId.length;
  currtag=0;
  error=false;
  do{
   Values=new StringBuilder();
   
   CurrInsertCount=0;
   firstinsert=true;
   do{
    if(firstinsert){firstinsert=false;}else{Values.append(',');}
    Values.append("("+Id+","+IFV.FDataIdName.DataId[currtag]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currtag=currtag+1;
   }while(currtag!=taglength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into SubjectXTag(Subject, TagOfSubject) values "+Values.toString());}
   catch(Exception E){error=true;}
  }while(currtag!=taglength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  currtag=0;
  insertpos=-1;
  do{
   if(PGUI.findLong(ListMdlSubTag, 0, IFV.FDataIdName.DataId[currtag])==-1){
    RowData=new Object[2];
    RowData[0]=(int)IFV.FDataIdName.DataId[currtag];
    RowData[1]=IFV.FDataIdName.DataName[currtag];
    insertpos=PGUI.findInsertPos(ListMdlSubTag, 1, IFV.FDataIdName.DataName[currtag], false, true, true);
    ListMdlSubTag.insert(insertpos, RowData);
   }
   currtag=currtag+1;
  }while(currtag!=taglength);
  if(insertpos!=-1){
   List_SubTag.setSelectedIndex(insertpos); List_SubTag.ensureIndexIsVisible(insertpos);
  }
  SIEtc=true; SIEtcClear=false; SIEmptyAll=false;
 }//GEN-LAST:event_Btn_SubjectTagAddActionPerformed

 private void Btn_SubjectTagRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubjectTagRemoveActionPerformed
  int[] rows=List_SubTag.getSelectedIndices();
  int rowSubject=List_Subject.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currtag, currtaglistcount, taglength;
  String TagList;
  
  if(rows.length==0 || rowSubject==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" tag yg dipilih dari daftar tag subjek ?",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)ListMdlSubject.Mdl.Rows.elementAt(rowSubject)[0];
  MaxList=1000;
  error=false;
  taglength=rows.length;
  currtag=0;
  do{
   currtaglistcount=MaxList;
   if(currtag+currtaglistcount>taglength){currtaglistcount=taglength-currtag;}
   TagList=PGUI.getElementList(ListMdlSubTag.Mdl.Rows, PCore.subArr(rows, currtag, currtaglistcount), 0, ",", "", false);
   
   try{IFV.Stm.execute("delete ignore from SubjectXTag where Subject="+Id+" and TagOfSubject in("+TagList+")");}
   catch(Exception E){error=true;}
   
   currtag=currtag+currtaglistcount;
  }while(currtag!=taglength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlSubTag.remove(rows);
 }//GEN-LAST:event_Btn_SubjectTagRemoveActionPerformed

 private void Pnl_SuppInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_SuppInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Supp, TableMdlSupp, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_SuppInfoPreviewMouseClicked

 private void ImgBox_TransInInfoItemPicMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ImgBox_TransInInfoItemPicMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_TransIn, TableMdlTransIn, 8, IFV.FItemPreview);
 }//GEN-LAST:event_ImgBox_TransInInfoItemPicMouseClicked

 private void ImgBox_TransOutInfoItemPicMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ImgBox_TransOutInfoItemPicMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_TransOut, TableMdlTransOut, 8, IFV.FItemPreview);
 }//GEN-LAST:event_ImgBox_TransOutInfoItemPicMouseClicked

 private void Btn_TransItemInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransItemInfoActionPerformed
  PMyShop.viewFormInfo_FromComboBox(CmB_TransItem, ComboMdlTransItem, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Btn_TransItemInfoActionPerformed

 private void Btn_TransInSubjectInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSubjectInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransIn, TableMdlTransIn, 2, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransInSubjectInfoActionPerformed

 private void Btn_TransInSalesmanInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSalesmanInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransIn, TableMdlTransIn, 4, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransInSalesmanInfoActionPerformed

 private void Btn_TransOutSubjectInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSubjectInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransOut, TableMdlTransOut, 2, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransOutSubjectInfoActionPerformed

 private void Btn_TransOutSalesmanInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSalesmanInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransOut, TableMdlTransOut, 4, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransOutSalesmanInfoActionPerformed

 private void Btn_TransInTransTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInTransTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransIn.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, true);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, true);
  }
 }//GEN-LAST:event_Btn_TransInTransTempListAddActionPerformed

 private void Btn_TransInTransTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInTransTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransIn.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, false);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, false);
  }
 }//GEN-LAST:event_Btn_TransInTransTempListRemoveActionPerformed

 private void Btn_TransInTransInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInTransInfoActionPerformed
  PMyShop.viewFormInfo_SpecificTrans_FromTable(Tbl_TransIn, TableMdlTransIn, 6, IFV.FTransPreview, RB_TransIsPreTransY.isSelected(), false);
 }//GEN-LAST:event_Btn_TransInTransInfoActionPerformed

 private void Btn_TransOutTransTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutTransTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransOut.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, true);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, true);
  }
 }//GEN-LAST:event_Btn_TransOutTransTempListAddActionPerformed

 private void Btn_TransOutTransTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutTransTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransOut.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, false);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, false);
  }
 }//GEN-LAST:event_Btn_TransOutTransTempListRemoveActionPerformed

 private void Btn_TransOutTransInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutTransInfoActionPerformed
  PMyShop.viewFormInfo_SpecificTrans_FromTable(Tbl_TransOut, TableMdlTransOut, 6, IFV.FTransPreview, RB_TransIsPreTransY.isSelected(), false);
 }//GEN-LAST:event_Btn_TransOutTransInfoActionPerformed

 private void Pnl_InfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_InfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(List_Subject, ListMdlSubject, 0, IFV.FSubjectPreview);
 }//GEN-LAST:event_Pnl_InfoPreviewMouseClicked

 private void Tbl_AddrKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_AddrKeyReleased
  onSelectedRowAddrChanged(false);
 }//GEN-LAST:event_Tbl_AddrKeyReleased

 private void Tbl_AddrMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_AddrMouseReleased
  onSelectedRowAddrChanged(false);
 }//GEN-LAST:event_Tbl_AddrMouseReleased

 private void Tbl_ContKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ContKeyReleased
  onSelectedRowContChanged(false);
 }//GEN-LAST:event_Tbl_ContKeyReleased

 private void Tbl_ContMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ContMouseReleased
  onSelectedRowContChanged(false);
 }//GEN-LAST:event_Tbl_ContMouseReleased

 private void List_CategoryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_CategoryKeyReleased
  onListCategoryRowSelected();
  
  int consumed=PNav.onKey_List(this, List_Category, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_CatRefresh)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_FindCategory)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddByCategoryActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveByCategoryActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_RIGHT:
    if(!ListMdlSubject.Mdl.Rows.isEmpty()){
     if(List_Subject.getSelectedRow()==-1){
      List_Subject.changeSelection(0, 0, false, false); onListSubjectSelectedRowChanged(false);
     }
     List_Subject.requestFocusInWindow();
    }
    break;
  }
 }//GEN-LAST:event_List_CategoryKeyReleased

 private void List_CategoryMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_CategoryMouseReleased
  onListCategoryRowSelected();
 }//GEN-LAST:event_List_CategoryMouseReleased

 private void List_SubPictureKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_SubPictureKeyReleased
  onListPicRowSelected(false);
 }//GEN-LAST:event_List_SubPictureKeyReleased

 private void List_SubPictureMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_SubPictureMouseReleased
  onListPicRowSelected(false);
 }//GEN-LAST:event_List_SubPictureMouseReleased

 private void Btn_QueryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QueryKeyPressed
  PNav.onKey_Btn(this, Btn_Query, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QueryKeyPressed

 private void CB_QNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QNameKeyPressed
  PNav.onKey_CB(this, CB_QName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QBirthDate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QName)));
 }//GEN-LAST:event_CB_QNameKeyPressed

 private void CB_QBirthDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QBirthDateKeyPressed
  PNav.onKey_CB(this, CB_QBirthDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QBirthStartYear)));
 }//GEN-LAST:event_CB_QBirthDateKeyPressed

 private void TF_QBirthStartYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QBirthStartYearKeyPressed
  PNav.onKey_TF(this, TF_QBirthStartYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QBirthDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBirthStartMonth)));
 }//GEN-LAST:event_TF_QBirthStartYearKeyPressed

 private void CmB_QBirthStartMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBirthStartMonthKeyPressed
  PNav.onKey_CmB(this, CmB_QBirthStartMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QBirthStartYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBirthStartDay)));
 }//GEN-LAST:event_CmB_QBirthStartMonthKeyPressed

 private void CmB_QBirthStartDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBirthStartDayKeyPressed
  PNav.onKey_CmB(this, CmB_QBirthStartDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QBirthStartMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QBirthEndYear)));
 }//GEN-LAST:event_CmB_QBirthStartDayKeyPressed

 private void TF_QBirthEndYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QBirthEndYearKeyPressed
  PNav.onKey_TF(this, TF_QBirthEndYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QBirthStartDay)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBirthEndMonth)));
 }//GEN-LAST:event_TF_QBirthEndYearKeyPressed

 private void CmB_QBirthEndMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBirthEndMonthKeyPressed
  PNav.onKey_CmB(this, CmB_QBirthEndMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QBirthEndYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBirthEndDay)));
 }//GEN-LAST:event_CmB_QBirthEndMonthKeyPressed

 private void CmB_QBirthEndDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBirthEndDayKeyPressed
  PNav.onKey_CmB(this, CmB_QBirthEndDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QBirthEndMonth)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QBirthEndDayKeyPressed

 private void CB_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCommentKeyPressed
  PNav.onKey_CB(this, CB_QComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QBirthDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QAddress)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QComment)));
 }//GEN-LAST:event_CB_QCommentKeyPressed

 private void CB_QAddressKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QAddressKeyPressed
  PNav.onKey_CB(this, CB_QAddress, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QContact)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QAddress)));
 }//GEN-LAST:event_CB_QAddressKeyPressed

 private void CB_QContactKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QContactKeyPressed
  PNav.onKey_CB(this, CB_QContact, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QAddress)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QBankAccount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QContact)));
 }//GEN-LAST:event_CB_QContactKeyPressed

 private void CB_QCityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCityKeyPressed
  PNav.onKey_CB(this, CB_QCity, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QBankAccount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCityUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCity)));
 }//GEN-LAST:event_CB_QCityKeyPressed

 private void CB_QCityUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCityUndefinedKeyPressed
  PNav.onKey_CB(this, CB_QCityUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QContactType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCity)));
 }//GEN-LAST:event_CB_QCityUndefinedKeyPressed

 private void List_QCityKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QCityKeyReleased
  PNav.onKey_List(this, List_QCity, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QBankAccount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QContactTypeAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCity)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QCityAdd)));
 }//GEN-LAST:event_List_QCityKeyReleased

 private void Btn_QCityAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCityAddKeyPressed
  PNav.onKey_Btn(this, Btn_QCityAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QBankAccount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCityRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCity)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCityAddKeyPressed

 private void Btn_QCityRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCityRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QCityRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCityAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QContactTypeAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCity)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCityRemoveKeyPressed

 private void CB_QContactTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QContactTypeKeyPressed
  PNav.onKey_CB(this, CB_QContactType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCityUndefined)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QContactTypeUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QContactType)));
 }//GEN-LAST:event_CB_QContactTypeKeyPressed

 private void CB_QContactTypeUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QContactTypeUndefinedKeyPressed
  PNav.onKey_CB(this, CB_QContactTypeUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QContactType)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QBankPlatform)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QContactType)));
 }//GEN-LAST:event_CB_QContactTypeUndefinedKeyPressed

 private void List_QContactTypeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QContactTypeKeyReleased
  PNav.onKey_List(this, List_QContactType, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCityAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QBankPlatformAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QContactType)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QContactTypeAdd)));
 }//GEN-LAST:event_List_QContactTypeKeyReleased

 private void Btn_QContactTypeAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QContactTypeAddKeyPressed
  PNav.onKey_Btn(this, Btn_QContactTypeAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCityRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QContactTypeRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QContactType)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QContactTypeAddKeyPressed

 private void Btn_QContactTypeRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QContactTypeRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QContactTypeRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QContactTypeAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QBankPlatformAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QContactType)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QContactTypeRemoveKeyPressed

 private void CB_QCatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCatKeyPressed
  PNav.onKey_CB(this, CB_QCat, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QBankPlatformUndefined)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCatNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCat)));
 }//GEN-LAST:event_CB_QCatKeyPressed

 private void CB_QCatNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCatNonKeyPressed
  PNav.onKey_CB(this, CB_QCatNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCat)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QTag)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCat)));
 }//GEN-LAST:event_CB_QCatNonKeyPressed

 private void List_QCatKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QCatKeyReleased
  PNav.onKey_List(this, List_QCat, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QBankPlatformAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCat)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QCatAdd)));
 }//GEN-LAST:event_List_QCatKeyReleased

 private void Btn_QCatAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCatAddKeyPressed
  PNav.onKey_Btn(this, Btn_QCatAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QBankPlatformRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCatRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCat)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCatAddKeyPressed

 private void Btn_QCatRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCatRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QCatRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCat)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCatRemoveKeyPressed

 private void CB_QTagKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QTagKeyPressed
  PNav.onKey_CB(this, CB_QTag, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCatNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QTagNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QTag)));
 }//GEN-LAST:event_CB_QTagKeyPressed

 private void CB_QTagNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QTagNonKeyPressed
  PNav.onKey_CB(this, CB_QTagNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QTag)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPic)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QTag)));
 }//GEN-LAST:event_CB_QTagNonKeyPressed

 private void List_QTagKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QTagKeyReleased
  PNav.onKey_List(this, List_QTag, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QTag)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QTagAdd)));
 }//GEN-LAST:event_List_QTagKeyReleased

 private void Btn_QTagAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QTagAddKeyPressed
  PNav.onKey_Btn(this, Btn_QTagAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCatRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTagRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QTag)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QTagAddKeyPressed

 private void Btn_QTagRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QTagRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QTagRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QTag)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QTagRemoveKeyPressed

 private void CB_QPicKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPicKeyPressed
  PNav.onKey_CB(this, CB_QPic, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QTagNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPicNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QPic)));
 }//GEN-LAST:event_CB_QPicKeyPressed

 private void CB_QPicNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPicNonKeyPressed
  PNav.onKey_CB(this, CB_QPicNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPic)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSup)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QPic)));
 }//GEN-LAST:event_CB_QPicNonKeyPressed

 private void List_QPicKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QPicKeyReleased
  PNav.onKey_List(this, List_QPic, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSupAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QPic)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QPicAdd)));
 }//GEN-LAST:event_List_QPicKeyReleased

 private void Btn_QPicAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QPicAddKeyPressed
  PNav.onKey_Btn(this, Btn_QPicAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTagRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QPicRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QPic)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QPicAddKeyPressed

 private void Btn_QPicRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QPicRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QPicRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSupAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QPic)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QPicRemoveKeyPressed

 private void CB_QSupKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSupKeyPressed
  PNav.onKey_CB(this, CB_QSup, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPicNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSupNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QSup)));
 }//GEN-LAST:event_CB_QSupKeyPressed

 private void CB_QSupNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSupNonKeyPressed
  PNav.onKey_CB(this, CB_QSupNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QSup)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QSup)));
 }//GEN-LAST:event_CB_QSupNonKeyPressed

 private void Tbl_QSupKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_QSupKeyReleased
  PNav.onKey_Tbl(this, Tbl_QSup, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QSup)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QSupAdd)));
 }//GEN-LAST:event_Tbl_QSupKeyReleased

 private void Btn_QSupAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSupAddKeyPressed
  PNav.onKey_Btn(this, Btn_QSupAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QPicRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSupRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QSup)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSupAddKeyPressed

 private void Btn_QSupRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSupRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QSupRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSupAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QSup)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSupRemoveKeyPressed

 private void Btn_CatRefreshKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatRefreshKeyPressed
  PNav.onKey_Btn(this, Btn_CatRefresh, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Category)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_CatQueryType)));
 }//GEN-LAST:event_Btn_CatRefreshKeyPressed

 private void CmB_CatQueryTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_CatQueryTypeKeyPressed
  PNav.onKey_CmB(this, CmB_CatQueryType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CatRefresh)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TempListAddByCategory)));
 }//GEN-LAST:event_CmB_CatQueryTypeKeyPressed

 private void Btn_TempListAddByCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TempListAddByCategoryKeyPressed
  PNav.onKey_Btn(this, Btn_TempListAddByCategory, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Category)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_CatQueryType)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TempListRemoveByCategory)));
 }//GEN-LAST:event_Btn_TempListAddByCategoryKeyPressed

 private void Btn_TempListRemoveByCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveByCategoryKeyPressed
  PNav.onKey_Btn(this, Btn_TempListRemoveByCategory, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Category)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_TempListAddByCategory)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_TempListRemoveByCategoryKeyPressed

 private void Btn_FCatBeforeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatBeforeKeyPressed
  PNav.onKey_Btn(this, Btn_FCatBefore, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_FindCategory)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FCatNext)));
 }//GEN-LAST:event_Btn_FCatBeforeKeyPressed

 private void Btn_FCatNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatNextKeyPressed
  PNav.onKey_Btn(this, Btn_FCatNext, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FCatBefore)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CatAdd)));
 }//GEN-LAST:event_Btn_FCatNextKeyPressed

 private void Btn_CatAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatAddKeyPressed
  PNav.onKey_Btn(this, Btn_CatAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FCatNext)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CatEdit)));
 }//GEN-LAST:event_Btn_CatAddKeyPressed

 private void Btn_CatEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatEditKeyPressed
  PNav.onKey_Btn(this, Btn_CatEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CatAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CatRemove)));
 }//GEN-LAST:event_Btn_CatEditKeyPressed

 private void Btn_CatRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_CatRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CatEdit)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_CatRemoveKeyPressed

 private void CB_SuppViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewCategorizedActionPerformed
  changeSuppViewByCategorized();
 }//GEN-LAST:event_CB_SuppViewCategorizedActionPerformed

 private void CB_SuppViewBuyPrcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewBuyPrcActionPerformed
  changeSuppViewByNormal();
 }//GEN-LAST:event_CB_SuppViewBuyPrcActionPerformed

 private void CB_SuppViewBuyCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewBuyCommentActionPerformed
  changeSuppViewByNormal();
 }//GEN-LAST:event_CB_SuppViewBuyCommentActionPerformed

 private void CB_SuppViewBuyUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewBuyUpdateActionPerformed
  changeSuppViewByNormal();
 }//GEN-LAST:event_CB_SuppViewBuyUpdateActionPerformed

 private void CB_TransInDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInDateActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInDateActionPerformed

 private void CB_TransInTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInTypeActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInTypeActionPerformed

 private void CB_TransInSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInSubjectActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInSubjectActionPerformed

 private void CB_TransInIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInIdActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInIdActionPerformed

 private void CB_TransInIdExternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInIdExternalActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInIdExternalActionPerformed

 private void CB_TransInItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInItemActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInItemActionPerformed

 private void CB_TransInItemCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInItemCommentActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInItemCommentActionPerformed

 private void CB_TransInPriceUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInPriceUnitActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInPriceUnitActionPerformed

 private void CB_TransInPriceTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInPriceTotalActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInPriceTotalActionPerformed

 private void CB_TransOutDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutDateActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutDateActionPerformed

 private void CB_TransOutTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutTypeActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutTypeActionPerformed

 private void CB_TransOutSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutSubjectActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutSubjectActionPerformed

 private void CB_TransOutSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutSalesmanActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutSalesmanActionPerformed

 private void CB_TransOutIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutIdActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutIdActionPerformed

 private void CB_TransOutIdExternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutIdExternalActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutIdExternalActionPerformed

 private void CB_TransOutItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutItemActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutItemActionPerformed

 private void CB_TransOutItemCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutItemCommentActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutItemCommentActionPerformed

 private void CB_TransOutPriceUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutPriceUnitActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutPriceUnitActionPerformed

 private void CB_TransOutPriceTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutPriceTotalActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutPriceTotalActionPerformed

 private void CB_TransOutPriceBasicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutPriceBasicActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutPriceBasicActionPerformed

 private void CB_TransInSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInSalesmanActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInSalesmanActionPerformed

 private void CB_TransInItemStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInItemStockUnitActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInItemStockUnitActionPerformed

 private void CB_TransOutItemStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutItemStockUnitActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutItemStockUnitActionPerformed

 private void CB_AddrViewCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AddrViewCityActionPerformed
  changeAddrViewByNormal();
 }//GEN-LAST:event_CB_AddrViewCityActionPerformed

 private void CB_AddrViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AddrViewCommentActionPerformed
  changeAddrViewByNormal();
 }//GEN-LAST:event_CB_AddrViewCommentActionPerformed

 private void CB_ContViewContactTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ContViewContactTypeActionPerformed
  changeContViewByNormal();
 }//GEN-LAST:event_CB_ContViewContactTypeActionPerformed

 private void CB_ContViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ContViewCommentActionPerformed
  changeContViewByNormal();
 }//GEN-LAST:event_CB_ContViewCommentActionPerformed

 private void CB_AccViewBankPlatformActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AccViewBankPlatformActionPerformed
  changeAccViewByNormal();
 }//GEN-LAST:event_CB_AccViewBankPlatformActionPerformed

 private void CB_AccViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AccViewCommentActionPerformed
  changeAccViewByNormal();
 }//GEN-LAST:event_CB_AccViewCommentActionPerformed

 private void Btn_SubAccountAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubAccountAddActionPerformed
  addAcc();
 }//GEN-LAST:event_Btn_SubAccountAddActionPerformed

 private void Btn_SubAccountEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubAccountEditActionPerformed
  editAcc();
 }//GEN-LAST:event_Btn_SubAccountEditActionPerformed

 private void Btn_SubAccountRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SubAccountRemoveActionPerformed
  removeAcc();
 }//GEN-LAST:event_Btn_SubAccountRemoveActionPerformed

 private void Tbl_AccKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_AccKeyReleased
  onSelectedRowAccChanged(false);
 }//GEN-LAST:event_Tbl_AccKeyReleased

 private void Tbl_AccMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_AccMouseReleased
  onSelectedRowAccChanged(false);
 }//GEN-LAST:event_Tbl_AccMouseReleased

 private void Btn_QBankPlatformAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QBankPlatformAddActionPerformed
  int temp, temp_;
  Object[] NewData;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblBankPlatform;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    NewData=new Object[2];
    NewData[0]=(int)IFV.FDataIdName.DataId[temp_];
    NewData[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQBankPlatform.append(NewData);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QBankPlatformAddActionPerformed

 private void Btn_QBankPlatformRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QBankPlatformRemoveActionPerformed
  ListMdlQBankPlatform.remove(List_QBankPlatform.getSelectedIndices());
 }//GEN-LAST:event_Btn_QBankPlatformRemoveActionPerformed

 private void Lbl_QBankAccountHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QBankAccountHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QBankAccountHelpMouseClicked

 private void CB_QBankAccountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QBankAccountKeyPressed
  PNav.onKey_CB(this, CB_QBankAccount, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QContact)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QBankAccount)));
 }//GEN-LAST:event_CB_QBankAccountKeyPressed

 private void TF_QBankAccountFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QBankAccountFocusGained
  LastFocusedCmpSearch=TF_QBankAccount;
 }//GEN-LAST:event_TF_QBankAccountFocusGained

 private void TF_QBankAccountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QBankAccountKeyPressed
  PNav.onKey_Query_TF(this, CB_QBankAccount, TF_QBankAccount, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QContact)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCityAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QBankAccount)));
 }//GEN-LAST:event_TF_QBankAccountKeyPressed

 private void CB_QBankPlatformKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QBankPlatformKeyPressed
  PNav.onKey_CB(this, CB_QBankPlatform, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QContactTypeUndefined)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QBankPlatformUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QBankPlatform)));
 }//GEN-LAST:event_CB_QBankPlatformKeyPressed

 private void CB_QBankPlatformUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QBankPlatformUndefinedKeyPressed
  PNav.onKey_CB(this, CB_QBankPlatformUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QBankPlatform)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCat)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QBankPlatform)));
 }//GEN-LAST:event_CB_QBankPlatformUndefinedKeyPressed

 private void Btn_QBankPlatformAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QBankPlatformAddKeyPressed
  PNav.onKey_Btn(this, Btn_QBankPlatformAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QContactTypeRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QBankPlatformRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QBankPlatform)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QBankPlatformAddKeyPressed

 private void Btn_QBankPlatformRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QBankPlatformRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QBankPlatformRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QBankPlatformAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QBankPlatform)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QBankPlatformRemoveKeyPressed

 private void List_QBankPlatformKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QBankPlatformKeyReleased
  PNav.onKey_List(this, List_QBankPlatform, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QContactTypeAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QBankPlatform)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QBankPlatformAdd)));
 }//GEN-LAST:event_List_QBankPlatformKeyReleased

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_CatAdd;
 private javax.swing.JButton Btn_CatEdit;
 private javax.swing.JButton Btn_CatRefresh;
 private javax.swing.JButton Btn_CatRemove;
 private javax.swing.JButton Btn_Choose;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FCatBefore;
 private javax.swing.JButton Btn_FCatNext;
 private javax.swing.JButton Btn_FindBefore;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_MultipleSubjectsCategoryAdd;
 private javax.swing.JButton Btn_MultipleSubjectsCategoryRemove;
 private javax.swing.JButton Btn_MultipleSubjectsItemAdd;
 private javax.swing.JButton Btn_MultipleSubjectsItemRemove;
 private javax.swing.JButton Btn_MultipleSubjectsPicAdd;
 private javax.swing.JButton Btn_MultipleSubjectsPicRemove;
 private javax.swing.JButton Btn_MultipleSubjectsTagAdd;
 private javax.swing.JButton Btn_MultipleSubjectsTagRemove;
 private javax.swing.JButton Btn_New;
 private javax.swing.JButton Btn_QBankPlatformAdd;
 private javax.swing.JButton Btn_QBankPlatformRemove;
 private javax.swing.JButton Btn_QCatAdd;
 private javax.swing.JButton Btn_QCatRemove;
 private javax.swing.JButton Btn_QCityAdd;
 private javax.swing.JButton Btn_QCityRemove;
 private javax.swing.JButton Btn_QContactTypeAdd;
 private javax.swing.JButton Btn_QContactTypeRemove;
 private javax.swing.JButton Btn_QPicAdd;
 private javax.swing.JButton Btn_QPicRemove;
 private javax.swing.JButton Btn_QSupAdd;
 private javax.swing.JButton Btn_QSupRemove;
 private javax.swing.JButton Btn_QTagAdd;
 private javax.swing.JButton Btn_QTagRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_QueryRefresh;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Report;
 private javax.swing.JButton Btn_SubAccountAdd;
 private javax.swing.JButton Btn_SubAccountEdit;
 private javax.swing.JButton Btn_SubAccountRemove;
 private javax.swing.JButton Btn_SubAddressAdd;
 private javax.swing.JButton Btn_SubAddressEdit;
 private javax.swing.JButton Btn_SubAddressRemove;
 private javax.swing.JButton Btn_SubCategoryAdd;
 private javax.swing.JButton Btn_SubCategoryRemove;
 private javax.swing.JButton Btn_SubContactAdd;
 private javax.swing.JButton Btn_SubContactEdit;
 private javax.swing.JButton Btn_SubContactRemove;
 private javax.swing.JButton Btn_SubPictureAdd;
 private javax.swing.JButton Btn_SubPictureRemove;
 private javax.swing.JButton Btn_SubjectTagAdd;
 private javax.swing.JButton Btn_SubjectTagRemove;
 private javax.swing.JButton Btn_SuppActiveAdd;
 private javax.swing.JButton Btn_SuppActiveRemove;
 private javax.swing.JButton Btn_SuppAdd;
 private javax.swing.JButton Btn_SuppEdit;
 private javax.swing.JButton Btn_SuppFindBef;
 private javax.swing.JButton Btn_SuppFindNext;
 private javax.swing.JButton Btn_SuppRemove;
 private javax.swing.JButton Btn_SuppTempListAdd;
 private javax.swing.JButton Btn_SuppTempListRemove;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListAddByCategory;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListRemoveByCategory;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JButton Btn_TransInFindBef;
 private javax.swing.JButton Btn_TransInFindNext;
 private javax.swing.JButton Btn_TransInItemTempListAdd;
 private javax.swing.JButton Btn_TransInItemTempListRemove;
 private javax.swing.JButton Btn_TransInSalesmanInfo;
 private javax.swing.JButton Btn_TransInSalesmanTempListAdd;
 private javax.swing.JButton Btn_TransInSalesmanTempListRemove;
 private javax.swing.JButton Btn_TransInSubjectInfo;
 private javax.swing.JButton Btn_TransInSubjectTempListAdd;
 private javax.swing.JButton Btn_TransInSubjectTempListRemove;
 private javax.swing.JButton Btn_TransInTransInfo;
 private javax.swing.JButton Btn_TransInTransTempListAdd;
 private javax.swing.JButton Btn_TransInTransTempListRemove;
 private javax.swing.JButton Btn_TransItemInfo;
 private javax.swing.JButton Btn_TransOutFindBef;
 private javax.swing.JButton Btn_TransOutFindNext;
 private javax.swing.JButton Btn_TransOutItemTempListAdd;
 private javax.swing.JButton Btn_TransOutItemTempListRemove;
 private javax.swing.JButton Btn_TransOutSalesmanInfo;
 private javax.swing.JButton Btn_TransOutSalesmanTempListAdd;
 private javax.swing.JButton Btn_TransOutSalesmanTempListRemove;
 private javax.swing.JButton Btn_TransOutSubjectInfo;
 private javax.swing.JButton Btn_TransOutSubjectTempListAdd;
 private javax.swing.JButton Btn_TransOutSubjectTempListRemove;
 private javax.swing.JButton Btn_TransOutTransInfo;
 private javax.swing.JButton Btn_TransOutTransTempListAdd;
 private javax.swing.JButton Btn_TransOutTransTempListRemove;
 private javax.swing.JToggleButton CB_AccViewBankPlatform;
 private javax.swing.JToggleButton CB_AccViewComment;
 private javax.swing.JToggleButton CB_AddrViewCity;
 private javax.swing.JToggleButton CB_AddrViewComment;
 private javax.swing.JToggleButton CB_ContViewComment;
 private javax.swing.JToggleButton CB_ContViewContactType;
 private javax.swing.JCheckBox CB_QAddress;
 private javax.swing.JCheckBox CB_QBankAccount;
 private javax.swing.JCheckBox CB_QBankPlatform;
 private javax.swing.JCheckBox CB_QBankPlatformUndefined;
 private javax.swing.JCheckBox CB_QBirthDate;
 private javax.swing.JCheckBox CB_QCat;
 private javax.swing.JCheckBox CB_QCatNon;
 private javax.swing.JCheckBox CB_QCity;
 private javax.swing.JCheckBox CB_QCityUndefined;
 private javax.swing.JCheckBox CB_QComment;
 private javax.swing.JCheckBox CB_QContact;
 private javax.swing.JCheckBox CB_QContactType;
 private javax.swing.JCheckBox CB_QContactTypeUndefined;
 private javax.swing.JCheckBox CB_QName;
 private javax.swing.JCheckBox CB_QPic;
 private javax.swing.JCheckBox CB_QPicNon;
 private javax.swing.JCheckBox CB_QSup;
 private javax.swing.JCheckBox CB_QSupNon;
 private javax.swing.JCheckBox CB_QTag;
 private javax.swing.JCheckBox CB_QTagNon;
 private javax.swing.JCheckBox CB_SuppInfoActive;
 private javax.swing.JToggleButton CB_SuppViewBuyComment;
 private javax.swing.JToggleButton CB_SuppViewBuyPrc;
 private javax.swing.JToggleButton CB_SuppViewBuyUpdate;
 private javax.swing.JToggleButton CB_SuppViewCategorized;
 private javax.swing.JToggleButton CB_TransInDate;
 private javax.swing.JToggleButton CB_TransInId;
 private javax.swing.JToggleButton CB_TransInIdExternal;
 private javax.swing.JToggleButton CB_TransInItem;
 private javax.swing.JToggleButton CB_TransInItemComment;
 private javax.swing.JToggleButton CB_TransInItemStockUnit;
 private javax.swing.JToggleButton CB_TransInPriceTotal;
 private javax.swing.JToggleButton CB_TransInPriceUnit;
 private javax.swing.JToggleButton CB_TransInSalesman;
 private javax.swing.JToggleButton CB_TransInSubject;
 private javax.swing.JToggleButton CB_TransInType;
 private javax.swing.JToggleButton CB_TransOutDate;
 private javax.swing.JToggleButton CB_TransOutId;
 private javax.swing.JToggleButton CB_TransOutIdExternal;
 private javax.swing.JToggleButton CB_TransOutItem;
 private javax.swing.JToggleButton CB_TransOutItemComment;
 private javax.swing.JToggleButton CB_TransOutItemStockUnit;
 private javax.swing.JToggleButton CB_TransOutPriceBasic;
 private javax.swing.JToggleButton CB_TransOutPriceTotal;
 private javax.swing.JToggleButton CB_TransOutPriceUnit;
 private javax.swing.JToggleButton CB_TransOutSalesman;
 private javax.swing.JToggleButton CB_TransOutSubject;
 private javax.swing.JToggleButton CB_TransOutType;
 private javax.swing.JComboBox<String> CmB_CatQueryType;
 private javax.swing.JComboBox<String> CmB_QBirthEndDay;
 private javax.swing.JComboBox<String> CmB_QBirthEndMonth;
 private javax.swing.JComboBox<String> CmB_QBirthStartDay;
 private javax.swing.JComboBox<String> CmB_QBirthStartMonth;
 private javax.swing.JComboBox<String> CmB_ReportType;
 private javax.swing.JComboBox<String> CmB_ResultFilterSubset;
 private javax.swing.JComboBox<String> CmB_SuppFind;
 private javax.swing.JComboBox<String> CmB_TransInFind;
 private javax.swing.JComboBox<String> CmB_TransItem;
 private javax.swing.JComboBox<String> CmB_TransOutFind;
 private javax.swing.JComboBox<String> CmB_TransType;
 private XImgBoxURL ImgBox_TransInInfoItemPic;
 private XImgBoxURL ImgBox_TransOutInfoItemPic;
 private javax.swing.JLabel Lbl_MultipleSelection;
 private javax.swing.JLabel Lbl_QAddressHelp;
 private javax.swing.JLabel Lbl_QBankAccountHelp;
 private javax.swing.JLabel Lbl_QBirthDateHelp;
 private javax.swing.JLabel Lbl_QCommentHelp;
 private javax.swing.JLabel Lbl_QContactHelp;
 private javax.swing.JLabel Lbl_QNameHelp;
 private XList List_Category;
 private XList List_QBankPlatform;
 private XList List_QCat;
 private XList List_QCity;
 private XList List_QContactType;
 private XList List_QPic;
 private XList List_QTag;
 private XList List_SubCategory;
 private XList List_SubPicture;
 private XList List_SubTag;
 private XTable List_Subject;
 private javax.swing.JPanel Panel_CategorizedView;
 private XImgBoxURL Panel_Image;
 private javax.swing.JPanel Panel_Query;
 private javax.swing.JPanel Panel_SubjectContact;
 private javax.swing.JPanel Panel_SubjectDetail;
 private javax.swing.JPanel Panel_SubjectEtc;
 private javax.swing.JPanel Panel_SubjectPicture;
 private javax.swing.JPanel Panel_SubjectSupp;
 private javax.swing.JPanel Panel_Trans;
 private javax.swing.JPanel Panel_TransIn;
 private javax.swing.JPanel Panel_TransOut;
 private XImgBoxURL Pnl_InfoPreview;
 private XImgBoxURL Pnl_SuppInfoPreview;
 private javax.swing.JRadioButton RB_TransIsPreTransN;
 private javax.swing.JRadioButton RB_TransIsPreTransY;
 private javax.swing.ButtonGroup RG_Query;
 private javax.swing.ButtonGroup RG_QueryBy;
 private javax.swing.ButtonGroup RG_TransIsPreTrans;
 private javax.swing.JScrollPane SPList_Subject;
 private javax.swing.JTextArea TA_DetComment;
 private javax.swing.JTextArea TA_InfoBio;
 private javax.swing.JTextArea TA_SubAddress;
 private javax.swing.JTextArea TA_SubBankAccount;
 private javax.swing.JTextArea TA_SubContact;
 private javax.swing.JTextArea TA_SuppInfoBuy;
 private javax.swing.JTextArea TA_SuppInfoName;
 private javax.swing.JTextArea TA_TransInInfoItemCategory;
 private javax.swing.JTextArea TA_TransInInfoItemIdName;
 private javax.swing.JTextArea TA_TransOutInfoItemCategory;
 private javax.swing.JTextArea TA_TransOutInfoItemIdName;
 private javax.swing.JTextField TF_CatCount;
 private javax.swing.JTextField TF_CategoryCheckedCount;
 private javax.swing.JTextField TF_DetBirthday;
 private javax.swing.JTextField TF_DetName;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_FindCategory;
 private javax.swing.JTextField TF_QAddress;
 private javax.swing.JTextField TF_QBankAccount;
 private javax.swing.JTextField TF_QBirthEndYear;
 private javax.swing.JTextField TF_QBirthStartYear;
 private javax.swing.JTextField TF_QComment;
 private javax.swing.JTextField TF_QContact;
 private javax.swing.JTextField TF_QName;
 private javax.swing.JTextField TF_QueryCount;
 private javax.swing.JTextField TF_QueryTempListCount;
 private javax.swing.JTextField TF_SubBankPlatform;
 private javax.swing.JTextField TF_SubCity;
 private javax.swing.JTextField TF_SubContactType;
 private javax.swing.JTextField TF_SuppFind;
 private javax.swing.JTextField TF_SuppInfoCategory;
 private javax.swing.JTextField TF_TempListQuantity;
 private javax.swing.JTextField TF_TransInFind;
 private javax.swing.JTextField TF_TransOutFind;
 private javax.swing.JTabbedPane TabbedPane;
 private javax.swing.JTabbedPane TabbedPane_TransList;
 private XTable Tbl_Acc;
 private XTable Tbl_Addr;
 private XTable Tbl_Cont;
 private XTable Tbl_QSup;
 private XTable Tbl_Supp;
 private XTable Tbl_TransIn;
 private XTable Tbl_TransOut;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel12;
 private javax.swing.JLabel jLabel13;
 private javax.swing.JLabel jLabel14;
 private javax.swing.JLabel jLabel15;
 private javax.swing.JLabel jLabel16;
 private javax.swing.JLabel jLabel17;
 private javax.swing.JLabel jLabel18;
 private javax.swing.JLabel jLabel19;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel20;
 private javax.swing.JLabel jLabel21;
 private javax.swing.JLabel jLabel22;
 private javax.swing.JLabel jLabel23;
 private javax.swing.JLabel jLabel24;
 private javax.swing.JLabel jLabel25;
 private javax.swing.JLabel jLabel26;
 private javax.swing.JLabel jLabel27;
 private javax.swing.JLabel jLabel28;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel16;
 private javax.swing.JPanel jPanel17;
 private javax.swing.JPanel jPanel18;
 private javax.swing.JPanel jPanel19;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel20;
 private javax.swing.JPanel jPanel21;
 private javax.swing.JPanel jPanel22;
 private javax.swing.JPanel jPanel23;
 private javax.swing.JPanel jPanel24;
 private javax.swing.JPanel jPanel25;
 private javax.swing.JPanel jPanel26;
 private javax.swing.JPanel jPanel27;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane12;
 private javax.swing.JScrollPane jScrollPane13;
 private javax.swing.JScrollPane jScrollPane14;
 private javax.swing.JScrollPane jScrollPane15;
 private javax.swing.JScrollPane jScrollPane16;
 private javax.swing.JScrollPane jScrollPane17;
 private javax.swing.JScrollPane jScrollPane18;
 private javax.swing.JScrollPane jScrollPane19;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane20;
 private javax.swing.JScrollPane jScrollPane21;
 private javax.swing.JScrollPane jScrollPane22;
 private javax.swing.JScrollPane jScrollPane23;
 private javax.swing.JScrollPane jScrollPane24;
 private javax.swing.JScrollPane jScrollPane25;
 private javax.swing.JScrollPane jScrollPane26;
 private javax.swing.JScrollPane jScrollPane27;
 private javax.swing.JScrollPane jScrollPane29;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 // End of variables declaration//GEN-END:variables
}
