public class CPrint {

 // java.awt.print.Paper's basic unit measurement: 1 coordinate = 1/72 inch
 
 /*
  > A4 paper (all unit in mm)
  |  width  |  height |  left   |  right  |  top    |  bottom |
  |  210    |  297    |  20     |  15     |  10     |  15     |
  > A5 paper (all unit in mm)
  |  width  |  height |  left   |  right  |  top    |  bottom |
  |  148    |  210    |  20     |  15     |  10     |  15     |
  > A6 paper (all unit in mm)
  |  width  |  height |  left   |  right  |  top    |  bottom |
  |  105    |  148    |  7      |  7      |  10     |  15     |
  > thermal roll paper various-width (all unit in mm)
  |  width  |  height |  left   |  right  |  top    |  bottom |
  |  --     |  210    |  7      |  6      |  19     |  6      |
 
  > A4-Half paper (all unit in mm)
  |  width  |  height |  left   |  right  |  top    |  bottom |
  |  105    |  297    |  7      |  7      |  7      |  7      |
 */
 
 public static final int AllOrientation=0;
 public static final int PortraitOrientation=1;
 public static final int LandscapeOrientation=2;
 
 public static final double PaperWidthMax=OUnit.mm_to_pixel(450);
 public static final double PaperHeightMax=OUnit.mm_to_pixel(450);
 public static final double PaperWidthToleranceDefault=OUnit.mm_to_pixel(30);
 public static final double PaperHeightToleranceDefault=OUnit.mm_to_pixel(30);
 
 public static final double ThermalPaperMarginTopDefault=OUnit.mm_to_pixel(22);
 public static final double ThermalPaperMarginTopMin=OUnit.mm_to_pixel(0);
 public static final double ThermalPaperMarginTopMax=OUnit.mm_to_pixel(35);
 public static final double ThermalPaperMarginBottomDefault=OUnit.mm_to_pixel(6);
 public static final double ThermalPaperMarginBottomMin=OUnit.mm_to_pixel(0);
 public static final double ThermalPaperMarginBottomMax=OUnit.mm_to_pixel(35);
 public static final double ThermalPaperMarginLeftDefault=OUnit.mm_to_pixel(7);
 public static final double ThermalPaperMarginLeftMin=OUnit.mm_to_pixel(0);
 public static final double ThermalPaperMarginLeftMax=OUnit.mm_to_pixel(25);
 public static final double ThermalPaperMarginRightDefault=OUnit.mm_to_pixel(6);
 public static final double ThermalPaperMarginRightMin=OUnit.mm_to_pixel(0);
 public static final double ThermalPaperMarginRightMax=OUnit.mm_to_pixel(25);
 
 public static final double StandardPaperMarginTopDefault=OUnit.mm_to_pixel(10);
 public static final double StandardPaperMarginTopMin=OUnit.mm_to_pixel(0);
 public static final double StandardPaperMarginTopMax=OUnit.mm_to_pixel(35);
 public static final double StandardPaperMarginBottomDefault=OUnit.mm_to_pixel(15);
 public static final double StandardPaperMarginBottomMin=OUnit.mm_to_pixel(0);
 public static final double StandardPaperMarginBottomMax=OUnit.mm_to_pixel(35);
 public static final double StandardPaperMarginLeftDefault=OUnit.mm_to_pixel(20);
 public static final double StandardPaperMarginLeftMin=OUnit.mm_to_pixel(0);
 public static final double StandardPaperMarginLeftMax=OUnit.mm_to_pixel(25);
 public static final double StandardPaperMarginRightDefault=OUnit.mm_to_pixel(15);
 public static final double StandardPaperMarginRightMin=OUnit.mm_to_pixel(0);
 public static final double StandardPaperMarginRightMax=OUnit.mm_to_pixel(25);
 
 // Paper A (1xxx)
 public static OPaper A4 = createStandardPaper(1001, "A4", 210, 297, 20, 15, 10, 15);
 public static OPaper A5 = createStandardPaper(1002, "A5", 148, 210, 20, 15, 10, 15);
 public static OPaper A6 = createStandardPaper(1003, "A6", 105, 148, 7, 7, 10, 15);
 
 // Paper Thermal (2xxx)
 public static OPaper Thermal57 = createThermalPaper(2057, 57, 210, 5, 6, 22, 6);
 public static OPaper Thermal60 = createThermalPaper(2060, 60, 210, 7, 6, 22, 6);
 public static OPaper Thermal62 = createThermalPaper(2062, 62, 210, 7, 6, 22, 6);
 public static OPaper Thermal65 = createThermalPaper(2065, 65, 210, 7, 6, 22, 6);
 public static OPaper Thermal67 = createThermalPaper(2067, 67, 210, 7, 6, 22, 6);
 public static OPaper Thermal70 = createThermalPaper(2070, 70, 210, 7, 6, 22, 6);
 public static OPaper Thermal72 = createThermalPaper(2072, 72, 210, 7, 6, 22, 6);
 public static OPaper Thermal75 = createThermalPaper(2075, 75, 210, 7, 6, 22, 6);
 public static OPaper Thermal77 = createThermalPaper(2077, 77, 210, 7, 6, 22, 6);
 public static OPaper Thermal80 = createThermalPaper(2080, 80, 210, 7, 6, 22, 6);
 public static OPaper Thermal100 = createThermalPaper(2100, 100, 250, 7, 6, 22, 6);
 public static OPaper Thermal102 = createThermalPaper(2102, 102, 250, 7, 6, 22, 6);
 public static OPaper Thermal105 = createThermalPaper(2105, 105, 250, 7, 6, 22, 6);
 public static OPaper Thermal107 = createThermalPaper(2107, 107, 250, 7, 6, 22, 6);
 public static OPaper Thermal110 = createThermalPaper(2110, 110, 250, 7, 6, 22, 6);
 public static OPaper Thermal112 = createThermalPaper(2112, 112, 250, 7, 6, 22, 6);
 public static OPaper Thermal115 = createThermalPaper(2115, 115, 250, 7, 6, 22, 6);
 public static OPaper Thermal117 = createThermalPaper(2117, 117, 250, 7, 6, 22, 6);
 public static OPaper Thermal120 = createThermalPaper(2120, 120, 250, 7, 6, 22, 6);
 
 // Paper Self-Adhesive Sticker
 
 
 // Custom Size (9xxx)
 public static OPaper A4Half = createStandardPaper(9001, "A4-Half", 105, 297, 7, 7, 7, 7);
 
 public static OPaper createThermalPaper(int Id, double Width, double Height,
  double LeftMargin, double RightMargin, double TopMargin, double BottomMargin){
  return OPaper.createPaper(Id, "Thermal "+PText.priceToString(Width)+" mm", "", true, null, null, null,
   OUnit.mm_to_pixel(Width), OUnit.mm_to_pixel(Height),
   OUnit.mm_to_pixel(LeftMargin), OUnit.mm_to_pixel(RightMargin),
   OUnit.mm_to_pixel(TopMargin), OUnit.mm_to_pixel(BottomMargin),
   0, 0, 0, 0);
 }
 public static OPaper createStandardPaper(int Id, String Name, double Width, double Height,
  double LeftMargin, double RightMargin, double TopMargin, double BottomMargin){
  return OPaper.createPaper(Id, Name, "("+PText.priceToString(Width)+" X "+PText.priceToString(Height)+" mm)", false, null, null ,null,
   OUnit.mm_to_pixel(Width), OUnit.mm_to_pixel(Height),
   OUnit.mm_to_pixel(LeftMargin), OUnit.mm_to_pixel(RightMargin),
   OUnit.mm_to_pixel(TopMargin), OUnit.mm_to_pixel(BottomMargin),
   0, 0, 0, 0);
 }
 
 public static OPaperMargin getMargin(boolean IsPaperStandard, int MarginMode){
  OPaperMargin ret=null;
  if(IsPaperStandard){
   switch(MarginMode){
    case 1 : ret=new OPaperMargin(StandardPaperMarginTopDefault, StandardPaperMarginBottomDefault, StandardPaperMarginLeftDefault, StandardPaperMarginRightDefault); break;
    case 2 : ret=new OPaperMargin(StandardPaperMarginTopMin, StandardPaperMarginBottomMin, StandardPaperMarginLeftMin, StandardPaperMarginRightMin); break;
    case 3 : ret=new OPaperMargin(StandardPaperMarginTopMax, StandardPaperMarginBottomMax, StandardPaperMarginLeftMax, StandardPaperMarginRightMax); break;
    default : ret=new OPaperMargin(StandardPaperMarginTopDefault, StandardPaperMarginBottomDefault, StandardPaperMarginLeftDefault, StandardPaperMarginRightDefault); break;
   }
  }
  else{
   switch(MarginMode){
    case 1 : ret=new OPaperMargin(ThermalPaperMarginTopDefault, ThermalPaperMarginBottomDefault, ThermalPaperMarginLeftDefault, ThermalPaperMarginRightDefault); break;
    case 2 : ret=new OPaperMargin(ThermalPaperMarginTopMin, ThermalPaperMarginBottomMin, ThermalPaperMarginLeftMin, ThermalPaperMarginRightMin); break;
    case 3 : ret=new OPaperMargin(ThermalPaperMarginTopMax, ThermalPaperMarginBottomMax, ThermalPaperMarginLeftMax, ThermalPaperMarginRightMax); break;
    default : ret=new OPaperMargin(ThermalPaperMarginTopDefault, ThermalPaperMarginBottomDefault, ThermalPaperMarginLeftDefault, ThermalPaperMarginRightDefault); break;
   }
  }
  return ret;
 }

}