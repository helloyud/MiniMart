import java.awt.*;
import java.io.File;
import java.util.Date;
import java.util.Vector;

class test{
 static void tes(Object... Obj){
  String str=null;
  if(Obj!=null){
   str="1";
  }
  System.out.print(str);
 }
 public static void main(String[] args){
  TestShowImage form;
  OLabelCreatorItemPriceTag lbl;
  Font fnt;
  GraphicsEnvironment GraphEnv;
  String RunningDirectory;
  OBarcodePatternizerCode128SetC codegen;
  String b; Object i;
  
  try{
   /*
   RunningDirectory=System.getProperty("user.dir");
   if(RunningDirectory.charAt(RunningDirectory.length()-1)!='\\'){
    RunningDirectory=RunningDirectory+"\\";
   }
   GraphEnv=GraphicsEnvironment.getLocalGraphicsEnvironment();
   fnt=Font.createFont(Font.TRUETYPE_FONT, new File(RunningDirectory+"_lain\\Inconsolata-Regular.ttf"));
   GraphEnv.registerFont(fnt);
   fnt=Font.createFont(Font.TRUETYPE_FONT, new File(RunningDirectory+"_lain\\Inconsolata-Bold.ttf"));
   GraphEnv.registerFont(fnt);
   
   lbl=new OLabelCreatorItemPriceTag();
   lbl.setLabelSize(OUnit.mm_to_pixel(41), OUnit.mm_to_pixel(26));
   lbl.setFont("Inconsolata");
   lbl.generateLayoutVariables();
   lbl.setLabelData(new OLabelDataPriceTag(123456789012345678L,
    "Coca-cola kaleng 550mL", 5500,
    "Beli 3 : Rp 13.500"));
   
   form=new TestShowImage(PGraphics.getImageString("coba", new Font("tahoma", Font.PLAIN, 50), 1), "");
   form.setVisible(true);
   */
   
   // System.out.println(Double.parseDouble("-0000.00"));
   // System.out.println(PText.dateToString(PDate.calculateDateByDay(PDate.generateDate(2019, 2, 30, false), 2, 1), 2));
   System.out.println("");
  }
  catch(Exception E){System.out.println(E.toString());}
 }
}