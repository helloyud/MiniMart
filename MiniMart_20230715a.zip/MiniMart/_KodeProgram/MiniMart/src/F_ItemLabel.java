import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_ItemLabel extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // panel add label
  //
 String Promo;
  // Item
 long CheckedItemId, I_CheckedItemId;
 long LastInputId;
 OInfoItem ItemDet, I_ItemDet;
 boolean InputInfoClearedItem;
  // Qty
 int Qty; double I_Qty;
  //
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 Color Lbl_PromoColor;
 
 // table label
 int PrintAccLabel;
 int AccLabelCount;
 OCustomTableModel TableMdlLabel;
 int LastSelectedRowLabel;
 
 // panel label formats
 OCustomComboBoxModel ComboMdlFormats;
 int LastSelectedRowFormat;
 OCustomComboBoxModel ComboMdlPapers;
 OLabelCreatorItem CurrLabelGen;
 VInteger CurrSelectedRowPaper;
 Vector<OPaper> CustomPaperLabel;
 
 // panel print
 OCustomComboBoxModel ComboMdlPrinters;
 OCustomComboBoxModel ComboMdlFirstPageStartColumn;
 OCustomComboBoxModel ComboMdlFirstPageStartRow;
 OCustomComboBoxModel ComboMdlFirstPageMaxRows;
 SpinnerNumberModel SpinMdlMovePrintHeadH;
 SpinnerNumberModel SpinMdlMovePrintHeadV;
 
 //
 final double LabelScaleFactor=2.5;
 
 public F_ItemLabel(MInterFormVariables IFV_) {
  int temp, length;
  OLabelCreatorItem LabelCreatorItem;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // panel add label
   //
  EnableDocumentListener=new VBoolean(true);
  
  TF_LabelCount.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQty();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQty();
     }
    }
    
   });
  
  EnableDocumentListener.Value=true;
  
  InputInfoClearedItem=true;
  
   //
  I_ItemDet=new OInfoItem();
  Lbl_PromoColor=Lbl_Promo.getForeground();
  
  clearItemId();
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  I_Qty=-1;
  
  // table label
  TableMdlLabel=new OCustomTableModel(true, true, true);
  TableMdlLabel.setColumnsInfo(
   PCore.refArr("Id Barang", "Nama Barang", "Harga Jual", "Komentar", "Label", "File Gambar"),
   PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeInteger, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(6, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(0, 1, 2, 3, 4),
   PCore.primArr(false, false, false, true, true, false));
  Tbl_Label.setModel(TableMdlLabel);
  LastSelectedRowLabel=-1;
  PGUI.resizeTableColumn(Tbl_Label, PCore.primArr(
   CGUI.ColCheck, CGUI.ColNum13, CGUI.ColTextMed+60, CGUI.ColCur09_02, CGUI.ColTextMed-60, CGUI.ColNumSep06));
  Tbl_Label.moveColumn(2, 1);
  Tbl_Label.moveColumn(5, 4);
  updateGUIAccListCount();
  AccLabelCount=0; updateGUIAccLabelCount();
  updateGUIPrintAccList();
  PrintAccLabel=0; updateGUIPrintAccLabel();
  
  Tbl_Label.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableLabel();}
   };
  
  Pnl_LabelItemPicture.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // panel print
  ComboMdlPrinters=new OCustomComboBoxModel();
  ComboMdlPrinters.setColumnsInfo(PCore.primArr(CCore.TypeUnknown, CCore.TypeString), 1);
  CmB_Printers.setModel(ComboMdlPrinters);
  
  ComboMdlFirstPageStartColumn=new OCustomComboBoxModel();
  ComboMdlFirstPageStartColumn.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  CmB_FirstPageStartColumn.setModel(ComboMdlFirstPageStartColumn);
  
  ComboMdlFirstPageStartRow=new OCustomComboBoxModel();
  ComboMdlFirstPageStartRow.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  CmB_FirstPageStartRow.setModel(ComboMdlFirstPageStartRow);
  
  ComboMdlFirstPageMaxRows=new OCustomComboBoxModel();
  ComboMdlFirstPageMaxRows.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  CmB_FirstPageMaxRows.setModel(ComboMdlFirstPageMaxRows);
  
  SpinMdlMovePrintHeadH=new SpinnerNumberModel(0D, -15D, 15D, 0.5D);
  Spin_MovePrintHeadHorizontal.setModel(SpinMdlMovePrintHeadH);
  ((DefaultEditor)Spin_MovePrintHeadHorizontal.getEditor()).getTextField().setEditable(false);
  
  Spin_MovePrintHeadHorizontal.addChangeListener(new ChangeListener(){
    public void stateChanged(ChangeEvent e){fillInfoPrint();}
   });
  
  SpinMdlMovePrintHeadV=new SpinnerNumberModel(0D, -15D, 15D, 0.5D);
  Spin_MovePrintHeadVertical.setModel(SpinMdlMovePrintHeadV);
  ((DefaultEditor)Spin_MovePrintHeadVertical.getEditor()).getTextField().setEditable(false);
  
  Spin_MovePrintHeadVertical.addChangeListener(new ChangeListener(){
    public void stateChanged(ChangeEvent e){refillFirstPageMaxRows(false); fillInfoPrint();}
   });
  
  // panel label format
  CustomPaperLabel=new Vector();
  
  ComboMdlPapers=new OCustomComboBoxModel();
  ComboMdlPapers.setColumnsInfo(PCore.primArr(CCore.TypeUnknown, CCore.TypeInteger, CCore.TypeString), 2);
  CmB_Papers.setModel(ComboMdlPapers);
  
  ComboMdlFormats=new OCustomComboBoxModel();
  // OLabelCreatorItem LabelCreatorItem, String LabelCreatorItem's Name, VInteger LastSelectedPaper
  ComboMdlFormats.setColumnsInfo(PCore.primArr(CCore.TypeUnknown, CCore.TypeString, CCore.TypeUnknown), 1);
  length=IFV.LabelCreatorsItem.size();
  temp=0;
  do{
   LabelCreatorItem=(OLabelCreatorItem)IFV.LabelCreatorsItem.elementAt(temp);
   ComboMdlFormats.append(PCore.objArrVariant(LabelCreatorItem, LabelCreatorItem.Name, new VInteger(-1)));
   temp=temp+1;
  }while(temp!=length);
  CmB_Formats.setModel(ComboMdlFormats);
  CmB_Formats.setSelectedIndex(0); CmB_Formats.repaint();
  
  CB_PrintChoosePage.setSelected(true);
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_AddMultipleLabel, Btn_AddLabel,
    CB_EnterIsAdd, TF_ItemId, Btn_ChooseItem,
    CmB_ItemComment,
    TF_LabelCount,
    CB_InitPromo, TF_Promo,
    
    TF_Find, Tbl_Label),
   PCore.objArrVariant());
  
  // shift + esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, InputEvent.SHIFT_DOWN_MASK, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddLabelActionPerformed(null);
    }
   });
  
  // f4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0, true), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddMultipleLabelActionPerformed(null);
    }
   });
  
  // f7
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0, true), "f7");
  act.put("f7", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f8
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F8, 0, true), "f8");
  act.put("f8", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_PrintActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // cancel table editing
  Tbl_Label.editingCanceled(null);
  
  // add label
  clearInputLabel();
  Lbl_ItemId.setForeground(CGUI.Color_Label_InputRight);
  Lbl_LabelCount.setForeground(CGUI.Color_Label_InputRight);
  Lbl_Promo.setForeground(Lbl_PromoColor);
  
  // table
  Tbl_Label.clearSelection(); onSelectedRowLabelChanged(false);
  
  // panel print
  ComboMdlPrinters.removeAll();
  
  // panel label formats
  CustomPaperLabel.removeAllElements();
 }
 
 //
 void onEditingTableLabel(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=Tbl_Label.Editing_Row;
  Col=TableMdlLabel.convertColumnIndexFromViewToModel(Tbl_Label.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdlLabel.Mdl.ColumnsType[Col], null, Tbl_Label.Editing_ValueOld, true, null, Tbl_Label.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableLabel_Check(Row); break;}
   result=onEditingTableLabel_Data(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableLabel_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  checkPrint(PCore.primArr(Row), PCore.objBoolean(Tbl_Label.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingTableLabel_Data(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  boolean valid;
  OEditLabelItem Edit;
  
  do{
   Edit=new OEditLabelItem();
   valid=true;
   switch(Col){
    // integer not null, positive only, >0
    case 4 : Edit.EditLabelCount=true; Edit.EditedLabelCount=PCore.objInteger(Tbl_Label.Editing_ValueNew, -1); if(Edit.EditedLabelCount<=0){valid=false;} break;
    
    // string null
    case 3 : Edit.EditPromo=true; Edit.EditedPromo=PCore.objString(Tbl_Label.Editing_ValueNew, ""); break;
   }
   if(!valid){ret=-2; break;}

   edit(PCore.primArr(Row), Edit);
  }while(false);
  
  return ret;
 }
 
 
 /* add label methods */
  // Item
 void clearItemId(){
  TF_ItemId.setText(""); LastInputId=-1; I_CheckedItemId=-1; clearItem();
 }
 boolean changeLastInputId(){
  boolean ret=false;
  long Input;
  String str=TF_ItemId.getText();
  
  // convert input in TF_ItemId to number; if input is empty or false, then value it to -1
  Input=-1;
  if(str.length()!=0){
   try{Input=Long.parseLong(str);}catch(Exception E){Input=-1;}
  }
  
  if(Input!=LastInputId){
   ret=true; LastInputId=Input;
  }
  
  return ret;
 }
 void changeItem(boolean FillOtherInputFromItem){
  OInfoItem InfoItem;
  
  InfoItem=PMyShop.getItemInfo(IFV.Stm, LastInputId, false);
  if(InfoItem==null){
   I_CheckedItemId=-1; clearItem();
   if(FillOtherInputFromItem){clearInputFromItem();}
   return;
  }
  
  I_ItemDet=InfoItem;
  I_CheckedItemId=LastInputId;
  
  changeItemQuantityPrice();
  
  setIQty(I_Qty, false);
  fillInputInfoItem();
  
  if(FillOtherInputFromItem){fillInputFromItem();}
 }
 void inputItem(boolean FillOtherInputFromItem){
  if(!changeLastInputId()){return;}
  changeItem(FillOtherInputFromItem);
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
 }
 void fillInputInfoItem(){
  if(I_CheckedItemId==-1){clearInputInfoItem(); return;}
  
  TA_ItemName.setText(I_ItemDet.Name);
  TF_ItemPrice.setText(PText.priceToString(I_ItemDet.SellPrice));
  fillItemComment();
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  TA_ItemName.setText("");
  TF_ItemPrice.setText("");
  TA_ItemComment.setText("");
  
  InputInfoClearedItem=true;
 }
 String getItemComment(){
  String ret=null;
  
  do{
   if(I_CheckedItemId==-1){break;}

   switch(CmB_ItemComment.getSelectedIndex()){
    case 0 : ret=I_ItemDet.Comment; break;
    case 1 : if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){ret=I_ItemDet.BuyPriceComment;} break;
    case 2 : ret=I_ItemDet.SellPriceComment; break;
   }
  }while(false);
  
  return PText.getString(ret, "", false);
 }
 void fillItemComment(){
  TA_ItemComment.setText(getItemComment());
 }
 void clearItem(){
  clearInputInfoItem();
  
  clearInputFromItem();
 }
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_LabelCount, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_LabelCount, "");}}
 }
 void inputQty(){
  I_Qty=PText.parseDouble(TF_LabelCount.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}
  
  if(I_Qty<=0){return;}
 }
 int getLabelCount(){
  int US_Qty; // unit standard's quantity
  
  US_Qty=PMath.round(I_Qty, 1); if(US_Qty<=0){US_Qty=1;}
  
  return US_Qty;
 }
  // Promo
 void fillPromo(){
  String str;
  
  if(I_CheckedItemId==-1){return;}
  
  str=null; if(CB_InitPromo.isSelected()){str=getItemComment();}
  TF_Promo.setText(PText.singleLine(PText.getString(str, "", false), '~'));
 }
  // Others
 void clearInputLabel(){
  clearItemId();
  setIQty(-1, true);
  TF_Promo.setText("");
 }
 void fillInputFromItem(){
  if(I_CheckedItemId==-1){return;}
  fillPromo();
 }
 void clearInputFromItem(){
  
 }
 void fillInputVariablesIntoRealVariables(){
  CheckedItemId=I_CheckedItemId;
  ItemDet=I_ItemDet;
  
  Qty=getLabelCount();
 }
 int findInsertPosition(String ItemName){
  int ret=0;
  int tblcount=TableMdlLabel.Mdl.Rows.size();
  
  if(tblcount!=0){
   do{
    if(PText.grading(ItemName, (String)TableMdlLabel.Mdl.Rows.elementAt(ret)[1], false)==1){
     break;
    }
    ret=ret+1;
   }while(ret!=tblcount);
  }
  return ret;
 }
 
 
 /* table methods */
 void clearTable(){
  TableMdlLabel.removeAll();
  updateGUIAccListCount();
  AccLabelCount=0; updateGUIAccLabelCount();
  updateGUIPrintAccList();
  PrintAccLabel=0; updateGUIPrintAccLabel();
  onSelectedRowLabelChanged(true);
  
  fillInfoPrint();
 }
 void onSelectedRowLabelChanged(boolean UpdateAnyway){
  int Row=Tbl_Label.getSelectedRow();
  
  if(Row==LastSelectedRowLabel && !UpdateAnyway){return;}
   
  LastSelectedRowLabel=Row;

  changeLabelFillInfoLabel(Row);
  changeLabelFillPanelLabelFormat(Row);
 }
 void changeLabelFillInfoLabel(int RowLabel){
  if(RowLabel==-1){clearInfoLabel(); return;}
  fillInfoLabel(RowLabel);
 }
 void fillInfoLabel(int RowLabel){
  Object[] Objs=TableMdlLabel.Mdl.Rows.elementAt(RowLabel);
  String str;
  str=(String)Objs[3]; if(str.length()!=0){str=" { "+str+" }";}
  TA_LabelInfo.setText("( "+PText.separate(Objs[0].toString(), " - ", 5)+" ) "+(String)Objs[1]+str);
  
  PGUI.fillPanelPictureURL(Pnl_LabelItemPicture, IFV.Conf.ImageDirItem, Objs[5]);
 }
 void clearInfoLabel(){
  TA_LabelInfo.setText("");
  
  PGUI.fillPanelPictureURL(Pnl_LabelItemPicture, IFV.Conf.ImageDirItem, null);
 }
 void changeLabelFillPanelLabelFormat(int RowLabel){
  changeLabelData(RowLabel);
  refreshImage();
 }
 void updateGUIAccListCount(){TF_AccListCount.setText("( "+PText.intToString(TableMdlLabel.Mdl.Rows.size())+" )");}
 void updateGUIAccLabelCount(){TF_AccLabelCount.setText(PText.intToString(AccLabelCount));}
 void updateGUIPrintAccList(){TF_PrintAccList.setText("( "+PText.intToString(TableMdlLabel.Mdl.CheckedCount)+" )");}
 void updateGUIPrintAccLabel(){TF_PrintAccLabel.setText(PText.intToString(PrintAccLabel));}
 void checkPrint(int[] SelectedIndex, boolean Chk){
  int[] rows;
  
  if(SelectedIndex.length==0){return;}
  
  rows=TableMdlLabel.setChecked(SelectedIndex, Chk);
  if(rows.length==0){return;}
  
  addPrint(rows.length, ((Long)PGUI.sumColumns(TableMdlLabel, PCore.primArr(4), rows)[0]).intValue(), Chk);
 }
 void addPrint(int ListCount, int LabelCount, boolean IsAdd){
  int sign;
  sign=1; if(!IsAdd){sign=-1;}
  PrintAccLabel=PrintAccLabel+sign*LabelCount;
  updateGUIPrintAccList();
  updateGUIPrintAccLabel();
  
  fillInfoPrint();
 }
 void addAcc(int ListCount, int LabelCount, boolean IsAdd){
  int sign;
  sign=1; if(!IsAdd){sign=-1;}
  AccLabelCount=AccLabelCount+sign*LabelCount;
  updateGUIAccListCount();
  updateGUIAccLabelCount();
 }
 
 /* panel label format methods */
 void onSelectedRowFormatChanged(boolean UpdateAnyway){
  int RowFormat=CmB_Formats.getSelectedIndex();
  Object[] RowData;
  
  if(RowFormat==LastSelectedRowFormat && !UpdateAnyway){return;}
  
  LastSelectedRowFormat=RowFormat;
  
  RowData=ComboMdlFormats.Mdl.Rows.elementAt(RowFormat);
  
  CurrLabelGen=(OLabelCreatorItem)RowData[0];
  changeLabelData(Tbl_Label.getSelectedRow());
  
  refillPapers(RowFormat);
 }
 void onSelectedRowPaperChanged(boolean UpdateAnyway){
  int RowPaper=CmB_Papers.getSelectedIndex();
  
  if(RowPaper==CurrSelectedRowPaper.Value && !UpdateAnyway){return;}
  CurrSelectedRowPaper.Value=RowPaper;

  changePaperLabelGen(CurrLabelGen, ComboMdlPapers, CurrSelectedRowPaper.Value);
  changePaperGUI();
  refreshImage();
  
  fillInfoPrint();
 }
 void refreshImage(){
  ImgBox_Label.setImageSource(CurrLabelGen.createBufferedImage(LabelScaleFactor));
 }
 void refillPapers(int RowFormat){
  Object[] RowData=ComboMdlFormats.Mdl.Rows.elementAt(RowFormat);
  OLabelCreatorItem LabelCreatorItem=(OLabelCreatorItem)RowData[0];
  Vector<OPaper> SupportedCustomPapers;
  OPaperLabel Paper;
  int temp, custompaper_length, filledcustompaper_length, filledinternalpaper_length, combomdlpapers_length, definerow;
  
  ComboMdlPapers.removeAll();
  
  SupportedCustomPapers=new Vector();
  custompaper_length=CustomPaperLabel.size();
  if(custompaper_length!=0){
   temp=0;
   do{
    Paper=(OPaperLabel)CustomPaperLabel.elementAt(temp);
    if(LabelCreatorItem.acceptPaper(Paper)){SupportedCustomPapers.addElement(Paper);}
    temp=temp+1;
   }while(temp!=custompaper_length);
  }
  PPrint.fillPapers(ComboMdlPapers, SupportedCustomPapers);
  filledcustompaper_length=ComboMdlPapers.Mdl.Rows.size();
  
  PPrint.fillPapers(ComboMdlPapers, LabelCreatorItem.InternalPapers);
  filledinternalpaper_length=ComboMdlPapers.Mdl.Rows.size()-filledcustompaper_length;
  
  CurrSelectedRowPaper=(VInteger)RowData[2];
  
  definerow=-1;
  combomdlpapers_length=filledcustompaper_length+filledinternalpaper_length;
  if(combomdlpapers_length!=0){
   do{
    definerow=CurrSelectedRowPaper.Value; if(definerow>=0 && definerow<=combomdlpapers_length-1){break;}
    definerow=filledcustompaper_length+LabelCreatorItem.DefaultInternalPaper; if(definerow>=0 && definerow<=combomdlpapers_length-1){break;}
    definerow=0;
   }while(false);
  }
  CmB_Papers.setSelectedIndex(definerow); CmB_Papers.repaint();
  onSelectedRowPaperChanged(true);
 }
 void changePaperLabelGen(OLabelCreatorItem LabelGen, OCustomComboBoxModel PaprMdl, int PaprMdlSelectedIndex){
  OPaperLabel Papr;
  Papr=null; if(PaprMdlSelectedIndex!=-1){Papr=(OPaperLabel)PaprMdl.Mdl.Rows.elementAt(PaprMdlSelectedIndex)[0];}
  LabelGen.setPaper(Papr); LabelGen.generateLayoutVariables();
 }
 void changePaperGUI(){
  fillPaperDescription(Lbl_PaperDescription, ComboMdlPapers, CurrSelectedRowPaper.Value);
  refillFirstPage(ComboMdlFirstPageStartRow, CmB_FirstPageStartRow, ComboMdlFirstPageStartColumn, CmB_FirstPageStartColumn, ComboMdlFirstPageMaxRows, CmB_FirstPageMaxRows, ComboMdlPapers, CurrSelectedRowPaper.Value);
 }
 void fillPaperDescription(JLabel Lbl_Desc, OCustomComboBoxModel PaprMdl, int PaprMdlSelectedIndex){
  OPaperLabel Papr;
  String str;
  
  // describe "label specification on a paper label"
  if(PaprMdlSelectedIndex==-1){str="-";}
  else{
   Papr=(OPaperLabel)PaprMdl.Mdl.Rows.elementAt(PaprMdlSelectedIndex)[0];
   str=PText.intToString(Papr.ColumnCount)+" kolom"+" & "+PText.intToString(Papr.RowCount)+" baris"+" "+
    "( @ "+PText.priceToString(OUnit.pixel_to_mm(Papr.LabelWidth))+" X "+PText.priceToString(OUnit.pixel_to_mm(Papr.LabelHeight))+" mm )";
  }
  Lbl_Desc.setText(str);
 }
 void refillFirstPage(
  OCustomComboBoxModel FirstPageStartRowMdl, JComboBox FirstPageStartRowGUI,
  OCustomComboBoxModel FirstPageStartColumnMdl, JComboBox FirstPageStartColumnGUI,
  OCustomComboBoxModel FirstPageMaxRowsMdl, JComboBox FirstPageMaxRowsGUI,
  OCustomComboBoxModel PaprMdl, int PaprMdlSelectedIndex){
  int lastselection, defineselection, count;
  OPaperLabel Papr;
  
  Papr=null; if(PaprMdlSelectedIndex!=-1){Papr=(OPaperLabel)PaprMdl.Mdl.Rows.elementAt(PaprMdlSelectedIndex)[0];}
  
  lastselection=FirstPageStartRowGUI.getSelectedIndex();
  FirstPageStartRowMdl.removeAll();
  defineselection=-1;
  if(PaprMdlSelectedIndex!=-1){
   count=Papr.RowCount; if(Papr.IsRollPaper){count=1;}
   if(count!=0){
    PGUI.fillNumberToComboBox(FirstPageStartRowMdl, 1, count, "", "");
    if(lastselection!=-1 && lastselection<=count-1){defineselection=lastselection;}else{defineselection=0;}
   }
  }
  FirstPageStartRowGUI.setSelectedIndex(defineselection); FirstPageStartRowGUI.repaint();
  
  lastselection=FirstPageStartColumnGUI.getSelectedIndex();
  FirstPageStartColumnMdl.removeAll();
  defineselection=-1;
  if(PaprMdlSelectedIndex!=-1){
   count=Papr.ColumnCount;
   if(count!=0){
    PGUI.fillNumberToComboBox(FirstPageStartColumnMdl, 1, count, "", "");
    if(lastselection!=-1 && lastselection<=count-1){defineselection=lastselection;}else{defineselection=0;}
   }
  }
  FirstPageStartColumnGUI.setSelectedIndex(defineselection); FirstPageStartColumnGUI.repaint();
  
  refillFirstPageMaxRows(true);
 }
 void refillFirstPageMaxRows(boolean SetSelectedIndexToTheLastRow){
  OCustomComboBoxModel PaprMdl=ComboMdlPapers;
  int PaprMdlSelectedIndex=CmB_Papers.getSelectedIndex();
  OCustomComboBoxModel FirstPageMaxRowsMdl=ComboMdlFirstPageMaxRows;
  JComboBox FirstPageMaxRowsGUI=CmB_FirstPageMaxRows;
  double MoveImageableY=OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadV.getValue(), 0));
  
  int lastselection, defineselection, temp, count, rowcount;
  OPaperLabel Papr;
  Object[] Obj;
  
  Papr=null; if(PaprMdlSelectedIndex!=-1){Papr=(OPaperLabel)PaprMdl.Mdl.Rows.elementAt(PaprMdlSelectedIndex)[0];}
  
  lastselection=FirstPageMaxRowsGUI.getSelectedIndex();
  FirstPageMaxRowsMdl.removeAll();
  defineselection=-1;
  if(PaprMdlSelectedIndex!=-1){
   count=Papr.RowCount; if(Papr.IsRollPaper){count=1;}
   if(count!=0){
    temp=0;
    do{
     rowcount=temp+1;
     Obj=PCore.objArrVariant(PText.intToString(rowcount)+"  ("+PText.priceToString(OUnit.pixel_to_mm(calculatePaperSizeMinimalHeight(Papr, MoveImageableY, rowcount)))+" mm)");
     FirstPageMaxRowsMdl.Mdl.Rows.addElement(Obj);
     temp=temp+1;
    }while(temp!=count);
    FirstPageMaxRowsMdl.refreshInsert(0, count-1);
    
    if(SetSelectedIndexToTheLastRow){defineselection=count-1;}
    else{
     if(lastselection!=-1 && lastselection<=count-1){defineselection=lastselection;}else{defineselection=count-1;}
    }
    
   }
  }
  FirstPageMaxRowsGUI.setSelectedIndex(defineselection); FirstPageMaxRowsGUI.repaint();
 }
 void changeLabelData(int RowLabel){
  OLabelData LabelData;
  Object[] RowData;
  
  LabelData=null;
  if(RowLabel!=-1){
   RowData=TableMdlLabel.Mdl.Rows.elementAt(RowLabel);
   LabelData=new OLabelDataItem((Long)RowData[0], (String)RowData[1], (Double)RowData[2], (String)RowData[3]);
  }
  CurrLabelGen.setLabelData(LabelData);
 }
 
 
 //
 void findData(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str=TF_Find.getText();
  if(str.length()!=0){
   if(TableMdlLabel.Mdl.Rows.size()!=0){
    switch(CmB_Find.getSelectedIndex()){
     case 1 : Column=1; ColumnType=CCore.TypeString; break; // Name
     case 2 : Column=3; ColumnType=CCore.TypeString; break; // Comment
     default : Column=0; ColumnType=CCore.TypeLong; break; // Id
    }
      
    Selected=Tbl_Label.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlLabel, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_Label.changeSelection(FindIndex, 0, false, false);
      onSelectedRowLabelChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel label !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel label dalam keadaan kosong !");
   }
  }
 }
 void edit(){
  int[] Rows=Tbl_Label.getSelectedRows();
  F_ItemLabelModify fm1=IFV.FItemLabelModify;
  F_ItemLabelModifyMulti fm2=IFV.FItemLabelModifyMulti;
  OEditLabelItem Edit=new OEditLabelItem();
  Object[] Objs;
  long ItemId;
  
  if(Rows.length==0){return;}
  
  if(Rows.length==1){
   Objs=TableMdlLabel.Mdl.Rows.elementAt(Rows[0]);
   fm1.wItemId=(Long)Objs[0];
   fm1.wLabelCount=(Integer)Objs[4];
   fm1.wPromo=(String)Objs[3];
   fm1.wInitPromo=CB_InitPromo.isSelected();
   fm1.wInitPromoIndex=CmB_ItemComment.getSelectedIndex();

   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}
   
   ItemId=fm1.ItemDet.PrimaryId;
   Edit.init(
    true, ItemId, fm1.ItemDet,
    true, fm1.Qty,
    true, false, null, fm1.Promo);
  }
  else{
   fm2.wDataCount=Rows.length;

   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    false, -1, null,
    fm2.ChangeLabelCount, fm2.LabelCount,
    fm2.ChangePromo, fm2.ChangePromoSub, fm2.PromoSub, fm2.Promo);
  }
  
  edit(Rows, Edit);
 }
 void edit(int[] Rows, OEditLabelItem Edit){
  Vector<OTableCellUpdater> ChangeValues;
  int SumLabelOld, SumPrintLabelOld, CheckedCount;
  int[] CheckedRows;
  int insertpos;
  Object[] ObjsNew, ObjsOld;
  String ObjsOld_Name=null;
  boolean checked;
  
  SumLabelOld=0;
  SumPrintLabelOld=0;
  CheckedCount=0;
  
  // prepare edit
  ChangeValues=new Vector();
  if(Edit.EditItem){
   ChangeValues.addElement(new OTableCellUpdaterByObject(0, Edit.EditedItemId));
   ChangeValues.addElement(new OTableCellUpdaterByObject(1, Edit.EditedItemInfo.Name));
   ChangeValues.addElement(new OTableCellUpdaterByObject(2, Edit.EditedItemInfo.SellPrice));
   ChangeValues.addElement(new OTableCellUpdaterByObject(5, Edit.EditedItemInfo.PictureFile));
  }
  if(Edit.EditLabelCount){
   ChangeValues.addElement(new OTableCellUpdaterByObject(4, Edit.EditedLabelCount));
   SumLabelOld=((Long)PGUI.sumColumns(TableMdlLabel, PCore.primArr(4), Rows)[0]).intValue();
   CheckedRows=TableMdlLabel.getChecked(Rows, true);
   CheckedCount=CheckedRows.length;
   if(CheckedCount!=0){SumPrintLabelOld=((Long)PGUI.sumColumns(TableMdlLabel, PCore.primArr(4), CheckedRows)[0]).intValue();}
  }
  if(Edit.EditPromo){
   if(!Edit.ReplaceSubPromo){
    ChangeValues.addElement(new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedPromo, "", false)));
   }
   else{
    ChangeValues.addElement(new OTableCellUpdaterBySubString(3, false, PText.getString(Edit.SubPromo, "", false), PText.getString(Edit.EditedPromo, "", false)));
   }
  }
  
  // edit
  
  
  // update gui & effected components
  if(Edit.EditItem){
   ObjsOld=TableMdlLabel.Mdl.Rows.elementAt(Rows[0]);
   ObjsOld_Name=PCore.objString(ObjsOld[1], "");
  }
  
  PGUI.changeElements(TableMdlLabel, Rows, ChangeValues);
  
  if(Edit.EditLabelCount){
   addAcc(0, (Edit.EditedLabelCount*Rows.length)-SumLabelOld, true);
   if(CheckedCount!=0){addPrint(0, (Edit.EditedLabelCount*CheckedCount)-SumPrintLabelOld, true);}
  }
  if(Edit.EditItem){
   ObjsNew=TableMdlLabel.Mdl.Rows.elementAt(Rows[0]);
   if(!PText.compare(ObjsOld_Name, PCore.objString(ObjsNew[1], ""), false)){
    checked=TableMdlLabel.getChecked(Rows[0]);
    TableMdlLabel.remove(Rows[0]);
    insertpos=findInsertPosition(PCore.objString(ObjsNew[1], ""));
    TableMdlLabel.insert(insertpos, ObjsNew);
    TableMdlLabel.setChecked(insertpos, checked);
    Tbl_Label.changeSelection(insertpos, 0, false, false);
   }
  }
  if(Edit.EditItem || Edit.EditPromo){
   onSelectedRowLabelChanged(true);
  }
 }
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 public int addLabelFromExternal(Vector<Object[]> AddData, OFormInformProgress Progress){
  // AddData's format : ItemId, LabelCount, Comment
  int length;
  int temp;
  OInfoItem InfoItem;
  Object[] CurrData;
  int addcount, addlblcount;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  if(Progress!=null){Progress.inform(0, "Menambah data label ...", "-");}
  addcount=0; addlblcount=0;
  
  if(AddData==null){return addcount;}
  length=AddData.size();
  if(length==0){return addcount;}
  
  if(Progress!=null){
   increase_n_times=10;
   increase_every_n_records=length/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=length;}
   increase_size=(100-Progress.getProgress())/increase_n_times;
  }
  temp=0;
  do{
   CurrData=AddData.elementAt(temp);

   InfoItem=PMyShop.getItemInfo(IFV.Stm, (Long)CurrData[0], false);
   if(InfoItem!=null){
    TableMdlLabel.insert(findInsertPosition(InfoItem.Name), PCore.objArrVariant(InfoItem.PrimaryId, InfoItem.Name, InfoItem.SellPrice,
      PText.singleLine(PCore.objString(CurrData[2], ""), '~'), CurrData[1], InfoItem.PictureFile));

    addcount=addcount+1;
    addlblcount=addlblcount+(Integer)CurrData[1];
   }
   
   temp=temp+1;
   if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
  }while(temp!=length);
  
  if(addcount>=1){
   addAcc(addcount, addlblcount, true);
   addPrint(addcount, addlblcount, true);
  }
  
  return addcount;
 }
 
 double calculatePaperSizeMinimalWidth(OPaperLabel PaperLabel, double MoveImageableX, int columncount){
  double ret;
  
  ret=
   PaperLabel.RealImageableX+
   MoveImageableX+
   columncount*PaperLabel.LabelWidth+
   (columncount-1)*PaperLabel.LabelSpacingHorizontal;
  
  if(ret<0){ret=0;}
  
  return ret;
 }
 double calculatePaperSizeMinimalHeight(OPaperLabel PaperLabel, double MoveImageableY, int rowcount){
  double ret;
  
  ret=
   PaperLabel.RealImageableY+
   MoveImageableY+
   PCore.subtBool_Double(!PaperLabel.IsRollPaper, 0D, PaperLabel.LabelSpacingVerticalA)+
   rowcount*PaperLabel.LabelHeight+
   (rowcount-1)*(PaperLabel.LabelSpacingVerticalA+PaperLabel.LabelSpacingVerticalB)+
   PCore.subtBool_Double(!PaperLabel.IsRollPaper, 0D, PaperLabel.LabelSpacingVerticalB);
  
  if(ret<0){ret=0;}
  
  return ret;
 }
 void fillInfoPrint(){
  OPaperLabel PaperLabel=(OPaperLabel)ComboMdlPapers.Mdl.Rows.elementAt(CmB_Papers.getSelectedIndex())[0];
  double MoveImageableX=OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadH.getValue(), 0));
  double MoveImageableY=OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadV.getValue(), 0));
  int FirstPageStartRow=CmB_FirstPageStartRow.getSelectedIndex()+1;
  int FirstPageStartColumn=CmB_FirstPageStartColumn.getSelectedIndex()+1;
  int FirstPageMaxRows=CmB_FirstPageMaxRows.getSelectedIndex()+1;
  int PrintLabelCount=PrintAccLabel;
  
  int FirstPageEndRow, FirstPageEndColumn, LastPageStartRow, LastPageStartColumn, LastPageEndRow, LastPageEndColumn, LastLabelRow=0, LastLabelColumn=0;
  int APaper_LabelCount, LabelLeft, PaperCount, FirstPageLabelLeft, temp, usedlabel, usedpaper;
  int rowcount, columncount;
  double width, height;
  ODimension FirstPageSizeMinimal=new ODimension(), MiddlePageSizeMinimal=new ODimension(), LastPageSizeMinimal=new ODimension();
  
  StringBuilder InfoPrint;
  boolean first, AllInputsIsValid;
  String none;
  
  // calculate variables
  do{
   AllInputsIsValid=true;
   PaperCount=0;
   LabelLeft=PrintLabelCount;
   APaper_LabelCount=PaperLabel.RowCount*PaperLabel.ColumnCount;
   
   if(FirstPageStartRow>FirstPageMaxRows){AllInputsIsValid=false; break;}
   
   if(LabelLeft==0){break;}
   
   // first page
   FirstPageLabelLeft=(PaperLabel.ColumnCount-FirstPageStartColumn+1)+((FirstPageMaxRows-FirstPageStartRow)*PaperLabel.ColumnCount);
   
   usedpaper=1;
   usedlabel=LabelLeft; if(usedlabel>FirstPageLabelLeft){usedlabel=FirstPageLabelLeft;}
   
   FirstPageEndRow=FirstPageMaxRows; FirstPageEndColumn=PaperLabel.ColumnCount;
   if(usedlabel<FirstPageLabelLeft){
    FirstPageEndRow=FirstPageStartRow; FirstPageEndColumn=FirstPageStartColumn;
    
    if(usedlabel>1){
     temp=1;
     do{
      if(FirstPageEndColumn<PaperLabel.ColumnCount){FirstPageEndColumn=FirstPageEndColumn+1;}
      else{FirstPageEndRow=FirstPageEndRow+1; FirstPageEndColumn=1;}

      temp=temp+1;
     }while(temp!=usedlabel);
    }
   }
   
   LastLabelRow=FirstPageEndRow; LastLabelColumn=FirstPageEndColumn;
   
   PaperCount=PaperCount+usedpaper;
   LabelLeft=LabelLeft-usedlabel;
   
   rowcount=FirstPageEndRow;
   columncount=FirstPageEndColumn; if(FirstPageEndRow!=FirstPageStartRow){columncount=PaperLabel.ColumnCount;}
   
   width=calculatePaperSizeMinimalWidth(PaperLabel, MoveImageableX, columncount);
   height=calculatePaperSizeMinimalHeight(PaperLabel, MoveImageableY, rowcount);
   FirstPageSizeMinimal.setSize(width, height);
   
   if(LabelLeft==0){break;}
   
   // middle page
   usedpaper=LabelLeft/APaper_LabelCount; if(usedpaper>0 && LabelLeft%APaper_LabelCount==0){usedpaper=usedpaper-1;}
   usedlabel=usedpaper*APaper_LabelCount;
   
   PaperCount=PaperCount+usedpaper;
   LabelLeft=LabelLeft-usedlabel;
   
   if(usedpaper>0){
    rowcount=PaperLabel.RowCount;
    columncount=PaperLabel.ColumnCount;

    width=calculatePaperSizeMinimalWidth(PaperLabel, MoveImageableX, columncount);
    height=calculatePaperSizeMinimalHeight(PaperLabel, MoveImageableY, rowcount);
    MiddlePageSizeMinimal.setSize(width, height);
   }
   
   // last page
   LastPageStartRow=1; LastPageStartColumn=1;
   
   usedpaper=1;
   usedlabel=LabelLeft;
   
   LastPageEndColumn=usedlabel%PaperLabel.ColumnCount; if(LastPageEndColumn==0){LastPageEndColumn=PaperLabel.ColumnCount;}
   LastPageEndRow=usedlabel/PaperLabel.ColumnCount; if(LastPageEndColumn!=PaperLabel.ColumnCount){LastPageEndRow=LastPageEndRow+1;}
   
   LastLabelRow=LastPageEndRow; LastLabelColumn=LastPageEndColumn;
   
   PaperCount=PaperCount+usedpaper;
   LabelLeft=LabelLeft-usedlabel;
   
   rowcount=LastPageEndRow;
   columncount=LastPageEndColumn; if(LastPageEndRow!=LastPageStartRow){columncount=PaperLabel.ColumnCount;}
   
   width=calculatePaperSizeMinimalWidth(PaperLabel, MoveImageableX, columncount);
   height=calculatePaperSizeMinimalHeight(PaperLabel, MoveImageableY, rowcount);
   LastPageSizeMinimal.setSize(width, height);
  }while(false);
  
  // fill info print
  do{
   InfoPrint=new StringBuilder(); first=true;
   none="-";

   if(first){first=false;}else{InfoPrint.append("\n");}
   InfoPrint.append("jumlah halaman  :  ");
   if(!AllInputsIsValid || PaperCount==0){InfoPrint.append(none);}
   else{
    InfoPrint.append(PText.intToString(PaperCount)+" halaman");
   }
   
   if(first){first=false;}else{InfoPrint.append("\n");}
   InfoPrint.append("posisi label terakhir  :  ");
   if(!AllInputsIsValid || PaperCount==0){InfoPrint.append(none);}
   else{
    InfoPrint.append("kolom ke-"+PText.intToString(LastLabelColumn)+" ("+PText.intToString(PaperLabel.ColumnCount)+")");
    InfoPrint.append("  ,  ");
    InfoPrint.append("baris ke-"+PText.intToString(LastLabelRow)+" ("+PText.intToString(PaperLabel.RowCount)+")");
   }
    
   
   if(first){first=false;}else{InfoPrint.append("\n");}
   InfoPrint.append("ukuran minimal halaman (lebar x tinggi)  :  ");
   if(!AllInputsIsValid || PaperCount==0){InfoPrint.append(none);}
   else{
    InfoPrint.append("awal "+PText.priceToString(OUnit.pixel_to_mm(FirstPageSizeMinimal.Width))+" x "+PText.priceToString(OUnit.pixel_to_mm(FirstPageSizeMinimal.Height)));
    if(PaperCount>2){
     InfoPrint.append("  ,  ");
     InfoPrint.append("tengah "+PText.priceToString(OUnit.pixel_to_mm(MiddlePageSizeMinimal.Width))+" x "+PText.priceToString(OUnit.pixel_to_mm(MiddlePageSizeMinimal.Height)));
    }
    if(PaperCount>1){
     InfoPrint.append("  ,  ");
     InfoPrint.append("akhir "+PText.priceToString(OUnit.pixel_to_mm(LastPageSizeMinimal.Width))+" x "+PText.priceToString(OUnit.pixel_to_mm(LastPageSizeMinimal.Height)));
    }
    InfoPrint.append(" mm");
   }
  }while(false);
  TA_InfoPrint.setText(InfoPrint.toString());
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jPanel10 = new javax.swing.JPanel();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  CmB_Formats = new javax.swing.JComboBox<>();
  jLabel2 = new javax.swing.JLabel();
  CmB_Papers = new javax.swing.JComboBox<>();
  jLabel3 = new javax.swing.JLabel();
  Lbl_PaperDescription = new javax.swing.JLabel();
  ImgBox_Label = new XImgBoxMemory();
  Pnl_AddLabel = new javax.swing.JPanel();
  Btn_AddLabel = new javax.swing.JButton();
  TF_ItemId = new javax.swing.JTextField();
  Lbl_ItemId = new javax.swing.JLabel();
  TF_LabelCount = new javax.swing.JTextField();
  Lbl_LabelCount = new javax.swing.JLabel();
  TF_Promo = new javax.swing.JTextField();
  Lbl_Promo = new javax.swing.JLabel();
  Btn_ChooseItem = new javax.swing.JButton();
  TF_ItemPrice = new javax.swing.JTextField();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  Lbl_AddLabel = new javax.swing.JLabel();
  Lbl_ItemName = new javax.swing.JLabel();
  Lbl_ItemPrice = new javax.swing.JLabel();
  Btn_AddMultipleLabel = new javax.swing.JButton();
  CB_EnterIsAdd = new javax.swing.JCheckBox();
  CB_InitPromo = new javax.swing.JCheckBox();
  CmB_ItemComment = new javax.swing.JComboBox<>();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_ItemComment = new javax.swing.JTextArea();
  jPanel11 = new javax.swing.JPanel();
  Panel_LabelAcc = new javax.swing.JPanel();
  Btn_PrintRemove = new javax.swing.JButton();
  Btn_PrintAdd = new javax.swing.JButton();
  TF_PrintAccLabel = new javax.swing.JTextField();
  TF_PrintAccList = new javax.swing.JTextField();
  TF_AccListCount = new javax.swing.JTextField();
  TF_AccLabelCount = new javax.swing.JTextField();
  Btn_Save = new javax.swing.JButton();
  Btn_Load = new javax.swing.JButton();
  jLabel1 = new javax.swing.JLabel();
  Btn_ClearAll = new javax.swing.JButton();
  jPanel6 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_Label = new XTable();
  jPanel12 = new javax.swing.JPanel();
  Pnl_LabelItemPicture = new XImgBoxURL();
  jPanel13 = new javax.swing.JPanel();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_LabelInfo = new javax.swing.JTextArea();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_InfoPrint = new javax.swing.JTextArea();
  Pnl_LabelModify = new javax.swing.JPanel();
  CmB_Find = new javax.swing.JComboBox<>();
  TF_Find = new javax.swing.JTextField();
  Btn_FindBef = new javax.swing.JButton();
  Btn_FindNext = new javax.swing.JButton();
  Btn_Edit = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  jPanel1 = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  CmB_Printers = new javax.swing.JComboBox<>();
  Lbl_Printer = new javax.swing.JLabel();
  jPanel8 = new javax.swing.JPanel();
  Lbl_MovePrintHead = new javax.swing.JLabel();
  Spin_MovePrintHeadVertical = new javax.swing.JSpinner();
  Spin_MovePrintHeadHorizontal = new javax.swing.JSpinner();
  Lbl_MovePrintHeadVertical = new javax.swing.JLabel();
  Lbl_MovePrintHeadHorizontal = new javax.swing.JLabel();
  jPanel9 = new javax.swing.JPanel();
  Btn_Print = new javax.swing.JButton();
  CB_PrintChoosePage = new javax.swing.JCheckBox();
  jPanel7 = new javax.swing.JPanel();
  Lbl_FirstPage = new javax.swing.JLabel();
  CmB_FirstPageStartRow = new javax.swing.JComboBox<>();
  Lbl_FirstPageStartRow = new javax.swing.JLabel();
  CmB_FirstPageStartColumn = new javax.swing.JComboBox<>();
  Lbl_FirstPageStartColumn = new javax.swing.JLabel();
  Lbl_FirstPageMaxRows = new javax.swing.JLabel();
  CmB_FirstPageMaxRows = new javax.swing.JComboBox<>();

  setTitle("Cetak Label Barang ( {Shift + Esc} Untuk Keluar )");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CmB_Formats.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_FormatsActionPerformed(evt);
   }
  });

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setText("*Format Label");

  CmB_Papers.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_PapersActionPerformed(evt);
   }
  });

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setText("*Kertas");

  Lbl_PaperDescription.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PaperDescription.setText("Deskripsi Kertas ...");

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel2)
     .addComponent(jLabel3))
    .addGap(18, 18, Short.MAX_VALUE)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_PaperDescription, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_Papers, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_Formats, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_Formats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2))
    .addGap(5, 5, 5)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_Papers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel3))
    .addGap(3, 3, 3)
    .addComponent(Lbl_PaperDescription))
  );

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(ImgBox_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(ImgBox_Label, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Pnl_AddLabel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_AddLabel.setText("Tambah {F2}");
  Btn_AddLabel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddLabel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddLabelActionPerformed(evt);
   }
  });
  Btn_AddLabel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddLabelKeyPressed(evt);
   }
  });

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_ItemId.setToolTipText("{F6} ket brg, {Spasi} cari brg");
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Brg");

  TF_LabelCount.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_LabelCount.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelCountFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_LabelCountFocusLost(evt);
   }
  });
  TF_LabelCount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelCountKeyPressed(evt);
   }
  });

  Lbl_LabelCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_LabelCount.setText("Jmlh Label");

  TF_Promo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_Promo.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PromoFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_PromoFocusLost(evt);
   }
  });
  TF_Promo.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PromoKeyPressed(evt);
   }
  });

  Lbl_Promo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Promo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_Promo.setText("Komntr");
  Lbl_Promo.setToolTipText("Klik untuk melihat \"Catatan Input Komentar\" !");
  Lbl_Promo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_Promo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PromoMouseClicked(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });
  Btn_ChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseItemKeyPressed(evt);
   }
  });

  TF_ItemPrice.setEditable(false);
  TF_ItemPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemPrice.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_ItemPrice.setRequestFocusEnabled(false);

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(20);
  TA_ItemName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setRows(1);
  TA_ItemName.setToolTipText("klik utk melihat keterangan barang");
  TA_ItemName.setWrapStyleWord(true);
  TA_ItemName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_ItemName.setRequestFocusEnabled(false);
  TA_ItemName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_ItemNameMouseClicked(evt);
   }
  });
  jScrollPane2.setViewportView(TA_ItemName);

  Lbl_AddLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_AddLabel.setText("---- Label");

  Lbl_ItemName.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_ItemName.setText("- Nama");

  Lbl_ItemPrice.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_ItemPrice.setText("- Hrg Jual ");

  Btn_AddMultipleLabel.setText("Tambah Jamak {F4}");
  Btn_AddMultipleLabel.setToolTipText("Menambah beberapa data barang sekaligus ke dalam tabel");
  Btn_AddMultipleLabel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddMultipleLabel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddMultipleLabelActionPerformed(evt);
   }
  });
  Btn_AddMultipleLabel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddMultipleLabelKeyPressed(evt);
   }
  });

  CB_EnterIsAdd.setToolTipText("centang opsi ini utk mengaktifkan penambahan data label secara otomatis ketika karakter 'Enter' ditekan pada 'text box Id Barang'");
  CB_EnterIsAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_EnterIsAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_EnterIsAddKeyPressed(evt);
   }
  });

  CB_InitPromo.setToolTipText("Centang opsi ini utk menginisialisasi komentar dgn \"Ket. Brg\"");
  CB_InitPromo.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_InitPromo.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_InitPromoKeyPressed(evt);
   }
  });

  CmB_ItemComment.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  CmB_ItemComment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ket. Umum", "Ket. Beli", "Ket. Jual" }));
  CmB_ItemComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ItemCommentActionPerformed(evt);
   }
  });
  CmB_ItemComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ItemCommentKeyPressed(evt);
   }
  });

  TA_ItemComment.setEditable(false);
  TA_ItemComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemComment.setColumns(20);
  TA_ItemComment.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_ItemComment.setLineWrap(true);
  TA_ItemComment.setWrapStyleWord(true);
  jScrollPane4.setViewportView(TA_ItemComment);

  javax.swing.GroupLayout Pnl_AddLabelLayout = new javax.swing.GroupLayout(Pnl_AddLabel);
  Pnl_AddLabel.setLayout(Pnl_AddLabelLayout);
  Pnl_AddLabelLayout.setHorizontalGroup(
   Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_AddLabelLayout.createSequentialGroup()
    .addComponent(Lbl_AddLabel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_AddMultipleLabel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_AddLabel))
   .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
      .addComponent(Lbl_Promo)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_InitPromo))
     .addComponent(Lbl_ItemName)
     .addComponent(Lbl_ItemPrice)
     .addComponent(Lbl_LabelCount)
     .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
      .addComponent(Lbl_ItemId)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_EnterIsAdd))
     .addComponent(CmB_ItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(18, 18, 18)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
      .addComponent(TF_ItemId)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseItem))
     .addComponent(TF_ItemPrice)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
      .addComponent(TF_Promo, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, Short.MAX_VALUE))
     .addComponent(TF_LabelCount)))
  );
  Pnl_AddLabelLayout.setVerticalGroup(
   Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_AddLabel)
     .addComponent(Lbl_AddLabel)
     .addComponent(Btn_AddMultipleLabel))
    .addGap(8, 8, 8)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_EnterIsAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_ItemId)
      .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Btn_ChooseItem)))
    .addGap(5, 5, 5)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_ItemName)
     .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(5, 5, 5)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ItemPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ItemPrice))
    .addGap(5, 5, 5)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_AddLabelLayout.createSequentialGroup()
      .addComponent(CmB_ItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, Short.MAX_VALUE))
     .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE))
    .addGap(5, 5, 5)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_LabelCount))
    .addGap(5, 5, 5)
    .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_InitPromo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Pnl_AddLabelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_Promo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_Promo))))
  );

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Pnl_AddLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Pnl_AddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_PrintRemove.setText("-");
  Btn_PrintRemove.setToolTipText("Hapus centang untuk menandai label yg tdk akan dicetak");
  Btn_PrintRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PrintRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PrintRemoveActionPerformed(evt);
   }
  });

  Btn_PrintAdd.setText("+");
  Btn_PrintAdd.setToolTipText("Centang utk menandai label yg akan dicetak");
  Btn_PrintAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PrintAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PrintAddActionPerformed(evt);
   }
  });

  TF_PrintAccLabel.setEditable(false);
  TF_PrintAccLabel.setBackground(new java.awt.Color(204, 255, 204));
  TF_PrintAccLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_PrintAccLabel.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_PrintAccLabel.setToolTipText("Akumulasi jumlah label yg akan dicetak");

  TF_PrintAccList.setEditable(false);
  TF_PrintAccList.setBackground(new java.awt.Color(204, 255, 204));
  TF_PrintAccList.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_PrintAccList.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_PrintAccList.setToolTipText("Jumlah data yg akan dicetak");

  TF_AccListCount.setEditable(false);
  TF_AccListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_AccListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_AccListCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_AccListCount.setToolTipText("Jumlah data di dalam tabel");
  TF_AccListCount.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
  TF_AccListCount.setRequestFocusEnabled(false);

  TF_AccLabelCount.setEditable(false);
  TF_AccLabelCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_AccLabelCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_AccLabelCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_AccLabelCount.setToolTipText("Akumulasi jumlah label di dalam tabel");
  TF_AccLabelCount.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
  TF_AccLabelCount.setRequestFocusEnabled(false);

  Btn_Save.setText("S");
  Btn_Save.setToolTipText("Simpan data tabel ke suatu file");
  Btn_Save.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Save.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SaveActionPerformed(evt);
   }
  });

  Btn_Load.setText("P");
  Btn_Load.setToolTipText("Pulihkan data tabel dari suatu file");
  Btn_Load.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Load.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_LoadActionPerformed(evt);
   }
  });

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("*Ctak");

  Btn_ClearAll.setText("X");
  Btn_ClearAll.setToolTipText("Kosongkan data label pada tabel");
  Btn_ClearAll.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearAll.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearAllActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Panel_LabelAccLayout = new javax.swing.GroupLayout(Panel_LabelAcc);
  Panel_LabelAcc.setLayout(Panel_LabelAccLayout);
  Panel_LabelAccLayout.setHorizontalGroup(
   Panel_LabelAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_LabelAccLayout.createSequentialGroup()
    .addComponent(TF_AccListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_AccLabelCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Save)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Load)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ClearAll)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel1)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_PrintAccList, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_PrintAccLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PrintAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PrintRemove))
  );
  Panel_LabelAccLayout.setVerticalGroup(
   Panel_LabelAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_LabelAccLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_PrintRemove)
    .addComponent(Btn_PrintAdd)
    .addComponent(TF_PrintAccLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_PrintAccList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_AccListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_AccLabelCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_Save)
    .addComponent(Btn_Load)
    .addComponent(jLabel1)
    .addComponent(Btn_ClearAll))
  );

  jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Tbl_Label.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Label.setToolTipText("F9 - Cek ; F10 - Hapus Cek");
  Tbl_Label.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Label.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Label.setRowHeight(18);
  Tbl_Label.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_LabelMouseReleased(evt);
   }
  });
  Tbl_Label.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_LabelKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_Label);

  Pnl_LabelItemPicture.setToolTipText("klik utk melihat keterangan barang");
  Pnl_LabelItemPicture.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_LabelItemPictureMouseClicked(evt);
   }
  });

  TA_LabelInfo.setEditable(false);
  TA_LabelInfo.setBackground(new java.awt.Color(204, 255, 204));
  TA_LabelInfo.setColumns(5);
  TA_LabelInfo.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_LabelInfo.setLineWrap(true);
  TA_LabelInfo.setWrapStyleWord(true);
  TA_LabelInfo.setRequestFocusEnabled(false);
  jScrollPane3.setViewportView(TA_LabelInfo);

  TA_InfoPrint.setEditable(false);
  TA_InfoPrint.setBackground(new java.awt.Color(204, 204, 255));
  TA_InfoPrint.setColumns(5);
  TA_InfoPrint.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  TA_InfoPrint.setForeground(new java.awt.Color(102, 0, 0));
  TA_InfoPrint.setLineWrap(true);
  TA_InfoPrint.setText("Informasi Print ...");
  TA_InfoPrint.setToolTipText("Informasi Print");
  TA_InfoPrint.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_InfoPrint);

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane3)
   .addComponent(jScrollPane5)
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(jScrollPane3)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addComponent(Pnl_LabelItemPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_LabelItemPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane1)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(jScrollPane1)
    .addGap(0, 0, 0)
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Pnl_LabelModify.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CmB_Find.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id", "Nama", "Komentar" }));

  TF_Find.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FindFocusLost(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  Btn_FindBef.setText("<");
  Btn_FindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBefActionPerformed(evt);
   }
  });

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_Edit.setText("Ubah {F7}");
  Btn_Edit.setToolTipText("ubah data-data label yg dipilih dalam daftar");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Remove.setText("Hapus {F8}");
  Btn_Remove.setToolTipText("hapus data-data label yg dipilih dalam daftar");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_LabelModifyLayout = new javax.swing.GroupLayout(Pnl_LabelModify);
  Pnl_LabelModify.setLayout(Pnl_LabelModifyLayout);
  Pnl_LabelModifyLayout.setHorizontalGroup(
   Pnl_LabelModifyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_LabelModifyLayout.createSequentialGroup()
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Find)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Btn_Remove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Edit))
  );
  Pnl_LabelModifyLayout.setVerticalGroup(
   Pnl_LabelModifyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_LabelModifyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_FindBef)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Remove))
  );

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Pnl_LabelModify, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(Pnl_LabelModify, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  Lbl_Printer.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Printer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_Printer.setText("*Printer :");

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Lbl_Printer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(CmB_Printers, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(Lbl_Printer)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CmB_Printers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Lbl_MovePrintHead.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MovePrintHead.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_MovePrintHead.setText("*Geser Print-Head (mm) :");

  Spin_MovePrintHeadVertical.setToolTipText("Geser print-head secara vertikal (atas (-) ... bawah (+)) sepanjang .... mm");

  Spin_MovePrintHeadHorizontal.setToolTipText("Geser print-head secara horizontal (kiri (-) ... kanan (+)) sepanjang .... mm");

  Lbl_MovePrintHeadVertical.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MovePrintHeadVertical.setText("Ver");

  Lbl_MovePrintHeadHorizontal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MovePrintHeadHorizontal.setText("Hor");

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Lbl_MovePrintHead, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
    .addComponent(Lbl_MovePrintHeadHorizontal)
    .addGap(3, 3, 3)
    .addComponent(Spin_MovePrintHeadHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_MovePrintHeadVertical)
    .addGap(3, 3, 3)
    .addComponent(Spin_MovePrintHeadVertical, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(Lbl_MovePrintHead)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Spin_MovePrintHeadVertical, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Spin_MovePrintHeadHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_MovePrintHeadVertical)
     .addComponent(Lbl_MovePrintHeadHorizontal)))
  );

  Btn_Print.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_Print.setText("*Ctak {F11}");
  Btn_Print.setToolTipText("Cetak label berdasarkan \"Format Label\" yg terpilih saat ini");
  Btn_Print.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Print.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PrintActionPerformed(evt);
   }
  });

  CB_PrintChoosePage.setText("Pilih Hlmn");
  CB_PrintChoosePage.setToolTipText("centang untuk memilih halaman sebelum mencetak");
  CB_PrintChoosePage.setMargin(new java.awt.Insets(0, 0, 0, 0));

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Btn_Print, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(CB_PrintChoosePage, javax.swing.GroupLayout.Alignment.TRAILING)))
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(CB_PrintChoosePage)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Print))
  );

  Lbl_FirstPage.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FirstPage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_FirstPage.setText("*Hlmn 1  :  Start Kolom & Baris  ~  Max Baris");

  CmB_FirstPageStartRow.setToolTipText("Cetak halaman pertama mulai dari baris ke....");
  CmB_FirstPageStartRow.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_FirstPageStartRowActionPerformed(evt);
   }
  });

  Lbl_FirstPageStartRow.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FirstPageStartRow.setText("Brs");

  CmB_FirstPageStartColumn.setToolTipText("Cetak halaman pertama mulai dari kolom ke....");
  CmB_FirstPageStartColumn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_FirstPageStartColumnActionPerformed(evt);
   }
  });

  Lbl_FirstPageStartColumn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FirstPageStartColumn.setText("Kol");

  Lbl_FirstPageMaxRows.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FirstPageMaxRows.setText("Max");

  CmB_FirstPageMaxRows.setToolTipText("Halaman pertama memiliki jumlah maksimal .... baris (dipandu dgn ukuran tinggi minimal halaman)");
  CmB_FirstPageMaxRows.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_FirstPageMaxRowsActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Lbl_FirstPage, javax.swing.GroupLayout.DEFAULT_SIZE, 390, Short.MAX_VALUE)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(Lbl_FirstPageStartColumn)
    .addGap(3, 3, 3)
    .addComponent(CmB_FirstPageStartColumn, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_FirstPageStartRow)
    .addGap(3, 3, 3)
    .addComponent(CmB_FirstPageStartRow, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_FirstPageMaxRows)
    .addGap(3, 3, 3)
    .addComponent(CmB_FirstPageMaxRows, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(Lbl_FirstPage)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_FirstPageStartRow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_FirstPageStartRow)
     .addComponent(CmB_FirstPageStartColumn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_FirstPageStartColumn)
     .addComponent(Lbl_FirstPageMaxRows)
     .addComponent(CmB_FirstPageMaxRows, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Panel_LabelAcc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addComponent(Panel_LabelAcc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void CmB_PapersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_PapersActionPerformed
  onSelectedRowPaperChanged(false);
 }//GEN-LAST:event_CmB_PapersActionPerformed

 private void Btn_AddLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddLabelActionPerformed
  boolean valid;
  int insertpos;
  Object[] Objs;
  long ItemId;
  
  // check input
  inputItem(true);
  
  valid=true;
  
  if(I_CheckedItemId!=-1){Lbl_ItemId.setForeground(CGUI.Color_Label_InputRight);}
  else{Lbl_ItemId.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  if(I_Qty>0){Lbl_LabelCount.setForeground(CGUI.Color_Label_InputRight);}
  else{Lbl_LabelCount.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  if(PText.checkInput(TF_Promo.getText(), true, 0, 0, 1, 1, 0)){Lbl_Promo.setForeground(Lbl_PromoColor);}
  else{Lbl_Promo.setForeground(CGUI.Color_Label_InputWrong); valid=false;}
  
  if(!valid){
   JOptionPane.showMessageDialog(null, "Input masih salah, silahkan koreksi label yg berwarna merah !");
   return;
  }
  
  fillInputVariablesIntoRealVariables();
  
  ItemId=ItemDet.PrimaryId;
  Objs=new Object[6];
  Objs[0]=ItemId;
  Objs[1]=ItemDet.Name;
  Objs[2]=ItemDet.SellPrice;
  Objs[3]=TF_Promo.getText();
  Objs[4]=Qty;
  Objs[5]=ItemDet.PictureFile;
  insertpos=findInsertPosition(ItemDet.Name);
  TableMdlLabel.insert(insertpos, Objs);
  
  addAcc(1, Qty, true);
  addPrint(1, Qty, true);
  
  Tbl_Label.changeSelection(insertpos, 0, false, false);
  onSelectedRowLabelChanged(true);
  
  clearInputLabel();
  TF_ItemId.requestFocusInWindow();
 }//GEN-LAST:event_Btn_AddLabelActionPerformed

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ItemId, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_AddLabel)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_EnterIsAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseItem)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_DOWN : TF_LabelCount.requestFocusInWindow(); break;
   case KeyEvent.VK_ENTER :
    if(!evt.isShiftDown()){
     if(CB_EnterIsAdd.isSelected()){Btn_AddLabelActionPerformed(null);}
     else{TF_LabelCount.requestFocusInWindow();}
    }
    break;
   case KeyEvent.VK_F6 : inputItem(true);; break;
   case KeyEvent.VK_SPACE : evt.consume(); Btn_ChooseItemActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOff);
  inputItem(true);
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOn);
  TF_ItemId.selectAll();
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void TF_LabelCountFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelCountFocusGained
  DocumentListenerFocus=1;
  TF_LabelCount.setBackground(CGUI.Color_TextBox_FocusOn);
  TF_LabelCount.selectAll();
 }//GEN-LAST:event_TF_LabelCountFocusGained

 private void TF_LabelCountFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelCountFocusLost
  DocumentListenerFocus=-1;
  TF_LabelCount.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_LabelCountFocusLost

 private void TF_PromoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PromoFocusGained
  TF_Promo.setBackground(CGUI.Color_TextBox_FocusOn);
  TF_Promo.selectAll();
 }//GEN-LAST:event_TF_PromoFocusGained

 private void TF_PromoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PromoFocusLost
  TF_Promo.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_PromoFocusLost

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  edit();
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  int[] Rows=Tbl_Label.getSelectedRows();
  int temp, labelscount, printlist, printlabels, currlabelqty;
  
  if(Rows.length==0){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+Rows.length+" data label yang dipilih ?",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  // perform remove
   // get removed labels count
  temp=0;
  labelscount=0;
  printlist=0;
  printlabels=0;
  do{
   currlabelqty=(Integer)TableMdlLabel.Mdl.Rows.elementAt(Rows[temp])[4];
   if(TableMdlLabel.getChecked(Rows[temp])){
    printlist=printlist+1;
    printlabels=printlabels+currlabelqty;
   }
   labelscount=labelscount+currlabelqty;
   temp=temp+1;
  }while(temp!=Rows.length);
  
   // remove data in table
  TableMdlLabel.remove(Rows);
  onSelectedRowLabelChanged(true);
  
   // update Accumulate of ListCount & LabelCount
  addAcc(Rows.length, labelscount, false);
  if(printlist!=0){addPrint(printlist, printlabels, false);}
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void Btn_PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PrintActionPerformed
  OValidation valid;
  int temp, count;
  Book GenBook;
  Object[] Objs;
  
  OLabelCreator LabelGen_=null;
  OPaperLabel PaperLabel=null;
  LinkedList<OPrintInfoLabel> Labels=null;
  OPrintInfoLabel info_print=null;
  int FirstPageStartColumn=0, FirstPageStartRow=0, FirstPageMaxRows=0;
  
  int[] CheckedRows;
  
  if(JOptionPane.showConfirmDialog(null, "Cetak Data Label ?", "Konfirmasi Pencetakan Label",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  // check input
  valid=new OValidation(true);
  
  if(TableMdlLabel.Mdl.CheckedCount==0){valid.addError("\n- Belum ada data label yang akan di-print.");}
  if(CmB_Papers.getSelectedIndex()==-1){valid.addError("\n- Tidak ada kertas label yang terpilih.");}
  if(CmB_Printers.getSelectedIndex()==-1){valid.addError("\n- Tidak ada printer yang terpilih.");}
  if(CmB_FirstPageStartRow.getSelectedIndex()==-1 ||
   CmB_FirstPageStartColumn.getSelectedIndex()==-1){valid.addError("\n- Start baris dan kolom di 'halaman pertama' belum didefenisikan.");}
  if(CmB_FirstPageMaxRows.getSelectedIndex()==-1){valid.addError("\n- Max baris di 'halaman pertama' belum didefenisikan.");}
  if(CmB_FirstPageStartRow.getSelectedIndex()!=-1 && CmB_FirstPageStartColumn.getSelectedIndex()!=-1 && CmB_FirstPageMaxRows.getSelectedIndex()!=-1){
   FirstPageStartRow=CmB_FirstPageStartRow.getSelectedIndex()+1;
   FirstPageStartColumn=CmB_FirstPageStartColumn.getSelectedIndex()+1;
   FirstPageMaxRows=CmB_FirstPageMaxRows.getSelectedIndex()+1;
   if(FirstPageStartRow>FirstPageMaxRows){valid.addError("\n- Start baris tidak boleh lebih besar daripada max baris di 'halaman pertama'.");}
  }
  
  if(!valid.getValid()){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang masih salah !\n"+valid.getError());
   return;
  }
  
  // perform print
  try{LabelGen_=(OLabelCreator)CurrLabelGen.clone();}catch(Exception E){}
  PaperLabel=(OPaperLabel)ComboMdlPapers.Mdl.Rows.elementAt(CmB_Papers.getSelectedIndex())[0];
  PaperLabel.changeMoveImageableXY(
   OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadH.getValue(), 0)),
   OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadV.getValue(), 0)));
  Labels=new LinkedList();
  CheckedRows=TableMdlLabel.getChecked(true);
  count=CheckedRows.length;
  temp=0;
  do{
   Objs=TableMdlLabel.Mdl.Rows.elementAt(CheckedRows[temp]);
   info_print=new OPrintInfoLabel(new OLabelDataItem((Long)Objs[0], (String)Objs[1], (Double)Objs[2], (String)Objs[3]), (Integer)Objs[4]);
   Labels.addLast(info_print);
   temp=temp+1;
  }while(temp!=count);
  
  IFV.PrintGenLabel.setPrintVariables(PaperLabel, LabelGen_, Labels, FirstPageStartColumn, FirstPageStartRow, FirstPageMaxRows);
  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  GenBook=IFV.PrintGenLabel.generateBook(IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  
  if(GenBook==null){
   JOptionPane.showMessageDialog(null, "Tidak dapat mencetak : Gagal membuat data print !");
   return;
  }
  
  if(CB_PrintChoosePage.isSelected()){
   IFV.FPrintPage.wBook=GenBook;
   
   if(IFV.FPrintPage.showForm()==false){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){
    GenBook=PPrint.subPage(GenBook, IFV.FPrintPage.PrintPages);
   }
  }
  
  do{
   if(PPrint.print(GenBook, (PrintService)ComboMdlPrinters.Mdl.Rows.elementAt(CmB_Printers.getSelectedIndex())[0],
    "LblBrg_"+PText.dateToString(new Date(), 101), true)){break;}
   if(JOptionPane.showConfirmDialog(null, "Tidak dapat mencetak ke printer !\nCoba cetak lagi ?",
    "Konfirmasi Percobaan Pencetakan Ulang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){break;}
  }while(true);
 }//GEN-LAST:event_Btn_PrintActionPerformed

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  LastInputId=IFV.FItem.ChoosedId[0];
  TF_ItemId.setText(String.valueOf(LastInputId));
  changeItem(true);
  TF_LabelCount.requestFocusInWindow();
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void TF_LabelCountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelCountKeyPressed
  int consumed=PNav.onKey_TF(this, TF_LabelCount, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Promo)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_LabelCountKeyPressed

 private void TF_PromoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PromoKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Promo, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_LabelCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_InitPromo)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_PromoKeyPressed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  int temp, length;
  Vector<OPaper> Papers;
  
  if(Activ){return;}
  
  Activ=true;
  
  PPrint.fillPrinters(ComboMdlPrinters);
  temp=PGUI.findString(ComboMdlPrinters, 1, IFV.CurrentReportPrinter.getName());
  if(temp!=-1){CmB_Printers.setSelectedIndex(temp);}
  
  Papers=PMyShop.getCustomPaperLabel(IFV.Stm, CApp.AddPaperSizeTolerance, IFV.Conf.StandardPaperMargin, IFV.Conf.ThermalPaperMargin);
  if(Papers!=null){
   length=Papers.size();
   if(length!=0){
    temp=0;
    do{
     CustomPaperLabel.addElement(Papers.elementAt(temp));
     temp=temp+1;
    }while(temp!=length);
   }
  }
  onSelectedRowFormatChanged(true);
  
  TF_ItemId.requestFocusInWindow();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SaveActionPerformed
  File f;
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.LabelFileFilter, "labels");
  if(f==null){return;}
  
  if(PEtc.saveModelToFile(TableMdlLabel, PCore.primArr(0, 4, 3), f,
    IFV.FSplashScreen, true, this, "Menulis Data Label")==false){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data tabel ke file !");
  }
 }//GEN-LAST:event_Btn_SaveActionPerformed

 private void Btn_LoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_LoadActionPerformed
  File f;
  Vector<Object[]> data;
  
  f=PGUI.showLoadDialog(IFV.FileChooser, IFV.LabelFileFilter, "labels");
  if(f==null){return;}
  
  IFV.FSplashScreen.appear(this, "Menambah Data Label Dari File");
  do{
   IFV.FSplashScreen.inform(0, "Sedang memproses ...", "-");
   data=PEtc.loadModelFromFile(f, TableMdlLabel, PCore.primArr(0, 4, 3),
    null, false, null, null);
   if(data==null){
    JOptionPane.showMessageDialog(null, "Gagal membaca data tabel dari file !");
    break;
   }
   IFV.FSplashScreen.inform(10, null, null);

   clearTable();
   addLabelFromExternal(data, IFV.FSplashScreen);
  }while(false);
  IFV.FSplashScreen.disappear();
 }//GEN-LAST:event_Btn_LoadActionPerformed

 private void Btn_AddMultipleLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddMultipleLabelActionPerformed
  int temp, count, InitPromo;
  long CurrId;
  String str=null;
  OInfoItem InfoItem;
  Object[] Objs;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=true;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Menambah Data Label");
  
  IFV.FSplashScreen.inform(0, "Sedang memproses ...", "-");
  
  InitPromo=-1; if(CB_InitPromo.isSelected()){InitPromo=CmB_ItemComment.getSelectedIndex();}
  count=IFV.FItem.ChoosedId.length;
  
  increase_n_times=10;
  increase_every_n_records=count/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=count;}
  increase_size=(100-IFV.FSplashScreen.getProgress())/increase_n_times;
  
  temp=0;
  do{
   Objs=new Object[6];
   CurrId=IFV.FItem.ChoosedId[temp];
   Objs[0]=CurrId;
   Objs[1]=IFV.FItem.ChoosedName[temp];
   Objs[2]=IFV.FItem.ChoosedSellPrice[temp];
   str=null;
   if(InitPromo!=-1){
    InfoItem=PMyShop.getItemInfo(IFV.Stm, CurrId, false);
    if(InfoItem!=null){
     switch(InitPromo){
      case 0 : str=InfoItem.Comment; break;
      case 1 : if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){str=InfoItem.BuyPriceComment;} break;
      case 2 : str=InfoItem.SellPriceComment; break;
     }
    }
   }
   Objs[3]=PText.singleLine(PText.getString(str, "", false), '~');
   Objs[4]=1;
   Objs[5]=IFV.FItem.ChoosedPicture[temp];
   TableMdlLabel.insert(findInsertPosition(IFV.FItem.ChoosedName[temp]), Objs);
   
   temp=temp+1;
   if(temp%increase_every_n_records==0){IFV.FSplashScreen.inform(increase_size, null, null);}
  }while(temp!=count);
  
  addAcc(count, count, true);
  addPrint(count, count, true);
  
  onSelectedRowLabelChanged(true);
  
  IFV.FSplashScreen.disappear();
 }//GEN-LAST:event_Btn_AddMultipleLabelActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findData(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void Btn_FindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBefActionPerformed
  findData(2);
 }//GEN-LAST:event_Btn_FindBefActionPerformed

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOn);
  TF_Find.selectAll();
 }//GEN-LAST:event_TF_FindFocusGained

 private void TF_FindFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusLost
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FindFocusLost

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Label)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Find)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void Lbl_PromoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PromoMouseClicked
  JOptionPane.showMessageDialog(null, PMyShop.getLabelCommentInputInfo()+
   "\n\nAturan input !\n"+PText.getInputInfo(true, 0, 0, 1, 1, 0, false));
 }//GEN-LAST:event_Lbl_PromoMouseClicked

 private void CmB_ItemCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ItemCommentActionPerformed
  fillItemComment();
 }//GEN-LAST:event_CmB_ItemCommentActionPerformed

 private void Btn_PrintAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PrintAddActionPerformed
  checkPrint(Tbl_Label.getSelectedRows(), true);
 }//GEN-LAST:event_Btn_PrintAddActionPerformed

 private void Btn_PrintRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PrintRemoveActionPerformed
  checkPrint(Tbl_Label.getSelectedRows(), false);
 }//GEN-LAST:event_Btn_PrintRemoveActionPerformed

 private void CmB_FormatsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_FormatsActionPerformed
  onSelectedRowFormatChanged(false);
 }//GEN-LAST:event_CmB_FormatsActionPerformed

 private void Btn_ClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearAllActionPerformed
  if(JOptionPane.showConfirmDialog(null, "Hapus semua data label di tabel ?",
   "Konfirmasi Penghapusan Semua Data Label Di Tabel", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  clearTable();
 }//GEN-LAST:event_Btn_ClearAllActionPerformed

 private void Tbl_LabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_LabelMouseReleased
  onSelectedRowLabelChanged(false);
 }//GEN-LAST:event_Tbl_LabelMouseReleased

 private void Tbl_LabelKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_LabelKeyReleased
  onSelectedRowLabelChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Label, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_PrintAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_PrintRemoveActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_Tbl_LabelKeyReleased

 private void Pnl_LabelItemPictureMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_LabelItemPictureMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Label, TableMdlLabel, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_LabelItemPictureMouseClicked

 private void TA_ItemNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_ItemNameMouseClicked
  if(I_CheckedItemId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedItemId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_ItemNameMouseClicked

 private void Btn_AddMultipleLabelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddMultipleLabelKeyPressed
  PNav.onKey_Btn(this, Btn_AddMultipleLabel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_AddLabel)));
 }//GEN-LAST:event_Btn_AddMultipleLabelKeyPressed

 private void Btn_AddLabelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddLabelKeyPressed
  PNav.onKey_Btn(this, Btn_AddLabel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_AddMultipleLabel)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_AddLabelKeyPressed

 private void CB_EnterIsAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_EnterIsAddKeyPressed
  PNav.onKey_CB(this, CB_EnterIsAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_AddLabel)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_ItemComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ItemId)));
 }//GEN-LAST:event_CB_EnterIsAddKeyPressed

 private void Btn_ChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseItemKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_AddLabel)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_LabelCount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseItemKeyPressed

 private void CmB_ItemCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ItemCommentKeyPressed
  PNav.onKey_CmB(this, CmB_ItemComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_EnterIsAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_LabelCount)));
 }//GEN-LAST:event_CmB_ItemCommentKeyPressed

 private void CB_InitPromoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_InitPromoKeyPressed
  PNav.onKey_CB(this, CB_InitPromo, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_LabelCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Promo)));
 }//GEN-LAST:event_CB_InitPromoKeyPressed

 private void CmB_FirstPageStartColumnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_FirstPageStartColumnActionPerformed
  fillInfoPrint();
 }//GEN-LAST:event_CmB_FirstPageStartColumnActionPerformed

 private void CmB_FirstPageStartRowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_FirstPageStartRowActionPerformed
  fillInfoPrint();
 }//GEN-LAST:event_CmB_FirstPageStartRowActionPerformed

 private void CmB_FirstPageMaxRowsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_FirstPageMaxRowsActionPerformed
  fillInfoPrint();
 }//GEN-LAST:event_CmB_FirstPageMaxRowsActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_AddLabel;
 private javax.swing.JButton Btn_AddMultipleLabel;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_ClearAll;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FindBef;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_Load;
 private javax.swing.JButton Btn_Print;
 private javax.swing.JButton Btn_PrintAdd;
 private javax.swing.JButton Btn_PrintRemove;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Save;
 private javax.swing.JCheckBox CB_EnterIsAdd;
 private javax.swing.JCheckBox CB_InitPromo;
 private javax.swing.JCheckBox CB_PrintChoosePage;
 private javax.swing.JComboBox<String> CmB_Find;
 private javax.swing.JComboBox<String> CmB_FirstPageMaxRows;
 private javax.swing.JComboBox<String> CmB_FirstPageStartColumn;
 private javax.swing.JComboBox<String> CmB_FirstPageStartRow;
 private javax.swing.JComboBox<String> CmB_Formats;
 private javax.swing.JComboBox<String> CmB_ItemComment;
 private javax.swing.JComboBox<String> CmB_Papers;
 private javax.swing.JComboBox<String> CmB_Printers;
 private XImgBoxMemory ImgBox_Label;
 private javax.swing.JLabel Lbl_AddLabel;
 private javax.swing.JLabel Lbl_FirstPage;
 private javax.swing.JLabel Lbl_FirstPageMaxRows;
 private javax.swing.JLabel Lbl_FirstPageStartColumn;
 private javax.swing.JLabel Lbl_FirstPageStartRow;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_ItemName;
 private javax.swing.JLabel Lbl_ItemPrice;
 private javax.swing.JLabel Lbl_LabelCount;
 private javax.swing.JLabel Lbl_MovePrintHead;
 private javax.swing.JLabel Lbl_MovePrintHeadHorizontal;
 private javax.swing.JLabel Lbl_MovePrintHeadVertical;
 private javax.swing.JLabel Lbl_PaperDescription;
 private javax.swing.JLabel Lbl_Printer;
 private javax.swing.JLabel Lbl_Promo;
 private javax.swing.JPanel Panel_LabelAcc;
 private javax.swing.JPanel Pnl_AddLabel;
 private XImgBoxURL Pnl_LabelItemPicture;
 private javax.swing.JPanel Pnl_LabelModify;
 private javax.swing.JSpinner Spin_MovePrintHeadHorizontal;
 private javax.swing.JSpinner Spin_MovePrintHeadVertical;
 private javax.swing.JTextArea TA_InfoPrint;
 private javax.swing.JTextArea TA_ItemComment;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextArea TA_LabelInfo;
 private javax.swing.JTextField TF_AccLabelCount;
 private javax.swing.JTextField TF_AccListCount;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_ItemPrice;
 private javax.swing.JTextField TF_LabelCount;
 private javax.swing.JTextField TF_PrintAccLabel;
 private javax.swing.JTextField TF_PrintAccList;
 private javax.swing.JTextField TF_Promo;
 private XTable Tbl_Label;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 // End of variables declaration//GEN-END:variables
}
