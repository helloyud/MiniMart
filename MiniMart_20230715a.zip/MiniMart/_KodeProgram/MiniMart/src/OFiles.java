class OFiles{

 class OFileLL{
  OFile File_;
  OFileLL Next;
  OFileLL(){
   File_=null;
   Next=null;
  }
 }
 OFileLL BeforeFirst;
 OFileLL Last;
 OFileLL BeforeReadCursor;
 OFileLL ReadCursor;
 int ReadCursorIndex; // -1 .. Length
 int Length; // 0 .. file count

 public OFiles(){
  BeforeFirst=new OFileLL();
  Last=BeforeFirst;
  Length=0;
  ReadCursorIndex=-1;
  BeforeReadCursor=null;
  ReadCursor=null;
 }


 public int getLength(){
  return Length;
 }
 public void clear(){
  BeforeFirst.Next=null;
  Last=BeforeFirst;
  Length=0;
  ReadCursorIndex=-1;
  BeforeReadCursor=null;
  ReadCursor=null;
 }
 public void append(OFile File_){
  OFileLL FileLL=new OFileLL();
  FileLL.File_=File_;
  Last.Next=FileLL;
  Last=FileLL;
  Length=Length+1;
 }
 
 public int getReadIndex(){
  return ReadCursorIndex;
 }
 public boolean resetReadIndex(){
  boolean ret=true;
  if(Length!=0){
   BeforeReadCursor=BeforeFirst;
   ReadCursor=BeforeReadCursor.Next;
   ReadCursorIndex=0;
  }
  else{ret=false;}
  return ret;
 }
 public OFile getFromReadIndex(boolean Remove){
  OFile ret=null;
  // only if ReadCursorIndex != -1 && ReadCursorIndex != Length
  if(ReadCursorIndex!=-1 && ReadCursorIndex!=Length){
   if(Remove==false){
    if(ReadCursor.File_!=null){
     ret=new OFile(ReadCursor.File_);
    }
    BeforeReadCursor=ReadCursor;
    ReadCursor=BeforeReadCursor.Next;
    ReadCursorIndex=ReadCursorIndex+1;
   }
   else{
    ret=ReadCursor.File_;
    if(Length==1){
     clear();
    }
    else{
     BeforeReadCursor.Next=ReadCursor.Next;
     ReadCursor=BeforeReadCursor.Next;
     Length=Length-1;
    }
   }
  }
  return ret;
 }
 
}