public abstract class OLabelData {
 
}