import java.util.Vector;

public abstract class OTableCellUpdater {

 OCustomModel Model; Vector<Object[]> Rows; int[] ColumnsType;
 int TableColumnIndex; // -1 no table's column index, >=0 table's column index

 void init(int TableColumnIndex){
  this.TableColumnIndex = TableColumnIndex;
 }

 void setModel(OCustomModel Model, Vector<Object[]> Rows, int[] ColumnsType){
  this.Model=Model;
  this.Rows=Rows;
  this.ColumnsType=ColumnsType;
 }
 void setModel(OCustomModel Model){
  setModel(Model, Model.getRows(), Model.getColumnsType());
 }
 Vector<Object[]> getRows(){
  if(Model==null){return Rows;}else{return Model.getRows();}
 }

 public abstract void update(int TableRowIndex);

}