public class OEditSubjectBankAccount {
 
 boolean EditBankPlatform; int EditBankPlatformMode; Integer EditedBankPlatformId; String EditedBankPlatformName;
 boolean EditAcc; int EditAccMode; boolean EditAccSub; String EditedAccSub; String EditedAcc;
 boolean EditComment; int EditCommentMode; boolean EditCommentSub; String EditedCommentSub; String EditedComment;
 
 public OEditSubjectBankAccount(){clearAll();}
 
 OEditSubjectBankAccount clearAll(){
  init(
   false, 0, -1, null,
   false, 0, false, null, null,
   false, 0, false, null, null);
  
  return this;
 }
 OEditSubjectBankAccount init(
  boolean EditBankPlatform, int EditBankPlatformMode, int EditedBankPlatformId, String EditedBankPlatformName,
  boolean EditAcc, int EditAccMode, boolean EditAccSub, String EditedAccSub, String EditedAcc,
  boolean EditComment, int EditCommentMode, boolean EditCommentSub, String EditedCommentSub, String EditedComment){
  
  this.EditBankPlatform = EditBankPlatform; this.EditBankPlatformMode = EditBankPlatformMode; this.EditedBankPlatformId = EditedBankPlatformId; this.EditedBankPlatformName = EditedBankPlatformName;
  this.EditAcc = EditAcc; this.EditAccMode = EditAccMode; this.EditAccSub = EditAccSub; this.EditedAccSub = EditedAccSub; this.EditedAcc = EditedAcc;
  this.EditComment = EditComment; this.EditCommentMode=EditCommentMode; this.EditCommentSub = EditCommentSub; this.EditedCommentSub = EditedCommentSub; this.EditedComment = EditedComment;
  
  return this;
 }
 
}