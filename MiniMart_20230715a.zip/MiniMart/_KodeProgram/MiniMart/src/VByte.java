public class VByte {

 byte Value;

 public VByte() {}
 public VByte(byte Value) {this.Value = Value;}
 
}