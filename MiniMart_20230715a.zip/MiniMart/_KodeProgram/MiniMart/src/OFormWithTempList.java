public interface OFormWithTempList {
 void fillTempList(long[] DataIds, boolean IsAdd);
 void clearTempList();
}