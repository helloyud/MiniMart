public class OCoordinate {
 double OffsetX;
 double OffsetY;
 double Width;
 double Height;
}