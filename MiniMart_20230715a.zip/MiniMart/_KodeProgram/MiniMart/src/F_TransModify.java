import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_TransModify extends XFormDialog {
 
 OCustomComboBoxModel ComboMdlTransType;
 OCustomComboBoxModel ComboMdlCashIn;
 OCustomComboBoxModel ComboMdlCashOut;
 
 String DbTable;
 String DbAppLock;
 String TransName;
 
 // set
 int wMode; // 1 add, 2 edit
 boolean wIsPreTrans;
 long wTransId;
 OInfoTrans wInfoTrans;
 
 // get
 long TransId;
 Date TransDate;
 int TransTypeId; String TransTypeName;
 int CashOutId; String CashOutName;
 String CashOutComment;
 int CashInId; String CashInName;
 String CashInComment;
 long TransSubjectId; String TransSubjectName;
 long TransSalesmanId; String TransSalesmanName;
 int TransCreditDays;
	Date TransRepayPeriodStart, TransRepayPeriodEnd;
 boolean TransImportant;
 String TransComment;
 String TransInfoIdExternal;
 
 /**
  * Creates new form F_TransModify
  */
 public F_TransModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  ComboMdlTransType=new OCustomComboBoxModel();
  ComboMdlTransType.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_TransType.setModel(ComboMdlTransType);
  
  ComboMdlCashIn=new OCustomComboBoxModel();
  ComboMdlCashIn.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_CashIn.setModel(ComboMdlCashIn);
  
  ComboMdlCashOut=new OCustomComboBoxModel();
  ComboMdlCashOut.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_CashOut.setModel(ComboMdlCashOut);
  
  CB_RepaymentPeriodActionPerformed(null);
  
  clearComponents();
 }
 
 void clearComponents(){
  TF_Id.setText("");
  CB_Important.setSelected(false);
  Lbl_InfoIdExternal.setForeground(CGUI.Color_Label_InputRight); TF_InfoIdExternal.setText("");
  Lbl_Date.setForeground(CGUI.Color_Label_InputRight); TF_DateYear.setText("");
  ComboMdlTransType.removeAll();
  Lbl_CashIn.setForeground(CGUI.Color_Label_InputRight); ComboMdlCashIn.removeAll(); TF_CashInComment.setText("");
  Lbl_CashOut.setForeground(CGUI.Color_Label_InputRight); ComboMdlCashOut.removeAll(); TF_CashOutComment.setText("");
  TF_Subject.setText("");
  TF_Salesman.setText("");
  Lbl_CreditDays.setForeground(CGUI.Color_Label_InputRight); TF_CreditDays.setText(""); clearCreditDaysInfo();
		Lbl_RepaymentPeriod.setForeground(CGUI.Color_Label_InputRight); CB_RepaymentPeriod.setSelected(false); CB_RepaymentPeriodActionPerformed(null);
  Lbl_Comment.setForeground(CGUI.Color_Label_InputRight); TA_Comment.setText("");
  
  clearSetVariables();
  Activ=false;
 }
 void clearSetVariables(){
  wInfoTrans=null;
 }
 
 private void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_Important,
    TF_InfoIdExternal,
    CmB_TransType,
    TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay,
    TF_CreditDays,
    CB_RepaymentPeriod, TF_RepayPeriodStartYear, CmB_RepayPeriodStartMonth, CmB_RepayPeriodStartDay, TF_RepayPeriodEndYear, CmB_RepayPeriodEndMonth, CmB_RepayPeriodEndDay,
    CmB_CashIn, TF_CashInComment,
    CmB_CashOut, TF_CashOutComment,
    Btn_ChooseSubject, Btn_ClearChoosedSubject,
    Btn_ChooseSalesman, Btn_ClearChoosedSalesman,
    TA_Comment,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
	void enableInputRepaymentPeriod(boolean Enable){
		PGUI.enableInput(Enable, TF_RepayPeriodStartYear, CmB_RepayPeriodStartMonth, CmB_RepayPeriodStartDay, false);
		PGUI.enableInput(Enable, TF_RepayPeriodEndYear, CmB_RepayPeriodEndMonth, CmB_RepayPeriodEndDay, false);
	}
	void updateValueTransDate(boolean AlsoUpdateCreditDaysInfo){
		TransDate=PGUI.valueOfDateComponent(TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay);
		if(AlsoUpdateCreditDaysInfo){refreshCreditDaysInfo();}
	}
	void updateValueTransCreditDays(boolean AlsoUpdateCreditDaysInfo){
		String str=TF_CreditDays.getText();
		do{
			if(!PText.checkInput(str, true, CCore.CharsCount_Int(), 2, 7, 0, 0)){TransCreditDays=-2; break;}
			if(str.length()==0){TransCreditDays=-1; break;}
			TransCreditDays=Integer.parseInt(str);
		}while(false);
		if(AlsoUpdateCreditDaysInfo){refreshCreditDaysInfo();}
	}
	void refreshCreditDaysInfo(){
		if(TransDate==null || TransCreditDays<=0){clearCreditDaysInfo(); return;}
		TF_CreditDaysInfo.setText(PText.dateToString(PDate.calculateDateByDay(TransDate, TransCreditDays, 1), 2));
	}
	void clearCreditDaysInfo(){TF_CreditDaysInfo.setText("");}
 
 void fillTransId(){TF_Id.setText(PText.separate(String.valueOf(TransId), " - ", PCore.primArr(4, 2, 2, 4, 4)));}
 void clearTransId(){TF_Id.setText("");}
 void fillTransIdAndDateInput(long Id, Date Dt){
  TransId=Id; fillTransId();
  PGUI.setDateComponent(Dt, TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay);
  updateValueTransDate(true);
 }
 void clearTransIdAndDateInput(){
  TransId=-1; clearTransId();
  TF_DateYear.setText(""); ComboBox_DateMonth.setSelectedIndex(0); ComboBox_DateDay.setSelectedIndex(0);
		updateValueTransDate(true);
 }
 void newTransId(){
  Date dt=new Date();
  TransId=PDatabase.addTransactionId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, wIsPreTrans, dt, null, true);
  if(TransId<0){
   if(TransId==-2){
    JOptionPane.showMessageDialog(null, "Gagal memulai "+TransName+" baru :"+
     "\nServer merespon terlalu lama ketika klien menunggu sebuah Id "+TransName+" baru !");
   }
   else{
    JOptionPane.showMessageDialog(null, "Gagal memulai "+TransName+" baru :"+
     "\nTerjadi kesalahan ketika klien menunggu sebuah Id "+TransName+" baru dari server !");
   }
   clearTransIdAndDateInput();
   Btn_Cancel.requestFocusInWindow();
   return;
  }
  fillTransIdAndDateInput(TransId, generateNewTransDate());
  Btn_Ok.requestFocusInWindow();
 }
 void removeCurrentTransId(){
  if(TransId==-1){return;}
  if(PDatabase.removeTransactionId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, wIsPreTrans, TransId, true)!=0){
   JOptionPane.showMessageDialog(null, "Gagal menghapus Id "+TransName+" saat ini !"+
    "\nSilahkan menghapus Id "+TransName+" tersebut secara manual !");
  }
 }
 Date generateNewTransDate(){
  Date ret=new Date();
  
  if(wIsPreTrans){ret=PDate.calculateDateByDay(ret, 1, 1);}
  
  return ret;
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  Lbl_Id = new javax.swing.JLabel();
  TF_Id = new javax.swing.JTextField();
  Lbl_Date = new javax.swing.JLabel();
  TF_DateYear = new javax.swing.JTextField();
  ComboBox_DateMonth = new javax.swing.JComboBox();
  CB_Important = new javax.swing.JCheckBox();
  TF_Subject = new javax.swing.JTextField();
  Btn_ClearChoosedSubject = new javax.swing.JButton();
  Btn_ChooseSubject = new javax.swing.JButton();
  Lbl_TransType = new javax.swing.JLabel();
  Lbl_Subject = new javax.swing.JLabel();
  Lbl_Comment = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_CommentHelp = new javax.swing.JLabel();
  Lbl_DateHelp = new javax.swing.JLabel();
  Btn_ClearChoosedSalesman = new javax.swing.JButton();
  Btn_ChooseSalesman = new javax.swing.JButton();
  TF_Salesman = new javax.swing.JTextField();
  Lbl_Salesman = new javax.swing.JLabel();
  TF_CreditDays = new javax.swing.JTextField();
  Lbl_CreditDaysHelp = new javax.swing.JLabel();
  Lbl_CreditDays = new javax.swing.JLabel();
  Lbl_CashOut = new javax.swing.JLabel();
  Lbl_CashIn = new javax.swing.JLabel();
  TF_RepayPeriodStartYear = new javax.swing.JTextField();
  CmB_RepayPeriodStartMonth = new javax.swing.JComboBox<>();
  CmB_RepayPeriodStartDay = new javax.swing.JComboBox<>();
  jLabel1 = new javax.swing.JLabel();
  CB_RepaymentPeriod = new javax.swing.JCheckBox();
  TF_RepayPeriodEndYear = new javax.swing.JTextField();
  CmB_RepayPeriodEndMonth = new javax.swing.JComboBox<>();
  CmB_RepayPeriodEndDay = new javax.swing.JComboBox<>();
  Lbl_RepaymentPeriodHelp = new javax.swing.JLabel();
  TF_CreditDaysInfo = new javax.swing.JTextField();
  ComboBox_DateDay = new javax.swing.JComboBox<>();
  Lbl_RepaymentPeriod = new javax.swing.JLabel();
  TF_InfoIdExternal = new javax.swing.JTextField();
  Lbl_InfoIdExternal = new javax.swing.JLabel();
  Lbl_InfoIdExternalHelp = new javax.swing.JLabel();
  CmB_TransType = new javax.swing.JComboBox<>();
  CmB_CashIn = new javax.swing.JComboBox<>();
  CmB_CashOut = new javax.swing.JComboBox<>();
  TF_CashInComment = new javax.swing.JTextField();
  TF_CashOutComment = new javax.swing.JTextField();
  Lbl_CashInCommentHelp = new javax.swing.JLabel();
  Lbl_CashOutCommentHelp = new javax.swing.JLabel();

  setTitle("Ubah Keterangan Transaksi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Lbl_Id.setText("Id");
  Lbl_Id.setRequestFocusEnabled(false);

  TF_Id.setEditable(false);
  TF_Id.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_Date.setText("Tgl Trans");
  Lbl_Date.setRequestFocusEnabled(false);

  TF_DateYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_DateYearFocusLost(evt);
   }
  });
  TF_DateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_DateYearKeyPressed(evt);
   }
  });

  ComboBox_DateMonth.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  ComboBox_DateMonth.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    ComboBox_DateMonthActionPerformed(evt);
   }
  });
  ComboBox_DateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_DateMonthKeyPressed(evt);
   }
  });

  CB_Important.setText("Penting");
  CB_Important.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Important.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ImportantKeyPressed(evt);
   }
  });

  TF_Subject.setEditable(false);
  TF_Subject.setBackground(new java.awt.Color(204, 255, 204));
  TF_Subject.setToolTipText("klik utk melihat keterangan subjek");
  TF_Subject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_Subject.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_SubjectMouseClicked(evt);
   }
  });

  Btn_ClearChoosedSubject.setText("-");
  Btn_ClearChoosedSubject.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearChoosedSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearChoosedSubjectActionPerformed(evt);
   }
  });
  Btn_ClearChoosedSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearChoosedSubjectKeyPressed(evt);
   }
  });

  Btn_ChooseSubject.setText("...");
  Btn_ChooseSubject.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseSubjectActionPerformed(evt);
   }
  });
  Btn_ChooseSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseSubjectKeyPressed(evt);
   }
  });

  Lbl_TransType.setText("Jenis Trans (Ops)");
  Lbl_TransType.setRequestFocusEnabled(false);

  Lbl_Subject.setText("Subjek (Ops)");
  Lbl_Subject.setRequestFocusEnabled(false);

  Lbl_Comment.setText("Ket. (Ops)");
  Lbl_Comment.setToolTipText("");
  Lbl_Comment.setRequestFocusEnabled(false);

  TA_Comment.setColumns(20);
  TA_Comment.setLineWrap(true);
  TA_Comment.setRows(5);
  TA_Comment.setWrapStyleWord(true);
  TA_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_Comment);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_CommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentHelp.setText("(?)");
  Lbl_CommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentHelpMouseClicked(evt);
   }
  });

  Lbl_DateHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DateHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_DateHelp.setText("(?)");
  Lbl_DateHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_DateHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_DateHelpMouseClicked(evt);
   }
  });

  Btn_ClearChoosedSalesman.setText("-");
  Btn_ClearChoosedSalesman.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearChoosedSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearChoosedSalesmanActionPerformed(evt);
   }
  });
  Btn_ClearChoosedSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearChoosedSalesmanKeyPressed(evt);
   }
  });

  Btn_ChooseSalesman.setText("...");
  Btn_ChooseSalesman.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseSalesmanActionPerformed(evt);
   }
  });
  Btn_ChooseSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseSalesmanKeyPressed(evt);
   }
  });

  TF_Salesman.setEditable(false);
  TF_Salesman.setBackground(new java.awt.Color(204, 255, 204));
  TF_Salesman.setToolTipText("klik utk melihat keterangan salesman");
  TF_Salesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_Salesman.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_SalesmanMouseClicked(evt);
   }
  });

  Lbl_Salesman.setText("Salesman (Ops)");

  TF_CreditDays.setToolTipText("Kosong input utk mengabaikan 'Lama Kredit'");
  TF_CreditDays.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_CreditDaysFocusLost(evt);
   }
  });
  TF_CreditDays.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CreditDaysKeyPressed(evt);
   }
  });

  Lbl_CreditDaysHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CreditDaysHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CreditDaysHelp.setText("(?)");
  Lbl_CreditDaysHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CreditDaysHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CreditDaysHelpMouseClicked(evt);
   }
  });

  Lbl_CreditDays.setText("Lama Kredit (Ops)");

  Lbl_CashOut.setText("Kas Keluar Tunai");

  Lbl_CashIn.setText("Kas Masuk Tunai");

  TF_RepayPeriodStartYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_RepayPeriodStartYearKeyPressed(evt);
   }
  });

  CmB_RepayPeriodStartMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01 Jan", "02 Feb", "03 Mar", "04 Apr", "05 Mei", "06 Jun", "07 Jul", "08 Agu", "09 Sep", "10 Okt", "11 Nop", "12 Des" }));
  CmB_RepayPeriodStartMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_RepayPeriodStartMonthKeyPressed(evt);
   }
  });

  CmB_RepayPeriodStartDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_RepayPeriodStartDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_RepayPeriodStartDayKeyPressed(evt);
   }
  });

  jLabel1.setText("-");

  CB_RepaymentPeriod.setText(" ");
  CB_RepaymentPeriod.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_RepaymentPeriod.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_RepaymentPeriodActionPerformed(evt);
   }
  });
  CB_RepaymentPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_RepaymentPeriodKeyPressed(evt);
   }
  });

  TF_RepayPeriodEndYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_RepayPeriodEndYearKeyPressed(evt);
   }
  });

  CmB_RepayPeriodEndMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01 Jan", "02 Feb", "03 Mar", "04 Apr", "05 Mei", "06 Jun", "07 Jul", "08 Agu", "09 Sep", "10 Okt", "11 Nop", "12 Des" }));
  CmB_RepayPeriodEndMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_RepayPeriodEndMonthKeyPressed(evt);
   }
  });

  CmB_RepayPeriodEndDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_RepayPeriodEndDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_RepayPeriodEndDayKeyPressed(evt);
   }
  });

  Lbl_RepaymentPeriodHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_RepaymentPeriodHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_RepaymentPeriodHelp.setText("(?)");
  Lbl_RepaymentPeriodHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_RepaymentPeriodHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_RepaymentPeriodHelpMouseClicked(evt);
   }
  });

  TF_CreditDaysInfo.setEditable(false);
  TF_CreditDaysInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_CreditDaysInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  TF_CreditDaysInfo.setToolTipText("Tanggal Tagih");

  ComboBox_DateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_DateDay.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    ComboBox_DateDayActionPerformed(evt);
   }
  });
  ComboBox_DateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_DateDayKeyPressed(evt);
   }
  });

  Lbl_RepaymentPeriod.setText("Periode Cicil");

  TF_InfoIdExternal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_InfoIdExternalKeyPressed(evt);
   }
  });

  Lbl_InfoIdExternal.setText("{ Id External }");

  Lbl_InfoIdExternalHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_InfoIdExternalHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_InfoIdExternalHelp.setText("(?)");
  Lbl_InfoIdExternalHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_InfoIdExternalHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_InfoIdExternalHelpMouseClicked(evt);
   }
  });

  CmB_TransType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_TransTypeKeyPressed(evt);
   }
  });

  CmB_CashIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_CashInKeyPressed(evt);
   }
  });

  CmB_CashOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_CashOutKeyPressed(evt);
   }
  });

  TF_CashInComment.setToolTipText("Keterangan kas masuk tunai");
  TF_CashInComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CashInCommentKeyPressed(evt);
   }
  });

  TF_CashOutComment.setToolTipText("Keterangan kas keluar tunai");
  TF_CashOutComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CashOutCommentKeyPressed(evt);
   }
  });

  Lbl_CashInCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CashInCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CashInCommentHelp.setText("(?)");
  Lbl_CashInCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CashInCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CashInCommentHelpMouseClicked(evt);
   }
  });

  Lbl_CashOutCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CashOutCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CashOutCommentHelp.setText("(?)");
  Lbl_CashOutCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CashOutCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CashOutCommentHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_Id)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_Date)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_DateHelp))
     .addComponent(Lbl_TransType)
     .addComponent(Lbl_CashOut)
     .addComponent(Lbl_Subject)
     .addComponent(Lbl_CashIn)
     .addComponent(Lbl_Salesman)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_CreditDays)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CreditDaysHelp))
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_RepaymentPeriod)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_RepaymentPeriodHelp))
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_Comment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CommentHelp))
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_InfoIdExternal)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_InfoIdExternalHelp)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(TF_Salesman)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseSalesman)
      .addGap(3, 3, 3)
      .addComponent(Btn_ClearChoosedSalesman))
     .addGroup(layout.createSequentialGroup()
      .addComponent(TF_Subject)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseSubject)
      .addGap(3, 3, 3)
      .addComponent(Btn_ClearChoosedSubject))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(TF_Id)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_Important))
     .addGroup(layout.createSequentialGroup()
      .addComponent(TF_DateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_DateMonth, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_DateDay, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(jScrollPane1)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(TF_CreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_CreditDaysInfo))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(CB_RepaymentPeriod)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(layout.createSequentialGroup()
        .addGap(0, 0, Short.MAX_VALUE)
        .addComponent(Btn_Ok)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_Cancel))
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_RepayPeriodStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_RepayPeriodStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_RepayPeriodStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(jLabel1)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_RepayPeriodEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_RepayPeriodEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_RepayPeriodEndDay, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
     .addComponent(TF_InfoIdExternal)
     .addComponent(CmB_TransType, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CmB_CashIn, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CmB_CashOut, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(layout.createSequentialGroup()
      .addComponent(TF_CashInComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CashInCommentHelp))
     .addGroup(layout.createSequentialGroup()
      .addComponent(TF_CashOutComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CashOutCommentHelp)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Id)
     .addComponent(TF_Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Important))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_InfoIdExternal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_InfoIdExternal)
     .addComponent(Lbl_InfoIdExternalHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_TransType)
     .addComponent(CmB_TransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Date)
     .addComponent(ComboBox_DateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DateHelp)
     .addComponent(ComboBox_DateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CreditDaysHelp)
     .addComponent(Lbl_CreditDays)
     .addComponent(TF_CreditDaysInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(CB_RepaymentPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_RepaymentPeriod)
      .addComponent(Lbl_RepaymentPeriodHelp))
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_RepayPeriodStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_RepayPeriodStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_RepayPeriodStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(jLabel1)
      .addComponent(TF_RepayPeriodEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_RepayPeriodEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_RepayPeriodEndDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_CashIn)
     .addComponent(CmB_CashIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CashInComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashInCommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_CashOut)
     .addComponent(CmB_CashOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CashOutComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashOutCommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Subject)
     .addComponent(TF_Subject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ClearChoosedSubject)
     .addComponent(Btn_ChooseSubject))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Salesman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ClearChoosedSalesman)
     .addComponent(Btn_ChooseSalesman)
     .addComponent(Lbl_Salesman))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(Lbl_Comment)
       .addComponent(Lbl_CommentHelp))
      .addGap(0, 0, Short.MAX_VALUE)))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Lbl_CommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_CommentHelpMouseClicked

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean bool;
		boolean currvalid;
		StringBuilder error;
  Object[] objs;
		
		updateValueTransDate(false);
		updateValueTransCreditDays(true);
  
  // first phase validation
		if(wMode==1 && TransId==-1){
   JOptionPane.showMessageDialog(null, "Tidak dapat memproses : Id "+TransName+" tidak ada !");
   return;
  }
  
  bool=true;
  
		TransImportant=CB_Important.isSelected();
		
  if(TransDate!=null){
			Lbl_Date.setForeground(CGUI.Color_Label_InputRight);
  }
  else{
   Lbl_Date.setForeground(CGUI.Color_Label_InputWrong);
   bool=false;
  }
  
		if(TransCreditDays!=-2){
   Lbl_CreditDays.setForeground(CGUI.Color_Label_InputRight);
  }
  else{
   Lbl_CreditDays.setForeground(CGUI.Color_Label_InputWrong);
   bool=false;
  }
		
		currvalid=true;
		TransRepayPeriodStart=null;
		TransRepayPeriodEnd=null;
		if(CB_RepaymentPeriod.isSelected()){
			currvalid=false;
			do{
				TransRepayPeriodStart=PGUI.valueOfDateComponent(TF_RepayPeriodStartYear, CmB_RepayPeriodStartMonth, CmB_RepayPeriodStartDay); if(TransRepayPeriodStart==null){break;}
				TransRepayPeriodEnd=PGUI.valueOfDateComponent(TF_RepayPeriodEndYear, CmB_RepayPeriodEndMonth, CmB_RepayPeriodEndDay); if(TransRepayPeriodEnd==null){break;}
				if(PDate.grading(TransRepayPeriodStart, TransRepayPeriodEnd, Long.MIN_VALUE)==1){break;}
				currvalid=true;
			}while(false);
		}
		if(currvalid){
			Lbl_RepaymentPeriod.setForeground(CGUI.Color_Label_InputRight);
		}
		else{
			Lbl_RepaymentPeriod.setForeground(CGUI.Color_Label_InputWrong);
			bool=false;
		}
  
  TransComment=TA_Comment.getText();
		if(PText.checkInput(TransComment, true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)){
   Lbl_Comment.setForeground(CGUI.Color_Label_InputRight);
			if(TransComment.length()==0){TransComment=null;}
  }
  else{
   Lbl_Comment.setForeground(CGUI.Color_Label_InputWrong);
   bool=false;
  }
  
  TransInfoIdExternal=TF_InfoIdExternal.getText();
		if(PText.checkInput(TransInfoIdExternal, true, 100, 0, 0, 0, 0)){
   Lbl_InfoIdExternal.setForeground(CGUI.Color_Label_InputRight);
			if(TransInfoIdExternal.length()==0){TransInfoIdExternal=null;}
  }
  else{
   Lbl_InfoIdExternal.setForeground(CGUI.Color_Label_InputWrong);
   bool=false;
  }
  
  CashInComment=TF_CashInComment.getText();
		if(PText.checkInput(CashInComment, true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)){
   Lbl_CashIn.setForeground(CGUI.Color_Label_InputRight);
			if(CashInComment.length()==0){CashInComment=null;}
  }
  else{
   Lbl_CashIn.setForeground(CGUI.Color_Label_InputWrong);
   bool=false;
  }
  
  CashOutComment=TF_CashOutComment.getText();
		if(PText.checkInput(CashOutComment, true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)){
   Lbl_CashOut.setForeground(CGUI.Color_Label_InputRight);
			if(CashOutComment.length()==0){CashOutComment=null;}
  }
  else{
   Lbl_CashOut.setForeground(CGUI.Color_Label_InputWrong);
   bool=false;
  }
  
  objs=ComboMdlTransType.Mdl.Rows.elementAt(CmB_TransType.getSelectedIndex()); TransTypeId=PCore.objInteger(objs[0], -1); TransTypeName=PCore.objString(objs[1], null);
  objs=ComboMdlCashIn.Mdl.Rows.elementAt(CmB_CashIn.getSelectedIndex()); CashInId=PCore.objInteger(objs[0], -1); CashInName=PCore.objString(objs[1], null);
  objs=ComboMdlCashOut.Mdl.Rows.elementAt(CmB_CashOut.getSelectedIndex()); CashOutId=PCore.objInteger(objs[0], -1); CashOutName=PCore.objString(objs[1], null);
  
  if(!bool){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+"Silahkan perbaiki masukan pada label berwarna merah !");
			return;
  }
		
		// second phase validation
		error=new StringBuilder();
		
		if(CB_RepaymentPeriod.isSelected()){
			if(TransCreditDays==-1){
				error.append("\n- Jika 'Periode Cicil' diisi, maka 'Lama Kredit' tdk boleh kosong !");
				bool=false;
			}
			else{
				if(PDate.grading(TransRepayPeriodEnd, PDate.calculateDateByDay(TransDate, TransCreditDays, 1), Long.MIN_VALUE)!=2){
					error.append("\n- Tanggal Akhir 'Periode Cicil' harus sebelum 'Tgl Tagih' !");
					bool=false;
				}
			}
		}
		
		if(!bool){
			JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+error.toString());
			return;
		}
		
		//
		DialogResult=1;
  clearComponents();
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  Date dt, dt1, dt2;
  
  if(Activ){return;}
  
  Activ=true;
  
  DbTable=PText.getString(!wIsPreTrans, "Trans", "PreTrans");
  DbAppLock=PText.getString(!wIsPreTrans, IFV.TransLock, IFV.PreTransLock);
  TransName=PText.getString(!wIsPreTrans, "Transaksi", "Pra-Transaksi");
  
  setTitle(PText.getString(wMode==1, "Tambah Data "+TransName+" Baru", "Ubah Data "+TransName));

  TransSubjectId=-1;
  TransSalesmanId=-1;
  TransCreditDays=-1;
  
  PDatabase.queryToComboBox(IFV.Stm, "select Id, Name from TransType", ComboMdlTransType, true, PCore.refArr("Tidak Didefenisikan")); CmB_TransType.setSelectedIndex(0);
  PDatabase.queryToComboBox(IFV.Stm, "select Id, Name from Cash", ComboMdlCashIn, true, PCore.refArr("Tidak Didefenisikan")); CmB_CashIn.setSelectedIndex(0);
  ComboMdlCashOut.append(ComboMdlCashIn.getRows()); CmB_CashOut.setSelectedIndex(0);
  
  if(wMode==1){
   newTransId();
   dt=TransDate; if(dt==null){dt=generateNewTransDate();}
			dt1=PDate.calculateDateByDay(dt, 30, 1);
			dt2=PDate.calculateDateByDay(dt1, 1, 2);
   PGUI.setDateComponent(dt, TF_RepayPeriodStartYear, CmB_RepayPeriodStartMonth, CmB_RepayPeriodStartDay);
   PGUI.setDateComponent(dt2, TF_RepayPeriodEndYear, CmB_RepayPeriodEndMonth, CmB_RepayPeriodEndDay);
  }
  else{
   TransId=wTransId; fillTransId();
   CB_Important.setSelected(wInfoTrans.Important);
   if(wInfoTrans.InfoIdExternal!=null){TF_InfoIdExternal.setText(wInfoTrans.InfoIdExternal);}

   TransDate=wInfoTrans.Dt;
   PGUI.setDateComponent(wInfoTrans.Dt, TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay);
   TransCreditDays=wInfoTrans.CreditDays;
   if(TransCreditDays!=-1){TF_CreditDays.setText(String.valueOf(wInfoTrans.CreditDays));}
   refreshCreditDaysInfo();
   if(TransCreditDays==-1 || wInfoTrans.RepaymentPeriodStart==null || wInfoTrans.RepaymentPeriodEnd==null){
    CB_RepaymentPeriod.setSelected(false); CB_RepaymentPeriodActionPerformed(null);
   }
   else{
    CB_RepaymentPeriod.setSelected(true); CB_RepaymentPeriodActionPerformed(null);
    PGUI.setDateComponent(wInfoTrans.RepaymentPeriodStart, TF_RepayPeriodStartYear, CmB_RepayPeriodStartMonth, CmB_RepayPeriodStartDay);
    PGUI.setDateComponent(wInfoTrans.RepaymentPeriodEnd, TF_RepayPeriodEndYear, CmB_RepayPeriodEndMonth, CmB_RepayPeriodEndDay);
   }

   PGUI.findAndSelect_Number_ComboBox(ComboMdlTransType, CmB_TransType, 0, wInfoTrans.TypeId, true, -1, true, 0, true, 0);
   PGUI.findAndSelect_Number_ComboBox(ComboMdlCashIn, CmB_CashIn, 0, wInfoTrans.CashInId, true, -1, true, 0, true, 0);
   PGUI.findAndSelect_Number_ComboBox(ComboMdlCashOut, CmB_CashOut, 0, wInfoTrans.CashOutId, true, -1, true, 0, true, 0);
   TransSubjectId=wInfoTrans.SubjectId;
   if(TransSubjectId!=-1){TransSubjectName=wInfoTrans.SubjectName; TF_Subject.setText(TransSubjectName);}
   TransSalesmanId=wInfoTrans.SalesmanId;
   if(TransSalesmanId!=-1){TransSalesmanName=wInfoTrans.SalesmanName; TF_Salesman.setText(TransSalesmanName);}

   if(wInfoTrans.Comment!=null){TA_Comment.setText(wInfoTrans.Comment);}
   
   if(wInfoTrans.CashInComment!=null){TF_CashInComment.setText(wInfoTrans.CashInComment);}
   if(wInfoTrans.CashOutComment!=null){TF_CashOutComment.setText(wInfoTrans.CashOutComment);}
   
   TA_Comment.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  if(wMode==1){removeCurrentTransId();}
  DialogResult=0;
  clearComponents();
 }//GEN-LAST:event_formWindowClosing

 private void Btn_ChooseSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseSubjectActionPerformed
  IFV.FSubject.wMode=1;
  IFV.FSubject.wAllowMultipleSelection=false;
  IFV.FSubject.wDialogWithFItem=false;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   TransSubjectId=IFV.FSubject.ChoosedId[0];
   TransSubjectName=IFV.FSubject.ChoosedName[0];
   TF_Subject.setText(TransSubjectName);
  }
 }//GEN-LAST:event_Btn_ChooseSubjectActionPerformed

 private void Btn_ClearChoosedSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSubjectActionPerformed
  TransSubjectId=-1;
  TF_Subject.setText("");
 }//GEN-LAST:event_Btn_ClearChoosedSubjectActionPerformed

 private void Lbl_DateHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_DateHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "Tahun hanya boleh bernilai 1 - 999999.");
 }//GEN-LAST:event_Lbl_DateHelpMouseClicked

 private void Lbl_CreditDaysHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CreditDaysHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- 'Lama Kredit' diinput dalam satuan hari.\n"+PText.getInputInfo(true, 9, 2, 7, 0, 0, false));
 }//GEN-LAST:event_Lbl_CreditDaysHelpMouseClicked

 private void Btn_ChooseSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseSalesmanActionPerformed
  IFV.FSubject.wMode=1;
  IFV.FSubject.wAllowMultipleSelection=false;
  IFV.FSubject.wDialogWithFItem=false;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   TransSalesmanId=IFV.FSubject.ChoosedId[0];
   TransSalesmanName=IFV.FSubject.ChoosedName[0];
   TF_Salesman.setText(TransSalesmanName);
  }
 }//GEN-LAST:event_Btn_ChooseSalesmanActionPerformed

 private void Btn_ClearChoosedSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSalesmanActionPerformed
  TransSalesmanId=-1;
  TF_Salesman.setText("");
 }//GEN-LAST:event_Btn_ClearChoosedSalesmanActionPerformed

 private void Lbl_RepaymentPeriodHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_RepaymentPeriodHelpMouseClicked
  JOptionPane.showMessageDialog(null,
			"- 'Periode Cicil' sebaiknya diisi jika transaksi memiliki utang.\n"+
			"- 'Periode Cicil' digunakan utk menghitung cicilan harian utk melunasi utang.\n"+
			"- Inputan 'Peride Cicil' bersifat opsional (boleh dikosongkan).\n"+
			"- Jika 'Periode Cicil' diisi, maka 'Lama Cicilan' tdk boleh kosong.\n"+
			"- Tgl Akhir 'Periode Cicil' < 'Tgl Tagih'.\n"+
			"- Tgl Awal 'Periode Cicil' <= Tgl Akhir 'Periode Cicil'.");
 }//GEN-LAST:event_Lbl_RepaymentPeriodHelpMouseClicked

 private void CB_RepaymentPeriodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_RepaymentPeriodActionPerformed
  enableInputRepaymentPeriod(CB_RepaymentPeriod.isSelected());
 }//GEN-LAST:event_CB_RepaymentPeriodActionPerformed

 private void ComboBox_DateMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_DateMonthActionPerformed
  updateValueTransDate(true); 
 }//GEN-LAST:event_ComboBox_DateMonthActionPerformed

 private void TF_DateYearFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_DateYearFocusLost
  updateValueTransDate(true);
 }//GEN-LAST:event_TF_DateYearFocusLost

 private void TF_CreditDaysFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CreditDaysFocusLost
  updateValueTransCreditDays(true);
 }//GEN-LAST:event_TF_CreditDaysFocusLost

 private void TF_CreditDaysKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CreditDaysKeyPressed
  int consumed=PNav.onKey_TF(this, TF_CreditDays, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DateYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_RepaymentPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
			case KeyEvent.VK_ENTER : updateValueTransCreditDays(true); break;
		}
 }//GEN-LAST:event_TF_CreditDaysKeyPressed

 private void ComboBox_DateDayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_DateDayActionPerformed
  updateValueTransDate(true);
 }//GEN-LAST:event_ComboBox_DateDayActionPerformed

 private void Lbl_InfoIdExternalHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_InfoIdExternalHelpMouseClicked
  JOptionPane.showMessageDialog(null, 
   "- Id External = keterangan bukti fisik nota."+"\n"+
   PText.getInputInfo(true, 100, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_InfoIdExternalHelpMouseClicked

 private void Lbl_CashInCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CashInCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_CashInCommentHelpMouseClicked

 private void Lbl_CashOutCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CashOutCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_CashOutCommentHelpMouseClicked

 private void TF_SubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_SubjectMouseClicked
  if(TransSubjectId==-1){return;}
  
  PMyShop.viewFormInfo(TransSubjectId, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_SubjectMouseClicked

 private void TF_SalesmanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_SalesmanMouseClicked
  if(TransSalesmanId==-1){return;}
  
  PMyShop.viewFormInfo(TransSalesmanId, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_SalesmanMouseClicked

 private void CB_ImportantKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ImportantKeyPressed
  PNav.onKey_CB(this, CB_Important, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_InfoIdExternal)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_ImportantKeyPressed

 private void TF_InfoIdExternalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_InfoIdExternalKeyPressed
  PNav.onKey_TF(this, TF_InfoIdExternal, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Important)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_TransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_InfoIdExternalKeyPressed

 private void CmB_TransTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_TransTypeKeyPressed
  PNav.onKey_CmB(this, CmB_TransType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_InfoIdExternal)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_DateYear)));
 }//GEN-LAST:event_CmB_TransTypeKeyPressed

 private void TF_DateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_DateYearKeyPressed
  PNav.onKey_TF(this, TF_DateYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_TransType)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CreditDays)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_DateMonth)));
 }//GEN-LAST:event_TF_DateYearKeyPressed

 private void ComboBox_DateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_DateMonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_DateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_DateYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_DateDay)));
 }//GEN-LAST:event_ComboBox_DateMonthKeyPressed

 private void ComboBox_DateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_DateDayKeyPressed
  PNav.onKey_CmB(this, ComboBox_DateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_DateMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CreditDays)));
 }//GEN-LAST:event_ComboBox_DateDayKeyPressed

 private void CB_RepaymentPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_RepaymentPeriodKeyPressed
  PNav.onKey_CB(this, CB_RepaymentPeriod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CreditDays)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_CashIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_RepayPeriodStartYear)));
 }//GEN-LAST:event_CB_RepaymentPeriodKeyPressed

 private void TF_RepayPeriodStartYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_RepayPeriodStartYearKeyPressed
  PNav.onKey_TF(this, TF_RepayPeriodStartYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CreditDays)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_CashIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_RepayPeriodStartMonth)));
 }//GEN-LAST:event_TF_RepayPeriodStartYearKeyPressed

 private void CmB_RepayPeriodStartMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_RepayPeriodStartMonthKeyPressed
  PNav.onKey_CmB(this, CmB_RepayPeriodStartMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_RepayPeriodStartYear, CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_RepayPeriodStartDay)));
 }//GEN-LAST:event_CmB_RepayPeriodStartMonthKeyPressed

 private void CmB_RepayPeriodStartDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_RepayPeriodStartDayKeyPressed
  PNav.onKey_CmB(this, CmB_RepayPeriodStartDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_RepayPeriodStartMonth, CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_RepayPeriodEndYear)));
 }//GEN-LAST:event_CmB_RepayPeriodStartDayKeyPressed

 private void TF_RepayPeriodEndYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_RepayPeriodEndYearKeyPressed
  PNav.onKey_TF(this, TF_RepayPeriodEndYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CreditDays)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_CashIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_RepayPeriodStartDay, CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_RepayPeriodEndMonth)));
 }//GEN-LAST:event_TF_RepayPeriodEndYearKeyPressed

 private void CmB_RepayPeriodEndMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_RepayPeriodEndMonthKeyPressed
  PNav.onKey_CmB(this, CmB_RepayPeriodEndMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_RepayPeriodEndYear, CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_RepayPeriodEndDay)));
 }//GEN-LAST:event_CmB_RepayPeriodEndMonthKeyPressed

 private void CmB_RepayPeriodEndDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_RepayPeriodEndDayKeyPressed
  PNav.onKey_CmB(this, CmB_RepayPeriodEndDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_RepayPeriodEndMonth, CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_CashIn)));
 }//GEN-LAST:event_CmB_RepayPeriodEndDayKeyPressed

 private void CmB_CashInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_CashInKeyPressed
  PNav.onKey_CmB(this, CmB_CashIn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_RepaymentPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CashInComment)));
 }//GEN-LAST:event_CmB_CashInKeyPressed

 private void TF_CashInCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CashInCommentKeyPressed
  PNav.onKey_TF(this, TF_CashInComment, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_CashIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_CashOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_CashInCommentKeyPressed

 private void CmB_CashOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_CashOutKeyPressed
  PNav.onKey_CmB(this, CmB_CashOut, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CashInComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CashOutComment)));
 }//GEN-LAST:event_CmB_CashOutKeyPressed

 private void TF_CashOutCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CashOutCommentKeyPressed
  PNav.onKey_TF(this, TF_CashOutComment, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_CashOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseSubject)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_CashOutCommentKeyPressed

 private void Btn_ChooseSubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseSubjectKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseSubject, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CashOutComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearChoosedSubject)));
 }//GEN-LAST:event_Btn_ChooseSubjectKeyPressed

 private void Btn_ClearChoosedSubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSubjectKeyPressed
  PNav.onKey_Btn(this, Btn_ClearChoosedSubject, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CashOutComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ClearChoosedSalesman)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseSubject)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ClearChoosedSubjectKeyPressed

 private void Btn_ChooseSalesmanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseSalesmanKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseSalesman, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseSubject)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearChoosedSalesman)));
 }//GEN-LAST:event_Btn_ChooseSalesmanKeyPressed

 private void Btn_ClearChoosedSalesmanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSalesmanKeyPressed
  PNav.onKey_Btn(this, Btn_ClearChoosedSalesman, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ClearChoosedSubject)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ClearChoosedSalesmanKeyPressed

 private void TA_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentKeyPressed
  PNav.onKey_TA(this, TA_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_CommentKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseSalesman;
 private javax.swing.JButton Btn_ChooseSubject;
 private javax.swing.JButton Btn_ClearChoosedSalesman;
 private javax.swing.JButton Btn_ClearChoosedSubject;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_Important;
 private javax.swing.JCheckBox CB_RepaymentPeriod;
 private javax.swing.JComboBox<String> CmB_CashIn;
 private javax.swing.JComboBox<String> CmB_CashOut;
 private javax.swing.JComboBox<String> CmB_RepayPeriodEndDay;
 private javax.swing.JComboBox<String> CmB_RepayPeriodEndMonth;
 private javax.swing.JComboBox<String> CmB_RepayPeriodStartDay;
 private javax.swing.JComboBox<String> CmB_RepayPeriodStartMonth;
 private javax.swing.JComboBox<String> CmB_TransType;
 private javax.swing.JComboBox<String> ComboBox_DateDay;
 private javax.swing.JComboBox ComboBox_DateMonth;
 private javax.swing.JLabel Lbl_CashIn;
 private javax.swing.JLabel Lbl_CashInCommentHelp;
 private javax.swing.JLabel Lbl_CashOut;
 private javax.swing.JLabel Lbl_CashOutCommentHelp;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_CommentHelp;
 private javax.swing.JLabel Lbl_CreditDays;
 private javax.swing.JLabel Lbl_CreditDaysHelp;
 private javax.swing.JLabel Lbl_Date;
 private javax.swing.JLabel Lbl_DateHelp;
 private javax.swing.JLabel Lbl_Id;
 private javax.swing.JLabel Lbl_InfoIdExternal;
 private javax.swing.JLabel Lbl_InfoIdExternalHelp;
 private javax.swing.JLabel Lbl_RepaymentPeriod;
 private javax.swing.JLabel Lbl_RepaymentPeriodHelp;
 private javax.swing.JLabel Lbl_Salesman;
 private javax.swing.JLabel Lbl_Subject;
 private javax.swing.JLabel Lbl_TransType;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextField TF_CashInComment;
 private javax.swing.JTextField TF_CashOutComment;
 private javax.swing.JTextField TF_CreditDays;
 private javax.swing.JTextField TF_CreditDaysInfo;
 private javax.swing.JTextField TF_DateYear;
 private javax.swing.JTextField TF_Id;
 private javax.swing.JTextField TF_InfoIdExternal;
 private javax.swing.JTextField TF_RepayPeriodEndYear;
 private javax.swing.JTextField TF_RepayPeriodStartYear;
 private javax.swing.JTextField TF_Salesman;
 private javax.swing.JTextField TF_Subject;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
