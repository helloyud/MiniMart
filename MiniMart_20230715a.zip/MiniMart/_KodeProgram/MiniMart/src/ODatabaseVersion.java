public class ODatabaseVersion {

 int Version;
 int SubVariant;

 public ODatabaseVersion(int Version, int SubVariant) {
  this.Version = Version;
  this.SubVariant = SubVariant;
 }

 public String toString(){
  return Version+"-"+SubVariant;
 }

}