import java.awt.Color;
import javax.swing.JOptionPane;

public class CGUI {

 // table column's width
  // number (without thousand separator) - suffix n digit
 static int ColNum03=30;
 static int ColNum04=40;
 static int ColNum06=55;
	static int ColNum09=75;
 static int ColNum13=100;
 static int ColNum16=120;
  // number (with thousand separator) - suffix n digit
 static int ColNumSep04=45;
 static int ColNumSep06=55;
 static int ColNumSep09=80;
 static int ColNumSep09_a=85;
  // currency (with fractional digit) - suffix n digit & n fractional digit
 static int ColCur09_02=100;
  // text
 static int ColTextMini=45;
 static int ColTextTiny=55;
 static int ColTextSml=130;
 static int ColTextMed=285;
 static int ColTextLrg=400;
  // date
 static int ColDate=85;
  // check box
 static int ColCheck=25;
 
 // colour
  // basic colour
 public static Color White = new Color(255, 255, 255);
 public static Color Black = new Color(0, 0, 0);
 public static Color Gray128 = new Color(128, 128, 128);
 public static Color Gray240 = new Color(240, 240, 240);
 public static Color Green = new Color(204, 255, 204);
 public static Color Blue = new Color(230, 230, 255);
 public static Color Yellow = new Color(255, 255, 204);
 
  // application's rule colour
 public static Color Color_Background_Blue_1 = new Color(230, 230, 255);
 public static Color Color_Background_Blue_2 = new Color(204, 204, 255);
 public static Color Color_Background_Red_1 = new Color(255, 220, 209);
 public static Color Color_Foreground_Red102 = new Color(102, 0, 0);
 public static Color Color_Foreground_Red153 = new Color(153, 0, 0);
 public static Color Color_Foreground_Red_1 = new Color(153, 61, 2);
 
 public static Color Color_Label_InputPrimary = new Color(0, 0, 0);
 public static Color Color_Label_InputSecondary = new Color(153, 102, 0);
 public static Color Color_Label_InputRight = new Color(0, 0, 0);
 public static Color Color_Label_InputWrong = new Color(255, 0, 0);
 
 public static Color Color_TextBox_Disable = new Color(128, 128, 128);
 public static Color Color_TextBox_Uneditable = new Color(204, 255, 204);
 public static Color Color_TextBox_FocusOff = new Color(255, 255, 255);
 public static Color Color_TextBox_FocusOn = new Color(255, 255, 204);
 
 public static Color Color_ToggleButton_Selected = new Color(204,204,0);
 
  // gui component colour
 final static Color Color_Form_Background = new Color(238, 232, 213); /* default is : UIManager.getColor("Panel.background") */
 
 //
 final static int FocusState_Leave = 0;
 final static int FocusState_Enter = 1;
 final static int FocusState_Work = 2;
 
 // JOptionPane's Dialog Variables
 final static int DialogType_Message = 1;
 final static int DialogType_Confirm = 2;
 final static int DialogAnswerType_YesNo = JOptionPane.YES_NO_OPTION;
 final static int DialogAnswerType_OkCancel = JOptionPane.OK_CANCEL_OPTION;
 final static int DialogAnswerValue_Yes = JOptionPane.YES_OPTION;
 final static int DialogAnswerValue_No = JOptionPane.NO_OPTION;
 final static int DialogAnswerValue_Ok = JOptionPane.OK_OPTION;
 final static int DialogAnswerValue_Cancel = JOptionPane.CANCEL_OPTION;

}