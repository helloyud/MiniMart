import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class F_ConvertRuleModifyMulti extends XFormDialog{
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeName; String NameSub; String Name;
 boolean ChangeIsActive; boolean IsActive;

 /**
  * Creates new form F_ItemSupplierModify
  */
 public F_ConvertRuleModifyMulti(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  PGUI.selectRadioButton(CApp.Default_ItemSupplier_Active, RB_IsActiveY, RB_IsActiveN);
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_Name, TF_NameSub, TF_Name,
    CB_IsActive, RB_IsActiveY, RB_IsActiveN,
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  CB_Name.setSelected(false); CB_Name.setForeground(CGUI.Color_Label_InputRight); TF_NameSub.setText(""); TF_Name.setText("");
  CB_IsActive.setSelected(false);
  
  clearSetVariables();
 }
 void clearSetVariables(){
  
 }
 void closingForm(int DialogResult){
  this.DialogResult=DialogResult;
  clearComponents();
  Activ=false;
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Active = new javax.swing.ButtonGroup();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_BuyPriceHelp = new javax.swing.JLabel();
  CB_Name = new javax.swing.JCheckBox();
  Lbl_DataCount = new javax.swing.JLabel();
  TF_NameSub = new javax.swing.JTextField();
  CB_IsActive = new javax.swing.JCheckBox();
  RB_IsActiveY = new javax.swing.JRadioButton();
  RB_IsActiveN = new javax.swing.JRadioButton();
  TF_Name = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  jLabel2 = new javax.swing.JLabel();

  setTitle("Ubah Data Dari Beberapa Aturan Konversi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_BuyPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceHelp.setText("(?)");
  Lbl_BuyPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceHelpMouseClicked(evt);
   }
  });

  CB_Name.setText("Nama");
  CB_Name.setToolTipText("");
  CB_Name.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_NameKeyPressed(evt);
   }
  });

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data");

  TF_NameSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameSubKeyPressed(evt);
   }
  });

  CB_IsActive.setText("Aktif");
  CB_IsActive.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsActive.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsActiveKeyPressed(evt);
   }
  });

  RG_Active.add(RB_IsActiveY);
  RB_IsActiveY.setText("Ya");
  RB_IsActiveY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsActiveY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsActiveYKeyPressed(evt);
   }
  });

  RG_Active.add(RB_IsActiveN);
  RB_IsActiveN.setText("Tidak");
  RB_IsActiveN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsActiveN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsActiveNKeyPressed(evt);
   }
  });

  TF_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameKeyPressed(evt);
   }
  });

  jLabel1.setText("Sub-Kata");

  jLabel2.setText("Diganti");

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(CB_Name)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPriceHelp))
     .addComponent(CB_IsActive))
    .addGap(44, 44, 44)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addGap(0, 70, Short.MAX_VALUE)
      .addComponent(Lbl_DataCount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jLabel1)
       .addComponent(jLabel2))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_Name)
       .addComponent(TF_NameSub)))
     .addGroup(layout.createSequentialGroup()
      .addComponent(RB_IsActiveY)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(RB_IsActiveN)
      .addGap(0, 0, Short.MAX_VALUE)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Name)
     .addComponent(Lbl_BuyPriceHelp)
     .addComponent(TF_NameSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_IsActiveY)
     .addComponent(RB_IsActiveN)
     .addComponent(CB_IsActive))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)
     .addComponent(Lbl_DataCount))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  
  Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data");
  
  TF_Name.requestFocusInWindow();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_BuyPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Inputan 'Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Diganti' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_BuyPriceHelpMouseClicked

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  closingForm(0);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrCheck=false;
  
  ChangeName=CB_Name.isSelected();
  ChangeIsActive=CB_IsActive.isSelected();
  if(!ChangeName && !ChangeIsActive){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  // check inputs validity
  IsValid=true;
  
  if(ChangeName){
   Name=TF_Name.getText();
   
   NameSub=TF_NameSub.getText();
   CurrCheck=NameSub.length()!=0;
   
   if(!CurrCheck){IsValid=false; CB_Name.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Name.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeIsActive){
   IsActive=RB_IsActiveY.isSelected();
  }
   
  // set get Variables
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !"+
    "\nSilahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void CB_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_NameKeyPressed
  PNav.onKey_CB(this, CB_Name, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsActive)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_NameSub)));
 }//GEN-LAST:event_CB_NameKeyPressed

 private void TF_NameSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameSubKeyPressed
  PNav.onKey_TF(this, TF_NameSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Name)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Name)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameSubKeyPressed

 private void TF_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameKeyPressed
  PNav.onKey_TF(this, TF_Name, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsActiveY)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Name)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameKeyPressed

 private void CB_IsActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsActiveKeyPressed
  PNav.onKey_CB(this, CB_IsActive, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsActiveY)));
 }//GEN-LAST:event_CB_IsActiveKeyPressed

 private void RB_IsActiveYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsActiveYKeyPressed
  PNav.onKey_RB(this, RB_IsActiveY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsActive)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsActiveN)));
 }//GEN-LAST:event_RB_IsActiveYKeyPressed

 private void RB_IsActiveNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsActiveNKeyPressed
  PNav.onKey_RB(this, RB_IsActiveN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsActiveY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_RB_IsActiveNKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActive)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActive)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed



 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_IsActive;
 private javax.swing.JCheckBox CB_Name;
 private javax.swing.JLabel Lbl_BuyPriceHelp;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.JRadioButton RB_IsActiveN;
 private javax.swing.JRadioButton RB_IsActiveY;
 private javax.swing.ButtonGroup RG_Active;
 private javax.swing.JTextField TF_Name;
 private javax.swing.JTextField TF_NameSub;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 // End of variables declaration//GEN-END:variables
}
