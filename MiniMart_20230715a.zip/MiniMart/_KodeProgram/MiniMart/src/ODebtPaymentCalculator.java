import java.util.Date;
import java.util.Vector;

public class ODebtPaymentCalculator {
	
	Date HDate;
	double HSaving;
	OCash CashHSaving;
	
	final int BColType=0;
	final int BColId=1;
	final int BColDate=2;
	final int BColAmount=3;
	
	final int TypeBillIn=1;
	final int TypeBillOut=2;
	
	/*
	 00 type
	 01 id
	 02 bill date (asc)
	 03 amount
	*/
	Vector<Object[]> BillsIn;
	
	final int IColCount=4;
	
	double ISumAmount;
	
	/*
	 00 type
	 01 id
	 02 bill date (asc)
	 03 amount
	 04 amount paid
	 05 repay period start
	 06 repay period end
	 07 calc start
	 08 interval (start - end)
	 09 interval (start - h)
	 10 interval (calc - end)
	 11 repay daily
	 12 total repay (start - h)
	 13 alloc from amount paid
	 14 alloc from hsaving
	 15 alloc from bills in
	 16 total alloc (start-h)
	 17 total repay (calc - end)
	 18 alloc from amount paid
	 19 alloc from hsaving
	 20 alloc from bills in
	 21 total alloc (calc - end)
	 22 total alloc (start - end)
	 23 repay daily calc
	 24 OCash (amount paid)
	 25 GroupAllocBillsIn
	*/
	Vector<Object[]> BillsOut;
	
	final int OColCount=26;
	final int OColAmountPaid=4;
	final int OColRepayPeriodStart=5;
	final int OColRepayPeriodEnd=6;
	final int OColCalcStart=7;
	final int OColIntStartEnd=8;
	final int OColIntStartH=9;
	final int OColIntCalcEnd=10;
	final int OColRepayDaily=11;
	final int OColStartHTotRepay=12;
	final int OColStartHAllocPaid=13;
	final int OColStartHAllocSaving=14;
	final int OColStartHAllocBillsIn=15;
	final int OColStartHTotAlloc=16;
	final int OColCalcEndTotRepay=17;
	final int OColCalcEndAllocPaid=18;
	final int OColCalcEndAllocSaving=19;
	final int OColCalcEndAllocBillsIn=20;
	final int OColCalcEndTotAlloc=21;
	final int OColTotAlloc=22;
	final int OColRepayDailyCalc=23;
	final int OColCashPaid=24;
	final int OColGroupAllocBillsIn=25;
	
	double OSumAmount;
	double OSumAmountPaid;
	double OSumStartHTotRepay;
	double OSumStartHAllocPaid;
	double OSumStartHAllocSaving;
	double OSumStartHAllocBillsIn;
	double OSumStartHTotAlloc;
	double OSumCalcEndTotRepay;
	double OSumCalcEndAllocPaid;
	double OSumCalcEndAllocSaving;
	double OSumCalcEndAllocBillsIn;
	double OSumCalcEndTotAlloc;
	double OSumTotAlloc;
	
	Date OBillDateMin;
	Date OBillDateMax;
	Date OCalcStartMin;
	Date ORepayPeriodStartMin;
	Date ORepayPeriodEndMax;
	
	/*
	 00 id
	 01 bills in total amount
	 02 Vector<Object[]> (bills out)
	 03 Vector<Object[]>.size() (bills out count)
	 04 total repay (start - h)
	 05 total alloc (start - h)
	 06 total repay (calc - end)
	 07 total alloc (calc - end)
	 08 OCash (bills in total amount)
	*/
	Vector<Object[]> GroupsAllocBillsIn;
	
	final int GColCount=9;
	final int GColId=0;
	final int GColBillsInAmount=1;
	final int GColBillsOut=2;
	final int GColBillsOutCount=3;
	final int GColStartHTotRepay=4;
	final int GColStartHTotAlloc=5;
	final int GColCalcEndTotRepay=6;
	final int GColCalcEndTotAlloc=7;
	final int GColCashBillsInAmount=8;
	
	double GSumBillsInAmount;
	
	/*
	 00 Start Date (asc)
	 01 End Date
	 02 Interval (Start - End)
	 03 Repay Daily Amount
	 04 Total Repay Daily
	*/
	Vector<Object[]> RepaySpec;
	
	final int RColCount=5;
	final int RColDateStart=0;
	final int RColDateEnd=1;
	final int RColIntStartEnd=2;
	final int RColRepayDaily=3;
	final int RColTotRepayDaily=4;
	
	double RSumTotRepayDaily;
	
	public void setVariables(Date vHDate, double vHSaving,
		Vector<Object[]> vBillsOut, int vBillsOutColDate, int vBillsOutColAmount, int vBillsOutColAmountPaid, int vBillsOutColRepayStart, int vBillsOutColRepayEnd,
		Vector<Object[]> vBillsIn, int vBillsInColDate, int vBillsInColAmount, int vBillsInColAmountPaid, boolean vBillsInWithAmountPaid){
		initCalcParameter(vHDate, vHSaving);
		initBillsOut(vBillsOut, vBillsOutColDate, vBillsOutColAmount, vBillsOutColAmountPaid, vBillsOutColRepayStart, vBillsOutColRepayEnd);
		initBillsIn(vBillsIn, vBillsInColDate, vBillsInColAmount, vBillsInColAmountPaid, vBillsInWithAmountPaid);
		initGroupAllocBillsIn();
		initBillsOutValue();
		initRepaySpec();
	}
	public Object[] calculate(Date vHDate, double vHSaving,
		Vector<Object[]> vBillsOut, int vBillsOutColDate, int vBillsOutColAmount, int vBillsOutColAmountPaid, int vBillsOutColRepayStart, int vBillsOutColRepayEnd,
		Vector<Object[]> vBillsIn, int vBillsInColDate, int vBillsInColAmount, int vBillsInColAmountPaid, boolean vBillsInWithAmountPaid){
		/*
		 - HDate < smallest RepayPeriodEnd of BillsOut (not necessary)
		 - BillsOut.size() > 0
		 return : text (String) & table data (Vector<Object[]>)
		*/
		Object[] ret=null;
		
		setVariables(vHDate, vHSaving, vBillsOut, vBillsOutColDate, vBillsOutColAmount, vBillsOutColAmountPaid,
			vBillsOutColRepayStart, vBillsOutColRepayEnd, vBillsIn, vBillsInColDate, vBillsInColAmount, vBillsInColAmountPaid, vBillsInWithAmountPaid);
		
		calculateAllocPaid();
		calculateAllocBillsIn();
		calculateAllocSaving();
		fillRepayDailyCalc();
		
		// return
		ret=getResult();
		return ret;
	}
	Object[] getResult(){
		Vector<Object[]> tb=new Vector();
		StringBuilder tx=new StringBuilder();
		
		int temp, length;
		Object[] bill, repay;
		double Amount, TotAlloc, UnPaid, RepayDaily;
		int IntCalcEnd;
		
		// result table
		length=BillsOut.size();
		
			// summary of repay daily calculation
		tb.addElement(PCore.objArrVariant("Id", "Tgl Tagih", "Jumlah Utang", "Sisa Utang", "Waktu Cicil", "Cicil Harian", "", "", "", ""));
		tb.addElement(PCore.newObjectArray(10, ""));
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
			Amount=(Double)bill[BColAmount]; TotAlloc=(Double)bill[OColTotAlloc]; UnPaid=Amount-TotAlloc;
   IntCalcEnd=(Integer)bill[OColIntCalcEnd]; RepayDaily=0; if(IntCalcEnd!=0){RepayDaily=UnPaid/IntCalcEnd;}
			tb.addElement(PCore.objArrVariant(
				String.valueOf((Integer)bill[BColId]), PText.dateToString((Date)bill[BColDate], 2), PText.priceToString(Amount),
				PText.priceToString(UnPaid), PText.intToString(IntCalcEnd), PText.priceToString(RepayDaily),
				"", "", "", ""
			));
			
			temp=temp+1;
		}while(temp!=length);
		tb.addElement(PCore.newObjectArray(10, ""));
		
		tb.addElement(PCore.newObjectArray(10, ""));
		tb.addElement(PCore.newObjectArray(10, ""));
		
			// detail of repay daily calculation
		tb.addElement(PCore.objArrVariant("Id", "Tgl Tagih", "Cicil Sebelum", "Alo. Terlunasi", "Alo. Piutang", "Alo. Kas Utang",
			"Cicil Setelah", "Alo. Terlunasi", "Alo. Piutang", "Alo. Kas Utang"));
		tb.addElement(PCore.newObjectArray(10, ""));
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
			tb.addElement(PCore.objArrVariant(
				String.valueOf((Integer)bill[BColId]), PText.dateToString((Date)bill[BColDate], 2),
				PText.priceToString((Double)bill[OColStartHTotRepay]), PText.priceToString((Double)bill[OColStartHAllocPaid]), PText.priceToString((Double)bill[OColStartHAllocBillsIn]), PText.priceToString((Double)bill[OColStartHAllocSaving]),
				PText.priceToString((Double)bill[OColCalcEndTotRepay]), PText.priceToString((Double)bill[OColCalcEndAllocPaid]), PText.priceToString((Double)bill[OColCalcEndAllocBillsIn]), PText.priceToString((Double)bill[OColCalcEndAllocSaving])
			));
			
			temp=temp+1;
		}while(temp!=length);
		tb.addElement(PCore.newObjectArray(10, ""));
		
		// result text
		 // summary
		tx.append("+ Rangkuman Hasil Kalkulasi ( Tgl Tagih Utang "+PText.dateToString(OBillDateMin, 2)+" ... "+PText.dateToString(OBillDateMax, 2)+" ) :");
		tx.append("\n");
  tx.append("\nTotal Utang : "+PText.priceToString(OSumAmount));
		tx.append("\n");
  tx.append("\nAlokasi Pelunasan : "+PText.priceToString(OSumTotAlloc));
		tx.append("\n~ ~ Alokasi Terlunasi : "+PText.priceToString(OSumStartHAllocPaid+OSumCalcEndAllocPaid));
		tx.append("\n~ ~ Alokasi Piutang : "+PText.priceToString(OSumStartHAllocBillsIn+OSumCalcEndAllocBillsIn)+" ( Sisa "+PText.priceToString(ISumAmount-(OSumStartHAllocBillsIn+OSumCalcEndAllocBillsIn))+" )");
		tx.append("\n~ ~ Alokasi Kas Utang : "+PText.priceToString(OSumStartHAllocSaving+OSumCalcEndAllocSaving)+" ( Sisa "+PText.priceToString(HSaving-(OSumStartHAllocSaving+OSumCalcEndAllocSaving))+" )");
		tx.append("\n");
  tx.append("\nSisa Utang : "+PText.priceToString(OSumAmount-OSumTotAlloc));
		
		 // repayment specification
		tx.append("\n\n\n");
  tx.append("+ Cicilan Hingga Ke Hari H ( Periode "+PText.dateToString(PDate.getMinMax(true, HDate, ORepayPeriodStartMin), 2)+
   " ... "+PText.dateToString(HDate, 2)+" ) :");
  tx.append("\n");
  tx.append("\nTotal Utang : "+PText.priceToString(OSumStartHTotRepay));
  tx.append("\nAlokasi Pelunasan : "+PText.priceToString(OSumStartHTotAlloc));
  tx.append("\nSisa Utang : "+PText.priceToString(OSumStartHTotRepay-OSumStartHTotAlloc));
  tx.append("\n\n\n");
  tx.append("+ Cicilan Mulai Dari Hari H+1 ( Periode "+PText.dateToString(PDate.calculateDateByDay(HDate, 1, 1), 2)+
   " ... "+PText.dateToString(PDate.getMinMax(false, PDate.calculateDateByDay(HDate, 1, 1), ORepayPeriodEndMax), 2)+" ) :");
  tx.append("\n");
  tx.append("\nTotal Utang : "+PText.priceToString(OSumCalcEndTotRepay));
  tx.append("\nAlokasi Pelunasan : "+PText.priceToString(OSumCalcEndTotAlloc));
  tx.append("\nSisa Utang : "+PText.priceToString(OSumCalcEndTotRepay-OSumCalcEndTotAlloc));
  tx.append("\n");
		tx.append("\nRincian Besaran Cicilan Harian :");
  tx.append("\n");
		length=RepaySpec.size();
		temp=0;
		do{
			repay=RepaySpec.elementAt(temp);
			tx.append(
				"\n"+PText.dateToString((Date)repay[RColDateStart], 2)+" ... "+PText.dateToString((Date)repay[RColDateEnd], 2)+
				" ("+PText.intToString((Integer)repay[RColIntStartEnd])+" hari) : "+
				PText.priceToString((Double)repay[RColRepayDaily])+" ("+PText.priceToString((Double)repay[RColTotRepayDaily])+")");
			temp=temp+1;
		}while(temp!=length);
		
		return PCore.objArrVariant(tx.toString(), tb);
	}
	
	//
	void calculateAllocPaid(){
		int temp, length;
		double alloc;
		
		Object[] bill;
		double StartHTotRepay, StartHTotAlloc, CalcEndTotRepay, CalcEndTotAlloc;
		OCash CashPaid;
		
		length=BillsOut.size();
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
			CashPaid=(OCash)bill[OColCashPaid];
			StartHTotRepay=(Double)bill[OColStartHTotRepay];
			StartHTotAlloc=(Double)bill[OColStartHTotAlloc];
			CalcEndTotRepay=(Double)bill[OColCalcEndTotRepay];
			CalcEndTotAlloc=(Double)bill[OColCalcEndTotAlloc];
			
			do{
				// alloc Start - H
				if(CashPaid.Saldo<=0){break;}
				if(StartHTotAlloc<StartHTotRepay){
					alloc=CashPaid.Saldo; if(StartHTotAlloc+CashPaid.Saldo>StartHTotRepay){alloc=StartHTotRepay-StartHTotAlloc;}
					addOStartHAllocPaid(bill, alloc, CashPaid);
					if(CashPaid.Saldo<=0){break;}
				}
				// alloc Calc - End
				if(CalcEndTotAlloc<CalcEndTotRepay){
					alloc=CashPaid.Saldo; if(CalcEndTotAlloc+CashPaid.Saldo>CalcEndTotRepay){alloc=CalcEndTotRepay-CalcEndTotAlloc;}
					addOCalcEndAllocPaid(bill, alloc, CashPaid);
				}
			}while(false);
			
			temp=temp+1;
		}while(temp!=length);
	}
	void calculateAllocBillsIn(){
		int billtemp;
		int grouplength, grouptemp;
		Object[] group, bill;
		Vector<Object[]> Bills;
		int BillsCount;
		double StartHTotRepay, StartHTotAlloc, CalcEndTotRepay, CalcEndTotAlloc;
		OCash Cash;
		OCash CashBef;
		double left, add_percentage, TotRepay, TotAlloc;
		
		grouplength=GroupsAllocBillsIn.size();
		if(grouplength==0){return;}
		
		grouptemp=0;
		CashBef=null;
		do{
			group=GroupsAllocBillsIn.elementAt(grouptemp);
			Bills=(Vector<Object[]>)group[GColBillsOut];
			BillsCount=(Integer)group[GColBillsOutCount];
			Cash=(OCash)group[GColCashBillsInAmount];
			StartHTotRepay=(Double)group[GColStartHTotRepay]; StartHTotAlloc=(Double)group[GColStartHTotAlloc];
			CalcEndTotRepay=(Double)group[GColCalcEndTotRepay]; CalcEndTotAlloc=(Double)group[GColCalcEndTotAlloc];
			if(CashBef!=null){if(CashBef.Saldo>0){addGCashBillsInAmount(group, CashBef.Saldo, CashBef);}}
			
			do{
    if(Cash.Saldo<=0){break;}
				if(StartHTotAlloc<StartHTotRepay){
     left=StartHTotRepay-StartHTotAlloc;
					add_percentage=1; if(Cash.Saldo<left){add_percentage=Cash.Saldo/left;}
					billtemp=0;
					do{
						bill=Bills.elementAt(billtemp);
						TotRepay=(Double)bill[OColStartHTotRepay]; TotAlloc=(Double)bill[OColStartHTotAlloc];
						if(TotAlloc<TotRepay){
							left=TotRepay-TotAlloc;
							addOStartHAllocBillsIn(bill, left*add_percentage, Cash);
						}
						billtemp=billtemp+1;
					}while(billtemp!=BillsCount);
     if(Cash.Saldo<=0){break;}
				}
				if(CalcEndTotAlloc<CalcEndTotRepay){
     left=CalcEndTotRepay-CalcEndTotAlloc;
					add_percentage=1; if(Cash.Saldo<left){add_percentage=Cash.Saldo/left;}
					billtemp=0;
					do{
						bill=Bills.elementAt(billtemp);
						TotRepay=(Double)bill[OColCalcEndTotRepay]; TotAlloc=(Double)bill[OColCalcEndTotAlloc];
						if(TotAlloc<TotRepay){
							left=TotRepay-TotAlloc;
							addOCalcEndAllocBillsIn(bill, left*add_percentage, Cash);
						}
						billtemp=billtemp+1;
					}while(billtemp!=BillsCount);
				}
			}while(false);
				
			CashBef=Cash;
			
			grouptemp=grouptemp+1;
		}while(grouptemp!=grouplength);
	}
	void calculateAllocSaving(){
		int temp, length;
		double left, alloc_percentage;
		Object[] bill;
		double TotRepay, TotAlloc;
  
		length=BillsOut.size();
		
  // alloc Start - H
		if(CashHSaving.Saldo<=0){return;}
		if(OSumStartHTotAlloc<OSumStartHTotRepay){
			left=OSumStartHTotRepay-OSumStartHTotAlloc;
			alloc_percentage=1; if(CashHSaving.Saldo<left){alloc_percentage=CashHSaving.Saldo/left;}
			temp=0;
			do{
				bill=BillsOut.elementAt(temp);
				TotRepay=(Double)bill[OColStartHTotRepay]; TotAlloc=(Double)bill[OColStartHTotAlloc];
				if(TotAlloc<TotRepay){
					left=TotRepay-TotAlloc;
					addOStartHAllocSaving(bill, left*alloc_percentage, CashHSaving);
				}
					
				temp=temp+1;
			}while(temp!=length);
			if(CashHSaving.Saldo<=0){return;}
		}
		// alloc Calc - End
		if(OSumCalcEndTotAlloc<OSumCalcEndTotRepay){
			left=OSumCalcEndTotRepay-OSumCalcEndTotAlloc;
			alloc_percentage=1; if(CashHSaving.Saldo<left){alloc_percentage=CashHSaving.Saldo/left;}
			temp=0;
			do{
				bill=BillsOut.elementAt(temp);
				TotRepay=(Double)bill[OColCalcEndTotRepay]; TotAlloc=(Double)bill[OColCalcEndTotAlloc];
				if(TotAlloc<TotRepay){
					left=TotRepay-TotAlloc;
					addOCalcEndAllocSaving(bill, left*alloc_percentage, CashHSaving);
				}
				
				temp=temp+1;
			}while(temp!=length);
		}
	}
	
	//
	void fillRepayDailyCalc(){
		int temp, length;
		Object[] bill;
		int insert_start, insert_end;
		double repaycalc;
		Date DtStart, DtEnd;
		
		length=BillsOut.size();
		
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
   
   if((Integer)bill[OColIntCalcEnd]!=0){
    bill[OColRepayDailyCalc]=(double)(((Double)bill[OColCalcEndTotRepay]-(Double)bill[OColCalcEndTotAlloc])/(Integer)bill[OColIntCalcEnd]);
   }
   
			temp=temp+1;
		}while(temp!=length);
		
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
   
   if((Integer)bill[OColIntCalcEnd]!=0){
    repaycalc=(Double)bill[OColRepayDailyCalc];
    DtStart=(Date)bill[OColCalcStart];
    DtEnd=(Date)bill[OColRepayPeriodEnd];
    
    insert_start=insertDateStart(DtStart);
    insert_end=insertDateEnd(DtEnd, insert_start);
    repayDailyCalcAdd(insert_start, insert_end, repaycalc);
   }
			
			temp=temp+1;
		}while(temp!=length);
		
		initRepaySpecValue();
	}
	int insertDateStart(Date Dt){
		int ret=RepaySpec.size()-1;
		int grade;
		Object[] repay;
		Object[] repaynew;
		Date DtEnd;
		double RepayDaily;
		
		// insert date start
		do{
			repay=RepaySpec.elementAt(ret);
			grade=PDate.grading((Date)repay[RColDateStart], Dt, Long.MIN_VALUE);
			if(grade!=1){break;}
			ret=ret-1;
		}while(ret!=-1);
		
		if(grade!=0){
			DtEnd=(Date)repay[RColDateEnd];
			RepayDaily=(Double)repay[RColRepayDaily];
			
			repay[RColDateEnd]=PDate.calculateDateByDay(Dt, 1, 2);
			
			repaynew=new Object[RColCount];
			repaynew[RColDateStart]=Dt; repaynew[RColDateEnd]=DtEnd; repaynew[RColRepayDaily]=RepayDaily; repaynew[RColTotRepayDaily]=0D;
			
			ret=ret+1;
			RepaySpec.insertElementAt(repaynew, ret);
		}
		
		return ret;
	}
	int insertDateEnd(Date Dt, int StartIndex){
		int ret=StartIndex;
		int length=RepaySpec.size();
		int grade;
		Object[] repay;
		Object[] repaynew;
		Date DtStart;
		double RepayDaily;
		
		// insert date end
		do{
			repay=RepaySpec.elementAt(ret);
			grade=PDate.grading((Date)repay[RColDateEnd], Dt, Long.MIN_VALUE);
			if(grade!=2){break;}
			ret=ret+1;
		}while(ret!=length);
		
		if(grade!=0){
			RepayDaily=(Double)repay[RColRepayDaily];
			DtStart=(Date)repay[RColDateStart];
			
			repay[RColDateStart]=PDate.calculateDateByDay(Dt, 1, 1);
			
			repaynew=new Object[RColCount];
			repaynew[RColDateStart]=DtStart; repaynew[RColDateEnd]=Dt; repaynew[RColRepayDaily]=RepayDaily; repaynew[RColTotRepayDaily]=0D;
			
			RepaySpec.insertElementAt(repaynew, ret);
		}
		
		return ret;
	}
	void repayDailyCalcAdd(int idx1, int idx2, double Value){
		int temp;
		Object[] repay;
		
		// add repay daily calc from start date to end date
		temp=idx1;
		do{
			repay=RepaySpec.elementAt(temp);
			repay[RColRepayDaily]=(double)((Double)repay[RColRepayDaily]+Value);
			temp=temp+1;
		}while(temp!=idx2+1);
	}
	
	//
	private void initRepaySpec(){
		Object[] repay;
		
		RSumTotRepayDaily=0;
		
		RepaySpec=new Vector();
		
		repay=new Object[RColCount];
		repay[RColDateStart]=OCalcStartMin;
  repay[RColDateEnd]=ORepayPeriodEndMax;
  if(PDate.grading((Date)repay[RColDateStart], (Date)repay[RColDateEnd], Long.MIN_VALUE)==1){repay[RColDateEnd]=repay[RColDateStart];}
  repay[RColRepayDaily]=0D;
  repay[RColTotRepayDaily]=0D;
		RepaySpec.addElement(repay);
	}
	private void initRepaySpecValue(){
		int temp, length;
		Object[] Repay;
		length=RepaySpec.size();
		temp=0;
		do{
			Repay=RepaySpec.elementAt(temp);
			Repay[RColIntStartEnd]=PDate.calculateIntervalDay((Date)Repay[RColDateStart], (Date)Repay[RColDateEnd]);
			addRTotRepayDaily(Repay, (Integer)Repay[RColIntStartEnd]*(Double)Repay[RColRepayDaily]);
			temp=temp+1;
		}while(temp!=length);
	}
	private void initCalcParameter(Date vHDate, double vHSaving){
		HDate=vHDate;
		HSaving=vHSaving;
		CashHSaving=new OCash(HSaving);
	}
	private void initBillsOut(Vector<Object[]> vBillsOut, int vBillsOutColDate, int vBillsOutColAmount, int vBillsOutColAmountPaid, int vBillsOutColRepayStart, int vBillsOutColRepayEnd){
		int temp, length;
		
		Object[] objs, bill;
		
		Date BBillDate, BRepayPeriodStart, BRepayPeriodEnd, BCalcStart, BCalcStartYesterday;
		double BAmount, BAmountPaid, BRepayDaily;
		int BIntStartEnd, BIntStartH, BIntCalcEnd;
		
		OSumAmount=0;
		OSumAmountPaid=0;
		OSumStartHTotRepay=0;
		OSumStartHAllocPaid=0;
		OSumStartHAllocSaving=0;
		OSumStartHAllocBillsIn=0;
		OSumStartHTotAlloc=0;
		OSumCalcEndTotRepay=0;
		OSumCalcEndAllocPaid=0;
		OSumCalcEndAllocSaving=0;
		OSumCalcEndAllocBillsIn=0;
		OSumCalcEndTotAlloc=0;
		OSumTotAlloc=0;
		
		BillsOut=new Vector();
		
		length=vBillsOut.size();
		temp=0;
		do{
			objs=vBillsOut.elementAt(temp);
			BBillDate=(Date)objs[vBillsOutColDate];
			BAmount=(Double)objs[vBillsOutColAmount];
			BAmountPaid=(Double)objs[vBillsOutColAmountPaid];
			BRepayPeriodStart=(Date)objs[vBillsOutColRepayStart];
			BRepayPeriodEnd=(Date)objs[vBillsOutColRepayEnd];
			BCalcStart=PDate.calculateDateByDay(HDate, 1, 1);
   if(PDate.grading(BRepayPeriodStart, BCalcStart, Long.MIN_VALUE)==1){BCalcStart=BRepayPeriodStart;}
   BCalcStartYesterday=PDate.calculateDateByDay(BCalcStart, 1, 2);
   if(PDate.grading(BRepayPeriodEnd, BCalcStartYesterday, Long.MIN_VALUE)==2){BCalcStartYesterday=BRepayPeriodEnd;}
			BIntStartEnd=PDate.calculateIntervalDay(BRepayPeriodStart, BRepayPeriodEnd);
			BIntStartH=PDate.calculateIntervalDay(BRepayPeriodStart, BCalcStartYesterday); if(BIntStartH<1){BIntStartH=0;}
			BIntCalcEnd=PDate.calculateIntervalDay(BCalcStart, BRepayPeriodEnd); if(BIntCalcEnd<1){BIntCalcEnd=0;}
			BRepayDaily=BAmount/BIntStartEnd;
			
			bill=new Object[OColCount];
			bill[BColType]=TypeBillOut; bill[BColId]=null; bill[BColDate]=BBillDate; bill[BColAmount]=0D; bill[OColAmountPaid]=0D;
			bill[OColRepayPeriodStart]=BRepayPeriodStart; bill[OColRepayPeriodEnd]=BRepayPeriodEnd; bill[OColCalcStart]=BCalcStart;
			bill[OColIntStartEnd]=BIntStartEnd; bill[OColIntStartH]=BIntStartH; bill[OColIntCalcEnd]=BIntCalcEnd; bill[OColRepayDaily]=BRepayDaily;
			bill[OColStartHTotRepay]=0D; bill[OColStartHAllocPaid]=0D; bill[OColStartHAllocSaving]=0D; bill[OColStartHAllocBillsIn]=0D; bill[OColStartHTotAlloc]=0D;
			bill[OColCalcEndTotRepay]=0D; bill[OColCalcEndAllocPaid]=0D; bill[OColCalcEndAllocSaving]=0D; bill[OColCalcEndAllocBillsIn]=0D; bill[OColCalcEndTotAlloc]=0D;
			bill[OColTotAlloc]=0D; bill[OColRepayDailyCalc]=0D; bill[OColCashPaid]=new OCash(0); bill[OColGroupAllocBillsIn]=null;
			
			addOAmount(bill, BAmount); addOAmountPaid(bill, BAmountPaid);

			BillsOut.insertElementAt(bill, PTable.findInsertPos(BillsOut, BColDate, BBillDate, true, false, true));

			temp=temp+1;
		}while(temp!=length);
			
		// fill id
		length=BillsOut.size();
		temp=0;
		do{
			BillsOut.elementAt(temp)[BColId]=temp;
			temp=temp+1;
		}while(temp!=length);
		
		OCalcStartMin=PTable.getMinMaxDate(true, BillsOut, OColCalcStart);
  ORepayPeriodStartMin=PTable.getMinMaxDate(true, BillsOut, OColRepayPeriodStart);
		ORepayPeriodEndMax=PTable.getMinMaxDate(false, BillsOut, OColRepayPeriodEnd);
		OBillDateMin=(Date)BillsOut.elementAt(0)[BColDate];
		OBillDateMax=(Date)BillsOut.elementAt(BillsOut.size()-1)[BColDate];
	}
	private void initBillsIn(Vector<Object[]> vBillsIn, int vBillsInColDate, int vBillsInColAmount, int vBillsInColAmountPaid,
  boolean vBillsInWithAmountPaid){
		int temp, length;
		
		Object[] objs, bill;
		
		Date BBillDate;
		double BAmount;
  double BAmountPaid;
		
		Date Dt;
		int index;
		
		ISumAmount=0;
		
		BillsIn=new Vector();
		
		length=vBillsIn.size();
		if(length==0){return;}
		
		temp=0;
		do{
			objs=vBillsIn.elementAt(temp);
			BBillDate=(Date)objs[vBillsInColDate];
			BAmountPaid=(Double)objs[vBillsInColAmountPaid];
			BAmount=(Double)objs[vBillsInColAmount]; if(vBillsInWithAmountPaid){BAmount=BAmount-BAmountPaid;} if(BAmount<0){BAmount=0;}
   
   bill=new Object[IColCount];
   bill[BColType]=TypeBillIn; bill[BColId]=null; bill[BColDate]=BBillDate; bill[BColAmount]=0D;

   addIAmount(bill, BAmount, true);

   BillsIn.insertElementAt(bill, PTable.findInsertPos(BillsIn, BColDate, BBillDate, true, false, true));
   
			temp=temp+1;
		}while(temp!=length);

		// eliminate bill in after largest bill date of bill out
		length=BillsIn.size();
		if(length==0){return;}
		Dt=(Date)BillsOut.elementAt(BillsOut.size()-1)[BColDate];
		index=PTable.findInsertPos(BillsIn, BColDate, Dt, true, false, true);
		if(index!=length){
			temp=length-1;
			do{
				bill=BillsIn.elementAt(temp);
				addIAmount(bill, (Double)bill[BColAmount], false);
				BillsIn.remove(temp);
				temp=temp-1;
			}while(temp!=index-1);
		}

		// fill id
		length=BillsIn.size();
		if(length==0){return;}
		temp=0;
		do{
			BillsIn.elementAt(temp)[BColId]=temp;
			temp=temp+1;
		}while(temp!=length);
	}
	private void initGroupAllocBillsIn(){
		int temp, length;
		
		Object[] bill, group;
		
		Vector<Object[]> GBillsOut;
		double GBillsInAmount;
		
		Vector<Object[]> BillsCombination;
		
		GSumBillsInAmount=0;
		
		GroupsAllocBillsIn=new Vector();
		
		if(BillsIn.size()==0){return;}
		
		BillsCombination=new Vector();

		// fill bills in to bills combination
		length=BillsIn.size();
		temp=0;
		do{
			BillsCombination.addElement(BillsIn.elementAt(temp));
			temp=temp+1;
		}while(temp!=length);

		// fill bills out to bills combination
		length=BillsOut.size();
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
			BillsCombination.insertElementAt(bill, PTable.findInsertPos(BillsCombination, BColDate, (Date)bill[BColDate], true, false, true));
			temp=temp+1;
		}while(temp!=length);

		// process group of 'bills in' allocation
		length=BillsCombination.size();
		temp=0;

			// find the first 'bill in' in 'bills combination'
		do{
			bill=BillsCombination.elementAt(temp);
			if((Integer)bill[BColType]==TypeBillIn){break;}
			temp=temp+1;
		}while(temp!=length);

			// start making group
		do{
			group=new Object[GColCount]; GroupsAllocBillsIn.addElement(group);

			GBillsInAmount=0;
			do{
				bill=BillsCombination.elementAt(temp);
				if((Integer)bill[BColType]==TypeBillOut){break;}
				GBillsInAmount=GBillsInAmount+(Double)bill[BColAmount];

				temp=temp+1;
			}while(temp!=length);

			GBillsOut=new Vector();
			do{
				bill=BillsCombination.elementAt(temp);
				if((Integer)bill[BColType]==TypeBillIn){break;}
				bill[OColGroupAllocBillsIn]=group;
				GBillsOut.addElement(bill);

				temp=temp+1;
			}while(temp!=length);

			group[GColId]=null; group[GColBillsInAmount]=0D;
			group[GColBillsOut]=GBillsOut; group[GColBillsOutCount]=GBillsOut.size();
			group[GColStartHTotRepay]=0D; group[GColStartHTotAlloc]=0D;
			group[GColCalcEndTotRepay]=0D; group[GColCalcEndTotAlloc]=0D;
			group[GColCashBillsInAmount]=new OCash(0);
			
			addGBillsInAmount(group, GBillsInAmount);
			
		}while(temp!=length);

		// fill id
		length=GroupsAllocBillsIn.size();
		temp=0;
		do{
			group=GroupsAllocBillsIn.elementAt(temp);
			group[GColId]=temp;
			temp=temp+1;
		}while(temp!=length);
	}
	private void initBillsOutValue(){
		int temp, length;
		
		Object[] bill;
		
		double BRepayDaily;
		int BIntStartH, BIntCalcEnd;
		
		length=BillsOut.size();
		temp=0;
		do{
			bill=BillsOut.elementAt(temp);
			BIntStartH=(Integer)bill[OColIntStartH];
			BIntCalcEnd=(Integer)bill[OColIntCalcEnd];
			BRepayDaily=(Double)bill[OColRepayDaily];
			addOStartHTotRepay(bill, BRepayDaily*BIntStartH);
			addOCalcEndTotRepay(bill, BRepayDaily*BIntCalcEnd);

			temp=temp+1;
		}while(temp!=length);
	}
	
	//
	private void addIAmount(Object[] BillIn, double Value, boolean IsAdd){
		int sign; if(IsAdd){sign=1;}else{sign=-1;}
		BillIn[BColAmount]=(Double)BillIn[BColAmount]+sign*Value;
		ISumAmount=ISumAmount+sign*Value;
	}
	private void addOAmount(Object[] BillOut, double Value){
		BillOut[BColAmount]=(Double)BillOut[BColAmount]+Value;
		OSumAmount=OSumAmount+Value;
	}
	private void addOAmountPaid(Object[] BillOut, double Value){
		BillOut[OColAmountPaid]=(Double)BillOut[OColAmountPaid]+Value;
		((OCash)BillOut[OColCashPaid]).add(Value);
		OSumAmountPaid=OSumAmountPaid+Value;
	}
	private void addOStartHTotRepay(Object[] BillOut, double Value){
		BillOut[OColStartHTotRepay]=(Double)BillOut[OColStartHTotRepay]+Value;
		OSumStartHTotRepay=OSumStartHTotRepay+Value;
		if(BillOut[OColGroupAllocBillsIn]!=null){addGStartHTotRepay((Object[])BillOut[OColGroupAllocBillsIn], Value);}
	}
	private void addOStartHAllocPaid(Object[] BillOut, double Value, OCash ByCash){
		ByCash.min(Value);
		BillOut[OColStartHAllocPaid]=(Double)BillOut[OColStartHAllocPaid]+Value;
		OSumStartHAllocPaid=OSumStartHAllocPaid+Value;
		addOStartHTotAlloc(BillOut, Value);
	}
	private void addOStartHAllocSaving(Object[] BillOut, double Value, OCash ByCash){
		ByCash.min(Value);
		BillOut[OColStartHAllocSaving]=(Double)BillOut[OColStartHAllocSaving]+Value;
		OSumStartHAllocSaving=OSumStartHAllocSaving+Value;
		addOStartHTotAlloc(BillOut, Value);
	}
	private void addOStartHAllocBillsIn(Object[] BillOut, double Value, OCash ByCash){
		ByCash.min(Value);
		BillOut[OColStartHAllocBillsIn]=(Double)BillOut[OColStartHAllocBillsIn]+Value;
		OSumStartHAllocBillsIn=OSumStartHAllocBillsIn+Value;
		addOStartHTotAlloc(BillOut, Value);
	}
	private void addOStartHTotAlloc(Object[] BillOut, double Value){
		BillOut[OColStartHTotAlloc]=(Double)BillOut[OColStartHTotAlloc]+Value;
		OSumStartHTotAlloc=OSumStartHTotAlloc+Value;
		addOTotAlloc(BillOut, Value);
		if(BillOut[OColGroupAllocBillsIn]!=null){addGStartHTotAlloc((Object[])BillOut[OColGroupAllocBillsIn], Value);}
	}
	private void addOCalcEndTotRepay(Object[] BillOut, double Value){
		BillOut[OColCalcEndTotRepay]=(Double)BillOut[OColCalcEndTotRepay]+Value;
		OSumCalcEndTotRepay=OSumCalcEndTotRepay+Value;
		if(BillOut[OColGroupAllocBillsIn]!=null){addGCalcEndTotRepay((Object[])BillOut[OColGroupAllocBillsIn], Value);}
	}
	private void addOCalcEndAllocPaid(Object[] BillOut, double Value, OCash ByCash){
		ByCash.min(Value);
		BillOut[OColCalcEndAllocPaid]=(Double)BillOut[OColCalcEndAllocPaid]+Value;
		OSumCalcEndAllocPaid=OSumCalcEndAllocPaid+Value;
		addOCalcEndTotAlloc(BillOut, Value);
	}
	private void addOCalcEndAllocSaving(Object[] BillOut, double Value, OCash ByCash){
		ByCash.min(Value);
		BillOut[OColCalcEndAllocSaving]=(Double)BillOut[OColCalcEndAllocSaving]+Value;
		OSumCalcEndAllocSaving=OSumCalcEndAllocSaving+Value;
		addOCalcEndTotAlloc(BillOut, Value);
	}
	private void addOCalcEndAllocBillsIn(Object[] BillOut, double Value, OCash ByCash){
		ByCash.min(Value);
		BillOut[OColCalcEndAllocBillsIn]=(Double)BillOut[OColCalcEndAllocBillsIn]+Value;
		OSumCalcEndAllocBillsIn=OSumCalcEndAllocBillsIn+Value;
		addOCalcEndTotAlloc(BillOut, Value);
	}
	private void addOCalcEndTotAlloc(Object[] BillOut, double Value){
		BillOut[OColCalcEndTotAlloc]=(Double)BillOut[OColCalcEndTotAlloc]+Value;
		OSumCalcEndTotAlloc=OSumCalcEndTotAlloc+Value;
		addOTotAlloc(BillOut, Value);
		if(BillOut[OColGroupAllocBillsIn]!=null){addGCalcEndTotAlloc((Object[])BillOut[OColGroupAllocBillsIn], Value);}
	}
	private void addOTotAlloc(Object[] BillOut, double Value){
		BillOut[OColTotAlloc]=(Double)BillOut[OColTotAlloc]+Value;
		OSumTotAlloc=OSumTotAlloc+Value;
	}
	private void addGBillsInAmount(Object[] GroupAllocBillsIn, double Value){
		GroupAllocBillsIn[GColBillsInAmount]=(Double)GroupAllocBillsIn[GColBillsInAmount]+Value;
		((OCash)GroupAllocBillsIn[GColCashBillsInAmount]).add(Value);
		GSumBillsInAmount=GSumBillsInAmount+Value;
	}
	private void addGCashBillsInAmount(Object[] GroupAllocBillsIn, double Value, OCash ByCash){
		ByCash.min(Value);
		((OCash)GroupAllocBillsIn[GColCashBillsInAmount]).add(Value);
	}
	private void addGStartHTotRepay(Object[] GroupAllocBillsIn, double Value){
		GroupAllocBillsIn[GColStartHTotRepay]=(Double)GroupAllocBillsIn[GColStartHTotRepay]+Value;
	}
	private void addGStartHTotAlloc(Object[] GroupAllocBillsIn, double Value){
		GroupAllocBillsIn[GColStartHTotAlloc]=(Double)GroupAllocBillsIn[GColStartHTotAlloc]+Value;
	}
	private void addGCalcEndTotRepay(Object[] GroupAllocBillsIn, double Value){
		GroupAllocBillsIn[GColCalcEndTotRepay]=(Double)GroupAllocBillsIn[GColCalcEndTotRepay]+Value;
	}
	private void addGCalcEndTotAlloc(Object[] GroupAllocBillsIn, double Value){
		GroupAllocBillsIn[GColCalcEndTotAlloc]=(Double)GroupAllocBillsIn[GColCalcEndTotAlloc]+Value;
	}
	private void addRTotRepayDaily(Object[] Repay, double Value){
		Repay[RColTotRepayDaily]=(double)((Double)Repay[RColTotRepayDaily]+Value);
		RSumTotRepayDaily=RSumTotRepayDaily+Value;
	}

}