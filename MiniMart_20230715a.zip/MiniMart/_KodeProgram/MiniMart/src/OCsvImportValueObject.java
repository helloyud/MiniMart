import java.util.Vector;

public class OCsvImportValueObject extends OCsvImportValue {
 
 String SQLValue;
 
 public OCsvImportValueObject(String SQLValue){
  initVariables(SQLValue);
 }
 
 public void initVariables(String SQLValue){
  this.SQLValue=SQLValue;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){preGenerateSQLValue(LastReadRecordFromFile);}
 
 public OGeneratedSQLValue generateSQLValue(){
  return new OGeneratedSQLValue(SQLValue);
 }

}