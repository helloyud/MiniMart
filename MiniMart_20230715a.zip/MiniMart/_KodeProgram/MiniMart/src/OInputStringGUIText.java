import javax.swing.text.JTextComponent;

public class OInputStringGUIText extends OInput {

 JTextComponent GUI_Text;
 boolean AcceptEmptyInput;
 int MaxInputLength;
 boolean AcceptTrailingAndTailingSpace;
 boolean ReturnEmptyStringAsNull;
 
 VString Value;

 public OInputStringGUIText(JTextComponent GUI_Text, boolean AcceptEmptyInput, int MaxInputLength, boolean AcceptTrailingAndTailingSpace, boolean ReturnEmptyStringAsNull) {
  this.GUI_Text = GUI_Text;
  this.AcceptEmptyInput = AcceptEmptyInput;
  this.MaxInputLength = MaxInputLength;
  this.AcceptTrailingAndTailingSpace = AcceptTrailingAndTailingSpace;
  this.ReturnEmptyStringAsNull = ReturnEmptyStringAsNull;
  
  Value = new VString();
 }

 
 
 public boolean isValid(){return PGUI.checkInputString(GUI_Text, Value, AcceptEmptyInput, MaxInputLength, AcceptTrailingAndTailingSpace, ReturnEmptyStringAsNull);}
 public Object getValue(){return Value.Value;}

}