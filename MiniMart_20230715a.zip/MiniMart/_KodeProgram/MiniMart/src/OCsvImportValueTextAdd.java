import java.util.Vector;

public class OCsvImportValueTextAdd extends OCsvImportValue {

 OCsvImportValue Value;
 String PreText;
 String PostText;

 public OCsvImportValueTextAdd(OCsvImportValue Value, String PreText, String PostText) {
  initVariables(Value, PreText, PostText);
 }
 
 public void initVariables(OCsvImportValue Value, String PreText, String PostText){
  this.Value=Value;
  this.PreText = PreText;
  this.PostText = PostText;
 }

 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile) {
  preGenerateSQLValue(LastReadRecordFromFile);
  Value.prepareGenerateSQLValue(LastReadRecordFromFile);
 }

 public OGeneratedSQLValue generateSQLValue() {
  OGeneratedSQLValue ret=new OGeneratedSQLValue();
  OGeneratedSQLValue GeneratedSQLValue;
  
  GeneratedSQLValue=Value.generateSQLValue();
  if(GeneratedSQLValue.isGenerated()){ret.setGeneratedSQLValue(PreText+GeneratedSQLValue.getGeneratedSQLValue()+PostText);}
  
  return ret;
 }
 
}