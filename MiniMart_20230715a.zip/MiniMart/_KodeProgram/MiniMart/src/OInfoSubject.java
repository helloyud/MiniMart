import java.util.Date;
import java.util.Vector;

public class OInfoSubject {
 String Name;
 Date Birthday;
 String Comment;
 
 String PictureFile;
 
 Vector<Object[]> ListAddress; int ListAddressCount;
 Vector<Object[]> ListContact; int ListContactCount;
}