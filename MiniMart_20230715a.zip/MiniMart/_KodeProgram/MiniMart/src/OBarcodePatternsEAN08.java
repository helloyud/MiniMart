public class OBarcodePatternsEAN08 extends OBarcodePatternsEAN {
 
 /*
  In this appication, the EAN-08 use the following specification:
  - X-Dimension 10.4 mil (magnification 80%)
  - width = 81 module (842.4 mil or 21.4 mm)
            start quiet zone (7 module) +
            start (3 module) +
            4 numbers (1st .. 4th) (28 module; @ 7 module / data) +
            middle (5 module) +
            3 numbers (5th .. 7th) (21 module; @ 7 module / data) +
            1 number as check digit (13th) (7 module) +
            stop (3 module) +
            end quiet zone (7 module)
  - height = 14.584 mm (magnification 80%)
 */
 
 public static final double EAN08IdealModuleWidth=OUnit.inch_to_pixel(0.0104);
 public static final double EAN08IdealModuleHeight=OUnit.mm_to_pixel(18.5);
 
 public static OBarcodePatternsSpecification getStandardSpecification(){
  return new OBarcodePatternsSpecification(EAN08IdealModuleWidth, EAN08IdealModuleHeight, 1, 7, 7);
 }
 
}