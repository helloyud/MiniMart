public class VStringArray {
 
 String[] Value;
 
 public VStringArray(){}
 public VStringArray(String[] Value){this.Value=Value;}
 
}