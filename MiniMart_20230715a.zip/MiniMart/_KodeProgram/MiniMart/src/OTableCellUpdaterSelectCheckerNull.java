public class OTableCellUpdaterSelectCheckerNull extends OTableCellUpdaterSelectChecker {

 /*
  check if all cells (by calculating from current_active_cell (TableColumnIndex, TableRowIndex) + cell reference (CheckCells)) are null or not null
 */
 
 boolean ModeCheckNull;
 int TableColumnIndex;
 OTableCellReference[] CheckCells;
 
 public OTableCellUpdaterSelectCheckerNull(boolean ModeCheckNull, int TableColumnIndex, OTableCellReference[] CheckCells) {
  this.ModeCheckNull=ModeCheckNull;
  this.TableColumnIndex=TableColumnIndex;
  this.CheckCells=CheckCells;
 }
 
 public boolean check(int TableRowIndex){
  int temp, length;
  OTableCellReference CurrCellReference;
  boolean IsNull;
  
  length=CheckCells.length;
  temp=0;
  do{
   CurrCellReference=CheckCells[temp];
   IsNull=PTable.getCellValue(getRows(), ColumnsType, TableRowIndex, TableColumnIndex, CurrCellReference, null, null)==null;
   if(IsNull!=ModeCheckNull){break;}
   temp=temp+1;
  }while(temp!=length);
  
  return temp==length;
 }
 
}