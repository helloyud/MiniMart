import java.awt.Graphics2D;

public abstract class ODrawComponent {
 
 double OffsetX, OffsetY;
 
 public ODimension calculateDrawDimension(boolean WithOffset){
  ODimension ret=calcDrawDimension();
  
  if(WithOffset){
   ret.setSize(OffsetX+ret.getWidth(), OffsetY+ret.getHeight());
  }
  
  return ret;
 }
 
 public abstract void draw(Graphics2D graphics, OGraphicsProperties Prop);
 public abstract ODimension calcDrawDimension();

}