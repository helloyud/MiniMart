import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Vector;

public class OLabelCreatorItemMiniID extends OLabelCreatorItem {
 
 
 
 
 
 public static ODimension getDimensionByCharacters(Font Fn, int RowsCount, int ColumnsCount, double MarginHorizontal, double MarginVertical, double AddLineSpacing){
  return PGraphics.getDimension(Fn, RowsCount, ColumnsCount, MarginHorizontal, MarginVertical, AddLineSpacing);
 }
 
 
 
 
 
 final int MaxChars=18+1; // add 1 character for 'the start sign' (character '#')
 int MaxDigit;
 
 
 
 
 
 public OLabelCreatorItemMiniID(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  ODimension dim;
  
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  dim=getDimensionByCharacters(Fon, RowsCountMin, ColumnsCountMin, MarginHorizontal, MarginVertical, TextLineSpacing);
  BoxWidthMin=dim.Width;
  BoxHeightMin=dim.Height;
 }
 protected void initDrawComponentsVariables(){
  super.initDrawComponentsVariables();
  initMargin(OUnit.mm_to_pixel(0.3), OUnit.mm_to_pixel(0.3));
  TextLineSpacing=OUnit.mm_to_pixel(0.1);
  
  ColumnsCountMin=3;
  RowsCountMin=1;
 }
 protected String getName(){return "ID) Mini";}
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  OPaper papr;
  ODimension LabelSize;
  Vector<OPaperInfoMiniID> MiniIDFormats;
  OPaperInfoMiniID CurrMiniIDFormat;
  int temp, count;
  
  MiniIDFormats=new Vector();
  
  // 2 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(2, 1, 3, false));
  // 3 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(3, 1, 4, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(3, 2, 2, false));
  // 4 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(4, 1, 5, false));
  // 5 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(5, 1, 6, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(5, 2, 3, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(5, 3, 2, false));
  // 6 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(6, 1, 7, false));
  // 7 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(7, 1, 8, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(7, 2, 4, false));
  // 8 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(8, 1, 9, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(8, 2, 5, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(8, 3, 3, false));
  // 13 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(13, 1, 14, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(13, 2, 7, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(13, 3, 5, false));
  // 18 digits Id
  MiniIDFormats.addElement(new OPaperInfoMiniID(18, 1, 19, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(18, 2, 10, false));
  MiniIDFormats.addElement(new OPaperInfoMiniID(18, 3, 7, false));
  
  count=MiniIDFormats.size();
  
  // A4 Half
  temp=0;
  do{
   CurrMiniIDFormat=MiniIDFormats.elementAt(temp);
   
   papr=CPrint.A4Half.cloneWithMargin(MgSt);
   
   LabelSize=getDimensionByCharacters(Fon, CurrMiniIDFormat.RowsCount, CurrMiniIDFormat.ColumnsCount, MarginHorizontal, MarginVertical, TextLineSpacing);
   CurrMiniIDFormat.IsRotated=PGraphics.gradingLabelCount(papr.RealImageableWidth, papr.RealImageableHeight,
    0, 0, 0, LabelSize.getWidth(), LabelSize.getHeight(), LabelSize.getHeight(), LabelSize.getWidth(), papr.IsRollPaper, true, false, true)==2;
   
   papr.Description=papr.Description+" {"+CurrMiniIDFormat.DigitSeries+" = "+
    CurrMiniIDFormat.RowsCount+" x "+CurrMiniIDFormat.ColumnsCount+"}";
   papr.setAdditionalInfo(CurrMiniIDFormat);
   
   
   if(!CurrMiniIDFormat.IsRotated){ret.addElement(new OPaperLabel(papr, LabelSize.getWidth(), LabelSize.getHeight(), 0, 0, 0, false, true, true, true, false));}
   else{ret.addElement(new OPaperLabel(papr, LabelSize.getHeight(), LabelSize.getWidth(), 0, 0, 0, false, true, true, true, false));}
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 14-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return true;}
 protected boolean isLabelRotatedInternalPaper(){return ((OPaperInfoMiniID)Papr.AdditionalInfo).IsRotated;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 public boolean genLayoutVariables(){
  OPaperInfoMiniID PaperInfo;
  ODimensionAbsolute rowcol_count;
  ODimension BoxSize;
  
  if(!Papr.IsCustomPaperLabel){
   PaperInfo=(OPaperInfoMiniID)Papr.AdditionalInfo;
   RowsCount=PaperInfo.RowsCount;
   ColumnsCount=PaperInfo.ColumnsCount;
  }
  else{
   rowcol_count=PGraphics.calculateLabelColumnAndRowCount(LabelWidth-2*MarginHorizontal, LabelHeight-2*MarginVertical,
    0, 0, TextLineSpacing, TextWidth, TextHeight, false);
   RowsCount=rowcol_count.RowsCount;
   ColumnsCount=rowcol_count.ColumnsCount;
   if(RowsCount*ColumnsCount>MaxChars){
    RowsCount=0;
    do{
     RowsCount=RowsCount+1;
    }while(RowsCount*ColumnsCount<MaxChars);
    ColumnsCount=PMath.round((double)MaxChars/(double)RowsCount, 1);
   }
  }
  if(RowsCount==0 || ColumnsCount==0){return false;}
  MaxDigit=RowsCount*ColumnsCount;
  
  BoxSize=getDimensionByCharacters(Fon, RowsCount, ColumnsCount, MarginHorizontal, MarginVertical, TextLineSpacing);
  BoxWidth=BoxSize.getWidth();
  BoxHeight=BoxSize.getHeight();
  
  return true;
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  OLabelDataItem Data;
  String strId, str;
  int CharCount, CurrChar, FillCount;
  double CurrY;
  
  g.setFont(Fon);
  
  Data=(OLabelDataItem)LabelData;
  
  strId=PText.fitString("#"+String.valueOf(Data.ItemId), MaxDigit, true, MaxDigit-1, 1, '~');
  CharCount=strId.length();
  CurrChar=0;
  CurrY=MarginVertical+PGraphics.getInsetY(AreaHeight, Fon, PMath.round((double)CharCount/(double)ColumnsCount, 1), TextLineSpacing, OAlignment.VerticalCenter);
  do{
   FillCount=ColumnsCount; if(CurrChar+FillCount>CharCount){FillCount=CharCount-CurrChar;}
   
   if(CurrChar!=0){CurrY=CurrY+TextLineSpacing;}
   str=PText.subString(strId, CurrChar, CurrChar+FillCount-1);
   g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+TextAscent));
   CurrY=CurrY+TextHeight;
   
   CurrChar=CurrChar+FillCount;
  }while(CurrChar!=CharCount);
 }
 
 
 
 
 
}