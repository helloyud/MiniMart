import java.util.Date;
import java.util.Vector;

public class OInfoItem {
 
 long PrimaryId;
 Vector<Long> SecondaryIds;
 
 String Name;
 Vector<String> Variants;
 boolean IsActive;
 String Comment;
 
 boolean UpdateStock;
 int StockUnit; String StockUnitName;
 double Stock; double MinStock; double MaxStock;
 
 boolean IsOpname;
 boolean IsReorder;
 double OrderEachPackQty;
 double OrderEachPackThreshold;
 double OrderMinPack;
 
 boolean HasExpireDate;
 int ExpireCheckPeriod;
 int ExpireThreshold;
 
 double SellPrice; String SellPriceComment; Date SellUpdate;
 double BuyPriceEstimation; String BuyPriceComment; Date BuyUpdate;
 
 Double OpnameStock;
 Date OpnameExpire;
 double OrderQuantity;
 
 String PictureFile;
 int CategoryId; String CategoryName;
 
 public OInfoItem(){
  this.PrimaryId=-1; this.Name=null;
  StockUnit=-1; StockUnitName=null;
 }
 
 public void init(OInfoItem Info){
  setVars(
   Info.PrimaryId, Info.SecondaryIds, Info.Name, Info.Variants, Info.IsActive, Info.Comment,
   Info.UpdateStock, Info.StockUnit, Info.StockUnitName, Info.Stock, Info.MinStock, Info.MaxStock,
   Info.IsOpname, Info.IsReorder, Info.OrderEachPackQty, Info.OrderEachPackThreshold, Info.OrderMinPack,
   Info.HasExpireDate, Info.ExpireCheckPeriod, Info.ExpireThreshold,
   Info.SellPrice, Info.SellPriceComment, Info.SellUpdate, Info.BuyPriceEstimation, Info.BuyPriceComment, Info.BuyUpdate,
   Info.OpnameStock, Info.OpnameExpire, Info.OrderQuantity,
   Info.PictureFile, Info.CategoryId, Info.CategoryName);
 }
 
 public void setVars(
  long PrimaryId, Vector<Long> SecondaryIds, String Name, Vector<String> Variants, boolean IsActive, String Comment,
  boolean UpdateStock, int StockUnit, String StockUnitName, double Stock, double MinStock, double MaxStock,
  boolean IsOpname, boolean IsReorder, double OrderEachPackQty, double OrderEachPackThreshold, double OrderMinPack,
  boolean HasExpireDate, int ExpireCheckPeriod, int ExpireThreshold,
  double SellPrice, String SellPriceComment, Date SellUpdate, double BuyPriceEstimation, String BuyPriceComment, Date BuyUpdate,
  Double OpnameStock, Date OpnameExpire, double OrderQuantity,
  String PictureFile, int CategoryId, String CategoryName){
  
  this.PrimaryId = PrimaryId; this.SecondaryIds = SecondaryIds; this.Name = Name; this.Variants = Variants; this.IsActive = IsActive; this.Comment = Comment;
  this.UpdateStock = UpdateStock; this.StockUnit = StockUnit; this.StockUnitName = StockUnitName; this.Stock = Stock; this.MinStock = MinStock; this.MaxStock = MaxStock;
  this.IsOpname = IsOpname; this.IsReorder = IsReorder; this.OrderEachPackQty = OrderEachPackQty; this.OrderEachPackThreshold = OrderEachPackThreshold; this.OrderMinPack = OrderMinPack;
  this.HasExpireDate = HasExpireDate; this.ExpireCheckPeriod = ExpireCheckPeriod; this.ExpireThreshold = ExpireThreshold;
  this.SellPrice = SellPrice; this.SellPriceComment = SellPriceComment; this.SellUpdate = SellUpdate;
  this.BuyPriceEstimation = BuyPriceEstimation; this.BuyPriceComment = BuyPriceComment; this.BuyUpdate = BuyUpdate;
  this.OpnameStock = OpnameStock; this.OpnameExpire = OpnameExpire; this.OrderQuantity = OrderQuantity;
  this.PictureFile = PictureFile; this.CategoryId = CategoryId; this.CategoryName = CategoryName;
 }
 
 public Object clone(){
  OInfoItem ret=new OInfoItem();
  ret.init(this);
  return ret;
 }
 
}