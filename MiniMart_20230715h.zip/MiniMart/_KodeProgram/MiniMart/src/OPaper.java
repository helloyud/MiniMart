import java.awt.print.Paper;

public class OPaper extends Paper
 implements Cloneable{
 
 
 
 int Id;
 String Name;
 String Description;
 boolean IsRollPaper;
 Object AdditionalInfo;
 OPaperMargin MarginStandardMinimal, MarginThermalMinimal;
 
 // Paper  manipulation (width - height, imageable x - y, imageable width - height)
 double RealWidth, RealHeight;
 double RealImageableX, RealImageableY;
 double RealImageableWidth, RealImageableHeight;
 
 double WidthTolerance, HeightTolerance;
 double MoveImageableX, MoveImageableY;
 
 
 public OPaper(){}
 public OPaper(OPaper ReferencePaper){changeThisPaperWith(ReferencePaper);}
 public OPaper(int Id, String Name, String Description, boolean IsRollPaper, Object AdditionalInfo, OPaperMargin MarginSt, OPaperMargin MarginTh,
  double RealWidth, double RealHeight, double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight,
  double WidthTolerance, double HeightTolerance, double MoveImageableX, double MoveImageableY){
  setAllVariables(Id, Name, Description, IsRollPaper, AdditionalInfo, MarginSt, MarginTh,
   RealWidth, RealHeight, RealImageableX, RealImageableY, RealImageableWidth, RealImageableHeight,
   WidthTolerance, HeightTolerance, MoveImageableX, MoveImageableY);
 }
 
 
 
 private void setAllVariables(int Id, String Name, String Description, boolean IsRollPaper, Object AdditionalInfo, OPaperMargin MarginSt, OPaperMargin MarginTh,
  double RealWidth, double RealHeight, double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight,
  double WidthTolerance, double HeightTolerance, double MoveImageableX, double MoveImageableY){
  
  setBasicVariables(Id, Name, Description, IsRollPaper);
  setAdditionalInfo(AdditionalInfo);
  setMarginMinimal(MarginSt, MarginTh);
  
  setRealSize(RealWidth, RealHeight);
  setRealImageableArea(RealImageableX, RealImageableY, RealImageableWidth, RealImageableHeight);
  setSizeTolerance(WidthTolerance, HeightTolerance);
  setMoveImageableXY(MoveImageableX, MoveImageableY);
  
  generateSize();
  generateImageableArea();
 
 }
 
 public void setBasicVariables(int Id, String Name, String Description, boolean IsRollPaper){
  this.Id=Id;
  this.Name=Name;
  this.Description=Description;
  this.IsRollPaper=IsRollPaper;
 }
 public void setAdditionalInfo(Object AddInfo){AdditionalInfo=AddInfo;}
 protected void setMarginMinimal(OPaperMargin MarginSt, OPaperMargin MarginTh){
  this.MarginStandardMinimal=MarginSt;
  this.MarginThermalMinimal=MarginTh;
 }
 
 private void setRealSize(double RealWidth, double RealHeight){
  this.RealWidth=RealWidth;
  this.RealHeight=RealHeight;
 }
 private void setRealImageableArea(double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight){
  this.RealImageableX=RealImageableX;
  this.RealImageableY=RealImageableY;
  this.RealImageableWidth=RealImageableWidth;
  this.RealImageableHeight=RealImageableHeight;
 }
 private void setSizeTolerance(double WidthTolerance, double HeightTolerance){
  this.WidthTolerance=WidthTolerance;
  this.HeightTolerance=HeightTolerance;
 }
 private void setMoveImageableXY(double MoveImageableX, double MoveImageableY){
  this.MoveImageableX=MoveImageableX;
  this.MoveImageableY=MoveImageableY;
 }
 void generateImageableArea(){
  double const1, v1, const2, v2;
  const1=RealImageableX; v1=MoveImageableX;
  const2=RealImageableY; v2=MoveImageableY;
  setImageableArea(const1+v1, const2+v2, RealImageableWidth, RealImageableHeight);
 }
 void generateSize(){
  double const1, v1, const2, v2;
  const1=RealWidth+WidthTolerance; v1=MoveImageableX; if(v1<0){v1=0;}
  const2=RealHeight+HeightTolerance; v2=MoveImageableY; if(v2<0){v2=0;}
  setSize(const1+v1, const2+v2);
 }
 
 
 
 public static OPaper createPaper(int Id, String Name, String Description, boolean IsRollPaper, Object AdditionalInfo, OPaperMargin MarginSt, OPaperMargin MarginTh,
  double RealWidth, double RealHeight, double LeftMargin, double RightMargin, double TopMargin, double BottomMargin,
  double WidthTolerance, double HeightTolerance, double MoveImageableX, double MoveImageableY){
  return new OPaper(Id, Name, Description, IsRollPaper, AdditionalInfo, MarginSt, MarginTh, RealWidth, RealHeight,
   LeftMargin, TopMargin, RealWidth-LeftMargin-RightMargin, RealHeight-TopMargin-BottomMargin,
   WidthTolerance, HeightTolerance, MoveImageableX, MoveImageableY);
 }
 public OPaper changeThisPaperWith(OPaper NewPaper){
  setAllVariables(NewPaper.Id, NewPaper.Name, NewPaper.Description, NewPaper.IsRollPaper, NewPaper.AdditionalInfo, NewPaper.MarginStandardMinimal, NewPaper.MarginThermalMinimal,
   NewPaper.RealWidth, NewPaper.RealHeight, NewPaper.RealImageableX, NewPaper.RealImageableY, NewPaper.RealImageableWidth, NewPaper.RealImageableHeight,
   NewPaper.WidthTolerance, NewPaper.HeightTolerance, NewPaper.MoveImageableX, NewPaper.MoveImageableY);
  return this;
 }
 
 public OPaper changeSize(double RealWidth, double RealHeight){
  setRealSize(RealWidth, RealHeight);
  generateSize();
  return this;
 }
 public OPaper changeImageableArea(double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight){
  setRealImageableArea(RealImageableX, RealImageableY, RealImageableWidth, RealImageableHeight);
  generateImageableArea();
  return this;
 }
 public OPaper changeSizeTolerance(double WidthTolerance, double HeightTolerance){
  setSizeTolerance(WidthTolerance, HeightTolerance);
  generateSize();
  return this;
 }
 public OPaper changeMoveImageableXY(double MoveImageableX, double MoveImageableY){
  setMoveImageableXY(MoveImageableX, MoveImageableY);
  generateSize();
  generateImageableArea();
  return this;
 }
 
 public OPaper changeMargin(OPaperMargin StandardMargin, OPaperMargin ThermalMargin){
  if(!IsRollPaper){return changeMargin(StandardMargin);}
  else{return changeMargin(ThermalMargin);}
 }
 public OPaper changeMargin(OPaperMargin Margin){
  return changeMargin(Margin.Top, Margin.Bottom, Margin.Left, Margin.Right);
 }
 public OPaper changeMargin(double Top, double Bottom, double Left, double Right){
  double vTop=RealImageableY;
  double vLeft=RealImageableX;
  double vRight=RealWidth-RealImageableWidth-vLeft;
  double vBottom=RealHeight-RealImageableHeight-vTop;
  
  if(Top>=0){vTop=Top;} if(Bottom>=0){vBottom=Bottom;} if(Left>=0){vLeft=Left;} if(Right>=0){vRight=Right;}
  changeImageableArea(vLeft, vTop, RealWidth-vLeft-vRight, RealHeight-vTop-vBottom);
  
  return this;
 }
 
 
 public Object clone() {
  return new OPaper(this);
 }
 public OPaper cloneWithMargin(double Top, double Bottom, double Left, double Right){
  return new OPaper(this).changeMargin(Top, Bottom, Left, Right);
 }
 public OPaper cloneWithMargin(OPaperMargin Margin){
  return new OPaper(this).changeMargin(Margin);
 }
 public OPaper cloneWithMargin(OPaperMargin StandardMargin, OPaperMargin ThermalMargin){
  return new OPaper(this).changeMargin(StandardMargin, ThermalMargin);
 }
 
 
 
 public static boolean validate(double RealWidth, double RealHeight, double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight){
  boolean ret=false;
  
  do{
   if(RealWidth<=0 || RealHeight<=0 || RealImageableX<0 || RealImageableY<0 || RealImageableWidth<=0 || RealImageableHeight<=0){break;}
   if(RealImageableX+RealImageableWidth>RealWidth || RealImageableY+RealImageableHeight>RealHeight){break;}
   ret=true;
  }while(false);
  
  return ret;
 }
 
 
 
}