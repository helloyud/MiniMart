public class VString {

 String Value;

 public VString() {}
 public VString(String Value) {this.Value = Value;}

}