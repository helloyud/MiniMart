import java.awt.Font;

public class OFont {
 
 String FontFamily;
 double CharWidth_1Point_XPixel; // inform 1 char's width at the size 1 point = ... pixel
 
 void setFont(String FontFamily){
  this.FontFamily=FontFamily;
  CharWidth_1Point_XPixel=PGraphics.getStringWidth(new Font(FontFamily, Font.PLAIN, 1), "W");
 }
 
 public float getPointSize(double CharWidth_XPixel){
  return (float)(CharWidth_XPixel/CharWidth_1Point_XPixel);
 }
 public float getPointSize(OFont OtherFont, float OtherFont_XPoint){
  return getPointSize(OtherFont.getPixelSize(OtherFont_XPoint));
 }
 public double getPixelSize(float CharWidth_XPoint){
  return CharWidth_XPoint*CharWidth_1Point_XPixel;
 }

}