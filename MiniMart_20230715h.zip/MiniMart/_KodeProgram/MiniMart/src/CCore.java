import java.io.File;

class CCore{
 
 public static final int TypeUnknown=0;
 public static final int TypeString=1;
 public static final int TypeInteger=2;
 public static final int TypeLong=3;
 public static final int TypeDouble=4;
 public static final int TypeBoolean=5;
 public static final int TypeDate=6;
 public static final int TypeBinary=7;
 public static final int TypeChar=8;

 public static final String vNull=new String("null");
 public static final String vTrue=new String("true");
 public static final String vFalse=new String("false");
 public static final String vTrueIndonesia=new String("ya");
 public static final String vFalseIndonesia=new String("tidak");
 public static final String vEmpty=new String("");
 
 public static final char Slash=File.separatorChar;
 
 public static final char[] Chars_a_z=PCore.newCharacterArrayInOrderedSequence('a', 'z');
 public static final char[] Chars_A_Z=PCore.newCharacterArrayInOrderedSequence('A', 'Z');
 public static final char[] Chars_0_9=PCore.newCharacterArrayInOrderedSequence('0', '9');
 public static final char[] Chars_Symbol={
  '`', '~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '=',
  '+', '[', ']', '{', '}', '|', ';', ':', '"', ',', '<', '>', '.', '/', '?',
  '\\', '\''
 };
 public static final char[] Chars_WhiteSpace={' ', '\t'};
 public static final char[] Chars_LineBreak={'\n', '\r'};
 public static final char[] Chars_WhiteChar={' ', '\t', '\n', '\r'};
 public static final char[] Chars_Separator={' ', '\t', '\n', '\r'};
 
 public static char[] CsvFieldDelimiters={'\"', '\''};
 public static char[] CsvFieldsSeparators={',', ';', '\t'};
 public static char[] CsvRecordsSeparators={'\n', '\r'};
 public static String[] CsvCharsets={"UTF-8", "ISO-8859-1", "US-ASCII"};
 
 public static char CsvDefaultFieldDelimiter='\"';
 public static char CsvDefaultFieldsSeparator=',';
 public static char CsvDefaultRecordsSeparator='\n';
 public static String CsvDefaultCharset="UTF-8";
 
 public static int NumberDigit=15;
 public static int FractionDigit=9;
 public static int RoundDigit=3;
 
 public static int Display_Normal_NumberDigit=10;
 public static int Display_Normal_FractionDigit=3;
 
 final static char NumericSeparatorThousand=',';
 final static char NumericSeparatorFraction='.';
 
 public static int getDisplayDigitMaxChars(int Mode){
  // Mode = 0 normal
  int NumberDigit=Display_Normal_NumberDigit;
  int FractionDigit=Display_Normal_FractionDigit;
  
  switch(Mode){
   default : NumberDigit=Display_Normal_NumberDigit; FractionDigit=Display_Normal_FractionDigit; break;
  }
  
  return PText.getCharsCountOfDigit(NumberDigit, FractionDigit, true, true);
 }
 
 public static int CharsCount_Int(){return 9;}
 public static int CharsCount_Long(){return 18;}
 public static int CharsCount_DoublePercentage(){return 6;}
 public static int CharsCount_Deci(){return PText.getCharsCountOfDigit(NumberDigit, FractionDigit, false, false);}
 public static int CharsCount_DeciSigned(){return PText.getCharsCountOfDigit(NumberDigit, FractionDigit, false, true);}
 
 public static String getDbDataType_Fraction(){return "Decimal("+(NumberDigit+FractionDigit)+","+FractionDigit+")";}
 
 public static long SmallestEnumerationOfId_WithoutBarcodeGenerator=1;
 public static long SmallestEnumerationOfId_WithBarcodeGenerator=1;
 
}