import java.sql.ResultSetMetaData;
import java.util.Vector;

public interface OCustomModel {
 
 public int[] getColumnsType();
	public int getColumnsCount();
 public void updateColumnsInfo(ResultSetMetaData RsM) throws Exception;
 
 public Vector<Object[]> getRows();
 public void append(Object[] NewRow);
 public void append(Vector<Object[]> NewData);
 public void insert(int RowIndex, Object[] NewRow);
 public void changeValue(int RowIndex, Object[] NewValue);
 public void remove(int RowIndex);
 public void remove(int[] RowsIndex);
 public void remove(int[] RowsIndex, boolean[] IsRemove);
 public void removeAll();
 
 public Vector<Object[]> subData(int[] Columns, int[] SelectedRows);
 public Object[] getObjects(int Column, int[] SelectedRows);
 public long[] getIds(int Column, int[] SelectedRows);
 
 public boolean isCheckable();
 public Vector<Boolean> getCheckList();
 public Vector<Boolean> getCheckList(int[] Rows);
 public boolean getCheckDefaultNewValue();
 public int getCheckedCount();
 public void setCheckedCount(int CheckedCount);
 public void addCheckedCount(int AddValue, boolean IsAdd);
 public boolean getChecked(int RowIndex);
 public int[] getChecked(boolean Value);
 public int[] getChecked(int[] RowsIndex, boolean Value);
 public boolean setChecked(int RowIndex, boolean Chk);
 public int[] setChecked(int[] Indices, boolean Chk);
 public int[] checkAll(boolean CheckValue);
 public Object[] check(long[] Data, int Column, int[] RangeRows,
  int IfFound_AddRowMode, boolean IfFound_IsUpdate, boolean IfFound_UpdateValue,
  int IfNotFound_AddRowMode, boolean IfNotFound_IsUpdate, boolean IfNotFound_UpdateValue);
 public int[] check(long[] Data, boolean Chk, int Column);
 public long[] getCheckedLong(int Column);
 
 public void refreshInsert(int StartIndex, int EndIndex);
 public void refreshUpdate(int StartIndex, int EndIndex);
 public void refreshRemove(int StartIndex, int EndIndex);
}