interface OBarcodeGenerator {
 public long generateCompatibleBarcodeFromNumber(long Number);
 public long generateCompatibleBarcodeFromNumberGetErrorSign();
 public String generateCompatibleBarcodeFromText(String Word);
 public String generateCompatibleBarcodeFromTextGetErrorSign();
}