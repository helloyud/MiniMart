import java.util.Vector;

public class OCalculationOperandTableCell
 extends OCalculationOperand{
 
 OCustomModel Model;
 Vector<Object[]> Rows;
 int[] ColumnsType;
	
	// active cell (TableRowIndex already defined in OCalculationOperand)
	int TableColumnIndex;
	
	// get cell
 int GetColMode; // 0 follow active cell, 1 static, 2 reference
	int GetCol;
 int GetRowMode; // 0 follow active cell, 1 static, 2 reference
	int GetRow;
	
	double ChangeGetInvalidCell;
	double ChangeNullValue;

 public OCalculationOperandTableCell(
  OCustomModel Model, Vector<Object[]> Rows, int[] ColumnsType,
		int TableColumnIndex,
		int GetColMode, int GetCol,
		int GetRowMode, int GetRow,
		double ChangeGetInvalidCell,
		double ChangeNullValue) {
  
  this.Model=Model;
  this.Rows=Rows;
  this.ColumnsType=ColumnsType;
		
		this.TableColumnIndex=TableColumnIndex;
  
		this.GetColMode=GetColMode;
		this.GetCol=GetCol;
		this.GetRowMode=GetRowMode;
		this.GetRow=GetRow;
		
		this.ChangeGetInvalidCell=ChangeGetInvalidCell;
	 this.ChangeNullValue=ChangeNullValue;
 }
 public OCalculationOperandTableCell(OCustomModel Model,
		int TableColumnIndex,
		int GetColMode, int GetCol,
		int GetRowMode, int GetRow,
		double ChangeGetInvalidCell,
		double ChangeNullValue) {
  
  this(Model, Model.getRows(), Model.getColumnsType(), TableColumnIndex, GetColMode, GetCol, GetRowMode, GetRow, ChangeGetInvalidCell, ChangeNullValue);
 }
 
 Vector<Object[]> getRows(){
  if(Model==null){return Rows;}else{return Model.getRows();}
 }
 
 public double getOperand(){
  double ret=0;
		int Row;
		int Col;
		Vector<Object[]> Data=getRows();
  
		Row=TableRowIndex;
		switch(GetRowMode){
			case 1 : Row=GetRow; break;
			case 2 : Row=TableRowIndex+GetRow; break;
		}
		
		Col=TableColumnIndex;
		switch(GetColMode){
			case 1 : Col=GetCol; break;
			case 2 : Col=TableColumnIndex+GetCol; break;
		}
		
		if(Row<0 || Row>=Data.size() || Col<0 || Col>=ColumnsType.length){return ChangeGetInvalidCell;}
		
  Object Obj=Data.elementAt(Row)[Col];
		
		if(Obj==null){return ChangeNullValue;}
		
  switch(ColumnsType[Col]){
   case CCore.TypeInteger : ret=(Integer)Obj; break;
   case CCore.TypeLong : ret=(Long)Obj; break;
   case CCore.TypeDouble : ret=(Double)Obj; break;
  }
		
  return ret;
 }
 
}