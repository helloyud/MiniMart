import java.awt.Graphics2D;
import java.util.Vector;

public class OLabelCreatorTestPrint extends OLabelCreator {
 
 final double DotSize=OUnit.mm_to_pixel(1.0);
 final double TestLabel_MarginHorizontal=OUnit.mm_to_pixel(0.7);
 final double TestLabel_MarginVertical=OUnit.mm_to_pixel(0.7);
 
 double Dot_InsetXLeft, Dot_InsetXCenter, Dot_InsetXRight,
  Dot_InsetYTop, Dot_InsetYCenter, Dot_InsetYBottom;
 
 public OLabelCreatorTestPrint(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  BoxWidthMin=0;
  BoxHeightMin=0;
 }
 protected void initDrawComponentsVariables(){
  super.initDrawComponentsVariables();
  
  // define test label's margin
  initMargin(TestLabel_MarginHorizontal, TestLabel_MarginVertical);
 }
 protected String getName(){return "Test)";}
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  
  ret.addElement(new OPaperLabel(CPrint.A4Half, OUnit.mm_to_pixel(20), OUnit.mm_to_pixel(10), 0, 0, 0, false, true, true, false, false));
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 1-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return true;}
 protected boolean isLabelRotatedInternalPaper(){return false;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 public boolean genLayoutVariables(){
  BoxWidth=LabelWidth;
  BoxHeight=LabelHeight;
  
  return true;
 }
 protected void postGenLayoutVariables(){
  Dot_InsetXLeft=AreaX+(0);
  Dot_InsetXCenter=AreaX+((AreaWidth/2)-(DotSize/2));
  Dot_InsetXRight=AreaX+(AreaWidth-DotSize);
  Dot_InsetYTop=AreaY+(0);
  Dot_InsetYCenter=AreaY+((AreaHeight/2)-(DotSize/2));
  Dot_InsetYBottom=AreaY+(AreaHeight-DotSize);
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  // draw top
  g.fillOval(PMath.round(Scaled_BoxX+Dot_InsetXCenter, 2), PMath.round(Scaled_BoxY+Dot_InsetYTop, 1), PMath.round(DotSize, 1), PMath.round(DotSize, 1));
  
  // draw bottom
  g.fillOval(PMath.round(Scaled_BoxX+Dot_InsetXCenter, 2), PMath.round(Scaled_BoxY+Dot_InsetYBottom, 2), PMath.round(DotSize, 1), PMath.round(DotSize, 1));
  
  // draw left
  g.fillOval(PMath.round(Scaled_BoxX+Dot_InsetXLeft, 1), PMath.round(Scaled_BoxY+Dot_InsetYCenter, 2), PMath.round(DotSize, 1), PMath.round(DotSize, 1));
  
  // draw right
  g.fillOval(PMath.round(Scaled_BoxX+Dot_InsetXRight, 2), PMath.round(Scaled_BoxY+Dot_InsetYCenter, 2), PMath.round(DotSize, 1), PMath.round(DotSize, 1));
 }
 
}