import java.util.Date;

public class OEditConverting {

 boolean EditConvDate; Date EditedConvDate;
 boolean EditReasonOfConv; Integer EditedReasonOfConvId; String EditedReasonOfConvName;
 boolean EditConvRuleDirection; Boolean EditedConvRuleDirection;
 boolean EditConvRuleCount; Double EditedConvRuleCount;

 public OEditConverting(){clearAll();}
 
 OEditConverting clearAll(){
  init(
   false, null,
   false, -1, null,
   false, false,
   false, 0);
  
  return this;
 }
 
 OEditConverting init(
  boolean EditConvDate, Date EditedConvDate,
  boolean EditReasonOfConv, int EditedReasonOfConvId, String EditedReasonOfConvName,
  boolean EditConvRuleDirection, boolean EditedConvRuleDirection,
  boolean EditConvRuleCount, double EditedConvRuleCount) {
  
  this.EditConvDate = EditConvDate; this.EditedConvDate = EditedConvDate;
  this.EditReasonOfConv = EditReasonOfConv; this.EditedReasonOfConvId = EditedReasonOfConvId; this.EditedReasonOfConvName = EditedReasonOfConvName;
  this.EditConvRuleDirection = EditConvRuleDirection; this.EditedConvRuleDirection = EditedConvRuleDirection;
  this.EditConvRuleCount = EditConvRuleCount; this.EditedConvRuleCount = EditedConvRuleCount;
 
  return this;
 }
 
 

}