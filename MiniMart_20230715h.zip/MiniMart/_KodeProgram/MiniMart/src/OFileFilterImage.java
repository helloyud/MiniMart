import java.io.File;
import javax.swing.filechooser.FileFilter;

public class OFileFilterImage extends FileFilter{
 public boolean accept(File path){
  boolean ret=true;
  String FileName;
  if(path.isFile()==true){
   FileName=path.getName();
   do{
    if(PFile.compareIgnoreCaseExtension(FileName, "jpg")){break;}
    if(PFile.compareIgnoreCaseExtension(FileName, "jpeg")){break;}
    if(PFile.compareIgnoreCaseExtension(FileName, "png")){break;}
    if(PFile.compareIgnoreCaseExtension(FileName, "gif")){break;}
    if(PFile.compareIgnoreCaseExtension(FileName, "bmp")){break;}
    ret=false;
   }while(false);
  }
  return ret;
 }
 public String getDescription(){
  return new String("File Gambar (jpg, jpeg, png, gif, bmp)");
 }
}
