import java.util.Date;

public class OEditItemVariant {
 
 boolean EditVariant; int EditVariantMode; boolean EditVariantSub; String EditedVariantSub; String EditedVariant;
 boolean EditIsActive; int EditIsActiveMode; Boolean EditedIsActive;
 boolean EditBuyPrice; int EditBuyPriceMode; Double EditedBuyPrice;
 boolean EditBuyComment; int EditBuyCommentMode; boolean EditBuyCommentSub; String EditedBuyCommentSub; String EditedBuyComment;
 boolean EditBuyUpdate; int EditBuyUpdateMode; Date EditedBuyUpdate;
 boolean EditComment; int EditCommentMode; boolean EditCommentSub; String EditedCommentSub; String EditedComment;
 boolean EditPictureFile; int EditPictureFileMode; String EditedPictureFile;
 
 public OEditItemVariant(){clearAll();}
 
 OEditItemVariant clearAll(){
  init(
   false, 0, false, null, null,
   false, 0, true,
   false, 0, 0,
   false, 0, false, null, null,
   false, 0, null,
   false, 0, false, null, null,
   false, 0, null);
  
  return this;
 }

 OEditItemVariant init(
  boolean EditVariant, int EditVariantMode, boolean EditVariantSub, String EditedVariantSub, String EditedVariant,
  boolean EditIsActive, int EditIsActiveMode, boolean EditedIsActive,
  boolean EditBuyPrice, int EditBuyPriceMode, double EditedBuyPrice,
  boolean EditBuyComment, int EditBuyCommentMode, boolean EditBuyCommentSub, String EditedBuyCommentSub, String EditedBuyComment,
  boolean EditBuyUpdate, int EditBuyUpdateMode, Date EditedBuyUpdate,
  boolean EditComment, int EditCommentMode, boolean EditCommentSub, String EditedCommentSub, String EditedComment,
  boolean EditPictureFile, int EditPictureFileMode, String EditedPictureFile) {
  this.EditVariant = EditVariant; this.EditVariantMode = EditVariantMode; this.EditVariantSub = EditVariantSub; this.EditedVariantSub = EditedVariantSub; this.EditedVariant = EditedVariant;
  this.EditIsActive = EditIsActive; this.EditIsActiveMode = EditIsActiveMode; this.EditedIsActive = EditedIsActive;
  this.EditBuyPrice = EditBuyPrice; this.EditBuyPriceMode = EditBuyPriceMode; this.EditedBuyPrice = EditedBuyPrice;
  this.EditBuyComment = EditBuyComment; this.EditBuyCommentMode = EditBuyCommentMode; this.EditBuyCommentSub = EditBuyCommentSub; this.EditedBuyCommentSub = EditedBuyCommentSub; this.EditedBuyComment = EditedBuyComment;
  this.EditBuyUpdate = EditBuyUpdate; this.EditBuyUpdateMode = EditBuyUpdateMode; this.EditedBuyUpdate = EditedBuyUpdate;
  this.EditComment = EditComment; this.EditCommentMode = EditCommentMode; this.EditCommentSub = EditCommentSub; this.EditedCommentSub = EditedCommentSub; this.EditedComment = EditedComment;
  this.EditPictureFile = EditPictureFile; this.EditPictureFileMode = EditPictureFileMode; this.EditedPictureFile = EditedPictureFile;
  
  return this;
 }
 
}