public class CDate {
 
 public final static int January   =  1;
 public final static int February  =  2;
 public final static int March     =  3;
 public final static int April     =  4;
 public final static int May       =  5;
 public final static int June      =  6;
 public final static int July      =  7;
 public final static int August    =  8;
 public final static int September =  9;
 public final static int October   = 10;
 public final static int November  = 11;
 public final static int December  = 12;
 
 public static int monthToCalendarIndex(int Month){return Month-1;}
 
}