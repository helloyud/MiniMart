import java.sql.ResultSetMetaData;
import java.util.Vector;
import javax.swing.AbstractListModel;

class OCustomListModel extends AbstractListModel
 implements OCustomModel{
 
 OCustomModelCommon Mdl;
 
 // set
 int MainColumn;
 
 String CheckPrefix;
 String CheckSuffix;
 
 boolean DisplayData;
 
 String[] AdditionalRows;
 int AdditionalRowsCount;
 boolean DisplayAdditionalRows;
 
 // constructor
 public OCustomListModel(boolean EnableCheck_){
  init(EnableCheck_, false, "", " *", false, -1);
 }
 public OCustomListModel(boolean EnableCheck_, boolean CheckDefaultNewValue_){
  init(EnableCheck_, CheckDefaultNewValue_, "", " *", false, -1);
 }
 public OCustomListModel(boolean EnableCheck_, boolean CheckDefaultNewValue_, String CheckPrefix, String CheckSuffix){
  init(EnableCheck_, CheckDefaultNewValue_, CheckPrefix, CheckSuffix, false, -1);
 }
 void init(boolean EnableCheck_, boolean CheckDefaultNewValue, String CheckPrefix, String CheckSuffix, boolean EnableIndex, int IndexColumn){
  Mdl=new OCustomModelCommon();
  Mdl.init(this, EnableCheck_, CheckDefaultNewValue, false, EnableIndex, IndexColumn);
  
  this.CheckPrefix=CheckPrefix;
  this.CheckSuffix=CheckSuffix;
  
  DisplayData=true;
  
  AdditionalRows=null;
  AdditionalRowsCount=0;
  DisplayAdditionalRows=false;
 }
 
 
 // metadata methods
 void setColumnsInfo(int[] ColumnsType_, int MainColumn_){
  Mdl.ColumnsType=ColumnsType_;
  Mdl.ColumnsCount=Mdl.ColumnsType.length;
  MainColumn=MainColumn_;
 }
 public void updateColumnsInfo(ResultSetMetaData RsM) throws Exception{
  int[] ColumnsType_;
  int temp, temp_;
  removeAll();
  temp=RsM.getColumnCount();
  ColumnsType_=new int[temp];
  temp_=0;
  do{
   ColumnsType_[temp_]=PDatabase.convertJavaSQLDataTypeToMyType(RsM, temp_+1);
   temp_=temp_+1;
  }while(temp_!=temp);
  if(MainColumn>=temp){MainColumn=0;}
  setColumnsInfo(ColumnsType_, MainColumn);
 }
 void setAdditinalRows(int AdditionalRowsType){
  int temp;
  switch(AdditionalRowsType){
   case 1 : // -- undefined --
    AdditionalRowsCount=1;
    AdditionalRows=new String[1];
    AdditionalRows[0]="Tidak Didefenisikan";
    break;
   case 2 : // -- alphabet --
    AdditionalRowsCount=27;
    AdditionalRows=new String[27];
    AdditionalRows[0]=String.valueOf('#');
    temp=0;
    do{
     AdditionalRows[1+temp]=String.valueOf((char)((int)'A'+temp));
     temp=temp+1;
    }while(temp!=26);
    break;
  }
 }
 
 // Mdl methods
 public int getColumnsCount(){return Mdl.getColumnsCount();}
 public int[] getColumnsType(){return Mdl.getColumnsType();}
 
 public Vector<Object[]> getRows(){return Mdl.getRows();}

 public void insert_(int RowIndex, Object[] NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.insert_(RowIndex, NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void insert(int RowIndex, Object[] NewRow, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.insert(RowIndex, NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void insert(int RowIndex, Object[] NewRow){Mdl.insert(RowIndex, NewRow);}
 public void append_(Object[] NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append_(NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append(NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow){Mdl.append(NewRow);}
 public void append(Vector<Object[]> NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append(NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Vector<Object[]> NewData){Mdl.append(NewData);}
 public void remove_(int RowIndex){Mdl.remove_(RowIndex);}
 public void remove(int RowIndex){Mdl.remove(RowIndex);}
 public void remove(int[] RowsIndex){Mdl.remove(RowsIndex);}
 public void remove(int[] RowsIndex, boolean[] IsRemove){Mdl.remove(RowsIndex, IsRemove);}
 public void removeAll(){Mdl.removeAll();}
 public void changeValue_(int RowIndex, Object[] NewValue){Mdl.changeValue_(RowIndex, NewValue);}
 public void changeValue(int RowIndex, Object[] NewValue){Mdl.changeValue(RowIndex, NewValue);}
 
 public Vector<Object[]> subData(int[] Columns, int[] SelectedRows){return Mdl.subData(Columns, SelectedRows);}
 public Object[] getObjects(int Column, int[] SelectedRows){return Mdl.getObjects(Column, SelectedRows);}
 public long[] getIds(int Column, int[] SelectedRows){return Mdl.getIds(Column, SelectedRows);}
 
 public boolean isCheckable(){return Mdl.isCheckable();}
 public Vector<Boolean> getCheckList(){return Mdl.getCheckList();}
 public Vector<Boolean> getCheckList(int[] Rows){return Mdl.getCheckList(Rows);}
 public boolean getCheckDefaultNewValue(){return Mdl.getCheckDefaultNewValue();}
 public int getCheckedCount(){return Mdl.getCheckedCount();}
 public void setCheckedCount(int CheckedCount){Mdl.setCheckedCount(CheckedCount);}
 public void addCheckedCount(int AddValue, boolean IsAdd){Mdl.addCheckedCount(AddValue, IsAdd);}
 public boolean getChecked(int RowIndex){return Mdl.getChecked(RowIndex);}
 public int[] getChecked(boolean Value){return Mdl.getChecked(Value);}
 public int[] getChecked(int[] RowsIndex, boolean Value){return Mdl.getChecked(RowsIndex, Value);}
 public long[] getCheckedLong(int Column){return Mdl.getCheckedLong(Column);}
 public boolean setChecked(int RowIndex, boolean Chk){return Mdl.setChecked(RowIndex, Chk);}
 public int[] setChecked(int[] Indices, boolean Chk){return Mdl.setChecked(Indices, Chk);}
 public int[] checkAll(boolean CheckValue){return Mdl.checkAll(CheckValue);}
 public Object[] check(long[] Data, int Column, int[] RangeRows, int IfFound_AddRowMode, boolean IfFound_IsUpdate, boolean IfFound_UpdateValue,
  int IfNotFound_AddRowMode, boolean IfNotFound_IsUpdate, boolean IfNotFound_UpdateValue){
  return Mdl.check(Data, Column, RangeRows, IfFound_AddRowMode, IfFound_IsUpdate, IfFound_UpdateValue,
   IfNotFound_AddRowMode, IfNotFound_IsUpdate, IfNotFound_UpdateValue);
 }
 public int[] check(long[] Data, boolean Chk, int Column){
  return Mdl.check(Data, Chk, Column);
 }
 
 // GUI methods
 public String getNativeElementAt(int Index){
  int RowIndex=Index;
  if(DisplayAdditionalRows){
   if(RowIndex<AdditionalRowsCount){
    return AdditionalRows[RowIndex];
   }
   RowIndex=RowIndex-AdditionalRowsCount;
  }
  return PText.getStringObj(Mdl.Rows.elementAt(RowIndex)[MainColumn], null, false);
 }
 public String getElementAt(int Index){
  String ret=null;
  int RowIndex=Index;
  
  if(DisplayAdditionalRows){
   if(RowIndex<AdditionalRowsCount){
    return "- "+AdditionalRows[RowIndex]+" -";
   }
   RowIndex=RowIndex-AdditionalRowsCount;
  }
  
  ret=PText.getStringObj(Mdl.Rows.elementAt(RowIndex)[MainColumn], "", false);
  if(Mdl.EnableCheck){
   if(Mdl.Checked.elementAt(RowIndex)){ret=CheckPrefix+ret+CheckSuffix;}
  }
  
  return ret;
 }
 public int getSize(){
  int ret=0;
  if(DisplayData){ret=ret+Mdl.Rows.size();}
  if(DisplayAdditionalRows){ret=ret+AdditionalRowsCount;}
  return ret;
 }
 /*
  the index0 & index1 in this class's methods (fireInterval Added, Changed, and Removed) are assumed
  data index & not gui index (Vector<Object[]> Rows's index)
 */
 public void fireIntervalAdded(Object source, int index0, int index1) {
  int temp;
  if(!DisplayData){return;}
  temp=0;
  if(DisplayAdditionalRows){temp=AdditionalRowsCount;}
  super.fireIntervalAdded(source, temp+index0, temp+index1);
 }
 public void fireContentsChanged(Object source, int index0, int index1) {
  int temp;
  if(!DisplayData){return;}
  temp=0;
  if(DisplayAdditionalRows){temp=AdditionalRowsCount;}
  super.fireContentsChanged(source, temp+index0, temp+index1);
 }
 public void fireIntervalRemoved(Object source, int index0, int index1) {
  int temp;
  if(!DisplayData){return;}
  temp=0;
  if(DisplayAdditionalRows){temp=AdditionalRowsCount;}
  super.fireIntervalRemoved(source, temp+index0, temp+index1);
 }
 public void refreshInsert(int StartIndex, int EndIndex){fireIntervalAdded(this, StartIndex, EndIndex);}
 public void refreshUpdate(int StartIndex, int EndIndex){fireContentsChanged(this, StartIndex, EndIndex);}
 public void refreshRemove(int StartIndex, int EndIndex){fireIntervalRemoved(this, StartIndex, EndIndex);}
 public void changeDisplay(boolean DisplayData_, boolean DisplayAdditionalRows_){
  int count;
  
  if(DisplayData==DisplayData_ && DisplayAdditionalRows==DisplayAdditionalRows_){
   return;
  }
  
  // clear current display
  count=getSize();
  if(count!=0){
   DisplayData=false;
   DisplayAdditionalRows=false;
   super.fireIntervalRemoved(this, 0, count-1);
  }
  
  // update current display
  DisplayData=DisplayData_;
  DisplayAdditionalRows=DisplayAdditionalRows_;
  count=getSize();
  if(count!=0){
   super.fireIntervalAdded(this, 0, count-1);
  }
 }

}