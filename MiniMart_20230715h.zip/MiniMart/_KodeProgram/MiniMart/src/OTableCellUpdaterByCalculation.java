import java.util.Vector;

public class OTableCellUpdaterByCalculation
 extends OTableCellUpdater{

 OCalculationOperand FirstOperand;
 OCalculation Calc;

 public OTableCellUpdaterByCalculation(int TableColumnIndex,
  OCalculationOperand FirstOperand, OCalculation Calc) {
  init(TableColumnIndex);
  this.FirstOperand=FirstOperand;
  this.Calc = Calc;
 }

 public void update(int TableRowIndex){
  Vector<Object[]> Data=getRows();
  OCalculationResult Result=new OCalculationResult();
  Object Obj;
  FirstOperand.setTableRowIndex(TableRowIndex);
  Calc.calculateResultFromChainedCalculation(Result, FirstOperand, TableRowIndex);
  switch(ColumnsType[TableColumnIndex]){
   case CCore.TypeInteger : Obj=(int)Result.Result; break;
   case CCore.TypeLong : Obj=(long)Result.Result; break;
   case CCore.TypeDouble : Obj=(double)Result.Result; break;
   default : Obj=null; break;
  }
  Data.elementAt(TableRowIndex)[TableColumnIndex]=Obj;
 }

}