import java.sql.Statement;
import java.util.Vector;

public class OCsvImportValueDbCheck extends OCsvImportValueCheckable {
 
 Statement Stm;
 String QuerySelectExcludeCondition;
 OCsvImportValuesInColsAndValues QuerySelectCondition;
 boolean QueryCheckNull;
 
 int QueryError_ReturnSign;
 OCsvImportValue QueryError_ValidValue;
 
 int QueryEmpty_ReturnSign;
 OCsvImportValue QueryEmpty_ValidValue;
 
 int QueryNotEmpty_ReturnSign;
 OCsvImportValue QueryNotEmpty_ValidValue;

 public OCsvImportValueDbCheck(boolean GetValidFromThisClass,
  Statement Stm, String QuerySelectExcludeCondition, OCsvImportValuesInColsAndValues QuerySelectCondition, boolean QueryCheckNull,
  int QueryError_ReturnSign, OCsvImportValue QueryError_ValidValue,
  int QueryEmpty_ReturnSign, OCsvImportValue QueryEmpty_ValidValue,
  int QueryNotEmpty_ReturnSign, OCsvImportValue QueryNotEmpty_ValidValue) {
  super(GetValidFromThisClass);
  initVariables(Stm, QuerySelectExcludeCondition, QuerySelectCondition, QueryCheckNull, QueryError_ReturnSign, QueryError_ValidValue,
   QueryEmpty_ReturnSign, QueryEmpty_ValidValue, QueryNotEmpty_ReturnSign, QueryNotEmpty_ValidValue);
 }
 
 public void initVariables(
  Statement Stm, String QuerySelectExcludeCondition, OCsvImportValuesInColsAndValues QuerySelectCondition, boolean QueryCheckNull,
  int QueryError_ReturnSign, OCsvImportValue QueryError_ValidValue,
  int QueryEmpty_ReturnSign, OCsvImportValue QueryEmpty_ValidValue,
  int QueryNotEmpty_ReturnSign, OCsvImportValue QueryNotEmpty_ValidValue){
  this.Stm = Stm;
  this.QuerySelectExcludeCondition = QuerySelectExcludeCondition;
  this.QuerySelectCondition = QuerySelectCondition;
  this.QueryCheckNull=QueryCheckNull;
  this.QueryError_ReturnSign=QueryError_ReturnSign;
  this.QueryError_ValidValue=QueryError_ValidValue;
  this.QueryEmpty_ReturnSign=QueryEmpty_ReturnSign;
  this.QueryEmpty_ValidValue=QueryEmpty_ValidValue;
  this.QueryNotEmpty_ReturnSign=QueryNotEmpty_ReturnSign;
  this.QueryNotEmpty_ValidValue=QueryNotEmpty_ValidValue;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  super.prepareGenerateSQLValue(LastReadRecordFromFile);
  QuerySelectCondition.prepareGenerateSQLValue(LastReadRecordFromFile);
 }
 
 public int checkAndGenSQLValue(){
  int ret=OCsvImportValueCheckable.CheckError;
  OGeneratedSQLValue GeneratedQuerySelectCondition;
  OCsvImportValue ValidValue=null;
  OGeneratedSQLValue GeneratedValidValue;
  int CheckResult;
  
  do{
   try{
    GeneratedQuerySelectCondition=QuerySelectCondition.generateSQLValue();
    if(!GeneratedQuerySelectCondition.isGenerated()){break;}
    CheckResult=PDatabase.isQueryEmpty(Stm, QuerySelectExcludeCondition+" "+GeneratedQuerySelectCondition.getGeneratedSQLValue(), QueryCheckNull);
    switch(CheckResult){
     case 0 :
      ret=QueryEmpty_ReturnSign;
      if(ret==OCsvImportValueCheckable.CheckValid){ValidValue=QueryEmpty_ValidValue;}
      break;
     case 1 :
      ret=QueryNotEmpty_ReturnSign;
      if(ret==OCsvImportValueCheckable.CheckValid){ValidValue=QueryNotEmpty_ValidValue;}
      break;
     default :
      ret=QueryError_ReturnSign;
      if(ret==OCsvImportValueCheckable.CheckValid){ValidValue=QueryError_ValidValue;};
      break;
    }
    if(ret!=OCsvImportValueCheckable.CheckValid){break;}
    ret=OCsvImportValueCheckable.CheckError;
    if(ValidValue==null){break;}
    GeneratedValidValue=ValidValue.generateSQLValue();
    if(!GeneratedValidValue.isGenerated()){break;}
    GeneratedSQLValue.setGeneratedSQLValue(GeneratedValidValue.getGeneratedSQLValue());
    ret=OCsvImportValueCheckable.CheckValid;
   }
   catch(Exception E){}
  }while(false);
  
  return ret;
 }

}