import java.awt.Component;
import java.awt.event.KeyEvent;

public interface OFormSupportsComponentShortcut {
 public void fireKeyAction(Component Cmp, KeyEvent e);
}