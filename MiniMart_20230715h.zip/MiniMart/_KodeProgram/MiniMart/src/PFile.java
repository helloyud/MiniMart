import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Reader;

public class PFile{

 public static boolean createNewFile(File Directory,
  String FileName){
  boolean ret=false;
  File temp;
  String Directory_;
  if(Directory!=null && FileName!=null){
   Directory_=Directory.toString();
   if(Directory_.length()!=0 && FileName.length()!=0){
    try{
     if(Directory.isDirectory()!=true){
      if(Directory.mkdirs()==true){
       if(Directory_.charAt(Directory_.length()-1)==File.separatorChar){
        temp=new File(Directory_+FileName);
       }
       else{
        temp=new File(Directory_+File.separatorChar+FileName);
       }
       ret=temp.createNewFile();
      }
     }
     else{
      if(Directory_.charAt(Directory_.length()-1)==File.separatorChar){
       temp=new File(Directory_+FileName);
      }
      else{
       temp=new File(Directory_+File.separatorChar+FileName);
      }
      if(temp.isFile()==false){
       ret=temp.createNewFile();
      }
     }
    }
    catch(Exception E_){}
   }
  }
  return ret;
 }
 public static boolean createNewFolder(File Directory,
  String FolderName){
  boolean ret=false;
  File temp;
  String Directory_;
  if(Directory!=null && FolderName!=null){
   Directory_=Directory.toString();
   if(Directory_.length()!=0 && FolderName.length()!=0){
    try{
     if(Directory.isDirectory()!=true){
      if(Directory.mkdirs()==true){
       if(Directory_.charAt(Directory_.length()-1)==File.separatorChar){
        temp=new File(Directory_+FolderName);
       }
       else{
        temp=new File(Directory_+File.separatorChar+FolderName);
       }
       ret=temp.mkdir();
      }
     }
     else{
      if(Directory_.charAt(Directory_.length()-1)==File.separatorChar){
       temp=new File(Directory_+FolderName);
      }
      else{
       temp=new File(Directory_+File.separatorChar+FolderName);
      }
      if(temp.isDirectory()==false){
       ret=temp.mkdir();
      }
     }
    }
    catch(Exception E_){}
   }
  }
  return ret;
 }
 public static boolean delete(File Directory,
  String[] DirContents){
  boolean ret=false;
  boolean exit, exit_;
  int contentslength, temp,
      temp_, subcontentslength;
  OFiles files;
  OFile file_;
  File contentf, subcontentf;
  String dir, content;
  try{
   do{
    if(Directory==null || DirContents==null){break;}
    contentslength=DirContents.length;
    dir=Directory.toString();
    if(dir.length()==0 || contentslength==0){break;}
    if(Directory.isDirectory()==false){break;}
    if(dir.charAt(dir.length()-1)!=File.separatorChar){
     dir=new String(dir+File.separatorChar);
    }
    temp=0;
    files=new OFiles();
    exit=false;
    do{
     content=new String(dir+DirContents[temp]);
     contentf=new File(content);
     if(contentf.isDirectory()==true){
      if(listSubContents(files, contentf)==true){
       subcontentslength=files.getLength();
       if(subcontentslength!=0){
        files.resetReadIndex();
        temp_=0;
        exit_=false;
        do{
         file_=files.getFromReadIndex(true);
         if(file_.File_.delete()==true){
          temp_=temp_+1;
          if(temp_==subcontentslength){exit_=true;}
         }
         else{exit_=true;}
        }while(exit_==false);
        if(temp_==subcontentslength){
         if(contentf.delete()==true){
          temp=temp+1;
          if(temp==contentslength){exit=true;}
         }
         else{exit=true;}
        }
        else{exit=true;}
       }
       else{
        if(contentf.delete()==true){
         temp=temp+1;
         if(temp==contentslength){exit=true;}
        }
        else{exit=true;}
       }
      }
      else{exit=true;}
     }
     else if(contentf.isFile()==true){
      if(contentf.delete()==true){
       temp=temp+1;
       if(temp==contentslength){exit=true;}
      }
      else{exit=true;}
     }
     else{exit=true;}
    }while(exit==false);
    if(temp==contentslength){
     ret=true;
    }
   }while(false);
  }
  catch(Exception E_){}
  return ret;
 }
 public static boolean rename(File Directory,
  String DirContentOldName, String DirContentNewName){
  boolean ret=false;
  String Directory_;
  File temp1, temp2;
  if(Directory!=null && DirContentOldName!=null &&
     DirContentNewName!=null){
   Directory_=Directory.toString();
   if(Directory_.length()!=0 && DirContentOldName.length()!=0 &&
      DirContentNewName.length()!=0){
    try{
     if(Directory_.charAt(Directory_.length()-1)==File.separatorChar){
      temp1=new File(Directory_+DirContentOldName);
      temp2=new File(Directory_+DirContentNewName);
     }
     else{
      temp1=new File(Directory_+File.separatorChar+DirContentOldName);
      temp2=new File(Directory_+File.separatorChar+DirContentNewName);
     }
     if(temp1.isFile()==true){
      if(temp2.isFile()==false){
       ret=temp1.renameTo(temp2);
      }
     }
     else{
      if(temp2.isDirectory()==false){
       ret=temp1.renameTo(temp2);
      }
     }
    }
    catch(Exception E_){}
   }
  }
  return ret;
 }
 public static boolean copyAFileOverwrite(File Source,
  File Dest, int ClusterProcess){
  boolean ret=false;
  boolean exit;
  byte[] Bytes;
  long flength, copied;
  int div, divi;
  FileInputStream fis;
  FileOutputStream fos;
  File parent;
  if(Source!=null && Dest!=null && ClusterProcess>0){
   fis=null;
   fos=null;
   try{
    do{
     flength=Source.length();
     if(flength==0){
      if(Source.isFile()==false){
       break;
      }
     }
     if(Dest.isFile()==true){
      if(Dest.delete()==false){break;}
     }
     else{
      parent=getParentDirectory(Dest);
      if(parent.isDirectory()==false){
       if(parent.mkdirs()==false){break;}
      }
     }
     if(Dest.createNewFile()==false){break;}
     if(flength>0){
      fis=new FileInputStream(Source);
      fos=new FileOutputStream(Dest);
      if(flength<(long)ClusterProcess){
       Bytes=new byte[(int)flength];
       if(fis.read(Bytes)==(int)flength){
        fos.write(Bytes);
        ret=true;
       }
      }
      else{
       div=(int)(flength/ClusterProcess);
       divi=0;
       Bytes=new byte[ClusterProcess];
       copied=0;
       exit=false;
       do{
        if(fis.read(Bytes)==ClusterProcess){
         fos.write(Bytes);
         copied=copied+ClusterProcess;
         divi=divi+1;
         if(divi==div){exit=true;}
        }
        else{exit=true;}
       }while(exit==false);
       if(divi==div){
        if(copied!=flength){
         Bytes=new byte[(int)(flength-copied)];
         if(fis.read(Bytes)==Bytes.length){
          fos.write(Bytes);
          ret=true;
         }
        }
        else{ret=true;}
       }
      }
      fis.close();
      fis=null;
      fos.close();
      fos=null;
     }
     else{ret=true;}
    }while(false);
   }
   catch(Exception E_){
    ret=false;
    if(fis!=null){
     try{fis.close();}catch(Exception E__){}
    }
    if(fos!=null){
     try{fos.close();}catch(Exception E__){}
    }
   }
  }
  return ret;
 }
 public static boolean copyOverwrite(File SourceDirectory,
  String[] SourceContents, File DestDirectory){
  boolean ret=false;
  boolean bool, exit, exit_;
  int length, temp, temp_,
      subcontentslength, scontstrlength;
  String d1, d2, dcontent, ssubcontent;
  OFile file_;
  OFiles files;
  File scontentf, dcontentf,
       dsubcontentf, dsubcontentparentf;
  try{
   do{
    // check parameters
    if(SourceDirectory==null || SourceContents==null ||
     DestDirectory==null){break;}
    d1=SourceDirectory.toString();
    d2=DestDirectory.toString();
    length=SourceContents.length;
    if(d1.length()==0 || d2.length()==0 ||
     length==0){break;}
    if(SourceDirectory.isDirectory()==false){break;}
    if(DestDirectory.isDirectory()==true){
     if(DestDirectory.equals(SourceDirectory)==true){
      ret=true;
      break;
     }
    }
    else{
     if(DestDirectory.mkdirs()==false){
      break;
     }
    }
    if(d1.charAt(d1.length()-1)!=File.separatorChar){
     d1=new String(d1+File.separatorChar);
    }
    if(d2.charAt(d2.length()-1)!=File.separatorChar){
     d2=new String(d2+File.separatorChar);
    }
    temp=0;
    exit=false;
    do{
     scontentf=new File(d1+SourceContents[temp]);
     dcontentf=new File(d2+SourceContents[temp]);
     temp_=checkFirstPathLevel(dcontentf, scontentf);
     if(temp_==1 || temp_==4){
      exit=true;
     }
     else{
      temp=temp+1;
      if(temp==length){exit=true;}
     }
    }while(exit==false);
    
    if(temp!=length){break;}
    // prepare
    files=new OFiles();
    subcontentslength=0;
    // copy
    exit=false;
    temp=0;
    do{
     scontentf=new File(d1+SourceContents[temp]);
     dcontentf=new File(d2+SourceContents[temp]);
     if(scontentf.isFile()==true){
      if(copyAFileOverwrite(scontentf, dcontentf, 1024)==true){
       temp=temp+1;
       if(temp==length){exit=true;}
      }
      else{exit=true;}
     }
     else if(scontentf.isDirectory()==true){
      bool=true;
      if(dcontentf.isDirectory()==false){
       if(dcontentf.mkdir()==false){
        bool=false;
       }
      }
      if(bool==true){
       if(listSubContents(files, scontentf)==true){
        subcontentslength=files.getLength();
        if(subcontentslength!=0){
         scontstrlength=scontentf.toString().length();
         dcontent=new String(dcontentf.toString()+File.separatorChar);
         files.resetReadIndex();
         temp_=0;
         exit_=false;
         do{
          file_=files.getFromReadIndex(true);
          ssubcontent=file_.File_.toString();
          dsubcontentf=new File(dcontent+
           PText.subString(ssubcontent, scontstrlength,
           ssubcontent.length()-1));
          if(file_.IsDirectory==false){
           if(copyAFileOverwrite(file_.File_, dsubcontentf, 1024)==true){
            temp_=temp_+1;
            if(temp_==subcontentslength){exit_=true;}
           }
           else{exit_=true;}
          }
          else{
           if(dsubcontentf.isDirectory()==false){
            if(dsubcontentf.mkdirs()==true){
             temp_=temp_+1;
             if(temp_==subcontentslength){exit_=true;}
            }
            else{exit_=true;}
           }
           else{
            temp_=temp_+1;
            if(temp_==subcontentslength){exit_=true;}
           }
          }
         }while(exit_==false);
         if(temp_==subcontentslength){
          temp=temp+1;
          if(temp==length){exit=true;}
         }
         else{exit=true;}
        }
        else{
         temp=temp+1;
         if(temp==length){exit=true;}
        }
       }
       else{exit=true;}
      }
      else{exit=true;}
     }
     else{exit=true;}
    }while(exit==false);
    if(temp==length){
     ret=true;
    }
   }while(false);
  }
  catch(Exception E_){}
  return ret;
 }
 public static boolean moveOverwrite(File SourceDirectory,
  String[] SourceContents, File DestDirectory){
  boolean ret=false;
  boolean bool, exit, exit_;
  int length, temp, temp_,
      subcontentslength, scontstrlength;
  String d1, d2, dcontent, ssubcontent;
  OFile file_;
  OFiles files;
  File scontentf, dcontentf,
       dsubcontentf, dsubcontentparentf;
  try{
   do{
    // check parameters
    if(SourceDirectory==null || SourceContents==null ||
     DestDirectory==null){break;}
    d1=SourceDirectory.toString();
    d2=DestDirectory.toString();
    length=SourceContents.length;
    if(d1.length()==0 || d2.length()==0 ||
     length==0){break;}
    if(SourceDirectory.isDirectory()==false){break;}
    if(DestDirectory.isDirectory()==true){
     if(DestDirectory.equals(SourceDirectory)==true){
      ret=true;
      break;
     }
    }
    else{
     if(DestDirectory.mkdirs()==false){
      break;
     }
    }
    if(d1.charAt(d1.length()-1)!=File.separatorChar){
     d1=new String(d1+File.separatorChar);
    }
    if(d2.charAt(d2.length()-1)!=File.separatorChar){
     d2=new String(d2+File.separatorChar);
    }
    temp=0;
    exit=true;
    do{
     scontentf=new File(d1+SourceContents[temp]);
     dcontentf=new File(d2+SourceContents[temp]);
     temp_=checkFirstPathLevel(dcontentf, scontentf);
     if(temp_==1 || temp_==4){
      exit=true;
     }
     else{
      temp=temp+1;
      if(temp==length){exit=true;}
     }
    }while(exit==false);
    if(temp!=length){break;}
    // prepare
    files=new OFiles();
    subcontentslength=0;
    // move
    exit=false;
    temp=0;
    do{
     scontentf=new File(d1+SourceContents[temp]);
     dcontentf=new File(d2+SourceContents[temp]);
     if(scontentf.isFile()==true){
      if(copyAFileOverwrite(scontentf, dcontentf, 1024)==true){
       if(scontentf.delete()==true){
        temp=temp+1;
        if(temp==length){exit=true;}
       }
       else{exit=true;}
      }
      else{exit=true;}
     }
     else if(scontentf.isDirectory()==true){
      bool=true;
      if(dcontentf.isDirectory()==false){
       if(dcontentf.mkdir()==false){
        bool=false;
       }
      }
      if(bool==true){
       if(listSubContents(files, scontentf)==true){
        subcontentslength=files.getLength();
        if(subcontentslength!=0){
         scontstrlength=scontentf.toString().length();
         dcontent=new String(dcontentf.toString()+File.separatorChar);
         files.resetReadIndex();
         temp_=0;
         exit_=false;
         do{
          file_=files.getFromReadIndex(true);
          ssubcontent=file_.File_.toString();
          dsubcontentf=new File(dcontent+
           PText.subString(ssubcontent, scontstrlength,
           ssubcontent.length()-1));
          if(file_.IsDirectory==false){
           if(copyAFileOverwrite(file_.File_, dsubcontentf, 1024)==true){
            if(file_.File_.delete()==true){
             temp_=temp_+1;
             if(temp_==subcontentslength){exit_=true;}
            }
            else{exit_=true;}
           }
           else{exit_=true;}
          }
          else{
           if(dsubcontentf.isDirectory()==false){
            if(dsubcontentf.mkdirs()==true){
             if(file_.File_.delete()==true){
              temp_=temp_+1;
              if(temp_==subcontentslength){exit_=true;}
             }
             else{exit_=true;}
            }
            else{exit_=true;}
           }
           else{
            if(file_.File_.delete()==true){
             temp_=temp_+1;
             if(temp_==subcontentslength){exit_=true;}
            }
            else{exit_=true;}
           }
          }
         }while(exit_==false);
         if(temp_==subcontentslength){
          if(scontentf.delete()==true){
           temp=temp+1;
           if(temp==length){exit=true;}
          }
          else{exit=true;}
         }
         else{exit=true;}
        }
        else{
         if(scontentf.delete()==true){
          temp=temp+1;
          if(temp==length){exit=true;}
         }
         else{exit=true;}
        }
       }
       else{exit=true;}
      }
      else{exit=true;}
     }
     else{exit=true;}
    }while(exit==false);
    if(temp==length){
     ret=true;
    }
   }while(false);
  }
  catch(Exception E_){}
  return ret;
 }

 public static File getParentDirectory(File Path){
  File ret=null;
  String ret_;
  boolean isbefchar, exit;
  int temp, temp_;
  if(Path!=null){
   ret_=Path.toString();
   temp=ret_.length();
   if(temp!=0){
    temp=temp-1;
    isbefchar=false;
    exit=false;
    do{
     if(ret_.charAt(temp)==File.separatorChar){
      if(isbefchar==true){exit=true;}
      else{
       temp=temp-1;
       if(temp==-1){exit=true;}
      }
     }
     else{
      if(isbefchar==false){isbefchar=true;}
      temp=temp-1;
      if(temp==-1){exit=true;}
     }
    }while(exit==false);
    if(temp>=1){
     isbefchar=false;
     temp=temp-1;
     exit=false;
     do{
      if(ret_.charAt(temp)==File.separatorChar){
       temp=temp-1;
       if(temp==-1){exit=true;}
      }
      else{exit=true;}
     }while(exit==false);
     if(temp!=-1){
      if(temp!=0){
       temp_=temp-1;
       exit=false;
       do{
        if(ret_.charAt(temp_)==File.separatorChar){
         exit=true;
        }
        else{
         temp_=temp_-1;
         if(temp_==-1){exit=true;}
        }
       }while(exit==false);
       if(temp_!=-1){
        ret=new File(PText.subString(ret_,0,temp));
       }
       else{
        ret=new File(PText.subString(ret_,0,temp)+File.separatorChar);
       }
      }
      else{
       ret=new File(PText.subString(ret_,0,temp)+File.separatorChar);
      }
     }
     else{ret=new File("");}
    }
    else{ret=new File("");}
   }
   else{ret=new File("");}
  }
  return ret;
 }
 public static int type(File Directory, String DirContent){
  int ret=0; // 0 unknown, 1 file system, 2 folder, 3 file
  File f;
  String path_;
  if(Directory!=null && DirContent!=null){
   if(DirContent.length()!=0){
    try{
     path_=Directory.toString();
     if(path_.length()==0){
      f=new File(DirContent);
      if(f.isDirectory()==true){
       ret=1;
      }
     }
     else{
      if(path_.charAt(path_.length()-1)==File.separatorChar){
       f=new File(path_+DirContent);
      }
      else{
       f=new File(path_+File.separatorChar+DirContent);
      }
      if(f.isDirectory()==true){
       ret=2;
      }
      else if(f.isFile()==true){
       ret=3;
      }
     }
    }
    catch(Exception E_){}
   }
  }
  return ret;
 }

 public static boolean listSubContents(
  OFiles Contents, File CurrentDirectory){
  boolean ret=true;
  boolean dir, exit;
  File[] files;
  int length, temp;
  files=CurrentDirectory.listFiles();
  if(files!=null){
   length=files.length;
   if(length!=0){
    temp=0;
    exit=false;
    do{
     dir=files[temp].isDirectory();
     if(dir==true){
      if(listSubContents(Contents, files[temp])==true){
       Contents.append(new OFile(files[temp],dir));
       temp=temp+1;
       if(temp==length){exit=true;}
      }
      else{exit=true;}
     }
     else{
      Contents.append(new OFile(files[temp],dir));
      temp=temp+1;
      if(temp==length){exit=true;}
     }
    }while(exit==false);
    if(temp!=length){
     ret=false;
    }
   }
  }
  else{ret=false;}
  return ret;
 }
 public static int checkFirstPathLevel(
  File Path1, File Path2){
  int ret=0; // 0 different, 1 same, 3 parent directory, 4 sub directory
  boolean exit, exit_, p1empty, p2empty, charbef;
  int P1pos, P2pos, P1first, P1last,
      P2first, P2last, P1length, P2length,
      c1, c2, temp, temp_;
  String P1, P2;
  P1=null;
  P2=null;
  P2length=0;
  P1length=0;
  P1last=0;
  P2last=0;
  // check empty
  p1empty=false;
  if(Path1!=null){
   P1=Path1.toString();
   P1length=P1.length();
   if(P1length==0){p1empty=true;}
  }
  else{p1empty=true;}
  p2empty=false;
  if(Path2!=null){
   P2=Path2.toString();
   P2length=P2.length();
   if(P2length==0){p2empty=true;}
  }
  else{p2empty=true;}
  if(p1empty==true){
   if(p2empty==true){
    ret=1;
   }
   else{
    P2pos=0;
    exit=false;
    do{
     c2=(int)P2.charAt(P2pos);
     if(c2==(int)File.separatorChar || c2==(int)' '){
      P2pos=P2pos+1;
      if(P2pos==P2length){
       ret=1;
       exit=true;
      }
     }
     else{exit=true;}
    }while(exit==false);
   }
  }
  else{
   if(p2empty==false){
    P1pos=0;
    exit=false;
    do{
     c1=(int)P1.charAt(P1pos);
     if(c1==(int)File.separatorChar || c1==(int)' '){
      P1pos=P1pos+1;
      if(P1pos==P1length){
       p1empty=true;
       exit=true;
      }
     }
     else{exit=true;}
    }while(exit==false);
    P2pos=0;
    exit=false;
    do{
     c2=(int)P2.charAt(P2pos);
     if(c2==(int)File.separatorChar || c2==(int)' '){
      P2pos=P2pos+1;
      if(P2pos==P2length){
       p2empty=true;
       exit=true;
      }
     }
     else{exit=true;}
    }while(exit==false);
    if(p1empty==false){
     if(p2empty==false){
      P1pos=P1pos-1;
      P2pos=P2pos-1;
      exit=false;
      do{
       // get path1 sub directory
       // check last slash
       if(P1pos<P1length-1){
        P1first=P1pos+1;
        // get first char
        exit_=false;
        do{
         c1=(int)P1.charAt(P1first);
         if(c1==(int)File.separatorChar || c1==(int)' '){
          P1first=P1first+1;
          if(P1first==P1length){exit_=true;}
         }
         else{exit_=true;}
        }while(exit_==false);
        // get last char
        if(P1first!=P1length){
         if(P1first==P1length-1){
          P1last=P1first;
          P1pos=P1length;
         }
         else{
          P1pos=P1first+1;
          charbef=true;
          exit_=false;
          do{
           c1=(int)P1.charAt(P1pos);
           if(c1!=(int)File.separatorChar){
            if(c1!=(int)' '){
             if(charbef==false){
              charbef=true;
             }
            }
            else{
             if(charbef==true){
              charbef=false;
              P1last=P1pos-1;
             }
            }
            P1pos=P1pos+1;
            if(P1pos==P1length){
             if(charbef==true){
              P1last=P1pos-1;
             }
             exit_=true;
            }
           }
           else{
            if(charbef==true){
             P1last=P1pos-1;
            }
            exit_=true;
           }
          }while(exit_==false);
         }
        }
       }
       else{P1first=P1length;}
       // get path2 sub directory
       // check last slash
       if(P2pos<P2length-1){
        P2first=P2pos+1;
        // get first char
        exit_=false;
        do{
         c2=(int)P2.charAt(P2first);
         if(c2==(int)File.separatorChar || c2==(int)' '){
          P2first=P2first+1;
          if(P2first==P2length){exit_=true;}
         }
         else{exit_=true;}
        }while(exit_==false);
        // get last char
        if(P2first!=P2length){
         if(P2first==P2length-1){
          P2last=P2first;
          P2pos=P2length;
         }
         else{
          P2pos=P2first+1;
          charbef=true;
          exit_=false;
          do{
           c2=(int)P2.charAt(P2pos);
           if(c2!=(int)File.separatorChar){
            if(c2!=(int)' '){
             if(charbef==false){
              charbef=true;
             }
            }
            else{
             if(charbef==true){
              charbef=false;
              P2last=P2pos-1;
             }
            }
            P2pos=P2pos+1;
            if(P2pos==P2length){
             if(charbef==true){
              P2last=P2pos-1;
             }
             exit_=true;
            }
           }
           else{
            if(charbef==true){
             P2last=P2pos-1;
            }
            exit_=true;
           }
          }while(exit_==false);
         }
        }
       }
       else{P2first=P2length;}
       // compare, if different or 1 path is end then exit
       if(P1first!=P1length && P2first!=P2length){
        temp=P1last-P1first+1;
        if(temp==P2last-P2first+1){
         exit_=false;
         temp=P1first;
         temp_=P2first;
         do{
          c1=(int)P1.charAt(temp);
          if(c1>=97 && c1<=122){c1=c1-32;}
          c2=(int)P2.charAt(temp_);
          if(c2>=97 && c2<=122){c2=c2-32;}
          if(c1==c2){
           if(temp==P1last){
            temp=temp+1;
            exit_=true;
           }
           else{
            temp=temp+1;
            temp_=temp_+1;
           }
          }
          else{exit_=true;}
         }while(exit_==false);
         if(temp!=P1last+1){
          exit=true;
         }
        }
        else{exit=true;}
       }
       else{exit=true;}
      }while(exit==false);
      if(P1first==P1length){
       if(P2first==P2length){
        ret=1;
       }
       else{ret=3;}
      }
      else{
       if(P2first==P2length){
        ret=4;
       }
      }
     }
    }
    else{
     if(p2empty==true){ret=1;}
    }
   }
   else{
    P1pos=0;
    exit=false;
    do{
     c1=(int)P1.charAt(P1pos);
     if(c1==(int)File.separatorChar || c1==(int)' '){
      P1pos=P1pos+1;
      if(P1pos==P1length){
       ret=1;
       exit=true;
      }
     }
     else{
      exit=true;
     }
    }while(exit==false);
   }
  }
  return ret;
 }

 public static String ext(String FileName, String Extension){
  String ret=null;
  boolean exit;
  int ext, length, temp;
  int chara, charb;
  if(FileName!=null && Extension!=null){
   length=Extension.length();
   ext=FileName.length();
   if(length!=0 && ext!=0){
    ext=ext-1;
    exit=false;
    do{
     if(FileName.charAt(ext)=='.'){
      exit=true;
     }
     else{
      ext=ext-1;
      if(ext==-1){exit=true;}
     }
    }while(exit==false);
    if(ext!=-1){
     if(ext!=0){
      if(ext+length+1==FileName.length()){
       ext=ext+1;
       temp=0;
       exit=false;
       do{
        chara=(int)FileName.charAt(ext);
        if(chara>=97 && chara<=122){chara=chara-32;}
        charb=(int)Extension.charAt(temp);
        if(charb>=97 && charb<=122){charb=charb-32;}
        if(chara==charb){
         temp=temp+1;
         if(temp!=length){
          ext=ext+1;
         }
         else{exit=true;}
        }
        else{exit=true;}
       }while(exit==false);
       if(temp==length){
        ret=FileName;
       }
      }
     }
    }
    else{
     ret=new String(FileName+"."+Extension);
    }
   }
  }
  return ret;
 }
 public static String toDirectory(String Directory, char DirectorySeparator){
  String ret=Directory;
  if(Directory.charAt(Directory.length()-1)!=DirectorySeparator){
   ret=ret+DirectorySeparator;
  }
  return ret;
 }

 public static boolean compareIgnoreCaseExtension(
  String FileName, String Extension){
  boolean ret=false;
  boolean exit;
  int flength;
  int temp, temp_;
  int chara, charb;
  if(FileName!=null && Extension!=null){
   flength=FileName.length();
   if(Extension.length()!=0 && flength!=0){
    temp=flength-Extension.length()-1;
    if(temp>=1){
     if(FileName.charAt(temp)=='.'){
      temp_=0;
      temp=temp+1;
      exit=false;
      do{
       chara=(int)FileName.charAt(temp);
       if(chara>=97 && chara<=122){chara=chara-32;}
       charb=(int)Extension.charAt(temp_);
       if(charb>=97 && charb<=122){charb=charb-32;}
       if(chara==charb){
        temp=temp+1;
        if(temp!=flength){
         temp_=temp_+1;
        }
        else{
         ret=true;
         exit=true;
        }
       }
       else{exit=true;}
      }while(exit==false);
     }
    }
   }
  }
  return ret;
 }

 public static String[] getFilesName(File[] Files){
  String[] ret=null;
  int temp, length;
  
  if(Files==null){return ret;}
  length=Files.length;
  ret=new String[length];
  if(length==0){return ret;}
  
  temp=0;
  do{
   ret[temp]=Files[temp].getName();
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static int readFromInputStream(Reader is, VBoolean IsBufferedLastRead, VInteger BufferedLastRead) throws IOException{
  int ret;
  char readch;
  char linebreak_combination;
  int newread;

  if(IsBufferedLastRead.Value){IsBufferedLastRead.Value=false; return BufferedLastRead.Value;}
  
  ret=is.read(); 
  
  readch=(char)ret;
  if(readch=='\n' || readch=='\r'){
   newread=is.read(); linebreak_combination=(Character)PCore.subtituteBool(readch=='\n', '\r', '\n');
   if(newread!=linebreak_combination){BufferedLastRead.Value=newread; IsBufferedLastRead.Value=true;}
  }
  
  return ret;
 }

}