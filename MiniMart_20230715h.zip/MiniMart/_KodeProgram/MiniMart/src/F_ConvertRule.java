import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class F_ConvertRule extends XFormDialog
 implements OFormWithTempList, OFormSupportsComponentShortcut{
 
 // set
 int wMode; // 0 Normal (New, Edit, Remove), 1 Choose (Choose)
 boolean wDialogWithFItem;
 boolean wAllowMultipleSelection;
 boolean wChooseActiveOnly;
 
 // get
 Long[] ChoosedId;
 String[] ChoosedName;
 Boolean[] ChoosedIsActive;
 Date[] ChoosedLastUpdate;
 
 // query
 OCustomListModel ListMdlQItemCategory;
 OCustomTableModel TableMdlQItem;
 
 Component LastFocusedCmpSearch;
 
 // query by item
  // All
 boolean QueryByItemPrepared;
 int LastFocusedCmpSearchFItem;
  
  // Filter (F)
 OCustomTableModel TableMdlFCat;
 
 int[] LastSelectedRowFCat;
 boolean FilledFCat;
 
  // Result of Filter (R)
 OCustomTableModel TableMdlRItem;
 
 String[] TableRItemColsName;
 int[] TableRItemColsType, TableRItemColsShowOption, TableRItemColsVisible, TableRItemColsWidth;
 boolean[] TableRItemColsEditable;
 
 boolean RItem_LastQueryDefined;
 int RItem_LastQueryOperationBy;
	int RItem_LQ_Limit;
    // Static Filter
 String RItem_LQ_StaticSourceTable, RItem_LQ_StaticCondition, RItem_LQ_StaticPostCondition;
 boolean RItem_LQ_StaticConditionDefined, RItem_LQ_StaticPostConditionDefined;
    // Dynamic Filter
 int RItem_LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
    // Additional Filter
 boolean RItem_LQ_WithAdditionalFilter;
    // Order By
 String RItem_LQ_OrderBy;
    // Table Having
 String RItem_QHavingTbl;
 
 int[] LastSelectedRowRItem;
 boolean InfoRItemClear;
 
 // quick-insert
 int[] TF_InsertConvRule_ShortcutKeys;
 int[] TF_InsertItem_ShortcutKeys;
 
 Color RItemModeAdd_ColorOff, RItemModeAdd_ColorOn;
 boolean RItemModeAddOn;
 boolean RItemModeAdd_AfterOn;
 
 Component LastFocusedCmpQuickInsert;
 
 // convert rule
  // Temp List
 OQuickListOfLong TempList;
 
  // Additional Filter
 VInteger LastResultFilterSubset;
 VInteger LastResultFilterIsActive;
 
  // Table
 OCustomTableModel TableMdlConvRule;
	
	String[] TableConvRuleColsName;
	int[] TableConvRuleColsType, TableConvRuleColsShowOption, TableConvRuleColsVisible, TableConvRuleColsWidth;
	boolean[] TableConvRuleColsEditable;
	
 boolean LastQueryDefined;
 int LastQueryOperationBy;
	int LQ_Limit;
    // Static Filter
 String LQ_StaticSourceTable, LQ_StaticCondition, LQ_StaticPostCondition;
 boolean LQ_StaticConditionDefined, LQ_StaticPostConditionDefined;
    // Dynamic Filter
 int LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
    // Additional Filter
 boolean LQ_WithAdditionalFilter;
    // Order By
 String LQ_OrderBy;
    // Table Having
 String QHavingTbl;
 
 int LastSelectedRow;
 boolean InfoConvRuleClear;
 
  // Table - List Items
	String[] TableConvItemsColsName;
	int[] TableConvItemsColsType, TableConvItemsColsShowOption;
	boolean[] TableConvItemsColsEditable;
	
 OCustomTableModel TableMdlConvItemsOut;
 VIntegerArray TableConvItemsOutColsVisible, TableConvItemsOutColsWidth;
 
 VInteger LastSelectedRowConvItemsOut;
 VBoolean InfoConvItemsOutClear;
 
 OCustomTableModel TableMdlConvItemsIn;
 VIntegerArray TableConvItemsInColsVisible, TableConvItemsInColsWidth;
 
 VInteger LastSelectedRowConvItemsIn;
 VBoolean InfoConvItemsInClear;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 public F_ConvertRule(MInterFormVariables IFV_) {
  int[] Editable;
  Date dt;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  this.IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // query
  ListMdlQItemCategory=new OCustomListModel(false);
  ListMdlQItemCategory.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QItemCategory.setModel(ListMdlQItemCategory);
  
  TableMdlQItem=new OCustomTableModel();
  TableMdlQItem.setColumnsInfo(
   PCore.refArr("Id", "Nama"),
   PCore.primArr(CCore.TypeLong, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(2, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(1, 0));
  Tbl_QItem.setModel(TableMdlQItem);
  PGUI.resizeTableColumn(Tbl_QItem, PCore.primArr(CGUI.ColTextLrg, CGUI.ColNum13));
 
  dt=new Date();
  PGUI.setDateComponent(dt, TF_QConvRuleUpdateStartY, CmB_QConvRuleUpdateStartM, CmB_QConvRuleUpdateStartD);
  PGUI.setDateComponent(dt, TF_QConvRuleUpdateEndY, CmB_QConvRuleUpdateEndM, CmB_QConvRuleUpdateEndD);
  
  LastFocusedCmpSearch=null;
  
  // query by item
   // Filter
  CmB_FIdName.setSelectedIndex(2);
  
  TableMdlFCat=new OCustomTableModel();
  TableMdlFCat.setColumnsInfo(
   PCore.refArr("Id", "Nama"),
   PCore.primArr(CCore.TypeInteger, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(2, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(1));
  Tbl_FCat.setModel(TableMdlFCat);
  
  LastSelectedRowFCat=new int[0];
  FilledFCat=false;
  
  Tbl_FCat.setTableHeader(null); SP_TblFCat.setColumnHeaderView(null);
  
  refreshQueryCountFCat();

   // Result of Filter
  TableMdlRItem=new OCustomTableModel();
	 Tbl_RItem.setModel(TableMdlRItem);
  
  TableRItemColsName=PCore.refArr("Id", "Nama", "Satuan", "Diperbarui", "File Gambar", "Kategori Barang");
		TableRItemColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString, CCore.TypeString);
  TableRItemColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableRItemColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(-1);
  TableRItemColsEditable=PCore.changeValue(PCore.newBooleanArray(TableRItemColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
  
  RItem_QHavingTbl="tb3";
  clearLastQueryRItem();
  
  CB_RItemViewCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableRItemViewStructure(true, true);
  updateTableRItemView(false);
  
  LastSelectedRowRItem=new int[0];
  InfoRItemClear=true;
  
  updateQueryCountRItem();
  
  Pnl_RItemInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
   // All
  QueryByItemPrepared=false;
  LastFocusedCmpSearchFItem=0;
  
  // quick-insert
  TF_InsertConvRule_ShortcutKeys=null;
  TF_InsertItem_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  RItemModeAdd_ColorOff=Btn_RItemModeAdd.getBackground();
  RItemModeAdd_ColorOn=new Color(212, 255, 0);
  RItemModeAdd_AfterOn=false;
  setRItemModeAdd(false);
  
  LastFocusedCmpQuickInsert=null;
  
  CmB_InsertConvRule.setSelectedIndex(1);
  resetInputQuickInsertItem(true); resetInputQuickInsertItem(false);
  
  
  // convert rule
   // Temp List
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  updateTempListQuantity();
  
   // Additional Filter
  LastResultFilterSubset=new VInteger(CmB_ResultFilterSubset.getSelectedIndex());
  LastResultFilterIsActive=new VInteger(CmB_ResultFilterActive.getSelectedIndex());
  
   // Table - List Items
  TableConvItemsColsName=PMyShop.getConvertItems_ColumnsName();
  TableConvItemsColsType=PMyShop.getConvertItems_ColumnsType();
  TableConvItemsColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableConvItemsColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(2);
  TableConvItemsColsEditable=PCore.changeValue(PCore.newBooleanArray(TableConvItemsColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));

    // Item Out
  TableMdlConvItemsOut=new OCustomTableModel(); Tbl_ItemOut.setModel(TableMdlConvItemsOut);
  TableConvItemsOutColsVisible=new VIntegerArray();
  TableConvItemsOutColsWidth=new VIntegerArray();

  LastSelectedRowConvItemsOut=new VInteger(-1);
  InfoConvItemsOutClear=new VBoolean(true);
  
  CB_ItemOutViewCategorized.setSelected(false);
  buildTableConvItemsViewStructure(true, true);
  updateTableConvItemsView(true, false);
  
  Tbl_ItemOut.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e){onEditingTableItem(true);}
   };
  
  Pnl_ItemOutInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

    // Item In
  TableMdlConvItemsIn=new OCustomTableModel(); Tbl_ItemIn.setModel(TableMdlConvItemsIn);
  TableConvItemsInColsVisible=new VIntegerArray();
  TableConvItemsInColsWidth=new VIntegerArray();

  LastSelectedRowConvItemsIn=new VInteger(-1);
  InfoConvItemsInClear=new VBoolean(true);
  
  CB_ItemInViewCategorized.setSelected(false);
  buildTableConvItemsViewStructure(false, true);
  updateTableConvItemsView(false, false);
  
  Tbl_ItemIn.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e){onEditingTableItem(false);}
   };
  
  Pnl_ItemInInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
   // Table
  TableMdlConvRule=new OCustomTableModel(true, false, true);
  Tbl_ConvRule.setModel(TableMdlConvRule);
  
  TableConvRuleColsName=PCore.refArr("Id", "Nama", "Aktif", "Tgl Update", "Jumlah Barang Sisi-A", "Jumlah Barang Sisi-B");
		TableConvRuleColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeDate, CCore.TypeInteger, CCore.TypeInteger);
  TableConvRuleColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableConvRuleColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(-1);
  TableConvRuleColsEditable=PCore.changeValue(PCore.newBooleanArray(TableConvRuleColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
  
  QHavingTbl="tb2";
  clearLastQuery();
  
  buildTableConvRuleViewStructure(true, true);
  updateTableConvRuleView(false);
  
  Tbl_ConvRule.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e){onEditingTableConvRule();}
   };
  
  LastSelectedRow=-1;
  InfoConvRuleClear=true;
  
  updateQueryCount();
  updateQueryTempListCount();
  
  // Tabbed Pane
  TabbedPane.addChangeListener(new ChangeListener(){
    public void stateChanged(ChangeEvent e) {onTabbedPaneChanged();}
   });
  
  //
  clearComponents();
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
  Btn_Query.setToolTipText("hasil pencarian terbatas hingga "+PText.intToString(CApp.FormQueryLimit)+" data");
 }
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Query,
    CB_QCheck, CmB_QCheck,
    CB_QConvRuleUpdate, TF_QConvRuleUpdateStartY, CmB_QConvRuleUpdateStartM, CmB_QConvRuleUpdateStartD,
    TF_QConvRuleUpdateEndY, CmB_QConvRuleUpdateEndM, CmB_QConvRuleUpdateEndD,
    CB_QItemId, CmB_QItemId, TF_QItemId,
    CB_QItemName, TF_QItemName,
    CB_QConvRuleName, TF_QConvRuleName,
    CB_QItemCategory, CB_QItemCategoryNon, List_QItemCategory, Btn_QItemCategoryAdd, Btn_QItemCategoryRemove,
    CB_QItem, Tbl_QItem, Btn_QItemAdd, Btn_QItemRemove,
    
    Btn_FCatRefresh, TF_FCatFind, Btn_FCatFindBef, Btn_FCatFindNext, Tbl_FCat,
    
    CmB_FIdName, TF_FIdName, Btn_FIdName,
    Btn_FChooseItem,
    Btn_RItemRefresh, CB_RItemViewCategorized, Tbl_RItem,
    
    Btn_InsertConvRule, CmB_InsertConvRule, TF_InsertConvRule,
    Btn_InsertItemOut, TF_InsertItemOut, Btn_InsertItemIn, TF_InsertItemIn,
    Btn_RItemModeAdd,
    
    TF_Find, Tbl_ConvRule),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_NewActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 0 : Btn_QueryActionPerformed(null); break;
     }
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // cancel table editing
  Tbl_ConvRule.editingCanceled(null);
  Tbl_ItemIn.editingCanceled(null);
  Tbl_ItemOut.editingCanceled(null);
  
  // query
  clearTabQuery();
  LastFocusedCmpSearch=null;
  
  // query by item
  PGUI.clearText(TF_FIdName);
  clearFCat(); PGUI.clearText(TF_FCatFind);
  
  clearLastQueryRItem(); clearRItem();
  
  QueryByItemPrepared=false;
  LastFocusedCmpSearchFItem=0;
  
  // quick-insert
  LastFocusedCmpQuickInsert=null;
  // resetInputQuickInsertItem(true); resetInputQuickInsertItem(false);
  setRItemModeAdd(false); RItemModeAdd_AfterOn=false;
  
  // convert rule
  clearLastQuery(); clearConvRule(); PGUI.clearText(TF_Find);
  
  // tabbed pane
  // TabbedPane.setSelectedIndex(1);
 }
 
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_InsertItemOut){TF_InsertItemOutKeyPressed(e);}
		if(Cmp==TF_InsertItemIn){TF_InsertItemInKeyPressed(e);}
 }
 
 // Tabbed Pane
 void onTabbedPaneChanged(){
  int CurrTab=TabbedPane.getSelectedIndex();
  int row;
  if(CurrTab!=0 && CurrTab!=1){
   row=-1;
   if(row!=-1){fillAnActiveTab(CurrTab, row);}
   else{clearAnActiveTab(CurrTab);}
  }
  else if(CurrTab==0){
   focusQuery();
  }
  else if(CurrTab==1){
   prepareQueryByItem();
   focusFItem(false);
  }
 }
 void fillAnActiveTab(int tab, long Id){
  switch(tab){
   
  }
 }
 void clearAnActiveTab(int tab){
  switch(tab){
   
  }
 }
 
 // methods of query
 void runQuery(){
  boolean input_valid, list_defined, confirst;
  String str1=null;
  String str2=null;
  StringBuilder tb_items, tb_items2;
  boolean bool1, isempty1, isempty2, isconpost;
  long[] numbers, ids;
  Long lg1, lg2;
  Double dbl1, dbl2;
  Date dt1, dt2;
  VBoolean Con_Defined;
  StringBuilder StcCon;
  
  StringBuilder StcSourceTable;
  StringBuilder StcCondition;
  StringBuilder StcPostConditions;
  
  boolean query_defined;
  VBoolean stc_con_defined;
  VBoolean stc_conpost_defined;
  
  int WithTempList;
  
  // validating input
  input_valid=false;
  do{
   if(CB_QConvRuleUpdate.isSelected()){
    dt1=PGUI.valueOfDateComponent(TF_QConvRuleUpdateStartY, CmB_QConvRuleUpdateStartM, CmB_QConvRuleUpdateStartD);
    dt2=PGUI.valueOfDateComponent(TF_QConvRuleUpdateEndY, CmB_QConvRuleUpdateEndM, CmB_QConvRuleUpdateEndD);
    if(dt1==null || dt2==null){break;}
   }
   if(CB_QItemId.isSelected()){
    if(!PText.checkInput(TF_QItemId.getText(), false, CCore.CharsCount_Long(), 2, 0, 0, 0)){break;}
   }
   if(CB_QItemName.isSelected()){
    if(!PText.checkInput(TF_QItemName.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_QConvRuleName.isSelected()){
    if(!PText.checkInput(TF_QConvRuleName.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_QItemCategory.isSelected()){
    if(ListMdlQItemCategory.Mdl.Rows.size()==0 && !CB_QItemCategoryNon.isSelected()){break;}
   }
   if(CB_QItem.isSelected()){
    if(TableMdlQItem.Mdl.Rows.size()==0){break;}
   }
   input_valid=true;
  }while(false);
  if(!input_valid){JOptionPane.showMessageDialog(null, "Tidak dapat mencari : masukan masih salah / belum lengkap !"); return;}
  
  if(!IFV.canAccessGUI(3, true,
    true
  )){return;}
  
  // build query
  query_defined=true;
  StcSourceTable=new StringBuilder();
  StcCondition=new StringBuilder(); stc_con_defined=new VBoolean(false);
  StcPostConditions=new StringBuilder(); stc_conpost_defined=new VBoolean(false);
  
  WithTempList=0;
  
  if(CB_QCheck.isSelected()){
   switch(CmB_QCheck.getSelectedIndex()){
    case 0 :
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" (ItemsACount=0 or ItemsBCount=0)"); break;
   }
  }
  
  if(CB_QConvRuleUpdate.isSelected()){
   str1="LastUpdate";
   dt1=PGUI.valueOfDateComponent(TF_QConvRuleUpdateStartY, CmB_QConvRuleUpdateStartM, CmB_QConvRuleUpdateStartD);
   dt2=PGUI.valueOfDateComponent(TF_QConvRuleUpdateEndY, CmB_QConvRuleUpdateEndM, CmB_QConvRuleUpdateEndD);
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+">=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+"<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   StcCondition.append(")");
  }

  if(CB_QItemId.isSelected()){
   bool1=CmB_QItemId.getSelectedIndex()==0;
   str1=TF_QItemId.getText();
   tb_items=new StringBuilder("("+PMyShop.getQueryOfFindItemIds(
     PText.getString(bool1, String.valueOf(Long.parseLong(str1)), str1), !bool1, "Item.Id as 'ItemId'", null, true, null, false
    )+") as items");
   
   StcSourceTable.append(", ("+
     "(select RuleOfConv from RuleOfConvXSideA, "+tb_items+" where RuleOfConvXSideA.Item=items.ItemId group by RuleOfConv) "+
     "union distinct "+
     "(select RuleOfConv from RuleOfConvXSideB, "+tb_items+" where RuleOfConvXSideB.Item=items.ItemId group by RuleOfConv) "+
    ") as ConvRule_ItemId");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RuleOfConv.Id=ConvRule_ItemId.RuleOfConv");
  }

  if(CB_QItemName.isSelected()){
   tb_items2=new StringBuilder(", ("+
     "(select Id as 'ItemId' from Item where "+PSql.genCheckWord("Name", TF_QItemName.getText(), true, true)+") "+
     "union distinct "+
     "(select Item from ItemXVariant where "+PSql.genCheckWord("Variant", TF_QItemName.getText(), true, true)+" group by Item) "+
    ") as item_name");
   
   tb_items=new StringBuilder("(select Id as 'ItemId' from Item"+tb_items2+" where Item.Id=item_name.ItemId) as items");
   
   StcSourceTable.append(", ("+
     "(select RuleOfConv from RuleOfConvXSideA, "+tb_items+" where RuleOfConvXSideA.Item=items.ItemId group by RuleOfConv) "+
     "union distinct "+
     "(select RuleOfConv from RuleOfConvXSideB, "+tb_items+" where RuleOfConvXSideB.Item=items.ItemId group by RuleOfConv) "+
    ") as ConvRule_ItemName");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RuleOfConv.Id=ConvRule_ItemName.RuleOfConv");
  }
  
  if(CB_QConvRuleName.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" "+PSql.genCheckWord("RuleOfConv.Name", TF_QConvRuleName.getText(), true, true));
  }
  
  if(CB_QItemCategory.isSelected()){
   tb_items=new StringBuilder("(select Id as 'ItemId' from Item left join ItemXCategory on Item.Id=ItemXCategory.Item where");
   list_defined=false;
   if(ListMdlQItemCategory.getSize()!=0){
    tb_items.append(" CategoryOfItem in ("+PGUI.getElementList(ListMdlQItemCategory.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QItemCategoryNon.isSelected()){
    if(list_defined){tb_items.append(" or");} tb_items.append(" ItemXCategory.Item is "+CCore.vNull);
   }
   tb_items.append(" group by Id) as items");
   
   StcSourceTable.append(", ("+
     "(select RuleOfConv from RuleOfConvXSideA, "+tb_items+" where RuleOfConvXSideA.Item=items.ItemId group by RuleOfConv) "+
     "union distinct "+
     "(select RuleOfConv from RuleOfConvXSideB, "+tb_items+" where RuleOfConvXSideB.Item=items.ItemId group by RuleOfConv) "+
    ") as ConvRule_ItemCat");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RuleOfConv.Id=ConvRule_ItemCat.RuleOfConv");
  }
  
  if(CB_QItem.isSelected()){
   tb_items=new StringBuilder("(select Id as 'ItemId' from Item where Id in("+PGUI.getElementList(TableMdlQItem.Mdl.Rows, 0, ",", "", false)+")) as items");
   
   StcSourceTable.append(", ("+
     "(select RuleOfConv from RuleOfConvXSideA, "+tb_items+" where RuleOfConvXSideA.Item=items.ItemId group by RuleOfConv) "+
     "union distinct "+
     "(select RuleOfConv from RuleOfConvXSideB, "+tb_items+" where RuleOfConvXSideB.Item=items.ItemId group by RuleOfConv) "+
    ") as ConvRule_Item");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RuleOfConv.Id=ConvRule_Item.RuleOfConv");
  }
  
  if(!query_defined){clearLastQuery();}
  else{
   setLastQuery(1, CApp.FormQueryLimit,
    StcSourceTable.toString(), StcCondition.toString(), stc_con_defined.Value, StcPostConditions.toString(), stc_conpost_defined.Value,
    WithTempList, true);
  }
  fillConvRule(false);
 }
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: QCB.setSelected(true); Btn_QueryActionPerformed(null); break;
   case KeyEvent.VK_RIGHT: if(QTF.getCaretPosition()==QTF.getDocument().getLength()){focusQueryResult();} break;
  }
 }
 void clearTabQuery(){
  CB_QCheck.setSelected(false);
  CB_QConvRuleUpdate.setSelected(false);
  PGUI.clear(CB_QItemId, TF_QItemId);
  PGUI.clear(CB_QItemName, TF_QItemName);
  PGUI.clear(CB_QConvRuleName, TF_QConvRuleName);
  CB_QItemCategory.setSelected(false); CB_QItemCategoryNon.setSelected(false); ListMdlQItemCategory.removeAll();
  CB_QItem.setSelected(false); TableMdlQItem.removeAll();
 }
 void focusQuery(){
  if(LastFocusedCmpSearch==null){LastFocusedCmpSearch=TF_QItemName;}
  PGUI.requestFocusInWindow(LastFocusedCmpSearch);
 }
 
 // methods of query of items
  // All
 void prepareQueryByItem(){
  if(QueryByItemPrepared){return;}
  
  fillFCat(1);
  
  QueryByItemPrepared=true;
 }
 void focusFItem(boolean PushFocus){
  int LastFocus;
  
  LastFocus=LastFocusedCmpSearchFItem; if(LastFocus==0){LastFocus=1;}
  switch(LastFocus){
   case 1 : focusFIdName(); break;
   case 2 : focusFCat(PushFocus); break;
  }
 }
 
  // FIdName
 void focusFIdName(){
  PGUI.requestFocusInWindow(TF_FIdName);
 }
 
  // FCat
 void onSelectedRowChangedFCat(boolean UpdateAnyway){
  int[] rows=Tbl_FCat.getSelectedRows();
  long[] CategoryIds;
  String tb_items;
  
  if(PCore.compareValue(rows, LastSelectedRowFCat) && RItem_LastQueryOperationBy==2 && !UpdateAnyway){return;}
  
  LastSelectedRowFCat=rows;
  
  if(rows.length==0){return;}
  
  CategoryIds=TableMdlFCat.getIds(0, rows);
  tb_items="(select Item from ItemXCategory where CategoryOfItem in ("+PText.toString(CategoryIds, 0, CategoryIds.length, ",")+") group by Item) as item_cat";
  setLastQueryRItem(2, 0, ", "+tb_items, " where Item.Id=item_cat.Item", true, "", false, 0, true);
  fillRItem();
 }
 void refreshQueryCountFCat(){TF_FCatCount.setText(PText.intToString(TableMdlFCat.getRowCount()));}
 String getQueryFCat(){
  String ret=null;
  
  ret="select Id, Name from CategoryOfItem order by Name asc";
  
  return ret;
 }
 void fillFCat(int FillMode){
  String Query;
  
  switch(FillMode){
   case 1 : if(FilledFCat){return;} break;
  }
  
  clearFCat();
  
  Query=getQueryFCat(); if(Query==null){return;}
  if(PDatabase.queryToTable(IFV.Stm, Query, TableMdlFCat, false, false, null, -1, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Terjadi error dalam proses mengambil Kategori Barang dari database !");
  }
  refreshQueryCountFCat();
  
  FilledFCat=true;
 }
 void clearFCat(){
  if(!FilledFCat){return;}
  
  TableMdlFCat.removeAll(); LastSelectedRowFCat=new int[0];
  refreshQueryCountFCat();
  
  FilledFCat=false;
 }
 void findInListFCat(int Mode){
  int Selected, FindIndex, column;
  String str;
  
  str=TF_FCatFind.getText(); if(str.length()==0){return;}
  if(TableMdlFCat.Mdl.Rows.size()==0){JOptionPane.showMessageDialog(null, "Daftar dalam keadaan kosong !"); return;}
  
  Selected=Tbl_FCat.getSelectedRow(); column=1;
  FindIndex=PGUI.searchInTable(TableMdlFCat, column, TableMdlFCat.Mdl.ColumnsType[column], str, Selected, Mode);
  if(FindIndex==-1){JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di daftar !"); return;}
  if(FindIndex==Selected){return;}
  
  Tbl_FCat.changeSelection(FindIndex, 0, false, false);
  onSelectedRowChangedFCat(false);
 }
 void focusFCat(boolean PushFocus){
  if(TableMdlFCat.Mdl.Rows.isEmpty()){return;}
  
  if(Tbl_FCat.getSelectedRow()==-1){
   if(!PushFocus){return;}
   Tbl_FCat.changeSelection(0, 0, false, false); onSelectedRowChangedFCat(false);
  }
  PGUI.requestFocusInWindow(Tbl_FCat);
 }
 
  // RItem
 void updateTableRItemView(boolean Requery){
  TableMdlRItem.updateColumnsInfo(TableRItemColsName, TableRItemColsType, TableRItemColsShowOption,
   TableRItemColsVisible, TableRItemColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_RItem, TableRItemColsWidth);
  if(!Requery){onSelectedRowChangedRItem(false);}else{fillRItem();}
 }
 void buildTableRItemColumns(){
  boolean IsCategorized=CB_RItemViewCategorized.isSelected();
  int visible_insertpos=0, visible_insertvalue=0,
   width_insertpos=0, width_insertvalue=0;
  
  TableRItemColsVisible=PCore.primArr(1, 2, 3);
  TableRItemColsWidth=PCore.primArr(CGUI.ColTextLrg, CGUI.ColTextTiny, CGUI.ColCheck);
  
  if(!IsCategorized){
   visible_insertpos=1; visible_insertvalue=0;
   width_insertpos=1; width_insertvalue=CGUI.ColNum13;
  }
  else{
   visible_insertpos=0; visible_insertvalue=5;
   width_insertpos=0; width_insertvalue=CGUI.ColTextSml;
  }
  
  TableRItemColsVisible=PCore.insert(TableRItemColsVisible, visible_insertpos, visible_insertvalue);
  TableRItemColsWidth=PCore.insert(TableRItemColsWidth, width_insertpos, width_insertvalue);
 }
 void buildTableRItemOrderBy(){
  boolean IsCategorized=CB_RItemViewCategorized.isSelected();
  RItem_LQ_OrderBy=PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }
 void buildTableRItemViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableRItemColumns();}
  if(RebuildOrderBy){buildTableRItemOrderBy();}
 }
 void changeRItemViewByCategorized(){
  buildTableRItemViewStructure(true, true);
  updateTableRItemView(true);
 }
 
 void onSelectedRowChangedRItem(boolean UpdateAnyway){
  int[] rows=Tbl_RItem.getSelectedRows();
  boolean issame;
  
  issame=PCore.compareValue(rows, LastSelectedRowRItem);
  do{
   if(!(!issame || UpdateAnyway)){break;}
   
   LastSelectedRowRItem=rows; if(rows.length==0){clearInfoRItem();}else{fillInfoRItem(rows[0]);}
  }while(false);
  
  do{
   if(LastSelectedRowRItem.length==0 || RItemModeAddOn){break;}
   if(!(!issame || LastQueryOperationBy!=2 || RItemModeAdd_AfterOn || UpdateAnyway)){break;}
   
   queryByRItem(rows); RItemModeAdd_AfterOn=false;
  }while(false);
 }
 
 void updateQueryCountRItem(){TF_RItemCount.setText(PText.intToString(TableMdlRItem.getRowCount()));}
 
 void setLastQueryRItem(int LastQueryOperationBy, int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConDefined, String StaticPostCondition, boolean StaticPostConDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  this.RItem_LastQueryOperationBy=LastQueryOperationBy;
  
  RItem_LQ_Limit=Limit;
  
		RItem_LQ_StaticSourceTable=StaticSourceTable;
		RItem_LQ_StaticCondition=StaticCondition; RItem_LQ_StaticConditionDefined=StaticConDefined;
		RItem_LQ_StaticPostCondition=StaticPostCondition; RItem_LQ_StaticPostConditionDefined=StaticPostConDefined;
  
  RItem_LQ_DynamicTempList=DynamicTempList;
  
  RItem_LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  RItem_LastQueryDefined=true;
 }
 void clearLastQueryRItem(){RItem_LastQueryDefined=false;}
 String getQueryRItem(){
  String ret=null;
  String Limit;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  long[] tlist;
  boolean con_defined, conpost_defined;
  
  do{
   // build query
   con_defined=RItem_LQ_StaticConditionDefined; conpost_defined=RItem_LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   
    // finally, build query
   Limit=PText.getString(RItem_LQ_Limit, 0, " limit "+RItem_LQ_Limit, "");
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
   ret=
    "select tb3.*, Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
      "(select ItemId, ItemName, StockUnit.Name as 'StockUnitName', UpdateStockOnTransaction from "+
       "(select Item.*, Item.Id as 'ItemId', Item.Name as 'ItemName' from Item"+RItem_LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
        RItem_LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+") as tb1 "+
      "left join StockUnit on tb1.StockUnit=StockUnit.Id) as tb2 "+
     "left join ItemXPicture on tb2.ItemId=ItemXPicture.Item group by tb2.ItemId) as tb3 "+
    "left join ItemXCategory on tb3.ItemId=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.ItemId"+
				RItem_LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+RItem_LQ_OrderBy+Limit;
  }while(false);
  
  return ret;
 }
 void fillRItem(){
  String Query;
  
  clearRItem();
  
  if(!RItem_LastQueryDefined){return;}
  
  Query=getQueryRItem(); if(Query==null){return;}
  if(PDatabase.queryToTable(IFV.Stm, Query, TableMdlRItem, false, false, null, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil query barang dari database !");
  }
  updateQueryCountRItem();
 }
 void clearRItem(){
  TableMdlRItem.removeAll(); onSelectedRowChangedRItem(true);
  updateQueryCountRItem();
 }
 void fillInfoRItem(int row){
  Object[] objs=TableMdlRItem.Mdl.Rows.elementAt(row);
  
  TA_RItemInfoCategory.setText(PCore.objString(objs[5], ""));
  TA_RItemInfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[1]);
  PGUI.fillPanelPictureURL(Pnl_RItemInfoPreview, IFV.Conf.ImageDirItem, objs[4]);
  
  InfoRItemClear=false;
 }
 void clearInfoRItem(){
  if(InfoRItemClear){return;}
  
  TA_RItemInfoCategory.setText("");
  TA_RItemInfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_RItemInfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoRItemClear=true;
 }
 void queryByRItem(int[] rows){
  String StaticSourceTable, StaticCondition;
  long[] ItemsId;
  
  ItemsId=TableMdlRItem.getIds(0, rows);
  
  /*
   Note :
   the table that is produced by union operation, will use 'the first select statement' to be its columns's name
  */
  StaticSourceTable=
   ", ("+
    "(select RuleOfConv as 'RuleOfConv_1' from RuleOfConvXSideA where Item in("+PText.toString(ItemsId, 0, ItemsId.length, ",")+") group by RuleOfConv) "+
    
    "union distinct "+
    
    "(select RuleOfConv from RuleOfConvXSideB where Item in("+PText.toString(ItemsId, 0, ItemsId.length, ",")+") group by RuleOfConv)"+
   ") as RuleOfConv_Items";
  
  StaticCondition=" where RuleOfConv.Id=RuleOfConv_Items.RuleOfConv_1";
  
  setLastQuery(2, 0, StaticSourceTable, StaticCondition, true, "", false, 0, true);
  fillConvRule(true);
 }
 void focusRItem(boolean PushFocus){
  if(TableMdlRItem.Mdl.Rows.isEmpty()){return;}

  if(Tbl_RItem.getSelectedRow()==-1){
   if(!PushFocus){return;}
   Tbl_RItem.changeSelection(0, 0, false, false); onSelectedRowChangedRItem(false);
  }
  PGUI.requestFocusInWindow(Tbl_RItem);
 }
 
 // methods of quick-insert
 void setRItemModeAdd(boolean Value){
  if(Value==false && RItemModeAddOn==true){RItemModeAdd_AfterOn=true;}
  RItemModeAddOn=Value;
  
  Btn_RItemModeAdd.setBackground((Color)PCore.subtituteBool(Value, RItemModeAdd_ColorOn, RItemModeAdd_ColorOff));
 }
 String quickInsertConvRule_GenName(String ItemName, String PostFix){
  String ret=null;
  String Item, Post;
  
  do{
   if(PText.isEmptyString(ItemName, true, true)){break;}
   Item=PText.trim(ItemName, "", 3, CCore.Chars_WhiteChar);
   Post=PText.trim(PostFix, "", 3, CCore.Chars_WhiteChar); if(Post.length()!=0){Post=" "+Post;}
   ret=Item+Post;
  }while(false);
  
  return ret;
 }
 void quickInsertConvRule(){
  int[] ItemRows;
  Double qty=null;
  OValidation Valid;
  boolean IsItemOut=false;
  OInfoConvertRule InfoConvRule=null;
  String ItemName, PostFix, ConvRuleName=null;
  String OpName=null;
  int itemcurr, itemcount, successcount, result, insertpos=0;
  Object[] Item, NewItem;
  
  Valid=new OValidation(true);
  
  ItemRows=Tbl_RItem.getSelectedRows(); if(ItemRows.length==0){Valid.addError("\n- Belum ada Barang yg dipilih.");}
  
  if(CmB_InsertConvRule.getSelectedIndex()!=0){
   IsItemOut=CmB_InsertConvRule.getSelectedIndex()==1;
   OpName=PText.getString(IsItemOut, "Sisi-A", "Sisi-B");
   qty=quickInsertItem_GetInputQty(IsItemOut); if(qty==null){Valid.addError("\n- Inputan Kuantitas di "+OpName+" belum benar.");}
  }
  
  if(!Valid.getValid()){JOptionPane.showMessageDialog(null, "Inputan belum benar :\n"+Valid.getError()); return;}
  
  itemcurr=0; itemcount=ItemRows.length; successcount=0;
  do{
   Item=TableMdlRItem.Mdl.Rows.elementAt(ItemRows[itemcurr]);
   
   do{
    ItemName=PCore.objString(Item[1], ""); PostFix=TF_InsertConvRule.getText();
    ConvRuleName=quickInsertConvRule_GenName(ItemName, PostFix); if(ConvRuleName==null){break;}

    InfoConvRule=new OInfoConvertRule();
    InfoConvRule.Name=ConvRuleName;
    InfoConvRule.IsActive=true;
    InfoConvRule.LastUpdate=PDate.generateDate(new Date(), false);

    result=addConvRule_(InfoConvRule); if(result==-1){break;}
    insertpos=result;
    
    if(CmB_InsertConvRule.getSelectedIndex()!=0){
     NewItem=new Object[7];
     NewItem[0]=Item[0]; // Id
     NewItem[1]=Item[1]; // Name
     NewItem[2]=qty; // Qty
     NewItem[3]=Item[2]; // StockUnit
     NewItem[4]=Item[3]; // IsStockUpdated
     NewItem[5]=Item[4]; // PictureFile
     NewItem[6]=Item[5]; // CategoryName
     
     convItemsAdd_Db(IsItemOut, PCore.primArr(insertpos), PCore.toMultiRows2(NewItem));
    }
    
    successcount=successcount+1;
   }while(false);
   
   itemcurr=itemcurr+1;
  }while(itemcurr!=itemcount);
  
  if(successcount!=0){
   updateQueryCount(); updateQueryTempListCount();
   Tbl_ConvRule.changeSelection(insertpos, 0, false, false); onSelectedRowChanged(true);
  }
  if(successcount!=itemcount){
   JOptionPane.showMessageDialog(null, "Gagal membuat "+PText.intToString(itemcount-successcount)+" data Aturan Konversi, mungkin dikarenakan"+
    "\nNama dari Aturan Konversi sudah ada.");
  }
  
  setRItemModeAdd(true);
 }
 Double quickInsertItem_GetInputQty(boolean IsItemOut){
  Double ret=null;
  
  JTextField TF=(JTextField)PCore.subtituteBool(IsItemOut, TF_InsertItemOut, TF_InsertItemIn);
  String input_str=TF.getText();
  Double input_value;
  
  do{
   if(!PText.checkInput(input_str, false, CCore.CharsCount_Deci(), 6, 6, 6, 7)){break;}
   input_value=PText.parseDouble(input_str, null, null); if(input_value==null){break;}
   ret=input_value;
  }while(false);
  
  return ret;
 }
 void quickInsertItem(boolean IsItemOut){
  int[] ConvRows;
  int ConvRow;
  int[] ItemRows;
  Vector<Object[]> Items;
  Double qty;
  OValidation Valid;
  int temp;
  Object[] ItemData, CurrRow;
  String OpName=PText.getString(IsItemOut, "Sisi-A", "Sisi-B");
  
  Valid=new OValidation(true);
  
  ConvRows=Tbl_ConvRule.getSelectedRows(); if(ConvRows.length==0){Valid.addError("\n- Belum ada Aturan Konversi yg dipilih.");}
  ItemRows=Tbl_RItem.getSelectedRows(); if(ItemRows.length==0){Valid.addError("\n- Belum ada Barang yg dipilih.");}
  qty=quickInsertItem_GetInputQty(IsItemOut); if(qty==null){Valid.addError("\n- Inputan Kuantitas di "+OpName+" belum benar.");}
  
  if(!Valid.getValid()){JOptionPane.showMessageDialog(null, "Inputan belum benar :\n"+Valid.getError()); return;}
  
  if(ConvRows.length>1){
   if(JOptionPane.showConfirmDialog(null,
    "Tambahkan "+ItemRows.length+" barang yang dipilih ke "+PText.getString(IsItemOut, "Sisi-A", "Sisi-B")+" pada "+ConvRows.length+" Aturan Konversi ?",
    "Konfirmasi Penambahan Barang ke Beberapa Aturan Konversi", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  }
  
  ConvRow=ConvRows[0];
  
  Items=new Vector();
  temp=0;
  do{
   CurrRow=TableMdlRItem.Mdl.Rows.elementAt(ItemRows[temp]);
   
   ItemData=new Object[7];
   ItemData[0]=CurrRow[0]; // Id
   ItemData[1]=CurrRow[1]; // Name
   ItemData[2]=qty; // Qty
   ItemData[3]=CurrRow[2]; // StockUnit
   ItemData[4]=CurrRow[3]; // IsStockUpdated
   ItemData[5]=CurrRow[4]; // PictureFile
   ItemData[6]=CurrRow[5]; // CategoryName
   
   Items.addElement(ItemData);
   
   temp=temp+1;
  }while(temp!=ItemRows.length);
  
  if(!convItemsAdd(IsItemOut, ConvRows, ConvRow, Items)){
   JOptionPane.showMessageDialog(null, "Gagal menambah data barang !"); return;}
  
  setRItemModeAdd(false);
 }
 
 void resetInputQuickInsertItem(boolean IsItemOut){
  JTextField TF=(JTextField)PCore.subtituteBool(IsItemOut, TF_InsertItemOut, TF_InsertItemIn);
  
  TF.setText(PText.doubleToString(1, true));
 }
 
 void focusQuickInsert(){
  if(LastFocusedCmpQuickInsert==null){LastFocusedCmpQuickInsert=TF_InsertConvRule;}
  PGUI.requestFocusInWindow(LastFocusedCmpQuickInsert);
 }
 
 // methods of convert rule
  // Table
 void updateTableConvRuleView(boolean Requery){
  TableMdlConvRule.updateColumnsInfo(TableConvRuleColsName, TableConvRuleColsType, TableConvRuleColsShowOption,
   TableConvRuleColsVisible, TableConvRuleColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_ConvRule, TableConvRuleColsWidth);
  if(!Requery){onSelectedRowChanged(false);}else{fillConvRule(false);}
 }
 void buildTableConvRuleColumns(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  ColsWidth.addElement(CGUI.ColCheck); // Check
  
  ColsVisible.addElement(1); ColsWidth.addElement(700); // Name
  ColsVisible.addElement(2); ColsWidth.addElement(CGUI.ColCheck); // IsActive
  ColsVisible.addElement(3); ColsWidth.addElement(CGUI.ColDate); // LastUpdate
  
  TableConvRuleColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableConvRuleColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableConvRuleOrderBy(){
  LQ_OrderBy=" order by "+QHavingTbl+".Name asc";
 }
 void buildTableConvRuleViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableConvRuleColumns();}
  if(RebuildOrderBy){buildTableConvRuleOrderBy();}
 }
 void changeConvRuleViewByNormal(){
  buildTableConvRuleViewStructure(true, false);
  updateTableConvRuleView(false);
 }
 
 void onSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_ConvRule.getSelectedRow();
  
  if(row==LastSelectedRow && !UpdateAnyway){return;}
  
  LastSelectedRow=row;
  
  if(row==-1){clearInfoConvRule(false, true, true); return;}
  
  fillInfoConvRule(row, true, true);
 }
 
 void updateQueryCount(){TF_QueryCount.setText(PText.intToString(TableMdlConvRule.getRowCount()));}
 void updateQueryTempListCount(){TF_QueryTempListCount.setText("( "+PText.intToString(TableMdlConvRule.getCheckedCount())+" )");}
 
 void setLastQuery(int LastQueryOperationBy, int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConDefined, String StaticPostCondition, boolean StaticPostConDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  this.LastQueryOperationBy=LastQueryOperationBy;
  
  LQ_Limit=Limit;
  
		LQ_StaticSourceTable=StaticSourceTable;
		LQ_StaticCondition=StaticCondition; LQ_StaticConditionDefined=StaticConDefined;
		LQ_StaticPostCondition=StaticPostCondition; LQ_StaticPostConditionDefined=StaticPostConDefined;
  
  LQ_DynamicTempList=DynamicTempList;
  
  LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  LastQueryDefined=true;
 }
 void clearLastQuery(){LastQueryDefined=false;}
 String getQuery(){
  String ret=null;
  String Limit;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  long[] tlist;
  boolean con_defined, conpost_defined;
  
  do{
   // build query
   con_defined=LQ_StaticConditionDefined; conpost_defined=LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   if(LQ_DynamicTempList!=0){
    if(TempList.ElementsCount==0){if(LQ_DynamicTempList==1){break;}}
    else{
     if(!con_defined){con_defined=true; DynamicCondition.append(" where");}else{DynamicCondition.append(" and");}
     tlist=TempList.getElements();
     DynamicCondition.append(" RuleOfConv.Id"+PText.getString(LQ_DynamicTempList, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
    }
   }
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   if(LQ_WithAdditionalFilter){
    if(LastResultFilterSubset.Value!=0){
     if(LastResultFilterSubset.Value!=LQ_DynamicTempList){
      if(LQ_DynamicTempList!=0){break;}
      if(TempList.ElementsCount==0){if(LastResultFilterSubset.Value==1){break;}}
      else{
       if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
       tlist=TempList.getElements();
       AdditionalCondition.append(" RuleOfConv.Id"+PText.getString(LastResultFilterSubset.Value, 1, 2, " in", " not in", null)+
        "("+PText.toString(tlist, 0, tlist.length, ",")+")");
      }
     }
    }
    if(LastResultFilterIsActive.Value!=0){
     if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
     AdditionalCondition.append(" RuleOfConv.IsActive="+PText.getString(LastResultFilterIsActive.Value, 1, 2, CCore.vTrue, CCore.vFalse, null));
    }
   }
   
    // finally, build query
   Limit=PText.getString(LQ_Limit, 0, " limit "+LQ_Limit, "");
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
   ret=
    "select tb2.*, Count(RuleOfConvXSideB.Item) as 'ItemsBCount' from "+
     "(select tb1.*, Count(RuleOfConvXSideA.Item) as 'ItemsACount' from "+
      "(select RuleOfConv.Id, RuleOfConv.Name, RuleOfConv.IsActive, RuleOfConv.LastUpdate from RuleOfConv"+LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
       LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+") as tb1 "+
     "left join RuleOfConvXSideA on tb1.Id=RuleOfConvXSideA.RuleOfConv group by tb1.Id) as tb2 "+
    "left join RuleOfConvXSideB on tb2.Id=RuleOfConvXSideB.RuleOfConv group by tb2.Id"+
				LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+LQ_OrderBy+Limit;
  }while(false);
  
  return ret;
 }
 void fillConvRule(boolean AutoSelect){
  String Query;
  int row;
  
  clearConvRule();
  
  if(!LastQueryDefined){return;}
  
  Query=getQuery(); if(Query==null){return;}
  if(PDatabase.queryToTable(IFV.Stm, Query, TableMdlConvRule, false, true, TempList, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil query aturan konversi dari database !");
  }
  updateQueryCount(); updateQueryTempListCount();
  
  if(AutoSelect){
   if(TableMdlConvRule.getRowCount()==0){return;}
   row=0;
   Tbl_ConvRule.changeSelection(row, 0, false, false);
   onSelectedRowChanged(true);
  }
 }
 void clearConvRule(){
  TableMdlConvRule.removeAll(); onSelectedRowChanged(true);
  updateQueryCount(); updateQueryTempListCount();
 }
 void fillInfoConvRule(int row, boolean FillHeader, boolean FillListItems){
  Object[] objs=TableMdlConvRule.Mdl.Rows.elementAt(row);
  long Id=PCore.objLong(objs[0], -1L);
  
  if(FillHeader){TF_ConvRuleInfoName.setText(PCore.objString(objs[1], ""));}
  if(FillListItems){fillConvItems(true, Id, true); fillConvItems(false, Id, true);}
  
  InfoConvRuleClear=false;
 }
 void clearInfoConvRule(boolean ClearAnyway, boolean ClearHeader, boolean ClearListItems){
  if(InfoConvRuleClear && !ClearAnyway){return;}
  
  if(ClearHeader){TF_ConvRuleInfoName.setText("");}
  if(ClearListItems){clearConvItems(true); clearConvItems(false);}
  
  InfoConvRuleClear=true;
 }
 
 void findInTableConvRule(int Mode){
  int Selected, FindIndex, Column;
  String str;
  
  str=TF_Find.getText(); if(str.length()==0){return;}
  if(TableMdlConvRule.Mdl.Rows.size()==0){JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !"); return;}
  
  Selected=Tbl_ConvRule.getSelectedRow(); Column=1;
  FindIndex=PGUI.searchInTable(TableMdlConvRule, Column, TableMdlConvRule.Mdl.ColumnsType[Column], str, Selected, Mode);
  if(FindIndex==-1){JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !"); return;}
  if(Selected==FindIndex){return;}
  Tbl_ConvRule.changeSelection(FindIndex, 0, false, false);
  onSelectedRowChanged(false);
 }
 
 void chooseData(){
  int[] rows;
  int temp, count;
  Object[] ARow;
  
  rows=Tbl_ConvRule.getSelectedRows(); count=rows.length;
  if(count==0){JOptionPane.showMessageDialog(null, "Anda harus memilih sebuah data aturan konversi pada tabel !"); return;}
  
  ChoosedId=new Long[count];
  ChoosedName=new String[count];
  ChoosedIsActive=new Boolean[count];
  ChoosedLastUpdate=new Date[count];
  
  temp=0;
  do{
   ARow=TableMdlConvRule.Mdl.Rows.elementAt(rows[temp]);
   
   ChoosedId[temp]=PCore.objLong(ARow[0], null);
   ChoosedName[temp]=PCore.objString(ARow[1], null);
   ChoosedIsActive[temp]=PCore.objBoolean(ARow[2], null);
   ChoosedLastUpdate[temp]=PCore.objDate(ARow[3], null);
   
   if(wChooseActiveOnly){
    if(!ChoosedIsActive[temp]){JOptionPane.showMessageDialog(null, "Hanya boleh memilih aturan konversi yang berstatus aktif !"); break;}
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  if(temp!=count){return;}
  
  closingForm(1);
  setVisible(false);
 }
 void onEditingTableConvRule(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=Tbl_ConvRule.Editing_Row;
  Col=TableMdlConvRule.convertColumnIndexFromViewToModel(Tbl_ConvRule.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdlConvRule.Mdl.ColumnsType[Col], null, Tbl_ConvRule.Editing_ValueOld, true, null, Tbl_ConvRule.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableConvRule_Check(Row); break;}
   result=onEditingTableConvRule_ConvRule(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableConvRule_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  PMyShop.tempListAdd(this, this, PGUI.getIdsFromSelectedRows(TableMdlConvRule, PCore.primArr(Row), 0), PCore.objBoolean(Tbl_ConvRule.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingTableConvRule_ConvRule(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  boolean valid, FetchDataOld;
  OEditConvertRule Edit;
  
  do{
   Edit=new OEditConvertRule();
   FetchDataOld=false;
   valid=true;
   switch(Col){
    // string not null
    case 1 : Edit.EditName=true; Edit.EditedName=PCore.objString(Tbl_ConvRule.Editing_ValueNew, null); if(PText.isEmptyString(Edit.EditedName, true, true)){valid=false;} break;
    
    // boolean not null
    case 2 : Edit.EditIsActive=true; Edit.EditedIsActive=PCore.objBoolean(Tbl_ConvRule.Editing_ValueNew, false); break;
    
    // date null
    case 3 : Edit.EditLastUpdate=true; Edit.EditedLastUpdate=PCore.objDate(Tbl_ConvRule.Editing_ValueNew, null); break;
   }
   if(!valid){ret=-2; break;}

   if(editConvRule(PCore.primArr(Row), FetchDataOld, null, Edit, false)!=0){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 int editConvRule(int[] Rows, boolean FetchDataOld, OInfoConvertRule DataOld, OEditConvertRule Edit, boolean WithSplashScreen){
  /*
   EditMode :
   - 1 : complete, both header & list-items
   - 2 : only header
  */
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Id has already exist
  boolean error;
  long Id;
  Object[] RowData;
  int Row, count;
  Vector<OTableCellUpdater> Values, PostValues;
  OFormInformProgress Progress;
  
  do{
   count=Rows.length;
   Row=Rows[0]; RowData=TableMdlConvRule.Mdl.Rows.elementAt(Row); Id=(Long)RowData[0];

   Values=new Vector(); PostValues=new Vector();

   if(Edit.EditName){
    if(!Edit.ReplaceSubName){
     Values.addElement(new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedName, null, false)));
    }
    else{
     Values.addElement(new OTableCellUpdaterBySubString(1, true, Edit.SubName, Edit.EditedName));
    }
   }
   if(Edit.EditIsActive){
    Values.addElement(new OTableCellUpdaterByObject(2, Edit.EditedIsActive));
   }
   if(Edit.EditLastUpdate){
    Values.addElement(new OTableCellUpdaterByObject(3, Edit.EditedLastUpdate));
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)
   

   // update
   error=false;
   
   if(WithSplashScreen){IFV.FSplashScreen.appear(this, "Mengubah Aturan Konversi");}
   if(WithSplashScreen){IFV.FSplashScreen.inform(0, "Mengubah "+PText.intToString(count)+" aturan konversi, harap menunggu ...", null);}
   
   do{
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(75);}

    Progress=null; if(WithSplashScreen){Progress=IFV.FSplashScreen;}
    ret=PMyShop.convRuleEdit(IFV.Stm, TableMdlConvRule.getIds(0, Rows), FetchDataOld, DataOld, Edit, Progress);
    if(ret!=0){error=true; break;}
    
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(100);}

    // post-update
     // update table
    PGUI.changeElements(TableMdlConvRule, Rows, Values);
    PGUI.changeElements(TableMdlConvRule, Rows, PostValues);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(20, null, null);}

     // update detail
    clearInfoConvRule(true, true, Edit.EditComplete);
    fillInfoConvRule(Row, true, Edit.EditComplete);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(5, null, null);}
   }while(false);
   
   if(WithSplashScreen){IFV.FSplashScreen.disappear();}
   
   if(error){break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 void editConvRule(){
  boolean WithSplashScreen=false, FetchDataOld=false;
  long Id;
  int[] rows;
  OInfoConvertRule DataOld=null;
  OEditConvertRule Edit;
  F_ConvertRuleModify fm1=IFV.FConvertRuleModify;
  F_ConvertRuleModifyMulti fm2=IFV.FConvertRuleModifyMulti;
  boolean IsSame_Header, IsSame_ListItems;
  
  rows=Tbl_ConvRule.getSelectedRows(); if(rows.length==0){return;}
  
  Edit=new OEditConvertRule();
  if(rows.length==1){
   Id=(Long)TableMdlConvRule.Mdl.Rows.elementAt(rows[0])[0];
   DataOld=PMyShop.getConvertRuleInfo(IFV.Stm, Id, true, false);
   if(DataOld==null){JOptionPane.showMessageDialog(null, "Gagal mengambil data Aturan Konversi !"); return;}
   
   fm1.wMode=2;
   fm1.InfoConvertRule=DataOld;
   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}
   
   WithSplashScreen=false;
   FetchDataOld=false;
   
   IsSame_ListItems=fm1.InfoConvertRule.compare(DataOld, false, true, true);
   
   Edit.init(
    true, false, null, fm1.InfoConvertRule.Name,
    true, fm1.InfoConvertRule.IsActive,
    IsSame_ListItems, PDate.generateDate(new Date(), false),
    true, fm1.InfoConvertRule);
  }
  else{
   fm2.wDataCount=rows.length;
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   WithSplashScreen=true;
   FetchDataOld=false;
   
   Edit.init(
    fm2.ChangeName, true, fm2.NameSub, fm2.Name,
    fm2.ChangeIsActive, fm2.IsActive,
    false, null,
    false, null);
  }
  
  editConvRule(rows, FetchDataOld, DataOld, Edit, WithSplashScreen);
 }
 void addConvRule(){
  F_ConvertRuleModify fm=IFV.FConvertRuleModify;
  
  fm.wMode=1;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  fm.InfoConvertRule.LastUpdate=PDate.generateDate(new Date(), false);
  
  if(!addConvRule(fm.InfoConvertRule)){
   JOptionPane.showMessageDialog(null, "Gagal menambah data Aturan Konversi, mungkin dikarenakan :\n"+
    "Nama dari Aturan Konversi sudah ada."); return;}
 }
 boolean addConvRule(OInfoConvertRule InfoConvRule){
  boolean ret=false;
  int insertpos;
  
  do{
   insertpos=addConvRule_(InfoConvRule); if(insertpos==-1){break;}

   updateQueryCount(); updateQueryTempListCount();
   Tbl_ConvRule.changeSelection(insertpos, 0, false, false); onSelectedRowChanged(true);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 int addConvRule_(OInfoConvertRule InfoConvRule){
  int ret=-1;
  
  long Id;
  Object[] NewRow;
  int FindColumn, insertpos;
  String FindName;
  boolean found;
  
  do{
   Id=PMyShop.convRuleAdd(IFV.Stm, IFV.ConvertRuleLock, InfoConvRule); if(Id==-1){break;}

   NewRow=new Object[4];
   NewRow[0]=Id;
   NewRow[1]=InfoConvRule.Name;
   NewRow[2]=InfoConvRule.IsActive;
   NewRow[3]=InfoConvRule.LastUpdate;

   FindColumn=1;
   FindName=PCore.objString(NewRow[FindColumn], null);
   insertpos=PGUI.findInsertPos(TableMdlConvRule, FindColumn, FindName, false, true, true);
   TableMdlConvRule.insert(insertpos, NewRow);

   found=TempList.checkElement(Id)>=0;
   TableMdlConvRule.setChecked(insertpos, found);
   
   ret=insertpos;
  }while(false);
  
  return ret;
 }
 void removeConvRule(){
  int[] rows;
  Object[] result;
  boolean[] IsRemoved;
  int RemovedCount;
  
  rows=Tbl_ConvRule.getSelectedRows(); if(rows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+PText.intToString(rows.length)+" aturan konversi yg dipilih pada tabel ?"+
   "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  IFV.FSplashScreen.appear(this, "Menghapus Aturan Konversi");  
  IFV.FSplashScreen.inform(0, "Menghapus "+PText.intToString(rows.length)+" aturan konversi, harap menunggu ...", "-");
  
  result=PMyShop.convRuleRemove(IFV.Stm, IFV.ConvertRuleLock, TableMdlConvRule.getIds(0, rows), IFV.FSplashScreen);
  
  IFV.FSplashScreen.disappear();
  
  if(result==null){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !"); return;}
  
  RemovedCount=(Integer)result[0];
  IsRemoved=(boolean[])result[1];
  
  if(RemovedCount!=0){
   TableMdlConvRule.remove(rows, IsRemoved); onSelectedRowChanged(true);
   updateQueryCount(); updateQueryTempListCount();
  }
  if(RemovedCount!=rows.length){
   JOptionPane.showMessageDialog(null, "Gagal menghapus "+(rows.length-RemovedCount)+" data !"+
    "\nMungkin aturan konversi tsb masih terdaftar pd suatu proses konversi !");
  }
 }
 
 void printReport(){
  int count, temp;
  LinkedList<Long> Ids;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  F_PrintConvertRule fm=IFV.FPrintConvertRule;
  
  count=TableMdlConvRule.Mdl.Rows.size(); if(count==0){return;}

  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}

  IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
  IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
  IFV.FPrintDialog.wPrintSettingMode=2;
  IFV.FPrintDialog.wEnableOption=false;

  if(!IFV.FPrintDialog.showForm()){return;}
  if(IFV.FPrintDialog.DialogResult!=1){return;}
  PaperType=IFV.FPrintDialog.PaperType;
  Printer=IFV.FPrintDialog.Printer;

  temp=0; Ids=new LinkedList(); TempRows=TableMdlConvRule.Mdl.Rows;
  do{
   Ids.addLast((Long)TempRows.elementAt(temp)[0]);
   temp=temp+1;
  }while(temp!=count);

  IFV.PrintGenConvertRule.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Ids,
   fm.Opt_IsActive, fm.Opt_LastUpdate,
   fm.OptList_Item, fm.OptList_ItemCategorized);

  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  bk=IFV.PrintGenConvertRule.generateBook(IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  if(bk==null){JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !"); return;}

  if(IFV.FPrintDialog.ChoosePage){
   IFV.FPrintPage.wBook=bk;

   if(!IFV.FPrintPage.showForm()){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
  }

  if(!PPrint.print(bk, Printer, "LapAturanKonversi_"+PText.dateToString(new Date(), 101), false)){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !"); return;}
 }
 void printCSV(){
  F_PrintConvertRule fm1=IFV.FPrintConvertRule;
  F_CsvWriteOption fm2=IFV.FCsvWriteOption;
  File f;
  long OperationResult;
  long[] Ids;
  
  if(TableMdlConvRule.Mdl.Rows.size()==0){return;}
  
  if(!fm1.showForm()){return;}
  if(fm1.DialogResult!=1){return;}
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(!fm2.showForm()){return;}
  if(fm2.DialogResult!=1){return;}
  
  Ids=TableMdlConvRule.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableMdlConvRule.Mdl.Rows.size(), 0, 1));
  
  IFV.FSplashScreen.appear(this, "Print Data Ke File CSV");
  OperationResult=PMyShop.printConvRuleCSV(
   IFV.FSplashScreen, IFV.Stm, f, fm2.FieldDelimiter, fm2.FieldsSeparator, CCore.CsvDefaultRecordsSeparator, Ids,
   fm1.Opt_IsActive, fm1.Opt_LastUpdate,
   fm1.OptList_Item, fm1.OptList_ItemCategorized);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses print data ke file CSV !"+"\n"+PMyShop.getCSVErrorMessage()); return;}
  
  /*
  JOptionPane.showMessageDialog(null,
   "Operasi berhasil !\n"+
   "Total data yg di-print ke file CSV = "+PText.intToString(OperationResult));
  */
 }
 
 void setConvRuleActive(boolean ActiveValue){
  int[] Rows=Tbl_ConvRule.getSelectedRows();
  OEditConvertRule Edit;
  int result;
  
  if(Rows.length==0){return;}
  
  Edit=new OEditConvertRule();
  Edit.EditIsActive=true; Edit.EditedIsActive=ActiveValue;
  
  result=editConvRule(Rows, false, null, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
 }
 
 void focusConvRule(boolean PushFocus){
  if(TableMdlConvRule.Mdl.Rows.isEmpty()){return;}
  
  if(Tbl_ConvRule.getSelectedRow()==-1){
   if(!PushFocus){return;}
   Tbl_ConvRule.changeSelection(0, 0, false, false); onSelectedRowChanged(false);
  }
  PGUI.requestFocusInWindow(Tbl_ConvRule);
 }
 
  // Table - List Items
 void updateTableConvItemsView(boolean IsItemOut, boolean Requery){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  VIntegerArray ColsVisible=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsVisible, TableConvItemsInColsVisible);
  VIntegerArray ColsWidth=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsWidth, TableConvItemsInColsWidth);
  
  int row;
  long Id;
  
  TableMdl.updateColumnsInfo(TableConvItemsColsName, TableConvItemsColsType, TableConvItemsColsShowOption,
   ColsVisible.Value, TableConvItemsColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl, ColsWidth.Value);
  if(!Requery){onSelectedRowChangedConvItems(IsItemOut, false);}
  else{
   Id=-1; row=Tbl_ConvRule.getSelectedRow(); if(row!=-1){Id=(Long)TableMdlConvRule.Mdl.Rows.elementAt(row)[0];}
   fillConvItems(IsItemOut, Id, false);
  }
 }
 void buildTableConvItemsColumns(boolean IsItemOut){
  JToggleButton CB_ViewCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  VIntegerArray ColsVisible=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsVisible, TableConvItemsInColsVisible);
  VIntegerArray ColsWidth=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsWidth, TableConvItemsInColsWidth);
  
  ColsVisible.Value=PMyShop.getConvertItems_ColumnsVisible(IsCategorized);
  ColsWidth.Value=PMyShop.getConvertItems_ColumnsWidth(IsCategorized);
 }
 void buildTableConvItemsViewStructure(boolean IsItemOut, boolean RebuildColumns){
  if(RebuildColumns){buildTableConvItemsColumns(IsItemOut);}
 }
 void changeConvItemsViewByCategorized(boolean IsItemOut){
  buildTableConvItemsViewStructure(IsItemOut, true);
  updateTableConvItemsView(IsItemOut, true);
 }
 
 void onEditingTableItem(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int ItemRow, ItemCol;
  int result=0;
  boolean IsSame;
  
  ItemRow=Tbl.Editing_Row;
  ItemCol=TableMdl.convertColumnIndexFromViewToModel(Tbl.Editing_Col);
  
  if(ItemCol!=-1){
   IsSame=PCore.grading(TableMdl.Mdl.ColumnsType[ItemCol], null, Tbl.Editing_ValueOld, true, null, Tbl.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(ItemCol==-1){result=0; break;}
   result=onEditingTableItem_Item(IsItemOut, ItemRow, ItemCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableItem_Item(boolean IsItemOut, int ItemRow, int ItemCol){
  int ret=0;
  
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  boolean valid;
  int ConvRow;
  OEditConvertItem Edit;
  
  do{
   ConvRow=Tbl_ConvRule.getSelectedRow(); if(ConvRow==-1){break;}
   
   Edit=new OEditConvertItem();
   valid=true;
   switch(ItemCol){
    // double not null, positive only, >0
    case 2 : Edit.EditQuantity=true; Edit.EditedQuantity=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedQuantity<=0){valid=false;} break;
   }
   if(!valid){ret=-2; break;}

   if(!convItemsEdit(IsItemOut, ConvRow, PCore.primArr(ItemRow), Edit)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void onSelectedRowChangedConvItems(boolean IsItemOut, boolean UpdateAnyway){
  VInteger LastSelectedRow=(VInteger)PCore.subtituteBool(IsItemOut, LastSelectedRowConvItemsOut, LastSelectedRowConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int row=Tbl.getSelectedRow();
  
  if(LastSelectedRow.Value==row && !UpdateAnyway){return;}
  
  LastSelectedRow.Value=row;
  
  if(row==-1){clearConvItemsInfo(IsItemOut); return;}
  
  fillConvItemsInfo(IsItemOut, row);
 }
 
 void refreshConvItemsCount(boolean IsItemOut){
  JTextField TF_Count=(JTextField)PCore.subtituteBool(IsItemOut, TF_ItemOutCount, TF_ItemInCount);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  TF_Count.setText(PText.intToString(TableMdl.getRowCount()));
 }
 void fillConvItems(boolean IsItemOut, long Id, boolean SelectAData){
  JToggleButton CB_ViewCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  Vector<Object[]> result;
  
  clearConvItems(IsItemOut);
  
  if(Id==-1){return;}
  
  result=PMyShop.getConvertItems(IFV.Stm, true, IsItemOut, Id, CB_ViewCategorized.isSelected());
  if(result==null){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dlm mengambil daftar barang "+PText.getString(IsItemOut, "Sisi-A", "Sisi-B")+" !");
   return;
  }
  
  TableMdl.append(result);
  refreshConvItemsCount(IsItemOut);
  
  if(!SelectAData || TableMdl.getRowCount()==0){return;}
  Tbl.changeSelection(0, 0, false, false); onSelectedRowChangedConvItems(IsItemOut, false);
 }
 void clearConvItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  TableMdl.removeAll(); onSelectedRowChangedConvItems(IsItemOut, true);
  refreshConvItemsCount(IsItemOut);
 }
 void fillConvItemsInfo(boolean IsItemOut, int Row){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  JTextArea TA_InfoCategory=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoCategory, TA_ItemInInfoCategory);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  VBoolean InfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, InfoConvItemsOutClear, InfoConvItemsInClear);
  
  Object[] objs=TableMdl.Mdl.Rows.elementAt(Row);
  
  TA_InfoCategory.setText(PCore.objString(objs[6], ""));
  TA_InfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+PCore.objString(objs[1], ""));
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, objs[5]);
  
  InfoClear.Value=false;
 }
 void clearConvItemsInfo(boolean IsItemOut){
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  JTextArea TA_InfoCategory=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoCategory, TA_ItemInInfoCategory);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  VBoolean InfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, InfoConvItemsOutClear, InfoConvItemsInClear);
  
  if(InfoClear.Value){return;}
  
  TA_InfoCategory.setText("");
  TA_InfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoClear.Value=true;
 }
 
 void convItemsAdd(boolean IsItemOut){
  int ConvRow;
  long ItemId;
  Object[] NewRow;
  F_ConvertItemModify fm=IFV.FConvertItemModify;
  
  ConvRow=Tbl_ConvRule.getSelectedRow(); if(ConvRow==-1){return;}

  fm.wConvert=1;
  fm.wMode=0;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  ItemId=fm.ItemInfo.PrimaryId;
  
  NewRow=new Object[7];
  NewRow[0]=ItemId;
  NewRow[1]=fm.ItemInfo.Name;
  NewRow[2]=fm.Qty;
  NewRow[3]=fm.ItemInfo.StockUnitName;
  NewRow[4]=fm.ItemInfo.UpdateStock;
  NewRow[5]=fm.ItemInfo.PictureFile;
  NewRow[6]=fm.ItemInfo.CategoryName;
  
  if(!convItemsAdd(IsItemOut, PCore.primArr(ConvRow), ConvRow, PCore.toMultiRows2(NewRow))){
   JOptionPane.showMessageDialog(null, "Gagal menambah data barang !"); return;}
 }
 boolean convItemsAdd(boolean IsItemOut, int[] ConvRows, int ConvRow, Vector<Object[]> NewRows){
  boolean ret=false;
  
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int insertpos;
  OEditConvertRule EditConvRule;
  
  do{
   insertpos=convItemsAdd_(IsItemOut, ConvRows, ConvRow, NewRows); if(insertpos==-1){break;}
   
   refreshConvItemsCount(IsItemOut);
   Tbl_Item.changeSelection(insertpos, 0, false, false); onSelectedRowChangedConvItems(IsItemOut, true);
   
   EditConvRule=new OEditConvertRule();
   EditConvRule.EditLastUpdate=true; EditConvRule.EditedLastUpdate=PDate.generateDate(new Date(), false);
   editConvRule(ConvRows, false, null, EditConvRule, false);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 int convItemsAdd_(boolean IsItemOut, int[] ConvRows, int ConvRow, Vector<Object[]> NewRows){
  int ret=-1;
  
  do{
   if(!convItemsAdd_Db(IsItemOut, ConvRows, NewRows)){break;}
   ret=convItemsAdd_GUI(IsItemOut, ConvRow, PTable.subDataOfIds(NewRows, PMyShop.getConvertItems_ColumnsType(), PCore.newIntegerArrayInOrderedSequence(NewRows.size(), 0, 1), 0));
  }while(false);
  
  return ret;
 }
 boolean convItemsAdd_Db(boolean IsItemOut, int[] ConvRows, Vector<Object[]> NewRows){
  long[] ConvIds=TableMdlConvRule.getIds(0, ConvRows);
  return PMyShop.convRuleAddItems(IsItemOut, true, IFV.Stm, ConvIds, NewRows);
 }
 int convItemsAdd_GUI(boolean IsItemOut, int ConvRow, long[] Items){
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  JToggleButton CB_ItemCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  boolean IsCategorized=CB_ItemCategorized.isSelected();
  
  int ret=-1;
  int temp, count;
  long ItemId;
  int FindColumn;
  String FindName;
  Object[] NewRow;
  Vector<Object[]> NewRows;
  long ConvId=(Long)TableMdlConvRule.Mdl.Rows.elementAt(ConvRow)[0];
  
  do{
   NewRows=PMyShop.getConvertItems(IFV.Stm, true, IsItemOut, ConvId, IsCategorized, Items); if(NewRows==null){break;}
   count=NewRows.size(); if(count==0){break;}
   
   temp=0;
   do{
    NewRow=NewRows.elementAt(temp);
    ItemId=PCore.objLong(NewRow[0], -1L);
    ret=PTable.findNumber(TableMdlItem.Mdl.Rows, ItemId, 0, false);
    if(ret==-1){
     if(!IsCategorized){FindColumn=1;}else{FindColumn=6;}
     FindName=PCore.objString(NewRow[FindColumn], null);
     ret=PGUI.findInsertPos(TableMdlItem, FindColumn, FindName, false, true, true);
     TableMdlItem.insert(ret, NewRow);
    }
    else{
     TableMdlItem.changeValue(ret, NewRow);
    }

    temp=temp+1;
   }while(temp!=count);
  }while(false);
  
  return ret;
 }
 void convItemsEdit(boolean IsItemOut){
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int ConvRow;
  int[] ItemRows;
  OEditConvertItem Edit=new OEditConvertItem();
  F_ConvertItemModify fm1=IFV.FConvertItemModify;
  F_ConvertItemModifyMulti fm2=IFV.FConvertItemModifyMulti;
  
  ConvRow=Tbl_ConvRule.getSelectedRow(); if(ConvRow==-1){return;}
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}

  if(ItemRows.length==1){
   fm1.wConvert=1;
   fm1.wMode=1;
   fm1.wItemId=(Long)TableMdlItem.Mdl.Rows.elementAt(ItemRows[0])[0];
   fm1.wQuantity=(Double)TableMdlItem.Mdl.Rows.elementAt(ItemRows[0])[2];
   
   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}

   Edit.init(
    true, fm1.Qty);
  }
  else{
   fm2.wDataCount=ItemRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    fm2.ChangeQuantity, fm2.Quantity);
  }
  
  if(!convItemsEdit(IsItemOut, ConvRow, ItemRows, Edit)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data barang !"); return;}
 }
 boolean convItemsEdit(boolean IsItemOut, int ConvRow, int[] ItemRows, OEditConvertItem Edit){
  boolean ret=false;
  long ConvId=(Long)TableMdlConvRule.Mdl.Rows.elementAt(ConvRow)[0];
  OEditConvertRule EditConvRule;
  
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  Vector<OTableCellUpdater> ChangeValues;
  
  do{
   if(!PMyShop.convRuleEditItems(IsItemOut, IFV.Stm, ConvId, TableMdlItem.getIds(0, ItemRows), Edit)){break;}
   
   ChangeValues=new Vector();
   
   if(Edit.EditQuantity){
    ChangeValues.addElement(new OTableCellUpdaterByObject(2, Edit.EditedQuantity));
   }
   
   PGUI.changeElements(TableMdlItem, ItemRows, ChangeValues);

   // fillConvItemsInfo(IsItemOut, ItemRows[0]);
   
   EditConvRule=new OEditConvertRule();
   EditConvRule.EditLastUpdate=true; EditConvRule.EditedLastUpdate=PDate.generateDate(new Date(), false);
   editConvRule(PCore.primArr(ConvRow), false, null, EditConvRule, false);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void convItemsDelete(boolean IsItemOut){
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int ConvRow;
  int[] ItemRows;
  
  ConvRow=Tbl_ConvRule.getSelectedRow(); if(ConvRow==-1){return;}
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+ItemRows.length+" barang "+PText.getString(IsItemOut, "Sisi-A", "Sisi-B")+" yang dipilih ?",
   "Konfirmasi Penghapusan Barang "+PText.getString(IsItemOut, "Sisi-A", "Sisi-B"), JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!convItemsDelete(IsItemOut, ConvRow, ItemRows)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data barang !"); return;}
 }
 boolean convItemsDelete(boolean IsItemOut, int ConvRow, int[] ItemRows){
  boolean ret=false;
  long ConvId=(Long)TableMdlConvRule.Mdl.Rows.elementAt(ConvRow)[0];
  OEditConvertRule EditConvRule;
  
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  do{
   if(!PMyShop.convRuleDeleteItems(IsItemOut, IFV.Stm, ConvId, TableMdlItem.getIds(0, ItemRows))){break;}
   
   TableMdlItem.remove(ItemRows); onSelectedRowChangedConvItems(IsItemOut, true);
   refreshConvItemsCount(IsItemOut);
   
   EditConvRule=new OEditConvertRule();
   EditConvRule.EditLastUpdate=true; EditConvRule.EditedLastUpdate=PDate.generateDate(new Date(), false);
   editConvRule(PCore.primArr(ConvRow), false, null, EditConvRule, false);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void convItemsMove(boolean IsItemOut){
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int ConvRow;
  int[] ItemRows;
  
  ConvRow=Tbl_ConvRule.getSelectedRow(); if(ConvRow==-1){return;}
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null,
   "Pindahkan "+ItemRows.length+" barang "+PText.getString(IsItemOut, "Sisi-A", "Sisi-B")+" yang dipilih "+
   "ke daftar "+PText.getString(IsItemOut, "Sisi-B", "Sisi-A")+" ?",
   "Konfirmasi Pemindahan Barang "+PText.getString(IsItemOut, "Sisi-A", "Sisi-B"), JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!convItemsMove(IsItemOut, ConvRow, ItemRows)){
   JOptionPane.showMessageDialog(null, "Gagal memindahkan data barang !"); return;}
 }
 boolean convItemsMove(boolean IsItemOut, int ConvRow, int[] ItemRows){
  boolean ret=false;
  
  OCustomTableModel TableMdlItemSrc=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  OCustomTableModel TableMdlItemDest=(OCustomTableModel)PCore.subtituteBool(!IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl_Item_Dest=(XTable)PCore.subtituteBool(!IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int insertpos;
  long[] ItemsId;
  long ConvId=(Long)TableMdlConvRule.Mdl.Rows.elementAt(ConvRow)[0];
  OEditConvertRule EditConvRule;
  
  do{
   ItemsId=TableMdlItemSrc.getIds(0, ItemRows);
   if(!PMyShop.convRuleMoveItems(IsItemOut, IFV.Stm, ConvId, ItemsId)){break;}
   
   insertpos=convItemsAdd_GUI(!IsItemOut, ConvRow, ItemsId);
   if(insertpos!=-1){Tbl_Item_Dest.changeSelection(insertpos, 0, false, false);} onSelectedRowChangedConvItems(!IsItemOut, true);
   refreshConvItemsCount(!IsItemOut);
   
   TableMdlItemSrc.remove(ItemRows); onSelectedRowChangedConvItems(IsItemOut, true);
   refreshConvItemsCount(IsItemOut);
   
   EditConvRule=new OEditConvertRule();
   EditConvRule.EditLastUpdate=true; EditConvRule.EditedLastUpdate=PDate.generateDate(new Date(), false);
   editConvRule(PCore.primArr(ConvRow), false, null, EditConvRule, false);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 
  // TempList
 void updateTempListQuantity(){TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));}
 public void fillTempList(long[] ConvRules, boolean IsAdd){
  long[] AffectItems;
  
  if(ConvRules.length==0){return;}
  
  AffectItems=PCore.subArr(ConvRules, TempList.addElements(ConvRules, IsAdd));
  if(AffectItems.length==0){return;}
  
  updateTempListQuantity();
  fillSignItems(AffectItems, IsAdd);
 }
 public void clearTempList(){
  TempList.removeAll();
  updateTempListQuantity();
  
  clearSignItems();
 }
 void fillSignItems(long[] ConvRules, boolean SignValue){
  TableMdlConvRule.check(ConvRules, SignValue, 0);
  updateQueryTempListCount();
 }
 void clearSignItems(){
  TableMdlConvRule.checkAll(false);
  updateQueryTempListCount();
 }
 
  // Additional Filter
 void onSelectedAdditionalFilterChanged(JComboBox CmB, VInteger LastSelected){
  int selected=CmB.getSelectedIndex();
  
  if(LastSelected.Value==selected){return;}
  
  LastSelected.Value=selected;
  fillConvRule(false);
 }
 
 // methods of others
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }
 void initPrivGUIShow(){
  
 }
 void dialogWithFItem(boolean Enable){
  PGUI.setEnabled(Enable, Btn_QItemAdd, Btn_New, Btn_Edit, Btn_FChooseItem, Btn_ItemOutAdd, Btn_ItemInAdd);
 }
 
 //
 void focusQueryResult(){
  focusConvRule(true);
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TabbedPane = new javax.swing.JTabbedPane();
  Pnl_Query = new javax.swing.JPanel();
  Btn_Query = new javax.swing.JButton();
  jLabel4 = new javax.swing.JLabel();
  TF_QConvRuleName = new javax.swing.JTextField();
  CB_QConvRuleName = new javax.swing.JCheckBox();
  CB_QItemCategory = new javax.swing.JCheckBox();
  TF_QItemName = new javax.swing.JTextField();
  TF_QItemId = new javax.swing.JTextField();
  CB_QItemId = new javax.swing.JCheckBox();
  CB_QItemName = new javax.swing.JCheckBox();
  CmB_QItemId = new javax.swing.JComboBox<>();
  jScrollPane9 = new javax.swing.JScrollPane();
  Tbl_QItem = new XTable();
  CB_QItem = new javax.swing.JCheckBox();
  Lbl_QItemIdHelp = new javax.swing.JLabel();
  Lbl_QItemNameHelp = new javax.swing.JLabel();
  Lbl_ConvRuleNameHelp = new javax.swing.JLabel();
  Btn_QItemCategoryAdd = new javax.swing.JButton();
  Btn_QItemCategoryRemove = new javax.swing.JButton();
  Btn_QItemAdd = new javax.swing.JButton();
  Btn_QItemRemove = new javax.swing.JButton();
  CmB_QConvRuleUpdateEndD = new javax.swing.JComboBox<>();
  CB_QConvRuleUpdate = new javax.swing.JCheckBox();
  TF_QConvRuleUpdateStartY = new javax.swing.JTextField();
  CmB_QConvRuleUpdateStartM = new javax.swing.JComboBox<>();
  CmB_QConvRuleUpdateStartD = new javax.swing.JComboBox<>();
  jLabel5 = new javax.swing.JLabel();
  TF_QConvRuleUpdateEndY = new javax.swing.JTextField();
  CmB_QConvRuleUpdateEndM = new javax.swing.JComboBox<>();
  CB_QItemCategoryNon = new javax.swing.JCheckBox();
  CmB_QCheck = new javax.swing.JComboBox<>();
  CB_QCheck = new javax.swing.JCheckBox();
  jScrollPane13 = new javax.swing.JScrollPane();
  List_QItemCategory = new XList();
  Pnl_QueryByItem = new javax.swing.JPanel();
  jPanel18 = new javax.swing.JPanel();
  jScrollPane10 = new javax.swing.JScrollPane();
  Tbl_RItem = new XTable();
  jPanel19 = new javax.swing.JPanel();
  Pnl_RItemInfoPreview = new XImgBoxURL();
  jScrollPane11 = new javax.swing.JScrollPane();
  TA_RItemInfoCategory = new javax.swing.JTextArea();
  jScrollPane12 = new javax.swing.JScrollPane();
  TA_RItemInfoName = new javax.swing.JTextArea();
  jPanel7 = new javax.swing.JPanel();
  jPanel16 = new javax.swing.JPanel();
  TF_RItemCount = new javax.swing.JTextField();
  Btn_RItemRefresh = new javax.swing.JButton();
  jLabel6 = new javax.swing.JLabel();
  CB_RItemViewCategorized = new javax.swing.JToggleButton();
  jPanel21 = new javax.swing.JPanel();
  Btn_FIdName = new javax.swing.JButton();
  TF_FIdName = new javax.swing.JTextField();
  CmB_FIdName = new javax.swing.JComboBox<>();
  jLabel8 = new javax.swing.JLabel();
  Btn_FChooseItem = new javax.swing.JButton();
  jPanel12 = new javax.swing.JPanel();
  Btn_InsertItemIn = new javax.swing.JButton();
  Btn_InsertItemOut = new javax.swing.JButton();
  Btn_InsertConvRule = new javax.swing.JButton();
  TF_InsertConvRule = new javax.swing.JTextField();
  TF_InsertItemOut = new javax.swing.JTextField();
  TF_InsertItemIn = new javax.swing.JTextField();
  CmB_InsertConvRule = new javax.swing.JComboBox<>();
  Btn_RItemModeAdd = new javax.swing.JButton();
  jPanel20 = new javax.swing.JPanel();
  jPanel22 = new javax.swing.JPanel();
  Btn_FCatFindNext = new javax.swing.JButton();
  Btn_FCatFindBef = new javax.swing.JButton();
  TF_FCatCount = new javax.swing.JTextField();
  TF_FCatFind = new javax.swing.JTextField();
  Btn_FCatRefresh = new javax.swing.JButton();
  jLabel7 = new javax.swing.JLabel();
  SP_TblFCat = new javax.swing.JScrollPane();
  Tbl_FCat = new XTable();
  jPanel1 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  Btn_New = new javax.swing.JButton();
  Btn_Edit = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  Btn_Choose = new javax.swing.JButton();
  Lbl_MultipleSelection = new javax.swing.JLabel();
  Btn_Report = new javax.swing.JButton();
  CmB_ReportType = new javax.swing.JComboBox<>();
  jPanel4 = new javax.swing.JPanel();
  jPanel10 = new javax.swing.JPanel();
  jPanel6 = new javax.swing.JPanel();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBef = new javax.swing.JButton();
  TF_Find = new javax.swing.JTextField();
  Btn_MultipleConvRulesActiveRemove = new javax.swing.JButton();
  Btn_MultipleConvRulesActiveAdd = new javax.swing.JButton();
  jLabel12 = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_ConvRule = new XTable();
  TF_ConvRuleInfoName = new javax.swing.JTextField();
  jPanel11 = new javax.swing.JPanel();
  jPanel9 = new javax.swing.JPanel();
  jPanel14 = new javax.swing.JPanel();
  jLabel3 = new javax.swing.JLabel();
  TF_ItemInCount = new javax.swing.JTextField();
  Btn_ItemInRemove = new javax.swing.JButton();
  Btn_ItemInEdit = new javax.swing.JButton();
  Btn_ItemInAdd = new javax.swing.JButton();
  Btn_ItemInMove = new javax.swing.JButton();
  CB_ItemInViewCategorized = new javax.swing.JToggleButton();
  jPanel15 = new javax.swing.JPanel();
  Pnl_ItemInInfoPreview = new XImgBoxURL();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_ItemInInfoCategory = new javax.swing.JTextArea();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_ItemInInfoName = new javax.swing.JTextArea();
  jScrollPane7 = new javax.swing.JScrollPane();
  Tbl_ItemIn = new XTable();
  jPanel8 = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  jLabel2 = new javax.swing.JLabel();
  TF_ItemOutCount = new javax.swing.JTextField();
  Btn_ItemOutRemove = new javax.swing.JButton();
  Btn_ItemOutEdit = new javax.swing.JButton();
  Btn_ItemOutAdd = new javax.swing.JButton();
  Btn_ItemOutMove = new javax.swing.JButton();
  CB_ItemOutViewCategorized = new javax.swing.JToggleButton();
  jPanel13 = new javax.swing.JPanel();
  Pnl_ItemOutInfoPreview = new XImgBoxURL();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemOutInfoCategory = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_ItemOutInfoName = new javax.swing.JTextArea();
  jScrollPane4 = new javax.swing.JScrollPane();
  Tbl_ItemOut = new XTable();
  jPanel2 = new javax.swing.JPanel();
  TF_QueryCount = new javax.swing.JTextField();
  TF_QueryTempListCount = new javax.swing.JTextField();
  CmB_ResultFilterSubset = new javax.swing.JComboBox<>();
  Btn_TempListClear = new javax.swing.JButton();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  Btn_QueryRefresh = new javax.swing.JButton();
  CmB_ResultFilterActive = new javax.swing.JComboBox<>();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });
  Btn_Query.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QueryKeyPressed(evt);
   }
  });

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("-- Filter (kosongkan smua utk cari smua)");

  TF_QConvRuleName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvRuleNameFocusGained(evt);
   }
  });
  TF_QConvRuleName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvRuleNameKeyPressed(evt);
   }
  });

  CB_QConvRuleName.setText("Nm Atr");
  CB_QConvRuleName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvRuleName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvRuleNameKeyPressed(evt);
   }
  });

  CB_QItemCategory.setText("Kategori");
  CB_QItemCategory.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemCategoryKeyPressed(evt);
   }
  });

  TF_QItemName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemNameFocusGained(evt);
   }
  });
  TF_QItemName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemNameKeyPressed(evt);
   }
  });

  TF_QItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemIdFocusGained(evt);
   }
  });
  TF_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemIdKeyPressed(evt);
   }
  });

  CB_QItemId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemIdKeyPressed(evt);
   }
  });

  CB_QItemName.setText("Nm Brg");
  CB_QItemName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemNameKeyPressed(evt);
   }
  });

  CmB_QItemId.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Sub" }));
  CmB_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QItemIdKeyPressed(evt);
   }
  });

  Tbl_QItem.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_QItem.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_QItemKeyReleased(evt);
   }
  });
  jScrollPane9.setViewportView(Tbl_QItem);

  CB_QItem.setText("Barang");
  CB_QItem.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemKeyPressed(evt);
   }
  });

  Lbl_QItemIdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QItemIdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QItemIdHelp.setText("(?)");
  Lbl_QItemIdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QItemIdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QItemIdHelpMouseClicked(evt);
   }
  });

  Lbl_QItemNameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QItemNameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QItemNameHelp.setText("(?)");
  Lbl_QItemNameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QItemNameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QItemNameHelpMouseClicked(evt);
   }
  });

  Lbl_ConvRuleNameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ConvRuleNameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ConvRuleNameHelp.setText("(?)");
  Lbl_ConvRuleNameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ConvRuleNameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ConvRuleNameHelpMouseClicked(evt);
   }
  });

  Btn_QItemCategoryAdd.setText("+");
  Btn_QItemCategoryAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemCategoryAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemCategoryAddActionPerformed(evt);
   }
  });
  Btn_QItemCategoryAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemCategoryAddKeyPressed(evt);
   }
  });

  Btn_QItemCategoryRemove.setText("-");
  Btn_QItemCategoryRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemCategoryRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemCategoryRemoveActionPerformed(evt);
   }
  });
  Btn_QItemCategoryRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemCategoryRemoveKeyPressed(evt);
   }
  });

  Btn_QItemAdd.setText("+");
  Btn_QItemAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemAddActionPerformed(evt);
   }
  });
  Btn_QItemAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemAddKeyPressed(evt);
   }
  });

  Btn_QItemRemove.setText("-");
  Btn_QItemRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemRemoveActionPerformed(evt);
   }
  });
  Btn_QItemRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemRemoveKeyPressed(evt);
   }
  });

  CmB_QConvRuleUpdateEndD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QConvRuleUpdateEndD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvRuleUpdateEndDKeyPressed(evt);
   }
  });

  CB_QConvRuleUpdate.setText("Update");
  CB_QConvRuleUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvRuleUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvRuleUpdateKeyPressed(evt);
   }
  });

  TF_QConvRuleUpdateStartY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvRuleUpdateStartYFocusGained(evt);
   }
  });
  TF_QConvRuleUpdateStartY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvRuleUpdateStartYKeyPressed(evt);
   }
  });

  CmB_QConvRuleUpdateStartM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QConvRuleUpdateStartM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvRuleUpdateStartMKeyPressed(evt);
   }
  });

  CmB_QConvRuleUpdateStartD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QConvRuleUpdateStartD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvRuleUpdateStartDKeyPressed(evt);
   }
  });

  jLabel5.setText("-");

  TF_QConvRuleUpdateEndY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvRuleUpdateEndYFocusGained(evt);
   }
  });
  TF_QConvRuleUpdateEndY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvRuleUpdateEndYKeyPressed(evt);
   }
  });

  CmB_QConvRuleUpdateEndM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QConvRuleUpdateEndM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvRuleUpdateEndMKeyPressed(evt);
   }
  });

  CB_QItemCategoryNon.setText("non");
  CB_QItemCategoryNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemCategoryNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemCategoryNonKeyPressed(evt);
   }
  });

  CmB_QCheck.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tanpa Barang di Sisi A atau Sisi B" }));
  CmB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCheckKeyPressed(evt);
   }
  });

  CB_QCheck.setText("Cek");
  CB_QCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCheckKeyPressed(evt);
   }
  });

  List_QItemCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QItemCategoryKeyReleased(evt);
   }
  });
  jScrollPane13.setViewportView(List_QItemCategory);

  javax.swing.GroupLayout Pnl_QueryLayout = new javax.swing.GroupLayout(Pnl_Query);
  Pnl_Query.setLayout(Pnl_QueryLayout);
  Pnl_QueryLayout.setHorizontalGroup(
   Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_QueryLayout.createSequentialGroup()
    .addComponent(jLabel4)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
   .addGroup(Pnl_QueryLayout.createSequentialGroup()
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QItemCategory)
     .addComponent(CB_QItem)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItemName)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QItemNameHelp))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItemId)
      .addGap(0, 0, 0)
      .addComponent(CmB_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(1, 1, 1)
      .addComponent(Lbl_QItemIdHelp))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QConvRuleName)
      .addGap(2, 2, 2)
      .addComponent(Lbl_ConvRuleNameHelp))
     .addComponent(CB_QConvRuleUpdate)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addComponent(CB_QItemCategoryNon))
     .addComponent(CB_QCheck))
    .addGap(4, 4, 4)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(TF_QConvRuleUpdateStartY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(CmB_QConvRuleUpdateStartM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(CmB_QConvRuleUpdateStartD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(jLabel5)
      .addGap(3, 3, 3)
      .addComponent(TF_QConvRuleUpdateEndY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(CmB_QConvRuleUpdateEndM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(CmB_QConvRuleUpdateEndD, 0, 76, Short.MAX_VALUE))
     .addComponent(TF_QItemId)
     .addComponent(TF_QItemName)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane13)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QItemCategoryAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QItemCategoryRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QItemAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QItemRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addComponent(TF_QConvRuleName, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(CmB_QCheck, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
  );
  Pnl_QueryLayout.setVerticalGroup(
   Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_QueryLayout.createSequentialGroup()
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Query)
     .addComponent(jLabel4))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_QCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QCheck))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_QConvRuleUpdateEndD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_QConvRuleUpdateStartY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QConvRuleUpdate)
     .addComponent(CmB_QConvRuleUpdateStartM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QConvRuleUpdateStartD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel5)
     .addComponent(TF_QConvRuleUpdateEndY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QConvRuleUpdateEndM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QItemId)
     .addComponent(CmB_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QItemIdHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QItemName)
     .addComponent(Lbl_QItemNameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QConvRuleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QConvRuleName)
     .addComponent(Lbl_ConvRuleNameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItemCategory)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QItemCategoryNon))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QItemCategoryAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QItemCategoryRemove))
     .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 361, Short.MAX_VALUE)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_QItem)
       .addComponent(Btn_QItemAdd))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QItemRemove)
      .addGap(0, 0, Short.MAX_VALUE))))
  );

  TabbedPane.addTab("Cari", Pnl_Query);

  Tbl_RItem.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_RItem.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_RItem.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_RItem.setRowHeight(17);
  Tbl_RItem.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_RItemMouseReleased(evt);
   }
  });
  Tbl_RItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_RItemKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_RItemKeyReleased(evt);
   }
  });
  jScrollPane10.setViewportView(Tbl_RItem);

  Pnl_RItemInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_RItemInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_RItemInfoPreviewMouseClicked(evt);
   }
  });

  TA_RItemInfoCategory.setEditable(false);
  TA_RItemInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_RItemInfoCategory.setColumns(20);
  TA_RItemInfoCategory.setLineWrap(true);
  TA_RItemInfoCategory.setRows(1);
  TA_RItemInfoCategory.setWrapStyleWord(true);
  jScrollPane11.setViewportView(TA_RItemInfoCategory);

  TA_RItemInfoName.setEditable(false);
  TA_RItemInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_RItemInfoName.setColumns(20);
  TA_RItemInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_RItemInfoName.setLineWrap(true);
  TA_RItemInfoName.setRows(1);
  TA_RItemInfoName.setWrapStyleWord(true);
  jScrollPane12.setViewportView(TA_RItemInfoName);

  javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
  jPanel19.setLayout(jPanel19Layout);
  jPanel19Layout.setHorizontalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel19Layout.createSequentialGroup()
    .addComponent(Pnl_RItemInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane11)
     .addComponent(jScrollPane12)))
  );
  jPanel19Layout.setVerticalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_RItemInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel19Layout.createSequentialGroup()
    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE))
  );

  jPanel16.setBorder(javax.swing.BorderFactory.createEtchedBorder());
  jPanel16.setOpaque(false);

  TF_RItemCount.setEditable(false);
  TF_RItemCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_RItemCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_RItemRefresh.setText("R");
  Btn_RItemRefresh.setToolTipText("klik 'R' untuk menyegarkan hasil pencarian barang dlm tabel");
  Btn_RItemRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_RItemRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RItemRefreshActionPerformed(evt);
   }
  });
  Btn_RItemRefresh.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_RItemRefreshKeyPressed(evt);
   }
  });

  jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  jLabel6.setText("Hasil Filter Barang");

  CB_RItemViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_RItemViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_RItemViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_RItemViewCategorized.setText("K");
  CB_RItemViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_RItemViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_RItemViewCategorized.setIconTextGap(0);
  CB_RItemViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_RItemViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_RItemViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
  jPanel16.setLayout(jPanel16Layout);
  jPanel16Layout.setHorizontalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel16Layout.createSequentialGroup()
    .addComponent(TF_RItemCount, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_RItemRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_RItemViewCategorized))
  );
  jPanel16Layout.setVerticalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel16Layout.createSequentialGroup()
    .addComponent(jLabel6)
    .addGap(0, 0, 0)
    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_RItemRefresh)
     .addComponent(TF_RItemCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_RItemViewCategorized)))
  );

  jPanel21.setBorder(javax.swing.BorderFactory.createEtchedBorder());
  jPanel21.setOpaque(false);

  Btn_FIdName.setText("Cari");
  Btn_FIdName.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FIdName.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FIdNameActionPerformed(evt);
   }
  });
  Btn_FIdName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FIdNameKeyPressed(evt);
   }
  });

  TF_FIdName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FIdNameFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FIdNameFocusLost(evt);
   }
  });
  TF_FIdName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FIdNameKeyPressed(evt);
   }
  });

  CmB_FIdName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id", "SubId", "Nama" }));
  CmB_FIdName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_FIdNameKeyPressed(evt);
   }
  });

  jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  jLabel8.setText("{ Filter by Id-Nama }");

  javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
  jPanel21.setLayout(jPanel21Layout);
  jPanel21Layout.setHorizontalGroup(
   jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel21Layout.createSequentialGroup()
    .addComponent(CmB_FIdName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FIdName)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FIdName))
   .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel21Layout.setVerticalGroup(
   jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel21Layout.createSequentialGroup()
    .addComponent(jLabel8)
    .addGap(0, 0, 0)
    .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_FIdName)
     .addComponent(TF_FIdName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_FIdName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  Btn_FChooseItem.setText("...");
  Btn_FChooseItem.setToolTipText("Pilih barang2 dari Form Barang");
  Btn_FChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FChooseItemActionPerformed(evt);
   }
  });
  Btn_FChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FChooseItemKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(Btn_FChooseItem)
    .addGap(0, 0, 0)
    .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Btn_FChooseItem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(0, 0, Short.MAX_VALUE))
  );

  jPanel12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_InsertItemIn.setText("+B");
  Btn_InsertItemIn.setToolTipText("Tambahkan barang yg dipilih ke Sisi B");
  Btn_InsertItemIn.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_InsertItemIn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InsertItemInActionPerformed(evt);
   }
  });
  Btn_InsertItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InsertItemInKeyPressed(evt);
   }
  });

  Btn_InsertItemOut.setText("+A");
  Btn_InsertItemOut.setToolTipText("Tambahkan barang yg dipilih ke Sisi A");
  Btn_InsertItemOut.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_InsertItemOut.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InsertItemOutActionPerformed(evt);
   }
  });
  Btn_InsertItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InsertItemOutKeyPressed(evt);
   }
  });

  Btn_InsertConvRule.setText("+Aturan");
  Btn_InsertConvRule.setToolTipText("Buat barang yg dipilih menjadi Aturan Konversi");
  Btn_InsertConvRule.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_InsertConvRule.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InsertConvRuleActionPerformed(evt);
   }
  });
  Btn_InsertConvRule.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InsertConvRuleKeyPressed(evt);
   }
  });

  TF_InsertConvRule.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  TF_InsertConvRule.setToolTipText("input Postfix utk pembuatan nama Aturan Konversi");
  TF_InsertConvRule.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_InsertConvRuleFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_InsertConvRuleFocusLost(evt);
   }
  });
  TF_InsertConvRule.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_InsertConvRuleKeyPressed(evt);
   }
  });

  TF_InsertItemOut.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  TF_InsertItemOut.setToolTipText("input kuantitas dari penambahan barang ke Sisi A");
  TF_InsertItemOut.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_InsertItemOutFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_InsertItemOutFocusLost(evt);
   }
  });
  TF_InsertItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_InsertItemOutKeyPressed(evt);
   }
  });

  TF_InsertItemIn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  TF_InsertItemIn.setToolTipText("input kuantitas dari penambahan barang ke Sisi B");
  TF_InsertItemIn.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_InsertItemInFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_InsertItemInFocusLost(evt);
   }
  });
  TF_InsertItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_InsertItemInKeyPressed(evt);
   }
  });

  CmB_InsertConvRule.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "+A", "+B" }));
  CmB_InsertConvRule.setToolTipText("pilih '+A' atau '+B' utk menyertakan penambahan barang ketika membuat Aturan Konversi");
  CmB_InsertConvRule.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_InsertConvRuleKeyPressed(evt);
   }
  });

  Btn_RItemModeAdd.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_RItemModeAdd.setText("ModeAdd");
  Btn_RItemModeAdd.setToolTipText("Mode Add ; jk aktif (warna Hijau), mk memilih data barang tdk menampilkan pencarian Aturan Konversi");
  Btn_RItemModeAdd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Btn_RItemModeAdd.setMargin(new java.awt.Insets(1, 1, 1, 1));
  Btn_RItemModeAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RItemModeAddActionPerformed(evt);
   }
  });
  Btn_RItemModeAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_RItemModeAddKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
    .addComponent(Btn_InsertConvRule)
    .addGap(0, 0, 0)
    .addComponent(CmB_InsertConvRule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(TF_InsertConvRule)
    .addGap(6, 6, 6)
    .addComponent(Btn_InsertItemOut)
    .addGap(0, 0, 0)
    .addComponent(TF_InsertItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(Btn_InsertItemIn)
    .addGap(0, 0, 0)
    .addComponent(TF_InsertItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(Btn_RItemModeAdd))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_InsertItemIn)
    .addComponent(Btn_InsertItemOut)
    .addComponent(Btn_InsertConvRule)
    .addComponent(TF_InsertConvRule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_InsertItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_InsertItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_InsertConvRule, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addComponent(Btn_RItemModeAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
  jPanel18.setLayout(jPanel18Layout);
  jPanel18Layout.setHorizontalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel18Layout.setVerticalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel18Layout.createSequentialGroup()
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 229, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel22.setBorder(javax.swing.BorderFactory.createEtchedBorder());
  jPanel22.setOpaque(false);

  Btn_FCatFindNext.setText(">");
  Btn_FCatFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatFindNextActionPerformed(evt);
   }
  });
  Btn_FCatFindNext.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatFindNextKeyPressed(evt);
   }
  });

  Btn_FCatFindBef.setText("<");
  Btn_FCatFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatFindBefActionPerformed(evt);
   }
  });
  Btn_FCatFindBef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatFindBefKeyPressed(evt);
   }
  });

  TF_FCatCount.setEditable(false);
  TF_FCatCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_FCatCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_FCatFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FCatFindFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FCatFindFocusLost(evt);
   }
  });
  TF_FCatFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FCatFindKeyPressed(evt);
   }
  });

  Btn_FCatRefresh.setText("R");
  Btn_FCatRefresh.setToolTipText("klik 'R' untuk menyegarkan daftar kategori barang dlm tabel");
  Btn_FCatRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatRefreshActionPerformed(evt);
   }
  });
  Btn_FCatRefresh.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatRefreshKeyPressed(evt);
   }
  });

  jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  jLabel7.setText("{ Filter by Kategori }");

  javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
  jPanel22.setLayout(jPanel22Layout);
  jPanel22Layout.setHorizontalGroup(
   jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
    .addComponent(TF_FCatCount, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FCatFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatFindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel7))
  );
  jPanel22Layout.setVerticalGroup(
   jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FCatFindNext)
    .addComponent(Btn_FCatFindBef)
    .addComponent(TF_FCatCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_FCatFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_FCatRefresh)
    .addComponent(jLabel7))
  );

  Tbl_FCat.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_FCat.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_FCat.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_FCat.setRowHeight(17);
  Tbl_FCat.setRowMargin(0);
  Tbl_FCat.setShowHorizontalLines(false);
  Tbl_FCat.setShowVerticalLines(false);
  Tbl_FCat.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    Tbl_FCatFocusGained(evt);
   }
  });
  Tbl_FCat.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_FCatMouseReleased(evt);
   }
  });
  Tbl_FCat.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_FCatKeyReleased(evt);
   }
  });
  SP_TblFCat.setViewportView(Tbl_FCat);

  javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
  jPanel20.setLayout(jPanel20Layout);
  jPanel20Layout.setHorizontalGroup(
   jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(SP_TblFCat, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
  );
  jPanel20Layout.setVerticalGroup(
   jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel20Layout.createSequentialGroup()
    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(SP_TblFCat, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout Pnl_QueryByItemLayout = new javax.swing.GroupLayout(Pnl_QueryByItem);
  Pnl_QueryByItem.setLayout(Pnl_QueryByItemLayout);
  Pnl_QueryByItemLayout.setHorizontalGroup(
   Pnl_QueryByItemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Pnl_QueryByItemLayout.setVerticalGroup(
   Pnl_QueryByItemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_QueryByItemLayout.createSequentialGroup()
    .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("Cari Barang", Pnl_QueryByItem);

  Btn_New.setText("Buat Baru {F1}");
  Btn_New.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_New.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_NewActionPerformed(evt);
   }
  });

  Btn_Edit.setText("Ubah {F2}");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Remove.setText("Hapus {F3}");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  Btn_Choose.setText("Pilih {F11}");
  Btn_Choose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Choose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseActionPerformed(evt);
   }
  });

  Lbl_MultipleSelection.setText("{Boleh > 1}");

  Btn_Report.setText("Cetak");
  Btn_Report.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Report.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReportActionPerformed(evt);
   }
  });

  CmB_ReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laporan", "CSV" }));

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(Btn_New)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Edit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Remove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Report)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Lbl_MultipleSelection)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Choose))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_New)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Remove)
    .addComponent(Btn_Choose)
    .addComponent(Lbl_MultipleSelection)
    .addComponent(Btn_Report)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_FindBef.setText("<");
  Btn_FindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBefActionPerformed(evt);
   }
  });

  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FindFocusLost(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  Btn_MultipleConvRulesActiveRemove.setText("-");
  Btn_MultipleConvRulesActiveRemove.setToolTipText("nonaktifkan aturan2 konversi yg dipilih di dlm daftar");
  Btn_MultipleConvRulesActiveRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_MultipleConvRulesActiveRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleConvRulesActiveRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleConvRulesActiveAdd.setText("+");
  Btn_MultipleConvRulesActiveAdd.setToolTipText("aktifkan aturan2 konversi yg dipilih di dlm daftar");
  Btn_MultipleConvRulesActiveAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_MultipleConvRulesActiveAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleConvRulesActiveAddActionPerformed(evt);
   }
  });

  jLabel12.setText("Atf");

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(TF_Find)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext)
    .addGap(18, 18, 18)
    .addComponent(jLabel12)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleConvRulesActiveAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleConvRulesActiveRemove))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_FindBef)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_MultipleConvRulesActiveRemove)
    .addComponent(Btn_MultipleConvRulesActiveAdd)
    .addComponent(jLabel12))
  );

  Tbl_ConvRule.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ConvRule.setToolTipText("F9 - tambah ke DaftarKu ; F10 - hapus dr DaftarKu");
  Tbl_ConvRule.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ConvRule.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_ConvRule.setRowHeight(18);
  Tbl_ConvRule.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ConvRuleMouseReleased(evt);
   }
  });
  Tbl_ConvRule.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_ConvRuleKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ConvRuleKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_ConvRule);

  TF_ConvRuleInfoName.setEditable(false);
  TF_ConvRuleInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_ConvRuleInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane1)
   .addComponent(TF_ConvRuleInfoName)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_ConvRuleInfoName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel9.setBackground(new java.awt.Color(204, 255, 102));
  jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel14.setOpaque(false);

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("Sisi B");

  TF_ItemInCount.setEditable(false);
  TF_ItemInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_ItemInRemove.setText("H");
  Btn_ItemInRemove.setToolTipText("Hapus data barang masuk yg dipilih pd tabel");
  Btn_ItemInRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInRemoveActionPerformed(evt);
   }
  });

  Btn_ItemInEdit.setText("U");
  Btn_ItemInEdit.setToolTipText("Ubah data barang masuk yg dipilih pd tabel");
  Btn_ItemInEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInEditActionPerformed(evt);
   }
  });

  Btn_ItemInAdd.setText("B");
  Btn_ItemInAdd.setToolTipText("Tambah data barang masuk");
  Btn_ItemInAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInAddActionPerformed(evt);
   }
  });

  Btn_ItemInMove.setText("<<");
  Btn_ItemInMove.setToolTipText("Pindahkan barang-barang yg dipilih pada Sisi-B ke Sisi-A");
  Btn_ItemInMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInMoveActionPerformed(evt);
   }
  });

  CB_ItemInViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemInViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemInViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemInViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemInViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemInViewCategorized.setIconTextGap(0);
  CB_ItemInViewCategorized.setLabel("K");
  CB_ItemInViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemInViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemInViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInRemove))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(jLabel3)
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_ItemInRemove)
    .addComponent(Btn_ItemInEdit)
    .addComponent(Btn_ItemInAdd)
    .addComponent(Btn_ItemInMove)
    .addComponent(CB_ItemInViewCategorized))
  );

  Pnl_ItemInInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemInInfoCategory.setEditable(false);
  TA_ItemInInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoCategory.setColumns(20);
  TA_ItemInInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoCategory.setLineWrap(true);
  TA_ItemInInfoCategory.setRows(1);
  TA_ItemInInfoCategory.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_ItemInInfoCategory);

  TA_ItemInInfoName.setEditable(false);
  TA_ItemInInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoName.setColumns(20);
  TA_ItemInInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoName.setLineWrap(true);
  TA_ItemInInfoName.setRows(1);
  TA_ItemInInfoName.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_ItemInInfoName);

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
     .addComponent(jScrollPane6)))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel15Layout.createSequentialGroup()
    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemIn.setRowHeight(17);
  Tbl_ItemIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemInMouseReleased(evt);
   }
  });
  Tbl_ItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemInKeyReleased(evt);
   }
  });
  jScrollPane7.setViewportView(Tbl_ItemIn);

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel8.setBackground(new java.awt.Color(255, 204, 153));
  jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel5.setOpaque(false);

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel2.setText("Sisi A");

  TF_ItemOutCount.setEditable(false);
  TF_ItemOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_ItemOutRemove.setText("H");
  Btn_ItemOutRemove.setToolTipText("Hapus data barang keluar yg dipilih pd tabel");
  Btn_ItemOutRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutRemoveActionPerformed(evt);
   }
  });

  Btn_ItemOutEdit.setText("U");
  Btn_ItemOutEdit.setToolTipText("Ubah data barang keluar yg dipilih pd tabel");
  Btn_ItemOutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutEditActionPerformed(evt);
   }
  });

  Btn_ItemOutAdd.setText("B");
  Btn_ItemOutAdd.setToolTipText("Tambah data barang keluar");
  Btn_ItemOutAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutAddActionPerformed(evt);
   }
  });

  Btn_ItemOutMove.setText(">>");
  Btn_ItemOutMove.setToolTipText("Pindahkan barang-barang yg dipilih pada Sisi-A ke Sisi-B");
  Btn_ItemOutMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutMoveActionPerformed(evt);
   }
  });

  CB_ItemOutViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutViewCategorized.setText("K");
  CB_ItemOutViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemOutViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutViewCategorized.setIconTextGap(0);
  CB_ItemOutViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutRemove))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(jLabel2)
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_ItemOutRemove)
    .addComponent(Btn_ItemOutEdit)
    .addComponent(Btn_ItemOutAdd)
    .addComponent(Btn_ItemOutMove)
    .addComponent(CB_ItemOutViewCategorized))
  );

  Pnl_ItemOutInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemOutInfoCategory.setEditable(false);
  TA_ItemOutInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoCategory.setColumns(20);
  TA_ItemOutInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoCategory.setLineWrap(true);
  TA_ItemOutInfoCategory.setRows(1);
  TA_ItemOutInfoCategory.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemOutInfoCategory);

  TA_ItemOutInfoName.setEditable(false);
  TA_ItemOutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoName.setColumns(20);
  TA_ItemOutInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoName.setLineWrap(true);
  TA_ItemOutInfoName.setRows(1);
  TA_ItemOutInfoName.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_ItemOutInfoName);

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemOut.setRowHeight(17);
  Tbl_ItemOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemOutMouseReleased(evt);
   }
  });
  Tbl_ItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemOutKeyReleased(evt);
   }
  });
  jScrollPane4.setViewportView(Tbl_ItemOut);

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_QueryCount.setEditable(false);
  TF_QueryCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_QueryTempListCount.setEditable(false);
  TF_QueryTempListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryTempListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CmB_ResultFilterSubset.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "*Semua", "*DaftarKu", "*~DftarKu" }));
  CmB_ResultFilterSubset.setToolTipText("Filter \"DaftarKu\"");
  CmB_ResultFilterSubset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterSubsetActionPerformed(evt);
   }
  });

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi aturan2 konversi yg dipilih dari 'DaftarKu'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan aturan2 konversi yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu' (klik kiri - lihat DaftarKu ; klik kanan - lihat ~DaftarKu)");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TempListQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TempListQuantityMouseClicked(evt);
   }
  });

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("*DaftarKu");

  Btn_QueryRefresh.setText("R");
  Btn_QueryRefresh.setToolTipText("klik 'R' untuk menyegarkan daftar aturan konversi dlm tabel");
  Btn_QueryRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_QueryRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryRefreshActionPerformed(evt);
   }
  });

  CmB_ResultFilterActive.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "{aktif}", "Aktif", "~Aktif" }));
  CmB_ResultFilterActive.setToolTipText("Filter \"Aktif\"");
  CmB_ResultFilterActive.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterActiveActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_QueryRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ResultFilterActive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel1)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListSave)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListLoad)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListClear))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_TempListClear)
    .addComponent(Btn_TempListLoad)
    .addComponent(Btn_TempListSave)
    .addComponent(Btn_TempListRemove)
    .addComponent(Btn_TempListAdd)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel1)
    .addComponent(Btn_QueryRefresh)
    .addComponent(CmB_ResultFilterActive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TabbedPane)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void TF_FIdNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FIdNameKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FIdName, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_FIdName)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FIdName)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FIdNameActionPerformed(null); break;
   case KeyEvent.VK_DOWN : focusRItem(true); break;
   case KeyEvent.VK_RIGHT : /*if(TF_FIdName.getCaretPosition()==TF_FIdName.getDocument().getLength() && TF_FIdName.getSelectedText()==null){focusRItem(true);}*/ break;
  }
 }//GEN-LAST:event_TF_FIdNameKeyPressed

 private void Btn_FIdNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FIdNameActionPerformed
  String input;
  StringBuilder SourceTable, Condition;
  int index;
  boolean bool;
  OValidation valid;
  
  index=CmB_FIdName.getSelectedIndex(); input=TF_FIdName.getText(); valid=new OValidation(true);
  switch(index){
   case 0 :
   case 1 :
    if(!PText.checkInput(input, false, CCore.CharsCount_Long(), 2, 0, 0, 0)){
     valid.addError(PText.getInputInfo(false, CCore.CharsCount_Long(), 2, 0, 0, 0, true));
    } break;
   case 2 :
    if(!PText.checkInput(input, false, 0, 0, 0, 0, 0)){
     valid.addError(PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
    } break;
  }
  if(!valid.getValid()){JOptionPane.showMessageDialog(null, "Inputan pencarian barang masih salah !\n\n"+valid.getError()); return;}
  
  SourceTable=new StringBuilder(); Condition=new StringBuilder(" where");
  switch(index){
   case 0 :
   case 1 : 
    bool=index==0;
    
    SourceTable.append(", ("+
     PMyShop.getQueryOfFindItemIds(
      PText.getString(bool, String.valueOf(Long.parseLong(input)), input), !bool, "Item.Id", null, true, null, false
     )+") as item_ids");
    
    Condition.append(" Item.Id=item_ids.Id");
    break;
   case 2 :
    SourceTable.append(", ("+
      "(select Id as 'ItemId' from Item where "+PSql.genCheckWord("Name", input, true, true)+") "+
      "union distinct "+
      "(select Item from ItemXVariant where "+PSql.genCheckWord("Variant", input, true, true)+" group by Item) "+
     ") as item_name");
    
    Condition.append(" Item.Id=item_name.ItemId");
    break;
  }
  
  setLastQueryRItem(1, 0, SourceTable.toString(), Condition.toString(), true, "", false, 0, true);
  fillRItem();
 }//GEN-LAST:event_Btn_FIdNameActionPerformed

 private void Btn_FCatFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatFindBefActionPerformed
  findInListFCat(2);
 }//GEN-LAST:event_Btn_FCatFindBefActionPerformed

 private void Btn_FCatFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatFindNextActionPerformed
  findInListFCat(1);
 }//GEN-LAST:event_Btn_FCatFindNextActionPerformed

 private void TF_FCatFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FCatFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FCatFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FCat)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FCatRefresh)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FCatFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FCatFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FCatFindKeyPressed

 private void Tbl_FCatKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_FCatKeyReleased
  onSelectedRowChangedFCat(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_FCat, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FCatFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_DOWN : if(Tbl_FCat.getSelectedRow()==-1 || Tbl_FCat.OnKeyPress_PosRow>=TableMdlFCat.getRowCount()-1){focusRItem(true);} break;
   case KeyEvent.VK_RIGHT : focusRItem(true); break;
  }
 }//GEN-LAST:event_Tbl_FCatKeyReleased

 private void Tbl_FCatMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_FCatMouseReleased
  onSelectedRowChangedFCat(false);
 }//GEN-LAST:event_Tbl_FCatMouseReleased

 private void Tbl_RItemMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_RItemMouseReleased
  onSelectedRowChangedRItem(false);
 }//GEN-LAST:event_Tbl_RItemMouseReleased

 private void Tbl_RItemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_RItemKeyReleased
  onSelectedRowChangedRItem(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_RItem, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_InsertConvRule)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : if(Tbl_RItem.getSelectedRow()==-1 || Tbl_RItem.OnKeyPress_PosRow<=0){if(LastFocusedCmpSearchFItem==1){focusFIdName();}} break;
   case KeyEvent.VK_LEFT : if(Tbl_RItem.getSelectedRow()==-1 || Tbl_RItem.OnKeyPress_PosCol<=0){} focusFItem(true); break;
   case KeyEvent.VK_RIGHT : if(Tbl_RItem.getSelectedRow()==-1 || Tbl_RItem.OnKeyPress_PosCol>=Tbl_RItem.getColumnCount()-1){} focusQueryResult(); break;
  }
 }//GEN-LAST:event_Tbl_RItemKeyReleased

 private void TF_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemIdKeyPressed
  PNav.onKey_Query_TF(this, CB_QItemId, TF_QItemId, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvRuleUpdateStartY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QItemId)));
 }//GEN-LAST:event_TF_QItemIdKeyPressed

 private void TF_QItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemNameKeyPressed
  PNav.onKey_Query_TF(this, CB_QItemName, TF_QItemName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QConvRuleName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemName)));
 }//GEN-LAST:event_TF_QItemNameKeyPressed

 private void TF_QConvRuleNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvRuleNameKeyPressed
  PNav.onKey_Query_TF(this, CB_QConvRuleName, TF_QConvRuleName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemCategoryAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvRuleName)));
 }//GEN-LAST:event_TF_QConvRuleNameKeyPressed

 private void Btn_QItemCategoryAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemCategoryAddActionPerformed
  int temp, temp_;
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfItem;
  IFV.FDataIdName.wUseCustomTitle=false;
  
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  temp_=0; temp=IFV.FDataIdName.DataId.length;
  do{
   ListMdlQItemCategory.append(PCore.objArrVariant(
    (int)IFV.FDataIdName.DataId[temp_],
    IFV.FDataIdName.DataName[temp_]
   ));
   
   temp_=temp_+1;
  }while(temp_!=temp);
 }//GEN-LAST:event_Btn_QItemCategoryAddActionPerformed

 private void Btn_QItemCategoryRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemCategoryRemoveActionPerformed
  ListMdlQItemCategory.remove(List_QItemCategory.getSelectedIndices());
 }//GEN-LAST:event_Btn_QItemCategoryRemoveActionPerformed

 private void Btn_QItemAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemAddActionPerformed
  int count, temp;
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=true;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  temp=0; count=IFV.FItem.ChoosedId.length;
  do{
   TableMdlQItem.append(PCore.objArrVariant(
    IFV.FItem.ChoosedId[temp],
    IFV.FItem.ChoosedName[temp]
   ));
   
   temp=temp+1;
  }while(temp!=count);
 }//GEN-LAST:event_Btn_QItemAddActionPerformed

 private void Btn_QItemRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveActionPerformed
  TableMdlQItem.remove(Tbl_QItem.getSelectedRows());
 }//GEN-LAST:event_Btn_QItemRemoveActionPerformed

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  runQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void Btn_QueryRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryRefreshActionPerformed
  fillConvRule(false);
 }//GEN-LAST:event_Btn_QueryRefreshActionPerformed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  PMyShop.tempListAdd(this, this, PGUI.getIdsFromSelectedRows(TableMdlConvRule, Tbl_ConvRule.getSelectedRows(), 0), true);
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  PMyShop.tempListAdd(this, this, PGUI.getIdsFromSelectedRows(TableMdlConvRule, Tbl_ConvRule.getSelectedRows(), 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  PMyShop.tempListSave(this, this, TempList, IFV.FileChooser, IFV.ReportFileFilter, IFV.FSplashScreen);
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  PMyShop.tempListLoad(this, this, TempList, IFV.FileChooser, IFV.ReportFileFilter, IFV.FSplashScreen);
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  PMyShop.tempListClear(this, this);
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Btn_FindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBefActionPerformed
  findInTableConvRule(2);
 }//GEN-LAST:event_Btn_FindBefActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findInTableConvRule(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void Btn_MultipleConvRulesActiveAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleConvRulesActiveAddActionPerformed
  setConvRuleActive(true);
 }//GEN-LAST:event_Btn_MultipleConvRulesActiveAddActionPerformed

 private void Btn_MultipleConvRulesActiveRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleConvRulesActiveRemoveActionPerformed
  setConvRuleActive(false);
 }//GEN-LAST:event_Btn_MultipleConvRulesActiveRemoveActionPerformed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ConvRule)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void Tbl_ConvRuleKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ConvRuleKeyReleased
  onSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ConvRule, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_LEFT:
    if(Tbl_ConvRule.OnKeyPress_PosCol<=0){
     switch(TabbedPane.getSelectedIndex()){
      case 0 : focusQuery(); break;
      case 1 : focusRItem(true); break;
     }
    }
    break;
  }
 }//GEN-LAST:event_Tbl_ConvRuleKeyReleased

 private void Tbl_ConvRuleMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ConvRuleMouseReleased
  onSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_ConvRuleMouseReleased

 private void Tbl_ItemOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemOutMouseReleased
  onSelectedRowChangedConvItems(true, false);
 }//GEN-LAST:event_Tbl_ItemOutMouseReleased

 private void Tbl_ItemOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemOutKeyReleased
  onSelectedRowChangedConvItems(true, false);
 }//GEN-LAST:event_Tbl_ItemOutKeyReleased

 private void Tbl_ItemInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemInKeyReleased
  onSelectedRowChangedConvItems(false, false);
 }//GEN-LAST:event_Tbl_ItemInKeyReleased

 private void Tbl_ItemInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemInMouseReleased
  onSelectedRowChangedConvItems(false, false);
 }//GEN-LAST:event_Tbl_ItemInMouseReleased

 private void Btn_NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_NewActionPerformed
  addConvRule();
 }//GEN-LAST:event_Btn_NewActionPerformed

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  editConvRule();
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  removeConvRule();
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void Btn_ChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseActionPerformed
  if(!Btn_Choose.isVisible()){return;}
  
  chooseData();
 }//GEN-LAST:event_Btn_ChooseActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean ModeChoose;
  
  if(Activ){return;}
  
  Activ=true;
  ModeChoose=wMode!=0;
  
  setTitle(PText.getString(!ModeChoose, "Aturan Konversi", "Cari dan Pilih Aturan Konversi"));
  
  Tbl_ConvRule.setSelectionMode(PCore.subtBool_Int(!wAllowMultipleSelection, ListSelectionModel.SINGLE_SELECTION, ListSelectionModel.MULTIPLE_INTERVAL_SELECTION));
  Lbl_MultipleSelection.setVisible(wAllowMultipleSelection && ModeChoose);
  Btn_Choose.setVisible(ModeChoose);
  
  dialogWithFItem(wDialogWithFItem);

  initPrivGUIShow();

  TabbedPane.setSelectedIndex(1); onTabbedPaneChanged();

  // PGUI.requestFocusInWindow(TF_FIdName);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void CmB_ResultFilterSubsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterSubsetActionPerformed
  onSelectedAdditionalFilterChanged(CmB_ResultFilterSubset, LastResultFilterSubset);
 }//GEN-LAST:event_CmB_ResultFilterSubsetActionPerformed

 private void CmB_ResultFilterActiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterActiveActionPerformed
  onSelectedAdditionalFilterChanged(CmB_ResultFilterActive, LastResultFilterIsActive);
 }//GEN-LAST:event_CmB_ResultFilterActiveActionPerformed

 private void TF_TempListQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TempListQuantityMouseClicked
  int DynamicTempList=0;
  
  do{
   if(SwingUtilities.isLeftMouseButton(evt)){DynamicTempList=1; break;}
   if(SwingUtilities.isRightMouseButton(evt)){DynamicTempList=2; break;}
   DynamicTempList=-1;
  }while(false);
  if(DynamicTempList==-1){return;}
  
  setLastQuery(3, 0, "", "", false, "", false, DynamicTempList, false);
  fillConvRule(false);
 }//GEN-LAST:event_TF_TempListQuantityMouseClicked

 private void Btn_RItemRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RItemRefreshActionPerformed
  fillRItem();
 }//GEN-LAST:event_Btn_RItemRefreshActionPerformed

 private void TF_QItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemIdFocusGained
  LastFocusedCmpSearch=TF_QItemId;
  PGUI.text_SelectAll(TF_QItemId);
 }//GEN-LAST:event_TF_QItemIdFocusGained

 private void Tbl_ConvRuleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ConvRuleKeyPressed
  boolean ChooseMode=wMode!=0;
  
  switch(evt.getKeyCode()){
			case KeyEvent.VK_ENTER:
    if(ChooseMode && !Tbl_ConvRule.isEditing()){
     if(Tbl_ConvRule.getSelectedRows().length!=0){evt.consume(); Btn_ChooseActionPerformed(null);}
    }
    break;
  }
 }//GEN-LAST:event_Tbl_ConvRuleKeyPressed

 private void TF_QItemNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemNameFocusGained
  LastFocusedCmpSearch=TF_QItemName;
  PGUI.text_SelectAll(TF_QItemName);
 }//GEN-LAST:event_TF_QItemNameFocusGained

 private void TF_QConvRuleNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvRuleNameFocusGained
  LastFocusedCmpSearch=TF_QConvRuleName;
  PGUI.text_SelectAll(TF_QConvRuleName);
 }//GEN-LAST:event_TF_QConvRuleNameFocusGained

 private void TF_QConvRuleUpdateEndYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvRuleUpdateEndYFocusGained
  LastFocusedCmpSearch=TF_QConvRuleUpdateEndY;
  PGUI.text_SelectAll(TF_QConvRuleUpdateEndY);
 }//GEN-LAST:event_TF_QConvRuleUpdateEndYFocusGained

 private void TF_QConvRuleUpdateStartYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvRuleUpdateStartYFocusGained
  LastFocusedCmpSearch=TF_QConvRuleUpdateStartY;
  PGUI.text_SelectAll(TF_QConvRuleUpdateStartY);
 }//GEN-LAST:event_TF_QConvRuleUpdateStartYFocusGained

 private void Btn_FCatRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatRefreshActionPerformed
  fillFCat(0);
 }//GEN-LAST:event_Btn_FCatRefreshActionPerformed

 private void Tbl_RItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_RItemKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_SPACE : evt.consume(); focusQuickInsert(); break;
  }
 }//GEN-LAST:event_Tbl_RItemKeyPressed

 private void Lbl_QItemIdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QItemIdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QItemIdHelpMouseClicked

 private void Lbl_QItemNameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QItemNameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QItemNameHelpMouseClicked

 private void Lbl_ConvRuleNameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ConvRuleNameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_ConvRuleNameHelpMouseClicked

 private void TF_FIdNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FIdNameFocusGained
  TF_FIdName.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_FIdName);
  
  LastFocusedCmpSearchFItem=1;
 }//GEN-LAST:event_TF_FIdNameFocusGained

 private void Tbl_FCatFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Tbl_FCatFocusGained
  LastFocusedCmpSearchFItem=2;
 }//GEN-LAST:event_Tbl_FCatFocusGained

 private void Pnl_RItemInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_RItemInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_RItem, TableMdlRItem, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_RItemInfoPreviewMouseClicked

 private void Pnl_ItemOutInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemOut, TableMdlConvItemsOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutInfoPreviewMouseClicked

 private void Pnl_ItemInInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemIn, TableMdlConvItemsIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInInfoPreviewMouseClicked

 private void TF_FIdNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FIdNameFocusLost
  TF_FIdName.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FIdNameFocusLost

 private void TF_FCatFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FCatFindFocusGained
  TF_FCatFind.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_FCatFind);
 }//GEN-LAST:event_TF_FCatFindFocusGained

 private void TF_FCatFindFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FCatFindFocusLost
  TF_FCatFind.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FCatFindFocusLost

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 private void TF_FindFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusLost
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FindFocusLost

 private void Btn_ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReportActionPerformed
  switch(CmB_ReportType.getSelectedIndex()){
   case 0 : printReport(); break; // Report
   case 1 : printCSV(); break; // CSV Report
  }
 }//GEN-LAST:event_Btn_ReportActionPerformed

 private void Btn_FChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FChooseItemActionPerformed
  long[] ids;
  
  if(!Btn_FChooseItem.isEnabled()){return;}
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=true;
  
  if(!IFV.FItem.showForm()){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  ids=PCore.primArr(IFV.FItem.ChoosedId);
  setLastQueryRItem(3, 0, "", " where Item.Id in("+PText.toString(ids, 0, ids.length, ",")+")", true, "", false, 0, false);
  fillRItem();
 }//GEN-LAST:event_Btn_FChooseItemActionPerformed

 private void Btn_FChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FChooseItemKeyPressed
  PNav.onKey_Btn(this, Btn_FChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FCat)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_RItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_RItemViewCategorized)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_FIdName)));
 }//GEN-LAST:event_Btn_FChooseItemKeyPressed

 private void Btn_ItemOutAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutAddActionPerformed
  convItemsAdd(true);
 }//GEN-LAST:event_Btn_ItemOutAddActionPerformed

 private void Btn_ItemOutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutEditActionPerformed
  convItemsEdit(true);
 }//GEN-LAST:event_Btn_ItemOutEditActionPerformed

 private void Btn_ItemOutRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutRemoveActionPerformed
  convItemsDelete(true);
 }//GEN-LAST:event_Btn_ItemOutRemoveActionPerformed

 private void Btn_ItemOutMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutMoveActionPerformed
  convItemsMove(true);
 }//GEN-LAST:event_Btn_ItemOutMoveActionPerformed

 private void Btn_ItemInAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInAddActionPerformed
  convItemsAdd(false);
 }//GEN-LAST:event_Btn_ItemInAddActionPerformed

 private void Btn_ItemInEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInEditActionPerformed
  convItemsEdit(false);
 }//GEN-LAST:event_Btn_ItemInEditActionPerformed

 private void Btn_ItemInRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInRemoveActionPerformed
  convItemsDelete(false);
 }//GEN-LAST:event_Btn_ItemInRemoveActionPerformed

 private void Btn_ItemInMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInMoveActionPerformed
  convItemsMove(false);
 }//GEN-LAST:event_Btn_ItemInMoveActionPerformed

 private void Btn_InsertConvRuleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InsertConvRuleActionPerformed
  quickInsertConvRule();
 }//GEN-LAST:event_Btn_InsertConvRuleActionPerformed

 private void Btn_InsertItemOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InsertItemOutActionPerformed
  quickInsertItem(true);
 }//GEN-LAST:event_Btn_InsertItemOutActionPerformed

 private void Btn_InsertItemInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InsertItemInActionPerformed
  quickInsertItem(false);
 }//GEN-LAST:event_Btn_InsertItemInActionPerformed

 private void TF_InsertItemOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_InsertItemOutKeyPressed
  JTextField TF=TF_InsertItemOut;
  
  int consumed=PNav.onKey_TF(this, TF_InsertItemOut, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InsertItemOut)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InsertItemIn)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
   case KeyEvent.VK_SPACE : evt.consume(); focusRItem(true); break;
  }
 }//GEN-LAST:event_TF_InsertItemOutKeyPressed

 private void TF_InsertItemInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_InsertItemInKeyPressed
  JTextField TF=TF_InsertItemIn;
  
  int consumed=PNav.onKey_TF(this, TF_InsertItemIn, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InsertItemIn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_RItemModeAdd)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
   case KeyEvent.VK_SPACE : evt.consume(); focusRItem(true); break;
  }
 }//GEN-LAST:event_TF_InsertItemInKeyPressed

 private void TF_InsertConvRuleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_InsertConvRuleKeyPressed
  JTextField TF=TF_InsertConvRule;
  
  int consumed=PNav.onKey_TF(this, TF_InsertConvRule, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_InsertConvRule)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InsertItemOut)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
   case KeyEvent.VK_SPACE : if(evt.isShiftDown()){evt.consume(); focusRItem(true);} break;
  }
 }//GEN-LAST:event_TF_InsertConvRuleKeyPressed

 private void TF_InsertConvRuleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_InsertConvRuleFocusGained
  TF_InsertConvRule.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_InsertConvRule);
  
  LastFocusedCmpQuickInsert=TF_InsertConvRule;
 }//GEN-LAST:event_TF_InsertConvRuleFocusGained

 private void TF_InsertConvRuleFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_InsertConvRuleFocusLost
  TF_InsertConvRule.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_InsertConvRuleFocusLost

 private void TF_InsertItemOutFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_InsertItemOutFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_InsertItemOut, TF_InsertItem_ShortcutKeys);
  
  TF_InsertItemOut.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_InsertItemOut);
  
  LastFocusedCmpQuickInsert=TF_InsertItemOut;
 }//GEN-LAST:event_TF_InsertItemOutFocusGained

 private void TF_InsertItemOutFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_InsertItemOutFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  TF_InsertItemOut.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_InsertItemOutFocusLost

 private void TF_InsertItemInFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_InsertItemInFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_InsertItemIn, TF_InsertItem_ShortcutKeys);
  
  TF_InsertItemIn.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_InsertItemIn);
  
  LastFocusedCmpQuickInsert=TF_InsertItemIn;
 }//GEN-LAST:event_TF_InsertItemInFocusGained

 private void TF_InsertItemInFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_InsertItemInFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  TF_InsertItemIn.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_InsertItemInFocusLost

 private void CmB_InsertConvRuleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_InsertConvRuleKeyPressed
  int consumed=PNav.onKey_CmB(this, CmB_InsertConvRule, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InsertConvRule)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_InsertConvRule)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_SPACE : evt.consume(); focusRItem(true); break;
  }
 }//GEN-LAST:event_CmB_InsertConvRuleKeyPressed

 private void Btn_InsertItemOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InsertItemOutKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_InsertItemOut, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_InsertConvRule)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_InsertItemOut)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
  }
 }//GEN-LAST:event_Btn_InsertItemOutKeyPressed

 private void Btn_InsertItemInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InsertItemInKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_InsertItemIn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_InsertItemOut)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_InsertItemIn)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
  }
 }//GEN-LAST:event_Btn_InsertItemInKeyPressed

 private void Btn_InsertConvRuleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InsertConvRuleKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_InsertConvRule, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_InsertConvRule)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
  }
 }//GEN-LAST:event_Btn_InsertConvRuleKeyPressed

 private void Btn_RItemModeAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RItemModeAddActionPerformed
  setRItemModeAdd(!RItemModeAddOn);
 }//GEN-LAST:event_Btn_RItemModeAddActionPerformed

 private void Btn_RItemModeAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_RItemModeAddKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_RItemModeAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_InsertItemIn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusRItem(true); break;
  }
 }//GEN-LAST:event_Btn_RItemModeAddKeyPressed

 private void CmB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCheckKeyPressed
  PNav.onKey_CmB(this, CmB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCheck)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QCheckKeyPressed

 private void CB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCheckKeyPressed
  PNav.onKey_CB(this, CB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvRuleUpdate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCheck)));
 }//GEN-LAST:event_CB_QCheckKeyPressed

 private void Btn_QueryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QueryKeyPressed
  PNav.onKey_Btn(this, Btn_Query, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QueryKeyPressed

 private void CB_QConvRuleUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvRuleUpdateKeyPressed
  PNav.onKey_CB(this, CB_QConvRuleUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvRuleUpdateStartY)));
 }//GEN-LAST:event_CB_QConvRuleUpdateKeyPressed

 private void TF_QConvRuleUpdateStartYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvRuleUpdateStartYKeyPressed
  PNav.onKey_TF(this, TF_QConvRuleUpdateStartY, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvRuleUpdate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvRuleUpdateStartM)));
 }//GEN-LAST:event_TF_QConvRuleUpdateStartYKeyPressed

 private void CmB_QConvRuleUpdateStartMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvRuleUpdateStartMKeyPressed
  PNav.onKey_CmB(this, CmB_QConvRuleUpdateStartM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QConvRuleUpdateStartY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvRuleUpdateStartD)));
 }//GEN-LAST:event_CmB_QConvRuleUpdateStartMKeyPressed

 private void CmB_QConvRuleUpdateStartDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvRuleUpdateStartDKeyPressed
  PNav.onKey_CmB(this, CmB_QConvRuleUpdateStartD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QConvRuleUpdateStartM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvRuleUpdateEndY)));
 }//GEN-LAST:event_CmB_QConvRuleUpdateStartDKeyPressed

 private void TF_QConvRuleUpdateEndYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvRuleUpdateEndYKeyPressed
  PNav.onKey_TF(this, TF_QConvRuleUpdateEndY, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QConvRuleUpdateStartD)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvRuleUpdateEndM)));
 }//GEN-LAST:event_TF_QConvRuleUpdateEndYKeyPressed

 private void CmB_QConvRuleUpdateEndMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvRuleUpdateEndMKeyPressed
  PNav.onKey_CmB(this, CmB_QConvRuleUpdateEndM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QConvRuleUpdateEndY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvRuleUpdateEndD)));
 }//GEN-LAST:event_CmB_QConvRuleUpdateEndMKeyPressed

 private void CmB_QConvRuleUpdateEndDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvRuleUpdateEndDKeyPressed
  PNav.onKey_CmB(this, CmB_QConvRuleUpdateEndD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QConvRuleUpdateEndM)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QConvRuleUpdateEndDKeyPressed

 private void CB_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemIdKeyPressed
  PNav.onKey_CB(this, CB_QItemId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvRuleUpdate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QItemId)));
 }//GEN-LAST:event_CB_QItemIdKeyPressed

 private void CmB_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QItemIdKeyPressed
  PNav.onKey_CmB(this, CmB_QItemId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemId)));
 }//GEN-LAST:event_CmB_QItemIdKeyPressed

 private void CB_QItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemNameKeyPressed
  PNav.onKey_CB(this, CB_QItemName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvRuleName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemName)));
 }//GEN-LAST:event_CB_QItemNameKeyPressed

 private void CB_QConvRuleNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvRuleNameKeyPressed
  PNav.onKey_CB(this, CB_QConvRuleName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemCategory)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvRuleName)));
 }//GEN-LAST:event_CB_QConvRuleNameKeyPressed

 private void CB_QItemCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemCategoryKeyPressed
  PNav.onKey_CB(this, CB_QItemCategory, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvRuleName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemCategoryNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QItemCategory)));
 }//GEN-LAST:event_CB_QItemCategoryKeyPressed

 private void CB_QItemCategoryNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemCategoryNonKeyPressed
  PNav.onKey_CB(this, CB_QItemCategoryNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemCategory)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QItemCategory)));
 }//GEN-LAST:event_CB_QItemCategoryNonKeyPressed

 private void Btn_QItemCategoryAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemCategoryAddKeyPressed
  PNav.onKey_Btn(this, Btn_QItemCategoryAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvRuleName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemCategoryRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QItemCategory)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemCategoryAddKeyPressed

 private void Btn_QItemCategoryRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemCategoryRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QItemCategoryRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemCategoryAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QItemCategory)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemCategoryRemoveKeyPressed

 private void CB_QItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemKeyPressed
  PNav.onKey_CB(this, CB_QItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemCategoryNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QItem)));
 }//GEN-LAST:event_CB_QItemKeyPressed

 private void Btn_QItemAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemAddKeyPressed
  PNav.onKey_Btn(this, Btn_QItemAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemCategoryRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemAddKeyPressed

 private void Btn_QItemRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QItemRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemRemoveKeyPressed

 private void Btn_FCatRefreshKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatRefreshKeyPressed
  PNav.onKey_Btn(this, Btn_FCatRefresh, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FCat)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_FCatFind)));
 }//GEN-LAST:event_Btn_FCatRefreshKeyPressed

 private void Btn_FCatFindBefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatFindBefKeyPressed
  PNav.onKey_Btn(this, Btn_FCatFindBef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FCat)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_FCatFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FCatFindNext)));
 }//GEN-LAST:event_Btn_FCatFindBefKeyPressed

 private void Btn_FCatFindNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatFindNextKeyPressed
  PNav.onKey_Btn(this, Btn_FCatFindNext, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FCat)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FCatFindBef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_FCatFindNextKeyPressed

 private void Btn_RItemRefreshKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_RItemRefreshKeyPressed
  PNav.onKey_Btn(this, Btn_RItemRefresh, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FCat)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_RItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_RItemViewCategorized)));
 }//GEN-LAST:event_Btn_RItemRefreshKeyPressed

 private void CmB_FIdNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_FIdNameKeyPressed
  PNav.onKey_CmB(this, CmB_FIdName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FChooseItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_FIdName)));
 }//GEN-LAST:event_CmB_FIdNameKeyPressed

 private void Btn_FIdNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FIdNameKeyPressed
  PNav.onKey_Btn(this, Btn_FIdName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FCat)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_RItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_FIdName)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_FIdNameKeyPressed

 private void List_QItemCategoryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QItemCategoryKeyReleased
  PNav.onKey_List(this, List_QItemCategory, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvRuleName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemCategory)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QItemCategoryAdd)));
 }//GEN-LAST:event_List_QItemCategoryKeyReleased

 private void Tbl_QItemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_QItemKeyReleased
  PNav.onKey_Tbl(this, Tbl_QItem, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemCategoryAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QItemAdd)));
 }//GEN-LAST:event_Tbl_QItemKeyReleased

 private void CB_ItemInViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemInViewCategorizedActionPerformed
  changeConvItemsViewByCategorized(false);
 }//GEN-LAST:event_CB_ItemInViewCategorizedActionPerformed

 private void CB_RItemViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_RItemViewCategorizedActionPerformed
  changeRItemViewByCategorized();
 }//GEN-LAST:event_CB_RItemViewCategorizedActionPerformed

 private void CB_ItemOutViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutViewCategorizedActionPerformed
  changeConvItemsViewByCategorized(true);
 }//GEN-LAST:event_CB_ItemOutViewCategorizedActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Choose;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FCatFindBef;
 private javax.swing.JButton Btn_FCatFindNext;
 private javax.swing.JButton Btn_FCatRefresh;
 private javax.swing.JButton Btn_FChooseItem;
 private javax.swing.JButton Btn_FIdName;
 private javax.swing.JButton Btn_FindBef;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_InsertConvRule;
 private javax.swing.JButton Btn_InsertItemIn;
 private javax.swing.JButton Btn_InsertItemOut;
 private javax.swing.JButton Btn_ItemInAdd;
 private javax.swing.JButton Btn_ItemInEdit;
 private javax.swing.JButton Btn_ItemInMove;
 private javax.swing.JButton Btn_ItemInRemove;
 private javax.swing.JButton Btn_ItemOutAdd;
 private javax.swing.JButton Btn_ItemOutEdit;
 private javax.swing.JButton Btn_ItemOutMove;
 private javax.swing.JButton Btn_ItemOutRemove;
 private javax.swing.JButton Btn_MultipleConvRulesActiveAdd;
 private javax.swing.JButton Btn_MultipleConvRulesActiveRemove;
 private javax.swing.JButton Btn_New;
 private javax.swing.JButton Btn_QItemAdd;
 private javax.swing.JButton Btn_QItemCategoryAdd;
 private javax.swing.JButton Btn_QItemCategoryRemove;
 private javax.swing.JButton Btn_QItemRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_QueryRefresh;
 private javax.swing.JButton Btn_RItemModeAdd;
 private javax.swing.JButton Btn_RItemRefresh;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Report;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JToggleButton CB_ItemInViewCategorized;
 private javax.swing.JToggleButton CB_ItemOutViewCategorized;
 private javax.swing.JCheckBox CB_QCheck;
 private javax.swing.JCheckBox CB_QConvRuleName;
 private javax.swing.JCheckBox CB_QConvRuleUpdate;
 private javax.swing.JCheckBox CB_QItem;
 private javax.swing.JCheckBox CB_QItemCategory;
 private javax.swing.JCheckBox CB_QItemCategoryNon;
 private javax.swing.JCheckBox CB_QItemId;
 private javax.swing.JCheckBox CB_QItemName;
 private javax.swing.JToggleButton CB_RItemViewCategorized;
 private javax.swing.JComboBox<String> CmB_FIdName;
 private javax.swing.JComboBox<String> CmB_InsertConvRule;
 private javax.swing.JComboBox<String> CmB_QCheck;
 private javax.swing.JComboBox<String> CmB_QConvRuleUpdateEndD;
 private javax.swing.JComboBox<String> CmB_QConvRuleUpdateEndM;
 private javax.swing.JComboBox<String> CmB_QConvRuleUpdateStartD;
 private javax.swing.JComboBox<String> CmB_QConvRuleUpdateStartM;
 private javax.swing.JComboBox<String> CmB_QItemId;
 private javax.swing.JComboBox<String> CmB_ReportType;
 private javax.swing.JComboBox<String> CmB_ResultFilterActive;
 private javax.swing.JComboBox<String> CmB_ResultFilterSubset;
 private javax.swing.JLabel Lbl_ConvRuleNameHelp;
 private javax.swing.JLabel Lbl_MultipleSelection;
 private javax.swing.JLabel Lbl_QItemIdHelp;
 private javax.swing.JLabel Lbl_QItemNameHelp;
 private XList List_QItemCategory;
 private XImgBoxURL Pnl_ItemInInfoPreview;
 private XImgBoxURL Pnl_ItemOutInfoPreview;
 private javax.swing.JPanel Pnl_Query;
 private javax.swing.JPanel Pnl_QueryByItem;
 private XImgBoxURL Pnl_RItemInfoPreview;
 private javax.swing.JScrollPane SP_TblFCat;
 private javax.swing.JTextArea TA_ItemInInfoCategory;
 private javax.swing.JTextArea TA_ItemInInfoName;
 private javax.swing.JTextArea TA_ItemOutInfoCategory;
 private javax.swing.JTextArea TA_ItemOutInfoName;
 private javax.swing.JTextArea TA_RItemInfoCategory;
 private javax.swing.JTextArea TA_RItemInfoName;
 private javax.swing.JTextField TF_ConvRuleInfoName;
 private javax.swing.JTextField TF_FCatCount;
 private javax.swing.JTextField TF_FCatFind;
 private javax.swing.JTextField TF_FIdName;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_InsertConvRule;
 private javax.swing.JTextField TF_InsertItemIn;
 private javax.swing.JTextField TF_InsertItemOut;
 private javax.swing.JTextField TF_ItemInCount;
 private javax.swing.JTextField TF_ItemOutCount;
 private javax.swing.JTextField TF_QConvRuleName;
 private javax.swing.JTextField TF_QConvRuleUpdateEndY;
 private javax.swing.JTextField TF_QConvRuleUpdateStartY;
 private javax.swing.JTextField TF_QItemId;
 private javax.swing.JTextField TF_QItemName;
 private javax.swing.JTextField TF_QueryCount;
 private javax.swing.JTextField TF_QueryTempListCount;
 private javax.swing.JTextField TF_RItemCount;
 private javax.swing.JTextField TF_TempListQuantity;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_ConvRule;
 private XTable Tbl_FCat;
 private XTable Tbl_ItemIn;
 private XTable Tbl_ItemOut;
 private XTable Tbl_QItem;
 private XTable Tbl_RItem;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel12;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel16;
 private javax.swing.JPanel jPanel18;
 private javax.swing.JPanel jPanel19;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel20;
 private javax.swing.JPanel jPanel21;
 private javax.swing.JPanel jPanel22;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane12;
 private javax.swing.JScrollPane jScrollPane13;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane9;
 // End of variables declaration//GEN-END:variables
}