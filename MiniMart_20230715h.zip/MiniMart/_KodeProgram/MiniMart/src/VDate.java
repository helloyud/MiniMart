import java.util.Date;

public class VDate {

 Date Value;

 public VDate() {}

 public VDate(Date Value) {this.Value = Value;}
 
 

}