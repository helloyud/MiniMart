import javax.swing.JCheckBox;

public class OInputBooleanGUICheck extends OInput {

 JCheckBox GUI_Check;
 
 VBoolean Value;

 public OInputBooleanGUICheck(JCheckBox GUI_Check) {
  this.GUI_Check = GUI_Check;
  Value=new VBoolean();
 }
 
 public boolean isValid(){return PGUI.checkInputBoolean(GUI_Check, Value);}
 public Object getValue(){return Value.Value;}

}