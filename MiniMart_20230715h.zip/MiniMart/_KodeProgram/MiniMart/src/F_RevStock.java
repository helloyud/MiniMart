import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.util.Date;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.KeyStroke;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class F_RevStock extends XFormDialog {
 
 // Table Revisi Stock
 OCustomTableModel TableMdlRev;
 int LastSelectedRow;
	
	String[] TableRevColsName;
	int[] TableRevColsType;
	int[] TableRevColsShowOption;
	boolean[] TableRevColsEditable;
	
 boolean LastQueryDefined;
 int LastQueryOperationBy;
	int LQ_Limit;
 String LQ_OrderBy;
 // Static Filter
 String LQ_StaticSourceTable, LQ_StaticCondition, LQ_StaticPostCondition;
 boolean LQ_StaticConditionDefined, LQ_StaticPostConditionDefined;
 // Dynamic Filter
 int LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
 // Additional Filter
 boolean LQ_WithAdditionalFilter;
 
 String QHavingTbl;
 
 int LastResultFilterSubset;
 
 int[] TableRevColsVisible, TableRevColsWidth;
 
 // Panel View
 int LastSelectedViewMode;
 
 // Tab Search
 OCustomListModel ListMdlQReasonOfRevisi;
 OCustomTableModel TableMdlQItem;
 Component LastFocusedCmpSearch;
 
 //
 OQuickListOfLong TempList;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 public F_RevStock(MInterFormVariables IFV_) {
  int[] Editable;
  Date dt;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();

  // Tab Search
  ListMdlQReasonOfRevisi=new OCustomListModel(false);
  ListMdlQReasonOfRevisi.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QReasonOfRevisi.setModel(ListMdlQReasonOfRevisi);
  
  TableMdlQItem=new OCustomTableModel();
  TableMdlQItem.setColumnsInfo(
   PCore.refArr("Id", "Nama"),
   PCore.primArr(CCore.TypeLong, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(2, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(1, 0));
  Tbl_QItem.setModel(TableMdlQItem);
  PGUI.resizeTableColumn(Tbl_QItem, PCore.primArr(CGUI.ColTextMed, CGUI.ColNum13));
  
  dt=new Date();
  PGUI.setDateComponent(dt, TF_QRevDateStartY, CmB_QRevDateStartM, CmB_QRevDateStartD);
  PGUI.setDateComponent(dt, TF_QRevDateEndY, CmB_QRevDateEndM, CmB_QRevDateEndD);
  
  // Table Revisi Stock
  TableMdlRev=new OCustomTableModel(true, false, true);
  Tbl_Rev.setModel(TableMdlRev);
		TableRevColsName=PCore.refArr("Id", "Tgl Revisi", "Alasan Revisi", "Id Barang", "Nama Barang", "St-Lama", "St-Baru", "Selisih",
   "Sat. Stok", "Diperbarui", "File Gambar", "Kategori");
		TableRevColsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeDate, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeString, CCore.TypeBoolean, CCore.TypeString, CCore.TypeString);
  TableRevColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableRevColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(3), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=new int[0];
  TableRevColsEditable=PCore.changeValue(PCore.newBooleanArray(TableRevColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
  LastSelectedRow=-1;
  QHavingTbl="tb5";
  
  updateQueryCount();
  clearLastQuery();
  
  LastResultFilterSubset=CmB_ResultFilterSubset.getSelectedIndex();
  
  buildTableRevViewStructure(true, true);
  updateTableRevView(false);
  
  Tbl_Rev.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableRev();}
   };
  
  Pnl_ItemPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // TempList
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  clearTempList();
  
  // Panel View
  CB_ViewCategorized.setSelected(IFV.Conf.ItemCategorized);
  LastSelectedViewMode=-1; CmB_ViewMode.setSelectedIndex(1); onSelectedViewModeChanged(false);
  
  CmB_Find.setSelectedIndex(1);
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
  Btn_Query.setToolTipText("hasil pencarian terbatas hingga "+PText.intToString(CApp.FormQueryLimit)+" data");
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Query,
    
    CB_QCheck, CmB_QCheck,
    CB_QRevDate, TF_QRevDateStartY, CmB_QRevDateStartM, CmB_QRevDateStartD, TF_QRevDateEndY, CmB_QRevDateEndM, CmB_QRevDateEndD,
    CB_QItemId, CmB_QItemId, TF_QItemId,
    CB_QItemName, TF_QItemName,
    CB_QStockOld, TF_QStockOld1, TF_QStockOld2,
    CB_QStockNew, TF_QStockNew1, TF_QStockNew2,
    CB_QDifferent, TF_QDifferent1, TF_QDifferent2,
    CB_QReasonOfRevisi, CB_QReasonOfRevisiEmpty, List_QReasonOfRevisi, Btn_QReasonOfRevisiAdd, Btn_QReasonOfRevisiRemove,
    CB_QItem, Tbl_QItem, Btn_QItemAdd, Btn_QItemRemove,
    
    TF_Find, Tbl_Rev),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_NewActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_QueryActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // cancel table editing
  Tbl_Rev.editingCanceled(null);
  
  // Tab Search
  CB_QCheck.setSelected(false);
  CB_QRevDate.setSelected(false);
  CB_QItemId.setSelected(false); TF_QItemId.setText("");
  CB_QItemName.setSelected(false); TF_QItemName.setText("");
  CB_QStockOld.setSelected(false); TF_QStockOld1.setText(""); TF_QStockOld2.setText("");
  CB_QStockNew.setSelected(false); TF_QStockNew1.setText(""); TF_QStockNew2.setText("");
  CB_QDifferent.setSelected(false); TF_QDifferent1.setText(""); TF_QDifferent2.setText("");
		CB_QReasonOfRevisi.setSelected(false); CB_QReasonOfRevisiEmpty.setSelected(false); ListMdlQReasonOfRevisi.removeAll();
  CB_QItem.setSelected(false); TableMdlQItem.removeAll();
  
  // Table Revisi Stock
  clearTable();
  clearLastQuery();
  PGUI.clearText(TF_Find);
 }
 
 //
 void updateTableRevView(boolean Requery){
  TableMdlRev.updateColumnsInfo(TableRevColsName, TableRevColsType, TableRevColsShowOption, TableRevColsVisible, TableRevColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Rev, TableRevColsWidth);
  if(!Requery){onTableSelectedRowChanged(false);}else{fillTable();}
 }
 void buildTableRevColumns(){
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  int PosName=0;
  switch(CmB_ViewMode.getSelectedIndex()){
   case 0 :
    TableRevColsVisible=PCore.primArr(1, 4, 2, 5, 6, 7, 8, 9);
    TableRevColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColDate+10, CGUI.ColTextLrg, CGUI.ColTextSml, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColTextTiny, CGUI.ColCheck);
    PosName=1;
    break;
   case 1 :
    TableRevColsVisible=PCore.primArr(1, 2, 4, 5, 6, 7, 8, 9);
    TableRevColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColDate+10, CGUI.ColTextSml, CGUI.ColTextLrg, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColTextTiny, CGUI.ColCheck);
    PosName=2;
    break;
   case 2 :
    TableRevColsVisible=PCore.primArr(4, 1, 2, 5, 6, 7, 8, 9);
    TableRevColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextLrg, CGUI.ColDate+10, CGUI.ColTextSml, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColTextTiny, CGUI.ColCheck);
    PosName=0;
    break;
   case 3 :
    TableRevColsVisible=PCore.primArr(4, 2, 1, 5, 6, 7, 8, 9);
    TableRevColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextLrg, CGUI.ColTextSml, CGUI.ColDate+10, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColTextTiny, CGUI.ColCheck);
    PosName=0;
    break;
   case 4 :
    TableRevColsVisible=PCore.primArr(2, 1, 4, 5, 6, 7, 8, 9);
    TableRevColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextSml, CGUI.ColDate+10, CGUI.ColTextLrg, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColTextTiny, CGUI.ColCheck);
    PosName=2;
    break;
   case 5 :
    TableRevColsVisible=PCore.primArr(2, 4, 1, 5, 6, 7, 8, 9);
    TableRevColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextSml, CGUI.ColTextLrg, CGUI.ColDate+10, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColNum06, CGUI.ColTextTiny, CGUI.ColCheck);
    PosName=1;
    break;
  }
  if(!IsCategorized){
   TableRevColsVisible=PCore.insert(TableRevColsVisible, PosName+1, 3);
   TableRevColsWidth=PCore.insert(TableRevColsWidth, (PosName+1)+1, CGUI.ColNum13+15);
  }
  else{
   TableRevColsVisible=PCore.insert(TableRevColsVisible, PosName, 11);
   TableRevColsWidth=PCore.insert(TableRevColsWidth, PosName+1, CGUI.ColTextSml);
  }
 }
 void buildTableRevOrderBy(){
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  StringBuilder strb;
  boolean first;
  
  strb=new StringBuilder(); first=true;
  
  strb.append(" order by");
  
  /*
  if(CmB_ViewMode.getSelectedIndex()==0){
   if(first){first=false;}else{strb.append(",");}
   strb.append(" RevisiDate desc");
  }
  
  if(IsCategorized){
   if(first){first=false;}else{strb.append(",");}
   strb.append(" CategoryOfItem.Name asc");
  }
  
  if(first){first=false;}else{strb.append(",");}
  strb.append(" ItemName asc");
  
  if(CmB_ViewMode.getSelectedIndex()==1){
   if(first){first=false;}else{strb.append(",");}
   strb.append(" RevisiDate desc");
  }
  
  if(first){first=false;}else{strb.append(",");}
  strb.append(" "+QHavingTbl+".Id desc");
  */
  
  String Order_Date, Order_Reason, Order_Item;
  
  Order_Date   = " RevisiDate desc";
  Order_Reason = " ReasonOfRevisiName asc";
  Order_Item   = " ItemName asc"; if(IsCategorized){Order_Item=" CategoryName asc,"+Order_Item;}
  
  switch(CmB_ViewMode.getSelectedIndex()){
   case 0 : strb.append(Order_Date+","+Order_Item+","+Order_Reason); break;
   case 1 : strb.append(Order_Date+","+Order_Reason+","+Order_Item); break;
   case 2 : strb.append(Order_Item+","+Order_Date+","+Order_Reason); break;
   case 3 : strb.append(Order_Item+","+Order_Reason+","+Order_Date); break;
   case 4 : strb.append(Order_Reason+","+Order_Date+","+Order_Item); break;
   case 5 : strb.append(Order_Reason+","+Order_Item+","+Order_Date); break;
  }
  strb.append(", "+QHavingTbl+".Id desc");
  
  LQ_OrderBy=strb.toString();
 }
 void buildTableRevViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableRevColumns();}
  if(RebuildOrderBy){buildTableRevOrderBy();}
 }
	void changeTableRevViewByCategorized(){
		buildTableRevViewStructure(true, true);
		updateTableRevView(true);
	}
	void changeTableRevViewByOrder(){
		buildTableRevViewStructure(true, true);
		updateTableRevView(true);
	}
 
 //
 void setLastQuery(int LastQueryOperationBy, int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConDefined, String StaticPostCondition, boolean StaticPostConDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  this.LastQueryOperationBy=LastQueryOperationBy;
  
		LQ_Limit=Limit;
  
		LQ_StaticSourceTable=StaticSourceTable;
		LQ_StaticCondition=StaticCondition; LQ_StaticConditionDefined=StaticConDefined;
		LQ_StaticPostCondition=StaticPostCondition; LQ_StaticPostConditionDefined=StaticPostConDefined;
  
  LQ_DynamicTempList=DynamicTempList;
  
  LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  LastQueryDefined=true;
 }
 void clearLastQuery(){
  LastQueryDefined=false;
 }

 void onSelectedViewModeChanged(boolean UpdateAnyway){
  int CurrRow=CmB_ViewMode.getSelectedIndex();
  
  if(CurrRow==LastSelectedViewMode && !UpdateAnyway){return;}
  
  LastSelectedViewMode=CurrRow;
  
  // change table view
  changeTableRevViewByOrder();
 }
 void onTableSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_Rev.getSelectedRow();
  
  if(row==LastSelectedRow && !UpdateAnyway){return;}
  
  LastSelectedRow=row;
  
  if(LastSelectedRow==-1){clearRevInfo(); return;}
  
  fillRevInfo(LastSelectedRow);
 }
 void onEditingTableRev(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=Tbl_Rev.Editing_Row;
  Col=TableMdlRev.convertColumnIndexFromViewToModel(Tbl_Rev.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdlRev.Mdl.ColumnsType[Col], null, Tbl_Rev.Editing_ValueOld, true, null, Tbl_Rev.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableRev_Check(Row); break;}
   result=onEditingTableRev_Rev(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut revisi-stok !");}
 }
 int onEditingTableRev_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  fillTempList(PGUI.getIdsFromSelectedRows(TableMdlRev, PCore.primArr(Row), 0), PCore.objBoolean(Tbl_Rev.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingTableRev_Rev(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  // not implemented yet
  
  return ret;
 }
 
 void updateTempListQuantity(){TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));}
 void fillTempList(long[] Items, boolean IsAdd){
  long[] AffectItems;
  
  if(Items.length==0){return;}
  
  AffectItems=PCore.subArr(Items, TempList.addElements(Items, IsAdd));
  if(AffectItems.length==0){return;}
  
  updateTempListQuantity();
  fillSignItems(AffectItems, IsAdd);
 }
 void clearTempList(){
  TempList.removeAll();
  updateTempListQuantity();
  
  clearSignItems();
 }
 void updateQueryCount(){TF_QueryCount.setText(PText.intToString(TableMdlRev.getRowCount()));}
 void fillTable(){
  String Query;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  long[] tlist;
  boolean con_defined, conpost_defined;
  
  clearTable();
  
  if(!LastQueryDefined){return;}
  
  Query=null;
  do{
   // build query
   con_defined=LQ_StaticConditionDefined; conpost_defined=LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   if(LQ_DynamicTempList!=0){
    if(TempList.ElementsCount==0){if(LQ_DynamicTempList==1){break;}}
    else{
     if(!con_defined){con_defined=true; DynamicCondition.append(" where");}else{DynamicCondition.append(" and");}
     tlist=TempList.getElements();
     DynamicCondition.append(" RevisiStock.Id"+PText.getString(LQ_DynamicTempList, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
    }
   }
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   if(LQ_WithAdditionalFilter){
    if(LastResultFilterSubset!=0){
     if(LastResultFilterSubset!=LQ_DynamicTempList){
      if(LQ_DynamicTempList!=0){break;}
      if(TempList.ElementsCount==0){if(LastResultFilterSubset==1){break;}}
      else{
       if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
       tlist=TempList.getElements();
       AdditionalCondition.append(" RevisiStock.Id"+PText.getString(LastResultFilterSubset, 1, 2, " in", " not in", null)+
        "("+PText.toString(tlist, 0, tlist.length, ",")+")");
      }
     }
    }
   }
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
    // finally, build query
   Query=
    "select tb5.*, Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb4.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
      "(select tb3.Id, RevisiDate, ReasonOfRevisiName, Item, ItemName, StockOld, StockNew, Different, StockUnit.Name as 'StockUnitName', UpdateStockOnTransaction from "+
       "(select tb2.*, Item.Name as 'ItemName', Item.StockUnit, Item.UpdateStockOnTransaction from "+
        "(select tb1.*, ReasonOfRevisi.Name as 'ReasonOfRevisiName' from "+
         "(select RevisiStock.*, (StockNew-StockOld) as 'Different' "+
         "from RevisiStock"+LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
          LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+
          PText.getString(LQ_Limit, 0, " limit "+LQ_Limit, "")+") as tb1 "+
        "left join ReasonOfRevisi on tb1.ReasonOfRevisi=ReasonOfRevisi.Id) as tb2 "+
       "left join Item on tb2.Item=Item.Id) as tb3 "+
      "left join StockUnit on tb3.StockUnit=StockUnit.Id) as tb4 "+
     "left join ItemXPicture on tb4.Item=ItemXPicture.Item group by tb4.Id) as tb5 "+
    "left join ItemXCategory on tb5.Item=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb5.Id"+
				LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+LQ_OrderBy;
  }while(false);
  
  if(Query==null){return;}
  if(PDatabase.queryToTable(IFV.Stm, Query, TableMdlRev, false, true, TempList, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil data dari database !");
  }
  updateQueryCount();
  updateQueryTempListCount();
 }
 void clearTable(){
  TableMdlRev.removeAll();
  onTableSelectedRowChanged(true);
  
  updateQueryCount();
  updateQueryTempListCount();
 }
 void updateQueryTempListCount(){TF_QueryTempListCount.setText("( "+PText.intToString(TableMdlRev.getCheckedCount())+" )");}
 void fillSignItems(long[] Items, boolean SignValue){
  TableMdlRev.check(Items, SignValue, 0);
  updateQueryTempListCount();
 }
 void clearSignItems(){
  TableMdlRev.checkAll(false);
  updateQueryTempListCount();
 }
 void fillRevInfo(int Row){
  Object[] Objs=TableMdlRev.Mdl.Rows.elementAt(Row);
  TA_ItemInfoCategory.setText(PCore.objString(Objs[11], ""));
  TA_ItemInfoName.setText("( "+PText.separate(Objs[3].toString(), " - ", 5)+" ) "+Objs[4].toString());
  PGUI.fillPanelPictureURL(Pnl_ItemPreview, IFV.Conf.ImageDirItem, Objs[10]);
 }
 void clearRevInfo(){
  TA_ItemInfoCategory.setText("");
  TA_ItemInfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_ItemPreview, IFV.Conf.ImageDirItem, null);
 }
 
 void runQuery(){
  boolean input_valid, confirst, list_defined, bool1;
  String str1=null;
  String str2=null;
  String str3=null;
  String tb1=null;
  String tb2=null;
  Date dt1=null;
  Date dt2=null;
  Double dbl1, dbl2;
  boolean isempty1, isempty2;
  int temp;
  
  StringBuilder StcSourceTable;
  StringBuilder StcCondition;
  StringBuilder StcPostConditions;
  
  boolean query_defined;
  VBoolean stc_con_defined;
  VBoolean stc_conpost_defined;
  
  int WithTempList;
  
  // validating input
  input_valid=false;
  do{
   if(CB_QRevDate.isSelected()){
    dt1=PGUI.valueOfDateComponent(TF_QRevDateStartY, CmB_QRevDateStartM, CmB_QRevDateStartD);
    dt2=PGUI.valueOfDateComponent(TF_QRevDateEndY, CmB_QRevDateEndM, CmB_QRevDateEndD);
    if(dt1==null && dt2==null){break;}
   }
   if(CB_QItemId.isSelected()){
    if(!PText.checkInput(TF_QItemId.getText(), false, CCore.CharsCount_Long(), 2, 0, 0, 0)){break;}
   }
   if(CB_QItemName.isSelected()){
    if(!PText.checkInput(TF_QItemName.getText(), false, 150, 0, 0, 0, 0)){break;}
   }
   if(CB_QStockOld.isSelected()){
    str1=TF_QStockOld1.getText(); str2=TF_QStockOld2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QStockNew.isSelected()){
    str1=TF_QStockNew1.getText(); str2=TF_QStockNew2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QDifferent.isSelected()){
    str1=TF_QDifferent1.getText(); str2=TF_QDifferent2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QItem.isSelected()){
    if(TableMdlQItem.Mdl.Rows.size()==0){break;}
   }
   input_valid=true;
  }while(false);
  if(!input_valid){
   JOptionPane.showMessageDialog(null, "Tidak dapat mencari : masukan masih salah / belum lengkap !");
   return;
  }
  
  // build query
  query_defined=true;
  stc_con_defined=new VBoolean(false);
  stc_conpost_defined=new VBoolean(false);
  
  StcSourceTable=new StringBuilder();
  StcCondition=new StringBuilder();
  StcPostConditions=new StringBuilder();
  
  WithTempList=0;
  
  if(CB_QRevDate.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   str1="RevisiStock.RevisiDate";
   dt1=PGUI.valueOfDateComponent(TF_QRevDateStartY, CmB_QRevDateStartM, CmB_QRevDateStartD);
   dt2=PGUI.valueOfDateComponent(TF_QRevDateEndY, CmB_QRevDateEndM, CmB_QRevDateEndD);
   
   StcCondition.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+">="+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false));
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+"<="+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true));
   }
   StcCondition.append(")");
  }

  if(CB_QItemId.isSelected()){
   bool1=CmB_QItemId.getSelectedIndex()==0;
   
   tb1=
    "select RevisiStock.Id as 'RevId' from "+
     "("+
      PMyShop.getQueryOfFindItemIds(
       PText.getString(bool1, String.valueOf(Long.parseLong(TF_QItemId.getText())), TF_QItemId.getText()), !bool1, "Item.Id", null, true, null, false)+
     ") as tb1 "+
    "inner join RevisiStock on tb1.Id=RevisiStock.Item";
   
   StcSourceTable.append(", ("+tb1+") as rev_itemids");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RevisiStock.Id=rev_itemids.RevId");
  }

  if(CB_QItemName.isSelected()){
   tb1=
    "select RevisiStock.Id as 'RevId' from "+
     "("+
      "(select Id as 'ItemId' from Item where "+PSql.genCheckWord("Name", TF_QItemName.getText(), true, true)+") "+
      "union distinct "+
      "(select Item from ItemXVariant where "+PSql.genCheckWord("Variant", TF_QItemName.getText(), true, true)+" group by Item) "+
     ") as tb1 "+
    "inner join RevisiStock on tb1.ItemId=RevisiStock.Item";
   
   StcSourceTable.append(", ("+tb1+") as rev_itemname");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RevisiStock.Id=rev_itemname.RevId");
  }
  
  if(CB_QStockOld.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   str1="RevisiStock.StockOld";
   dbl1=PText.parseDouble(TF_QStockOld1.getText(), null, null); dbl2=PText.parseDouble(TF_QStockOld2.getText(), null, null);
   StcCondition.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCondition.append(")");
  }
  
  if(CB_QStockNew.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   str1="RevisiStock.StockNew";
   dbl1=PText.parseDouble(TF_QStockNew1.getText(), null, null); dbl2=PText.parseDouble(TF_QStockNew2.getText(), null, null);
   StcCondition.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCondition.append(")");
  }
  
  if(CB_QDifferent.isSelected()){
   if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
   str1="Different";
   dbl1=PText.parseDouble(TF_QDifferent1.getText(), null, null); dbl2=PText.parseDouble(TF_QDifferent2.getText(), null, null);
   StcPostConditions.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcPostConditions.append(" and");}
    StcPostConditions.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcPostConditions.append(" and");}
    StcPostConditions.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcPostConditions.append(")");
  }

  if(CB_QCheck.isSelected()){
   temp=CmB_QCheck.getSelectedIndex();
   do{
    if(temp==0){str2="1 Month"; str3=">="; break;}
    if(temp==1){str2="3 Month"; str3=">="; break;}
    if(temp==2){str2="6 Month"; str3=">="; break;}
    if(temp==3){str2="1 Year"; str3=">="; break;}
    if(temp==4){str2="18 Month"; str3=">="; break;}
    if(temp==5){str2="2 Year"; str3=">="; break;}
    if(temp==6){str2="30 Month"; str3=">="; break;}
    if(temp==7){str2="3 Year"; str3=">="; break;}
    if(temp==8){str2="4 Year"; str3=">="; break;}
    if(temp==9){str2="5 Year"; str3=">="; break;}
    if(temp==10){str2="1 Month"; str3="<"; break;}
    if(temp==11){str2="3 Month"; str3="<"; break;}
    if(temp==12){str2="6 Month"; str3="<"; break;}
    if(temp==13){str2="1 Year"; str3="<"; break;}
    if(temp==14){str2="18 Month"; str3="<"; break;}
    if(temp==15){str2="2 Year"; str3="<"; break;}
    if(temp==16){str2="30 Month"; str3="<"; break;}
    if(temp==17){str2="3 Year"; str3="<"; break;}
    if(temp==18){str2="4 Year"; str3="<"; break;}
    if(temp==19){str2="5 Year"; str3="<"; break;}
   }while(false);
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   str1="RevisiStock.RevisiDate";
   StcCondition.append(" "+str1+str3+"Date_Sub(CurDate(), Interval "+str2+")");
  }
  
  if(CB_QReasonOfRevisi.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" (");
   list_defined=false;
   if(ListMdlQReasonOfRevisi.Mdl.Rows.size()!=0){
    StcCondition.append(" RevisiStock.ReasonOfRevisi in ("+PGUI.getElementList(ListMdlQReasonOfRevisi.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QReasonOfRevisiEmpty.isSelected()){
    if(list_defined){StcCondition.append(" or");} StcCondition.append(" RevisiStock.ReasonOfRevisi is "+CCore.vNull);
   }
   StcCondition.append(")");
  }
  
  if(CB_QItem.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" RevisiStock.Item in ("+PGUI.getElementList(TableMdlQItem.Mdl.Rows, 0, ",", "", false)+")");
  }
  
  if(query_defined){
   setLastQuery(1, CApp.FormQueryLimit,
    StcSourceTable.toString(), StcCondition.toString(), stc_con_defined.Value, StcPostConditions.toString(), stc_conpost_defined.Value,
    WithTempList, true);
  }
  else{
   clearLastQuery();
  }
  fillTable();
 }
 void findInTable(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str;
  
  str=TF_Find.getText();
  if(str.length()==0){return;}

  if(TableMdlRev.Mdl.Rows.size()==0){
   JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !");
   return;
  }
  
  switch(CmB_Find.getSelectedIndex()){
   case 0 : Column=3; break;
   case 1 : Column=4; break;
   case 2 : Column=11; break;
   case 3 : Column=2; break;
   default : Column=3; break;
  }
  ColumnType=TableMdlRev.Mdl.ColumnsType[Column];
  Selected=Tbl_Rev.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlRev, Column, ColumnType, str, Selected, Mode);
  if(FindIndex==-1){
   JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !");
   return;
  }
  
  if(Selected!=FindIndex){
   Tbl_Rev.changeSelection(FindIndex, 0, false, false);
   onTableSelectedRowChanged(false);
  }
 }
 void printReport(){
  long[] Id;
  Book bk;
  OPaper PaperType;
  PrintService Printer;
		F_PrintRevStock fm=IFV.FPrintRevStock;
  
  if(TableMdlRev.Mdl.Rows.size()==0){return;}

  fm.wOrderMode=CmB_ViewMode.getSelectedIndex();
  fm.wItemCategorized=PCore.subtBool_Int(CB_ViewCategorized.isSelected(), 1, 2);
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}

  IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
  IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
  IFV.FPrintDialog.wPrintSettingMode=2;
  IFV.FPrintDialog.wEnableOption=false;

  if(IFV.FPrintDialog.showForm()==false){return;}
  if(IFV.FPrintDialog.DialogResult!=1){return;}
  PaperType=IFV.FPrintDialog.PaperType;
  Printer=IFV.FPrintDialog.Printer;

  Id=TableMdlRev.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableMdlRev.Mdl.Rows.size(), 0, 1));

  IFV.PrintGenRevStock.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Id, fm.OrderMode, fm.ItemCategorized);
  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  bk=IFV.PrintGenRevStock.generateBook(IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  if(bk==null){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
   return;
  }

  if(IFV.FPrintDialog.ChoosePage){
   IFV.FPrintPage.wBook=bk;

   if(IFV.FPrintPage.showForm()==false){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
  }

  if(!PPrint.print(bk, Printer, "LapRevisiStok_"+PText.dateToString(new Date(), 101), false)){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
   return;
  }
 }
 void printCSV(){
  F_PrintRevStock fm1=IFV.FPrintRevStock;
  F_CsvWriteOption fm2=IFV.FCsvWriteOption;
  File f;
  long OperationResult;
  long[] Ids;
  
  if(TableMdlRev.Mdl.Rows.size()==0){return;}
  
  fm1.wOrderMode=CmB_ViewMode.getSelectedIndex();
  fm1.wItemCategorized=PCore.subtBool_Int(CB_ViewCategorized.isSelected(), 1, 2);
  if(fm1.showForm()==false){return;}
  if(fm1.DialogResult!=1){return;}
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm2.showForm()==false){return;}
  if(fm2.DialogResult!=1){return;}
  
  Ids=TableMdlRev.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableMdlRev.Mdl.Rows.size(), 0, 1));
  
  IFV.FSplashScreen.appear(this, "Print Data Ke File CSV");
  OperationResult=PMyShop.printRevStockCSV(
   IFV.FSplashScreen, IFV.Stm, f, fm2.FieldDelimiter, fm2.FieldsSeparator, CCore.CsvDefaultRecordsSeparator, Ids,
   fm1.OrderMode, fm1.ItemCategorized);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses print data ke file CSV !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Operasi berhasil !\n"+
   "Total data yg di-print ke file CSV = "+PText.intToString(OperationResult));
  */
 }
 int editRevStock(int[] Rows, boolean FetchDataOld, OInfoRevStock DataOld, OEditRevStock Edit, boolean WithSplashScreen){
  int ret=-1; // 0 success, -1 unknown error
  long Id=0;
  OInfoRevStock InfoRevStock=null;
  boolean first, error, started;
  Object[] RowData;
  StringBuilder col;
  int Row, count, MaxList, curridx, currlistcount;
  String columns;
  Vector<OTableCellUpdater> Values, PostValues;
  
  long[] ids;
  boolean op_query;
  double progress_inc=0;
  int progress_inc_times;
  boolean IsCheckWithOldValue;
  
  do{
   count=Rows.length;
   op_query=false;

   if(count==1){
    RowData=TableMdlRev.Mdl.Rows.elementAt(Rows[0]);
    Id=(Long)RowData[0];
    InfoRevStock=DataOld; if(InfoRevStock==null && FetchDataOld){InfoRevStock=PMyShop.getRevStockInfo(IFV.Stm, Id);}
   }
   IsCheckWithOldValue=(count==1 && InfoRevStock!=null);

   Values=new Vector(); PostValues=new Vector();
   col=new StringBuilder();
   first=true;
   
   if(Edit.EditRevDate){
    if(first){first=false;}else{col.append(',');}
    col.append("RevisiDate="+PDatabase.dateToSQLStringFormat(Edit.EditedRevDate));
    Values.addElement(new OTableCellUpdaterByObject(1, Edit.EditedRevDate));
    op_query=true;
   }
   
   if(Edit.EditReasonOfRevisi){
    if(first){first=false;}else{col.append(',');}
    col.append("ReasonOfRevisi="+PText.getString(Edit.EditedReasonOfRevisiId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(2, PText.getString(Edit.EditedReasonOfRevisiId, -1, Edit.EditedReasonOfRevisiName, null)));
    op_query=true;
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)

   // update
   if(WithSplashScreen){IFV.FSplashScreen.appear(this, "Mengubah Data Revisi Stok");}
   
   if(WithSplashScreen){IFV.FSplashScreen.inform(0, "Mengubah "+PText.intToString(count)+" data revisi stok, harap menunggu ...", null);}
   
   error=false;
   MaxList=1000;
   do{
    if(WithSplashScreen){
     IFV.FSplashScreen.setProgressIncreasePercentage(75);
     progress_inc_times=PMath.round((double)count/(double)MaxList, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    columns=col.toString();
    
    curridx=0;
    started=false;
    do{
     try{
      IFV.Stm.executeUpdate("start transaction;");
      started=true;

      do{
       currlistcount=MaxList;
       if(curridx+currlistcount>count){currlistcount=count-curridx;}
       ids=TableMdlRev.getIds(0, PCore.subArr(Rows, curridx, currlistcount));

       if(op_query){
        IFV.Stm.executeUpdate("update RevisiStock set "+columns+" where Id in("+PText.toString(ids, 0, ids.length, ",")+");");
       }
       
       if(WithSplashScreen){IFV.FSplashScreen.inform(progress_inc, null, null);}

       curridx=curridx+currlistcount;
      }while(curridx!=count);
      if(error){break;}

      IFV.Stm.executeUpdate("commit;");
     }
     catch(Exception E){error=true; break;}
    }while(false);
    if(error){
     if(started){try{IFV.Stm.executeUpdate("rollback;");}catch(Exception E){}}
     break;
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(100);}

    // post-update

     // update table
    PGUI.changeElements(TableMdlRev, Rows, Values);
    PGUI.changeElements(TableMdlRev, Rows, PostValues);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(20, null, null);}

     // update detail
    
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(5, null, null);}
   }while(false);
   if(WithSplashScreen){IFV.FSplashScreen.disappear();}
   
   if(error){break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 void editSingle(int Row){
  long Id;
  OInfoRevStock InfoRevStock=null;
  Object[] RowData;
  F_RevStockModify fm=IFV.FRevStockModify;
  OEditRevStock Edit;
  int result;
  
  RowData=TableMdlRev.Mdl.Rows.elementAt(Row);
  Id=(Long)RowData[0];
  InfoRevStock=PMyShop.getRevStockInfo(IFV.Stm, Id);
  if(InfoRevStock==null){
   JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : terjadi kesalahan ketika mengambil data dari database !");
   return;
  }
  fm.wMode=2;
  fm.wInfoRevStock=InfoRevStock;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}

  Edit=new OEditRevStock();
  Edit.init(
   true, fm.RevDate,
   true, fm.ReasonOfRevisiId, fm.ReasonOfRevisiName);

  result=editRevStock(PCore.primArr(Row), false, InfoRevStock, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
  else if(result==-2){}
 }
 void editMultiple(int[] Rows){
  int count=Rows.length;
  F_RevStockModifyMulti fm=IFV.FRevStockModifyMulti;
  OEditRevStock Edit;
  int result;
  
  fm.wDataCount=count;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  Edit=new OEditRevStock();
  Edit.init(
   fm.ChangeRevDate, fm.RevDate,
   fm.ChangeReasonOfRevisi, fm.ReasonOfRevisiId, fm.ReasonOfRevisiName);

  result=editRevStock(Rows, false, null, Edit, true);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
  else if(result==-2){}
 }
 
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF.getCaretPosition()==QTF.getDocument().getLength()){
     focusQueryResult();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange1(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF1.getCaretPosition()==QTF1.getDocument().getLength()){
     QTF2.requestFocusInWindow();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange2(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_LEFT:
    if(QTF2.getCaretPosition()==0){
     QTF1.requestFocusInWindow();
    }
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF2.getCaretPosition()==QTF2.getDocument().getLength()){
     focusQueryResult();
    }
    break;
  }
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }
 
 //
 void focusQueryResult(){
  if(!TableMdlRev.Mdl.Rows.isEmpty()){
   if(Tbl_Rev.getSelectedRow()==-1){Tbl_Rev.changeSelection(0, 0, false, false); onTableSelectedRowChanged(false);}
   Tbl_Rev.requestFocusInWindow();
  }
 }
 void focusQuery(){
  if(LastFocusedCmpSearch==null){LastFocusedCmpSearch=TF_QItemName;}
  LastFocusedCmpSearch.requestFocusInWindow();
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jPanel1 = new javax.swing.JPanel();
  jLabel1 = new javax.swing.JLabel();
  CB_QRevDate = new javax.swing.JCheckBox();
  CB_QStockOld = new javax.swing.JCheckBox();
  CB_QStockNew = new javax.swing.JCheckBox();
  CB_QDifferent = new javax.swing.JCheckBox();
  CB_QItem = new javax.swing.JCheckBox();
  CmB_QRevDateStartM = new javax.swing.JComboBox<>();
  CmB_QRevDateStartD = new javax.swing.JComboBox<>();
  TF_QRevDateStartY = new javax.swing.JTextField();
  jLabel2 = new javax.swing.JLabel();
  TF_QRevDateEndY = new javax.swing.JTextField();
  CmB_QRevDateEndM = new javax.swing.JComboBox<>();
  CmB_QRevDateEndD = new javax.swing.JComboBox<>();
  TF_QStockOld1 = new javax.swing.JTextField();
  jLabel3 = new javax.swing.JLabel();
  TF_QStockOld2 = new javax.swing.JTextField();
  TF_QStockNew1 = new javax.swing.JTextField();
  jLabel4 = new javax.swing.JLabel();
  TF_QStockNew2 = new javax.swing.JTextField();
  TF_QDifferent1 = new javax.swing.JTextField();
  jLabel5 = new javax.swing.JLabel();
  TF_QDifferent2 = new javax.swing.JTextField();
  Btn_QItemAdd = new javax.swing.JButton();
  Btn_QItemRemove = new javax.swing.JButton();
  CmB_QCheck = new javax.swing.JComboBox<>();
  CB_QCheck = new javax.swing.JCheckBox();
  CB_QReasonOfRevisi = new javax.swing.JCheckBox();
  CB_QReasonOfRevisiEmpty = new javax.swing.JCheckBox();
  Btn_QReasonOfRevisiAdd = new javax.swing.JButton();
  Btn_QReasonOfRevisiRemove = new javax.swing.JButton();
  Btn_Query = new javax.swing.JButton();
  TF_QItemId = new javax.swing.JTextField();
  TF_QItemName = new javax.swing.JTextField();
  CB_QItemId = new javax.swing.JCheckBox();
  CB_QItemName = new javax.swing.JCheckBox();
  CmB_QItemId = new javax.swing.JComboBox<>();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_QItem = new XTable();
  jScrollPane6 = new javax.swing.JScrollPane();
  List_QReasonOfRevisi = new XList();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  Btn_TempListClear = new javax.swing.JButton();
  TF_QueryCount = new javax.swing.JTextField();
  TF_QueryTempListCount = new javax.swing.JTextField();
  Btn_QueryRefresh = new javax.swing.JButton();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel7 = new javax.swing.JLabel();
  CmB_ResultFilterSubset = new javax.swing.JComboBox<>();
  jPanel4 = new javax.swing.JPanel();
  CmB_Find = new javax.swing.JComboBox<>();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBefore = new javax.swing.JButton();
  TF_Find = new javax.swing.JTextField();
  CmB_ViewMode = new javax.swing.JComboBox<>();
  jLabel8 = new javax.swing.JLabel();
  CB_ViewCategorized = new javax.swing.JToggleButton();
  Pnl_ItemPreview = new XImgBoxURL();
  jPanel5 = new javax.swing.JPanel();
  Btn_Edit = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  Btn_Report = new javax.swing.JButton();
  Btn_ItemTempListRemove = new javax.swing.JButton();
  Btn_ItemTempListAdd = new javax.swing.JButton();
  jLabel6 = new javax.swing.JLabel();
  Btn_New = new javax.swing.JButton();
  CmB_ReportType = new javax.swing.JComboBox<>();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_ItemInfoName = new javax.swing.JTextArea();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_ItemInfoCategory = new javax.swing.JTextArea();
  jScrollPane5 = new javax.swing.JScrollPane();
  Tbl_Rev = new XTable();

  setTitle("Revisi Stok");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("-- Filter (kosongkan smua utk cari smua)");

  CB_QRevDate.setText("Tgl Revisi");
  CB_QRevDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QRevDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QRevDateKeyPressed(evt);
   }
  });

  CB_QStockOld.setText("Stok Lama");
  CB_QStockOld.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QStockOld.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QStockOldKeyPressed(evt);
   }
  });

  CB_QStockNew.setText("Stok Baru");
  CB_QStockNew.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QStockNew.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QStockNewKeyPressed(evt);
   }
  });

  CB_QDifferent.setText("Selisih");
  CB_QDifferent.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QDifferent.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QDifferentKeyPressed(evt);
   }
  });

  CB_QItem.setText("Barang");
  CB_QItem.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemKeyPressed(evt);
   }
  });

  CmB_QRevDateStartM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QRevDateStartM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRevDateStartMKeyPressed(evt);
   }
  });

  CmB_QRevDateStartD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QRevDateStartD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRevDateStartDKeyPressed(evt);
   }
  });

  TF_QRevDateStartY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QRevDateStartYFocusGained(evt);
   }
  });
  TF_QRevDateStartY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QRevDateStartYKeyPressed(evt);
   }
  });

  jLabel2.setText("-");

  TF_QRevDateEndY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QRevDateEndYFocusGained(evt);
   }
  });
  TF_QRevDateEndY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QRevDateEndYKeyPressed(evt);
   }
  });

  CmB_QRevDateEndM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QRevDateEndM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRevDateEndMKeyPressed(evt);
   }
  });

  CmB_QRevDateEndD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QRevDateEndD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRevDateEndDKeyPressed(evt);
   }
  });

  TF_QStockOld1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QStockOld1FocusGained(evt);
   }
  });
  TF_QStockOld1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QStockOld1KeyPressed(evt);
   }
  });

  jLabel3.setText("-");

  TF_QStockOld2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QStockOld2FocusGained(evt);
   }
  });
  TF_QStockOld2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QStockOld2KeyPressed(evt);
   }
  });

  TF_QStockNew1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QStockNew1FocusGained(evt);
   }
  });
  TF_QStockNew1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QStockNew1KeyPressed(evt);
   }
  });

  jLabel4.setText("-");

  TF_QStockNew2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QStockNew2FocusGained(evt);
   }
  });
  TF_QStockNew2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QStockNew2KeyPressed(evt);
   }
  });

  TF_QDifferent1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QDifferent1FocusGained(evt);
   }
  });
  TF_QDifferent1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QDifferent1KeyPressed(evt);
   }
  });

  jLabel5.setText("-");

  TF_QDifferent2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QDifferent2FocusGained(evt);
   }
  });
  TF_QDifferent2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QDifferent2KeyPressed(evt);
   }
  });

  Btn_QItemAdd.setText("+");
  Btn_QItemAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemAddActionPerformed(evt);
   }
  });
  Btn_QItemAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemAddKeyPressed(evt);
   }
  });

  Btn_QItemRemove.setText("-");
  Btn_QItemRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_QItemRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemRemoveActionPerformed(evt);
   }
  });
  Btn_QItemRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemRemoveKeyPressed(evt);
   }
  });

  CmB_QCheck.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 Bulan Terakhir", "3 Bulan Terakhir", "6 Bulan Terakhir", "1 Tahun Terakhir", "1.5 Tahun Terakhir", "2 Tahun Terakhir", "2.5 Tahun Terakhir", "3 Tahun Terakhir", "4 Tahun Terakhir", "5 Tahun Terakhir", "> 1 Bulan Terakhir", "> 3 Bulan Terakhir", "> 6 Bulan Terakhir", "> 1 Tahun Terakhir", "> 1.5 Tahun Terakhir", "> 2 Tahun Terakhir", "> 2.5 Tahun Terakhir", "> 3 Tahun Terakhir", "> 4 Tahun Terakhir", "> 5 Tahun Terakhir" }));
  CmB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCheckKeyPressed(evt);
   }
  });

  CB_QCheck.setText("Cek");
  CB_QCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCheckKeyPressed(evt);
   }
  });

  CB_QReasonOfRevisi.setText("Alasan");
  CB_QReasonOfRevisi.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QReasonOfRevisi.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QReasonOfRevisiKeyPressed(evt);
   }
  });

  CB_QReasonOfRevisiEmpty.setText("ksg");
  CB_QReasonOfRevisiEmpty.setToolTipText("centang opsi ini utk mengikutsertakan revisi dgn alasan yg tdk didefenisikan");
  CB_QReasonOfRevisiEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QReasonOfRevisiEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QReasonOfRevisiEmptyKeyPressed(evt);
   }
  });

  Btn_QReasonOfRevisiAdd.setText("+");
  Btn_QReasonOfRevisiAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QReasonOfRevisiAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QReasonOfRevisiAddActionPerformed(evt);
   }
  });
  Btn_QReasonOfRevisiAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QReasonOfRevisiAddKeyPressed(evt);
   }
  });

  Btn_QReasonOfRevisiRemove.setText("-");
  Btn_QReasonOfRevisiRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QReasonOfRevisiRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QReasonOfRevisiRemoveActionPerformed(evt);
   }
  });
  Btn_QReasonOfRevisiRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QReasonOfRevisiRemoveKeyPressed(evt);
   }
  });

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setToolTipText("");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });
  Btn_Query.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QueryKeyPressed(evt);
   }
  });

  TF_QItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemIdFocusGained(evt);
   }
  });
  TF_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemIdKeyPressed(evt);
   }
  });

  TF_QItemName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemNameFocusGained(evt);
   }
  });
  TF_QItemName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemNameKeyPressed(evt);
   }
  });

  CB_QItemId.setIconTextGap(0);
  CB_QItemId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemIdKeyPressed(evt);
   }
  });

  CB_QItemName.setText("Nama Brg");
  CB_QItemName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemNameKeyPressed(evt);
   }
  });

  CmB_QItemId.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Sub-Id" }));
  CmB_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QItemIdKeyPressed(evt);
   }
  });

  Tbl_QItem.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_QItem.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_QItem.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_QItem.setRowHeight(18);
  Tbl_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_QItemKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_QItem);

  List_QReasonOfRevisi.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QReasonOfRevisiKeyReleased(evt);
   }
  });
  jScrollPane6.setViewportView(List_QReasonOfRevisi);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel1)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QRevDate)
     .addComponent(CB_QStockOld)
     .addComponent(CB_QStockNew)
     .addComponent(CB_QDifferent)
     .addComponent(CB_QItem)
     .addComponent(CB_QCheck)
     .addComponent(CB_QReasonOfRevisi)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addComponent(CB_QReasonOfRevisiEmpty))
     .addComponent(CB_QItemName)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(CB_QItemId)
      .addGap(0, 0, 0)
      .addComponent(CmB_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_QItemName)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_QRevDateStartY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRevDateStartM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRevDateStartD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel2)
      .addGap(2, 2, 2)
      .addComponent(TF_QRevDateEndY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRevDateEndM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRevDateEndD, 0, 80, Short.MAX_VALUE))
     .addComponent(CmB_QCheck, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
       .addComponent(TF_QStockOld1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
       .addComponent(TF_QStockNew1, javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_QDifferent1, javax.swing.GroupLayout.Alignment.LEADING))
      .addGap(2, 2, 2)
      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jLabel4)
       .addComponent(jLabel3)
       .addComponent(jLabel5))
      .addGap(2, 2, 2)
      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_QDifferent2)
       .addComponent(TF_QStockOld2)
       .addComponent(TF_QStockNew2)))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
      .addComponent(jScrollPane6)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QReasonOfRevisiAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QReasonOfRevisiRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QItemAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QItemRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addComponent(TF_QItemId)))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel1)
     .addComponent(Btn_Query))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_QCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QCheck))
    .addGap(8, 8, 8)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QRevDate)
     .addComponent(CmB_QRevDateStartM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRevDateStartD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_QRevDateStartY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2)
     .addComponent(TF_QRevDateEndY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRevDateEndM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRevDateEndD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(CB_QItemId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QItemName))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QStockOld)
     .addComponent(TF_QStockOld1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel3)
     .addComponent(TF_QStockOld2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QStockNew)
     .addComponent(TF_QStockNew1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel4)
     .addComponent(TF_QStockNew2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QDifferent)
     .addComponent(TF_QDifferent1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel5)
     .addComponent(TF_QDifferent2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(CB_QReasonOfRevisi)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QReasonOfRevisiEmpty))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(Btn_QReasonOfRevisiAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QReasonOfRevisiRemove))
     .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_QItem)
       .addComponent(Btn_QItemAdd))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QItemRemove))
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE)))
  );

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  TF_QueryCount.setEditable(false);
  TF_QueryCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_QueryTempListCount.setEditable(false);
  TF_QueryTempListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryTempListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_QueryRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_QueryRefresh.setText("R");
  Btn_QueryRefresh.setToolTipText("klik 'R' untuk menyegarkan daftar revisi stok dlm tabel");
  Btn_QueryRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_QueryRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryRefreshActionPerformed(evt);
   }
  });

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi revisi2 yg dipilih dari 'DaftarKu'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan revisi2 yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu' (klik kiri - lihat DaftarKu ; klik kanan - lihat ~DaftarKu)");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TempListQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TempListQuantityMouseClicked(evt);
   }
  });

  jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel7.setText("*DaftarKu");

  CmB_ResultFilterSubset.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "*Semua", "*DaftarKu", "*~DftarKu" }));
  CmB_ResultFilterSubset.setToolTipText("Filter \"DaftarKu\"");
  CmB_ResultFilterSubset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterSubsetActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_QueryRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel7)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListSave)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListLoad)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListClear))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TempListClear)
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_QueryRefresh)
    .addComponent(Btn_TempListLoad)
    .addComponent(Btn_TempListSave)
    .addComponent(Btn_TempListRemove)
    .addComponent(Btn_TempListAdd)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel7)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CmB_Find.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nama Brg", "Kategori", "Alasan" }));

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_FindBefore.setText("<");
  Btn_FindBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBeforeActionPerformed(evt);
   }
  });

  TF_Find.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  CmB_ViewMode.setBackground(new java.awt.Color(204, 204, 0));
  CmB_ViewMode.setForeground(new java.awt.Color(102, 102, 0));
  CmB_ViewMode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tgl - Brg - Alasan", "Tgl - Alasan - Brg", "Brg - Tgl - Alasan", "Brg - Alasan - Tgl", "Alasan - Tgl - Brg", "Alasan - Brg - Tgl" }));
  CmB_ViewMode.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ViewModeActionPerformed(evt);
   }
  });

  jLabel8.setText("Urut Berdasarkan");

  CB_ViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCategorized.setText("K");
  CB_ViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCategorized.setIconTextGap(0);
  CB_ViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Find, javax.swing.GroupLayout.DEFAULT_SIZE, 447, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindBefore)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel8)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ViewMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCategorized))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_FindBefore)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ViewMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel8)
    .addComponent(CB_ViewCategorized))
  );

  Pnl_ItemPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemPreviewMouseClicked(evt);
   }
  });

  Btn_Edit.setText("Ubah {F2}");
  Btn_Edit.setToolTipText("");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Remove.setText("Hapus {F3}");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  Btn_Report.setText("Cetak");
  Btn_Report.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Report.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReportActionPerformed(evt);
   }
  });

  Btn_ItemTempListRemove.setText("-");
  Btn_ItemTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_ItemTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemTempListRemoveActionPerformed(evt);
   }
  });

  Btn_ItemTempListAdd.setText("+");
  Btn_ItemTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_ItemTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemTempListAddActionPerformed(evt);
   }
  });

  jLabel6.setText("*");

  Btn_New.setText("Tambah {F1}");
  Btn_New.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_New.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_NewActionPerformed(evt);
   }
  });

  CmB_ReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laporan", "File CSV" }));

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(Btn_New)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Edit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Remove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Report)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel6)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemTempListRemove))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Remove)
    .addComponent(Btn_Report)
    .addComponent(Btn_ItemTempListRemove)
    .addComponent(Btn_ItemTempListAdd)
    .addComponent(jLabel6)
    .addComponent(Btn_New)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TA_ItemInfoName.setEditable(false);
  TA_ItemInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInfoName.setColumns(20);
  TA_ItemInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInfoName.setLineWrap(true);
  TA_ItemInfoName.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_ItemInfoName);

  TA_ItemInfoCategory.setEditable(false);
  TA_ItemInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInfoCategory.setColumns(20);
  TA_ItemInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInfoCategory.setLineWrap(true);
  TA_ItemInfoCategory.setWrapStyleWord(true);
  jScrollPane4.setViewportView(TA_ItemInfoCategory);

  Tbl_Rev.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Rev.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  Tbl_Rev.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Rev.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Rev.setRowHeight(18);
  Tbl_Rev.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_RevMouseReleased(evt);
   }
  });
  Tbl_Rev.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_RevKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(Tbl_Rev);

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(Pnl_ItemPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane4)
     .addComponent(jScrollPane3)))
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane5)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5)
    .addGap(0, 0, 0)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel2Layout.createSequentialGroup()
      .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane3))
     .addComponent(Pnl_ItemPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  runQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void Btn_QItemAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemAddActionPerformed
  Object[] NewRow;
  int count, temp;
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=true;
  IFV.FItem.wAllowMultipleSelection=true;
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  count=IFV.FItem.ChoosedId.length;
  temp=0;
  do{
   NewRow=new Object[2];
   NewRow[0]=IFV.FItem.ChoosedId[temp];
   NewRow[1]=IFV.FItem.ChoosedName[temp];
   TableMdlQItem.append(NewRow);
   temp=temp+1;
  }while(temp!=count);
 }//GEN-LAST:event_Btn_QItemAddActionPerformed

 private void Btn_QItemRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveActionPerformed
  TableMdlQItem.remove(Tbl_QItem.getSelectedRows());
 }//GEN-LAST:event_Btn_QItemRemoveActionPerformed

 private void CmB_ResultFilterSubsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterSubsetActionPerformed
  int temp=CmB_ResultFilterSubset.getSelectedIndex();
  if(LastResultFilterSubset==temp){return;}
  LastResultFilterSubset=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterSubsetActionPerformed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(TableMdlRev, Tbl_Rev.getSelectedRows(), 0), true);
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_QueryRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryRefreshActionPerformed
  fillTable();
 }//GEN-LAST:event_Btn_QueryRefreshActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(TableMdlRev, Tbl_Rev.getSelectedRows(), 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  File f;
  String fstr;
  
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION){return;}
   
  f=IFV.FileChooser.getSelectedFile();
  if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
   JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
   return;
  }
  try{
   fstr=f.getCanonicalPath();
   if(PFile.compareIgnoreCaseExtension(fstr, "report")==false){
    f=new File(fstr+".report");
   }
  }
  catch(Exception E){
   JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !");
   return;
  }
  if(PEtc.saveIdToFile(TempList.getElements(), f, false,
   IFV.FSplashScreen, true, this, "Menulis Data DaftarKu")==false){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data report ke file !");
  }
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  File f;
  long[] tlist;
  
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showDialog(this, "Load")!=JFileChooser.APPROVE_OPTION){return;}
  f=IFV.FileChooser.getSelectedFile();
  if(PFile.compareIgnoreCaseExtension(f.getName(), "report")==false){
   JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+
    "Ekstensi file harus '.report'.");
   return;
  }
  tlist=PEtc.loadIdFromFile(f, false,
   IFV.FSplashScreen, true, this, "Membaca Data DaftarKu");
  if(tlist==null){
   JOptionPane.showMessageDialog(null, "Gagal membaca data report dari file !");
   return;
  }
  
  clearTempList();
  fillTempList(tlist, true);
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  if(JOptionPane.showConfirmDialog(null, "Kosongkan data pada 'Daftarku' ?", "Konfirmasi Pengosongan Data Pada 'Daftarku'",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  clearTempList();
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Btn_FindBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBeforeActionPerformed
  findInTable(2);
 }//GEN-LAST:event_Btn_FindBeforeActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findInTable(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  int[] rows;
  int count;
  
  rows=Tbl_Rev.getSelectedRows();
  
  count=rows.length;
  if(count==0){return;}
  if(count==1){editSingle(rows[0]); return;}
  if(count>1){editMultiple(rows); return;}
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  int[] rows=Tbl_Rev.getSelectedRows();
  boolean success;
  
  if(rows.length==0){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" data revisi stok yg dipilih pada tabel ?",
   "Konfirmasi Penghapusan Data Revisi-Stok", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  IFV.FSplashScreen.appear(this, "Menghapus Revisi-Stok");
  IFV.FSplashScreen.inform(0, "Sedang memproses (harap menunggu) ...", "-");
  success=PDatabase.removeIdsWithLock(IFV.FSplashScreen, IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.RevStockLock, 10,
   "RevisiStock", TableMdlRev.getIds(0, rows));
  IFV.FSplashScreen.disappear();
  
  if(!success){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  TableMdlRev.remove(rows); onTableSelectedRowChanged(true);
  updateQueryCount(); updateQueryTempListCount();
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void Btn_ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReportActionPerformed
  switch(CmB_ReportType.getSelectedIndex()){
   case 0 : printReport(); break;
   case 1 : printCSV(); break;
  }
 }//GEN-LAST:event_Btn_ReportActionPerformed

 private void Btn_ItemTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemTempListAddActionPerformed
  int[] rows=Tbl_Rev.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlRev.getIds(3, rows), true);
 }//GEN-LAST:event_Btn_ItemTempListAddActionPerformed

 private void Btn_ItemTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemTempListRemoveActionPerformed
  int[] rows=Tbl_Rev.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlRev.getIds(3, rows), false);
 }//GEN-LAST:event_Btn_ItemTempListRemoveActionPerformed

 private void TF_TempListQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TempListQuantityMouseClicked
  int DynamicTempList=0;
  
  do{
   if(SwingUtilities.isLeftMouseButton(evt)){DynamicTempList=1; break;}
   if(SwingUtilities.isRightMouseButton(evt)){DynamicTempList=2; break;}
   DynamicTempList=-1;
  }while(false);
  if(DynamicTempList==-1){return;}
  
  setLastQuery(3, 0, "", "", false, "", false, DynamicTempList, false);
  fillTable();
 }//GEN-LAST:event_TF_TempListQuantityMouseClicked

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Rev)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Find)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;

  PGUI.requestFocusInWindow(TF_QItemName);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void TF_QStockOld1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QStockOld1KeyPressed
  PNav.onKey_Query_TF1(this, CB_QStockOld, TF_QStockOld1, TF_QStockOld2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QStockNew1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QStockOld)));
 }//GEN-LAST:event_TF_QStockOld1KeyPressed

 private void TF_QStockOld2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QStockOld2KeyPressed
  PNav.onKey_Query_TF2(this, CB_QStockOld, TF_QStockOld1, TF_QStockOld2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QStockNew2)));
 }//GEN-LAST:event_TF_QStockOld2KeyPressed

 private void TF_QStockOld1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QStockOld1FocusGained
  LastFocusedCmpSearch=TF_QStockOld1;
  PGUI.text_SelectAll(TF_QStockOld1);
 }//GEN-LAST:event_TF_QStockOld1FocusGained

 private void TF_QStockOld2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QStockOld2FocusGained
  LastFocusedCmpSearch=TF_QStockOld2;
  PGUI.text_SelectAll(TF_QStockOld2);
 }//GEN-LAST:event_TF_QStockOld2FocusGained

 private void TF_QStockNew1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QStockNew1FocusGained
  LastFocusedCmpSearch=TF_QStockNew1;
  PGUI.text_SelectAll(TF_QStockNew1);
 }//GEN-LAST:event_TF_QStockNew1FocusGained

 private void TF_QStockNew1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QStockNew1KeyPressed
  PNav.onKey_Query_TF1(this, CB_QStockNew, TF_QStockNew1, TF_QStockNew2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QStockOld1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QDifferent1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QStockNew)));
 }//GEN-LAST:event_TF_QStockNew1KeyPressed

 private void TF_QStockNew2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QStockNew2FocusGained
  LastFocusedCmpSearch=TF_QStockNew2;
  PGUI.text_SelectAll(TF_QStockNew2);
 }//GEN-LAST:event_TF_QStockNew2FocusGained

 private void TF_QStockNew2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QStockNew2KeyPressed
  PNav.onKey_Query_TF2(this, CB_QStockNew, TF_QStockNew1, TF_QStockNew2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QStockOld2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QDifferent2)));
 }//GEN-LAST:event_TF_QStockNew2KeyPressed

 private void TF_QDifferent1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QDifferent1FocusGained
  LastFocusedCmpSearch=TF_QDifferent1;
  PGUI.text_SelectAll(TF_QDifferent1);
 }//GEN-LAST:event_TF_QDifferent1FocusGained

 private void TF_QDifferent1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QDifferent1KeyPressed
  PNav.onKey_Query_TF1(this, CB_QDifferent, TF_QDifferent1, TF_QDifferent2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QStockNew1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QReasonOfRevisiAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QDifferent)));
 }//GEN-LAST:event_TF_QDifferent1KeyPressed

 private void TF_QDifferent2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QDifferent2FocusGained
  LastFocusedCmpSearch=TF_QDifferent2;
  PGUI.text_SelectAll(TF_QDifferent2);
 }//GEN-LAST:event_TF_QDifferent2FocusGained

 private void TF_QDifferent2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QDifferent2KeyPressed
  PNav.onKey_Query_TF2(this, CB_QDifferent, TF_QDifferent1, TF_QDifferent2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QStockNew2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QReasonOfRevisiAdd)));
 }//GEN-LAST:event_TF_QDifferent2KeyPressed

 private void CmB_ViewModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ViewModeActionPerformed
  onSelectedViewModeChanged(false);
 }//GEN-LAST:event_CmB_ViewModeActionPerformed

 private void Btn_NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_NewActionPerformed
  F_RevStockModify fm=IFV.FRevStockModify;
  Object[] Objs;
  int insertpos;
  long[] result;
  Vector<Object[]> Rows;
  long ItemId;
  OInfoRevStock InfoRevStock;
  
  fm.wMode=1;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  ItemId=fm.ItemDet.PrimaryId;
  Rows=new Vector();
  Rows.addElement(PCore.objArrVariant(fm.RevDate, PCore.subtituteLong(fm.ReasonOfRevisiId, -1, fm.ReasonOfRevisiId, null), ItemId, fm.StockOld, fm.StockNew, fm.StockDiff));
  
  /*
  result=PDatabase.insert_MultiRecords_AutoIncrement_ByList(IFV.Stm, "RevisiStock", PText.getString(IFV.CurrentDatabase, "", false)+IFV.RevStockLock, 10,
   null, null, null,
   "Id",
   PCore.refArr("RevisiDate", "ReasonOfRevisi", "Item", "StockOld", "StockNew"), PCore.primArr(CCore.TypeDate, CCore.TypeInteger, CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble),
   Rows, PCore.primArr(0), PCore.newIntegerArrayInOrderedSequence(5, 0, 1));
  */
  result=PMyShop.revAdd(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.RevStockLock, Rows);
  
  if(result==null){JOptionPane.showMessageDialog(null, "Gagal menambah data !"); return;}
  
  InfoRevStock=PMyShop.getRevStockInfo(IFV.Stm, result[0]);
  if(InfoRevStock==null){JOptionPane.showMessageDialog(null, "Gagal mengambil data revisi stok yang baru ditambahkan !"); return;}
  
  Objs=PCore.objArrVariant((long)result[0], fm.RevDate, PText.getString(fm.ReasonOfRevisiId, -1, fm.ReasonOfRevisiName, null),
   ItemId, fm.ItemDet.Name, InfoRevStock.StockOld, InfoRevStock.StockNew, InfoRevStock.StockDiff,
   fm.ItemDet.StockUnitName, fm.ItemDet.UpdateStock, fm.ItemDet.PictureFile, fm.ItemDet.CategoryName);
  insertpos=TableMdlRev.Mdl.Rows.size();
  TableMdlRev.insert(insertpos, Objs); Tbl_Rev.changeSelection(insertpos, 0, false, false); onTableSelectedRowChanged(true);
  updateQueryCount(); updateQueryTempListCount();
 }//GEN-LAST:event_Btn_NewActionPerformed

 private void Tbl_RevKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_RevKeyReleased
  onTableSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Rev, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_LEFT : if(Tbl_Rev.OnKeyPress_PosCol<=0){focusQuery();} break;
  }
 }//GEN-LAST:event_Tbl_RevKeyReleased

 private void Tbl_RevMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_RevMouseReleased
  onTableSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_RevMouseReleased

 private void Btn_QReasonOfRevisiAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QReasonOfRevisiAddActionPerformed
  Object[] NewRow;
  int count, temp;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblReasonOfRevisi;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   count=IFV.FDataIdName.DataId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=(int)IFV.FDataIdName.DataId[temp];
    NewRow[1]=IFV.FDataIdName.DataName[temp];
    ListMdlQReasonOfRevisi.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QReasonOfRevisiAddActionPerformed

 private void Btn_QReasonOfRevisiRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QReasonOfRevisiRemoveActionPerformed
  ListMdlQReasonOfRevisi.remove(List_QReasonOfRevisi.getSelectedIndices());
 }//GEN-LAST:event_Btn_QReasonOfRevisiRemoveActionPerformed

 private void Pnl_ItemPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Rev, TableMdlRev, 3, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemPreviewMouseClicked

 private void TF_QItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemIdFocusGained
  LastFocusedCmpSearch=TF_QItemId;
  PGUI.text_SelectAll(TF_QItemId);
 }//GEN-LAST:event_TF_QItemIdFocusGained

 private void TF_QItemNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemNameFocusGained
  LastFocusedCmpSearch=TF_QItemName;
  PGUI.text_SelectAll(TF_QItemName);
 }//GEN-LAST:event_TF_QItemNameFocusGained

 private void TF_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemIdKeyPressed
  PNav.onKey_Query_TF(this, CB_QItemId, TF_QItemId, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QRevDateStartY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QItemId)));
 }//GEN-LAST:event_TF_QItemIdKeyPressed

 private void TF_QItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemNameKeyPressed
  PNav.onKey_Query_TF(this, CB_QItemName, TF_QItemName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QStockOld1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemName)));
 }//GEN-LAST:event_TF_QItemNameKeyPressed

 private void Btn_QueryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QueryKeyPressed
  PNav.onKey_Btn(this, Btn_Query, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QueryKeyPressed

 private void CB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCheckKeyPressed
  PNav.onKey_CB(this, CB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QRevDate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCheck)));
 }//GEN-LAST:event_CB_QCheckKeyPressed

 private void CmB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCheckKeyPressed
  PNav.onKey_CmB(this, CmB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCheck)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QCheckKeyPressed

 private void CB_QRevDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QRevDateKeyPressed
  PNav.onKey_CB(this, CB_QRevDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QRevDateStartY)));
 }//GEN-LAST:event_CB_QRevDateKeyPressed

 private void TF_QRevDateStartYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QRevDateStartYKeyPressed
  PNav.onKey_TF(this, TF_QRevDateStartY, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QRevDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRevDateStartM)));
 }//GEN-LAST:event_TF_QRevDateStartYKeyPressed

 private void CmB_QRevDateStartMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRevDateStartMKeyPressed
  PNav.onKey_CmB(this, CmB_QRevDateStartM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QRevDateStartY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRevDateStartD)));
 }//GEN-LAST:event_CmB_QRevDateStartMKeyPressed

 private void CmB_QRevDateStartDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRevDateStartDKeyPressed
  PNav.onKey_CmB(this, CmB_QRevDateStartD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QRevDateStartM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QRevDateEndY)));
 }//GEN-LAST:event_CmB_QRevDateStartDKeyPressed

 private void TF_QRevDateEndYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QRevDateEndYKeyPressed
  PNav.onKey_TF(this, TF_QRevDateEndY, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QRevDateStartD)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRevDateEndM)));
 }//GEN-LAST:event_TF_QRevDateEndYKeyPressed

 private void CmB_QRevDateEndMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRevDateEndMKeyPressed
  PNav.onKey_CmB(this, CmB_QRevDateEndM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QRevDateEndY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRevDateEndD)));
 }//GEN-LAST:event_CmB_QRevDateEndMKeyPressed

 private void CmB_QRevDateEndDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRevDateEndDKeyPressed
  PNav.onKey_CmB(this, CmB_QRevDateEndD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QRevDateEndM)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QRevDateEndDKeyPressed

 private void CB_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemIdKeyPressed
  PNav.onKey_CB(this, CB_QItemId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QRevDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QItemId)));
 }//GEN-LAST:event_CB_QItemIdKeyPressed

 private void CmB_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QItemIdKeyPressed
  PNav.onKey_CmB(this, CmB_QItemId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemId)));
 }//GEN-LAST:event_CmB_QItemIdKeyPressed

 private void CB_QItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemNameKeyPressed
  PNav.onKey_CB(this, CB_QItemName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QStockOld)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemName)));
 }//GEN-LAST:event_CB_QItemNameKeyPressed

 private void CB_QStockOldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QStockOldKeyPressed
  PNav.onKey_CB(this, CB_QStockOld, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QStockNew)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QStockOld1)));
 }//GEN-LAST:event_CB_QStockOldKeyPressed

 private void CB_QStockNewKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QStockNewKeyPressed
  PNav.onKey_CB(this, CB_QStockNew, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QStockOld)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QDifferent)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QStockNew1)));
 }//GEN-LAST:event_CB_QStockNewKeyPressed

 private void CB_QDifferentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QDifferentKeyPressed
  PNav.onKey_CB(this, CB_QDifferent, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QStockNew)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QReasonOfRevisi)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QDifferent1)));
 }//GEN-LAST:event_CB_QDifferentKeyPressed

 private void CB_QReasonOfRevisiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QReasonOfRevisiKeyPressed
  PNav.onKey_CB(this, CB_QReasonOfRevisi, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QDifferent)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QReasonOfRevisiEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QReasonOfRevisi)));
 }//GEN-LAST:event_CB_QReasonOfRevisiKeyPressed

 private void CB_QReasonOfRevisiEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QReasonOfRevisiEmptyKeyPressed
  PNav.onKey_CB(this, CB_QReasonOfRevisiEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QReasonOfRevisi)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QReasonOfRevisi)));
 }//GEN-LAST:event_CB_QReasonOfRevisiEmptyKeyPressed

 private void List_QReasonOfRevisiKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QReasonOfRevisiKeyReleased
  PNav.onKey_List(this, List_QReasonOfRevisi, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QDifferent1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QReasonOfRevisi)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QReasonOfRevisiAdd)));
 }//GEN-LAST:event_List_QReasonOfRevisiKeyReleased

 private void Btn_QReasonOfRevisiAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QReasonOfRevisiAddKeyPressed
  PNav.onKey_Btn(this, Btn_QReasonOfRevisiAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QDifferent1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QReasonOfRevisiRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QReasonOfRevisi)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QReasonOfRevisiAddKeyPressed

 private void Btn_QReasonOfRevisiRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QReasonOfRevisiRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QReasonOfRevisiRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QReasonOfRevisiAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QReasonOfRevisi)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QReasonOfRevisiRemoveKeyPressed

 private void CB_QItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemKeyPressed
  PNav.onKey_CB(this, CB_QItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QReasonOfRevisiEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QItem)));
 }//GEN-LAST:event_CB_QItemKeyPressed

 private void Tbl_QItemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_QItemKeyReleased
  PNav.onKey_Tbl(this, Tbl_QItem, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QReasonOfRevisiAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QItemAdd)));
 }//GEN-LAST:event_Tbl_QItemKeyReleased

 private void Btn_QItemAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemAddKeyPressed
  PNav.onKey_Btn(this, Btn_QItemAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QReasonOfRevisiRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemAddKeyPressed

 private void Btn_QItemRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QItemRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemRemoveKeyPressed

 private void CB_ViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCategorizedActionPerformed
  changeTableRevViewByCategorized();
 }//GEN-LAST:event_CB_ViewCategorizedActionPerformed

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 private void TF_QRevDateStartYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QRevDateStartYFocusGained
  PGUI.text_SelectAll(TF_QRevDateStartY);
 }//GEN-LAST:event_TF_QRevDateStartYFocusGained

 private void TF_QRevDateEndYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QRevDateEndYFocusGained
  PGUI.text_SelectAll(TF_QRevDateEndY);
 }//GEN-LAST:event_TF_QRevDateEndYFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FindBefore;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_ItemTempListAdd;
 private javax.swing.JButton Btn_ItemTempListRemove;
 private javax.swing.JButton Btn_New;
 private javax.swing.JButton Btn_QItemAdd;
 private javax.swing.JButton Btn_QItemRemove;
 private javax.swing.JButton Btn_QReasonOfRevisiAdd;
 private javax.swing.JButton Btn_QReasonOfRevisiRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_QueryRefresh;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Report;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JCheckBox CB_QCheck;
 private javax.swing.JCheckBox CB_QDifferent;
 private javax.swing.JCheckBox CB_QItem;
 private javax.swing.JCheckBox CB_QItemId;
 private javax.swing.JCheckBox CB_QItemName;
 private javax.swing.JCheckBox CB_QReasonOfRevisi;
 private javax.swing.JCheckBox CB_QReasonOfRevisiEmpty;
 private javax.swing.JCheckBox CB_QRevDate;
 private javax.swing.JCheckBox CB_QStockNew;
 private javax.swing.JCheckBox CB_QStockOld;
 private javax.swing.JToggleButton CB_ViewCategorized;
 private javax.swing.JComboBox<String> CmB_Find;
 private javax.swing.JComboBox<String> CmB_QCheck;
 private javax.swing.JComboBox<String> CmB_QItemId;
 private javax.swing.JComboBox<String> CmB_QRevDateEndD;
 private javax.swing.JComboBox<String> CmB_QRevDateEndM;
 private javax.swing.JComboBox<String> CmB_QRevDateStartD;
 private javax.swing.JComboBox<String> CmB_QRevDateStartM;
 private javax.swing.JComboBox<String> CmB_ReportType;
 private javax.swing.JComboBox<String> CmB_ResultFilterSubset;
 private javax.swing.JComboBox<String> CmB_ViewMode;
 private XList List_QReasonOfRevisi;
 private XImgBoxURL Pnl_ItemPreview;
 private javax.swing.JTextArea TA_ItemInfoCategory;
 private javax.swing.JTextArea TA_ItemInfoName;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_QDifferent1;
 private javax.swing.JTextField TF_QDifferent2;
 private javax.swing.JTextField TF_QItemId;
 private javax.swing.JTextField TF_QItemName;
 private javax.swing.JTextField TF_QRevDateEndY;
 private javax.swing.JTextField TF_QRevDateStartY;
 private javax.swing.JTextField TF_QStockNew1;
 private javax.swing.JTextField TF_QStockNew2;
 private javax.swing.JTextField TF_QStockOld1;
 private javax.swing.JTextField TF_QStockOld2;
 private javax.swing.JTextField TF_QueryCount;
 private javax.swing.JTextField TF_QueryTempListCount;
 private javax.swing.JTextField TF_TempListQuantity;
 private XTable Tbl_QItem;
 private XTable Tbl_Rev;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 // End of variables declaration//GEN-END:variables
}
