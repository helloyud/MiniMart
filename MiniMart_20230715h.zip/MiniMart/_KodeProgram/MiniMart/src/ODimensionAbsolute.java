public class ODimensionAbsolute {
 
 int RowsCount;
 int ColumnsCount;

 public ODimensionAbsolute() {}
 public ODimensionAbsolute(int RowsCount, int ColumnsCount) {
  setSize(RowsCount, ColumnsCount);
 }
 
 public void setSize(int RowsCount, int ColumnsCount){
  this.RowsCount=RowsCount;
  this.ColumnsCount=ColumnsCount;
 }

}