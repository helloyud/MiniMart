public class ODrawInfoString {
 
 double LineAscent;
 double LineDescent;
 double LineHeight;
 double SingleCharWidth;
 
}