public class OPaperMargin {

 double Top;
 double Bottom;
 double Left;
 double Right;

 public OPaperMargin(double Top, double Bottom, double Left, double Right) {
  this.Top = Top;
  this.Bottom = Bottom;
  this.Left = Left;
  this.Right = Right;
 }

}