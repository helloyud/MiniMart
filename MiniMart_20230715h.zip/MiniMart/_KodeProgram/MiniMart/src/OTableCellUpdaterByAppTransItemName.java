import java.util.Vector;

public class OTableCellUpdaterByAppTransItemName
 extends OTableCellUpdater{
 
 int ColName, ColComment;

 public OTableCellUpdaterByAppTransItemName(int TableColumnIndex,
  int ColName, int ColComment) {
  init(TableColumnIndex);
  this.ColName = ColName;
  this.ColComment = ColComment;
 }
 
 public void update(int TableRowIndex){
  Vector<Object[]> Data=getRows();
  Object[] AData;
  String Name, Comment;
  
  AData=Data.elementAt(TableRowIndex);
  Name=PCore.objString(AData[ColName], null);
  Comment=PCore.objString(AData[ColComment], null);
  
  Data.elementAt(TableRowIndex)[TableColumnIndex]=PMyShop.genTransItemName(Name, Comment);
  
 }
 
}