import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;

public class PDatabaseApp {

 static OGregorianCalendar cal=new OGregorianCalendar();
 static Vector<ODatabaseTable> DbStructBackupTables=getDatabaseBackupStructureOfTable();
 static Vector<ODatabaseProcedure> DbStructBackupProcedures=getDatabaseBackupStructureOfProcedure();
 
 // these methods need to be changed when the database structure is changed
 public static Vector<ODatabaseTable> getDatabaseBackupStructureOfTable(){
  Vector<ODatabaseTable> ret=new Vector();
  ODatabaseTable Tbl;
  
  /*
   The order of tables & columns cannot be changed, but only can be appended from time to time.
   The order of tables & columns must in ascending order (from low to high version).
  */
  
  // 1
  Tbl=new ODatabaseTable("StockUnit", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 2
  Tbl=new ODatabaseTable("Item", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("StockUnit", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("UpdateStockOnTransaction", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("MinimalStock", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                                  .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("MaximalStock", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                                  .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("SellPrice", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("SellPriceComment", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyPriceComment", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("HasExpireDate", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsActive", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ExpireCheckPeriod", 6, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ExpireThreshold", 6, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("MismatchStock", 7, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("OpnameStock", 11, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))
                                                                                  .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, true, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("OpnameExpire", 11, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyPriceEstimation", 14, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("OrderQuantity", 14, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))
                                                                                    .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, true, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("SellUpdate", 15, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyUpdate", 15, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("OrderEachPackQty", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                                       .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("OrderEachPackThreshold", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("OrderMinPack", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                                   .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsReorder", 21, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsOpname", 25, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  ret.addElement(Tbl);
  
  // 3
  Tbl=new ODatabaseTable("CategoryOfItem", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 4
  Tbl=new ODatabaseTable("ItemXCategory", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CategoryOfItem", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  ret.addElement(Tbl);
  
  // 5
  Tbl=new ODatabaseTable("ItemXPicture", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("FileName", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 6
  Tbl=new ODatabaseTable("Subject", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Birthday", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 7
  Tbl=new ODatabaseTable("CategoryOfSubject", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 8
  Tbl=new ODatabaseTable("SubjectXCategory", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CategoryOfSubject", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  ret.addElement(Tbl);
  
  // 9
  Tbl=new ODatabaseTable("City", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 10
  Tbl=new ODatabaseTable("SubjectXAddress", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Address", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("City", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 11
  Tbl=new ODatabaseTable("ContactType", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 12
  Tbl=new ODatabaseTable("SubjectXContact", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Contact", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ContactType", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 13
  Tbl=new ODatabaseTable("ItemXSupplier", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Supplier", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyPriceComment", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("UpdateDate", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsActive", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyPrice", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  ret.addElement(Tbl);
  
  // 14
  Tbl=new ODatabaseTable("TransType", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 15
  Tbl=new ODatabaseTable("Trans", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransDate", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransType", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsImportant", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Salesman", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CreditDays", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashIn", 5, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodStart", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodEnd", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("InfoIdExternal", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashOutComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashInComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsFinalized", 23, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  ret.addElement(Tbl);
  
  // 16
  Tbl=new ODatabaseTable("TransXItemOut", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Trans", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 17
  Tbl=new ODatabaseTable("TransXItemIn", 0, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Trans", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 0, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 18
  Tbl=new ODatabaseTable("TransXPayment", 1, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Trans", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 1, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 19
  Tbl=new ODatabaseTable("PreTrans", 2, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransDate", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransType", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsImportant", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Salesman", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CreditDays", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashIn", 5, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodStart", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodEnd", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("InfoIdExternal", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashOutComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashInComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsFinalized", 23, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  ret.addElement(Tbl);
  
  // 20
  Tbl=new ODatabaseTable("PreTransXItemOut", 2, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTrans", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 21
  Tbl=new ODatabaseTable("PreTransXItemIn", 2, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTrans", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 22
  Tbl=new ODatabaseTable("PreTransXPayment", 2, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTrans", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 2, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 23
  Tbl=new ODatabaseTable("TransXPaymentIn", 3, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Trans", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 24
  Tbl=new ODatabaseTable("PreTransXPaymentIn", 3, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTrans", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 3, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 25
  Tbl=new ODatabaseTable("Cash", 4, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 4, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 26
  Tbl=new ODatabaseTable("TransPend", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransId", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransDate", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransType", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsImportant", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Salesman", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CreditDays", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashOut", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashIn", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodStart", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodEnd", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("InfoIdExternal", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashOutComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashInComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 27
  Tbl=new ODatabaseTable("TransPendXItemOut", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 28
  Tbl=new ODatabaseTable("TransPendXItemIn", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 29
  Tbl=new ODatabaseTable("TransPendXPaymentOut", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 30
  Tbl=new ODatabaseTable("TransPendXPaymentIn", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 31
  Tbl=new ODatabaseTable("PreTransPend", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTransId", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransDate", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TransType", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsImportant", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Salesman", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CreditDays", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashOut", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashIn", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodStart", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RepaymentPeriodEnd", 12, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("InfoIdExternal", 16, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashOutComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("CashInComment", 19, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 32
  Tbl=new ODatabaseTable("PreTransPendXItemOut", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 33
  Tbl=new ODatabaseTable("PreTransPendXItemIn", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                           .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Checked", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 24, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 34
  Tbl=new ODatabaseTable("PreTransPendXPaymentOut", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 35
  Tbl=new ODatabaseTable("PreTransPendXPaymentIn", 8, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("PreTransPend", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaymentDate", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Price", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Cash", 8, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 36
  Tbl=new ODatabaseTable("TagOfItem", 9, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 9, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 9, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 37
  Tbl=new ODatabaseTable("ItemXTag", 9, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 9, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TagOfItem", 9, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  ret.addElement(Tbl);
  
  // 38
  Tbl=new ODatabaseTable("ApplicationInfo", 10, false);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Parameter", 10, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ValueType", 10, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Value", 10, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBinary, true, 0))));
  ret.addElement(Tbl);
  
  // 39
  Tbl=new ODatabaseTable("CustomPaperLabel", 13, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsRollPaper", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("DrawCutLine", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaperWidth", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PaperHeight", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("MarginLeft", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("MarginTop", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("LabelWidth", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("LabelHeight", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("LabelGapHorizontal", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("LabelGapVerticalA", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("LabelGapVerticalB", 13, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  ret.addElement(Tbl);
  
  // 40
  Tbl=new ODatabaseTable("ItemXSecondaryId", 17, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 17, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("SecondaryId", 17, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  ret.addElement(Tbl);
  
  // 41
  Tbl=new ODatabaseTable("RevisiStock", 18, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RevisiDate", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("StockOld", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                               .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("StockNew", 18, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))
                                                                               .addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 19))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ReasonOfRevisi", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  ret.addElement(Tbl);
  
  // 42
  Tbl=new ODatabaseTable("ReasonOfRevisi", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 43
  Tbl=new ODatabaseTable("TagOfSubject", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 44
  Tbl=new ODatabaseTable("SubjectXTag", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("TagOfSubject", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  ret.addElement(Tbl);
  
  // 45
  Tbl=new ODatabaseTable("SubjectXPicture", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("FileName", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 46
  Tbl=new ODatabaseTable("RuleOfConv", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsActive", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("LastUpdate", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  ret.addElement(Tbl);
  
  // 47
  Tbl=new ODatabaseTable("RuleOfConvXSideA", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("RuleOfConv", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  ret.addElement(Tbl);
  
  // 48
  Tbl=new ODatabaseTable("RuleOfConvXSideB", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("RuleOfConv", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  ret.addElement(Tbl);
  
  // 49
  Tbl=new ODatabaseTable("ReasonOfConv", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 50
  Tbl=new ODatabaseTable("Conv", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ConvDate", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RuleOfConv", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RuleOfConvDirection", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("RuleOfConvCount", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("ReasonOfConv", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsFinalized", 23, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  ret.addElement(Tbl);
  
  // 51
  Tbl=new ODatabaseTable("ConvXItemOut", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Conv", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  ret.addElement(Tbl);
  
  // 52
  Tbl=new ODatabaseTable("ConvXItemIn", 20, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Conv", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Stock", 20, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  ret.addElement(Tbl);
  
  // 53
  Tbl=new ODatabaseTable("ItemXVariant", 22, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Item", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Variant", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("IsActive", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeBoolean, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyPrice", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDouble, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyPriceComment", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BuyUpdate", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeDate, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("PictureFile", 22, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  // 54 - 63 is temporary tables (trans ~ item in, item out, pay out, pay in ; pre-trans ~ item in, item out, pay out, pay in ; conv ~ item out, item in)
  
  // 64
  Tbl=new ODatabaseTable("BankPlatform", 26, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Id", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Name", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  ret.addElement(Tbl);
  
  // 65
  Tbl=new ODatabaseTable("SubjectXBankAccount", 26, true);
  Tbl.Columns.addElement(new ODatabaseTableColumn("Subject", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeLong, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Enumeration", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BankAccount", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, false, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("BankPlatform", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeInteger, true, 0))));
  Tbl.Columns.addElement(new ODatabaseTableColumn("Comment", 26, new OVector().addElement2(new ODatabaseTableColumnType(CCore.TypeString, true, 0))));
  ret.addElement(Tbl);
  
  return ret;
 }
 public static Vector<ODatabaseProcedure> getDatabaseBackupStructureOfProcedure(){
  Vector<ODatabaseProcedure> ret=new Vector();
  ODatabaseProcedure Proc;
  
  /*
   Only contains db-initial-executing-procedures while loading a database from a file
   The order of db-initial-executing-procedures should be in ascending order (from low to high version).
  */
  
  // 23
  Proc=new ODatabaseProcedure("TransInitialFinalizing", true, new ODatabaseVersion(23, 2));
  ret.addElement(Proc);
  
  Proc=new ODatabaseProcedure("PreTransInitialFinalizing", true, new ODatabaseVersion(23, 2));
  ret.addElement(Proc);
  
  Proc=new ODatabaseProcedure("ConvInitialFinalizing", true, new ODatabaseVersion(23, 2));
  ret.addElement(Proc);
  
  return ret;
 }
 public static int[] generate(Statement Stm, String DatabaseName,
  OParameterValueGroup AppInfo, boolean GetValueDefault, int GetValueIfNotIsAlreadyReturn,
  OFormInformProgress FSplash){
  int[] ret=new int[2];
  ret[0]=1; // index 0 indicates the state of generate operation (1 success, -1 error creating database, -2 error creating tables)
  ret[1]=1; // index 1 indicates the state of switch database operation (-1 fail, 1 success)
  OAnObject CurrDatabase=new OAnObject("");
  
  boolean Created=false;
  
  do{
   try{
    switchGetCurrDatabase(Stm, ret, CurrDatabase);
    
    // create database
    FSplash.inform(0, "Membuat database...", "-");
    
    Stm.execute("create database "+DatabaseName+";");
    Created=true;
    FSplash.inform(10, null, null);
    
    Stm.execute("use "+DatabaseName+";");
    
    // create tables
    FSplash.inform(0, "Membuat tabel & prosedur (harap menunggu)...", "-");
    
    // create table ApplicationInfo
    Stm.execute("create table "+DatabaseName+".ApplicationInfo("+
     "Parameter VarChar(150) Not Null, ValueType Int Unsigned Not Null, Value VarBinary("+CApp.DbVarcharMaxSize+"), "+
     "Primary Key(Parameter)) Engine=InnoDb;");
    
    PDatabase.parameterValueInsert(Stm, DatabaseName, "ApplicationInfo", AppInfo, GetValueDefault, GetValueIfNotIsAlreadyReturn);
    
    FSplash.inform(0, null, "Membuat tabel-tabel Barang");
    
    // create table StockUnit
    Stm.execute("create table "+DatabaseName+".StockUnit(Id Int Unsigned Not Null, Name VarChar(30) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table Item
    Stm.execute("create table "+DatabaseName+".Item(Id BigInt Unsigned Not Null, Name VarChar(150) Not Null, "+
     "StockUnit Int Unsigned, Stock "+CCore.getDbDataType_Fraction()+" Not Null, "+
     "UpdateStockOnTransaction Bool Not Null, MinimalStock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, MaximalStock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "SellPrice "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, SellPriceComment VarChar("+CApp.DbVarcharMaxSize+"), BuyPriceComment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "HasExpireDate Bool Not Null, IsActive Bool Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     
     // (extended 6)
     "ExpireCheckPeriod Int Unsigned Default Null, ExpireThreshold Int Unsigned Default Null, "+
     
     // (extended 7)
     "MismatchStock Boolean Not Null Default "+CCore.vFalse+", "+
     
     // (extended 11)
     "OpnameStock "+CCore.getDbDataType_Fraction()+" Default Null, OpnameExpire Date Default Null, "+
     
     // (extended 14)
     "BuyPriceEstimation "+CCore.getDbDataType_Fraction()+" Unsigned Not Null Default 0, OrderQuantity "+CCore.getDbDataType_Fraction()+" Unsigned Default Null, "+
     
     // (extended 15)
     "SellUpdate Date Default Null, BuyUpdate Date Default Null, "+
     
     // (extended 16)
     "OrderEachPackQty "+CCore.getDbDataType_Fraction()+" Unsigned Not Null Default 1, "+
     "OrderEachPackThreshold "+CCore.getDbDataType_Fraction()+" Unsigned Not Null Default "+PText.doubleToString(CApp.Default_Item_OrderEachPackThreshold, false)+", "+
     "OrderMinPack "+CCore.getDbDataType_Fraction()+" Unsigned Not Null Default 1, "+
     
     // (extended 21)
     "IsReorder Boolean Not Null Default "+CCore.vTrue+", "+
     
     // (extended 25)
     "IsOpname Boolean Not Null Default "+CCore.vTrue+", "+
     
     "Primary Key(Id), Unique(Name), Index(StockUnit), "+
     "Foreign Key(StockUnit) References StockUnit(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table CategoryOfItem
    Stm.execute("create table "+DatabaseName+".CategoryOfItem(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table ItemXCategory
    Stm.execute("create table "+DatabaseName+".ItemXCategory(Item BigInt Unsigned Not Null, CategoryOfItem Int Unsigned Not Null, "+
     "Primary Key(Item, CategoryOfItem), Index(Item), Index(CategoryOfItem), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(CategoryOfItem) References CategoryOfItem(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table TagOfItem (extended 9)
    Stm.execute("create table "+DatabaseName+".TagOfItem(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table ItemXTag (extended 9)
    Stm.execute("create table "+DatabaseName+".ItemXTag(Item BigInt Unsigned Not Null, TagOfItem Int Unsigned Not Null, "+
     "Primary Key(Item, TagOfItem), Index(Item), Index(TagOfItem), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(TagOfItem) References TagOfItem(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table ItemXPicture
    Stm.execute("create table "+DatabaseName+".ItemXPicture(Item BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null Default 0, "+
     "FileName VarChar(150) Not Null, "+
     "Primary Key(Item, FileName), Index(Item), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table CustomPaperLabel (extended 13)
    Stm.execute("create table "+DatabaseName+".CustomPaperLabel(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "IsRollPaper Bool Not Null, DrawCutLine Bool Not Null, "+
     "PaperWidth "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, PaperHeight "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "MarginLeft "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, MarginTop "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "LabelWidth "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, LabelHeight "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "LabelGapHorizontal "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, LabelGapVerticalA "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, LabelGapVerticalB "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table ItemXSecondaryId (extended 17)
    Stm.execute("create table "+DatabaseName+".ItemXSecondaryId(Item BigInt Unsigned Not Null, SecondaryId BigInt Unsigned Not Null, "+
     "Primary Key(Item, SecondaryId), Unique(SecondaryId), Index(Item), Index(SecondaryId), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table ItemXVariant (extended 22)
    Stm.execute("create table "+DatabaseName+".ItemXVariant(Item BigInt Unsigned Not Null, Variant VarChar(150) Not Null, "+
     "IsActive Bool Not Null Default "+CApp.Default_ItemVariant_Active+", Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, PictureFile VarChar(150) Default Null, "+
     "BuyPrice "+CCore.getDbDataType_Fraction()+" Unsigned Not Null Default 0, BuyPriceComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, BuyUpdate Date Default Null, "+
     "Primary Key(Item, Variant), Index(Item), Index(Variant), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    FSplash.inform(30, null, null);
    
    FSplash.inform(0, null, "Membuat tabel-tabel Subjek");

    // create table Subject
    Stm.execute("create table "+DatabaseName+".Subject(Id BigInt Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Birthday Date, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table CategoryOfSubject
    Stm.execute("create table "+DatabaseName+".CategoryOfSubject(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table SubjectXCategory
    Stm.execute("create table "+DatabaseName+".SubjectXCategory(Subject BigInt Unsigned Not Null, CategoryOfSubject Int Unsigned Not Null, "+
     "Primary Key(Subject, CategoryOfSubject), Index(Subject), Index(CategoryOfSubject), "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(CategoryOfSubject) References CategoryOfSubject(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table City
    Stm.execute("create table "+DatabaseName+".City(Id Int Unsigned Not Null, Name VarChar(100) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

     // create table SubjectXAddress
    Stm.execute("create table "+DatabaseName+".SubjectXAddress(Subject BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "Address VarChar("+CApp.DbVarcharMaxSize+") Not Null, City Int Unsigned, "+
     
     // (extended 26)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(Subject, Enumeration), Unique(Subject, City, Address), Index(Subject), Index(City), "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(City) References City(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table ContactType
    Stm.execute("create table "+DatabaseName+".ContactType(Id Int Unsigned Not Null, Name VarChar(100) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table SubjectXContact
    Stm.execute("create table "+DatabaseName+".SubjectXContact(Subject BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "Contact VarChar(150) Not Null, ContactType Int Unsigned, "+
     
     // (extended 26)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(Subject, Enumeration), Unique(Subject, ContactType, Contact), Index(Subject), Index(ContactType), "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(ContactType) References ContactType(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table BankPlatform (extended 26)
    Stm.execute("create table "+DatabaseName+".BankPlatform(Id Int Unsigned Not Null, Name VarChar(100) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table SubjectXBankAccount (extended 26)
    Stm.execute("create table "+DatabaseName+".SubjectXBankAccount(Subject BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "BankAccount VarChar(150) Not Null, BankPlatform Int Unsigned, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Primary Key(Subject, Enumeration), Unique(Subject, BankPlatform, BankAccount), Index(Subject), Index(BankPlatform), "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(BankPlatform) References BankPlatform(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table TagOfSubject (extended 20)
    Stm.execute("create table "+DatabaseName+".TagOfSubject(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table SubjectXTag (extended 20)
    Stm.execute("create table "+DatabaseName+".SubjectXTag(Subject BigInt Unsigned Not Null, TagOfSubject Int Unsigned Not Null, "+
     "Primary Key(Subject, TagOfSubject), Index(Subject), Index(TagOfSubject), "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(TagOfSubject) References TagOfSubject(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table SubjectXPicture (extended 20)
    Stm.execute("create table "+DatabaseName+".SubjectXPicture(Subject BigInt Unsigned Not Null, FileName VarChar(150) Not Null, "+
     "Primary Key(Subject, FileName), Index(Subject), "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

     // create table ItemXSupplier
    Stm.execute("create table "+DatabaseName+".ItemXSupplier(Item BigInt Unsigned Not Null, Supplier BigInt Unsigned Not Null, "+
     "BuyPriceComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, UpdateDate Date Default Null, "+
     
     // (extended 18)
     "IsActive Bool Not Null Default "+CApp.Default_ItemSupplier_Active+", "+
     
     // (extended 22)
     "BuyPrice "+CCore.getDbDataType_Fraction()+" Unsigned Not Null Default 0, "+
     
     "Primary Key(Item, Supplier), Index(Item), Index(Supplier), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade, "+
     "Foreign key(Supplier) References Subject(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    FSplash.inform(20, null, null);
    
    FSplash.inform(0, null, "Membuat tabel-tabel Transaksi");

     // create table TransType
    Stm.execute("create table "+DatabaseName+".TransType(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table Cash (extended 4)
    Stm.execute("create table "+DatabaseName+".Cash(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table Trans
    Stm.execute("create table "+DatabaseName+".Trans(Id BigInt Unsigned Not Null, TransDate Date Not Null, "+
     "TransType Int Unsigned, Subject BigInt Unsigned, IsImportant Bool Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     
     // (extended 1)
     "Salesman BigInt Unsigned Default Null, CreditDays Int Unsigned Default Null, "+
     
     // (extended 4)
     "Cash Int Unsigned Default Null, "+
     
     // (extended 5)
     "CashIn Int Unsigned Default Null, "+
					
					// (extended 12)
					"RepaymentPeriodStart Date Default Null, RepaymentPeriodEnd Date Default Null, "+
     
     // (extended 16)
     "InfoIdExternal VarChar(100) Default Null, "+
     
     // (extended 19)
     "CashOutComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, CashInComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     // (extended 23)
     "IsFinalized Bool Not Null Default "+CCore.vFalse+", "+
     
     "Primary Key(Id), Index(TransType), Index(Subject), Index(Salesman), "+
     "Foreign Key(TransType) References TransType(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Salesman) References Subject(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(CashIn) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table TransXItemOut
    createTable(Stm, DatabaseName, "TransXItemOut", true,
     "Trans BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(Trans, Item), Index(Trans), Index(Item), "+
     "Foreign Key(Trans) References Trans(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Restrict");

    // create table TransXItemIn
    createTable(Stm, DatabaseName, "TransXItemIn", true,
     "Trans BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(Trans, Item), Index(Trans), Index(Item), "+
     "Foreign Key(Trans) References Trans(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Restrict");
    
    // create table TransXPayment {as PaymentOut} (extended 1)
    createTable(Stm, DatabaseName, "TransXPayment", true,
     "Trans BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     
     // (extended 4)
     "Cash Int Unsigned Default Null, "+
     
     "Primary Key(Trans, Enumeration), Index(Trans), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Trans) References Trans(Id) On Update Cascade On Delete Cascade");
    
    // create table TransXPaymentIn (extended 3)
    createTable(Stm, DatabaseName, "TransXPaymentIn", true,
     "Trans BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     
     // (extended 4)
     "Cash Int Unsigned Default Null, "+
     
     "Primary Key(Trans, Enumeration), Index(Trans), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Trans) References Trans(Id) On Update Cascade On Delete Cascade");

    // create table PreTrans (extended 2)
    Stm.execute("create table "+DatabaseName+".PreTrans(Id BigInt Unsigned Not Null, TransDate Date Not Null, "+
     "TransType Int Unsigned, Subject BigInt Unsigned, IsImportant Bool Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Salesman BigInt Unsigned Default Null, CreditDays Int Unsigned Default Null, "+
     
     // (extended 4)
     "Cash Int Unsigned Default Null, "+
     
     // (extended 5)
     "CashIn Int Unsigned Default Null, "+
					
					// (extended 12)
					"RepaymentPeriodStart Date Default Null, RepaymentPeriodEnd Date Default Null, "+
     
     // (extended 16)
     "InfoIdExternal VarChar(100) Default Null, "+
     
     // (extended 19)
     "CashOutComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, CashInComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     // (extended 23)
     "IsFinalized Bool Not Null Default "+CCore.vFalse+", "+
     
     "Primary Key(Id), Index(TransType), Index(Subject), Index(Salesman), "+
     "Foreign Key(TransType) References TransType(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Salesman) References Subject(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(CashIn) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table PreTransXItemOut (extended 2)
    createTable(Stm, DatabaseName, "PreTransXItemOut", true,
     "PreTrans BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(PreTrans, Item), Index(PreTrans), Index(Item), "+
     "Foreign Key(PreTrans) References PreTrans(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Restrict");

    // create table PreTransXItemIn (extended 2)
    createTable(Stm, DatabaseName, "PreTransXItemIn", true,
     "PreTrans BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(PreTrans, Item), Index(PreTrans), Index(Item), "+
     "Foreign Key(PreTrans) References PreTrans(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Restrict");
    
    // create table PreTransXPayment {as PaymentOut} (extended 2)
    createTable(Stm, DatabaseName, "PreTransXPayment", true,
     "PreTrans BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     
     // (extended 4)
     "Cash Int Unsigned Default Null, "+
     
     "Primary Key(PreTrans, Enumeration), Index(PreTrans), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(PreTrans) References PreTrans(Id) On Update Cascade On Delete Cascade");
    
    // create table PreTransXPaymentIn (extended 3)
    createTable(Stm, DatabaseName, "PreTransXPaymentIn", true,
     "PreTrans BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     
     // (extended 4)
     "Cash Int Unsigned Default Null, "+
     
     "Primary Key(PreTrans, Enumeration), Index(PreTrans), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(PreTrans) References PreTrans(Id) On Update Cascade On Delete Cascade");

    // create table TransPend (extended 8)
    Stm.execute("create table "+DatabaseName+".TransPend(Id BigInt Unsigned Not Null, TransId BigInt Unsigned Not Null, TransDate Date Not Null, "+
     "TransType Int Unsigned, Subject BigInt Unsigned, IsImportant Bool Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Salesman BigInt Unsigned Default Null, CreditDays Int Unsigned Default Null, "+
     "CashOut Int Unsigned Default Null, CashIn Int Unsigned Default Null, "+
					
					// (extended 12)
					"RepaymentPeriodStart Date Default Null, RepaymentPeriodEnd Date Default Null, "+
     
     // (extended 16)
     "InfoIdExternal VarChar(100) Default Null, "+
     
     // (extended 19)
     "CashOutComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, CashInComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
					
     "Primary Key(Id), Unique(TransId), "+
     "Foreign Key(TransId) References Trans(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(TransType) References TransType(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Salesman) References Subject(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(CashOut) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(CashIn) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

   // create table TransPendXItemOut (extended 8)
    Stm.execute("create table "+DatabaseName+".TransPendXItemOut(TransPend BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(TransPend, Item), Index(TransPend), Index(Item), "+
     "Foreign Key(TransPend) References TransPend(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table TransPendXItemIn (extended 8)
    Stm.execute("create table "+DatabaseName+".TransPendXItemIn(TransPend BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(TransPend, Item), Index(TransPend), Index(Item), "+
     "Foreign Key(TransPend) References TransPend(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table TransPendXPaymentOut (extended 8)
    Stm.execute("create table "+DatabaseName+".TransPendXPaymentOut(TransPend BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Cash Int Unsigned Default Null, "+
     "Primary Key(TransPend, Enumeration), Index(TransPend), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(TransPend) References TransPend(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table TransPendXPaymentIn (extended 8)
    Stm.execute("create table "+DatabaseName+".TransPendXPaymentIn(TransPend BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Cash Int Unsigned Default Null, "+
     "Primary Key(TransPend, Enumeration), Index(TransPend), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(TransPend) References TransPend(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table PreTransPend (extended 8)
    Stm.execute("create table "+DatabaseName+".PreTransPend(Id BigInt Unsigned Not Null, PreTransId BigInt Unsigned Not Null, TransDate Date Not Null, "+
     "TransType Int Unsigned, Subject BigInt Unsigned, IsImportant Bool Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Salesman BigInt Unsigned Default Null, CreditDays Int Unsigned Default Null, "+
     "CashOut Int Unsigned Default Null, CashIn Int Unsigned Default Null, "+
					
					// (extended 12)
					"RepaymentPeriodStart Date Default Null, RepaymentPeriodEnd Date Default Null, "+
     
     // (extended 16)
     "InfoIdExternal VarChar(100) Default Null, "+
     
     // (extended 19)
     "CashOutComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, CashInComment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
					
     "Primary Key(Id), Unique(PreTransId), "+
     "Foreign Key(PreTransId) References PreTrans(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(TransType) References TransType(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Salesman) References Subject(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(CashOut) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(CashIn) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(Subject) References Subject(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

   // create table PreTransPendXItemOut (extended 8)
    Stm.execute("create table "+DatabaseName+".PreTransPendXItemOut(PreTransPend BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(PreTransPend, Item), Index(PreTransPend), Index(Item), "+
     "Foreign Key(PreTransPend) References PreTransPend(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table PreTransPendXItemIn (extended 8)
    Stm.execute("create table "+DatabaseName+".PreTransPendXItemIn(PreTransPend BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     
     // (extended 18)
     "Checked Bool Not Null Default "+CApp.Default_TransItem_Checked+", "+
     
     // (extended 24)
     "Comment VarChar("+CApp.DbVarcharMaxSize+") Default Null, "+
     
     "Primary Key(PreTransPend, Item), Index(PreTransPend), Index(Item), "+
     "Foreign Key(PreTransPend) References PreTransPend(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table PreTransPendXPaymentOut (extended 8)
    Stm.execute("create table "+DatabaseName+".PreTransPendXPaymentOut(PreTransPend BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Cash Int Unsigned Default Null, "+
     "Primary Key(PreTransPend, Enumeration), Index(PreTransPend), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(PreTransPend) References PreTransPend(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table PreTransPendXPaymentIn (extended 8)
    Stm.execute("create table "+DatabaseName+".PreTransPendXPaymentIn(PreTransPend BigInt Unsigned Not Null, Enumeration Int Unsigned Not Null, "+
     "PaymentDate Date Not Null, Price "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, Comment VarChar("+CApp.DbVarcharMaxSize+"), "+
     "Cash Int Unsigned Default Null, "+
     "Primary Key(PreTransPend, Enumeration), Index(PreTransPend), "+
     "Foreign Key(Cash) References Cash(Id) On Update Cascade On Delete Set Null, "+
     "Foreign Key(PreTransPend) References PreTransPend(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table ReasonOfRevisi (extended 20)
    Stm.execute("create table "+DatabaseName+".ReasonOfRevisi(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table RevisiStock (extended 18)
    Stm.execute("create table "+DatabaseName+".RevisiStock(Id BigInt Unsigned Not Null, "+
     "RevisiDate Date Not Null, Item BigInt Unsigned Not Null, StockOld "+CCore.getDbDataType_Fraction()+" Not Null, StockNew "+CCore.getDbDataType_Fraction()+" Not Null, "+
     
     // (extended 20)
     "ReasonOfRevisi Int Unsigned Default Null, "+
     
     "Primary Key(Id), Index(Item), Index(ReasonOfRevisi), "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(ReasonOfRevisi) References ReasonOfRevisi(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");

    // create table RuleOfConv (extended 20)
    Stm.execute("create table "+DatabaseName+".RuleOfConv(Id BigInt Unsigned Not Null, Name VarChar("+CApp.DbVarcharMaxSize+") Not Null, "+
     "IsActive Bool Not Null, LastUpdate Date, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");
    
    // create table RuleOfConvXSideA (extended 20)
    Stm.execute("create table "+DatabaseName+".RuleOfConvXSideA(RuleOfConv BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "Primary Key(RuleOfConv, Item), Index(RuleOfConv), Index(Item), "+
     "Foreign Key(RuleOfConv) References RuleOfConv(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");
    
    // create table RuleOfConvXSideB (extended 20)
    Stm.execute("create table "+DatabaseName+".RuleOfConvXSideB(RuleOfConv BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "Primary Key(RuleOfConv, Item), Index(RuleOfConv), Index(Item), "+
     "Foreign Key(RuleOfConv) References RuleOfConv(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade) Engine=InnoDb;");

    // create table ReasonOfConv (extended 20)
    Stm.execute("create table "+DatabaseName+".ReasonOfConv(Id Int Unsigned Not Null, Name VarChar(150) Not Null, "+
     "Primary Key(Id), Unique(Name)) Engine=InnoDb;");

    // create table Conv (extended 20)
    Stm.execute("create table "+DatabaseName+".Conv(Id BigInt Unsigned Not Null, ConvDate Date Not Null, RuleOfConv BigInt Unsigned Not Null, "+
     "RuleOfConvDirection Bool Not Null, RuleOfConvCount "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, ReasonOfConv Int Unsigned, "+
     
     // (extended 23)
     "IsFinalized Bool Not Null Default "+CCore.vFalse+", "+
     
     "Primary Key(Id), Index(RuleOfConv), Index(ReasonOfConv), "+
     "Foreign Key(RuleOfConv) References RuleOfConv(Id) On Update Cascade On Delete Restrict, "+
     "Foreign Key(ReasonOfConv) References ReasonOfConv(Id) On Update Cascade On Delete Set Null) Engine=InnoDb;");
    
    // create table ConvXItemOut (extended 20)
    createTable(Stm, DatabaseName, "ConvXItemOut", true,
     "Conv BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "Primary Key(Conv, Item), Index(Conv), Index(Item), "+
     "Foreign Key(Conv) References Conv(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade");
    
    // create table ConvXItemIn (extended 20)
    createTable(Stm, DatabaseName, "ConvXItemIn", true,
     "Conv BigInt Unsigned Not Null, Item BigInt Unsigned Not Null, "+
     "Stock "+CCore.getDbDataType_Fraction()+" Unsigned Not Null, "+
     "Primary Key(Conv, Item), Index(Conv), Index(Item), "+
     "Foreign Key(Conv) References Conv(Id) On Update Cascade On Delete Cascade, "+
     "Foreign Key(Item) References Item(Id) On Update Cascade On Delete Cascade");
    
    FSplash.inform(20, null, null);
    
    // create procedures, functions, & triggers
    FSplash.inform(0, null, "Membuat prosedur-prosedur");

    createTrigger(Stm, DatabaseName);
    
    createProcedure(Stm, DatabaseName);
    
    FSplash.inform(20, null, null);
   }
   catch(Exception E_){
    System.out.println(E_.toString());
    if(!Created){ret[0]=-1;}
    else{
     try{Stm.execute("drop database "+DatabaseName+";");}catch(Exception E){}
     ret[0]=-2;
    }
    break;
   }
  }while(false);
  
  switchReswitchToCurrDatabase(Stm, ret, CurrDatabase);
  
  return ret;
 }
 public static void createTable(Statement Stm, String Database, String Table, boolean WithTemporaryTable, String TableContent) throws Exception{
  Stm.execute("create table "+Database+"."+Table+"("+TableContent+") Engine=InnoDb;");
  if(WithTemporaryTable){Stm.execute("create table "+Database+"."+CSQL.getTableTemp(Table)+"("+TableContent+") Engine=InnoDb;");}
 }
 private static void createTrigger(Statement Stm, String DatabaseName) throws Exception{
  String Op_ItemStock, Op_Modify;
  
  /* definer='root'@'localhost' must be included in the trigger's declaration because the trigger's statement can be executed only if the definer still exists !!! */
  
  // create trigger TransXItemIn
  Op_Modify="+cast(new.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ItemInOnInsert after insert on "+DatabaseName+".TransXItemIn for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=new.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="+(cast(new.Stock as "+CCore.getDbDataType_Fraction()+")-cast(old.Stock as "+CCore.getDbDataType_Fraction()+"))";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ItemInOnUpdate after update on "+DatabaseName+".TransXItemIn for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="-cast(old.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ItemInOnDelete after delete on "+DatabaseName+".TransXItemIn for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  // create trigger TransXItemOut
  Op_Modify="-cast(new.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ItemOutOnInsert after insert on "+DatabaseName+".TransXItemOut for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=new.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="+(cast(old.Stock as "+CCore.getDbDataType_Fraction()+")-cast(new.Stock as "+CCore.getDbDataType_Fraction()+"))";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ItemOutOnUpdate after update on "+DatabaseName+".TransXItemOut for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="+cast(old.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ItemOutOnDelete after delete on "+DatabaseName+".TransXItemOut for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");
  
  // create trigger RevisiStock
  Op_Modify="+(new.StockNew-new.StockOld)";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".RevisiStockOnInsert after insert on "+DatabaseName+".RevisiStock for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=new.Item;");
  
  // create trigger ConvXItemIn
  Op_Modify="+cast(new.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ConvInOnInsert after insert on "+DatabaseName+".ConvXItemIn for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=new.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="+(cast(new.Stock as "+CCore.getDbDataType_Fraction()+")-cast(old.Stock as "+CCore.getDbDataType_Fraction()+"))";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ConvInOnUpdate after update on "+DatabaseName+".ConvXItemIn for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="-cast(old.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ConvInOnDelete after delete on "+DatabaseName+".ConvXItemIn for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  // create trigger ConvXItemOut
  Op_Modify="-cast(new.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ConvOutOnInsert after insert on "+DatabaseName+".ConvXItemOut for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=new.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="+(cast(old.Stock as "+CCore.getDbDataType_Fraction()+")-cast(new.Stock as "+CCore.getDbDataType_Fraction()+"))";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ConvOutOnUpdate after update on "+DatabaseName+".ConvXItemOut for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");

  Op_Modify="+cast(old.Stock as "+CCore.getDbDataType_Fraction()+")";
  Op_ItemStock="Stock"+Op_Modify;
  Stm.execute("create definer='root'@'localhost' trigger "+DatabaseName+".ConvOutOnDelete after delete on "+DatabaseName+".ConvXItemOut for each row "+
   "update Item set "+
    "Stock="+Op_ItemStock+" "+
   "where Id=old.Item and UpdateStockOnTransaction="+CCore.vTrue+";");
 }
 private static void dropTrigger(Statement Stm, String DatabaseName) throws Exception{
  // drop trigger TransXItemIn
  Stm.execute("drop trigger if exists "+DatabaseName+".ItemInOnInsert;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ItemInOnUpdate;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ItemInOnDelete;");
  
  // drop trigger TransXItemOut
  Stm.execute("drop trigger if exists "+DatabaseName+".ItemOutOnInsert;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ItemOutOnUpdate;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ItemOutOnDelete;");
  
  // drop trigger RevisiStock
  Stm.execute("drop trigger if exists "+DatabaseName+".RevisiStockOnInsert;");
  
  // drop trigger ConvXItemIn
  Stm.execute("drop trigger if exists "+DatabaseName+".ConvInOnInsert;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ConvInOnUpdate;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ConvInOnDelete;");
  
  // drop trigger ConvXItemOut
  Stm.execute("drop trigger if exists "+DatabaseName+".ConvOutOnInsert;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ConvOutOnUpdate;");
  Stm.execute("drop trigger if exists "+DatabaseName+".ConvOutOnDelete;");
 }
 private static void createProcedure(Statement Stm, String DatabaseName) throws Exception{
  /* definer='root'@'localhost' must be included in the procedure's declaration because the procedure's statement can be executed only if the definer still exists !!! */
  /*
   'sql security' can be declared with 2 ways :
   a. 'sql security definer' means who ever calls/invokes the procedure, then the sql statements inside the procedure will be executed with the privilledge of the definer
   b. 'sql security invoker' means who ever calls/invokes the procedure, then the sql statements inside the procedure will be executed with the privilledge of the invoker
   In this application, every procedure will be defined with 'sql security definer', so who ever can calls/invokes the procedure successfully
   as long as he has the rights/privilledge to calls/invokes the procedure.
  */
  
  // Procedures of Trans
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".TransEditNotImportant("+
   "In TId BigInt Unsigned, In TDate Date, In TType Int Unsigned, In TCashOut Int Unsigned, In TCashIn Int Unsigned, "+
   "In TSubject BigInt Unsigned, In TSalesman BigInt Unsigned, In TCreditDays Int Unsigned, In TRepayPeriodStart Date, "+
			"In TRepayPeriodEnd Date, In TImportant Boolean, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TInfoIdExternal Varchar(100), "+
   "In TCashOutComment Varchar("+CApp.DbVarcharMaxSize+"), In TCashInComment Varchar("+CApp.DbVarcharMaxSize+")) sql security definer "+
   "update trans set transdate=TDate, transtype=TType, cash=TCashOut, cashin=TCashIn, subject=TSubject, salesman=TSalesman, "+
   "creditdays=TCreditDays, repaymentperiodstart=TRepayPeriodStart, repaymentperiodend=TRepayPeriodEnd, isimportant=TImportant, "+
			"comment=TComment, infoidexternal=TInfoIdExternal, CashOutComment=TCashOutComment, CashInComment=TCashInComment "+
   "where id=TId and isimportant="+CCore.vFalse+";");
  
  /*
   MySQL's formula to delete rows in a table :
    delete from table_to_be_deleted using <list_of_rows_to_be_deleted>
   
   <list_of_rows_to_be_deleted> is list of rows to be deleted from table
   <list_of_rows_to_be_deleted> must contain "table_to_be_deleted" (to delete all rows)
   And optionally can be combined with "join clause" or "where clause" in order to filter only some rows to be deleted
  */
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".TransRemoveEmpty(In RemoveId BigInt) sql security definer "+
   "delete from trans using "+
    "trans "+
    "cross join (select 0) as fake_table on trans.id=RemoveId "+ // 1st step = trans fake join fake_table to select only RemoveId row
    "left join transxitemin on trans.id=transxitemin.trans "+ // 2nd step = result_from_1st_step left join transxitemin to get list of item in
    "left join transxitemout on trans.id=transxitemout.trans "+ // 3rd step = result_from_2nd_step left join transxitemout to get list of item out
   "where transxitemin.trans is "+CCore.vNull+" and transxitemout.trans is "+CCore.vNull+";");
  
  Stm.execute(genProc_TransInitialFinalizing(false, DatabaseName));
  Stm.execute(genProc_TransInsert(false, DatabaseName));
  Stm.execute(genProc_TransRemoveInTableTemporary(false, DatabaseName));
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".TransInAdd(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into transxitemin(trans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".TransInAddUpdate(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into transxitemin(trans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked) "+
   "on duplicate key update stock=stock+values(stock), price=price+values(price);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".TransOutAdd(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into transxitemout(trans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".TransOutAddUpdate(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into transxitemout(trans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked) "+
   "on duplicate key update stock=stock+values(stock), price=price+values(price);");
  
  // Procedures of PreTrans
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".PreTransEditNotImportant("+
   "In TId BigInt Unsigned, In TDate Date, In TType Int Unsigned, In TCashOut Int Unsigned, In TCashIn Int Unsigned, "+
   "In TSubject BigInt Unsigned, In TSalesman BigInt Unsigned, In TCreditDays Int Unsigned, In TRepayPeriodStart Date, "+
			"In TRepayPeriodEnd Date, In TImportant Boolean, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TInfoIdExternal Varchar(100), "+
   "In TCashOutComment Varchar("+CApp.DbVarcharMaxSize+"), In TCashInComment Varchar("+CApp.DbVarcharMaxSize+")) sql security definer "+
   "update pretrans set transdate=TDate, transtype=TType, cash=TCashOut, cashin=TCashIn, subject=TSubject, salesman=TSalesman, "+
   "creditdays=TCreditDays, repaymentperiodstart=TRepayPeriodStart, repaymentperiodend=TRepayPeriodEnd, isimportant=TImportant, "+
			"comment=TComment, infoidexternal=TInfoIdExternal, CashOutComment=TCashOutComment, CashInComment=TCashInComment "+
   "where id=TId and isimportant="+CCore.vFalse+";");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".PreTransRemoveEmpty(In RemoveId BigInt) sql security definer "+
   "delete from pretrans using "+
    "pretrans "+
    "cross join (select 0) as fake_table on pretrans.id=RemoveId "+
    "left join pretransxitemin on pretrans.id=pretransxitemin.pretrans "+
    "left join pretransxitemout on pretrans.id=pretransxitemout.pretrans "+
   "where pretransxitemin.pretrans is "+CCore.vNull+" and pretransxitemout.pretrans is "+CCore.vNull+";");
  
  Stm.execute(genProc_TransInitialFinalizing(true, DatabaseName));
  Stm.execute(genProc_TransInsert(true, DatabaseName));
  Stm.execute(genProc_TransRemoveInTableTemporary(true, DatabaseName));
  Stm.execute(genProc_TransRemove(true, DatabaseName, true));
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".PreTransInAdd(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into pretransxitemin(pretrans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".PreTransInAddUpdate(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into pretransxitemin(pretrans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked) "+
   "on duplicate key update stock=stock+values(stock), price=price+values(price);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".PreTransOutAdd(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into pretransxitemout(pretrans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".PreTransOutAddUpdate(In TId BigInt Unsigned, In TItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned, In TPrice "+CCore.getDbDataType_Fraction()+" Unsigned, In TComment Varchar("+CApp.DbVarcharMaxSize+"), In TChecked Boolean) sql security definer "+
   "insert into pretransxitemout(pretrans, item, stock, price, comment, checked) values (TId, TItem, Quantity, TPrice, TComment, TChecked) "+
   "on duplicate key update stock=stock+values(stock), price=price+values(price);");
  
  // Procedures of Conv
  
  Stm.execute(genProc_ConvInitialFinalizing(DatabaseName));
  Stm.execute(genProc_ConvInsert(DatabaseName));
  Stm.execute(genProc_ConvRemoveInTableTemporary(DatabaseName));
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".ConvInAdd(In CId BigInt Unsigned, In CItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned) sql security definer "+
   "insert into convxitemin(conv, item, stock) values (CId, CItem, Quantity);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".ConvInAddUpdate(In CId BigInt Unsigned, In CItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned) sql security definer "+
   "insert into convxitemin(conv, item, stock) values (CId, CItem, Quantity) "+
   "on duplicate key update stock=stock+values(stock);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".ConvOutAdd(In CId BigInt Unsigned, In CItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned) sql security definer "+
   "insert into convxitemout(conv, item, stock) values (CId, CItem, Quantity);");
  
  Stm.execute("create definer='root'@'localhost' procedure "+DatabaseName+".ConvOutAddUpdate(In CId BigInt Unsigned, In CItem BigInt Unsigned, "+
   "In Quantity "+CCore.getDbDataType_Fraction()+" Unsigned) sql security definer "+
   "insert into convxitemout(conv, item, stock) values (CId, CItem, Quantity) "+
   "on duplicate key update stock=stock+values(stock);");
  
  // Procedures of RevStock
  Stm.execute(genProc_RevInsert(DatabaseName));
 }
 private static String genProc_TransInitialFinalizing(boolean IsPreTrans, String DatabaseName){
  String ret=null;
  String Trans, Proc, TableTransPend, TableTransInfo;
  
  Trans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  Proc=Trans+"InitialFinalizing";
  
  TableTransPend=Trans+"Pend";
  
  TableTransInfo=
   " inner join "+
   
    "("+
     "select "+Trans+".Id, if("+TableTransPend+".Id is not null, true, false) as 'IsPending' from "+Trans+" "+
     "left join "+TableTransPend+" on "+Trans+".Id="+TableTransPend+"."+Trans+"Id "+
    ") as info_trans"+
   
   " on "+Trans+".Id=info_trans.Id";
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"() sql security definer "+
   "Proc: begin "+
    
    "update "+Trans+TableTransInfo+" set IsFinalized=true where IsFinalized=false and IsPending=false; "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_TransRemove(boolean IsPreTrans, String DatabaseName, boolean IsCancelling){
  String ret=null;
  String Trans, Proc, Tb_Trans, Tb_ItemIn, Tb_ItemOut, Tb_PayOut, Tb_PayIn, Tb_ItemIn_Temp, Tb_ItemOut_Temp, Tb_PayOut_Temp, Tb_PayIn_Temp;
  
  Trans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  Proc=Trans+PText.getString(IsCancelling, "Cancel", "Remove");
  if(!IsPreTrans){
   Tb_Trans=Trans;
   Tb_ItemIn=Trans+"XItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
   Tb_ItemOut=Trans+"XItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
   Tb_PayOut=Trans+"XPayment"; Tb_PayOut_Temp=CSQL.getTableTemp(Tb_PayOut);
   Tb_PayIn=Trans+"XPaymentIn"; Tb_PayIn_Temp=CSQL.getTableTemp(Tb_PayIn);
  }
  else{
   Tb_Trans=Trans;
   Tb_ItemIn=Trans+"XItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
   Tb_ItemOut=Trans+"XItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
   Tb_PayOut=Trans+"XPayment"; Tb_PayOut_Temp=CSQL.getTableTemp(Tb_PayOut);
   Tb_PayIn=Trans+"XPaymentIn"; Tb_PayIn_Temp=CSQL.getTableTemp(Tb_PayIn);
  }
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"(In TId BigInt Unsigned) sql security definer "+
   "Proc: begin "+
    
    PText.getString(!IsCancelling, "",
    "delete from "+Tb_ItemIn+" where "+Trans+"=TId; "+
    "delete from "+Tb_ItemOut+" where "+Trans+"=TId; "+
    "delete from "+Tb_PayOut+" where "+Trans+"=TId; "+
    "delete from "+Tb_PayIn+" where "+Trans+"=TId; ")+
    
    "delete from "+Tb_Trans+" where Id=TId; "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_TransInsert(boolean IsPreTrans, String DatabaseName){
  String ret=null;
  String Trans, Proc, Tb_ItemIn, Tb_ItemOut, Tb_PayOut, Tb_PayIn, Tb_ItemIn_Temp, Tb_ItemOut_Temp, Tb_PayOut_Temp, Tb_PayIn_Temp;
  
  Trans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  Proc=Trans+"Insert";
  if(!IsPreTrans){
   Tb_ItemIn=Trans+"XItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
   Tb_ItemOut=Trans+"XItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
   Tb_PayOut=Trans+"XPayment"; Tb_PayOut_Temp=CSQL.getTableTemp(Tb_PayOut);
   Tb_PayIn=Trans+"XPaymentIn"; Tb_PayIn_Temp=CSQL.getTableTemp(Tb_PayIn);
  }
  else{
   Tb_ItemIn=Trans+"XItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
   Tb_ItemOut=Trans+"XItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
   Tb_PayOut=Trans+"XPayment"; Tb_PayOut_Temp=CSQL.getTableTemp(Tb_PayOut);
   Tb_PayIn=Trans+"XPaymentIn"; Tb_PayIn_Temp=CSQL.getTableTemp(Tb_PayIn);
  }
  
  /* code for "start transaction - commit - rollback" (put inside procedure)
   procedure x()
   begin
    
    declare exit handler for sqlexception
    begin
     rollback;
    end;

    start transaction;

    .....

    commit;
    
   end;
  */
  
  /*
   how to exit a procedure or a loop in mysql's procedure :
  
   [leave_label:] begin
    
    ..... inside, we can put : Leave [leave_label];
   
   end;
  */
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"(In TId BigInt Unsigned) sql security definer "+
   "Proc: begin "+
    
    "declare IsFound Bool; "+
    "declare VIsFinalized Bool; "+
    
    "declare QueryResult cursor for select IsFinalized from "+Trans+" where Id=TId; "+
    
    "declare continue handler for not found "+
    "begin "+
     "set IsFound=false; "+
    "end; "+
    
    "set IsFound=true; "+
    
    "open QueryResult; "+
    "fetch QueryResult into VIsFinalized; "+
    "close QueryResult; "+
    
    "if (IsFound=false) then "+
     "leave Proc; "+
    "end if; "+
    
    "if (VIsFinalized) then "+
     "leave Proc; "+
    "end if; "+
    
    "insert into "+Tb_ItemIn+"("+Trans+", Item, Stock, Price, Comment, Checked) "+
     "select "+Trans+", Item, Stock, Price, Comment, Checked from "+Tb_ItemIn_Temp+" where "+Tb_ItemIn_Temp+"."+Trans+"=TId; "+
    
    "insert into "+Tb_ItemOut+"("+Trans+", Item, Stock, Price, Comment, Checked) "+
     "select "+Trans+", Item, Stock, Price, Comment, Checked from "+Tb_ItemOut_Temp+" where "+Tb_ItemOut_Temp+"."+Trans+"=TId; "+
    
    "insert into "+Tb_PayIn+"("+Trans+", Enumeration, PaymentDate, Price, Comment, Cash) "+
     "select "+Trans+", Enumeration, PaymentDate, Price, Comment, Cash from "+Tb_PayIn_Temp+" where "+Tb_PayIn_Temp+"."+Trans+"=TId; "+
    
    "insert into "+Tb_PayOut+"("+Trans+", Enumeration, PaymentDate, Price, Comment, Cash) "+
     "select "+Trans+", Enumeration, PaymentDate, Price, Comment, Cash from "+Tb_PayOut_Temp+" where "+Tb_PayOut_Temp+"."+Trans+"=TId; "+
    
    "update "+Trans+" set IsFinalized=true where Id=TId; "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_TransRemoveInTableTemporary(boolean IsPreTrans, String DatabaseName){
  String ret=null;
  String Trans, Proc, Tb_ItemIn, Tb_ItemOut, Tb_PayOut, Tb_PayIn, Tb_ItemIn_Temp, Tb_ItemOut_Temp, Tb_PayOut_Temp, Tb_PayIn_Temp;
  
  Trans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  Proc=Trans+"RemoveTemporary";
  if(!IsPreTrans){
   Tb_ItemIn=Trans+"XItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
   Tb_ItemOut=Trans+"XItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
   Tb_PayOut=Trans+"XPayment"; Tb_PayOut_Temp=CSQL.getTableTemp(Tb_PayOut);
   Tb_PayIn=Trans+"XPaymentIn"; Tb_PayIn_Temp=CSQL.getTableTemp(Tb_PayIn);
  }
  else{
   Tb_ItemIn=Trans+"XItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
   Tb_ItemOut=Trans+"XItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
   Tb_PayOut=Trans+"XPayment"; Tb_PayOut_Temp=CSQL.getTableTemp(Tb_PayOut);
   Tb_PayIn=Trans+"XPaymentIn"; Tb_PayIn_Temp=CSQL.getTableTemp(Tb_PayIn);
  }
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"(In TId BigInt Unsigned) sql security definer "+
   "begin "+
    
    "delete from "+Tb_ItemIn_Temp+" where "+Trans+"=TId; "+
    "delete from "+Tb_ItemOut_Temp+" where "+Trans+"=TId; "+
    "delete from "+Tb_PayOut_Temp+" where "+Trans+"=TId; "+
    "delete from "+Tb_PayIn_Temp+" where "+Trans+"=TId; "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_RevInsert(String DatabaseName){
  String ret=null;
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+".RevAdd(In RId BigInt Unsigned, In RRevisiDate Date, In RReasonOfRevisi Int Unsigned, "+
   "In RItem BigInt Unsigned, In RStockDiff "+CCore.getDbDataType_Fraction()+") sql security definer "+
   "Proc: begin "+
    
    "declare IsFound Bool; "+
    "declare RStockOld "+CCore.getDbDataType_Fraction()+"; "+
    
    "declare QueryResult cursor for select Stock from Item where Id=RItem; "+
    
    "declare continue handler for not found "+
    "begin "+
     "set IsFound=false; "+
    "end; "+
    
    "set IsFound=true; "+
    
    "open QueryResult; "+
    "fetch QueryResult into RStockOld; "+
    "close QueryResult; "+
    
    "if (IsFound=false) then "+
     "leave Proc; "+
    "end if; "+
    
    "insert into RevisiStock(id, revisidate, reasonofrevisi, item, stockold, stocknew) "+
     "values (RId, RRevisiDate, RReasonOfRevisi, RItem, RStockOld, RStockOld+RStockDiff); "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_ConvInitialFinalizing(String DatabaseName){
  String ret=null;
  String Proc;
  
  Proc="ConvInitialFinalizing";
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"() sql security definer "+
   "Proc: begin "+
    
    "update Conv set IsFinalized=true where IsFinalized=false; "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_ConvInsert(String DatabaseName){
  String ret=null;
  String Proc;
  
  Proc="ConvInsert";
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"(In CId BigInt Unsigned) sql security definer "+
   "Proc: begin "+
    
    "declare IsFound Bool; "+
    "declare VIsFinalized Bool; "+
    "declare VConvRule BigInt Unsigned; "+
    "declare VConvDirection Bool; "+
    "declare VConvCount "+CCore.getDbDataType_Fraction()+"; "+
    
    "declare QueryResult cursor for select IsFinalized, RuleOfConv, RuleOfConvDirection, RuleOfConvCount from Conv where Id=CId; "+
    
    "declare continue handler for not found "+
    "begin "+
     "set IsFound=false; "+
    "end; "+
    
    "set IsFound=true; "+
    
    "open QueryResult; "+
    "fetch QueryResult into VIsFinalized, VConvRule, VConvDirection, VConvCount; "+
    "close QueryResult; "+
    
    "if (IsFound=false) then "+
     "leave Proc; "+
    "end if; "+
    
    "if (VIsFinalized) then "+
     "leave Proc; "+
    "end if; "+
    
    "if (VConvDirection) then "+
     
     "insert into ConvXItemOut(Conv, Item, Stock) "+
      "select CId, Item, Stock*VConvCount from RuleOfConvXSideA where RuleOfConvXSideA.RuleOfConv=VConvRule; "+

     "insert into ConvXItemIn(Conv, Item, Stock) "+
      "select CId, Item, Stock*VConvCount from RuleOfConvXSideB where RuleOfConvXSideB.RuleOfConv=VConvRule; "+
    
    "else "+
     
     "insert into ConvXItemOut(Conv, Item, Stock) "+
      "select CId, Item, Stock*VConvCount from RuleOfConvXSideB where RuleOfConvXSideB.RuleOfConv=VConvRule; "+

     "insert into ConvXItemIn(Conv, Item, Stock) "+
      "select CId, Item, Stock*VConvCount from RuleOfConvXSideA where RuleOfConvXSideA.RuleOfConv=VConvRule; "+
     
    "end if; "+
    
    "update Conv set IsFinalized=true where Id=CId; "+
    
   "end;";
  
  return ret;
 }
 private static String genProc_ConvRemoveInTableTemporary(String DatabaseName){
  String ret=null;
  String Proc, Tb_ItemIn, Tb_ItemOut, Tb_ItemIn_Temp, Tb_ItemOut_Temp;
  
  Proc="ConvRemoveTemporary";
  Tb_ItemIn="ConvXItemIn"; Tb_ItemIn_Temp=CSQL.getTableTemp(Tb_ItemIn);
  Tb_ItemOut="ConvXItemOut"; Tb_ItemOut_Temp=CSQL.getTableTemp(Tb_ItemOut);
  
  ret=
   "create definer='root'@'localhost' procedure "+DatabaseName+"."+Proc+"(In CId BigInt Unsigned) sql security definer "+
   "begin "+
    
    "delete from "+Tb_ItemOut_Temp+" where Conv=CId; "+
    "delete from "+Tb_ItemIn_Temp+" where Conv=CId; "+
    
   "end;";
  
  return ret;
 }
 private static int checkExtendedStructure(Statement Stm, String DatabaseName) throws Exception{
  /* this method identifies database version by checking the number of tables and columns */
  int ret=0; // 0 - original, n (>0) - extended n
  int temp, temp2;
  do{
   
   temp=Stm.executeUpdate("show tables from "+DatabaseName+";");
   
   // extended 26 = 65 tables
   if(temp>=65){ret=26; break;}
   
   // extended 23, 24, 25 = 63 tables
   if(temp>=63){
    temp2=Stm.executeUpdate("show columns from Item from "+DatabaseName+";");
    if(temp2>=27){ret=25; break;}
    if(temp2>=26){
     temp2=Stm.executeUpdate("show columns from TransXItemIn from "+DatabaseName+";");
     if(temp2>=6){ret=24; break;}
     if(temp2>=5){ret=23; break;}
    }
   }
   
   // extended 22 = 53 tables
   if(temp>=53){ret=22; break;}
   
   // extended 20, 21 = 52 tables
   if(temp>=52){
    temp2=Stm.executeUpdate("show columns from Item from "+DatabaseName+";");
    if(temp2>=26){ret=21; break;}
    if(temp2>=25){ret=20; break;}
   }
   
   // extended 18, 19 = 41 tables
   if(temp>=41){
    temp2=Stm.executeUpdate("show columns from Trans from "+DatabaseName+";");
    if(temp2>=15){ret=19; break;}
    if(temp2>=13){ret=18; break;}
   }
   
   // extended 17 = 40 tables
   if(temp>=40){ret=17; break;}
   
   // extended 13, 14, 15, 16 = 39 tables
   if(temp>=39){
    temp2=Stm.executeUpdate("show columns from Item from "+DatabaseName+";");
    if(temp2>=25){ret=16; break;}
    if(temp2>=22){ret=15; break;}
    if(temp2>=20){ret=14; break;}
    if(temp2>=18){ret=13; break;}
   }
   
   // extended 10, 11, 12 = 38 tables
   if(temp>=38){
    temp2=Stm.executeUpdate("show columns from Item from "+DatabaseName+";");
    if(temp2>=18){
					temp2=Stm.executeUpdate("show columns from Trans from "+DatabaseName+";");
					if(temp2>=12){ret=12; break;}
					if(temp2>=10){ret=11; break;}
				}
    if(temp2>=16){ret=10; break;}
   }
   
   // extended 9 = 37 tables
   if(temp>=37){ret=9; break;}
   
   // extended 8 = 35 tables
   if(temp>=35){ret=8; break;}
   
   // extended 4, 5, 6, 7 = 25 tables
   if(temp>=25){
    temp2=Stm.executeUpdate("show columns from Trans from "+DatabaseName+";");
    if(temp2>=10){
     temp2=Stm.executeUpdate("show columns from Item from "+DatabaseName+";");
     if(temp2>=16){ret=7; break;}
     if(temp2>=15){ret=6; break;}
     if(temp2>=13){ret=5; break;}
    }
    if(temp2>=9){ret=4; break;}
   }
   
   // extended 3 = 24 tables
   if(temp>=24){ret=3; break;}
   
   // extended 2 = 22 tables
   if(temp>=22){ret=2; break;}
   
   // extended 1 = 18 tables
   if(temp>=18){ret=1; break;}
   
   // original = 17 tables
   if(temp>=17){ret=0; break;}
   
  }while(false);
  return ret;
 }
 public static ODatabaseVersion getDatabaseVersion(Statement Stm, String DatabaseName){
  ODatabaseVersion ret=null;
  OParameterValueGroup versioncheck;
  Object version, subvariant;
  
  do{
   try{
    versioncheck=new OParameterValueGroup();
    versioncheck.addElement(new OParameterValue(CApp.ParamDbVersion, CCore.TypeInteger, null, null, false, false));
    versioncheck.addElement(new OParameterValue(CApp.ParamDbSubVariant, CCore.TypeInteger, null, null, false, false));
    
    versioncheck=PDatabase.parameterValueGet(Stm, DatabaseName, "ApplicationInfo", versioncheck);
    version=versioncheck.elementAt(0).getValue(false, 0);
    subvariant=versioncheck.elementAt(1).getValue(false, 0);
    
    if(version==null || subvariant==null){
     version=checkExtendedStructure(Stm, DatabaseName);
     subvariant=1;
    }
   }
   catch(Exception E){break;}
   ret=new ODatabaseVersion((Integer)version, (Integer)subvariant);
  }while(false);
  
  return ret;
 }

 // final methods
 public static int[] upgradeDatabase(Statement Stm, String TargetDb, OParameterValueGroup AppInfo, String TempDirectory, int AppDbVersion, OFormInformProgress Progress){
  int[] ret=new int[2];
  ret[0]=-1; // index 0 indicates the state of upgrade operation (1 success, -1 fail)
  ret[1]=1; // index 1 indicates the state of switch database operation (1 success, -1 fail)
  OAnObject CurrDatabase=new OAnObject("");
  
  OParameterValueGroup ApInf;
  
  File backupfile=new File(PFile.toDirectory(TempDirectory, File.separatorChar)+"dbtemp_"+PText.dateToString(new Date(), 6));
  
  Vector<OUserAccess> UsersAccess;
  
  do{
   try{
    switchGetCurrDatabase(Stm, ret, CurrDatabase);
    
    // backup from old_db
    
     // data
    Progress.inform(0, "Menyimpan 'data' dari database lama", "-");
    Progress.progressInformExternalMode(true, 15);
    if(saveTablesData(Stm, TargetDb, backupfile, AppDbVersion, Progress)[0]!=1){break;}
    ApInf=PDatabase.parameterValueGet(Stm, TargetDb, "ApplicationInfo", AppInfo);
    Progress.progressInformExternalMode(false, 100);
    
     // user access permission
    Progress.inform(0, "Menyimpan 'hak akses user' dari database lama", "-");
    UsersAccess=PDatabaseUser.createUsersAccess(PDatabaseUser.getUsers(Stm), null); if(UsersAccess==null){break;}
    if(!PDatabaseUser.getUsersDatabasePrivilleges(Stm, TargetDb, UsersAccess, true)){break;}
    Progress.inform(5, null, null);
    
    // delete old_db
    Progress.inform(0, "Menghapus database lama", "-");
    Progress.progressInformExternalMode(true, 10);
    if(!dropDatabase(Stm, TargetDb, Progress)){break;}
    Progress.progressInformExternalMode(false, 100);

    // create new_db
    Progress.inform(0, "Membuat database baru", "-");
    Progress.progressInformExternalMode(true, 25);
    if(generate(Stm, TargetDb, AppInfo, true, 1, Progress)[0]!=1){break;}
    Progress.progressInformExternalMode(false, 100);
    
    // restore to new_db
    
     // data
    Progress.inform(0, "Merestorasi 'data' ke database baru", "-");
    Progress.progressInformExternalMode(true, 45);
    if(loadTablesData(Stm, backupfile, TargetDb, AppDbVersion, Progress)[0]!=1){break;}
    if(!PDatabase.parameterValueUpdate(Stm, TargetDb, "ApplicationInfo", ApInf, false, 1)){break;}
    Progress.progressInformExternalMode(false, 100);
    
     // user access permission
    Progress.inform(0, "Merestorasi 'hak akses user' ke database baru", "-");
    if(!PDatabaseUser.setUsersDatabasePrivilleges(Stm, TargetDb, UsersAccess, true)){break;}
    Progress.inform(5, null, null);
   }
   catch(Exception E){break;}
   ret[0]=1;
  }while(false);
  
  // delete backup file (if exist)
  if(backupfile.exists()){try{backupfile.delete();}catch(Exception E){}}
  
  switchReswitchToCurrDatabase(Stm, ret, CurrDatabase);
  
  return ret;
 }

 public static boolean dropDatabase(Statement Stm, String Db, OFormInformProgress Progress){
  boolean ret=false;
  Vector<OUserAccess> UsersAccess;
  
  do{
   try{
    Progress.inform(0, "Sedang memproses (harap menunggu)...", "-");
    UsersAccess=PDatabaseUser.createUsersAccess(PDatabaseUser.getUsers(Stm), PCore.newBooleanArray(PDatabaseUser.DatabasePrivillegesCount, false));
    if(UsersAccess==null){break;}
    PDatabaseUser.setUsersDatabasePrivilleges(Stm, Db, UsersAccess, true);
    Stm.execute("drop database "+Db+";");
    Progress.inform(100, null, null);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  
  return ret;
 }

 public static int[] saveTablesData(Statement Stm, String SrcDb, File DestFileOri, int AppDbVersion, OFormInformProgress Progress){
  int[] ret=new int[2];
  ret[0]=-1; // index 0 indicates the state of save operation (1 success, -1 fail)
  ret[1]=1; // index 1 indicates the state of switch database operation (1 success, -1 fail)
  OAnObject CurrDatabase=new OAnObject("");
  
  FileOutputStream fos=null;
  BufferedOutputStream bos=null;
  DataOutputStream dos=null;
  ResultSet rs;
  long temp, temp_;
  int structure, structuredb;
  StringBuilder Columns;
  boolean vBool;
  int vInt;
  long vLong;
  double vDouble;
  String vString;
  Date vDate;
  double progress_increment;
  
  File DestFile=null;
  File Dir;
  boolean DestFileOriExist=false;
  boolean DestFileOriIsDirectory=false;
  
  int TblCurr, TblCount, ColCurr, ColCount;
  ODatabaseTable Tbl;
  Vector<ODatabaseTableColumn> Cols;
  ODatabaseTableColumn Col;
  boolean firstcol, isnull;
  
  ODatabaseTableColumnType coltype_db;
  
  do{
   try{
    
    Progress.inform(0, "Mempersiapkan proses backup...", "-");

    // prepare file
    if(DestFileOri.exists()==true){
     DestFileOriExist=true;
     if(DestFileOri.isFile()!=true){
      DestFileOriIsDirectory=true;
      break;
     }
     DestFile=new File(DestFileOri.getCanonicalPath()+".shoptemp");
     if(DestFile.exists()){
      if(DestFile.delete()==false){break;}
     }
    }
    else{
     DestFile=DestFileOri;
     Dir=DestFile.getParentFile();
     if(!Dir.isDirectory()){
      if(!Dir.mkdirs()){break;}
     }
    }

    // prepare read data from database and write data to file
    fos=new FileOutputStream(DestFile);
    bos=new BufferedOutputStream(fos, 8192);
    dos=new DataOutputStream(bos);
    
    // check structure on database
    structuredb=checkExtendedStructure(Stm, SrcDb);
    
    // define write-structure; maximal write-structure is the lowest version between db-structure & app-structure
    structure=structuredb; if(AppDbVersion<structuredb){structure=AppDbVersion;}
    if(structure!=0){
     dos.write(PSerialize.serString("-D-b-E-x-t-"));
     dos.writeInt(structure);
    }
    
    TblCount=DbStructBackupTables.size();
    
    switchGetCurrDatabase(Stm, ret, CurrDatabase);
    
    Stm.execute("use "+SrcDb+";");
    
    Progress.inform(7, null, null);
    
    Progress.inform(0, "Menyimpan data dari database ke file...", "-");
    
    progress_increment=(1d/(double)TblCount)*90;
    TblCurr=0;
    do{
     Tbl=DbStructBackupTables.elementAt(TblCurr);
     
     if(structure>=Tbl.SinceVersion && Tbl.IncludeInBackup){
      rs=Stm.executeQuery("select count(*) from "+SrcDb+"."+Tbl.Name+";");
      rs.next();
      temp=rs.getLong(1);
      dos.writeLong(temp);
      if(temp!=0){
       
       Cols=Tbl.Columns;
       ColCount=Cols.size();
       
       // generate columns
       Columns=new StringBuilder();
       ColCurr=0;
       firstcol=true;
       do{
        Col=Cols.elementAt(ColCurr);
        if(structure>=Col.SinceVersion){
         if(firstcol){firstcol=false;}else{Columns.append(',');}
         Columns.append(Col.Name);
        }
        ColCurr=ColCurr+1;
       }while(ColCurr!=ColCount);
       
       // doing operation
       rs=Stm.executeQuery("select "+Columns.toString()+" from "+SrcDb+"."+Tbl.Name+";");
       
       temp_=0;
       do{
        rs.next();
        
        ColCurr=0;
        do{
         Col=Cols.elementAt(ColCurr);
         if(structure>=Col.SinceVersion){
          coltype_db=getDatabaseTableColomnType(Col.ColumnTypes, structure);
          switch(coltype_db.Type){
           case CCore.TypeString :
            vString=rs.getString(ColCurr+1);
            if(coltype_db.Nullable){isnull=rs.wasNull(); dos.writeBoolean(!isnull); if(isnull){break;}}
            dos.writeUTF(vString); break;
           case CCore.TypeInteger :
            vInt=rs.getInt(ColCurr+1);
            if(coltype_db.Nullable){isnull=rs.wasNull(); dos.writeBoolean(!isnull); if(isnull){break;}}
            dos.writeInt(vInt); break;
           case CCore.TypeLong :
            vLong=rs.getLong(ColCurr+1);
            if(coltype_db.Nullable){isnull=rs.wasNull(); dos.writeBoolean(!isnull); if(isnull){break;}}
            dos.writeLong(vLong); break;
           case CCore.TypeDouble :
            vDouble=rs.getDouble(ColCurr+1);
            if(coltype_db.Nullable){isnull=rs.wasNull(); dos.writeBoolean(!isnull); if(isnull){break;}}
            dos.writeDouble(vDouble); break;
           case CCore.TypeBoolean :
            vBool=rs.getBoolean(ColCurr+1);
            if(coltype_db.Nullable){isnull=rs.wasNull(); dos.writeBoolean(!isnull); if(isnull){break;}}
            dos.writeBoolean(vBool); break;
           case CCore.TypeDate :
            vDate=rs.getDate(ColCurr+1);
            if(coltype_db.Nullable){isnull=rs.wasNull(); dos.writeBoolean(!isnull); if(isnull){break;}}
            cal.setNewTime(vDate); dos.writeLong(cal.getTimeInMillis()); break;
          }
         }
         ColCurr=ColCurr+1;
        }while(ColCurr!=ColCount);

        temp_=temp_+1;
       }while(temp_!=temp);
       
      }
     }
     TblCurr=TblCurr+1;
     Progress.inform(progress_increment, null, null);
    }while(TblCurr!=TblCount);

    // write 'the remaining unwritten bytes' in OutputStream
    dos.flush();
    
    Progress.inform(3, null, null);
   }
   catch(Exception E_){break;}
   ret[0]=1;
  }while(false);
  if(dos!=null){
   try{dos.close();}catch(Exception E_){}
  }
  if(bos!=null){
   try{bos.close();}catch(Exception E_){}
  }
  if(fos!=null){
   try{fos.close();}catch(Exception E_){}
  }
  
  // post file processing
  do{
   try{
    
    if(DestFileOriIsDirectory || DestFile==null){break;}

    // if operation was failed : {nothing} do nothing, {temp ori} delete temp ori, {ori & temp ori} delete temp ori
    if(!(ret[0]==1)){
     // delete the temp ori
     if(!DestFile.exists()){break;}
     DestFile.delete();
     break;
    }

    // if operation was success : {temp ori} do nothing, {ori & temp ori} rename temp ori to ori
    // rename temp ori to ori
    if(!DestFileOriExist){break;}
    ret[0]=-1;
    if(DestFileOri.delete()==false){break;}
    if(DestFile.renameTo(DestFileOri)==false){break;}
    ret[0]=1;
    
   }
   catch(Exception E){}
  }while(false);
  
  switchReswitchToCurrDatabase(Stm, ret, CurrDatabase);
  
  return ret;
 }
 public static int[] loadTablesData(Statement VStm, File SrcFile, String DestDb, int AppDbVersion, OFormInformProgress Progress){
  int[] ret=new int[2];
  ret[0]=-1; // index 0 indicates the state of load operation (1 success, -1 fail)
  ret[1]=1; // index 1 indicates the state of switch database operation (1 success, -1 fail)
  OAnObject CurrDatabase=new OAnObject("");
  
  FileInputStream fis=null;
  BufferedInputStream bis=null;
  DataInputStream dis=null;
  byte[] Bytes;
  long temp, temp_;
  ODatabaseVersion structuredb;
  int CurrIns, InsUntil, EachInsertCount, structurefl, structure;
  StringBuilder Columns;
  StringBuilder str;
  boolean first;
  
  boolean isnull;
  OAnObject value=new OAnObject();
  double progress_increment;
  
  int TblCurr, TblCount, ColCurr, ColCount, ProcCurr, ProcCount;
  ODatabaseTable Tbl;
  Vector<ODatabaseTableColumn> Cols;
  ODatabaseTableColumn Col;
  boolean firstcol;
  ODatabaseProcedure Proc;
  
  int dbtbl_count, dbtbl_temp;
  Vector<String> dbtbl, tbl_unbackup;
  String tblname;
  
  ODatabaseTableColumnType coltype_fl, coltype_db;
  
  do{
   try{
    Progress.inform(0, "Mempersiapkan proses restore (harap menunggu)...", "-");
    
    // check if the file is exist
    if(SrcFile.exists()!=true){break;}
    if(SrcFile.isFile()!=true){break;}
    
    // check structure on database & structure on file
    structuredb=getDatabaseVersion(VStm, DestDb); if(structuredb==null){break;}
    structurefl=0;
    fis=new FileInputStream(SrcFile); bis=new BufferedInputStream(fis, 16); dis=new DataInputStream(bis);
    Bytes=new byte[11]; dis.read(Bytes);
    if(PText.compare(PSerialize.deserString(Bytes), "-D-b-E-x-t-", true)){structurefl=dis.readInt();}
    dis.close(); bis.close(); fis.close();
    
    // app-structure must equal or greater than both file-structure and db-structure
    if(AppDbVersion<structurefl || AppDbVersion<structuredb.Version){break;}
    
    // define read-structure; maximal read-structure is the lowest version between file-structure & db-structure
    structure=structurefl; if(structuredb.Version<structurefl){structure=structuredb.Version;}

    // prepare read data from file and insert to database
    fis=new FileInputStream(SrcFile);
    bis=new BufferedInputStream(fis, 8192);
    dis=new DataInputStream(bis);
    if(structurefl!=0){dis.skip(11); dis.readInt();}
    
    TblCount=DbStructBackupTables.size();
    
    switchGetCurrDatabase(VStm, ret, CurrDatabase);
    
    VStm.execute("use "+DestDb+";");
    
    dropTrigger(VStm, DestDb);
    VStm.execute("set foreign_key_checks=0;");
    
    Progress.inform(2, null, null);
    
    dbtbl=getTablesInADatabase(VStm, DestDb); if(dbtbl==null){break;}
    dbtbl_count=dbtbl.size(); if(dbtbl_count==0){break;}
    tbl_unbackup=getTablesNotIncludeInBackup();
    progress_increment=(1d/(double)dbtbl_count)*38;
    dbtbl_temp=0;
    do{
     tblname=dbtbl.elementAt(dbtbl_temp);
     if(PText.findElement(tbl_unbackup, tblname, false)==-1){
      /* truncate */
      VStm.execute("truncate table "+DestDb+"."+tblname+";");
      /* truncate's alternative
      VStm.execute("create table "+DestDb+"."+dbtbl.elementAt(dbtbl_temp)+"_new like "+DestDb+"."+dbtbl.elementAt(dbtbl_temp)+";");
      VStm.execute("drop table "+DestDb+"."+dbtbl.elementAt(dbtbl_temp)+";");
      VStm.execute("alter table "+DestDb+"."+dbtbl.elementAt(dbtbl_temp)+"_new rename to "+DestDb+"."+dbtbl.elementAt(dbtbl_temp)+";");
      */
     }
     
     Progress.inform(progress_increment, null, null);
     dbtbl_temp=dbtbl_temp+1;
    }while(dbtbl_temp!=dbtbl_count);
    
    EachInsertCount=400;
    
    Progress.inform(0, "Memasukkan data dari file ke database...", "-");
    
    // inserting tables's data
    Progress.inform(0, null, "memasukkan data ke dalam tabel");
    progress_increment=(1d/(double)TblCount)*50;
    
    TblCurr=0;
    do{
     Tbl=DbStructBackupTables.elementAt(TblCurr);
     
     if(structure>=Tbl.SinceVersion && Tbl.IncludeInBackup){
      temp=dis.readLong();
      if(temp!=0){
       Cols=Tbl.Columns;
       ColCount=Cols.size();
       
       // generate Columns
       Columns=new StringBuilder();
       ColCurr=0;
       firstcol=true;
       do{
        Col=Cols.elementAt(ColCurr);
        if(structurefl>=Col.SinceVersion && structuredb.Version>=Col.SinceVersion){
         if(firstcol){firstcol=false;}else{Columns.append(',');}
         Columns.append(Col.Name);
        }
        ColCurr=ColCurr+1;
       }while(ColCurr!=ColCount);
       
       // doing operation
       temp_=0;
       do{
        str=new StringBuilder("insert into "+DestDb+"."+Tbl.Name+" ("+Columns.toString()+") values ");
        CurrIns=0;
        InsUntil=EachInsertCount;
        if(temp-temp_<InsUntil){InsUntil=(int)(temp-temp_);}
        first=true;
        do{
         if(first){first=false;}else{str.append(',');}
         str.append('(');
         
         ColCurr=0;
         firstcol=true;
         do{
          Col=Cols.elementAt(ColCurr);
          if(structurefl>=Col.SinceVersion){
           isnull=false;
           
           // read column from file
           do{
            coltype_fl=getDatabaseTableColomnType(Col.ColumnTypes, structurefl);
            if(coltype_fl.Nullable){isnull=!dis.readBoolean(); if(isnull){break;}}
            switch(coltype_fl.Type){
             case CCore.TypeString : value.initString(dis.readUTF()); break;
             case CCore.TypeInteger : value.initInteger(dis.readInt(), false); break;
             case CCore.TypeLong : value.initLong(dis.readLong(), false); break;
             case CCore.TypeDouble : value.initDouble(dis.readDouble(), false); break;
             case CCore.TypeBoolean : value.initBoolean(dis.readBoolean()); break;
             case CCore.TypeDate : cal.setNewTimeInMillis(dis.readLong()); value.initDate(cal.getTime()); break;
            }
           }while(false);

           // write column to database
           if(structuredb.Version>=Col.SinceVersion){
            do{
             coltype_db=getDatabaseTableColomnType(Col.ColumnTypes, structuredb.Version);
             if(firstcol){firstcol=false;}else{str.append(',');}
             if(isnull){str.append(CCore.vNull); break;}
             switch(coltype_db.Type){
              case CCore.TypeString : str.append(PDatabase.getSQLString(value.getValueString(), CCore.TypeString, CCore.vNull, false));break;
              case CCore.TypeInteger : str.append(PDatabase.getSQLString(value.getValueInteger(), CCore.TypeInteger, CCore.vNull, false)); break;
              case CCore.TypeLong : str.append(PDatabase.getSQLString(value.getValueLong(), CCore.TypeLong, CCore.vNull, false)); break;
              case CCore.TypeDouble : str.append(PDatabase.getSQLString(value.getValueDouble(), CCore.TypeDouble, CCore.vNull, false)); break;
              case CCore.TypeBoolean : str.append(PDatabase.getSQLString(value.getValueBoolean(), CCore.TypeBoolean, CCore.vNull, false)); break;
              case CCore.TypeDate : str.append(PDatabase.getSQLString(value.getValueDate(), CCore.TypeDate, CCore.vNull, false)); break;
             }
            }while(false);
           }
           
          }
          ColCurr=ColCurr+1;
         }while(ColCurr!=ColCount);
         
         str.append(')');
         CurrIns=CurrIns+1;
        }while(CurrIns!=InsUntil);
        VStm.execute(str.toString());
        
        temp_=temp_+InsUntil;
       }while(temp_!=temp);
      }
     }
     TblCurr=TblCurr+1;
     Progress.inform(progress_increment, null, null);
    }while(TblCurr!=TblCount);
    
    // executing initial procedures
    Progress.inform(0, null, "eksekusi prosedur awal");
    ProcCount=DbStructBackupProcedures.size();
    progress_increment=(1d/(double)ProcCount)*10;
    
    ProcCurr=0;
    do{
     Proc=DbStructBackupProcedures.elementAt(ProcCurr);
     
     if(
      (structuredb.Version==Proc.SinceVersion.Version && structuredb.SubVariant>=Proc.SinceVersion.SubVariant) ||
      (structuredb.Version>Proc.SinceVersion.Version)){
      try{VStm.execute("call "+Proc.Name+"()");}catch(Exception E){}
     }
     
     ProcCurr=ProcCurr+1;
     Progress.inform(progress_increment, null, null);
    }while(ProcCurr!=ProcCount);
   }
   catch(Exception E_){break;}
   ret[0]=1;
  }while(false);
  if(dis!=null){
   try{dis.close();}catch(Exception E){}
  }
  if(bis!=null){
   try{bis.close();}catch(Exception E){}
  }
  if(fis!=null){
   try{fis.close();}catch(Exception E){}
  }
  try{VStm.execute("set foreign_key_checks=1;");}catch(Exception E){}
  try{createTrigger(VStm, DestDb);}catch(Exception E){}
  
  switchReswitchToCurrDatabase(VStm, ret, CurrDatabase);
  
  return ret;
 }

 public static int queryDatabaseToModel(Statement Stm, OCustomModel Mdl){
  // query format : database name (string), database version (string, version & subvariant)
  int ret=0; // -1 error, >=0 application database count
  LinkedList<String> LL;
  ResultSet Rs;
  Vector<Object[]> Rows=Mdl.getRows();
  int mdl_size=Rows.size();
  String db;
  String str=null;
  ODatabaseVersion dbstruct;
  
  try{
   Stm.execute("show databases;");
   
   Rs=Stm.getResultSet();
   if(Rs.next()){
    LL=new LinkedList<String>();
    do{
     LL.add(Rs.getString(1));
    }while(Rs.next());
    
    do{
     db=LL.pop();
     
     do{
      if(!checkTablesStructure(Stm, db)){break;}
      dbstruct=getDatabaseVersion(Stm, db); if(dbstruct==null){break;}
      
      str=dbstruct.Version+"-"+dbstruct.SubVariant;
      
      Rows.addElement(PCore.objArrVariant(db, str));
      ret=ret+1;
     }while(false);
      
    }while(LL.size()!=0);
   }
  }
  catch(Exception E){ret=-1;}
  
  if(ret>0){Mdl.refreshInsert(mdl_size, mdl_size+(ret-1));}
  
  return ret;
 }
 
 public static Vector<String> getTablesInADatabase(Statement Stm, String DatabaseName){
  Vector<String> ret=null;
  Vector<String> rettemp=new Vector();
  ResultSet rs;
  
  do{
   try{
    rs=Stm.executeQuery("show tables from "+DatabaseName+";");
    if(rs.next()){
     do{
      rettemp.addElement(rs.getString(1));
     }while(rs.next());
    }
   }
   catch(Exception E_){break;}
   ret=rettemp;
  }while(false);
   
  return ret;
 }
 private static Vector<String> getTablesNotIncludeInBackup(){
  Vector<String> ret=new Vector();
  ODatabaseTable Tbl;
  int temp, length;
  
  length=DbStructBackupTables.size();
  temp=0;
  do{
   Tbl=DbStructBackupTables.elementAt(temp);
   if(!Tbl.IncludeInBackup){ret.addElement(Tbl.Name);}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 private static boolean checkTablesStructure(Statement Stm, String DatabaseName){
  boolean ret=false;
  do{
   try{
    /* whole database check */
    if(Stm.executeUpdate("show tables from "+DatabaseName+";")<17) break;
    
    /* item - included check */
    if(Stm.executeUpdate("show columns from Item from "+DatabaseName+";")<13) break;
    if(Stm.executeUpdate("show columns from ItemXCategory from "+DatabaseName+";")<2) break;
    
    /* item - excluded check
    if(Stm.executeUpdate("show columns from StockUnit from "+DatabaseName+";")<2) break;
    if(Stm.executeUpdate("show columns from CategoryOfItem from "+DatabaseName+";")<2) break;
    if(Stm.executeUpdate("show columns from ItemXPicture from "+DatabaseName+";")<3) break;
    if(Stm.executeUpdate("show columns from ItemXSupplier from "+DatabaseName+";")<4) break;
    */
    
    /* subject - included check */
    if(Stm.executeUpdate("show columns from Subject from "+DatabaseName+";")<4) break;
    if(Stm.executeUpdate("show columns from SubjectXCategory from "+DatabaseName+";")<2) break;
    
    /* subject - excluded check
    if(Stm.executeUpdate("show columns from CategoryOfSubject from "+DatabaseName+";")<2) break;
    if(Stm.executeUpdate("show columns from SubjectXAddress from "+DatabaseName+";")<4) break;
    if(Stm.executeUpdate("show columns from City from "+DatabaseName+";")<2) break;
    if(Stm.executeUpdate("show columns from SubjectXContact from "+DatabaseName+";")<4) break;
    if(Stm.executeUpdate("show columns from ContactType from "+DatabaseName+";")<2) break;
    */
    
    /* trans - included check */
    if(Stm.executeUpdate("show columns from Trans from "+DatabaseName+";")<6) break;
    if(Stm.executeUpdate("show columns from TransType from "+DatabaseName+";")<2) break;
    
    /* trans - excluded check
    if(Stm.executeUpdate("show columns from TransXItemOut from "+DatabaseName+";")<4) break;
    if(Stm.executeUpdate("show columns from TransXItemIn from "+DatabaseName+";")<4) break;
    */
    
    ret=true;
   }
   catch(SQLException E_){}
  }while(false);
  return ret;
 }
 
 private static ODatabaseTableColumnType getDatabaseTableColomnType(OVector<ODatabaseTableColumnType> ColumnTypes, int CurrVersion){
  ODatabaseTableColumnType ret=null;
  int temp;
  ODatabaseTableColumnType coltype;
  
  temp=ColumnTypes.size()-1;
  do{
   coltype=ColumnTypes.elementAt(temp);
   if(CurrVersion>=coltype.SinceVersion){ret=coltype; break;}
   temp=temp-1;
  }while(temp!=-1);
  
  return ret;
 }
 private static void switchGetCurrDatabase(Statement Stm, int[] state, OAnObject CurrDatabase) throws Exception{
  // get curr database
  CurrDatabase.Obj=PDatabase.getCurrentDatabase(Stm);
  state[1]=-1;
 }
 private static void switchReswitchToCurrDatabase(Statement Stm, int[] state, OAnObject CurrDatabase){
  // re-switch to curr database
  if(state[1]==-1){
   try{
    if(CurrDatabase.Obj!=null){Stm.execute("use "+CurrDatabase.Obj+";");}
    state[1]=1;
   }
   catch(Exception E){state[1]=-1;}
  }
 }

}