import javax.swing.AbstractSpinnerModel;

public class OCustomSpinnerModelNumber extends AbstractSpinnerModel {

 boolean IsLong;
 Object CurrData;
 
 int OperationMode;
 double CalculationValue;
 
 double DataMinValue;
 double DataMaxValue;
 
 public OCustomSpinnerModelNumber(int OperationMode, double CalculationValue, double DataMinValue, double DataMaxValue,
  Object CurrData, boolean IsLong) {
  this.OperationMode=OperationMode;
  this.CalculationValue=CalculationValue;
  this.DataMinValue=DataMinValue;
  this.DataMaxValue=DataMaxValue;
  setData(CurrData, IsLong);
 }
 
 public void setData(Object CurrData, boolean IsLong){
  this.CurrData=CurrData;
  this.IsLong=IsLong;
 }
 public void changeData(Object CurrData, boolean IsLong){
  setData(CurrData, IsLong);
  fireStateChanged();
 }

 public boolean isCalculationResultValid(double CalculationResult){
  return CalculationResult>=DataMinValue && CalculationResult<=DataMaxValue;
 }
 private Object getPreviousNextValue(boolean IsPreviousValue){
  Object ret=null;
  double result;
  int MathOperation;
  
  if(CurrData==null){return ret;}
  
  MathOperation=PCore.subtBool_Int(IsPreviousValue,
   PCore.subtBool_Int(OperationMode==CMath.AddMinus, CMath.Minus, CMath.Divide),
   PCore.subtBool_Int(OperationMode==CMath.AddMinus, CMath.Add, CMath.Times));
  
  result=PMath.calculate(PCore.getValueLongDouble(CurrData, IsLong, 0), CalculationValue, MathOperation, false, 0);
  if(!isCalculationResultValid(result)){return CurrData;}
  
  if(IsLong){CurrData=(long)result;}
  else{CurrData=(double)result;}
  ret=CurrData;
  
  return ret;
 }
 public Object getNextValue() {return getPreviousNextValue(false);}
 public Object getPreviousValue() {return getPreviousNextValue(true);}
 public Object getValue() {
  Object ret=null;
  
  if(CurrData==null){return ret;}
  
  ret=PCore.getValueLongDouble(ret, IsLong, 0);
  
  return ret;
 }
 public void setValue(Object value){}
 
}