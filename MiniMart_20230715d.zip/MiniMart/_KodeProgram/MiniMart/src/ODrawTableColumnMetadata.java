public class ODrawTableColumnMetadata {
 
 String Name; 
 double Width;
  
	ODrawTableColumnMetadata(String Name, double Width){
		this.Name=Name;
		this.Width=Width;
	}
 
}