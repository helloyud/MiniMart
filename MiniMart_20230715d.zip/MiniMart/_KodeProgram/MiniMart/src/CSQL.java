

public class CSQL {
 
 //
 static String UserPriv_CreateTableTemp = "create temporary tables";
 
 //
 static String TableTemp_Postfix = "_Temp";
 public static String getTableTemp(String TableName){return TableName+TableTemp_Postfix;}
 
}