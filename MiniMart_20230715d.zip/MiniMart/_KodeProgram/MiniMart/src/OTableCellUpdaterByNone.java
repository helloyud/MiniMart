public class OTableCellUpdaterByNone
 extends OTableCellUpdater{

 public OTableCellUpdaterByNone(int TableColumnIndex){
  init(TableColumnIndex);
 }

 public void update(int TableRowIndex) {
  
 }

}