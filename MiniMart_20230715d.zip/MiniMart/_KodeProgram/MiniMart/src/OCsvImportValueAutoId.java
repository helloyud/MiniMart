import java.sql.Statement;
import java.util.Vector;

public class OCsvImportValueAutoId extends OCsvImportValue {
 
 OBarcodeGenerator BarcodeGen;
 Statement Stm;
 String Query;
 
 public OCsvImportValueAutoId(OBarcodeGenerator BarcodeGen, Statement Stm, String Query){
  initVariables(BarcodeGen, Stm, Query);
 }
 
 public void initVariables(OBarcodeGenerator BarcodeGen, Statement Stm, String Query){
  this.BarcodeGen=BarcodeGen;
  this.Stm=Stm;
  this.Query=Query;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  preGenerateSQLValue(LastReadRecordFromFile);
 }
 
 public OGeneratedSQLValue generateSQLValue(){
  OGeneratedSQLValue ret=new OGeneratedSQLValue();
  Long Id;
  
  Id=PDatabase.generateNewId(BarcodeGen, Stm, Query);
  if(Id!=null){ret.setGeneratedSQLValue(PDatabase.getSQLString(Id, CCore.TypeLong, CCore.vNull, false));}
  
  return ret;
 }

}