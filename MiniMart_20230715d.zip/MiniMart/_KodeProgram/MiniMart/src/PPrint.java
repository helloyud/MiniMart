import java.awt.print.Book;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.Attribute;
import javax.print.attribute.AttributeSet;
import javax.print.attribute.DocAttribute;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintJobAttribute;
import javax.print.attribute.PrintRequestAttribute;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttribute;
import javax.print.attribute.standard.DocumentName;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.PrintQuality;

public class PPrint {
 
 public static boolean print(Book Doc, PrintService Printer, String PrintJobTitle, boolean HighQuality){
  boolean ret=false;
  DocPrintJob printjob;
  DocAttributeSet attrset_doc=null;
  PrintRequestAttributeSet attrset_printreq=null;
  try{
   printjob=Printer.createPrintJob();
   
   attrset_doc=new HashDocAttributeSet();
   attrset_printreq=new HashPrintRequestAttributeSet();
   attributeSetAdd(attrset_printreq, 3, printjob.getAttributes());
   if(PrintJobTitle!=null){
    if(PrintJobTitle.length()!=0){
     attrset_doc.add(new DocumentName(PrintJobTitle, null));
     attrset_printreq.add(new JobName(PrintJobTitle, null));
    }
   }
   if(HighQuality){
    attrset_doc.add(PrintQuality.HIGH);
    attrset_printreq.add(PrintQuality.HIGH);
   }
   
   printjob.print(new SimpleDoc(Doc, DocFlavor.SERVICE_FORMATTED.PAGEABLE, attrset_doc), attrset_printreq);
   
   ret=true;
  }
  catch(Exception E){}
  return ret;
 }

 public static Book subPage(Book OldBook, int[] PageIndex){
  // PageIndex must have been sorted ascending
  Book ret=OldBook;
  Book rettemp=null;
  int PageCount, temp, count, currpage;
  boolean NotAdded;
  
  PageCount=PageIndex.length;
  if(PageCount!=0){
   count=OldBook.getNumberOfPages();
   rettemp=new Book();
   NotAdded=true;
   
   temp=0;
   do{
    currpage=PageIndex[temp];
    if(currpage<count){
     rettemp.append(OldBook.getPrintable(currpage), OldBook.getPageFormat(currpage));
     if(NotAdded){NotAdded=false;}
    }
    temp=temp+1;
   }while(temp!=PageCount);
   if(!NotAdded){ret=rettemp;}
  }
  
  return ret;
 }
 public static Book combineBooks(Vector<Book> Books){
  Book ret=null;
  Book rettemp, bookcurr;
  int temp, length, pagecurr, pagelength;
  
  do{
   if(Books==null){break;}
   length=Books.size(); if(length==0){break;}
   
   temp=0; rettemp=new Book();
   do{
    do{
     bookcurr=Books.elementAt(temp); if(bookcurr==null){break;}
     pagelength=bookcurr.getNumberOfPages(); if(pagelength==0){break;}
     
     pagecurr=0;
     do{
      rettemp.append(bookcurr.getPrintable(pagecurr), bookcurr.getPageFormat(pagecurr));
      pagecurr=pagecurr+1;
     }while(pagecurr!=pagelength);
    }while(false);
    
    temp=temp+1;
   }while(temp!=length);
   if(rettemp.getNumberOfPages()==0){break;}
   
   ret=rettemp;
  }while(false);
  
  return ret;
 }

 public static PrintService getOperatingSystemDefaultPrinter(PrintService[] Printers){
  PrintService ret=null;
  PrintService rettemp;
  PrintService[] AvailablePrinters;
  
  do{
   rettemp=PrintServiceLookup.lookupDefaultPrintService();
   if(rettemp==null){
    AvailablePrinters=Printers; if(AvailablePrinters==null){AvailablePrinters=PrintServiceLookup.lookupPrintServices(null, null);}
    if(AvailablePrinters==null){break;}
    if(AvailablePrinters.length==0){break;}
    rettemp=AvailablePrinters[0];
   }
   ret=rettemp;
  }while(false);
  
  return ret;
 }
 public static int findIndex(PrintService[] Printers, String SearchPrinter){
  int ret=-1;
  int temp, temp_;
  
  temp=Printers.length;
  if(temp!=0){
   temp_=0;
   do{
    if(PText.compare(SearchPrinter, Printers[temp_].getName(), false)){
     ret=temp_;
     break;
    }
    temp_=temp_+1;
   }while(temp_!=temp);
  }
  
  return ret;
 }
 
 public static int fillPrinters(Vector<Object[]> Data){
  // Fill format : PrintService, PrintService's Name
  int ret=0;
  PrintService[] Printers;
  Object[] Obj;
  do{
   try{
    Printers=PrintServiceLookup.lookupPrintServices(null, null);
    if(Printers==null){break;}
    if(Printers.length==0){break;}
    do{
     Obj=new Object[2];
     Obj[0]=Printers[ret];
     Obj[1]=Printers[ret].getName();
     Data.addElement(Obj);
     ret=ret+1;
    }while(ret!=Printers.length);
   }
   catch(Exception E){}
  }while(false);
  return ret;
 }
 public static int fillPrinters(OCustomModel Mdl){
  int ret;
  Vector<Object[]> Data=Mdl.getRows();
  int mdl_size=Data.size();
  ret=fillPrinters(Data);
  if(ret>0){Mdl.refreshInsert(mdl_size, mdl_size+(ret-1));}
  return ret;
 }
 public static int fillPapers(Vector<Object[]> Data, Vector<OPaper> Papers){
  // Fill format : OPaper, Id, Name+Description
  int ret=0;
  int temp, papers_count;
  Object[] Obj;
  OPaper papr;
  if(Papers==null){return ret;}
  papers_count=Papers.size();
  if(papers_count==0){return ret;}
  temp=0;
  do{
   Obj=new Object[3];
   papr=Papers.elementAt(temp);
   Obj[0]=papr;
   Obj[1]=papr.Id;
   Obj[2]=papr.Name+PText.getStringObj(papr.Description, "", " "+papr.Description, false);
   Data.addElement(Obj);
   temp=temp+1;
  }while(temp!=papers_count);
  ret=papers_count;
  return ret;
 }
 public static int fillPapers(OCustomModel Mdl, Vector<OPaper> Papers){
  int ret;
  Vector<Object[]> Data=Mdl.getRows();
  int mdl_size=Data.size();
  ret=fillPapers(Data, Papers);
  if(ret>0){Mdl.refreshInsert(mdl_size, mdl_size+(ret-1));}
  return ret;
 }
 public static void generatePageListToTable(OCustomTableModel TableMdl, int PageCount, boolean InitialValue){
  int befcount, temp;
  Object[] Objs;
  
  if(PageCount==0){return;}
  
  befcount=TableMdl.Mdl.Rows.size();
  temp=0;
  do{
   Objs=new Object[2];
   Objs[0]=new Integer(temp+1);
   Objs[1]=new Boolean(InitialValue);
   TableMdl.Mdl.Rows.addElement(Objs);
   temp=temp+1;
  }while(temp!=PageCount);
  
  TableMdl.refreshInsert(befcount, befcount+(PageCount-1));
 }

 private static void attributeSetAdd(AttributeSet AttrSet, int AttrSetType, AttributeSet AttrSetAdd){
  // AttributeType : 1 - DocAttributeSet, 2 - PrintJobAttributeSet, 3 - PrintRequestAttributeSet, 4 - PrintServiceAttributeSet
  int count, temp;
  Attribute[] Attr=AttrSetAdd.toArray();
  count=Attr.length;
  if(count!=0){
   temp=0;
   do{
    switch(AttrSetType){
     case 1 : if(Attr[temp] instanceof DocAttribute){AttrSet.add(Attr[temp]);} break;
     case 2 : if(Attr[temp] instanceof PrintJobAttribute){AttrSet.add(Attr[temp]);} break;
     case 3 : if(Attr[temp] instanceof PrintRequestAttribute){AttrSet.add(Attr[temp]);} break;
     case 4 : if(Attr[temp] instanceof PrintServiceAttribute){AttrSet.add(Attr[temp]);} break;
    }
    
    temp=temp+1;
   }while(temp!=count);
  }
 }
 
 public static LinkedList<OPrintInfoLabel> generateTestPrintLabels(OPaperLabel PaperLabel, OLabelDataTestPrint LabelData){
  LinkedList<OPrintInfoLabel> ret=new LinkedList();
  OPrintInfoLabel PrintInfoLabel=new OPrintInfoLabel(LabelData, PaperLabel.ColumnCount*PaperLabel.RowCount);
  
  ret.addLast(PrintInfoLabel);
  
  return ret;
 }

}