import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_TransFinishSummary extends XFormDialog {
 
 // set
 int wCashInId; String wCashInName; String wCashInComment;
 int wItemsOutCount; int wItemsOutCheckCount;
 double wItemsOutPrice;
 
 int wCashOutId; String wCashOutName; String wCashOutComment;
 int wItemsInCount; int wItemsInCheckCount;
 double wItemsInPrice;
 
 //
 double SummaryPrice, SummaryPrice_Positive;
 double CheckedSummaryReceive;
 double CheckedSummaryReturn;
 
 final String PositiveSign="( + )  ";
 final String NegativeSign="( - )  ";
 
 int DocumentListenerFocus;
 boolean EnableDocumentListener;
 
 public F_TransFinishSummary(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  TF_SummaryPaymentReceive.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener){
      inputSummaryPaymentReceive();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener){
      inputSummaryPaymentReceive();
     }
    }
   });
  
  TF_SummaryPaymentReturn.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener){
      inputSummaryPaymentReturn();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener){
      inputSummaryPaymentReturn();
     }
    }
   });
  
  EnableDocumentListener=true;
  
  clearComponents();
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_SummaryPaymentReceive,
    TF_SummaryPaymentReturn,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f-11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 
 void clearComponents(){
  clearGUIComponents();
  clearSetVariables();
 }
 void clearGUIComponents(){
  EnableDocumentListener=false;
  
  PGUI.clearText(TF_CashIn, TF_CashInComment, TF_CashIn_ItemsCount, TF_CashIn_ItemsPrice,
   TF_CashOut, TF_CashOutComment, TF_CashOut_ItemsCount, TF_CashOut_ItemsPrice,
   TF_SummaryPrice, TF_SummaryPaymentReceive, TF_SummaryPaymentReturn);
  
  EnableDocumentListener=true;
 }
 void clearSetVariables(){
  wCashInName=null; wCashInComment=null;
  wCashOutName=null; wCashOutComment=null;
 }
 
 void fillSetVariables(
  int wCashInId, String wCashInName, String wCashInComment, int wItemsOutCount, int wItemsOutCheckCount, double wItemsOutPrice,
  int wCashOutId, String wCashOutName, String wCashOutComment, int wItemsInCount, int wItemsInCheckCount, double wItemsInPrice){
  this.wCashInId=wCashInId;
  this.wCashInName=wCashInName;
  this.wCashInComment=wCashInComment;
  this.wItemsOutCount=wItemsOutCount;
  this.wItemsOutCheckCount=wItemsOutCheckCount;
  this.wItemsOutPrice=wItemsOutPrice;

  this.wCashOutId=wCashOutId;
  this.wCashOutName=wCashOutName;
  this.wCashOutComment=wCashOutComment;
  this.wItemsInCount=wItemsInCount;
  this.wItemsInCheckCount=wItemsInCheckCount;
  this.wItemsInPrice=wItemsInPrice;
 }
 boolean appear(
  int wCashInId, String wCashInName, String wCashInComment, int wItemsOutCount, int wItemsOutCheckCount, double wItemsOutPrice,
  int wCashOutId, String wCashOutName, String wCashOutComment, int wItemsInCount, int wItemsInCheckCount, double wItemsInPrice){
  fillSetVariables(
   wCashInId, wCashInName, wCashInComment, wItemsOutCount, wItemsOutCheckCount, wItemsOutPrice,
   wCashOutId, wCashOutName, wCashOutComment, wItemsInCount, wItemsInCheckCount, wItemsInPrice);
  
  return showForm();
 }
 void calcSummaryPrice(){
  SummaryPrice=wItemsOutPrice-wItemsInPrice;
  SummaryPrice_Positive=PCore.subtBool_Double(SummaryPrice>=0, SummaryPrice, -1*SummaryPrice);
 }
 void calcSummaryReceive(){CheckedSummaryReceive=SummaryPrice_Positive+CheckedSummaryReturn;}
 void calcSummaryReturn(){CheckedSummaryReturn=CheckedSummaryReceive-SummaryPrice_Positive;}
 void calcSummary(){
  calcSummaryPrice();
  CheckedSummaryReceive=0;
  calcSummaryReturn();
 }
 void fillGUIComponentsWithSetVariables(){
  EnableDocumentListener=false;
  
  calcSummary();
  
  TF_CashIn.setText(PText.getString(wCashInId, -1, wCashInName, ""));
  TF_CashInComment.setText(PText.getString(wCashInComment, "", false));
  TF_CashIn_ItemsCount.setText(PText.intToString(wItemsOutCount)+"  ( "+PText.intToString(wItemsOutCheckCount)+" )");
  TF_CashIn_ItemsPrice.setText(PText.signedPriceToString(wItemsOutPrice, false, PositiveSign, false, NegativeSign, true, true));
  
  TF_CashOut.setText(PText.getString(wCashOutId, -1, wCashOutName, ""));
  TF_CashOutComment.setText(PText.getString(wCashOutComment, "", false));
  TF_CashOut_ItemsCount.setText(PText.intToString(wItemsInCount)+"  ( "+PText.intToString(wItemsInCheckCount)+" )");
  TF_CashOut_ItemsPrice.setText(PText.signedPriceToString(wItemsInPrice, false, PositiveSign, false, NegativeSign, true, false));
  
  TF_SummaryPrice.setText(PText.signedPriceToString(SummaryPrice, true, PositiveSign, true, NegativeSign, false, true));
  TF_SummaryPaymentReceive.setText(PText.doubleToString(CheckedSummaryReceive, true));
  TF_SummaryPaymentReturn.setText(PText.doubleToString(CheckedSummaryReturn, true));
  
  EnableDocumentListener=true;
 }
 void inputSummaryPaymentReceive(){
  try{
   CheckedSummaryReceive=Double.parseDouble(TF_SummaryPaymentReceive.getText());
   
   // effect Summary Payment Return
   calcSummaryReturn();
   changeDocument(TF_SummaryPaymentReturn, PText.doubleToString(CheckedSummaryReturn, true));
  }
  catch(Exception E){CheckedSummaryReceive=-1;}
 }
 void inputSummaryPaymentReturn(){
  try{
   CheckedSummaryReturn=Double.parseDouble(TF_SummaryPaymentReturn.getText());
   
   // effect Summary Payment Receive
   calcSummaryReceive();
   changeDocument(TF_SummaryPaymentReceive, PText.doubleToString(CheckedSummaryReceive, true));
  }
  catch(Exception E){CheckedSummaryReturn=-1;}
 }
 void changeDocument(JTextField TF, String Str){
  EnableDocumentListener=false;
  TF.setText(Str);
  EnableDocumentListener=true;
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_CashIn_ItemsPrice = new javax.swing.JTextField();
  Lbl_Title = new javax.swing.JLabel();
  TF_CashIn_ItemsCount = new javax.swing.JTextField();
  Lbl_CashIn = new javax.swing.JLabel();
  Lbl_CashOut = new javax.swing.JLabel();
  TF_CashOut_ItemsPrice = new javax.swing.JTextField();
  TF_CashOut_ItemsCount = new javax.swing.JTextField();
  TF_SummaryPrice = new javax.swing.JTextField();
  jSeparator1 = new javax.swing.JSeparator();
  Lbl_SummaryPrice = new javax.swing.JLabel();
  TF_SummaryPaymentReceive = new javax.swing.JTextField();
  Lbl_SummaryPaymentReceive = new javax.swing.JLabel();
  TF_SummaryPaymentReturn = new javax.swing.JTextField();
  Lbl_SummaryPaymentReturn = new javax.swing.JLabel();
  jSeparator2 = new javax.swing.JSeparator();
  jSeparator3 = new javax.swing.JSeparator();
  jPanel1 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_FinishConfirmation = new javax.swing.JLabel();
  jSeparator4 = new javax.swing.JSeparator();
  TF_CashInComment = new javax.swing.JTextField();
  TF_CashOutComment = new javax.swing.JTextField();
  Lbl_CashIn2 = new javax.swing.JLabel();
  Lbl_CashOut2 = new javax.swing.JLabel();
  jSeparator5 = new javax.swing.JSeparator();
  jSeparator6 = new javax.swing.JSeparator();
  TF_CashIn = new javax.swing.JTextField();
  TF_CashOut = new javax.swing.JTextField();
  jSeparator7 = new javax.swing.JSeparator();
  jSeparator8 = new javax.swing.JSeparator();
  jSeparator9 = new javax.swing.JSeparator();
  jSeparator10 = new javax.swing.JSeparator();

  setTitle("Konfirmasi Penyelesaian Transaksi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_CashIn_ItemsPrice.setEditable(false);
  TF_CashIn_ItemsPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashIn_ItemsPrice.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_CashIn_ItemsPrice.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_CashIn_ItemsPrice.setToolTipText("Harga barang keluar");

  Lbl_Title.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  Lbl_Title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_Title.setText("Rangkuman Transaksi");

  TF_CashIn_ItemsCount.setEditable(false);
  TF_CashIn_ItemsCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashIn_ItemsCount.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_CashIn_ItemsCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_CashIn_ItemsCount.setToolTipText("Jumlah barang keluar (jumlah cek)");

  Lbl_CashIn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_CashIn.setText("Bayar Masuk Tunai");

  Lbl_CashOut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_CashOut.setText("Bayar Keluar Tunai");

  TF_CashOut_ItemsPrice.setEditable(false);
  TF_CashOut_ItemsPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashOut_ItemsPrice.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_CashOut_ItemsPrice.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_CashOut_ItemsPrice.setToolTipText("Harga barang masuk");

  TF_CashOut_ItemsCount.setEditable(false);
  TF_CashOut_ItemsCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashOut_ItemsCount.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_CashOut_ItemsCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_CashOut_ItemsCount.setToolTipText("Jumlah barang masuk (jumlah cek)");

  TF_SummaryPrice.setEditable(false);
  TF_SummaryPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryPrice.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_SummaryPrice.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

  Lbl_SummaryPrice.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_SummaryPrice.setText("Total Harga");

  TF_SummaryPaymentReceive.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_SummaryPaymentReceive.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_SummaryPaymentReceive.setToolTipText("Bisa dikosongkan ; Tekan {Enter} untuk menyelesaikan transaksi");
  TF_SummaryPaymentReceive.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SummaryPaymentReceiveFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_SummaryPaymentReceiveFocusLost(evt);
   }
  });
  TF_SummaryPaymentReceive.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SummaryPaymentReceiveKeyPressed(evt);
   }
  });

  Lbl_SummaryPaymentReceive.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_SummaryPaymentReceive.setText("Pembayaran");

  TF_SummaryPaymentReturn.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
  TF_SummaryPaymentReturn.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_SummaryPaymentReturn.setToolTipText("Bisa dikosongkan ; Tekan {Enter} untuk menyelesaikan transaksi");
  TF_SummaryPaymentReturn.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SummaryPaymentReturnFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_SummaryPaymentReturnFocusLost(evt);
   }
  });
  TF_SummaryPaymentReturn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SummaryPaymentReturnKeyPressed(evt);
   }
  });

  Lbl_SummaryPaymentReturn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_SummaryPaymentReturn.setText("Kembalian");

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_FinishConfirmation.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_FinishConfirmation.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  Lbl_FinishConfirmation.setText("Selesaikan Transaksi ?");

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addComponent(Lbl_FinishConfirmation, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok)
    .addComponent(Lbl_FinishConfirmation))
  );

  TF_CashInComment.setEditable(false);
  TF_CashInComment.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashInComment.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_CashInComment.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_CashInComment.setToolTipText("Keterangan kas masuk tunai");

  TF_CashOutComment.setEditable(false);
  TF_CashOutComment.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashOutComment.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_CashOutComment.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_CashOutComment.setToolTipText("Keterangan kas keluar tunai");

  Lbl_CashIn2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_CashIn2.setText("{ Barang Keluar }");

  Lbl_CashOut2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_CashOut2.setText("{ Barang Masuk }");

  TF_CashIn.setEditable(false);
  TF_CashIn.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashIn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_CashIn.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_CashIn.setToolTipText("Kas masuk tunai");

  TF_CashOut.setEditable(false);
  TF_CashOut.setBackground(new java.awt.Color(204, 255, 204));
  TF_CashOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_CashOut.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_CashOut.setToolTipText("Kas keluar tunai");

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_Title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jSeparator6)
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Lbl_CashIn, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
       .addComponent(jSeparator3)
       .addComponent(Lbl_CashIn2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jSeparator7)
       .addComponent(Lbl_CashOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Lbl_CashOut2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(TF_CashInComment, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
       .addComponent(TF_CashOutComment)
       .addComponent(jSeparator8)
       .addComponent(jSeparator4)
       .addComponent(TF_CashOut)
       .addComponent(TF_CashIn))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(jSeparator9)
       .addComponent(Lbl_SummaryPaymentReceive, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
       .addComponent(Lbl_SummaryPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jSeparator2)
       .addComponent(Lbl_SummaryPaymentReturn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(TF_CashOut_ItemsCount)
       .addComponent(TF_CashIn_ItemsCount))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_SummaryPrice, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_CashOut_ItemsPrice)
       .addComponent(TF_SummaryPaymentReceive)
       .addComponent(TF_SummaryPaymentReturn)
       .addComponent(jSeparator10)
       .addComponent(TF_CashIn_ItemsPrice))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_Title)
      .addGap(18, 18, 18)
      .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_CashIn_ItemsPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_CashIn_ItemsCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Lbl_CashIn)
       .addComponent(TF_CashIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_CashInComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Lbl_CashIn2))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(jSeparator9)
       .addComponent(jSeparator10)
       .addComponent(jSeparator8)
       .addComponent(jSeparator7))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_CashOut_ItemsPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_CashOut_ItemsCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Lbl_CashOut)
       .addComponent(TF_CashOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(Lbl_CashOut2)
       .addComponent(TF_CashOutComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(jSeparator4)
       .addComponent(jSeparator2)
       .addComponent(jSeparator1)))
     .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SummaryPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SummaryPrice))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SummaryPaymentReceive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SummaryPaymentReceive))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SummaryPaymentReturn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SummaryPaymentReturn))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, Short.MAX_VALUE)
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  fillGUIComponentsWithSetVariables();
  TF_SummaryPaymentReceive.requestFocusInWindow();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void TF_SummaryPaymentReceiveFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SummaryPaymentReceiveFocusGained
  DocumentListenerFocus=1;
  TF_SummaryPaymentReceive.setBackground(CGUI.Color_TextBox_FocusOn);
  TF_SummaryPaymentReceive.selectAll();
 }//GEN-LAST:event_TF_SummaryPaymentReceiveFocusGained

 private void TF_SummaryPaymentReceiveFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SummaryPaymentReceiveFocusLost
  DocumentListenerFocus=-1;
  TF_SummaryPaymentReceive.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_SummaryPaymentReceiveFocusLost

 private void TF_SummaryPaymentReceiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SummaryPaymentReceiveKeyPressed
  int consumed=PNav.onKey_TF(this, TF_SummaryPaymentReceive, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER :
    if(evt.isShiftDown()){Btn_OkActionPerformed(null);}
    else{Btn_OkActionPerformed(null);}
    break;
   case KeyEvent.VK_DOWN : TF_SummaryPaymentReturn.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_TF_SummaryPaymentReceiveKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : TF_SummaryPaymentReturn.requestFocusInWindow(); break;
   case KeyEvent.VK_RIGHT : Btn_Cancel.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : TF_SummaryPaymentReturn.requestFocusInWindow(); break;
   case KeyEvent.VK_LEFT : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_SummaryPaymentReturnFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SummaryPaymentReturnFocusGained
  DocumentListenerFocus=2;
  TF_SummaryPaymentReturn.setBackground(CGUI.Color_TextBox_FocusOn);
  TF_SummaryPaymentReturn.selectAll();
 }//GEN-LAST:event_TF_SummaryPaymentReturnFocusGained

 private void TF_SummaryPaymentReturnFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SummaryPaymentReturnFocusLost
  DocumentListenerFocus=-1;
  TF_SummaryPaymentReturn.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_SummaryPaymentReturnFocusLost

 private void TF_SummaryPaymentReturnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SummaryPaymentReturnKeyPressed
  int consumed=PNav.onKey_TF(this, TF_SummaryPaymentReturn, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER :
    if(evt.isShiftDown()){Btn_OkActionPerformed(null);}
    else{Btn_OkActionPerformed(null);}
    break;
   case KeyEvent.VK_UP : TF_SummaryPaymentReceive.requestFocusInWindow(); break;
   case KeyEvent.VK_DOWN : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_TF_SummaryPaymentReturnKeyPressed



 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JLabel Lbl_CashIn;
 private javax.swing.JLabel Lbl_CashIn2;
 private javax.swing.JLabel Lbl_CashOut;
 private javax.swing.JLabel Lbl_CashOut2;
 private javax.swing.JLabel Lbl_FinishConfirmation;
 private javax.swing.JLabel Lbl_SummaryPaymentReceive;
 private javax.swing.JLabel Lbl_SummaryPaymentReturn;
 private javax.swing.JLabel Lbl_SummaryPrice;
 private javax.swing.JLabel Lbl_Title;
 private javax.swing.JTextField TF_CashIn;
 private javax.swing.JTextField TF_CashInComment;
 private javax.swing.JTextField TF_CashIn_ItemsCount;
 private javax.swing.JTextField TF_CashIn_ItemsPrice;
 private javax.swing.JTextField TF_CashOut;
 private javax.swing.JTextField TF_CashOutComment;
 private javax.swing.JTextField TF_CashOut_ItemsCount;
 private javax.swing.JTextField TF_CashOut_ItemsPrice;
 private javax.swing.JTextField TF_SummaryPaymentReceive;
 private javax.swing.JTextField TF_SummaryPaymentReturn;
 private javax.swing.JTextField TF_SummaryPrice;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator10;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 private javax.swing.JSeparator jSeparator6;
 private javax.swing.JSeparator jSeparator7;
 private javax.swing.JSeparator jSeparator8;
 private javax.swing.JSeparator jSeparator9;
 // End of variables declaration//GEN-END:variables
}
