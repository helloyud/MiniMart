import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.util.Vector;

public class OLabelCreatorItemMiniPriceTagA extends OLabelCreatorItem {
 
 
 
 
 
  // Ideal label size (in pixel)
 public static final double IdealLabelWidth  = OUnit.mm_to_pixel(42);
 public static final double IdealLabelHeight = OUnit.mm_to_pixel(21);
 
 final int MinimalNameLineCount = 2;
 final int MaximalNameLineCount = 4;
 int NameLineCount, NameLineFixedTop;
 double NameY;
 double NameAreaHeight;
 
 double LineY;
 
 double IdY;
 
 final double SpaceBetweenPromoAndId = OUnit.mm_to_pixel(0.7);
 
 final int MinimalPromoLineCount = 1;
 final int MaximalPromoLineCount = 3;
 int PromoLineCount, PromoLineFixedTop;
 double PromoY;
 double PromoAreaHeight;

 
 
 
 
 public OLabelCreatorItemMiniPriceTagA(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  BoxWidthMin=
   2*MarginHorizontal+
   PCore.getMinMax_Double(false, PCore.refArr(ColumnsCountMin*TextWidth));
  BoxHeightMin=
   2*MarginVertical+
   MinimalNameLineCount*TextHeight+(MinimalNameLineCount-1)*TextLineSpacing+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   TextHeight+
   SpaceBetweenPromoAndId+
   MinimalPromoLineCount*TextHeight+(MinimalPromoLineCount-1)*TextLineSpacing;
 }
 protected void initDrawComponentsVariables(){
  super.initDrawComponentsVariables();
  
  ColumnsCountMin=19;
  ColumnsCountMax=55;
 }
 protected String getName(){return "Price Tag) Mini A";}
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  OPaper papr;
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth, IdealLabelHeight, 0, 0, 0, true, true, true, true, false));
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 1-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return false;}
 protected boolean isLabelRotatedInternalPaper(){return false;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 protected boolean genLayoutVariables(){
  boolean ret=true;
  double dbl;
  
  // calculate NameLineCount
  dbl=LabelHeight-(
   2*MarginVertical+
   MinimalNameLineCount*TextHeight+(MinimalNameLineCount-1)*TextLineSpacing+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   TextHeight+
   SpaceBetweenPromoAndId+
   MinimalPromoLineCount*TextHeight+(MinimalPromoLineCount-1)*TextLineSpacing);
  if(dbl<0){return false;}
  NameLineCount=MinimalNameLineCount+(int)(dbl/(TextLineSpacing+TextHeight));
  if(NameLineCount>MaximalNameLineCount){NameLineCount=MaximalNameLineCount;}
  NameLineFixedTop=(int)(0.5*NameLineCount); if(NameLineFixedTop==0){NameLineFixedTop=1;}
  
  // calculate PromoLineCount
  dbl=LabelHeight-(
   2*MarginVertical+
   NameLineCount*TextHeight+(NameLineCount-1)*TextLineSpacing+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   TextHeight+
   SpaceBetweenPromoAndId+
   MinimalPromoLineCount*TextHeight+(MinimalPromoLineCount-1)*TextLineSpacing);
  PromoLineCount=MinimalPromoLineCount+(int)(dbl/(TextLineSpacing+TextHeight));
  if(PromoLineCount>MaximalPromoLineCount){PromoLineCount=MaximalPromoLineCount;}
  PromoLineFixedTop=(int)(0.5*PromoLineCount); if(PromoLineFixedTop==0){PromoLineFixedTop=1;}
  
  // set coordinate Y of contents
  NameY=MarginVertical;
  NameAreaHeight=NameLineCount*TextHeight+(NameLineCount-1)*TextLineSpacing;
  LineY=NameY+NameAreaHeight+SpaceToLine;
  IdY=LineY+LineWidth+SpaceToLine;
  PromoY=IdY+TextHeight+SpaceBetweenPromoAndId;
  PromoAreaHeight=PromoLineCount*TextHeight+(PromoLineCount-1)*TextLineSpacing;
  
  ColumnsCount=(int)((LabelWidth-2*MarginHorizontal)/TextWidth);
  if(ColumnsCount<ColumnsCountMin){return false;}
  if(ColumnsCount>ColumnsCountMax){ColumnsCount=ColumnsCountMax;}
  
  //
  BoxWidth=
   2*MarginHorizontal+
   PCore.getMinMax_Double(false, PCore.refArr(ColumnsCount*TextWidth));
  BoxHeight=
   2*MarginVertical+
   NameAreaHeight+
   SpaceToLine+
   LineWidth+
   SpaceToLine+
   TextHeight+
   SpaceBetweenPromoAndId+
   PromoAreaHeight;
  
  return ret;
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  OLabelDataItem Data;
  Stroke strok;
  OBarcodePatterns patt;
  Vector<String> strv=null;
  String str;
  int temp, count;
  double CurrY;
  
  g.setFont(Fon);
  
  Data=(OLabelDataItem)LabelData;
  
  if(NameLineCount==1){
   strv=PCore.vect(PText.fitString(Data.ItemName, ColumnsCount, true, (int)(0.6*ColumnsCount), 1, '~'));
  }
  else{
   strv=PText.fitMultiLine(
    PText.multiLine(Data.ItemName, ColumnsCount), NameLineCount, true, NameLineFixedTop,
    ColumnsCount, true, (int)(0.4*ColumnsCount), 1, '~');
  }
  
  count=strv.size();
  CurrY=NameY+PGraphics.getInsetY(NameAreaHeight, Fon, count, TextLineSpacing, OAlignment.VerticalCenter);
  temp=0;
  do{
   if(temp!=0){CurrY=CurrY+TextLineSpacing;}
   
   str=strv.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+TextAscent));
   CurrY=CurrY+TextHeight;

   temp=temp+1;
  }while(temp!=count);
  
  strok=g.getStroke();
  g.setStroke(new BasicStroke((float)LineWidth));
  temp=PMath.round(Scaled_BoxY+LineY, 0);
  g.drawLine(0, temp, PMath.round(Scaled_LabelWidth, 0), temp);
  g.setStroke(strok);
  
  str=PText.priceToString(Data.ItemSellPrice);
  g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalRight)), (float)(Scaled_BoxY+IdY+TextAscent));
  temp=ColumnsCount-str.length()-1-2;
  str="("+PText.fitString(String.valueOf(Data.ItemId), temp, false, temp-1, 1, '~')+")";
  g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalLeft)), (float)(Scaled_BoxY+IdY+TextAscent));
  
  if(PromoLineCount==1){
   strv=PCore.vect(PText.fitString(Data.PromoComment, ColumnsCount, true, (int)(0.6*ColumnsCount), 1, '~'));
  }
  else{
   strv=PText.fitMultiLine(
    PText.multiLine(Data.PromoComment, ColumnsCount), PromoLineCount, true, PromoLineFixedTop,
    ColumnsCount, true, (int)(0.4*ColumnsCount), 1, '~');
  }
   
  count=strv.size();
  CurrY=PromoY+PGraphics.getInsetY(PromoAreaHeight, Fon, count, TextLineSpacing, OAlignment.VerticalCenter);
  temp=0;
  do{
   if(temp!=0){CurrY=CurrY+TextLineSpacing;}
   
   str=strv.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+TextAscent));
   CurrY=CurrY+TextHeight;

   temp=temp+1;
  }while(temp!=count);
 }
 
 
 
 
 
}