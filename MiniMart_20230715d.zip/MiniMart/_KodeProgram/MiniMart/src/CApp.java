import java.util.Vector;

public class CApp {
 
 
 // Version of Application & Database
 public static OApplicationVersion getVersionOfApplication(){
  /*  the variable 'Month' in PDate.generateDate() start from 00 (January) until 11 (December)  */
  return new OApplicationVersion(PDate.generateDate(2023, CDate.monthToCalendarIndex(07), 15, false), "d");
 }
 public static ODatabaseVersion getVersionOfDatabase(){
  return new ODatabaseVersion(26, 1);
 }
 
 
 // the parameter's name shouldn't be changed because its already referenced by some operations in this application
 final static String ParamDbVersion="Database Version";
 final static String ParamDbSubVariant="Database Version Sub-Variant";
 final static String ParamShopName="Shop Name";
 final static String ParamShopAddress="Shop Address";
 final static String ParamShopContact="Shop Contact";
 final static String ParamShopWorkingHour="Shop Working-Hour";
 
 final static int TblCategoryOfItem=1;
 final static int TblTagOfItem=2;
 final static int TblStockUnit=3;
 final static int TblReasonOfRevisi=4;
 final static int TblReasonOfConv=5;
 final static int TblCategoryOfSubject=6;
 final static int TblTagOfSubject=7;
 final static int TblCity=8;
 final static int TblContactType=9;
 final static int TblBankPlatform=10;
 final static int TblTransType=11;
 final static int TblCash=12;
 final static int TblItem=13;
 final static int TblSubject=14;
 final static int TblTrans=15;
 
 final static double Default_Item_OrderEachPackThreshold=25.0;
 final static boolean Default_ItemSupplier_Active=true;
 final static boolean Default_ItemVariant_Active=true;
 final static boolean Default_TransItem_Checked=false;
 final static boolean Default_RuleOfConvert_Active=true;
 final static double TransPriceAndPriceEstTolerance=35.0;
 final static String ConvRuleDirForward  = "A - B"; public static String ConvRuleDirForwardSQL(){return "'"+PSql.norm(ConvRuleDirForward)+"'";}
 final static String ConvRuleDirBackward = "B - A"; public static String ConvRuleDirBackwardSQL(){return "'"+PSql.norm(ConvRuleDirBackward)+"'";}
 
 final static int TableGetLockTimeout=10; // in seconds
 final static int FormQueryLimit=10000;
 
 final static int InitFocusInTableIfCountLimit=50;
 
 final static boolean AddPaperSizeTolerance=false;
 
 final static int DbVarcharMaxSize=750;
 
 public static String getTable(int Tbl){
  String ret=null;
  switch(Tbl){
   
   case CApp.TblStockUnit            : ret="StockUnit"; break;
   case CApp.TblCategoryOfItem       : ret="CategoryOfItem"; break;
   case CApp.TblTagOfItem            : ret="TagOfItem"; break;
   case CApp.TblReasonOfRevisi       : ret="ReasonOfRevisi"; break;
   case CApp.TblReasonOfConv         : ret="ReasonOfConv"; break;
   case CApp.TblCity                 : ret="City"; break;
   case CApp.TblContactType          : ret="ContactType"; break;
   case CApp.TblBankPlatform         : ret="BankPlatform"; break;
   case CApp.TblCategoryOfSubject    : ret="CategoryOfSubject"; break;
   case CApp.TblTagOfSubject         : ret="TagOfSubject"; break;
   case CApp.TblTransType            : ret="TransType"; break;
   case CApp.TblCash                 : ret="Cash"; break;
   case CApp.TblItem                 : ret="Item"; break;
   case CApp.TblSubject              : ret="Subject"; break;
  
  }
  return ret;
 }
 public static String getTableText(int Tbl){
  String ret=null;
  switch(Tbl){
   
   case CApp.TblStockUnit            : ret="Satuan Stok"; break;
   case CApp.TblCategoryOfItem       : ret="Kategori Barang"; break;
   case CApp.TblTagOfItem            : ret="Tag Barang"; break;
   case CApp.TblReasonOfRevisi       : ret="Alasan Revisi"; break;
   case CApp.TblReasonOfConv         : ret="Alasan Konversi"; break;
   case CApp.TblCity                 : ret="Kota"; break;
   case CApp.TblContactType          : ret="Tipe Kontak"; break;
   case CApp.TblBankPlatform         : ret="Bank"; break;
   case CApp.TblCategoryOfSubject    : ret="Kategori Subjek"; break;
   case CApp.TblTagOfSubject         : ret="Tag Subjek"; break;
   case CApp.TblTransType            : ret="Jenis Transaksi"; break;
   case CApp.TblCash                 : ret="Kas"; break;
   case CApp.TblItem                 : ret="Barang"; break;
   case CApp.TblSubject              : ret="Subjek"; break;
  
  }
  return ret;
 }
 public static String[] getExportColumnsHeader(int Tbl, char FieldDelimiter){
  String[] ret=null;
  switch(Tbl){
   
   case CApp.TblItem : ret=PCore.refArr(
    "*Id Barang", PText.quote("*Nama Barang", "", FieldDelimiter, true), "*Aktif", "{Keterangan}",
    "Satuan", "*Barui Stok", "*Stok", "*St Min", "*St Maks",
    "*Di-Opname", "*Di-Reorder", "*Qty / Pak", "{*Pembulatan / Pak}", "{*Order Min Pak}",
    "*Exp", "Cek Exp Tiap", "Batas Exp",
    "*Hrg Jual", "{Tgl Update Jual}", "{Ket Hrg Jual}", "*Hrg Beli", "{Tgl Update Beli}", "{Ket Hrg Beli}",
    "{Opname Stok (Selisih)}", "{Opname Expire}", "{Order Qty}");
    break;
   
   case CApp.TblSubject : ret=PCore.refArr(
    PText.quote("*Nama Subjek", "", FieldDelimiter, true), "Tanggal Lahir", "Keterangan");
    break;
   
   default : ret=PCore.refArr(PText.quote("*Nama "+getTableText(Tbl), "", FieldDelimiter, true)); break;
   
  }
  return ret;
 }
 public static String getExportQuery(int Tbl, long[] Ids){
  String ret=null;
  int ids_length;
  String condition=null;
  
  ids_length=0; if(Ids!=null){ids_length=Ids.length;}
  
  switch(Tbl){
   
   case CApp.TblItem :
    if(ids_length!=0){condition=" where Id in ("+PText.toString(Ids, 0, ids_length, ",")+")";}
    ret=
     "select "+
      "tb1.Id, tb1.Name, IsActive, Comment, "+
      "StockUnit.Name as 'StockUnitName', UpdateStockOnTransaction, Stock, MinimalStock, MaximalStock, "+
      "IsOpname, IsReorder, OrderEachPackQty, OrderEachPackThreshold, OrderMinPack, "+
      "HasExpireDate, ExpireCheckPeriod, ExpireThreshold, "+
      "SellPrice, SellUpdate, SellPriceComment, BuyPriceEstimation, BuyUpdate, BuyPriceComment, "+
      "OpnameStock, OpnameExpire, OrderQuantity "+"from "+
      "(select * from Item"+PText.getString(condition, "", false)+") as tb1 "+
     "left join StockUnit on tb1.StockUnit=StockUnit.Id "+
     "order by tb1.Name asc";
    break;
   
   case CApp.TblSubject :
    if(ids_length!=0){condition=" where Id in ("+PText.toString(Ids, 0, ids_length, ",")+")";}
    ret=
     "select "+
      "Name, Birthday, Comment "+"from "+
      "(select * from Subject"+PText.getString(condition, "", false)+") as tb1 "+
     "order by tb1.Name asc";
    break;
   
   default : ret="select Name from "+getTable(Tbl)+" order by Name asc"; break;
   
  }
  return ret;
 }
 public static int[] getExportColumnsType(int Tbl){
  int[] ret=null;
  switch(Tbl){
  
   case CApp.TblItem :
    ret=PCore.primArr(
     CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString,
     CCore.TypeString, CCore.TypeBoolean, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
     CCore.TypeBoolean, CCore.TypeBoolean, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
     CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeInteger,
     CCore.TypeDouble, CCore.TypeDate, CCore.TypeString, CCore.TypeDouble, CCore.TypeDate, CCore.TypeString,
     CCore.TypeDouble, CCore.TypeDate, CCore.TypeDouble);
    break;
   
   case CApp.TblSubject :
    ret=PCore.primArr(
     CCore.TypeString, CCore.TypeDate, CCore.TypeString);
    break;
    
   default : ret=PCore.primArr(CCore.TypeString); break;
   
  }
  return ret;
 }
 public static Vector<Object[]> getExportSample(int ExportSample){
  Vector<Object[]> ret=null;
  switch(ExportSample){
   
   case CApp.TblStockUnit : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Dos", "Unit", "Rol", "Lembar", "Buah", "Kaleng", "Batang", "Pasang", "Set", "Biji", "Tube", "Bungkus"))); break;
   case CApp.TblCategoryOfItem : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Snack / Makanan Ringan", "Kopi", "Sabun Batang", "Sabun Cair", "Pasta Gigi", "Detergen", "Teh Celup", "Mie Instan", "Biskuit", "Roti", "Beras Karung", "Minyak Goreng"))); break;
   case CApp.TblTagOfItem : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Pecah Belah", "Bergaransi", "Halal", "Non Halal", "Barang Laku Sepanjang Waktu", "Barang Laku Musim Lebaran", "Barang Laku Musim Natal"))); break;
   case CApp.TblReasonOfRevisi : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Opname Stok", "Rusak", "Hilang", "Penambahan Pribadi", "Pemakaian Pribadi"))); break;
   case CApp.TblReasonOfConv : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Pindah Satuan", "Buat Parcel Lebaran", "Buat Parcel Natal"))); break;
   case CApp.TblCity : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Palembang", "Jakarta", "Yogyakarta", "Surabaya", "Makassar", "Palangkaraya", "Bali", "Ambon", "Jayapura", "Kupang"))); break;
   case CApp.TblContactType : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "BBM", "WhatsApp", "Facebook", "Twitter", "E-mail", "Hand Phone", "Telepon Rumah", "Fax"))); break;
   case CApp.TblBankPlatform : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Bank Mandiri", "Bank BRI", "Bank BNI", "Bank BCA", "Bank Danamon", "OVO"))); break;
   case CApp.TblCategoryOfSubject : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Suplier Sembako", "Suplier Kelontong", "Suplier ATK (Alat Tulis Perkantoran)", "Tukang Listrik", "Tukang Bangunan", "Relasi", "Teman", "Keluarga", "Pelanggan", "Dokter Gigi", "Dokter Anak"))); break;
   case CApp.TblTagOfSubject : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Sering Beli Grosir", "Kawan Lama", "Jual Kue", "Service Laptop"))); break;
   case CApp.TblTransType : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Pembelian Tunai", "Pembelian Kredit", "Penjualan Tunai", "Penjualan Kredit", "Barang Return Masuk", "Barang Return Keluar", "Konsumsi Pribadi", "Buang Barang Rusak", "Mutasi / Konversi Barang", "Koreksi Stok"))); break;
   case CApp.TblCash : ret=PCore.toMultiRows(PCore.vect(PCore.refArr(
    "Bank BCA", "Bank Danamon", "Bank BRI", "Bank Mandiri", "Laci Kasir 1", "Laci Kasir 2", "Laci Kasir 3"))); break;
    
   case CApp.TblItem :
    ret=new Vector();
    
    ret.addElement(PCore.objArrVariant(
     1231234564560L, "Minuman Coca-Cola kaleng 350 mL", true, null,
     "Kaleng", true, 17D, 6D, 24D,
     true, true, 10D, 30D, 1D,
     true, 60, 120,
     7500D, PDate.generateDate(2019, 1-1, 22, false), "Normal = 7500, >10 = 7000", 5200D, PDate.generateDate(2018, 7-1, 4, false), "5250 (disc. 5% kalau tunai)",
     -2D, PDate.generateDate(2018, 3-1, 1, false), null));
    
    ret.addElement(PCore.objArrVariant(
     7657652341238L, "Snack Cheetos rasa Jagung Bakar bungkus 80 gr", true, "Boleh di-stok banyak karena anak-anak sekolah suka makan....",
     "Bungkus", true, 5D, 12D, 30D,
     true, true, 24D, 50D, 2D,
     true, 30, 60,
     7000D, null, null, 5750D, null, "5750",
     1D, PDate.generateDate(2019, 2-1, 15, false), 16D));
    
    ret.addElement(PCore.objArrVariant(
     7391731312892L, "Shampoo Rejoice sachet 15 mL", true, "Per gantung isi 10 sachet",
     "Sachet", true, 25D, 12D, 48D,
     true, true, 10D, 30D, 3D,
     true, 90, 180,
     1500D, PDate.generateDate(2017, 8-1, 5, false), "1 Sachet = 1500, 1 Gantung = 12000", 1075D, null, "10750 per gantung (beli >30 gantung bonus 3 gantung)",
     -3D, PDate.generateDate(2020, 5-1, 6, false), null));
    
    ret.addElement(PCore.objArrVariant(
     6137187131039L, "Beras ecer literan", true, null,
     "Liter", false, 0D, 0D, 0D,
     false, false, 1D, 100D, 1D,
     true, null, null,
     9500.25D, null, null, 8600.50D, PDate.generateDate(2016, 3-1, 12, false), null,
     null, null, null));
    
    ret.addElement(PCore.objArrVariant(
     24181231991310L, "Lampu Philips pijar 40 Watt", false, "Barang dites sebelum dijual dan tidak boleh dikembalikan !",
     "Buah", true, 3D, 5D, 10D,
     true, true, 12D, 45D, 2D,
     false, null, null,
     8500D, PDate.generateDate(2018, 12-1, 31, false), "Harga net = 8000", 7150D, PDate.generateDate(2018, 10-1, 6, false), "7000",
     3D, null, 6D));
    
    ret.addElement(PCore.objArrVariant(
     42892420982010L, "Air mineral Aqua botol 1500 mL", true, "1 dos isi 12 botol.",
     "Botol", true, 11D, 24D, 60D,
     true, true, 20D, 25D, 1D,
     true, 15, 90,
     6500D, null, "normal = 6500, >5 = 6250", 5450D, null, "5600",
     5D, PDate.generateDate(2020, 4-1, 20, false), 24D));
    
    ret.addElement(PCore.objArrVariant(
     81391372472181L, "Biskuit Oreo bungkus 230 gr", true, null,
     "Bungkus", true, 4D, 4D, 10D,
     true, true, 12D, 30D, 1D,
     true, 30, 90,
     8250.50D, PDate.generateDate(2017, 10-1, 1, false), null, 6900D, null, "7000",
     null, PDate.generateDate(2019, 1-1, 3, false), null));
    
    ret.addElement(PCore.objArrVariant(
     5491378191223L, "Mie instan Indomie goreng bungkus 70 gr", true, "1 dos isi 50 bungkus.",
     "Bungkus", true, 35D, 20D, 100D,
     true, true, 48D, 30D, 1D,
     true, 30, 120,
     2500.25D, null, "normal = 2500, >5 = 2350", 2075D, PDate.generateDate(2018, 3-1, 27, false), "2100 (beli 3 dos disc. 5%)",
     -7D, PDate.generateDate(2019, 6-1, 6, false), null));
    
    break;
   
   case CApp.TblSubject :
    ret=new Vector();
    ret.addElement(PCore.objArrVariant("Budi Pratama", PDate.generateDate(1975, 4-1, 3, false), null));
    ret.addElement(PCore.objArrVariant("Anto", PDate.generateDate(1981, 6-1, 15, false), "Teman sekampus di waktu dulu...."));
    ret.addElement(PCore.objArrVariant("Muhammad Candra", null, "Pelanggan tetap yg suka belanja mie instan...."));
    ret.addElement(PCore.objArrVariant("Aiman Wiratama", null, null));
    ret.addElement(PCore.objArrVariant("Erika", PDate.generateDate(1984, 2-1, 7, false), "Teman SMP ...."));
    ret.addElement(PCore.objArrVariant("Gunawan Kumala", null, null));
    ret.addElement(PCore.objArrVariant("Deddy", PDate.generateDate(1993, 8-1, 3, false), "Bisa servis AC rusak...."));
    ret.addElement(PCore.objArrVariant("Agus Hamzah", PDate.generateDate(1963, 3-1, 24, false), null));
    break;
  
  }
  return ret;
 }
 
}