public class OValue {
 
 public static final int StateUndefined=1;
 public static final int StateDefinedNoError=2;
 public static final int StateDefinedError=3;
 public static final int StateDefinedNull=4;
 
 private Object Value;
 private int State;

 public OValue(){setUndefined();}
 public OValue(Object Value, int State){
  this.Value = Value;
  this.State = State;
 }
 
 public Object getValue(){return Value;}
 public int getState(){return State;}
 
 public OValue setUndefined(){Value=null; State=StateUndefined; return this;}
 public OValue setDefinedNoError(Object Value){this.Value=Value; State=StateDefinedNoError; return this;}
 public OValue setDefinedError(Object Value){this.Value=Value; State=StateDefinedError; return this;}
 public OValue setDefinedNull(Object Value){this.Value=Value; State=StateDefinedNull; return this;}

}