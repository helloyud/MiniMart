import javax.swing.JOptionPane;

public class Run {
 public static void main(String[] args){
  MInterFormVariables IFV;
  
  IFV=new MInterFormVariables();
  IFV.initializeVar();
  
  if(IFV.IsError){
   JOptionPane.showMessageDialog(null,
    "Gagal memulai aplikasi (kode '"+IFV.getInfoStep()+"'), silahkan periksa kembali :\n"+
    "- Penyetelan printer default pada sistem operasi.\n"+
    "- Kelengkapan file yg terdapat pada folder 'lib'."+
    
    "\n\n\n"+
    
    "Catatan :\n"+
    "Jangan menjalankan file MiniMart.jar dari dalam file zip sebab akan terjadi error,\n"+
    "di-ekstrak (unzip) dulu file zip nya ke sebuah folder, lalu jalankan file MiniMart.jar .");
   IFV.closeApplication();
  }
  
  if(!IFV.DirectLogin){
   IFV.FMain.setVisible(true);
   IFV.FLogin.loginUser();
  }
  else{
   IFV.FMain.UpdateUser=true;
   IFV.FMain.setVisible(true);
  }
 }
}