public class VIntegerArray {
 
 int[] Value;
 
 public VIntegerArray(){}
 public VIntegerArray(int[] Value){this.Value=Value;}
 
}