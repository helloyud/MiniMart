public class OCalculationOperandConstanta
 extends OCalculationOperand{
 
 double Constanta;

 public OCalculationOperandConstanta(double Constanta) {
  this.Constanta = Constanta;
 }
 
 public double getOperand(){return Constanta;}
 
}
