public class OEditSubjectContact {
 
 boolean EditContactType; int EditContactTypeMode; Integer EditedContactTypeId; String EditedContactTypeName;
 boolean EditCont; int EditContMode; boolean EditContSub; String EditedContSub; String EditedCont;
 boolean EditComment; int EditCommentMode; boolean EditCommentSub; String EditedCommentSub; String EditedComment;
 
 public OEditSubjectContact(){clearAll();}
 
 OEditSubjectContact clearAll(){
  init(
   false, 0, -1, null,
   false, 0, false, null, null,
   false, 0, false, null, null);
  
  return this;
 }
 OEditSubjectContact init(
  boolean EditContactType, int EditContactTypeMode, int EditedContactTypeId, String EditedContactTypeName,
  boolean EditCont, int EditContMode, boolean EditContSub, String EditedContSub, String EditedCont,
  boolean EditComment, int EditCommentMode, boolean EditCommentSub, String EditedCommentSub, String EditedComment){
  
  this.EditContactType = EditContactType; this.EditContactTypeMode = EditContactTypeMode; this.EditedContactTypeId = EditedContactTypeId; this.EditedContactTypeName = EditedContactTypeName;
  this.EditCont = EditCont; this.EditContMode = EditContMode; this.EditContSub = EditContSub; this.EditedContSub = EditedContSub; this.EditedCont = EditedCont;
  this.EditComment = EditComment; this.EditCommentMode=EditCommentMode; this.EditCommentSub = EditCommentSub; this.EditedCommentSub = EditedCommentSub; this.EditedComment = EditedComment;
  
  return this;
 }
 
}