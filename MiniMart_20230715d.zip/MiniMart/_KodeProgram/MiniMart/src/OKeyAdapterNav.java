import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;

public class OKeyAdapterNav extends OKeyAdapter {
 
 Component Cmp;
 
 Window Form;
 Object[] ExcludeComponents;

 public OKeyAdapterNav(Component Cmp,
  
  Window Form, Object[] ExcludeComponents) {
  
  this.Cmp = Cmp;
  
  this.Form = Form;
  this.ExcludeComponents = ExcludeComponents;
 
 }
 
 public void keyPressed(KeyEvent evt) {PNav.actionNavDefault(Cmp, CNav.StateKey_Pressed, evt, Form, ExcludeComponents);}
 public void keyReleased(KeyEvent evt) {PNav.actionNavDefault(Cmp, CNav.StateKey_Released, evt, Form, ExcludeComponents);}
 public void keyTyped(KeyEvent evt) {}
 
}