import java.sql.Statement;
import java.util.Vector;

class OPrintGeneratorRevStock extends OPrintGenerator{
 
 // additional printing properties
 long[] Id;
 int OrderMode;
 boolean ItemCategorized;
 
  // Query
 String Query_WithoutOrderBy;
 String Query_OrderBy;
 String Query_TbHaving;
 
  // Record
 int[] Record_ColType;
 int Record_ColCount;
 int Record_Col_RevId, Record_Col_Date, Record_Col_ReasonId, Record_Col_ReasonName, Record_Col_ItemId, Record_Col_ItemName,
  Record_Col_StockOld, Record_Col_StockNew, Record_Col_StockDiff, Record_Col_StockUnitName,
  Record_Col_UpdateStock, Record_Col_CategoryId, Record_Col_CategoryName;
 
 boolean NextRecord;
 Object[] CurrRecord, BefRecord;
 
  // Table
 ODrawTable Table, TableHeader;
 OInset Inset;
 int[] Table_Cols;
 ODrawTableRow TableNewRow;
 
 final int Table_ColId_RevDateOrder=0;
 final int Table_ColId_RevDate=1;
 final int Table_ColId_RevReasonOrder=2;
 final int Table_ColId_RevReason=3;
 final int Table_ColId_RevItemCatOrder=4;
 final int Table_ColId_RevItemCat=5;
 final int Table_ColId_RevItemOrder=6;
 final int Table_ColId_RevItem=7;
 final int Table_ColId_RevStockOld=8;
 final int Table_ColId_RevStockNew=9;
 final int Table_ColId_RevStockDiff=10;
 
  // Ordering
 VLong NumberOfOrderDate; VBoolean FirstOrderDate;
 VLong NumberOfOrderReason; VBoolean FirstOrderReason;
 VLong NumberOfOrderItem; VBoolean FirstOrderItem;
 VLong NumberOfOrderItemCat; VBoolean FirstOrderItemCat;
 
 Vector<VLong> Order_Number;
 Vector<VBoolean> Order_First;
 Vector<Integer> Order_RecordCol;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 final int ColSizeNumberOfOrder=6;
 final int ColSizeDate=10;
 final int ColSizeReason=17;
 final int ColSizeQty=6;
 final int ColSizeTextMin=10;
 final String NumberOfOrder_Dot=".";
 final double ColPercentageCategory=0.3;
 double CellAreaMinHeight;
 
 OPrintGeneratorRevStock(OFont FontStandard) {
  super(FontStandard);
  NumberOfOrderDate=new VLong(); FirstOrderDate=new VBoolean();
  NumberOfOrderReason=new VLong(); FirstOrderReason=new VBoolean();
  NumberOfOrderItem=new VLong(); FirstOrderItem=new VBoolean();
  NumberOfOrderItemCat=new VLong(); FirstOrderItemCat=new VBoolean();
 }
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, long[] Id, int OrderMode, boolean ItemCategorized){
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.Id=Id;
  this.OrderMode=OrderMode;
  this.ItemCategorized=ItemCategorized;
 }
 
 // standard private methods
	protected boolean hasHeader(){return true;}
 protected boolean hasFooter(){return true;}
	protected boolean isMultiColumnar(){return false;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.0f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(6.25f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  CellAreaMinHeight=NormalHeight;
  Inset=new OInset(0.2*FontHeight, 0.2*FontHeight, 0.7*FontWidth, 0.7*FontWidth);
 }
 protected void prepareFirstPageData() throws Exception{
		int temp, column_resize, column_category, category_charcount;
  ODrawTableColumnMetadata[] Columns;
  ODrawTableColumnMetadata Column=null;
  double temp_d;
  
  initVar_All();
  
  Columns=new ODrawTableColumnMetadata[Table_Cols.length];
  temp=0; column_resize=-1; column_category=-1;
  do{
   switch(Table_Cols[temp]){
    case Table_ColId_RevDateOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevDate : Column=new ODrawTableColumnMetadata("Tgl", ColSizeDate*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevReasonOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevReason : Column=new ODrawTableColumnMetadata("Alasan", ColSizeReason*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevItemCatOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevItemCat : Column=new ODrawTableColumnMetadata("Kategori", 0); column_category=temp; break;
    case Table_ColId_RevItemOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevItem : Column=new ODrawTableColumnMetadata("Barang", 0); column_resize=temp; break;
    case Table_ColId_RevStockOld : Column=new ODrawTableColumnMetadata("St-Lm", ColSizeQty*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevStockNew : Column=new ODrawTableColumnMetadata("St-Br", ColSizeQty*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_RevStockDiff : Column=new ODrawTableColumnMetadata("Slsih", ColSizeQty*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
   }
   Columns[temp]=Column;
   temp=temp+1;
  }while(temp!=Table_Cols.length);
  if(column_resize==-1){throw new Exception();}
  temp_d=ColumnarWidth-PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(column_category!=-1){
   category_charcount=(int)((ColPercentageCategory*(temp_d-2*(Inset.InsetLeft+Inset.InsetRight)))/FontWidth);
   Columns[column_category].Width=category_charcount*FontWidth+(Inset.InsetLeft+Inset.InsetRight);
   temp_d=temp_d-Columns[column_category].Width;
  }
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)>temp_d){throw new Exception();}
  Columns[column_resize].Width=temp_d;
  
  Table=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillAll);
  
  TableHeader=new ODrawTable(Table.Columns, Table.Inset, ODrawTableBorder.DefaultFillEmpty);
  TableHeader.insertARow(0, TableHeader.getRowHeader(FontType, LineSpacing,
   new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalCenter), true, 1, true, 0, true, 1.0, 1, '~'));
  
  BefRecord=null;
  queryRev(); if(!getNextRev()){throw new Exception();}
 }
 protected void addHeader() throws Exception{
  DrawComponents.add(new ODrawComponentTable(0, CurrY, TableHeader));
  CurrY=CurrY+TableHeader.Height;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  CurrY=CurrY+HeaderAddLineSpacing;
 }
 protected boolean addColumnar() throws Exception{
  boolean ret=false;
		boolean KeepPrinting=true;
  
  do{
   Table.insertARow(Table.Rows.size(), TableNewRow);
   if(!getNextRev()){break;}
   if(checkOverColumnarHeight(Table.Height+TableNewRow.Height)){break;}
  }while(KeepPrinting);
  
  DrawComponents.addElement(new ODrawComponentTable(0, BaseY+CurrY, Table));
  Table=Table.createNewTable();
  
		return ret;
 }
 protected void addFooter() throws Exception{
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  PText.fillStringToChars(TxtPage, "Hal. "+CurrPage, PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  return NextRecord;
 }
 protected void clearVar(){
  BefRecord=null;
  CurrRecord=null;
  Query_OrderBy=null;
  Table=null;
  TableHeader=null;
  TableNewRow=null;
 }
 
 // additional private methods
 private void initVar_QueryAndRecord(){
  Query_WithoutOrderBy=
   "select tb4.*, ItemXCategory.CategoryOfItem, Min(CategoryOfItem.Name) as 'CategoryName' from "+
    "(select tb3.Id, tb3.RevisiDate, tb3.ReasonOfRevisi, tb3.ReasonOfRevisiName, tb3.Item, tb3.ItemName, tb3.StockOld, tb3.StockNew, tb3.Different, StockUnit.Name as 'StockUnitName', tb3.UpdateStockOnTransaction from "+
     "(select tb2.*, Item.Name as 'ItemName', Item.StockUnit, Item.UpdateStockOnTransaction from "+
      "(select tb1.*, ReasonOfRevisi.Name as 'ReasonOfRevisiName' from "+
       "(select RevisiStock.*, (StockNew-StockOld) as 'Different' from RevisiStock where Id in("+PText.toString(Id, 0, Id.length, ",")+")) as tb1 "+
      "left join ReasonOfRevisi on tb1.ReasonOfRevisi=ReasonOfRevisi.Id) as tb2 "+
     "left join Item on tb2.Item=Item.Id) as tb3 "+
    "left join StockUnit on tb3.StockUnit=StockUnit.Id) as tb4 "+
   "left join ItemXCategory on tb4.Item=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.Id";
  Query_TbHaving="tb4";
  
  Record_Col_RevId=0;
  Record_Col_Date=1;
  Record_Col_ReasonId=2;
  Record_Col_ReasonName=3;
  Record_Col_ItemId=4;
  Record_Col_ItemName=5;
  Record_Col_StockOld=6;
  Record_Col_StockNew=7;
  Record_Col_StockDiff=8;
  Record_Col_StockUnitName=9;
  Record_Col_UpdateStock=10;
  Record_Col_CategoryId=11;
  Record_Col_CategoryName=12;
  Record_ColType=PCore.primArr(CCore.TypeLong, CCore.TypeDate, CCore.TypeInteger, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeString);
  Record_ColCount=Record_ColType.length;
 }
 private void initVar_Query_OrderBy(){
  StringBuilder strb;
  boolean first;
  
  String Order_Date, Order_Reason, Order_Item;
  
  strb=new StringBuilder(); first=true;
  
  strb.append(" order by");
  
  /*
  if(OrderByRevisiDate){
   if(first){first=false;}else{strb.append(",");}
   strb.append(" RevisiDate desc");
  }
  
  if(ItemCategorized){
   if(first){first=false;}else{strb.append(",");}
   strb.append(" CategoryOfItem.Name asc");
  }
  
  if(first){first=false;}else{strb.append(",");}
  strb.append(" ItemName asc");
  
  if(!OrderByRevisiDate){
   if(first){first=false;}else{strb.append(",");}
   strb.append(" RevisiDate desc");
  }
  
  if(first){first=false;}else{strb.append(",");}
  strb.append(" "+Query_TbHaving+".Id desc");
  */
  
  Order_Date   = " RevisiDate desc";
  Order_Reason = " ReasonOfRevisiName asc";
  Order_Item   = " ItemName asc"; if(ItemCategorized){Order_Item=" CategoryName asc,"+Order_Item;}
  switch(OrderMode){
   case 0 : strb.append(Order_Date+","+Order_Item+","+Order_Reason); break;
   case 1 : strb.append(Order_Date+","+Order_Reason+","+Order_Item); break;
   case 2 : strb.append(Order_Item+","+Order_Date+","+Order_Reason); break;
   case 3 : strb.append(Order_Item+","+Order_Reason+","+Order_Date); break;
   case 4 : strb.append(Order_Reason+","+Order_Date+","+Order_Item); break;
   case 5 : strb.append(Order_Reason+","+Order_Item+","+Order_Date); break;
  }
  strb.append(", "+Query_TbHaving+".Id desc");
  
  Query_OrderBy=strb.toString();
 }
 private void initVar_Table_Ordering(){
  final int Id_Date=1;
  final int Id_Reason=2;
  final int Id_ItemCat=3;
  final int Id_Item=4;
  int[] Cols=null;
  int PosName=0;
  int temp;
  
  Order_Number=new Vector();
  Order_First=new Vector();
  Order_RecordCol=new Vector();
  
  /*
  if(OrderByRevisiDate){
   Order_Number.addElement(NumberOfOrderDate);
   Order_First.addElement(FirstOrderDate);
   Order_RecordCol.addElement(Record_Col_Date);
  }
  
  if(ItemCategorized){
   Order_Number.addElement(NumberOfOrderItemCat);
   Order_First.addElement(FirstOrderItemCat);
   Order_RecordCol.addElement(Record_Col_CategoryId);
  }
  
  Order_Number.addElement(NumberOfOrderItem);
  Order_First.addElement(FirstOrderItem);
  Order_RecordCol.addElement(Record_Col_ItemId);
  
  if(!OrderByRevisiDate){
   Order_Number.addElement(NumberOfOrderDate);
   Order_First.addElement(FirstOrderDate);
   Order_RecordCol.addElement(Record_Col_Date);
  }
  */
  
  switch(OrderMode){
   case 0 : Cols=PCore.primArr(Id_Date, Id_Item, Id_Reason); PosName=1; break;
   case 1 : Cols=PCore.primArr(Id_Date, Id_Reason, Id_Item); PosName=2; break;
   case 2 : Cols=PCore.primArr(Id_Item, Id_Date, Id_Reason); PosName=0; break;
   case 3 : Cols=PCore.primArr(Id_Item, Id_Reason, Id_Date); PosName=0; break;
   case 4 : Cols=PCore.primArr(Id_Reason, Id_Date, Id_Item); PosName=2; break;
   case 5 : Cols=PCore.primArr(Id_Reason, Id_Item, Id_Date); PosName=1; break;
  }
  if(ItemCategorized){Cols=PCore.insert(Cols, PosName, Id_ItemCat);}
  
  temp=0;
  do{
   switch(Cols[temp]){
    case Id_Date    : Order_Number.addElement(NumberOfOrderDate); Order_First.addElement(FirstOrderDate); Order_RecordCol.addElement(Record_Col_Date); break;
    case Id_Reason  : Order_Number.addElement(NumberOfOrderReason); Order_First.addElement(FirstOrderReason); Order_RecordCol.addElement(Record_Col_ReasonId); break;
    case Id_ItemCat : Order_Number.addElement(NumberOfOrderItemCat); Order_First.addElement(FirstOrderItemCat); Order_RecordCol.addElement(Record_Col_CategoryId); break;
    case Id_Item    : Order_Number.addElement(NumberOfOrderItem); Order_First.addElement(FirstOrderItem); Order_RecordCol.addElement(Record_Col_ItemId); break;
   }
   temp=temp+1;
  }while(temp!=Cols.length);
 }
 private void initVar_Table_Columns(){
  Vector<Integer> ColsId;
  int PosName=0;
  
  /*
  ColsId=new Vector();
  
  if(OrderByRevisiDate){
   ColsId.addElement(Table_ColId_RevDateOrder);
   ColsId.addElement(Table_ColId_RevDate);
  }
  
  if(ItemCategorized){
   // ColsId.addElement(Table_ColId_RevItemCatOrder);
   ColsId.addElement(Table_ColId_RevItemCat);
  }
  
  ColsId.addElement(Table_ColId_RevItemOrder);
  ColsId.addElement(Table_ColId_RevItem);
  
  if(!OrderByRevisiDate){
   ColsId.addElement(Table_ColId_RevDateOrder);
   ColsId.addElement(Table_ColId_RevDate);
  }
  
  ColsId.addElement(Table_ColId_RevStockOld);
  ColsId.addElement(Table_ColId_RevStockNew);
  ColsId.addElement(Table_ColId_RevStockDiff);
  
  Table_Cols=PCore.primArr_VectInt(ColsId);
  */
  
  switch(OrderMode){
   case 0 : Table_Cols=PCore.primArr(Table_ColId_RevDate, Table_ColId_RevItem, Table_ColId_RevReason, Table_ColId_RevStockOld, Table_ColId_RevStockNew, Table_ColId_RevStockDiff); PosName=1; break;
   case 1 : Table_Cols=PCore.primArr(Table_ColId_RevDate, Table_ColId_RevReason, Table_ColId_RevItem, Table_ColId_RevStockOld, Table_ColId_RevStockNew, Table_ColId_RevStockDiff); PosName=2; break;
   case 2 : Table_Cols=PCore.primArr(Table_ColId_RevItem, Table_ColId_RevDate, Table_ColId_RevReason, Table_ColId_RevStockOld, Table_ColId_RevStockNew, Table_ColId_RevStockDiff); PosName=0; break;
   case 3 : Table_Cols=PCore.primArr(Table_ColId_RevItem, Table_ColId_RevReason, Table_ColId_RevDate, Table_ColId_RevStockOld, Table_ColId_RevStockNew, Table_ColId_RevStockDiff); PosName=0; break;
   case 4 : Table_Cols=PCore.primArr(Table_ColId_RevReason, Table_ColId_RevDate, Table_ColId_RevItem, Table_ColId_RevStockOld, Table_ColId_RevStockNew, Table_ColId_RevStockDiff); PosName=2; break;
   case 5 : Table_Cols=PCore.primArr(Table_ColId_RevReason, Table_ColId_RevItem, Table_ColId_RevDate, Table_ColId_RevStockOld, Table_ColId_RevStockNew, Table_ColId_RevStockDiff); PosName=1; break;
  }
  if(ItemCategorized){Table_Cols=PCore.insert(Table_Cols, PosName, Table_ColId_RevItemCat);}
 }
 private void initVar_All(){
  initVar_QueryAndRecord();
  initVar_Query_OrderBy();
  initVar_Table_Ordering();
  initVar_Table_Columns();
 }
 private void queryRev() throws Exception{
  Rs=Stm.executeQuery(Query_WithoutOrderBy+Query_OrderBy);
 }
 void resetOrder(int Index){
  int Idx=Index;
  
  Order_First.elementAt(Idx).Value=true;
  
  if(Idx==Order_First.size()-1){return;}
  
  Idx=Idx+1;
  Order_Number.elementAt(Idx).Value=1;
  resetOrder(Idx);
 }
 boolean isCurrRecordSameWithBefRecord(int OrderIndex) throws Exception{
  Integer ret;
  int RecordCol=Order_RecordCol.elementAt(OrderIndex);
  Object BefValue, CurrValue;
  
  BefValue=BefRecord[RecordCol]; CurrValue=CurrRecord[RecordCol];
  
  ret=PCore.grading(Record_ColType[RecordCol], null, CurrValue, true, null, BefValue, true, null);
  if(ret==null){throw new Exception();}
  
  return ret==0;
 }
 private void defineCurrRev() throws Exception{
  boolean IsSame;
  int temp, length;
  VLong OrderNum;
  
  if(BefRecord==null){
   Order_Number.elementAt(0).Value=1;
   resetOrder(0);
   return;
  }
  
  temp=0; length=Order_First.size();
  do{
   IsSame=isCurrRecordSameWithBefRecord(temp);
   if(!IsSame){
    OrderNum=Order_Number.elementAt(temp);
    OrderNum.Value=OrderNum.Value+1;
    resetOrder(temp);
    break;
   }
   Order_First.elementAt(temp).Value=false;
   
   temp=temp+1;
  }while(temp!=length);
 }
 private boolean getNextRev() throws Exception{
  int insertpos;
  ODimension dim;
  
  NextRecord=Rs.next();
  if(!NextRecord){return false;}
  
  CurrRecord=new Object[Record_ColCount];
  PDatabase.fillResultSetToRow(Rs, CurrRecord, Record_ColType, false, null, null);
  
  defineCurrRev();
  BefRecord=CurrRecord;
  
  TableNewRow=new ODrawTableRow(0, Table.ColumnsCount);
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevDateOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderDate.Value, PText.intToString(NumberOfOrderDate.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevDate, -1),
   new ODrawTableCellText(PText.getString(FirstOrderDate.Value, PText.dateToString(PCore.objDate(CurrRecord[Record_Col_Date], null), 1), ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevReasonOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderReason.Value, PText.intToString(NumberOfOrderReason.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevReason, -1),
   new ODrawTableCellText(PText.getString(FirstOrderReason.Value, PText.getString(PCore.objString(CurrRecord[Record_Col_ReasonName], null), "Tdk didefenisikan", true), ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevItemCatOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderItemCat.Value, PText.intToString(NumberOfOrderItemCat.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevItemCat, -1),
   new ODrawTableCellText(PText.getString(FirstOrderItemCat.Value, PText.getString(PCore.objString(CurrRecord[Record_Col_CategoryName], null), "Tdk didefenisikan", true), ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevItemOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderItem.Value, PText.intToString(NumberOfOrderItem.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevItem, -1),
   new ODrawTableCellText(PText.getString(FirstOrderItem.Value, PCore.objString(CurrRecord[Record_Col_ItemName], "")+" ("+PCore.objLong(CurrRecord[Record_Col_ItemId], -1L)+")", ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevStockOld, -1),
   new ODrawTableCellText(PText.priceToString(PCore.objDouble(CurrRecord[Record_Col_StockOld], -1D)),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevStockNew, -1),
   new ODrawTableCellText(PText.priceToString(PCore.objDouble(CurrRecord[Record_Col_StockNew], -1D)),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_RevStockDiff, -1),
   new ODrawTableCellText(PText.priceToString(PCore.objDouble(CurrRecord[Record_Col_StockDiff], -1D)),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  insertpos=Table.Rows.size();
  if(!TableNewRow.preGenerateCellsDrawContents(Table, insertpos)){
   TableNewRow.clearAllCells();
   TableNewRow.setHeight(CellAreaMinHeight+(Table.Inset.InsetTop+Table.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow.calculatePreGeneratedCellsDrawContentsDimension(Table, insertpos);
   TableNewRow.setHeight(dim.getHeight()+(Table.Inset.InsetTop+Table.Inset.InsetBottom));
   TableNewRow.generateCellsDrawContents(Table, insertpos);
  }
  
  return true;
 }
 
}