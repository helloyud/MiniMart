import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.JTextComponent;

public class F_ItemImportAdd extends XFormDialog {
 
 OCustomTableModel TableMdlFilePreview;
 int PreviewMaxRows;
 
 OFileCsv ChoosedFile;
 
 int ChoosedStockUnitId; String ChoosedStockUnitName;
 
 //
 
 OFileCsv FileCsv;
 
 VBoolean IdByFile; VInteger IdFileField;
 VInteger NameFileField;
 VBoolean IsActiveByFile; VInteger IsActiveFileField; VBoolean IsActive;
 VBoolean CommentByFile; VInteger CommentFileField; VString Comment;
 
 VBoolean StockUnitByFile; VInteger StockUnitFileField; VInteger StockUnitId;
 VBoolean StockByFile; VInteger StockFileField; VDouble Stock;
 VBoolean UpStockByFile; VInteger UpStockFileField; VBoolean UpStock;
 VBoolean StockMinByFile; VInteger StockMinFileField; VDouble StockMin;
 VBoolean StockMaxByFile; VInteger StockMaxFileField; VDouble StockMax;
 
 VBoolean IsOpnameByFile; VInteger IsOpnameFileField; VBoolean IsOpname;
 VBoolean IsReorderByFile; VInteger IsReorderFileField; VBoolean IsReorder;
 VBoolean OrderMinPackByFile; VInteger OrderMinPackFileField; VDouble OrderMinPack;
 VBoolean OrderEachPackQtyByFile; VInteger OrderEachPackQtyFileField; VDouble OrderEachPackQty;
 VBoolean OrderEachPackThresholdByFile; VInteger OrderEachPackThresholdFileField; VDouble OrderEachPackThreshold;
 
 VBoolean HasExpByFile; VInteger HasExpFileField; VBoolean HasExp;
 VBoolean ExpCheckPeriodByFile; VInteger ExpCheckPeriodFileField; VInteger ExpCheckPeriod;
 VBoolean ExpThresholdByFile; VInteger ExpThresholdFileField; VInteger ExpThreshold;
 
 VBoolean SellPriceByFile; VInteger SellPriceFileField; VDouble SellPrice;
 VBoolean SellCommentByFile; VInteger SellCommentFileField; VString SellComment;
 VBoolean SellUpdateByFile; VInteger SellUpdateFileField; VDate SellUpdate;
 VBoolean BuyPriceEstByFile; VInteger BuyPriceEstFileField; VDouble BuyPriceEst;
 VBoolean BuyCommentByFile; VInteger BuyCommentFileField; VString BuyComment;
 VBoolean BuyUpdateByFile; VInteger BuyUpdateFileField; VDate BuyUpdate;
 
 VBoolean OpStockByFile; VInteger OpStockFileField; VDouble OpStock;
 VBoolean OpExpByFile; VInteger OpExpFileField; VDate OpExp;
 VBoolean OrderQtyByFile; VInteger OrderQtyFileField; VDouble OrderQty;
 
 public F_ItemImportAdd(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  TableMdlFilePreview=new OCustomTableModel();
  Tbl_FilePreview.setModel(TableMdlFilePreview);
  PreviewMaxRows=10;
  
  IdByFile=new VBoolean(); IdFileField=new VInteger();
  NameFileField=new VInteger();
  IsActiveByFile=new VBoolean(); IsActiveFileField=new VInteger(); IsActive=new VBoolean();
  CommentByFile=new VBoolean(); CommentFileField=new VInteger(); Comment=new VString();
  
  StockUnitByFile=new VBoolean(); StockUnitFileField=new VInteger(); StockUnitId=new VInteger();
  StockByFile=new VBoolean(); StockFileField=new VInteger(); Stock=new VDouble();
  UpStockByFile=new VBoolean(); UpStockFileField=new VInteger(); UpStock=new VBoolean();
  StockMinByFile=new VBoolean(); StockMinFileField=new VInteger(); StockMin=new VDouble();
  StockMaxByFile=new VBoolean(); StockMaxFileField=new VInteger(); StockMax=new VDouble();
  
  IsOpnameByFile=new VBoolean(); IsOpnameFileField=new VInteger(); IsOpname=new VBoolean();
  IsReorderByFile=new VBoolean(); IsReorderFileField=new VInteger(); IsReorder=new VBoolean();
  OrderMinPackByFile=new VBoolean(); OrderMinPackFileField=new VInteger(); OrderMinPack=new VDouble();
  OrderEachPackQtyByFile=new VBoolean(); OrderEachPackQtyFileField=new VInteger(); OrderEachPackQty=new VDouble();
  OrderEachPackThresholdByFile=new VBoolean(); OrderEachPackThresholdFileField=new VInteger(); OrderEachPackThreshold=new VDouble();
  
  HasExpByFile=new VBoolean(); HasExpFileField=new VInteger(); HasExp=new VBoolean();
  ExpCheckPeriodByFile=new VBoolean(); ExpCheckPeriodFileField=new VInteger(); ExpCheckPeriod=new VInteger();
  ExpThresholdByFile=new VBoolean(); ExpThresholdFileField=new VInteger(); ExpThreshold=new VInteger();
  
  SellPriceByFile=new VBoolean(); SellPriceFileField=new VInteger(); SellPrice=new VDouble();
  SellCommentByFile=new VBoolean(); SellCommentFileField=new VInteger(); SellComment=new VString();
  SellUpdateByFile=new VBoolean(); SellUpdateFileField=new VInteger(); SellUpdate=new VDate();
  BuyPriceEstByFile=new VBoolean(); BuyPriceEstFileField=new VInteger(); BuyPriceEst=new VDouble();
  BuyCommentByFile=new VBoolean(); BuyCommentFileField=new VInteger(); BuyComment=new VString();
  BuyUpdateByFile=new VBoolean(); BuyUpdateFileField=new VInteger(); BuyUpdate=new VDate();
  
  OpStockByFile=new VBoolean(); OpStockFileField=new VInteger(); OpStock=new VDouble();
  OpExpByFile=new VBoolean(); OpExpFileField=new VInteger(); OpExp=new VDate();
  OrderQtyByFile=new VBoolean(); OrderQtyFileField=new VInteger(); OrderQty=new VDouble();
  
  Tbl_FilePreview.setToolTipText("preview isi file (maksimal "+PreviewMaxRows+" baris data)");
  
  clearComponents();
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_ChooseFile,
    Tbl_FilePreview,
    
    CB_IdFile, TF_IdFile,
    TF_NameFile,
    CB_IsActiveFile, TF_IsActiveFile, CmB_IsActiveDef,
    CB_CommentFile, TF_CommentFile, TA_CommentDef,
    CB_StockUnitFile, TF_StockUnitFile, Btn_StockUnitDefChoose, Btn_StockUnitDefClear,
    CB_UpStockFile, TF_UpStockFile, CmB_UpStockDef,
    CB_StockFile, TF_StockFile, TF_StockDef,
    CB_StockMinFile, TF_StockMinFile, TF_StockMinDef,
    CB_StockMaxFile, TF_StockMaxFile, TF_StockMaxDef,
    CB_IsOpnameFile, TF_IsOpnameFile, CmB_IsOpnameDef,
    CB_IsReorderFile, TF_IsReorderFile, CmB_IsReorderDef,
    CB_OrderEachPackQtyFile, TF_OrderEachPackQtyFile, TF_OrderEachPackQtyDef,
    CB_OrderEachPackThresholdFile, TF_OrderEachPackThresholdFile, TF_OrderEachPackThresholdDef,
    CB_OrderMinPackFile, TF_OrderMinPackFile, TF_OrderMinPackDef,
    CB_HasExpFile, TF_HasExpFile, CmB_HasExpDef,
    CB_ExpCheckPeriodFile, TF_ExpCheckPeriodFile, TF_ExpCheckPeriodDef,
    CB_ExpThresholdFile, TF_ExpThresholdFile, TF_ExpThresholdDef,
    CB_SellPriceFile, TF_SellPriceFile, TF_SellPriceDef,
    CB_SellUpdateFile, TF_SellUpdateFile, CB_SellUpdateDefIsSet, TF_SellUpdateDefY, CmB_SellUpdateDefM, CmB_SellUpdateDefD,
    CB_SellCommentFile, TF_SellCommentFile, TA_SellCommentDef,
    CB_BuyPriceEstFile, TF_BuyPriceEstFile, TF_BuyPriceEstDef,
    CB_BuyUpdateFile, TF_BuyUpdateFile, CB_BuyUpdateDefIsSet, TF_BuyUpdateDefY, CmB_BuyUpdateDefM, CmB_BuyUpdateDefD,
    CB_BuyCommentFile, TF_BuyCommentFile, TA_BuyCommentDef,
    CB_OpStockFile, TF_OpStockFile, TF_OpStockDef,
    CB_OpExpFile, TF_OpExpFile, CB_OpExpDefIsSet, TF_OpExpDefY, CmB_OpExpDefM, CmB_OpExpDefD,
    CB_OrderQtyFile, TF_OrderQtyFile, TF_OrderQtyDef,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  setFileCsv(null, CCore.CsvDefaultFieldDelimiter, CCore.CsvFieldsSeparators, CCore.CsvRecordsSeparators, true);
  
  clearAttribute(Lbl_Id, CB_IdFile, TF_IdFile, CGUI.Color_Label_InputPrimary);
  Lbl_Name.setForeground(CGUI.Color_Label_InputPrimary); TF_NameFile.setText("");
  clearAttribute(Lbl_IsActive, CB_IsActiveFile, TF_IsActiveFile, CGUI.Color_Label_InputPrimary); CmB_IsActiveDef.setSelectedIndex(0);
  clearAttribute(Lbl_Comment, CB_CommentFile, TF_CommentFile, CGUI.Color_Label_InputSecondary); setText(TA_CommentDef, "");
  
  clearAttribute(Lbl_StockUnit, CB_StockUnitFile, TF_StockUnitFile, CGUI.Color_Label_InputPrimary); setStockUnit(-1, null);
  clearAttribute(Lbl_Stock, CB_StockFile, TF_StockFile, CGUI.Color_Label_InputPrimary); setText(TF_StockDef, "0");
  clearAttribute(Lbl_UpStock, CB_UpStockFile, TF_UpStockFile, CGUI.Color_Label_InputPrimary); CmB_UpStockDef.setSelectedIndex(0);
  clearAttribute(Lbl_StockMin, CB_StockMinFile, TF_StockMinFile, CGUI.Color_Label_InputPrimary); setText(TF_StockMinDef, "0");
  clearAttribute(Lbl_StockMax, CB_StockMaxFile, TF_StockMaxFile, CGUI.Color_Label_InputPrimary); setText(TF_StockMaxDef, "0");
  
  clearAttribute(Lbl_IsOpname, CB_IsOpnameFile, TF_IsOpnameFile, CGUI.Color_Label_InputPrimary); CmB_IsOpnameDef.setSelectedIndex(0);
  clearAttribute(Lbl_IsReorder, CB_IsReorderFile, TF_IsReorderFile, CGUI.Color_Label_InputPrimary); CmB_IsReorderDef.setSelectedIndex(0);
  clearAttribute(Lbl_OrderMinPack, CB_OrderMinPackFile, TF_OrderMinPackFile, CGUI.Color_Label_InputSecondary); setText(TF_OrderMinPackDef, "1");
  clearAttribute(Lbl_OrderEachPackQty, CB_OrderEachPackQtyFile, TF_OrderEachPackQtyFile, CGUI.Color_Label_InputPrimary); setText(TF_OrderEachPackQtyDef, "1");
  clearAttribute(Lbl_OrderEachPackThreshold, CB_OrderEachPackThresholdFile, TF_OrderEachPackThresholdFile, CGUI.Color_Label_InputSecondary); setText(TF_OrderEachPackThresholdDef, PText.doubleToString(CApp.Default_Item_OrderEachPackThreshold, true));
  
  clearAttribute(Lbl_HasExp, CB_HasExpFile, TF_HasExpFile, CGUI.Color_Label_InputPrimary); CmB_HasExpDef.setSelectedIndex(1);
  clearAttribute(Lbl_ExpCheckPeriod, CB_ExpCheckPeriodFile, TF_ExpCheckPeriodFile, CGUI.Color_Label_InputPrimary); setText(TF_ExpCheckPeriodDef, "");
  clearAttribute(Lbl_ExpThreshold, CB_ExpThresholdFile, TF_ExpThresholdFile, CGUI.Color_Label_InputPrimary); setText(TF_ExpThresholdDef, "");
  
  clearAttribute(Lbl_SellPrice, CB_SellPriceFile, TF_SellPriceFile, CGUI.Color_Label_InputPrimary); setText(TF_SellPriceDef, "0");
  clearAttribute(Lbl_SellComment, CB_SellCommentFile, TF_SellCommentFile, CGUI.Color_Label_InputSecondary); setText(TA_SellCommentDef, "");
  clearAttribute(Lbl_SellUpdate, CB_SellUpdateFile, TF_SellUpdateFile, CGUI.Color_Label_InputSecondary); CB_SellUpdateDefIsSet.setSelected(false); CB_SellUpdateDefIsSetActionPerformed(null);
  clearAttribute(Lbl_BuyPriceEst, CB_BuyPriceEstFile, TF_BuyPriceEstFile, CGUI.Color_Label_InputPrimary); setText(TF_BuyPriceEstDef, "0");
  clearAttribute(Lbl_BuyComment, CB_BuyCommentFile, TF_BuyCommentFile, CGUI.Color_Label_InputSecondary); setText(TA_BuyCommentDef, "");
  clearAttribute(Lbl_BuyUpdate, CB_BuyUpdateFile, TF_BuyUpdateFile, CGUI.Color_Label_InputSecondary); CB_BuyUpdateDefIsSet.setSelected(false); CB_BuyUpdateDefIsSetActionPerformed(null);
  
  clearAttribute(Lbl_OpStock, CB_OpStockFile, TF_OpStockFile, CGUI.Color_Label_InputSecondary); setText(TF_OpStockDef, "");
  clearAttribute(Lbl_OpExp, CB_OpExpFile, TF_OpExpFile, CGUI.Color_Label_InputSecondary); CB_OpExpDefIsSet.setSelected(false); CB_OpExpDefIsSetActionPerformed(null);
  clearAttribute(Lbl_OrderQty, CB_OrderQtyFile, TF_OrderQtyFile, CGUI.Color_Label_InputSecondary); setText(TF_OrderQtyDef, "");
 }
 
 boolean setFileCsv(File f, char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators, boolean ShowMessage){
  OFileCsv f_csv;
  
  if(f==null){
   ChoosedFile=null; clearFileCsv();
   return true;
  }
  
  IFV.FSplashScreen.appear(this, "Membaca File CSV");
  f_csv=new OFileCsv(f, FieldDelimiter, FieldsSeparators, RecordsSeparators, false, PreviewMaxRows, IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  
  if(f_csv.IsValid.IsValid){ChoosedFile=f_csv; fillFileCsv();}
  
  if(!f_csv.IsValid.IsValid && ShowMessage){
   IFV.FMessage.showMessage("Terjadi kegagalan dalam membaca file ("+PMyShop.getCSVErrorMessage()+") :\n"+f_csv.IsValid.getError());
  }
  
  return f_csv.IsValid.IsValid;
 }
 void fillFileCsv(){
  TF_File.setText(ChoosedFile.FileName);
  fillFileInfo();
 }
 void clearFileCsv(){
  TF_File.setText("");
  clearFileInfo();
 }
 void fillFileInfo(){
  int temp, length;
  String[] ColsName;
  String ColName;
  Vector<String> Record;
  
  // clear
  clearFileInfo();
  
  // fill File Info
  TF_FileInfo.setText(PText.intToString(ChoosedFile.RecordsCount)+" record ( "+PText.intToString(ChoosedFile.FieldsCount)+" field )");
  
  // fill File Preview
  if(ChoosedFile.FieldsCount==0){return;}
  
  ColsName=new String[ChoosedFile.FieldsCount];
  temp=0;
  do{
   ColName=ChoosedFile.Header.elementAt(temp);
   ColsName[temp]="("+(temp+1)+")"+PText.getString(ColName, "", " "+ColName, true);
   temp=temp+1;
  }while(temp!=ChoosedFile.FieldsCount);
  
  TableMdlFilePreview.updateColumnsInfo(
   ColsName, PCore.newIntegerArray(ChoosedFile.FieldsCount, CCore.TypeString),
   PCore.newIntegerArrayInOrderedSequence(ChoosedFile.FieldsCount, 0, 1), true);
  
  PGUI.resizeTableColumn(Tbl_FilePreview, PCore.newIntegerArray(ChoosedFile.FieldsCount, CGUI.ColTextSml));
  
  length=ChoosedFile.SampleRecords.size();
  if(length==0){return;}
  temp=0;
  do{
   Record=ChoosedFile.SampleRecords.elementAt(temp);
   TableMdlFilePreview.append(PCore.objArr_Vect(Record));
   temp=temp+1;
  }while(temp!=length);
 }
 void clearFileInfo(){
  TF_FileInfo.setText("");
  TableMdlFilePreview.emptyColumnsInfo();
 }
 
 void clearAttribute(JLabel Lbl, JCheckBox CB_File, JTextField TF_File, Color LblColorValid){
  Lbl.setForeground(LblColorValid);
  selectFileField(false, CB_File, TF_File);
 }
 void selectFileField(boolean Select, JCheckBox CB_File, JTextField TF_File){
  CB_File.setSelected(Select);
  enableFileField(CB_File, TF_File);
 }
 void enableFileField(JCheckBox CB_File, JTextField TF_File){
  boolean enable=CB_File.isSelected();
  TF_File.setEnabled(enable);
  TF_File.setBackground((Color)PCore.subtituteBool(enable, CGUI.Color_TextBox_FocusOff, CGUI.Gray240));
  if(!enable){TF_File.setText("");}
 }
 void setStockUnit(int Id, String Name){
  ChoosedStockUnitId=Id;
  ChoosedStockUnitName=Name;
  TF_StockUnitDef.setText(PText.getString(ChoosedStockUnitId, -1, ChoosedStockUnitName, ""));
 }
 void setText(JTextComponent TextComponent, String str){
  TextComponent.setText(str);
 }
 int fileFieldIsValid(JTextField TF_File){
  int ret=-1;
  int temp;
  String str;
  do{
   str=TF_File.getText();
   if(!PText.checkInput(str, false, CCore.CharsCount_Int(), 2, 7, 0, 0)){break;}
   temp=Integer.parseInt(str)-1;
   if(temp<0 || temp>ChoosedFile.FieldsCount-1){break;}
   ret=temp;
  }while(false);
  return ret;
 }
 void checkInteger(
  VBoolean AttrByFile, VInteger AttrByFileField, VInteger AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JTextField TF_ByDef,
  JLabel Lbl_Attr, OValidation IsValid, Color LblColorValid,
  boolean AcceptEmpty, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, int Range1, int Range2){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   if(!PGUI.checkInputInteger(TF_ByDef, AttrByDef, AcceptEmpty, AcceptZero, PositiveOnly, WithinRange, Range1, Range2)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid, LblColorValid);
 }
 void checkDouble(
  VBoolean AttrByFile, VInteger AttrByFileField, VDouble AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JTextField TF_ByDef,
  JLabel Lbl_Attr, OValidation IsValid, Color LblColorValid,
  boolean AcceptEmpty, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, double Range1, double Range2){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   if(!PGUI.checkInputDouble(TF_ByDef, AttrByDef, AcceptEmpty, AcceptZero, PositiveOnly, WithinRange, Range1, Range2)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid, LblColorValid);
 }
 void checkBoolean(
  VBoolean AttrByFile, VInteger AttrByFileField, VBoolean AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JComboBox CmB_ByDef,
  JLabel Lbl_Attr, OValidation IsValid, Color LblColorValid){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   AttrByDef.Value=CmB_ByDef.getSelectedIndex()==0;
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid, LblColorValid);
 }
 void checkString(
  VBoolean AttrByFile, VInteger AttrByFileField, VString AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JTextComponent TF_ByDef,
  JLabel Lbl_Attr, OValidation IsValid, Color LblColorValid,
  boolean AcceptEmpty, int MaxInputLength){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   if(!PGUI.checkInputString(TF_ByDef, AttrByDef, AcceptEmpty, MaxInputLength, false, true)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid, LblColorValid);
 }
 void checkDate(
  VBoolean AttrByFile, VInteger AttrByFileField, VDate AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JCheckBox CB_ByDefEnable, JTextField TF_ByDefYear, JComboBox CmB_ByDefMonth, JComboBox CmB_ByDefDay,
  JLabel Lbl_Attr, OValidation IsValid, Color LblColorValid){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   if(!PGUI.checkInputDate(CB_ByDefEnable, TF_ByDefYear, CmB_ByDefMonth, CmB_ByDefDay, AttrByDef)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid, LblColorValid);
 }
 boolean checkFileField(VBoolean AttrByFile, VInteger AttrByFileField,
  JCheckBox CB_ByFile, JTextField TF_ByFileField){
  boolean ret=true;
  
  AttrByFile.Value=CB_ByFile.isSelected();
  if(AttrByFile.Value){
   AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){ret=false;}
  }
   
  return ret;
 }
 void setValid(boolean Valid, JLabel Lbl_Attr, OValidation IsValid, Color LblColorValid){
  if(Valid){Lbl_Attr.setForeground(LblColorValid);}else{Lbl_Attr.setForeground(CGUI.Color_Label_InputWrong); IsValid.setValid(false);}
 }
 
 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Id = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  TF_File = new javax.swing.JTextField();
  Btn_ChooseFile = new javax.swing.JButton();
  Lbl_File = new javax.swing.JLabel();
  TF_FileInfo = new javax.swing.JTextField();
  Lbl_FileHelp = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_FilePreview = new XTable();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  jLabel21 = new javax.swing.JLabel();
  Lbl_FileField2 = new javax.swing.JLabel();
  jLabel23 = new javax.swing.JLabel();
  CB_SellPriceFile = new javax.swing.JCheckBox();
  TF_SellPriceFile = new javax.swing.JTextField();
  TF_SellPriceDef = new javax.swing.JTextField();
  Lbl_SellPriceDefHelp = new javax.swing.JLabel();
  Lbl_SellPrice = new javax.swing.JLabel();
  CB_SellCommentFile = new javax.swing.JCheckBox();
  TF_SellCommentFile = new javax.swing.JTextField();
  Lbl_SellCommentDefHelp = new javax.swing.JLabel();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_SellCommentDef = new javax.swing.JTextArea();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_BuyCommentDef = new javax.swing.JTextArea();
  Lbl_BuyCommentDefHelp = new javax.swing.JLabel();
  CB_BuyCommentFile = new javax.swing.JCheckBox();
  TF_BuyCommentFile = new javax.swing.JTextField();
  Lbl_BuyComment = new javax.swing.JLabel();
  Lbl_SellComment = new javax.swing.JLabel();
  TF_OpStockDef = new javax.swing.JTextField();
  Lbl_OpStockDefHelp = new javax.swing.JLabel();
  CB_OpStockFile = new javax.swing.JCheckBox();
  TF_OpStockFile = new javax.swing.JTextField();
  Lbl_OpStock = new javax.swing.JLabel();
  CmB_OpExpDefD = new javax.swing.JComboBox<>();
  CmB_OpExpDefM = new javax.swing.JComboBox<>();
  TF_OpExpDefY = new javax.swing.JTextField();
  CB_OpExpDefIsSet = new javax.swing.JCheckBox();
  TF_OpExpFile = new javax.swing.JTextField();
  CB_OpExpFile = new javax.swing.JCheckBox();
  Lbl_OpExp = new javax.swing.JLabel();
  TF_BuyPriceEstDef = new javax.swing.JTextField();
  Lbl_BuyPriceEstDefHelp = new javax.swing.JLabel();
  CB_BuyPriceEstFile = new javax.swing.JCheckBox();
  TF_BuyPriceEstFile = new javax.swing.JTextField();
  Lbl_BuyPriceEst = new javax.swing.JLabel();
  Lbl_OrderQtyDefHelp = new javax.swing.JLabel();
  TF_OrderQtyDef = new javax.swing.JTextField();
  CB_OrderQtyFile = new javax.swing.JCheckBox();
  TF_OrderQtyFile = new javax.swing.JTextField();
  Lbl_OrderQty = new javax.swing.JLabel();
  CB_SellUpdateDefIsSet = new javax.swing.JCheckBox();
  TF_SellUpdateDefY = new javax.swing.JTextField();
  CmB_SellUpdateDefM = new javax.swing.JComboBox<>();
  CmB_SellUpdateDefD = new javax.swing.JComboBox<>();
  CB_SellUpdateFile = new javax.swing.JCheckBox();
  TF_SellUpdateFile = new javax.swing.JTextField();
  Lbl_SellUpdate = new javax.swing.JLabel();
  CB_BuyUpdateDefIsSet = new javax.swing.JCheckBox();
  TF_BuyUpdateDefY = new javax.swing.JTextField();
  CmB_BuyUpdateDefM = new javax.swing.JComboBox<>();
  CmB_BuyUpdateDefD = new javax.swing.JComboBox<>();
  CB_BuyUpdateFile = new javax.swing.JCheckBox();
  TF_BuyUpdateFile = new javax.swing.JTextField();
  Lbl_BuyUpdate = new javax.swing.JLabel();
  Lbl_HasExp = new javax.swing.JLabel();
  CB_HasExpFile = new javax.swing.JCheckBox();
  TF_HasExpFile = new javax.swing.JTextField();
  CmB_HasExpDef = new javax.swing.JComboBox<>();
  Lbl_ExpCheckPeriod = new javax.swing.JLabel();
  CB_ExpCheckPeriodFile = new javax.swing.JCheckBox();
  TF_ExpCheckPeriodFile = new javax.swing.JTextField();
  TF_ExpCheckPeriodDef = new javax.swing.JTextField();
  Lbl_ExpCheckPeriodDef = new javax.swing.JLabel();
  Lbl_ExpThreshold = new javax.swing.JLabel();
  CB_ExpThresholdFile = new javax.swing.JCheckBox();
  TF_ExpThresholdFile = new javax.swing.JTextField();
  TF_ExpThresholdDef = new javax.swing.JTextField();
  Lbl_ExpThresholdDefHelp = new javax.swing.JLabel();
  jPanel5 = new javax.swing.JPanel();
  jLabel1 = new javax.swing.JLabel();
  Lbl_FileField1 = new javax.swing.JLabel();
  jLabel6 = new javax.swing.JLabel();
  TF_IdFile = new javax.swing.JTextField();
  Lbl_Id = new javax.swing.JLabel();
  TF_NameFile = new javax.swing.JTextField();
  Lbl_Name = new javax.swing.JLabel();
  CB_StockUnitFile = new javax.swing.JCheckBox();
  TF_StockUnitFile = new javax.swing.JTextField();
  TF_StockUnitDef = new javax.swing.JTextField();
  Btn_StockUnitDefChoose = new javax.swing.JButton();
  Btn_StockUnitDefClear = new javax.swing.JButton();
  Lbl_StockUnit = new javax.swing.JLabel();
  CB_StockFile = new javax.swing.JCheckBox();
  TF_StockFile = new javax.swing.JTextField();
  TF_StockDef = new javax.swing.JTextField();
  Lbl_StockDefHelp = new javax.swing.JLabel();
  Lbl_Stock = new javax.swing.JLabel();
  CB_UpStockFile = new javax.swing.JCheckBox();
  TF_UpStockFile = new javax.swing.JTextField();
  Lbl_UpStock = new javax.swing.JLabel();
  CmB_UpStockDef = new javax.swing.JComboBox<>();
  CB_StockMinFile = new javax.swing.JCheckBox();
  TF_StockMinFile = new javax.swing.JTextField();
  Lbl_StockMin = new javax.swing.JLabel();
  TF_StockMinDef = new javax.swing.JTextField();
  Lbl_StockMinDefHelp = new javax.swing.JLabel();
  CB_StockMaxFile = new javax.swing.JCheckBox();
  TF_StockMaxFile = new javax.swing.JTextField();
  TF_StockMaxDef = new javax.swing.JTextField();
  Lbl_StockMaxHelp = new javax.swing.JLabel();
  Lbl_StockMax = new javax.swing.JLabel();
  CB_CommentFile = new javax.swing.JCheckBox();
  TF_CommentFile = new javax.swing.JTextField();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_CommentDef = new javax.swing.JTextArea();
  Lbl_CommentDefHelp = new javax.swing.JLabel();
  Lbl_Comment = new javax.swing.JLabel();
  TF_IdDef = new javax.swing.JTextField();
  CB_IdFile = new javax.swing.JCheckBox();
  CmB_IsActiveDef = new javax.swing.JComboBox<>();
  TF_IsActiveFile = new javax.swing.JTextField();
  CB_IsActiveFile = new javax.swing.JCheckBox();
  Lbl_IsActive = new javax.swing.JLabel();
  Lbl_OrderMinPack = new javax.swing.JLabel();
  CB_OrderMinPackFile = new javax.swing.JCheckBox();
  TF_OrderMinPackFile = new javax.swing.JTextField();
  TF_OrderMinPackDef = new javax.swing.JTextField();
  Lbl_OrderMinPackHelp = new javax.swing.JLabel();
  CB_OrderEachPackThresholdFile = new javax.swing.JCheckBox();
  Lbl_OrderEachPackThreshold = new javax.swing.JLabel();
  TF_OrderEachPackThresholdFile = new javax.swing.JTextField();
  TF_OrderEachPackThresholdDef = new javax.swing.JTextField();
  Lbl_OrderEachPackThresholdHelp = new javax.swing.JLabel();
  CB_OrderEachPackQtyFile = new javax.swing.JCheckBox();
  TF_OrderEachPackQtyFile = new javax.swing.JTextField();
  TF_OrderEachPackQtyDef = new javax.swing.JTextField();
  Lbl_OrderEachPackQtyHelp = new javax.swing.JLabel();
  Lbl_OrderEachPackQty = new javax.swing.JLabel();
  TF_IsReorderFile = new javax.swing.JTextField();
  CB_IsReorderFile = new javax.swing.JCheckBox();
  CmB_IsReorderDef = new javax.swing.JComboBox<>();
  Lbl_IsReorder = new javax.swing.JLabel();
  CmB_IsOpnameDef = new javax.swing.JComboBox<>();
  CB_IsOpnameFile = new javax.swing.JCheckBox();
  TF_IsOpnameFile = new javax.swing.JTextField();
  Lbl_IsOpname = new javax.swing.JLabel();
  jSeparator1 = new javax.swing.JSeparator();
  jPanel4 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_ImportInfo = new javax.swing.JLabel();
  jLabel3 = new javax.swing.JLabel();

  setTitle("Impor-Tambah Data Barang");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_File.setEditable(false);
  TF_File.setBackground(new java.awt.Color(204, 255, 204));

  Btn_ChooseFile.setText("...");
  Btn_ChooseFile.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseFileActionPerformed(evt);
   }
  });
  Btn_ChooseFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseFileKeyPressed(evt);
   }
  });

  Lbl_File.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_File.setText("File CSV");

  TF_FileInfo.setEditable(false);
  TF_FileInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_FileInfo.setToolTipText("jumlah record & jumlah field pada file");

  Lbl_FileHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileHelp.setText("(?)");
  Lbl_FileHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileHelpMouseClicked(evt);
   }
  });

  Tbl_FilePreview.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_FilePreview.setToolTipText("preview isi file (maksimal n baris data)");
  Tbl_FilePreview.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
  Tbl_FilePreview.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_FilePreview.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_FilePreviewKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_FilePreview);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(Lbl_File)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_File, javax.swing.GroupLayout.DEFAULT_SIZE, 866, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FileInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ChooseFile)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_FileHelp))
   .addComponent(jScrollPane1)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_File, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ChooseFile)
     .addComponent(Lbl_File)
     .addComponent(Lbl_FileHelp)
     .addComponent(TF_FileInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE))
  );

  jLabel21.setBackground(new java.awt.Color(204, 204, 255));
  jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel21.setText("Atribut");
  jLabel21.setOpaque(true);

  Lbl_FileField2.setBackground(new java.awt.Color(204, 204, 255));
  Lbl_FileField2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileField2.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileField2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_FileField2.setText("Field Pd File");
  Lbl_FileField2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileField2.setOpaque(true);
  Lbl_FileField2.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileField2MouseClicked(evt);
   }
  });

  jLabel23.setBackground(new java.awt.Color(204, 204, 255));
  jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel23.setText("Defenisi Sendiri");
  jLabel23.setOpaque(true);

  CB_SellPriceFile.setText(" ");
  CB_SellPriceFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_SellPriceFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellPriceFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellPriceFileActionPerformed(evt);
   }
  });
  CB_SellPriceFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellPriceFileKeyPressed(evt);
   }
  });

  TF_SellPriceFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellPriceFileKeyPressed(evt);
   }
  });

  TF_SellPriceDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellPriceDefKeyPressed(evt);
   }
  });

  Lbl_SellPriceDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellPriceDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellPriceDefHelp.setText("(?)");
  Lbl_SellPriceDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellPriceDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellPriceDefHelpMouseClicked(evt);
   }
  });

  Lbl_SellPrice.setText("Harga Jual");

  CB_SellCommentFile.setText(" ");
  CB_SellCommentFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_SellCommentFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellCommentFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellCommentFileActionPerformed(evt);
   }
  });
  CB_SellCommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellCommentFileKeyPressed(evt);
   }
  });

  TF_SellCommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellCommentFileKeyPressed(evt);
   }
  });

  Lbl_SellCommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellCommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellCommentDefHelp.setText("(?)");
  Lbl_SellCommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellCommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellCommentDefHelpMouseClicked(evt);
   }
  });

  TA_SellCommentDef.setColumns(5);
  TA_SellCommentDef.setLineWrap(true);
  TA_SellCommentDef.setWrapStyleWord(true);
  TA_SellCommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_SellCommentDefKeyPressed(evt);
   }
  });
  jScrollPane3.setViewportView(TA_SellCommentDef);

  TA_BuyCommentDef.setColumns(5);
  TA_BuyCommentDef.setLineWrap(true);
  TA_BuyCommentDef.setWrapStyleWord(true);
  TA_BuyCommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyCommentDefKeyPressed(evt);
   }
  });
  jScrollPane4.setViewportView(TA_BuyCommentDef);

  Lbl_BuyCommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyCommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyCommentDefHelp.setText("(?)");
  Lbl_BuyCommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyCommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyCommentDefHelpMouseClicked(evt);
   }
  });

  CB_BuyCommentFile.setText(" ");
  CB_BuyCommentFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_BuyCommentFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyCommentFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyCommentFileActionPerformed(evt);
   }
  });
  CB_BuyCommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyCommentFileKeyPressed(evt);
   }
  });

  TF_BuyCommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyCommentFileKeyPressed(evt);
   }
  });

  Lbl_BuyComment.setText("~ Ket. Harga Beli");
  Lbl_BuyComment.setToolTipText("");

  Lbl_SellComment.setText("~ Ket. Harga Jual");

  TF_OpStockDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpStockDefKeyPressed(evt);
   }
  });

  Lbl_OpStockDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OpStockDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OpStockDefHelp.setText("(?)");
  Lbl_OpStockDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OpStockDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OpStockDefHelpMouseClicked(evt);
   }
  });

  CB_OpStockFile.setText(" ");
  CB_OpStockFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_OpStockFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpStockFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OpStockFileActionPerformed(evt);
   }
  });
  CB_OpStockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpStockFileKeyPressed(evt);
   }
  });

  TF_OpStockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpStockFileKeyPressed(evt);
   }
  });

  Lbl_OpStock.setText("Op. Stok (Selisih)");

  CmB_OpExpDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_OpExpDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpDefDKeyPressed(evt);
   }
  });

  CmB_OpExpDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_OpExpDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpDefMKeyPressed(evt);
   }
  });

  TF_OpExpDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpExpDefYKeyPressed(evt);
   }
  });

  CB_OpExpDefIsSet.setText(" ");
  CB_OpExpDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExpDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OpExpDefIsSetActionPerformed(evt);
   }
  });
  CB_OpExpDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpDefIsSetKeyPressed(evt);
   }
  });

  TF_OpExpFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpExpFileKeyPressed(evt);
   }
  });

  CB_OpExpFile.setText(" ");
  CB_OpExpFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_OpExpFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExpFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OpExpFileActionPerformed(evt);
   }
  });
  CB_OpExpFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpFileKeyPressed(evt);
   }
  });

  Lbl_OpExp.setText("Opname Expire");

  TF_BuyPriceEstDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceEstDefKeyPressed(evt);
   }
  });

  Lbl_BuyPriceEstDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceEstDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceEstDefHelp.setText("(?)");
  Lbl_BuyPriceEstDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceEstDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceEstDefHelpMouseClicked(evt);
   }
  });

  CB_BuyPriceEstFile.setText(" ");
  CB_BuyPriceEstFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyPriceEstFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyPriceEstFileActionPerformed(evt);
   }
  });
  CB_BuyPriceEstFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyPriceEstFileKeyPressed(evt);
   }
  });

  TF_BuyPriceEstFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceEstFileKeyPressed(evt);
   }
  });

  Lbl_BuyPriceEst.setText("Kis. Harga Beli");

  Lbl_OrderQtyDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderQtyDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderQtyDefHelp.setText("(?)");
  Lbl_OrderQtyDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderQtyDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderQtyDefHelpMouseClicked(evt);
   }
  });

  TF_OrderQtyDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderQtyDefKeyPressed(evt);
   }
  });

  CB_OrderQtyFile.setText(" ");
  CB_OrderQtyFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderQtyFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OrderQtyFileActionPerformed(evt);
   }
  });
  CB_OrderQtyFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderQtyFileKeyPressed(evt);
   }
  });

  TF_OrderQtyFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderQtyFileKeyPressed(evt);
   }
  });

  Lbl_OrderQty.setText("Order Qty");

  CB_SellUpdateDefIsSet.setText(" ");
  CB_SellUpdateDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdateDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellUpdateDefIsSetActionPerformed(evt);
   }
  });
  CB_SellUpdateDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateDefIsSetKeyPressed(evt);
   }
  });

  TF_SellUpdateDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellUpdateDefYKeyPressed(evt);
   }
  });

  CmB_SellUpdateDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_SellUpdateDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateDefMKeyPressed(evt);
   }
  });

  CmB_SellUpdateDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_SellUpdateDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateDefDKeyPressed(evt);
   }
  });

  CB_SellUpdateFile.setText(" ");
  CB_SellUpdateFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdateFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellUpdateFileActionPerformed(evt);
   }
  });
  CB_SellUpdateFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateFileKeyPressed(evt);
   }
  });

  TF_SellUpdateFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellUpdateFileKeyPressed(evt);
   }
  });

  Lbl_SellUpdate.setText("~ Tgl Pmbruan Jual");

  CB_BuyUpdateDefIsSet.setText(" ");
  CB_BuyUpdateDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdateDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyUpdateDefIsSetActionPerformed(evt);
   }
  });
  CB_BuyUpdateDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateDefIsSetKeyPressed(evt);
   }
  });

  TF_BuyUpdateDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateDefYKeyPressed(evt);
   }
  });

  CmB_BuyUpdateDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_BuyUpdateDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDefMKeyPressed(evt);
   }
  });

  CmB_BuyUpdateDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_BuyUpdateDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDefDKeyPressed(evt);
   }
  });

  CB_BuyUpdateFile.setText(" ");
  CB_BuyUpdateFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdateFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyUpdateFileActionPerformed(evt);
   }
  });
  CB_BuyUpdateFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateFileKeyPressed(evt);
   }
  });

  TF_BuyUpdateFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateFileKeyPressed(evt);
   }
  });

  Lbl_BuyUpdate.setText("~ Tgl Pmbruan Beli");

  Lbl_HasExp.setText("Berkadaluarsa");

  CB_HasExpFile.setText(" ");
  CB_HasExpFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_HasExpFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_HasExpFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_HasExpFileActionPerformed(evt);
   }
  });
  CB_HasExpFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_HasExpFileKeyPressed(evt);
   }
  });

  TF_HasExpFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_HasExpFileKeyPressed(evt);
   }
  });

  CmB_HasExpDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_HasExpDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_HasExpDefKeyPressed(evt);
   }
  });

  Lbl_ExpCheckPeriod.setText("~ Cek Expire Tiap");

  CB_ExpCheckPeriodFile.setText(" ");
  CB_ExpCheckPeriodFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_ExpCheckPeriodFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ExpCheckPeriodFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ExpCheckPeriodFileActionPerformed(evt);
   }
  });
  CB_ExpCheckPeriodFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpCheckPeriodFileKeyPressed(evt);
   }
  });

  TF_ExpCheckPeriodFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpCheckPeriodFileKeyPressed(evt);
   }
  });

  TF_ExpCheckPeriodDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpCheckPeriodDefKeyPressed(evt);
   }
  });

  Lbl_ExpCheckPeriodDef.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpCheckPeriodDef.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpCheckPeriodDef.setText("(?)");
  Lbl_ExpCheckPeriodDef.setToolTipText("");
  Lbl_ExpCheckPeriodDef.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpCheckPeriodDef.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpCheckPeriodDefMouseClicked(evt);
   }
  });

  Lbl_ExpThreshold.setText("~ Batas Expire");

  CB_ExpThresholdFile.setText(" ");
  CB_ExpThresholdFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_ExpThresholdFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ExpThresholdFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ExpThresholdFileActionPerformed(evt);
   }
  });
  CB_ExpThresholdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpThresholdFileKeyPressed(evt);
   }
  });

  TF_ExpThresholdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpThresholdFileKeyPressed(evt);
   }
  });

  TF_ExpThresholdDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpThresholdDefKeyPressed(evt);
   }
  });

  Lbl_ExpThresholdDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpThresholdDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpThresholdDefHelp.setText("(?)");
  Lbl_ExpThresholdDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpThresholdDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpThresholdDefHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_BuyComment, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_SellComment, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
     .addComponent(Lbl_SellPrice, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_OpStock, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_SellUpdate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_BuyUpdate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_OpExp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_OrderQty, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_BuyPriceEst, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_ExpThreshold, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_ExpCheckPeriod, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_HasExp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_OrderQtyFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderQtyFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_OpStockFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OpStockFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_BuyCommentFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_BuyUpdateFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyUpdateFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_SellCommentFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_SellUpdateFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellUpdateFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_SellPriceFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellPriceFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_ExpThresholdFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_ExpThresholdFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_ExpCheckPeriodFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_ExpCheckPeriodFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_OpExpFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OpExpFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(Lbl_FileField2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_BuyPriceEstFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyPriceEstFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(CB_HasExpFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_HasExpFile)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(TF_OrderQtyDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderQtyDefHelp))
     .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_OpStockDef, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(CB_OpExpDefIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_OpExpDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_OpExpDefM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_OpExpDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OpStockDefHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(CB_BuyUpdateDefIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_BuyUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BuyUpdateDefM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BuyUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addComponent(jScrollPane4)
       .addComponent(jScrollPane3))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_SellCommentDefHelp, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Lbl_BuyCommentDefHelp, javax.swing.GroupLayout.Alignment.TRAILING)))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(CmB_HasExpDef, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(CB_SellUpdateDefIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_SellUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_SellUpdateDefM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_SellUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addComponent(TF_SellPriceDef, javax.swing.GroupLayout.Alignment.LEADING))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_SellPriceDefHelp))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(TF_BuyPriceEstDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPriceEstDefHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addComponent(TF_ExpThresholdDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ExpThresholdDefHelp))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(TF_ExpCheckPeriodDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ExpCheckPeriodDef))))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel21)
     .addComponent(Lbl_FileField2)
     .addComponent(jLabel23))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_HasExp)
     .addComponent(CB_HasExpFile)
     .addComponent(CmB_HasExpDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_HasExpFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpCheckPeriodDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ExpCheckPeriodDef)
     .addComponent(TF_ExpCheckPeriodFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ExpCheckPeriodFile)
     .addComponent(Lbl_ExpCheckPeriod))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpThresholdFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ExpThresholdFile)
     .addComponent(Lbl_ExpThresholdDefHelp)
     .addComponent(TF_ExpThresholdDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ExpThreshold))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_SellPrice)
     .addComponent(CB_SellPriceFile)
     .addComponent(TF_SellPriceFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SellPriceDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SellPriceDefHelp))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SellUpdateDefIsSet)
     .addComponent(TF_SellUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellUpdateFile)
     .addComponent(TF_SellUpdateFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SellUpdate))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(CB_SellCommentFile)
      .addComponent(TF_SellCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_SellCommentDefHelp)
      .addComponent(Lbl_SellComment))
     .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_BuyPriceEst)
     .addComponent(CB_BuyPriceEstFile)
     .addComponent(TF_BuyPriceEstFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_BuyPriceEstDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_BuyPriceEstDefHelp))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BuyUpdateDefIsSet)
     .addComponent(TF_BuyUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyUpdateFile)
     .addComponent(TF_BuyUpdateFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_BuyUpdate))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_BuyCommentDefHelp)
       .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
        .addComponent(CB_BuyCommentFile)
        .addComponent(TF_BuyCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addComponent(Lbl_BuyComment)))
      .addGap(0, 0, Short.MAX_VALUE)))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OpStockDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OpStockDefHelp)
     .addComponent(CB_OpStockFile)
     .addComponent(TF_OpStockFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OpStock))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_OpExpDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_OpExpDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OpExpDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpExpDefIsSet)
     .addComponent(TF_OpExpFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpExpFile)
     .addComponent(Lbl_OpExp))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_OrderQtyDefHelp)
     .addComponent(TF_OrderQtyDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OrderQtyFile)
     .addComponent(TF_OrderQtyFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderQty)))
  );

  jLabel1.setBackground(new java.awt.Color(204, 204, 255));
  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("Atribut");
  jLabel1.setOpaque(true);

  Lbl_FileField1.setBackground(new java.awt.Color(204, 204, 255));
  Lbl_FileField1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileField1.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileField1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_FileField1.setText("Field Pd File");
  Lbl_FileField1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileField1.setOpaque(true);
  Lbl_FileField1.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileField1MouseClicked(evt);
   }
  });

  jLabel6.setBackground(new java.awt.Color(204, 204, 255));
  jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel6.setText("Defenisi Sendiri");
  jLabel6.setOpaque(true);

  TF_IdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IdFileKeyPressed(evt);
   }
  });

  Lbl_Id.setText("Id Barang");

  TF_NameFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameFileKeyPressed(evt);
   }
  });

  Lbl_Name.setText("Nama Barang");

  CB_StockUnitFile.setText(" ");
  CB_StockUnitFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_StockUnitFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockUnitFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_StockUnitFileActionPerformed(evt);
   }
  });
  CB_StockUnitFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockUnitFileKeyPressed(evt);
   }
  });

  TF_StockUnitFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockUnitFileKeyPressed(evt);
   }
  });

  TF_StockUnitDef.setEditable(false);
  TF_StockUnitDef.setBackground(new java.awt.Color(204, 255, 204));

  Btn_StockUnitDefChoose.setText("...");
  Btn_StockUnitDefChoose.setToolTipText("pilih stok unit");
  Btn_StockUnitDefChoose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_StockUnitDefChoose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_StockUnitDefChooseActionPerformed(evt);
   }
  });
  Btn_StockUnitDefChoose.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_StockUnitDefChooseKeyPressed(evt);
   }
  });

  Btn_StockUnitDefClear.setText("-");
  Btn_StockUnitDefClear.setToolTipText("hapus nilai stok unit yg telah dipilih");
  Btn_StockUnitDefClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_StockUnitDefClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_StockUnitDefClearActionPerformed(evt);
   }
  });
  Btn_StockUnitDefClear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_StockUnitDefClearKeyPressed(evt);
   }
  });

  Lbl_StockUnit.setText("Satuan Stok");

  CB_StockFile.setText(" ");
  CB_StockFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_StockFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_StockFileActionPerformed(evt);
   }
  });
  CB_StockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockFileKeyPressed(evt);
   }
  });

  TF_StockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockFileKeyPressed(evt);
   }
  });

  TF_StockDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockDefKeyPressed(evt);
   }
  });

  Lbl_StockDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockDefHelp.setText("(?)");
  Lbl_StockDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockDefHelpMouseClicked(evt);
   }
  });

  Lbl_Stock.setText("~ Stok");

  CB_UpStockFile.setText(" ");
  CB_UpStockFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_UpStockFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_UpStockFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_UpStockFileActionPerformed(evt);
   }
  });
  CB_UpStockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpStockFileKeyPressed(evt);
   }
  });

  TF_UpStockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_UpStockFileKeyPressed(evt);
   }
  });

  Lbl_UpStock.setText("Perbarui Stok");

  CmB_UpStockDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_UpStockDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_UpStockDefKeyPressed(evt);
   }
  });

  CB_StockMinFile.setText(" ");
  CB_StockMinFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_StockMinFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockMinFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_StockMinFileActionPerformed(evt);
   }
  });
  CB_StockMinFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockMinFileKeyPressed(evt);
   }
  });

  TF_StockMinFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMinFileKeyPressed(evt);
   }
  });

  Lbl_StockMin.setText("~ Stok Minimal");

  TF_StockMinDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMinDefKeyPressed(evt);
   }
  });

  Lbl_StockMinDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockMinDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockMinDefHelp.setText("(?)");
  Lbl_StockMinDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockMinDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockMinDefHelpMouseClicked(evt);
   }
  });

  CB_StockMaxFile.setText(" ");
  CB_StockMaxFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_StockMaxFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockMaxFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_StockMaxFileActionPerformed(evt);
   }
  });
  CB_StockMaxFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockMaxFileKeyPressed(evt);
   }
  });

  TF_StockMaxFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMaxFileKeyPressed(evt);
   }
  });

  TF_StockMaxDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMaxDefKeyPressed(evt);
   }
  });

  Lbl_StockMaxHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockMaxHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockMaxHelp.setText("(?)");
  Lbl_StockMaxHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockMaxHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockMaxHelpMouseClicked(evt);
   }
  });

  Lbl_StockMax.setText("~ Stok Maksimal");

  CB_CommentFile.setText(" ");
  CB_CommentFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_CommentFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CommentFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_CommentFileActionPerformed(evt);
   }
  });
  CB_CommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentFileKeyPressed(evt);
   }
  });

  TF_CommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CommentFileKeyPressed(evt);
   }
  });

  TA_CommentDef.setColumns(5);
  TA_CommentDef.setLineWrap(true);
  TA_CommentDef.setWrapStyleWord(true);
  TA_CommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentDefKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_CommentDef);

  Lbl_CommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentDefHelp.setText("(?)");
  Lbl_CommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentDefHelpMouseClicked(evt);
   }
  });

  Lbl_Comment.setText("Keterangan");

  TF_IdDef.setEditable(false);
  TF_IdDef.setBackground(new java.awt.Color(204, 255, 204));
  TF_IdDef.setText("Buat Otomatis (Auto Generate)");

  CB_IdFile.setText(" ");
  CB_IdFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_IdFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IdFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_IdFileActionPerformed(evt);
   }
  });
  CB_IdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IdFileKeyPressed(evt);
   }
  });

  CmB_IsActiveDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_IsActiveDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IsActiveDefKeyPressed(evt);
   }
  });

  TF_IsActiveFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IsActiveFileKeyPressed(evt);
   }
  });

  CB_IsActiveFile.setText(" ");
  CB_IsActiveFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_IsActiveFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsActiveFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_IsActiveFileActionPerformed(evt);
   }
  });
  CB_IsActiveFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsActiveFileKeyPressed(evt);
   }
  });

  Lbl_IsActive.setText("Masih Aktif");

  Lbl_OrderMinPack.setText("~ Order Min Pak");
  Lbl_OrderMinPack.setToolTipText("");

  CB_OrderMinPackFile.setText(" ");
  CB_OrderMinPackFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderMinPackFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OrderMinPackFileActionPerformed(evt);
   }
  });
  CB_OrderMinPackFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderMinPackFileKeyPressed(evt);
   }
  });

  TF_OrderMinPackFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderMinPackFileKeyPressed(evt);
   }
  });

  TF_OrderMinPackDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderMinPackDefKeyPressed(evt);
   }
  });

  Lbl_OrderMinPackHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderMinPackHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderMinPackHelp.setText("(?)");
  Lbl_OrderMinPackHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderMinPackHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderMinPackHelpMouseClicked(evt);
   }
  });

  CB_OrderEachPackThresholdFile.setText(" ");
  CB_OrderEachPackThresholdFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderEachPackThresholdFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OrderEachPackThresholdFileActionPerformed(evt);
   }
  });
  CB_OrderEachPackThresholdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderEachPackThresholdFileKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackThreshold.setText("~ Pembulatan / Pak");
  Lbl_OrderEachPackThreshold.setToolTipText("");

  TF_OrderEachPackThresholdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackThresholdFileKeyPressed(evt);
   }
  });

  TF_OrderEachPackThresholdDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackThresholdDefKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackThresholdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackThresholdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackThresholdHelp.setText("(?)");
  Lbl_OrderEachPackThresholdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackThresholdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackThresholdHelpMouseClicked(evt);
   }
  });

  CB_OrderEachPackQtyFile.setText(" ");
  CB_OrderEachPackQtyFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderEachPackQtyFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OrderEachPackQtyFileActionPerformed(evt);
   }
  });
  CB_OrderEachPackQtyFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderEachPackQtyFileKeyPressed(evt);
   }
  });

  TF_OrderEachPackQtyFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackQtyFileKeyPressed(evt);
   }
  });

  TF_OrderEachPackQtyDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackQtyDefKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackQtyHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackQtyHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackQtyHelp.setText("(?)");
  Lbl_OrderEachPackQtyHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackQtyHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackQtyHelpMouseClicked(evt);
   }
  });

  Lbl_OrderEachPackQty.setText("~ Order Qty / Pak");

  TF_IsReorderFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IsReorderFileKeyPressed(evt);
   }
  });

  CB_IsReorderFile.setText(" ");
  CB_IsReorderFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsReorderFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_IsReorderFileActionPerformed(evt);
   }
  });
  CB_IsReorderFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsReorderFileKeyPressed(evt);
   }
  });

  CmB_IsReorderDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_IsReorderDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IsReorderDefKeyPressed(evt);
   }
  });

  Lbl_IsReorder.setText("Di-Reorder");

  CmB_IsOpnameDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_IsOpnameDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IsOpnameDefKeyPressed(evt);
   }
  });

  CB_IsOpnameFile.setText(" ");
  CB_IsOpnameFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsOpnameFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_IsOpnameFileActionPerformed(evt);
   }
  });
  CB_IsOpnameFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsOpnameFileKeyPressed(evt);
   }
  });

  TF_IsOpnameFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IsOpnameFileKeyPressed(evt);
   }
  });

  Lbl_IsOpname.setText("Di-Opname");

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
      .addComponent(Lbl_Id, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_Name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_StockUnit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_Stock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_StockMin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_StockMax, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_IsActive, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_Comment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_OrderMinPack, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_OrderEachPackThreshold, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_OrderEachPackQty, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
      .addComponent(Lbl_UpStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addComponent(Lbl_IsReorder)
     .addComponent(Lbl_IsOpname))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_OrderMinPackFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderMinPackFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_IsActiveFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_IsActiveFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_StockMinFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_StockMinFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_StockFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_StockFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_StockUnitFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_StockUnitFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_IdFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_IdFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_StockMaxFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_StockMaxFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_UpStockFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_UpStockFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_OrderEachPackQtyFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderEachPackQtyFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(CB_OrderEachPackThresholdFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderEachPackThresholdFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGap(29, 29, 29)
      .addComponent(TF_NameFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(CB_IsOpnameFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_IsOpnameFile))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(CB_IsReorderFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_IsReorderFile))
       .addComponent(Lbl_FileField1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(CB_CommentFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_CommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
      .addGap(0, 0, Short.MAX_VALUE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(TF_StockMinDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_StockMinDefHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_IdDef, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE)
       .addComponent(CmB_UpStockDef, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(TF_StockUnitDef)
        .addGap(0, 0, 0)
        .addComponent(Btn_StockUnitDefChoose)
        .addGap(3, 3, 3)
        .addComponent(Btn_StockUnitDefClear))
       .addComponent(TF_StockDef))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_StockDefHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(CmB_IsActiveDef, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CommentDefHelp))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(TF_OrderMinPackDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderMinPackHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(CmB_IsOpnameDef, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(CmB_IsReorderDef, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(TF_OrderEachPackThresholdDef)
       .addComponent(TF_OrderEachPackQtyDef)
       .addComponent(TF_StockMaxDef))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_StockMaxHelp, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Lbl_OrderEachPackQtyHelp, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Lbl_OrderEachPackThresholdHelp, javax.swing.GroupLayout.Alignment.TRAILING)))))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel1)
     .addComponent(Lbl_FileField1)
     .addComponent(jLabel6))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Id)
     .addComponent(TF_IdDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_IdFile)
     .addComponent(TF_IdFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_NameFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Name))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_IsActiveDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_IsActiveFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_IsActiveFile)
     .addComponent(Lbl_IsActive))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_CommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CB_CommentFile)
      .addComponent(Lbl_Comment))
     .addComponent(Lbl_CommentDefHelp)
     .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_StockUnitFile)
     .addComponent(TF_StockUnitFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_StockUnitDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_StockUnitDefChoose)
     .addComponent(Btn_StockUnitDefClear)
     .addComponent(Lbl_StockUnit))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_UpStockFile)
     .addComponent(TF_UpStockFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_UpStock)
     .addComponent(CmB_UpStockDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_StockFile)
     .addComponent(TF_StockFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_StockDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockDefHelp)
     .addComponent(Lbl_Stock))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_StockMinFile)
     .addComponent(TF_StockMinFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockMin)
     .addComponent(TF_StockMinDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockMinDefHelp))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_StockMaxFile)
     .addComponent(TF_StockMaxFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_StockMaxDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockMaxHelp)
     .addComponent(Lbl_StockMax))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_IsOpnameDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_IsOpnameFile)
     .addComponent(TF_IsOpnameFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_IsOpname))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_IsReorderFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_IsReorderFile)
     .addComponent(CmB_IsReorderDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_IsReorder))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_OrderEachPackQty)
     .addComponent(CB_OrderEachPackQtyFile)
     .addComponent(TF_OrderEachPackQtyFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OrderEachPackQtyDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderEachPackQtyHelp))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_OrderEachPackThreshold)
     .addComponent(CB_OrderEachPackThresholdFile)
     .addComponent(TF_OrderEachPackThresholdFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OrderEachPackThresholdDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderEachPackThresholdHelp))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_OrderMinPack)
     .addComponent(CB_OrderMinPackFile)
     .addComponent(TF_OrderMinPackFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OrderMinPackDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderMinPackHelp))
    .addGap(0, 0, 0))
  );

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator1)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_ImportInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ImportInfo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ImportInfo.setText("{ Klik utk melihat aturan impor-tambah }");
  Lbl_ImportInfo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ImportInfo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ImportInfoMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(Lbl_ImportInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok)
    .addComponent(Lbl_ImportInfo))
  );

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("- - - Defenisikan Data Yg Akan Di-impor - - -");

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel3)
    .addGap(4, 4, 4)
    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation IsValid;
  boolean CurrValid;
  
  // validate file csv
  if(ChoosedFile==null){
   JOptionPane.showMessageDialog(null, "Belum ada file CSV yg dipilih !");
   return;
  }
  FileCsv=ChoosedFile;
  
  // validate import data input
  IsValid=new OValidation(true);
  
  CurrValid=false;
  do{
   if(!checkFileField(IdByFile, IdFileField, CB_IdFile, TF_IdFile)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Id, IsValid, CGUI.Color_Label_InputPrimary);
  
  CurrValid=false;
  do{
   NameFileField.Value=fileFieldIsValid(TF_NameFile); if(NameFileField.Value==-1){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Name, IsValid, CGUI.Color_Label_InputPrimary);
  
  CurrValid=false;
  do{
   if(!checkFileField(StockUnitByFile, StockUnitFileField, CB_StockUnitFile, TF_StockUnitFile)){break;}
   StockUnitId.Value=ChoosedStockUnitId;
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_StockUnit, IsValid, CGUI.Color_Label_InputPrimary);
  
  // check double cannot be null
  checkDouble(StockByFile, StockFileField, Stock, CB_StockFile, TF_StockFile, TF_StockDef, Lbl_Stock, IsValid, CGUI.Color_Label_InputPrimary, false, true, false, false, 0, 0);
  checkDouble(StockMinByFile, StockMinFileField, StockMin, CB_StockMinFile, TF_StockMinFile, TF_StockMinDef, Lbl_StockMin, IsValid, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  checkDouble(StockMaxByFile, StockMaxFileField, StockMax, CB_StockMaxFile, TF_StockMaxFile, TF_StockMaxDef, Lbl_StockMax, IsValid, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  
  checkDouble(OrderMinPackByFile, OrderMinPackFileField, OrderMinPack, CB_OrderMinPackFile, TF_OrderMinPackFile, TF_OrderMinPackDef, Lbl_OrderMinPack, IsValid, CGUI.Color_Label_InputSecondary, false, false, true, false, 0, 0);
  checkDouble(OrderEachPackQtyByFile, OrderEachPackQtyFileField, OrderEachPackQty, CB_OrderEachPackQtyFile, TF_OrderEachPackQtyFile, TF_OrderEachPackQtyDef, Lbl_OrderEachPackQty, IsValid, CGUI.Color_Label_InputPrimary, false, false, true, false, 0, 0);
  checkDouble(OrderEachPackThresholdByFile, OrderEachPackThresholdFileField, OrderEachPackThreshold, CB_OrderEachPackThresholdFile, TF_OrderEachPackThresholdFile, TF_OrderEachPackThresholdDef, Lbl_OrderEachPackThreshold, IsValid, CGUI.Color_Label_InputSecondary, false, true, true, true, 0.01, 100);
  
  checkDouble(SellPriceByFile, SellPriceFileField, SellPrice, CB_SellPriceFile, TF_SellPriceFile, TF_SellPriceDef, Lbl_SellPrice, IsValid, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  checkDouble(BuyPriceEstByFile, BuyPriceEstFileField, BuyPriceEst, CB_BuyPriceEstFile, TF_BuyPriceEstFile, TF_BuyPriceEstDef, Lbl_BuyPriceEst, IsValid, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
    
  // check double can be null
  checkDouble(OpStockByFile, OpStockFileField, OpStock, CB_OpStockFile, TF_OpStockFile, TF_OpStockDef, Lbl_OpStock, IsValid, CGUI.Color_Label_InputSecondary, true, true, false, false, 0, 0);
  checkDouble(OrderQtyByFile, OrderQtyFileField, OrderQty, CB_OrderQtyFile, TF_OrderQtyFile, TF_OrderQtyDef, Lbl_OrderQty, IsValid, CGUI.Color_Label_InputSecondary, true, true, true, false, 0, 0);
    
  // check integer can be null
  checkInteger(ExpCheckPeriodByFile, ExpCheckPeriodFileField, ExpCheckPeriod, CB_ExpCheckPeriodFile, TF_ExpCheckPeriodFile, TF_ExpCheckPeriodDef, Lbl_ExpCheckPeriod, IsValid, CGUI.Color_Label_InputPrimary, true, false, true, false, 0, 0);
  checkInteger(ExpThresholdByFile, ExpThresholdFileField, ExpThreshold, CB_ExpThresholdFile, TF_ExpThresholdFile, TF_ExpThresholdDef, Lbl_ExpThreshold, IsValid, CGUI.Color_Label_InputPrimary, true, true, true, false, 0, 0);
  
  // check boolean
  checkBoolean(UpStockByFile, UpStockFileField, UpStock, CB_UpStockFile, TF_UpStockFile, CmB_UpStockDef, Lbl_UpStock, IsValid, CGUI.Color_Label_InputPrimary);
  checkBoolean(IsActiveByFile, IsActiveFileField, IsActive, CB_IsActiveFile, TF_IsActiveFile, CmB_IsActiveDef, Lbl_IsActive, IsValid, CGUI.Color_Label_InputPrimary);
  checkBoolean(IsOpnameByFile, IsOpnameFileField, IsOpname, CB_IsOpnameFile, TF_IsOpnameFile, CmB_IsOpnameDef, Lbl_IsOpname, IsValid, CGUI.Color_Label_InputPrimary);
  checkBoolean(IsReorderByFile, IsReorderFileField, IsReorder, CB_IsReorderFile, TF_IsReorderFile, CmB_IsReorderDef, Lbl_IsReorder, IsValid, CGUI.Color_Label_InputPrimary);
  checkBoolean(HasExpByFile, HasExpFileField, HasExp, CB_HasExpFile, TF_HasExpFile, CmB_HasExpDef, Lbl_HasExp, IsValid, CGUI.Color_Label_InputPrimary);
  
  // check date
  checkDate(OpExpByFile, OpExpFileField, OpExp, CB_OpExpFile, TF_OpExpFile, CB_OpExpDefIsSet, TF_OpExpDefY, CmB_OpExpDefM, CmB_OpExpDefD, Lbl_OpExp, IsValid, CGUI.Color_Label_InputSecondary);
  checkDate(SellUpdateByFile, SellUpdateFileField, SellUpdate, CB_SellUpdateFile, TF_SellUpdateFile, CB_SellUpdateDefIsSet, TF_SellUpdateDefY, CmB_SellUpdateDefM, CmB_SellUpdateDefD, Lbl_SellUpdate, IsValid, CGUI.Color_Label_InputSecondary);
  checkDate(BuyUpdateByFile, BuyUpdateFileField, BuyUpdate, CB_BuyUpdateFile, TF_BuyUpdateFile, CB_BuyUpdateDefIsSet, TF_BuyUpdateDefY, CmB_BuyUpdateDefM, CmB_BuyUpdateDefD, Lbl_BuyUpdate, IsValid, CGUI.Color_Label_InputSecondary);
  
  // check string
  checkString(CommentByFile, CommentFileField, Comment, CB_CommentFile, TF_CommentFile, TA_CommentDef, Lbl_Comment, IsValid, CGUI.Color_Label_InputSecondary, true, CApp.DbVarcharMaxSize);
  checkString(SellCommentByFile, SellCommentFileField, SellComment, CB_SellCommentFile, TF_SellCommentFile, TA_SellCommentDef, Lbl_SellComment, IsValid, CGUI.Color_Label_InputSecondary, true, CApp.DbVarcharMaxSize);
  checkString(BuyCommentByFile, BuyCommentFileField, BuyComment, CB_BuyCommentFile, TF_BuyCommentFile, TA_BuyCommentDef, Lbl_BuyComment, IsValid, CGUI.Color_Label_InputSecondary, true, CApp.DbVarcharMaxSize);
  
  if(!IsValid.getValid()){
   JOptionPane.showMessageDialog(null, "Inputan data masih salah !"+
    "\nSilahkan koreksi inputan data pada label berwarna merah !");
   return;
  }
  
  clearComponents();
  DialogResult=1;
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_ChooseFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseFileActionPerformed
  File f;
  F_CsvReadOption fm=IFV.FCsvReadOption;
  
  f=PGUI.showLoadDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  setFileCsv(f, fm.FieldDelimiter, fm.FieldsSeparators, CCore.CsvRecordsSeparators, true);
 }//GEN-LAST:event_Btn_ChooseFileActionPerformed

 private void Lbl_FileHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileHelpMouseClicked
  JOptionPane.showMessageDialog(null, PMyShop.getReadWriteCsvInfo(true));
 }//GEN-LAST:event_Lbl_FileHelpMouseClicked

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  DialogResult=0;
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  Activ=true;
 }//GEN-LAST:event_formWindowActivated

 private void Lbl_ImportInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ImportInfoMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Hanya mengimpor data barang jika Id dan Nama dari barang tsb belum ada di database."+"\n"+
   "- Semua nilai 'Definisi Sendiri' harus diisi dengan benar."+"\n"+
   "- Dalam proses mengimpor, nilai dari sebuah 'Atribut' akan diutamakan diambil dari 'Field Pada File',"+"\n"+
   "    tetapi jika gagal, maka nilai 'Definisi Sendiri' yg diambil."
   );
 }//GEN-LAST:event_Lbl_ImportInfoMouseClicked

 private void CB_StockUnitFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_StockUnitFileActionPerformed
  enableFileField(CB_StockUnitFile, TF_StockUnitFile);
 }//GEN-LAST:event_CB_StockUnitFileActionPerformed

 private void CB_StockFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_StockFileActionPerformed
  enableFileField(CB_StockFile, TF_StockFile);
 }//GEN-LAST:event_CB_StockFileActionPerformed

 private void CB_UpStockFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_UpStockFileActionPerformed
  enableFileField(CB_UpStockFile, TF_UpStockFile);
 }//GEN-LAST:event_CB_UpStockFileActionPerformed

 private void CB_StockMinFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_StockMinFileActionPerformed
  enableFileField(CB_StockMinFile, TF_StockMinFile);
 }//GEN-LAST:event_CB_StockMinFileActionPerformed

 private void CB_StockMaxFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_StockMaxFileActionPerformed
  enableFileField(CB_StockMaxFile, TF_StockMaxFile);
 }//GEN-LAST:event_CB_StockMaxFileActionPerformed

 private void CB_OpStockFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OpStockFileActionPerformed
  enableFileField(CB_OpStockFile, TF_OpStockFile);
 }//GEN-LAST:event_CB_OpStockFileActionPerformed

 private void CB_OpExpFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OpExpFileActionPerformed
  enableFileField(CB_OpExpFile, TF_OpExpFile);
 }//GEN-LAST:event_CB_OpExpFileActionPerformed

 private void CB_CommentFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_CommentFileActionPerformed
  enableFileField(CB_CommentFile, TF_CommentFile);
 }//GEN-LAST:event_CB_CommentFileActionPerformed

 private void CB_IsActiveFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_IsActiveFileActionPerformed
  enableFileField(CB_IsActiveFile, TF_IsActiveFile);
 }//GEN-LAST:event_CB_IsActiveFileActionPerformed

 private void CB_HasExpFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_HasExpFileActionPerformed
  enableFileField(CB_HasExpFile, TF_HasExpFile);
 }//GEN-LAST:event_CB_HasExpFileActionPerformed

 private void CB_ExpCheckPeriodFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ExpCheckPeriodFileActionPerformed
  enableFileField(CB_ExpCheckPeriodFile, TF_ExpCheckPeriodFile);
 }//GEN-LAST:event_CB_ExpCheckPeriodFileActionPerformed

 private void CB_ExpThresholdFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ExpThresholdFileActionPerformed
  enableFileField(CB_ExpThresholdFile, TF_ExpThresholdFile);
 }//GEN-LAST:event_CB_ExpThresholdFileActionPerformed

 private void CB_SellPriceFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellPriceFileActionPerformed
  enableFileField(CB_SellPriceFile, TF_SellPriceFile);
 }//GEN-LAST:event_CB_SellPriceFileActionPerformed

 private void CB_SellCommentFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellCommentFileActionPerformed
  enableFileField(CB_SellCommentFile, TF_SellCommentFile);
 }//GEN-LAST:event_CB_SellCommentFileActionPerformed

 private void CB_BuyCommentFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyCommentFileActionPerformed
  enableFileField(CB_BuyCommentFile, TF_BuyCommentFile);
 }//GEN-LAST:event_CB_BuyCommentFileActionPerformed

 private void Btn_StockUnitDefChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefChooseActionPerformed
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=false;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblStockUnit;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  setStockUnit((int)IFV.FDataIdName.DataId[0], IFV.FDataIdName.DataName[0]);
 }//GEN-LAST:event_Btn_StockUnitDefChooseActionPerformed

 private void Btn_StockUnitDefClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefClearActionPerformed
  setStockUnit(-1, null);
 }//GEN-LAST:event_Btn_StockUnitDefClearActionPerformed

 private void Lbl_StockDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_StockDefHelpMouseClicked

 private void Lbl_StockMinDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockMinDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_StockMinDefHelpMouseClicked

 private void Lbl_StockMaxHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockMaxHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_StockMaxHelpMouseClicked

 private void Lbl_OpStockDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OpStockDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_OpStockDefHelpMouseClicked

 private void Lbl_CommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_CommentDefHelpMouseClicked

 private void Lbl_ExpCheckPeriodDefMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpCheckPeriodDefMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 9, 2, 7, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpCheckPeriodDefMouseClicked

 private void Lbl_ExpThresholdDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpThresholdDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 9, 2, 3, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpThresholdDefHelpMouseClicked

 private void Lbl_SellPriceDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellPriceDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_SellPriceDefHelpMouseClicked

 private void Lbl_SellCommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellCommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_SellCommentDefHelpMouseClicked

 private void Lbl_BuyCommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyCommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_BuyCommentDefHelpMouseClicked

 private void CB_IdFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_IdFileActionPerformed
  enableFileField(CB_IdFile, TF_IdFile);
 }//GEN-LAST:event_CB_IdFileActionPerformed

 private void CB_OpExpDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OpExpDefIsSetActionPerformed
  PGUI.enableInput(CB_OpExpDefIsSet.isSelected(), TF_OpExpDefY, CmB_OpExpDefM, CmB_OpExpDefD, false);
 }//GEN-LAST:event_CB_OpExpDefIsSetActionPerformed

 private void Lbl_FileField1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileField1MouseClicked
  JOptionPane.showMessageDialog(null,
   "Isi inputan dgn posisi field pd file."+
   "\n(jangkauan nilai mulai dari nilai 1 hingga 'jumlah field pada file').");
 }//GEN-LAST:event_Lbl_FileField1MouseClicked

 private void Lbl_FileField2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileField2MouseClicked
  Lbl_FileField1MouseClicked(null);
 }//GEN-LAST:event_Lbl_FileField2MouseClicked

 private void Lbl_OrderQtyDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderQtyDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_OrderQtyDefHelpMouseClicked

 private void Lbl_BuyPriceEstDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceEstDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPriceEstDefHelpMouseClicked

 private void CB_BuyPriceEstFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyPriceEstFileActionPerformed
  enableFileField(CB_BuyPriceEstFile, TF_BuyPriceEstFile);
 }//GEN-LAST:event_CB_BuyPriceEstFileActionPerformed

 private void CB_OrderQtyFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OrderQtyFileActionPerformed
  enableFileField(CB_OrderQtyFile, TF_OrderQtyFile);
 }//GEN-LAST:event_CB_OrderQtyFileActionPerformed

 private void CB_SellUpdateFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellUpdateFileActionPerformed
  enableFileField(CB_SellUpdateFile, TF_SellUpdateFile);
 }//GEN-LAST:event_CB_SellUpdateFileActionPerformed

 private void CB_BuyUpdateFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyUpdateFileActionPerformed
  enableFileField(CB_BuyUpdateFile, TF_BuyUpdateFile);
 }//GEN-LAST:event_CB_BuyUpdateFileActionPerformed

 private void CB_BuyUpdateDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyUpdateDefIsSetActionPerformed
  PGUI.enableInput(CB_BuyUpdateDefIsSet.isSelected(), TF_BuyUpdateDefY, CmB_BuyUpdateDefM, CmB_BuyUpdateDefD, false);
 }//GEN-LAST:event_CB_BuyUpdateDefIsSetActionPerformed

 private void CB_SellUpdateDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellUpdateDefIsSetActionPerformed
  PGUI.enableInput(CB_SellUpdateDefIsSet.isSelected(), TF_SellUpdateDefY, CmB_SellUpdateDefM, CmB_SellUpdateDefD, false);
 }//GEN-LAST:event_CB_SellUpdateDefIsSetActionPerformed

 private void Lbl_OrderMinPackHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderMinPackHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderMinPackHelpMouseClicked

 private void Lbl_OrderEachPackQtyHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackQtyHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackQtyHelpMouseClicked

 private void Lbl_OrderEachPackThresholdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackThresholdHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Bulatkan menjadi 1 pak jika 'sisa perhitungan' >= 'n' % x 'Order Qty / Pak'."+"\n"+
   "- Jangkauan nilai 'n' adalah 0 < 'n' <= 100."+"\n"+
   PText.getInputInfo(false, 6, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackThresholdHelpMouseClicked

 private void CB_OrderMinPackFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OrderMinPackFileActionPerformed
  enableFileField(CB_OrderMinPackFile, TF_OrderMinPackFile);
 }//GEN-LAST:event_CB_OrderMinPackFileActionPerformed

 private void CB_OrderEachPackQtyFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OrderEachPackQtyFileActionPerformed
  enableFileField(CB_OrderEachPackQtyFile, TF_OrderEachPackQtyFile);
 }//GEN-LAST:event_CB_OrderEachPackQtyFileActionPerformed

 private void CB_OrderEachPackThresholdFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OrderEachPackThresholdFileActionPerformed
  enableFileField(CB_OrderEachPackThresholdFile, TF_OrderEachPackThresholdFile);
 }//GEN-LAST:event_CB_OrderEachPackThresholdFileActionPerformed

 private void CB_IsReorderFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_IsReorderFileActionPerformed
  enableFileField(CB_IsReorderFile, TF_IsReorderFile);
 }//GEN-LAST:event_CB_IsReorderFileActionPerformed

 private void Btn_ChooseFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseFileKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseFileKeyPressed

 private void Tbl_FilePreviewKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_FilePreviewKeyReleased
  PNav.onKey_Tbl(this, Tbl_FilePreview, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IdFile, CB_IdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Tbl_FilePreviewKeyReleased

 private void CB_IdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IdFileKeyPressed
  PNav.onKey_CB(this, CB_IdFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_NameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IdFile)));
 }//GEN-LAST:event_CB_IdFileKeyPressed

 private void TF_IdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IdFileKeyPressed
  PNav.onKey_TF(this, TF_IdFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_NameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_IdFileKeyPressed

 private void TF_NameFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameFileKeyPressed
  PNav.onKey_TF(this, TF_NameFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IdFile, CB_IdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IsActiveFile, CB_IsActiveFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameFileKeyPressed

 private void CB_IsActiveFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsActiveFileKeyPressed
  PNav.onKey_CB(this, CB_IsActiveFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_CommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IsActiveFile, CmB_IsActiveDef)));
 }//GEN-LAST:event_CB_IsActiveFileKeyPressed

 private void TF_IsActiveFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IsActiveFileKeyPressed
  PNav.onKey_TF(this, TF_IsActiveFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CommentFile, CB_CommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsActiveFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsActiveDef)));
 }//GEN-LAST:event_TF_IsActiveFileKeyPressed

 private void CmB_IsActiveDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IsActiveDefKeyPressed
  PNav.onKey_CmB(this, CmB_IsActiveDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_IsActiveFile, CB_IsActiveFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_CommentDef)));
 }//GEN-LAST:event_CmB_IsActiveDefKeyPressed

 private void CB_CommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentFileKeyPressed
  PNav.onKey_CB(this, CB_CommentFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActiveFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockUnitFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CommentFile, TA_CommentDef)));
 }//GEN-LAST:event_CB_CommentFileKeyPressed

 private void TF_CommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CommentFileKeyPressed
  PNav.onKey_TF(this, TF_CommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IsActiveFile, CB_IsActiveFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockUnitFile, CB_StockUnitFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_CommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_CommentDef)));
 }//GEN-LAST:event_TF_CommentFileKeyPressed

 private void TA_CommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentDefKeyPressed
  PNav.onKey_TA(this, TA_CommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_IsActiveDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_StockUnitDefChoose)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CommentFile, CB_CommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_CommentDefKeyPressed

 private void CB_StockUnitFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockUnitFileKeyPressed
  PNav.onKey_CB(this, CB_StockUnitFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_CommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_UpStockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockUnitFile, Btn_StockUnitDefChoose)));
 }//GEN-LAST:event_CB_StockUnitFileKeyPressed

 private void TF_StockUnitFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockUnitFileKeyPressed
  PNav.onKey_TF(this, TF_StockUnitFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CommentFile, CB_CommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_UpStockFile, CB_UpStockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockUnitFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_StockUnitDefChoose)));
 }//GEN-LAST:event_TF_StockUnitFileKeyPressed

 private void Btn_StockUnitDefChooseKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefChooseKeyPressed
  PNav.onKey_Btn(this, Btn_StockUnitDefChoose, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_CommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_UpStockDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockUnitFile, CB_StockUnitFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_StockUnitDefClear)));
 }//GEN-LAST:event_Btn_StockUnitDefChooseKeyPressed

 private void Btn_StockUnitDefClearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefClearKeyPressed
  PNav.onKey_Btn(this, Btn_StockUnitDefClear, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_CommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_UpStockDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_StockUnitDefChoose)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_StockUnitDefClearKeyPressed

 private void CB_UpStockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpStockFileKeyPressed
  PNav.onKey_CB(this, CB_UpStockFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockUnitFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_UpStockFile, CmB_UpStockDef)));
 }//GEN-LAST:event_CB_UpStockFileKeyPressed

 private void TF_UpStockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_UpStockFileKeyPressed
  PNav.onKey_TF(this, TF_UpStockFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockUnitFile, CB_StockUnitFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockFile, CB_StockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_UpStockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_UpStockDef)));
 }//GEN-LAST:event_TF_UpStockFileKeyPressed

 private void CmB_UpStockDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_UpStockDefKeyPressed
  PNav.onKey_CmB(this, CmB_UpStockDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_UpStockFile, CB_UpStockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockDef)));
 }//GEN-LAST:event_CmB_UpStockDefKeyPressed

 private void CB_StockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockFileKeyPressed
  PNav.onKey_CB(this, CB_StockFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_UpStockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockMinFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockFile, TF_StockDef)));
 }//GEN-LAST:event_CB_StockFileKeyPressed

 private void TF_StockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockFileKeyPressed
  PNav.onKey_TF(this, TF_StockFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_UpStockFile, CB_UpStockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMinFile, CB_StockMinFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockDef)));
 }//GEN-LAST:event_TF_StockFileKeyPressed

 private void TF_StockDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockDefKeyPressed
  PNav.onKey_TF(this, TF_StockDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_UpStockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMinDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockFile, CB_StockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_StockDefKeyPressed

 private void CB_StockMinFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockMinFileKeyPressed
  PNav.onKey_CB(this, CB_StockMinFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockMaxFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMinFile, TF_StockMinDef)));
 }//GEN-LAST:event_CB_StockMinFileKeyPressed

 private void TF_StockMinFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMinFileKeyPressed
  PNav.onKey_TF(this, TF_StockMinFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockFile, CB_StockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMaxFile, CB_StockMaxFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockMinFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMinDef)));
 }//GEN-LAST:event_TF_StockMinFileKeyPressed

 private void TF_StockMinDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMinDefKeyPressed
  PNav.onKey_TF(this, TF_StockMinDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMaxDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockMinFile, CB_StockMinFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_StockMinDefKeyPressed

 private void CB_StockMaxFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockMaxFileKeyPressed
  PNav.onKey_CB(this, CB_StockMaxFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockMinFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsOpnameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMaxFile, TF_StockMaxDef)));
 }//GEN-LAST:event_CB_StockMaxFileKeyPressed

 private void TF_StockMaxFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMaxFileKeyPressed
  PNav.onKey_TF(this, TF_StockMaxFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockMinFile, CB_StockMinFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IsOpnameFile, CB_IsOpnameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockMaxFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMaxDef)));
 }//GEN-LAST:event_TF_StockMaxFileKeyPressed

 private void TF_StockMaxDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMaxDefKeyPressed
  PNav.onKey_TF(this, TF_StockMaxDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockMinDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_IsOpnameDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockMaxFile, CB_StockMaxFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_StockMaxDefKeyPressed

 private void CB_IsReorderFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsReorderFileKeyPressed
  PNav.onKey_CB(this, CB_IsReorderFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsOpnameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderEachPackQtyFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IsReorderFile, CmB_IsReorderDef)));
 }//GEN-LAST:event_CB_IsReorderFileKeyPressed

 private void TF_IsReorderFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IsReorderFileKeyPressed
  PNav.onKey_TF(this, TF_IsReorderFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IsOpnameFile, CB_IsOpnameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackQtyFile, CB_OrderEachPackQtyFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsReorderFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsReorderDef)));
 }//GEN-LAST:event_TF_IsReorderFileKeyPressed

 private void CmB_IsReorderDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IsReorderDefKeyPressed
  PNav.onKey_CmB(this, CmB_IsReorderDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_IsReorderFile, CB_IsReorderFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQtyDef)));
 }//GEN-LAST:event_CmB_IsReorderDefKeyPressed

 private void CB_OrderEachPackQtyFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderEachPackQtyFileKeyPressed
  PNav.onKey_CB(this, CB_OrderEachPackQtyFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsReorderFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderEachPackThresholdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQtyFile, TF_OrderEachPackQtyDef)));
 }//GEN-LAST:event_CB_OrderEachPackQtyFileKeyPressed

 private void TF_OrderEachPackQtyFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyFileKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackQtyFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IsReorderFile, CB_IsReorderFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile, CB_OrderEachPackThresholdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderEachPackQtyFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQtyDef)));
 }//GEN-LAST:event_TF_OrderEachPackQtyFileKeyPressed

 private void TF_OrderEachPackQtyDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyDefKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackQtyDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_IsReorderDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackThresholdDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderEachPackQtyFile, CB_OrderEachPackQtyFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderEachPackQtyDefKeyPressed

 private void CB_OrderEachPackThresholdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderEachPackThresholdFileKeyPressed
  PNav.onKey_CB(this, CB_OrderEachPackThresholdFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderEachPackQtyFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderMinPackFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile, TF_OrderEachPackThresholdDef)));
 }//GEN-LAST:event_CB_OrderEachPackThresholdFileKeyPressed

 private void TF_OrderEachPackThresholdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdFileKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackThresholdFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackQtyFile, CB_OrderEachPackQtyFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderMinPackFile, CB_OrderMinPackFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderEachPackThresholdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackThresholdDef)));
 }//GEN-LAST:event_TF_OrderEachPackThresholdFileKeyPressed

 private void TF_OrderEachPackThresholdDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdDefKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackThresholdDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackQtyDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderMinPackDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile, CB_OrderEachPackThresholdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderEachPackThresholdDefKeyPressed

 private void CB_OrderMinPackFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderMinPackFileKeyPressed
  PNav.onKey_CB(this, CB_OrderMinPackFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderEachPackThresholdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_HasExpFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderMinPackFile, TF_OrderMinPackDef)));
 }//GEN-LAST:event_CB_OrderMinPackFileKeyPressed

 private void TF_OrderMinPackFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderMinPackFileKeyPressed
  PNav.onKey_TF(this, TF_OrderMinPackFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile, CB_OrderEachPackThresholdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_HasExpFile, CB_HasExpFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderMinPackFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderMinPackDef)));
 }//GEN-LAST:event_TF_OrderMinPackFileKeyPressed

 private void TF_OrderMinPackDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderMinPackDefKeyPressed
  PNav.onKey_TF(this, TF_OrderMinPackDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackThresholdDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_HasExpDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderMinPackFile, CB_OrderMinPackFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderMinPackDefKeyPressed

 private void CB_HasExpFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_HasExpFileKeyPressed
  PNav.onKey_CB(this, CB_HasExpFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderMinPackFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ExpCheckPeriodFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_HasExpFile, CmB_HasExpDef)));
 }//GEN-LAST:event_CB_HasExpFileKeyPressed

 private void TF_HasExpFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_HasExpFileKeyPressed
  PNav.onKey_TF(this, TF_HasExpFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderMinPackFile, CB_OrderMinPackFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpCheckPeriodFile, CB_ExpCheckPeriodFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_HasExpFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_HasExpDef)));
 }//GEN-LAST:event_TF_HasExpFileKeyPressed

 private void CmB_HasExpDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_HasExpDefKeyPressed
  PNav.onKey_CmB(this, CmB_HasExpDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_HasExpFile, CB_HasExpFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpCheckPeriodDef)));
 }//GEN-LAST:event_CmB_HasExpDefKeyPressed

 private void CB_ExpCheckPeriodFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpCheckPeriodFileKeyPressed
  PNav.onKey_CB(this, CB_ExpCheckPeriodFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_HasExpFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ExpThresholdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpCheckPeriodFile, TF_ExpCheckPeriodDef)));
 }//GEN-LAST:event_CB_ExpCheckPeriodFileKeyPressed

 private void TF_ExpCheckPeriodFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpCheckPeriodFileKeyPressed
  PNav.onKey_TF(this, TF_ExpCheckPeriodFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_HasExpFile, CB_HasExpFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpThresholdFile, CB_ExpThresholdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ExpCheckPeriodFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpCheckPeriodDef)));
 }//GEN-LAST:event_TF_ExpCheckPeriodFileKeyPressed

 private void TF_ExpCheckPeriodDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpCheckPeriodDefKeyPressed
  PNav.onKey_TF(this, TF_ExpCheckPeriodDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_HasExpDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpThresholdDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ExpCheckPeriodFile, CB_ExpCheckPeriodFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpCheckPeriodDefKeyPressed

 private void CB_ExpThresholdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpThresholdFileKeyPressed
  PNav.onKey_CB(this, CB_ExpThresholdFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ExpCheckPeriodFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellPriceFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpThresholdFile, TF_ExpThresholdDef)));
 }//GEN-LAST:event_CB_ExpThresholdFileKeyPressed

 private void TF_ExpThresholdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpThresholdFileKeyPressed
  PNav.onKey_TF(this, TF_ExpThresholdFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpCheckPeriodFile, CB_ExpCheckPeriodFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellPriceFile, CB_SellPriceFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ExpThresholdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpThresholdDef)));
 }//GEN-LAST:event_TF_ExpThresholdFileKeyPressed

 private void TF_ExpThresholdDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpThresholdDefKeyPressed
  PNav.onKey_TF(this, TF_ExpThresholdDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpCheckPeriodDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellPriceDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ExpThresholdFile, CB_ExpThresholdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpThresholdDefKeyPressed

 private void CB_SellPriceFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellPriceFileKeyPressed
  PNav.onKey_CB(this, CB_SellPriceFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ExpThresholdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdateFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellPriceFile, TF_SellPriceDef)));
 }//GEN-LAST:event_CB_SellPriceFileKeyPressed

 private void TF_SellPriceFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellPriceFileKeyPressed
  PNav.onKey_TF(this, TF_SellPriceFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpThresholdFile, CB_ExpThresholdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellUpdateFile, CB_SellUpdateFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellPriceFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellPriceDef)));
 }//GEN-LAST:event_TF_SellPriceFileKeyPressed

 private void TF_SellPriceDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellPriceDefKeyPressed
  PNav.onKey_TF(this, TF_SellPriceDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpThresholdDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellPriceFile, CB_SellPriceFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_SellPriceDefKeyPressed

 private void CB_SellUpdateFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateFileKeyPressed
  PNav.onKey_CB(this, CB_SellUpdateFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellPriceFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellCommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellUpdateFile, CB_SellUpdateDefIsSet)));
 }//GEN-LAST:event_CB_SellUpdateFileKeyPressed

 private void TF_SellUpdateFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellUpdateFileKeyPressed
  PNav.onKey_TF(this, TF_SellUpdateFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellPriceFile, CB_SellPriceFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellCommentFile, CB_SellCommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdateFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)));
 }//GEN-LAST:event_TF_SellUpdateFileKeyPressed

 private void CB_SellUpdateDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_SellUpdateDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellPriceDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellUpdateFile, CB_SellUpdateFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellUpdateDefY)));
 }//GEN-LAST:event_CB_SellUpdateDefIsSetKeyPressed

 private void TF_SellUpdateDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellUpdateDefYKeyPressed
  PNav.onKey_TF(this, TF_SellUpdateDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellPriceDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateDefM)));
 }//GEN-LAST:event_TF_SellUpdateDefYKeyPressed

 private void CmB_SellUpdateDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateDefMKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellUpdateDefY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateDefD)));
 }//GEN-LAST:event_CmB_SellUpdateDefMKeyPressed

 private void CmB_SellUpdateDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateDefDKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SellUpdateDefM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_SellCommentDef)));
 }//GEN-LAST:event_CmB_SellUpdateDefDKeyPressed

 private void CB_SellCommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellCommentFileKeyPressed
  PNav.onKey_CB(this, CB_SellCommentFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdateFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyPriceEstFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellCommentFile, TA_SellCommentDef)));
 }//GEN-LAST:event_CB_SellCommentFileKeyPressed

 private void TF_SellCommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellCommentFileKeyPressed
  PNav.onKey_TF(this, TF_SellCommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellUpdateFile, CB_SellUpdateFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceEstFile, CB_BuyPriceEstFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellCommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_SellCommentDef)));
 }//GEN-LAST:event_TF_SellCommentFileKeyPressed

 private void TA_SellCommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_SellCommentDefKeyPressed
  PNav.onKey_TA(this, TA_SellCommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceEstDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellCommentFile, CB_SellCommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_SellCommentDefKeyPressed

 private void CB_BuyPriceEstFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyPriceEstFileKeyPressed
  PNav.onKey_CB(this, CB_BuyPriceEstFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellCommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdateFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPriceEstFile, TF_BuyPriceEstDef)));
 }//GEN-LAST:event_CB_BuyPriceEstFileKeyPressed

 private void TF_BuyPriceEstFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstFileKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceEstFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellCommentFile, CB_SellCommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyUpdateFile, CB_BuyUpdateFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyPriceEstFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPriceEstDef)));
 }//GEN-LAST:event_TF_BuyPriceEstFileKeyPressed

 private void TF_BuyPriceEstDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstDefKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceEstDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_SellCommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyPriceEstFile, CB_BuyPriceEstFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPriceEstDefKeyPressed

 private void CB_BuyUpdateFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateFileKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdateFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyPriceEstFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyCommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateFile, CB_BuyUpdateDefIsSet)));
 }//GEN-LAST:event_CB_BuyUpdateFileKeyPressed

 private void TF_BuyUpdateFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateFileKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEstFile, CB_BuyPriceEstFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyCommentFile, CB_BuyCommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdateFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)));
 }//GEN-LAST:event_TF_BuyUpdateFileKeyPressed

 private void CB_BuyUpdateDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdateDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEstDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateFile, CB_BuyUpdateFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateDefY)));
 }//GEN-LAST:event_CB_BuyUpdateDefIsSetKeyPressed

 private void TF_BuyUpdateDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateDefYKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEstDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateDefM)));
 }//GEN-LAST:event_TF_BuyUpdateDefYKeyPressed

 private void CmB_BuyUpdateDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDefMKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateDefY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateDefD)));
 }//GEN-LAST:event_CmB_BuyUpdateDefMKeyPressed

 private void CmB_BuyUpdateDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDefDKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateDefM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_BuyCommentDef)));
 }//GEN-LAST:event_CmB_BuyUpdateDefDKeyPressed

 private void CB_BuyCommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyCommentFileKeyPressed
  PNav.onKey_CB(this, CB_BuyCommentFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpStockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyCommentFile, TA_BuyCommentDef)));
 }//GEN-LAST:event_CB_BuyCommentFileKeyPressed

 private void TF_BuyCommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyCommentFileKeyPressed
  PNav.onKey_TF(this, TF_BuyCommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyUpdateFile, CB_BuyUpdateFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpStockFile, CB_OpStockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyCommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_BuyCommentDef)));
 }//GEN-LAST:event_TF_BuyCommentFileKeyPressed

 private void TA_BuyCommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyCommentDefKeyPressed
  PNav.onKey_TA(this, TA_BuyCommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpStockDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyCommentFile, CB_BuyCommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyCommentDefKeyPressed

 private void CB_OpStockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpStockFileKeyPressed
  PNav.onKey_CB(this, CB_OpStockFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyCommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExpFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpStockFile, TF_OpStockDef)));
 }//GEN-LAST:event_CB_OpStockFileKeyPressed

 private void TF_OpStockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpStockFileKeyPressed
  PNav.onKey_TF(this, TF_OpStockFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyCommentFile, CB_BuyCommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpExpFile, CB_OpExpFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpStockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpStockDef)));
 }//GEN-LAST:event_TF_OpStockFileKeyPressed

 private void TF_OpStockDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpStockDefKeyPressed
  PNav.onKey_TF(this, TF_OpStockDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyCommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExpDefIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpStockFile, CB_OpStockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OpStockDefKeyPressed

 private void CB_OpExpFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpFileKeyPressed
  PNav.onKey_CB(this, CB_OpExpFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpStockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderQtyFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpExpFile, CB_OpExpDefIsSet)));
 }//GEN-LAST:event_CB_OpExpFileKeyPressed

 private void TF_OpExpFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpExpFileKeyPressed
  PNav.onKey_TF(this, TF_OpExpFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStockFile, CB_OpStockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQtyFile, CB_OrderQtyFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExpFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_OpExpDefIsSet)));
 }//GEN-LAST:event_TF_OpExpFileKeyPressed

 private void CB_OpExpDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_OpExpDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQtyDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpExpFile, CB_OpExpFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpExpDefY)));
 }//GEN-LAST:event_CB_OpExpDefIsSetKeyPressed

 private void TF_OpExpDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpExpDefYKeyPressed
  PNav.onKey_TF(this, TF_OpExpDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQtyDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExpDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpDefM)));
 }//GEN-LAST:event_TF_OpExpDefYKeyPressed

 private void CmB_OpExpDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpDefMKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpExpDefY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpDefD)));
 }//GEN-LAST:event_CmB_OpExpDefMKeyPressed

 private void CmB_OpExpDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpDefDKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_OpExpDefM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQtyDef)));
 }//GEN-LAST:event_CmB_OpExpDefDKeyPressed

 private void CB_OrderQtyFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderQtyFileKeyPressed
  PNav.onKey_CB(this, CB_OrderQtyFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExpFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQtyFile, TF_OrderQtyDef)));
 }//GEN-LAST:event_CB_OrderQtyFileKeyPressed

 private void TF_OrderQtyFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderQtyFileKeyPressed
  PNav.onKey_TF(this, TF_OrderQtyFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpExpFile, CB_OpExpFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderQtyFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQtyDef)));
 }//GEN-LAST:event_TF_OrderQtyFileKeyPressed

 private void TF_OrderQtyDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderQtyDefKeyPressed
  PNav.onKey_TF(this, TF_OrderQtyDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExpDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderQtyFile, CB_OrderQtyFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderQtyDefKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderQtyFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderQtyFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void CB_IsOpnameFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_IsOpnameFileActionPerformed
  enableFileField(CB_IsOpnameFile, TF_IsOpnameFile);
 }//GEN-LAST:event_CB_IsOpnameFileActionPerformed

 private void CB_IsOpnameFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsOpnameFileKeyPressed
  PNav.onKey_CB(this, CB_IsOpnameFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockMaxFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsReorderFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IsOpnameFile, CmB_IsOpnameDef)));
 }//GEN-LAST:event_CB_IsOpnameFileKeyPressed

 private void TF_IsOpnameFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IsOpnameFileKeyPressed
  PNav.onKey_TF(this, TF_IsOpnameFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockMaxFile, CB_StockMaxFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IsReorderFile, CB_IsReorderFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsOpnameFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsOpnameDef)));
 }//GEN-LAST:event_TF_IsOpnameFileKeyPressed

 private void CmB_IsOpnameDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IsOpnameDefKeyPressed
  PNav.onKey_CmB(this, CmB_IsOpnameDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_IsOpnameFile, CB_IsOpnameFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsReorderDef)));
 }//GEN-LAST:event_CmB_IsOpnameDefKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseFile;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_StockUnitDefChoose;
 private javax.swing.JButton Btn_StockUnitDefClear;
 private javax.swing.JCheckBox CB_BuyCommentFile;
 private javax.swing.JCheckBox CB_BuyPriceEstFile;
 private javax.swing.JCheckBox CB_BuyUpdateDefIsSet;
 private javax.swing.JCheckBox CB_BuyUpdateFile;
 private javax.swing.JCheckBox CB_CommentFile;
 private javax.swing.JCheckBox CB_ExpCheckPeriodFile;
 private javax.swing.JCheckBox CB_ExpThresholdFile;
 private javax.swing.JCheckBox CB_HasExpFile;
 private javax.swing.JCheckBox CB_IdFile;
 private javax.swing.JCheckBox CB_IsActiveFile;
 private javax.swing.JCheckBox CB_IsOpnameFile;
 private javax.swing.JCheckBox CB_IsReorderFile;
 private javax.swing.JCheckBox CB_OpExpDefIsSet;
 private javax.swing.JCheckBox CB_OpExpFile;
 private javax.swing.JCheckBox CB_OpStockFile;
 private javax.swing.JCheckBox CB_OrderEachPackQtyFile;
 private javax.swing.JCheckBox CB_OrderEachPackThresholdFile;
 private javax.swing.JCheckBox CB_OrderMinPackFile;
 private javax.swing.JCheckBox CB_OrderQtyFile;
 private javax.swing.JCheckBox CB_SellCommentFile;
 private javax.swing.JCheckBox CB_SellPriceFile;
 private javax.swing.JCheckBox CB_SellUpdateDefIsSet;
 private javax.swing.JCheckBox CB_SellUpdateFile;
 private javax.swing.JCheckBox CB_StockFile;
 private javax.swing.JCheckBox CB_StockMaxFile;
 private javax.swing.JCheckBox CB_StockMinFile;
 private javax.swing.JCheckBox CB_StockUnitFile;
 private javax.swing.JCheckBox CB_UpStockFile;
 private javax.swing.JComboBox<String> CmB_BuyUpdateDefD;
 private javax.swing.JComboBox<String> CmB_BuyUpdateDefM;
 private javax.swing.JComboBox<String> CmB_HasExpDef;
 private javax.swing.JComboBox<String> CmB_IsActiveDef;
 private javax.swing.JComboBox<String> CmB_IsOpnameDef;
 private javax.swing.JComboBox<String> CmB_IsReorderDef;
 private javax.swing.JComboBox<String> CmB_OpExpDefD;
 private javax.swing.JComboBox<String> CmB_OpExpDefM;
 private javax.swing.JComboBox<String> CmB_SellUpdateDefD;
 private javax.swing.JComboBox<String> CmB_SellUpdateDefM;
 private javax.swing.JComboBox<String> CmB_UpStockDef;
 private javax.swing.JLabel Lbl_BuyComment;
 private javax.swing.JLabel Lbl_BuyCommentDefHelp;
 private javax.swing.JLabel Lbl_BuyPriceEst;
 private javax.swing.JLabel Lbl_BuyPriceEstDefHelp;
 private javax.swing.JLabel Lbl_BuyUpdate;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_CommentDefHelp;
 private javax.swing.JLabel Lbl_ExpCheckPeriod;
 private javax.swing.JLabel Lbl_ExpCheckPeriodDef;
 private javax.swing.JLabel Lbl_ExpThreshold;
 private javax.swing.JLabel Lbl_ExpThresholdDefHelp;
 private javax.swing.JLabel Lbl_File;
 private javax.swing.JLabel Lbl_FileField1;
 private javax.swing.JLabel Lbl_FileField2;
 private javax.swing.JLabel Lbl_FileHelp;
 private javax.swing.JLabel Lbl_HasExp;
 private javax.swing.JLabel Lbl_Id;
 private javax.swing.JLabel Lbl_ImportInfo;
 private javax.swing.JLabel Lbl_IsActive;
 private javax.swing.JLabel Lbl_IsOpname;
 private javax.swing.JLabel Lbl_IsReorder;
 private javax.swing.JLabel Lbl_Name;
 private javax.swing.JLabel Lbl_OpExp;
 private javax.swing.JLabel Lbl_OpStock;
 private javax.swing.JLabel Lbl_OpStockDefHelp;
 private javax.swing.JLabel Lbl_OrderEachPackQty;
 private javax.swing.JLabel Lbl_OrderEachPackQtyHelp;
 private javax.swing.JLabel Lbl_OrderEachPackThreshold;
 private javax.swing.JLabel Lbl_OrderEachPackThresholdHelp;
 private javax.swing.JLabel Lbl_OrderMinPack;
 private javax.swing.JLabel Lbl_OrderMinPackHelp;
 private javax.swing.JLabel Lbl_OrderQty;
 private javax.swing.JLabel Lbl_OrderQtyDefHelp;
 private javax.swing.JLabel Lbl_SellComment;
 private javax.swing.JLabel Lbl_SellCommentDefHelp;
 private javax.swing.JLabel Lbl_SellPrice;
 private javax.swing.JLabel Lbl_SellPriceDefHelp;
 private javax.swing.JLabel Lbl_SellUpdate;
 private javax.swing.JLabel Lbl_Stock;
 private javax.swing.JLabel Lbl_StockDefHelp;
 private javax.swing.JLabel Lbl_StockMax;
 private javax.swing.JLabel Lbl_StockMaxHelp;
 private javax.swing.JLabel Lbl_StockMin;
 private javax.swing.JLabel Lbl_StockMinDefHelp;
 private javax.swing.JLabel Lbl_StockUnit;
 private javax.swing.JLabel Lbl_UpStock;
 private javax.swing.ButtonGroup RG_Id;
 private javax.swing.JTextArea TA_BuyCommentDef;
 private javax.swing.JTextArea TA_CommentDef;
 private javax.swing.JTextArea TA_SellCommentDef;
 private javax.swing.JTextField TF_BuyCommentFile;
 private javax.swing.JTextField TF_BuyPriceEstDef;
 private javax.swing.JTextField TF_BuyPriceEstFile;
 private javax.swing.JTextField TF_BuyUpdateDefY;
 private javax.swing.JTextField TF_BuyUpdateFile;
 private javax.swing.JTextField TF_CommentFile;
 private javax.swing.JTextField TF_ExpCheckPeriodDef;
 private javax.swing.JTextField TF_ExpCheckPeriodFile;
 private javax.swing.JTextField TF_ExpThresholdDef;
 private javax.swing.JTextField TF_ExpThresholdFile;
 private javax.swing.JTextField TF_File;
 private javax.swing.JTextField TF_FileInfo;
 private javax.swing.JTextField TF_HasExpFile;
 private javax.swing.JTextField TF_IdDef;
 private javax.swing.JTextField TF_IdFile;
 private javax.swing.JTextField TF_IsActiveFile;
 private javax.swing.JTextField TF_IsOpnameFile;
 private javax.swing.JTextField TF_IsReorderFile;
 private javax.swing.JTextField TF_NameFile;
 private javax.swing.JTextField TF_OpExpDefY;
 private javax.swing.JTextField TF_OpExpFile;
 private javax.swing.JTextField TF_OpStockDef;
 private javax.swing.JTextField TF_OpStockFile;
 private javax.swing.JTextField TF_OrderEachPackQtyDef;
 private javax.swing.JTextField TF_OrderEachPackQtyFile;
 private javax.swing.JTextField TF_OrderEachPackThresholdDef;
 private javax.swing.JTextField TF_OrderEachPackThresholdFile;
 private javax.swing.JTextField TF_OrderMinPackDef;
 private javax.swing.JTextField TF_OrderMinPackFile;
 private javax.swing.JTextField TF_OrderQtyDef;
 private javax.swing.JTextField TF_OrderQtyFile;
 private javax.swing.JTextField TF_SellCommentFile;
 private javax.swing.JTextField TF_SellPriceDef;
 private javax.swing.JTextField TF_SellPriceFile;
 private javax.swing.JTextField TF_SellUpdateDefY;
 private javax.swing.JTextField TF_SellUpdateFile;
 private javax.swing.JTextField TF_StockDef;
 private javax.swing.JTextField TF_StockFile;
 private javax.swing.JTextField TF_StockMaxDef;
 private javax.swing.JTextField TF_StockMaxFile;
 private javax.swing.JTextField TF_StockMinDef;
 private javax.swing.JTextField TF_StockMinFile;
 private javax.swing.JTextField TF_StockUnitDef;
 private javax.swing.JTextField TF_StockUnitFile;
 private javax.swing.JTextField TF_UpStockFile;
 private XTable Tbl_FilePreview;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel21;
 private javax.swing.JLabel jLabel23;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JSeparator jSeparator1;
 // End of variables declaration//GEN-END:variables
}
