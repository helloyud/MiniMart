import java.sql.Statement;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;

public class OInstructionsTable  extends OInstructions{

 public static final int InstructionsType=2;
 public int getInstructionsType(){return InstructionsType;}

 /* Instructions code:
    1 fill table by FillMode
      (& check PassSumResult)
 */

 // table metadata
 public String[] ColumnsName;
 public int[] ColumnsType;
 public int[] ColumnsShowOption;
 public int[] ColumnsVisible;
 public int[] ColumnsWidth;
 
 // if there is Id in the column, then define ColumnId
 public int[] ColumnId; // null = no Id column, not null = list of columns index that is defined as Id
 
 public int FillTableMode; // 1 CustomTableData, 2 SqlQuery
	public Vector<Object[]> CustomTableData;
	public String SqlQuery;
 
 public boolean PassSumResult;
 public boolean[] SumColumn;
 public double[] SumResult;
 public int[] ColumnsToBePassed;

 public OInstructionsTable() {
  super();
 }

 void clearProcessedDataAdditional() {}
 void processing(OFormSupportsInstructions Form) throws Exception {
  JTable Table=Form.getTable();
  OCustomTableModel TableMdl=(OCustomTableModel)Table.getModel();
  JTextField TFCount=Form.getTableCount();
  JComboBox CmBIdColumn=Form.getTableIdColumn();
  OCustomComboBoxModel CmBIdColumnMdl=(OCustomComboBoxModel)CmBIdColumn.getModel();
  Statement Stm=Form.getStatement();
  
  int insttemp;
  
  insttemp=0;
  do{
   switch(Instructions[insttemp]){
    case 1: fillTable(Stm, TableMdl, Table, TFCount, CmBIdColumnMdl, CmBIdColumn); break;
   }
   insttemp=insttemp+1;
  }while(insttemp!=Instructions.length);
  
  Form.getTableResultSign().setSelected(true);
 }
 
 void fillTable(Statement Stm, OCustomTableModel TableMdl, JTable TableGUI,
  JTextField TFCount, OCustomComboBoxModel CmBIdColumnMdl, JComboBox CmBIdColumnGUI)
  throws Exception{
  int temp, temp2;
  OAnObject Obj;
  
  TableMdl.updateColumnsInfo(ColumnsName, ColumnsType, ColumnsShowOption, ColumnsVisible, true);
  PGUI.resizeTableColumn(TableGUI, ColumnsWidth);
  
  CmBIdColumnMdl.removeAll();
  if(ColumnId==null){CmBIdColumnMdl.append(PCore.objArrVariant(-1, "Tdk ada kolom Id"));}
  else{
   temp=ColumnId.length;
   temp2=0;
   do{
    CmBIdColumnMdl.append(PCore.objArrVariant(ColumnId[temp2], ColumnsName[ColumnId[temp2]]));
    temp2=temp2+1;
   }while(temp2!=temp);
  }
  CmBIdColumnGUI.setSelectedIndex(0);
  
  temp=0;
		switch(FillTableMode){
			case 1 :
				TableMdl.append(CustomTableData);
				temp=CustomTableData.size();
				break;
			case 2 :
				if(!PassSumResult){temp=PDatabase.queryToTable(Stm, SqlQuery, TableMdl, false,  false, null, -1, false, -1);}
				else{temp=PDatabase.queryToTableWithSum(Stm, SqlQuery, TableMdl, SumColumn, SumResult, false, false, null, -1, false, -1);}
				break;
		}
  
  TFCount.setText(PText.intToString(temp));
  
  if(PassSumResult && Next!=null){
   temp=ColumnsToBePassed.length;
   temp2=0;
   do{
    Obj=new OAnObject(SumResult[ColumnsToBePassed[temp2]], true);
    Next.PreviousData.addElement(Obj);
    temp2=temp2+1;
   }while(temp2!=temp);
  }
 }

}