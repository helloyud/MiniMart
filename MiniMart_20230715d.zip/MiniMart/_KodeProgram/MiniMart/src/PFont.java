import java.awt.Font;
import java.util.Vector;

public class PFont {
 
 public static Font getFont(String FontFamily, float FontSize, boolean IsBold, boolean IsItalic){
  Font ret=null;
  int Style;
  
  Style=Font.PLAIN;
  if(IsItalic){Style=Style|Font.ITALIC;}
  if(IsBold){Style=Style|Font.BOLD;}
  ret=new Font(FontFamily, Style, (int)FontSize);
  if(PMath.isFraction(FontSize)){ret=ret.deriveFont(FontSize);}
  
  return ret;
 }

 public static boolean isMonospace(Font Fnt){
  boolean ret=false;
  Vector<char[]> CheckList;
  char[] CurrCheckList;
  int temp, count;
  int ch_temp, ch_count;
  double char_width;
  
  char_width=PGraphics.getStringWidth(Fnt, String.valueOf("W"));
  
  CheckList=new Vector();
  CheckList.addElement(CCore.Chars_a_z);
  CheckList.addElement(CCore.Chars_A_Z);
  CheckList.addElement(CCore.Chars_0_9);
  CheckList.addElement(CCore.Chars_Symbol);
  
  count=CheckList.size();
  temp=0;
  do{
   CurrCheckList=CheckList.elementAt(temp);
   ch_count=CurrCheckList.length;
   ch_temp=0;
   do{
    if(!PMath.compare(PGraphics.getStringWidth(Fnt, String.valueOf(CurrCheckList[ch_temp])), char_width, 0.05)){break;}
    ch_temp=ch_temp+1;
   }while(ch_temp!=ch_count);
   if(ch_temp!=ch_count){break;}

   temp=temp+1;
  }while(temp!=count);
  if(temp==count){ret=true;}
  
  return ret;
 }
 public static int getFontFileType(String FontFileName){
  int ret=-1;
  
  do{
   if(PFile.compareIgnoreCaseExtension(FontFileName, "ttf")){ret=Font.TRUETYPE_FONT; break;}
   if(PFile.compareIgnoreCaseExtension(FontFileName, "otf")){/*unsupported yet*/; break;}
  }while(false);
  
  return ret;
 }

}