import java.awt.Window;

public interface OFormInformProgress {
 // Progress is range from 0 to 100
 public void inform(double IncreaseProgress, String Process, String SubProcess);
 public double getProgress();
 public void setProgressIncreasePercentage(double ProgressIncreasePercentage); // 0 to 100
 public void limitProgress(double ProgressLimit);
 public void unlimitProgress();
 public double getProgressLimit();
 public void setEnableChangeTextProcess(boolean Enable);
 public void setEnableChangeTextSubProcess(boolean Enable);
 public void setMoveTextProcessToSubProcess(boolean Value);
 public void progressInformExternalMode(boolean Value, double IncPercentage);
 public void appear(Window FormBef, String Title);
 public void disappear();
}