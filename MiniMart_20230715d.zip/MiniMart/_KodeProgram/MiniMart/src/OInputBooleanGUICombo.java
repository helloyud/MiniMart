import javax.swing.JComboBox;

public class OInputBooleanGUICombo extends OInput {
 
 JComboBox GUI_Combo; // ComboBox must contain : index 0 = yes, index 1 = no
 
 VBoolean Value;

 public OInputBooleanGUICombo(JComboBox GUI_Combo) {
  this.GUI_Combo = GUI_Combo;
  Value=new VBoolean();
 }
 
 public boolean isValid(){return PGUI.checkInputBoolean(GUI_Combo, Value);}
 public Object getValue(){return Value.Value;}
 
}