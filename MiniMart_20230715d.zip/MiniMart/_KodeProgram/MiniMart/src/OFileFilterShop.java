import java.io.File;
import javax.swing.filechooser.FileFilter;

class OFileFilterShop extends FileFilter{
 public boolean accept(File path){
  boolean ret=true;
  if(path.isFile()){
   ret=PFile.compareIgnoreCaseExtension(path.getName(), "shop");
  }
  return ret;
 }
 public String getDescription(){
  return new String("File Backup Data MiniMart (.shop)");
 }
}