import java.util.Date;

public class OEditSubject {

 boolean EditName; boolean ReplaceSubName; String SubName; String EditedName;
 boolean EditBirthday; Date EditedBirthday;
 boolean EditComment; boolean ReplaceSubComment; String SubComment; String EditedComment;

 public OEditSubject(){clearAll();}
 
 OEditSubject clearAll(){
  init(
   false, false, null, null,
   false, null,
   false, false, null, null);
  
  return this;
 }
 
 OEditSubject init(
  boolean EditName, boolean ReplaceSubName, String SubName, String EditedName,
  boolean EditBirthday, Date EditedBirthday,
  boolean EditComment, boolean ReplaceSubComment, String SubComment, String EditedComment) {
  
  this.EditName = EditName; this.ReplaceSubName = ReplaceSubName; this.SubName = SubName; this.EditedName = EditedName;
  this.EditBirthday = EditBirthday; this.EditedBirthday = EditedBirthday;
  this.EditComment = EditComment; this.ReplaceSubComment = ReplaceSubComment; this.SubComment = SubComment; this.EditedComment = EditedComment;
 
  return this;
 }

}