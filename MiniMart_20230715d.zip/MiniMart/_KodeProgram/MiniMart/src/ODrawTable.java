import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Vector;

public class ODrawTable {
 
 // Table
 double Height;
 double Width;

 // Column
 ODrawTableColumnMetadata[] Columns;
 int ColumnsCount;
 
 // Row
 Vector<ODrawTableRow> Rows;
 
 // Content/Cell
 OInset Inset;
 
 // Border
 ODrawTableBorder Border;
 
 //
 ODrawTable(ODrawTableColumnMetadata[] Columns, OInset Inset, ODrawTableBorder Border){
  init(Columns, Inset, Border);
 }
 void init(ODrawTableColumnMetadata[] Columns, OInset Inset, ODrawTableBorder Border){
  int temp;
  
  this.Columns=Columns;
  ColumnsCount=Columns.length;
  
  Rows=new Vector();
  
  this.Inset=Inset;
  this.Border=Border;
  
  Width=0;
  temp=0;
  do{
   Width=Width+Columns[temp].Width;
   temp=temp+1;
  }while(temp!=ColumnsCount);
  Height=0;
 }
 
 //
 public void insertARow(int RowIndex, ODrawTableRow Row){
  Rows.insertElementAt(Row, RowIndex);
  Height=Height+Row.Height;
 }
 public void changeRowHeight(int RowIndex, double NewRowHeight){
  ODrawTableRow Row=Rows.elementAt(RowIndex);
  Height=Height-Row.Height+NewRowHeight;
  Row.setHeight(NewRowHeight);
 }
 public ODrawTableRow getRowHeader(Font FontType, double AddLineSpacing, OAlignment Alignment,
  boolean FitLine, int FitLineCount, boolean FitLineFixedTopSide, int FitLineFixedSideCount,
  boolean ConcatenateFixedLeftSide, double ConcatenateFixedSidePercentage, int ConcatenateDotCount, char ConcatenateDotChar){
  ODrawTableRow ret=null;
  ODrawTableRow rettemp;
  int temp;
  ODimension dim;
  
  do{
   rettemp=new ODrawTableRow(0, ColumnsCount);
   
   temp=0;
   do{
    rettemp.setCell(temp, new ODrawTableCellText(PText.getString(Columns[temp].Name, "", false), FontType, AddLineSpacing, Alignment,
     FitLine, FitLineCount, FitLineFixedTopSide, FitLineFixedSideCount,
     ConcatenateFixedLeftSide, ConcatenateFixedSidePercentage, ConcatenateDotCount, ConcatenateDotChar));

    temp=temp+1;
   }while(temp!=ColumnsCount);
   
   if(rettemp.preGenerateCellsDrawContents(this, 0)==false){break;}
   dim=rettemp.calculatePreGeneratedCellsDrawContentsDimension(this, 0);
   rettemp.setHeight(dim.getHeight()+(Inset.InsetTop+Inset.InsetBottom));
   rettemp.generateCellsDrawContents(this, 0);
   
   ret=rettemp;
  }while(false);
  
  return ret;
 }
 
 public void draw(Graphics2D g, OGraphicsProperties Prop, double OffsetX, double OffsetY){
  int temp_row, temp_column, rowcount;
  double temp_y, temp_x;
  double CurrX, CurrY, CurrRowHeight, CurrColumnWidth;
  ODrawTableCell Cell;
  
  rowcount=Rows.size();
  if(rowcount==0){return;}
  
  // paint horizontal border
  temp_x=OffsetX+Width;
  
  if(Border.FillBorderTop){
   PGraphics.paintLine(g, OffsetX, OffsetY, temp_x, OffsetY, Border.BorderWidth);
  }
  
  if(Border.FillBorderInsideHorizontal && rowcount>1){
   /* paint characteristic : paint start from (2nd row) to (last row); for each row, paint border at top side) */
   CurrY=OffsetY+Rows.elementAt(0).Height;
   temp_row=1;
   do{
    temp_y=CurrY;
    PGraphics.paintLine(g, OffsetX, temp_y, temp_x, temp_y, Border.BorderWidth);
     
    CurrY=CurrY+Rows.elementAt(temp_row).Height;
    temp_row=temp_row+1;
   }while(temp_row!=rowcount);
  }
  
  if(Border.FillBorderBottom){
   temp_y=OffsetY+Height;
   PGraphics.paintLine(g, OffsetX, temp_y, temp_x, temp_y, Border.BorderWidth);
  }
  
  // paint vertical border
  temp_y=OffsetY+Height;
  
  if(Border.FillBorderLeft){
   PGraphics.paintLine(g, OffsetX, OffsetY, OffsetX, temp_y, Border.BorderWidth);
  }
  
  if(Border.FillBorderInsideVertical && ColumnsCount>1){
   /* paint characteristic : paint start from (2nd column) to (last column); for each column, paint border at left side) */
   CurrX=OffsetX+Columns[0].Width;
   temp_column=1;
   do{
    temp_x=CurrX;
    PGraphics.paintLine(g, temp_x, OffsetY, temp_x, temp_y, Border.BorderWidth);
    
    CurrX=CurrX+Columns[temp_column].Width;
    temp_column=temp_column+1;
   }while(temp_column!=ColumnsCount);
  }
  
  if(Border.FillBorderRight){
   temp_x=OffsetX+Width;
   PGraphics.paintLine(g, temp_x, OffsetY, temp_x, temp_y, Border.BorderWidth);
  }
  
  
  // paint content (row by row)
  CurrY=OffsetY;
  temp_row=0;
  do{
			CurrRowHeight=Rows.elementAt(temp_row).Height;
			
   CurrX=OffsetX;
   temp_column=0;
   do{
				CurrColumnWidth=Columns[temp_column].Width;
				
    // paint content
    Cell=Rows.elementAt(temp_row).Cells[temp_column];
    if(Cell!=null){
     Cell.drawInCell(g, Prop, CurrX+Inset.InsetLeft, CurrY+Inset.InsetTop);
    }
    
    CurrX=CurrX+CurrColumnWidth;
    temp_column=temp_column+1;
   }while(temp_column!=ColumnsCount);
   
   CurrY=CurrY+CurrRowHeight;
   temp_row=temp_row+1;
  }while(temp_row!=rowcount);
  
 }
 
 public ODrawTable createNewTable(){
  return new ODrawTable(Columns, Inset, Border);
 }
 
}