import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;

public class OActionKeyFocusAuto extends OActionKey {
 
 boolean IsForward;

 public OActionKeyFocusAuto(){}
 public OActionKeyFocusAuto(boolean IsForward) {
  init(IsForward);
 }
 public OActionKeyFocusAuto(
  Window Form, Component Cmp, KeyEvent evt,
  boolean IsForward) {
  
  init(Form, Cmp, evt, IsForward);
 
 }
 
 OActionKeyFocusAuto init(boolean IsForward){
  this.IsForward = IsForward;
  return this;
 }
 OActionKeyFocusAuto init(
  Window Form, Component Cmp, KeyEvent evt,
  boolean IsForward){
  
  init(Form, Cmp, evt);
  init(IsForward);
  
  return this;
 }
 
 public int doAction() {
  int ret=CNav.Ret_Unconsumed;
  
  if(PNav.transferFocus(Form, Cmp, IsForward)){ret=CNav.Ret_Consumed;}
  
  return ret;
 }
 
}