import java.io.File;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;

public class PMyShop {
 
 static OBarcodePatternizerEAN08 PattEAN08=new OBarcodePatternizerEAN08();
 static OBarcodePatternizerEAN13 PattEAN13=new OBarcodePatternizerEAN13();
 static OBarcodePatternizerCode128SetC PattCode128SetC=new OBarcodePatternizerCode128SetC();
 
 public static OParameterValueGroup getParameterValueOfApplicationInfo(ODatabaseVersion DatabaseVersion){
  OParameterValueGroup ret=new OParameterValueGroup();
  
  ret.addElement(new OParameterValue(CApp.ParamDbVersion, CCore.TypeInteger, null, DatabaseVersion.Version, false, true));
  ret.addElement(new OParameterValue(CApp.ParamDbSubVariant, CCore.TypeInteger, null, DatabaseVersion.SubVariant, false, true));
  ret.addElement(new OParameterValue(CApp.ParamShopName, CCore.TypeString, null, "Toko ???", false, false));
  ret.addElement(new OParameterValue(CApp.ParamShopAddress, CCore.TypeString, null, "Jl. ???, Makassar", false, false));
  ret.addElement(new OParameterValue(CApp.ParamShopContact, CCore.TypeString, null, "081-1234-1234", false, false));
  ret.addElement(new OParameterValue(CApp.ParamShopWorkingHour, CCore.TypeString, null, "Senin-Sabtu (08.00-17.00)", false, false));
  
  return ret;
 }

 public static OInfoItem getItemInfo(Statement Stm, long Id, boolean CompleteInfo){
  OInfoItem ret=null;
  ResultSet Rs;
  boolean IsError;
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(
     "select tb4.*, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
      "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
       "(select tb2.*, StockUnit.Name as 'StockUnitName' from "+
        "(select tb1.Id, Name, StockUnit, Stock, UpdateStockOnTransaction, MinimalStock, MaximalStock, IsOpname, IsReorder, OrderEachPackQty, OrderEachPackThreshold, OrderMinPack, "+
          "SellPrice, SellPriceComment, SellUpdate, BuyPriceEstimation, BuyPriceComment, BuyUpdate, "+
          "HasExpireDate, IsActive, Comment, ExpireCheckPeriod, ExpireThreshold, OpnameStock, OpnameExpire, OrderQuantity from "+
         "("+PMyShop.getQueryOfFindItemIds(String.valueOf(Id), false, "Item.Id", null, false, null, true)+") as tb1 "+
        "left join Item on tb1.Id=Item.Id) as tb2 "+
       "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
      "left join ItemXPicture on tb3.Id=ItemXPicture.Item group by tb3.Id) as tb4 "+
     "left join ItemXCategory on tb4.Id=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.Id"
    );
    
    if(!Rs.next()){IsError=true; break;}
    
    ret=new OInfoItem();
    ret.PrimaryId=Rs.getLong(1);
    ret.Name=Rs.getString(2);
    ret.StockUnit=Rs.getInt(3); if(Rs.wasNull()==true){ret.StockUnit=-1;}
    ret.Stock=Rs.getDouble(4);
    ret.UpdateStock=Rs.getBoolean(5);
    ret.MinStock=Rs.getDouble(6);
    ret.MaxStock=Rs.getDouble(7);
    ret.IsOpname=Rs.getBoolean(8);
    ret.IsReorder=Rs.getBoolean(9);
    ret.OrderEachPackQty=Rs.getDouble(10);
    ret.OrderEachPackThreshold=Rs.getDouble(11);
    ret.OrderMinPack=Rs.getDouble(12);
    ret.SellPrice=Rs.getDouble(13);
    ret.SellPriceComment=Rs.getString(14);
    ret.SellUpdate=Rs.getDate(15);
    ret.BuyPriceEstimation=Rs.getDouble(16);
    ret.BuyPriceComment=Rs.getString(17);
    ret.BuyUpdate=Rs.getDate(18);
    ret.HasExpireDate=Rs.getBoolean(19);
    ret.IsActive=Rs.getBoolean(20);
    ret.Comment=Rs.getString(21);
    ret.ExpireCheckPeriod=Rs.getInt(22); if(Rs.wasNull()){ret.ExpireCheckPeriod=-1;}
    ret.ExpireThreshold=Rs.getInt(23); if(Rs.wasNull()){ret.ExpireThreshold=-1;}
    ret.OpnameStock=Rs.getDouble(24); if(Rs.wasNull()){ret.OpnameStock=null;}
    ret.OpnameExpire=Rs.getDate(25); if(Rs.wasNull()){ret.OpnameExpire=null;}
    ret.OrderQuantity=Rs.getDouble(26); if(Rs.wasNull()){ret.OrderQuantity=-1;}
    if(ret.StockUnit!=-1){ret.StockUnitName=Rs.getString(27);}
    ret.PictureFile=Rs.getString(28);
    ret.CategoryId=Rs.getInt(29); if(Rs.wasNull()){ret.CategoryId=-1;}
    if(ret.CategoryId!=-1){ret.CategoryName=Rs.getString(30);}
    
    if(!CompleteInfo){break;}
    
    ret.SecondaryIds=getItemSecondaryIds(Stm, Id); if(ret.SecondaryIds==null){IsError=true; break;}
    ret.Variants=getItemVariants(Stm, Id); if(ret.Variants==null){IsError=true; break;}
   }while(false);
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
  
  return ret;
 }
 public static String getItemPictureFile(Statement Stm, long Id){
  String ret=null;
  ResultSet Rs;
  try{
   Rs=Stm.executeQuery(
    "select Min(FileName) from "+
     "("+PMyShop.getQueryOfFindItemIds(String.valueOf(Id), false, "Item.Id", null, false, null, true)+") as item_id "+
    "left join ItemXPicture on item_id.Id=ItemXPicture.Item group by item_id.Id;");
   if(Rs.next()){ret=Rs.getString(1);}
  }
  catch(Exception E){ret=null;}
  return ret;
 }
 public static Vector<Long> getItemSecondaryIds(Statement Stm, long Id){
  Vector<Long> ret=new Vector();
  ResultSet Rs;
  boolean loop=true;
  boolean IsError;
  
  IsError=false;
  try{
   Rs=Stm.executeQuery("select SecondaryId from ItemXSecondaryId where Item="+Id);
   
   do{
    if(!Rs.next()){break;}
    ret.addElement(Rs.getLong(1));
   }while(loop);
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
  
  return ret;
 }
 public static Vector<String> getItemVariants(Statement Stm, long Id){
  Vector<String> ret=new Vector();
  ResultSet Rs;
  boolean loop=true;
  boolean IsError;
  
  IsError=false;
  try{
   Rs=Stm.executeQuery("select Variant from ItemXVariant where Item="+Id);
   
   do{
    if(!Rs.next()){break;}
    ret.addElement(Rs.getString(1));
   }while(loop);
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
  
  return ret;
 }
 
 public static OInfoRevStock getRevStockInfo(Statement Stm, long Id){
  OInfoRevStock ret=null;
  ResultSet Rs;
  try{
   Rs=Stm.executeQuery(
    "select tb4.*, ItemXCategory.CategoryOfItem as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb3.Id, RevisiDate, ReasonOfRevisi, ReasonOfRevisiName, Item, ItemName, StockOld, StockNew, Different, StockUnit, StockUnit.Name as 'StockUnitName', UpdateStockOnTransaction from "+
      "(select tb2.*, Item.Name as 'ItemName', Item.StockUnit, Item.UpdateStockOnTransaction from "+
       "(select tb1.*, ReasonOfRevisi.Name as 'ReasonOfRevisiName' from "+
        "(select RevisiStock.*, (StockNew-StockOld) as 'Different' from RevisiStock where Id="+Id+") as tb1 "+
       "left join ReasonOfRevisi on tb1.ReasonOfRevisi=ReasonOfRevisi.Id) as tb2 "+
      "left join Item on tb2.Item=Item.Id) as tb3 "+
     "left join StockUnit on tb3.StockUnit=StockUnit.Id) as tb4 "+
    "left join ItemXCategory on tb4.Item=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.Id"
   );
   if(Rs.next()){
    ret=new OInfoRevStock();
    ret.Id=Rs.getLong(1);
    ret.RevDate=Rs.getDate(2);
    ret.ReasonOfRevisiId=Rs.getInt(3); if(Rs.wasNull()){ret.ReasonOfRevisiId=-1;}
    ret.ReasonOfRevisiName=Rs.getString(4); if(Rs.wasNull()){ret.ReasonOfRevisiName=null;}
    ret.ItemId=Rs.getLong(5);
    ret.ItemName=Rs.getString(6);
    ret.StockOld=Rs.getDouble(7);
    ret.StockNew=Rs.getDouble(8);
    ret.StockDiff=Rs.getDouble(9);
    ret.StockUnitId=Rs.getInt(10); if(Rs.wasNull()){ret.StockUnitId=-1;}
    ret.StockUnitName=Rs.getString(11); if(Rs.wasNull()){ret.StockUnitName=null;}
    ret.UpdateStock=Rs.getBoolean(12);
    ret.CategoryId=Rs.getInt(13); if(Rs.wasNull()){ret.CategoryId=-1;}
    ret.CategoryName=Rs.getString(14); if(Rs.wasNull()){ret.CategoryName=null;}
   }
  }
  catch(Exception E){ret=null;}
  return ret;
 }
 public static OInfoSubject getSubjectInfo(Statement Stm, long Id, boolean IsComplete){
  OInfoSubject ret=new OInfoSubject();
  ResultSet Rs;
  boolean IsError;
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(
     "select tb1.*, Min(SubjectXPicture.FileName) as 'PictureFile' from "+
      "(select Id, Name, Birthday, Comment from Subject where Id="+String.valueOf(Id)+") as tb1 "+
     "left join SubjectXPicture on tb1.Id=SubjectXPicture.Subject group by tb1.Id;"
    );
    if(!Rs.next()){IsError=true; break;}
    ret.Name=Rs.getString(2);
    ret.Birthday=Rs.getDate(3);
    ret.Comment=Rs.getString(4);
    ret.PictureFile=Rs.getString(5);
    
    if(!IsComplete){break;}
    
    ret.ListAddress=getSubjectAddresses(Stm, Id); if(ret.ListAddress==null){IsError=true; break;} ret.ListAddressCount=ret.ListAddress.size();
    ret.ListContact=getSubjectContacts(Stm, Id); if(ret.ListContact==null){IsError=true; break;} ret.ListContactCount=ret.ListContact.size();
   }while(false);    
  }
  catch(Exception E){IsError=true;}
  if(IsError){ret=null;}
   
  return ret;
 }
 public static OInfoSubject getSubjectInfo(Statement Stm, long Id){
  return getSubjectInfo(Stm, Id, false);
 }
 public static OInfoTrans getTransInfo(Statement Stm, boolean IsPreTrans, long TransId){
  OInfoTrans ret=new OInfoTrans();
  ResultSet Rs;
  boolean IsError;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  
  IsError=false;
  try{
   do{
    // get Trans Detail

    Rs=Stm.executeQuery(
     "select tb2.*, Cash.Name as 'CashInName', Subject.Name as 'SalesmanName' from "+
      "(select tb1.*, TransType.Name as 'TransTypeName', Cash.Name as 'CashOutName', Subject.Name as 'SubjectName' from "+
       "(select TransDate, TransType, Cash, CashIn, Subject, Salesman, CreditDays, RepaymentPeriodStart, RepaymentPeriodEnd, IsImportant, Comment, "+
        "InfoIdExternal, CashOutComment, CashInComment from "+Tbl+
       " where Id="+TransId+") as tb1 "+
      "left join TransType on tb1.TransType=TransType.Id left join Cash on tb1.Cash=Cash.Id left join Subject on tb1.Subject=Subject.Id) as tb2 "+
     "left join Cash on tb2.CashIn=Cash.Id left join Subject on tb2.Salesman=Subject.Id;"
    );
    if(!Rs.next()){IsError=true; break;}
    ret.TransId=TransId;
    ret.Dt=Rs.getDate(1);
    ret.TypeId=Rs.getInt(2); if(Rs.wasNull()){ret.TypeId=-1;}
    ret.CashOutId=Rs.getInt(3); if(Rs.wasNull()){ret.CashOutId=-1;}
    ret.CashInId=Rs.getInt(4); if(Rs.wasNull()){ret.CashInId=-1;}
    ret.SubjectId=Rs.getLong(5); if(Rs.wasNull()){ret.SubjectId=-1;}
    ret.SalesmanId=Rs.getLong(6); if(Rs.wasNull()){ret.SalesmanId=-1;}
    ret.CreditDays=Rs.getInt(7); if(Rs.wasNull()){ret.CreditDays=-1;}
    ret.RepaymentPeriodStart=Rs.getDate(8);
    ret.RepaymentPeriodEnd=Rs.getDate(9);
    ret.Important=Rs.getBoolean(10);
    ret.Comment=Rs.getString(11);
    ret.InfoIdExternal=Rs.getString(12);
    ret.CashOutComment=Rs.getString(13);
    ret.CashInComment=Rs.getString(14);
    if(ret.TypeId!=-1){ret.TypeName=Rs.getString(15);}
    if(ret.CashOutId!=-1){ret.CashOutName=Rs.getString(16);}
    if(ret.SubjectId!=-1){ret.SubjectName=Rs.getString(17);}
    if(ret.CashInId!=-1){ret.CashInName=Rs.getString(18);}
    if(ret.SalesmanId!=-1){ret.SalesmanName=Rs.getString(19);}
   }while(false);
  }
  catch(Exception E){IsError=true;}
  if(IsError){ret=null;}
  
  return ret;
 }
 public static OInfoTransPending getTransPendingInfo(Statement Stm, boolean IsPreTrans, long TransPendingId){
  OInfoTransPending ret=new OInfoTransPending();
  ResultSet Rs;
  boolean IsError;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  
  IsError=false;
  try{
   do{
    // get Trans Detail

    Rs=Stm.executeQuery(
     "select tb2.*, Cash.Name as 'CashInName', Subject.Name as 'SalesmanName' from "+
      "(select tb1.*, TransType.Name as 'TransTypeName', Cash.Name as 'CashOutName', Subject.Name as 'SubjectName' from "+
       "(select "+Tbl+"Id, TransDate, TransType, CashOut, CashIn, Subject, Salesman, CreditDays, RepaymentPeriodStart, RepaymentPeriodEnd, IsImportant, Comment, "+
        "InfoIdExternal, CashOutComment, CashInComment from "+Tbl+"Pend where Id="+TransPendingId+") as tb1 "+
      "left join TransType on tb1.TransType=TransType.Id left join Cash on tb1.CashOut=Cash.Id left join Subject on tb1.Subject=Subject.Id) as tb2 "+
     "left join Cash on tb2.CashIn=Cash.Id left join Subject on tb2.Salesman=Subject.Id;"
    );
    if(!Rs.next()){IsError=true; break;}
    ret.PendingId=TransPendingId;
    ret.TransId=Rs.getLong(1);
    ret.Dt=Rs.getDate(2);
    ret.TypeId=Rs.getInt(3); if(Rs.wasNull()){ret.TypeId=-1;}
    ret.CashOutId=Rs.getInt(4); if(Rs.wasNull()){ret.CashOutId=-1;}
    ret.CashInId=Rs.getInt(5); if(Rs.wasNull()){ret.CashInId=-1;}
    ret.SubjectId=Rs.getLong(6); if(Rs.wasNull()){ret.SubjectId=-1;}
    ret.SalesmanId=Rs.getLong(7); if(Rs.wasNull()){ret.SalesmanId=-1;}
    ret.CreditDays=Rs.getInt(8); if(Rs.wasNull()){ret.CreditDays=-1;}
    ret.RepaymentPeriodStart=Rs.getDate(9);
    ret.RepaymentPeriodEnd=Rs.getDate(10);
    ret.Important=Rs.getBoolean(11);
    ret.Comment=Rs.getString(12);
    ret.InfoIdExternal=Rs.getString(13);
    ret.CashOutComment=Rs.getString(14);
    ret.CashInComment=Rs.getString(15);
    if(ret.TypeId!=-1){ret.TypeName=Rs.getString(16);}
    if(ret.CashOutId!=-1){ret.CashOutName=Rs.getString(17);}
    if(ret.SubjectId!=-1){ret.SubjectName=Rs.getString(18);}
    if(ret.CashInId!=-1){ret.CashInName=Rs.getString(19);}
    if(ret.SalesmanId!=-1){ret.SalesmanName=Rs.getString(20);}
   }while(false);
  }
  catch(Exception E){IsError=true;}
  if(IsError){ret=null;}
  
  return ret;
 }
 public static OInfoCustomPaperLabel getCustomPaperLabelInfo(Statement Stm, int Id){
  OInfoCustomPaperLabel ret=null;
  OInfoCustomPaperLabel info=new OInfoCustomPaperLabel();
  ResultSet rs;
  
  do{
   try{
    rs=Stm.executeQuery(
     "select Id, Name, IsRollPaper, DrawCutLine, PaperWidth, PaperHeight, MarginLeft, MarginTop, "+
     "LabelWidth, LabelHeight, LabelGapHorizontal, LabelGapVerticalA, LabelGapVerticalB "+
     "from CustomPaperLabel where Id="+Id);
    if(!rs.next()){break;}
    fillInfoCustomPaperLabel(rs, info);
   }
   catch(Exception E){break;}
   ret=info;
  }while(false);
  
  return ret;
 }
 public static Vector<OPaper> getCustomPaperLabel(Statement Stm, boolean AddPaperSizeTolerance, OPaperMargin MarginSt, OPaperMargin MarginTh){
  Vector<OPaper> ret=null;
  Vector<OPaper> rettemp=new Vector();
  ResultSet rs;
  OInfoCustomPaperLabel info=new OInfoCustomPaperLabel();
  
  do{
   try{
    rs=Stm.executeQuery(
     "select Id, Name, IsRollPaper, DrawCutLine, PaperWidth, PaperHeight, MarginLeft, MarginTop, "+
     "LabelWidth, LabelHeight, LabelGapHorizontal, LabelGapVerticalA, LabelGapVerticalB "+
     "from CustomPaperLabel order by Name asc;");
    if(rs.next()){
     do{
      fillInfoCustomPaperLabel(rs, info);
      rettemp.addElement(info.getPaperLabel(AddPaperSizeTolerance, MarginSt, MarginTh));
     }while(rs.next());
    }
   }
   catch(Exception E){break;}
   ret=rettemp;
  }while(false);
  
  return ret;
 }
 private static void fillInfoCustomPaperLabel(ResultSet rs, OInfoCustomPaperLabel info) throws Exception{
  info.Id=rs.getInt(1);
  info.PaperName=rs.getString(2);
  info.IsRollPaper=rs.getBoolean(3);
  info.DrawCutLine=rs.getBoolean(4);
  info.PaperWidth=OUnit.mm_to_pixel(rs.getDouble(5)); info.PaperHeight=OUnit.mm_to_pixel(rs.getDouble(6));
  info.MarginLeft=OUnit.mm_to_pixel(rs.getDouble(7)); info.MarginTop=OUnit.mm_to_pixel(rs.getDouble(8));
  info.LabelWidth=OUnit.mm_to_pixel(rs.getDouble(9)); info.LabelHeight=OUnit.mm_to_pixel(rs.getDouble(10));
  info.LabelGapHorizontal=OUnit.mm_to_pixel(rs.getDouble(11));
  info.LabelGapVerticalA=OUnit.mm_to_pixel(rs.getDouble(12)); info.LabelGapVerticalB=OUnit.mm_to_pixel(rs.getDouble(13));
 }
 public static boolean isStockUpdate(Statement Stm, long ItemId) throws Exception{
  boolean ret=true;
  ResultSet Rs=Stm.executeQuery("select UpdateStockOnTransaction from Item where Id="+ItemId+";");
  if(Rs.next()){
   ret=Rs.getBoolean(1);
  }
  return ret;
 }
 
 public static Vector<Object[]> getSubjectAddresses(Statement Stm, long SubjectId, int[] Enumerations){
  // returns : null = error, Vector(Integer Enumeration, String City, String Address) = success
  Vector<Object[]> ret=null;
  Vector<Object[]> rettemp=new Vector();
  int result;
  String ConEnumerations;
  
  ConEnumerations="";
  if(Enumerations!=null){
   if(Enumerations.length!=0){
    ConEnumerations=" and Enumeration in ("+PText.toString(Enumerations, 0, Enumerations.length, ",")+")";
   }
  }
  
  result=PDatabase.queryToRows(Stm,
   "select Enumeration, City, City.Name as 'CityName', Address, Comment from "+
    "(select * from SubjectXAddress where Subject="+SubjectId+ConEnumerations+") as tb1 "+
   "left join City on tb1.City=City.Id order by CityName asc, Address asc;",
   rettemp, PCore.primArr(CCore.TypeInteger, CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString));
  if(result!=-1){ret=rettemp;}
  
  return ret;
 }
 public static Vector<Object[]> getSubjectAddresses(Statement Stm, long SubjectId){
  return getSubjectAddresses(Stm, SubjectId, null);
 }
 public static Vector<Object[]> getSubjectContacts(Statement Stm, long SubjectId, int[] Enumerations){
  // returns : null = error, Vector(Integer Enumeration, String ContactType, String Contact) = success
  Vector<Object[]> ret=null;
  Vector<Object[]> rettemp=new Vector();
  int result;
  String ConEnumerations;
  
  ConEnumerations="";
  if(Enumerations!=null){
   if(Enumerations.length!=0){
    ConEnumerations=" and Enumeration in ("+PText.toString(Enumerations, 0, Enumerations.length, ",")+")";
   }
  }
  
  result=PDatabase.queryToRows(Stm,
   "select Enumeration, ContactType, ContactType.Name as 'ContactTypeName', Contact, Comment from "+
    "(select * from SubjectXContact where Subject="+SubjectId+ConEnumerations+") as tb1 "+
   "left join ContactType on tb1.ContactType=ContactType.Id order by ContactTypeName asc, Contact asc;",
   rettemp, PCore.primArr(CCore.TypeInteger, CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString));
  if(result!=-1){ret=rettemp;}
  
  return ret;
 }
 public static Vector<Object[]> getSubjectContacts(Statement Stm, long SubjectId){
  return getSubjectContacts(Stm, SubjectId, null);
 }
 public static Vector<Object[]> getSubjectBankAccounts(Statement Stm, long SubjectId, int[] Enumerations){
  // returns : null = error, Vector(Integer Enumeration, String BankPlatform, String BankAccount) = success
  Vector<Object[]> ret=null;
  Vector<Object[]> rettemp=new Vector();
  int result;
  String ConEnumerations;
  
  ConEnumerations="";
  if(Enumerations!=null){
   if(Enumerations.length!=0){
    ConEnumerations=" and Enumeration in ("+PText.toString(Enumerations, 0, Enumerations.length, ",")+")";
   }
  }
  
  result=PDatabase.queryToRows(Stm,
   "select Enumeration, BankPlatform, BankPlatform.Name as 'BankPlatformName', BankAccount, Comment from "+
    "(select * from SubjectXBankAccount where Subject="+SubjectId+ConEnumerations+") as tb1 "+
   "left join BankPlatform on tb1.BankPlatform=BankPlatform.Id order by BankPlatformName asc, BankAccount asc;",
   rettemp, PCore.primArr(CCore.TypeInteger, CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString));
  if(result!=-1){ret=rettemp;}
  
  return ret;
 }
 public static Vector<Object[]> getSubjectBankAccounts(Statement Stm, long SubjectId){
  return getSubjectBankAccounts(Stm, SubjectId, null);
 }
 
 public static String[] getConvertItems_ColumnsName(){
  return PCore.refArr("Id Barang", "Nama Barang", "Qty", "Satuan Unit", "Diperbarui", "File Gambar", "Kategori");
 }
 public static int[] getConvertItems_ColumnsType(){
  return PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString, CCore.TypeString);
 }
 public static int[] getConvertItems_ColumnsShowOption(){
  return PCore.changeValue(PCore.newIntegerArray(getConvertItems_ColumnsType().length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
 }
 public static boolean[] getConvertItems_ColumnsEditable(boolean EditableQty){
  int[] Editable=PCore.primArr(PCore.subtBool_Int(EditableQty, 2, -1));
  
  return PCore.changeValue(PCore.newBooleanArray(getConvertItems_ColumnsType().length, false), Editable, PCore.newBooleanArray(Editable.length, true));
 }
 public static int[] getConvertItems_ColumnsVisible(boolean IsItemCategorized){
  int[] ret;
  int insertpos=0, insertvalue=0;
  
  ret=PCore.primArr(1, 2, 3, 4);
  if(!IsItemCategorized){
   insertpos=3; insertvalue=0;
  }
  else{
   insertpos=0; insertvalue=6;
  }
  ret=PCore.insert(ret, insertpos, insertvalue);
  
  return ret;
 }
 public static int[] getConvertItems_ColumnsWidth(boolean IsItemCategorized){
  int[] ret;
  int insertpos=0, insertvalue=0;
  
  ret=PCore.primArr(CGUI.ColTextLrg, CGUI.ColNumSep06, CGUI.ColTextTiny, CGUI.ColCheck);
  if(!IsItemCategorized){
   insertpos=3; insertvalue=CGUI.ColNum13;
  }
  else{
   insertpos=0; insertvalue=CGUI.ColTextSml;
  }
  ret=PCore.insert(ret, insertpos, insertvalue);
  
  return ret;
 }
 public static String getConvertItems_Query(boolean IsConvertRule, boolean IsItemOut, long Id, boolean IsItemCategorized, long[] Items){
  String ColumnId=null;
  String TableListItems=null;
  String ConItems;
  StringBuilder OrderBy;
  String Order_ItemCategory, Order_ItemName;
  
  do{
   if(IsConvertRule && IsItemOut){ColumnId="RuleOfConv"; TableListItems=ColumnId+"XSideA"; break;}
   if(IsConvertRule && !IsItemOut){ColumnId="RuleOfConv"; TableListItems=ColumnId+"XSideB"; break;}
   if(!IsConvertRule && IsItemOut){ColumnId="Conv"; TableListItems=ColumnId+"XItemOut"; break;}
   if(!IsConvertRule && !IsItemOut){ColumnId="Conv"; TableListItems=ColumnId+"XItemIn"; break;}
  }while(false);
  
  if(PCore.isArrayEmpty(Items, true)){ConItems="";}
  else{ConItems=" and Item in ("+PText.toString(Items, 0, Items.length, ",")+")";}
  
  OrderBy=new StringBuilder(" order by");
  
  Order_ItemName=" ItemName asc"; Order_ItemCategory=" ItemCategoryName asc";
  
  if(!IsItemCategorized){OrderBy.append(Order_ItemName);}
  else{OrderBy.append(Order_ItemCategory+","+Order_ItemName);}
  
  return
   "select ItemId, ItemName, Qty, StockUnitName, IsUpdate, PictureFile, Min(CategoryOfItem.Name) as 'ItemCategoryName' from "+
    "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
     "(select tb2.*, StockUnit.Name as 'StockUnitName' from "+
      "(select tb1.*, Name as 'ItemName', StockUnit as 'StockUnitId', UpdateStockOnTransaction as 'IsUpdate' from "+
       "(select Item as 'ItemId', Stock as 'Qty' from "+TableListItems+" where "+ColumnId+"="+Id+ConItems+") as tb1 "+
      "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnitId=StockUnit.Id) as tb3 "+
    "left join ItemXPicture on tb3.ItemId=ItemXPicture.Item group by tb3.ItemId) as tb4 "+
   "left join ItemXCategory on tb4.ItemId=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.ItemId"+
   OrderBy.toString();
 }
 public static Vector<Object[]> getConvertItems(Statement Stm, boolean IsConvertRule, boolean IsItemOut, long Id, boolean IsItemCategorized, long[] Items){
  Vector<Object[]> ret=new Vector();
  int result;
  
  result=PDatabase.queryToRows(Stm, getConvertItems_Query(IsConvertRule, IsItemOut, Id, IsItemCategorized, Items), ret, getConvertItems_ColumnsType());
  if(result==-1){ret=null;}
  
  return ret;
 }
 public static Vector<Object[]> getConvertItems(Statement Stm, boolean IsConvertRule, boolean IsItemOut, long Id, boolean IsItemCategorized){
  return getConvertItems(Stm, IsConvertRule, IsItemOut, Id, IsItemCategorized, null);
 }
 public static OInfoConvertRule getConvertRuleInfo(Statement Stm, long Id, boolean IsComplete, boolean IsItemCategorized){
  OInfoConvertRule ret=new OInfoConvertRule();
  ResultSet Rs;
  boolean IsError;
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(
     "select Id, Name, IsActive, LastUpdate from RuleOfConv where Id="+String.valueOf(Id)
    );
    if(!Rs.next()){IsError=true; break;}
    ret.Id=Id;
    ret.Name=Rs.getString(2);
    ret.IsActive=Rs.getBoolean(3);
    ret.LastUpdate=Rs.getDate(4);
    
    if(!IsComplete){break;}
    
    ret.ListItemA=getConvertItems(Stm, true, true, Id, IsItemCategorized); if(ret.ListItemA==null){IsError=true; break;}
    ret.ListItemB=getConvertItems(Stm, true, false, Id, IsItemCategorized); if(ret.ListItemB==null){IsError=true; break;}
   }while(false);    
  }
  catch(Exception E){IsError=true;}
  if(IsError){ret=null;}
   
  return ret;
 }
 public static OInfoConvertRule getConvertRuleInfo(Statement Stm, long Id){
  return getConvertRuleInfo(Stm, Id, false, false);
 }
 public static OInfoConverting getConvertingInfo(Statement Stm, long Id, boolean IsComplete, boolean IsItemCategorized){
  OInfoConverting ret=new OInfoConverting();
  ResultSet Rs;
  boolean IsError;
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(
     "select tb2.Id, ConvDate, ReasonOfConv, ReasonOfConvName, "+
     "RuleOfConv, RuleOfConv.Name as 'RuleOfConvName', IsActive, LastUpdate, "+
     "RuleOfConvDirection, RuleOfConvCount from "+
      "(select tb1.*, ReasonOfConv.Name as 'ReasonOfConvName' from "+
       "(select Conv.* from Conv where Id="+String.valueOf(Id)+") as tb1 "+
      "left join ReasonOfConv on tb1.ReasonOfConv=ReasonOfConv.Id) as tb2 "+
     "inner join RuleOfConv on tb2.RuleOfConv=RuleOfConv.Id"
    );
    if(!Rs.next()){IsError=true; break;}
    ret.Id=Id;
    ret.ConvDate=Rs.getDate(2);
    ret.ReasonOfConvId=Rs.getInt(3); if(Rs.wasNull()){ret.ReasonOfConvId=-1;}
    ret.ReasonOfConvName=Rs.getString(4);
    
    ret.ConvRule=new OInfoConvertRule();
    ret.ConvRule.Id=Rs.getLong(5);
    ret.ConvRule.Name=Rs.getString(6);
    ret.ConvRule.IsActive=Rs.getBoolean(7);
    ret.ConvRule.LastUpdate=Rs.getDate(8);
    
    ret.ConvRuleDirection=Rs.getBoolean(9); // true = A to B , false = B to A
    ret.ConvRuleCount=Rs.getDouble(10);
    
    if(!IsComplete){break;}
    
    ret.ListItemOut=getConvertItems(Stm, false, true, Id, IsItemCategorized); if(ret.ListItemOut==null){IsError=true; break;}
    ret.ListItemIn=getConvertItems(Stm, false, false, Id, IsItemCategorized); if(ret.ListItemIn==null){IsError=true; break;}
    ret.ConvRule.generateListItemsFromConverting(ret.ConvRuleDirection, ret.ConvRuleCount, ret.ListItemOut, ret.ListItemIn);
   }while(false);    
  }
  catch(Exception E){IsError=true;}
  if(IsError){ret=null;}
   
  return ret;
 }
 public static OInfoConverting getConvertingInfo(Statement Stm, long Id){
  return getConvertingInfo(Stm, Id, false, false);
 }
 
 // Item Supplier
 public static String[] getItemSupp_ColumnsName(boolean ByItem){
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  return PCore.refArr(
   PText.getString(ByItem, "Id Suplier", "Id Barang"), PText.getString(ByItem, "Suplier", "Nama Barang"),
   "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori");
 }
 public static int[] getItemSupp_ColumnsType(){
  return PCore.primArr(
   CCore.TypeLong, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeBoolean, CCore.TypeString, CCore.TypeString);
 }
 public static int[] getItemSupp_ColumnsShowOption(){
  return PCore.changeValue(PCore.newIntegerArray(getItemSupp_ColumnsType().length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
 }
 public static boolean[] getItemSupp_ColumnsEditable(
  boolean EditableBuyPrc, boolean EditableBuyComment, boolean EditableBuyUpdate){
  int[] Editable=PCore.primArr(
   PCore.subtBool_Int(EditableBuyPrc, 2, -1),
   PCore.subtBool_Int(EditableBuyComment, 3, -1),
   PCore.subtBool_Int(EditableBuyUpdate, 4, -1));
  
  return PCore.changeValue(PCore.newBooleanArray(getItemSupp_ColumnsType().length, false), Editable, PCore.newBooleanArray(Editable.length, true));
 }
 public static int[] getItemSupp_ColumnsVisible(boolean ByItem, boolean IsCategorized,
  boolean ViewBuyPrc, boolean ViewBuyComment, boolean ViewBuyUpdate){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  ColsComp=new Vector();
  PCore.concatVect(ColsComp, PCore.primArr(1));
  if(!ByItem){
   if(!IsCategorized){
    ColsComp.insertElementAt(0, 1);
   }
   else{
    ColsComp.insertElementAt(7, 0);
   }
  }
  
  ColsOther=new Vector();
  if(ViewBuyPrc){PCore.concatVect(ColsOther, PCore.primArr(2));} // BuyPrice
  if(ViewBuyComment){PCore.concatVect(ColsOther, PCore.primArr(3));} // BuyComment
  if(ViewBuyUpdate){PCore.concatVect(ColsOther, PCore.primArr(4));} // BuyUpdate
  PCore.concatVect(ColsOther, PCore.primArr(5)); // IsActive
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 public static int[] getItemSupp_ColumnsWidth(boolean ByItem, boolean IsCategorized,
  boolean ViewBuyPrc, boolean ViewBuyComment, boolean ViewBuyUpdate){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  ColsComp=new Vector();
  PCore.concatVect(ColsComp, PCore.primArr(PCore.subtBool_Int(ByItem, CGUI.ColTextSml, CGUI.ColTextMed)));
  if(!ByItem){
   if(!IsCategorized){
    ColsComp.insertElementAt(CGUI.ColNum13, 1);
   }
   else{
    ColsComp.insertElementAt(130, 0);
   }
  }
  
  ColsOther=new Vector();
  if(ViewBuyPrc){PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColNumSep09_a));} // BuyPrice
  if(ViewBuyComment){PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColTextSml-20));} // BuyComment
  if(ViewBuyUpdate){PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColDate));} // BuyUpdate
  PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColCheck)); // IsActive
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 static String getItemSupp_Query_Condition(boolean ByItem, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   long[] ByIndependent_CompanionIds){
  StringBuilder ret;
  boolean first;
  int[] coltype;
  Object[] ByStrict_AData;
  String ColMainId, ColCompId; // Comp = Companion
  
  ret=new StringBuilder(); first=true;

  ColMainId=PText.getString(ByItem, "Item", "Supplier");
  ColCompId=PText.getString(ByItem, "Supplier", "Item");
  
  if(!PCore.isArrayEmpty(MainIds, true)){
   if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
   ret.append(" "+ColMainId+" in("+PText.toString(MainIds, 0, MainIds.length, ",")+")");
  }
  
  if(ByStrict){
   if(!PCore.isVectorEmpty(ByStrict_Data, true)){
    if(!ByStrict_SpecificRow){
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ret.append(" "+PSql.genCheckKey(PCore.refArr(ColCompId), ByStrict_Data, getItemSupp_ColumnsType(), PCore.primArr(0)));
    }
    else{
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ByStrict_AData=ByStrict_Data.elementAt(ByStrict_Row); coltype=getItemSupp_ColumnsType();
     ret.append(" ("+PSql.genVarAndValue(ColCompId, ByStrict_AData[0], coltype[0], true)+")");
    }
   }
  }
  else{
   if(!PCore.isArrayEmpty(ByIndependent_CompanionIds, true)){
    if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
    ret.append(" "+PSql.genCheckList(ColCompId, ByIndependent_CompanionIds, true));
   }
  }
  
  return ret.toString();
 }
 public static String getItemSupp_Query(boolean ByItem, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   long[] ByIndependent_CompanionIds,
  boolean IsCategorized,
  boolean WithCompleteInfo){
  String ret=null;
  StringBuilder OrderBy;
  String ColMainId, TblMain, ColCompId, TblComp; // Comp = Companion
  String Order_Normal, Order_Category;
  String ColInfo;
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  ColMainId=PText.getString(ByItem, "Item", "Supplier");
  TblMain=PText.getString(ByItem, "Item", "Subject");
  ColCompId=PText.getString(ByItem, "Supplier", "Item");
  TblComp=PText.getString(ByItem, "Subject", "Item");
  
  OrderBy=new StringBuilder(" order by");
  Order_Normal=" "+ColCompId+"Name asc";
  Order_Category=" CategoryName asc";
  if(!IsCategorized){OrderBy.append(Order_Normal);}else{OrderBy.append(Order_Category+","+Order_Normal);}

  ColInfo=PText.getString(WithCompleteInfo, ", "+ColMainId+"Id, "+ColMainId+"Name", "");
  
  ret=
   "select "+ColCompId+"Id, "+ColCompId+"Name, BuyPrice, BuyPriceComment, UpdateDate, IsActive, PictureFile, CategoryName"+ColInfo+" from "+
    "(select tb4.*, Min(CategoryOf"+TblComp+".Name) as 'CategoryName' from "+
     "(select tb3.*, Min("+TblComp+"XPicture.FileName) as 'PictureFile' from "+
      "(select tb2.*, Name as '"+ColCompId+"Name' from "+
       "(select tb1.*, Name as '"+ColMainId+"Name' from "+
        "(select "+ColMainId+" as '"+ColMainId+"Id', "+ColCompId+" as '"+ColCompId+"Id', BuyPrice, BuyPriceComment, UpdateDate, IsActive from ItemXSupplier"+
        getItemSupp_Query_Condition(ByItem, MainIds, ByStrict, ByStrict_Data, ByStrict_SpecificRow, ByStrict_Row, ByIndependent_CompanionIds)+") as tb1 "+
       "inner join "+TblMain+" on tb1."+ColMainId+"Id="+TblMain+".Id) as tb2 "+
      "inner join "+TblComp+" on tb2."+ColCompId+"Id="+TblComp+".Id) as tb3 "+
     "left join "+TblComp+"XPicture on tb3."+ColCompId+"Id="+TblComp+"XPicture."+TblComp+" group by tb3."+ColCompId+"Id) as tb4 "+
    "left join "+TblComp+"XCategory on tb4."+ColCompId+"Id="+TblComp+"XCategory."+TblComp+" "+
   "left join CategoryOf"+TblComp+" on "+TblComp+"XCategory.CategoryOf"+TblComp+"=CategoryOf"+TblComp+".Id group by tb4."+ColCompId+"Id) as tb5"+
   OrderBy.toString();
  
  return ret;
 }
 public static Vector<Object[]> getItemSupp(Statement Stm, boolean ByItem, long MainId, long[] CompanionIds, boolean IsCategorized){
  Vector<Object[]> ret=new Vector();
  int result;
  
  result=PDatabase.queryToRows(Stm,
   getItemSupp_Query(ByItem, PCore.primArr(MainId), false, null, false, -1, CompanionIds, IsCategorized, false), ret, getItemSupp_ColumnsType());
  if(result==-1){ret=null;}
  
  return ret;
 }
 public static Vector<Object[]> getItemSupp(Statement Stm, boolean ByItem, long MainId, boolean IsCategorized){
  return getItemSupp(Stm, ByItem, MainId, null, IsCategorized);
 }
 
 public static OInfoItemSupplier getItemSupplierInfo(Statement Stm, boolean ByItem, long MainId, long CompId){
  OInfoItemSupplier ret=new OInfoItemSupplier();
  ResultSet Rs;
  boolean IsError;
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(getItemSupp_Query(ByItem, PCore.primArr(MainId), false, null, false, -1, PCore.primArr(CompId), false, false));
    if(!Rs.next()){IsError=true; break;}
    
    ret.BuyPrc=Rs.getDouble(3);
    ret.BuyComment=Rs.getString(4);
    ret.Update=Rs.getDate(5);
    ret.IsActive=Rs.getBoolean(6);
   }while(false);    
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
   
  return ret;
 }
 
 // Item Variant
 public static String[] getItemVart_ColumnsName(){
  return PCore.refArr(
   "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Keterangan", "File Gambar");
 }
 public static int[] getItemVart_ColumnsType(){
  return PCore.primArr(
   CCore.TypeString, CCore.TypeBoolean, CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeString, CCore.TypeString);
 }
 public static int[] getItemVart_ColumnsShowOption(){
  return PCore.changeValue(PCore.newIntegerArray(getItemVart_ColumnsType().length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
 }
 public static boolean[] getItemVart_ColumnsEditable(
  boolean EditableVariant, boolean EditableBuyPrice, boolean EditableBuyComment, boolean EditableBuyUpdate, boolean EditableComment){
  int[] Editable=PCore.primArr(
   PCore.subtBool_Int(EditableVariant, 0, -1),
   PCore.subtBool_Int(EditableBuyPrice, 2, -1),
   PCore.subtBool_Int(EditableBuyComment, 3, -1),
   PCore.subtBool_Int(EditableBuyUpdate, 4, -1),
   PCore.subtBool_Int(EditableComment, 5, -1));
  
  return PCore.changeValue(PCore.newBooleanArray(getItemVart_ColumnsType().length, false), Editable, PCore.newBooleanArray(Editable.length, true));
 }
 public static int[] getItemVart_ColumnsVisible(
  boolean ViewBuyPrice, boolean ViewBuyComment, boolean ViewBuyUpdate, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsName, ColsOther;
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  ColsName=new Vector();
  PCore.concatVect(ColsName, PCore.primArr(0)); // Variant
  if(ViewComment){PCore.concatVect(ColsName, PCore.primArr(5));} // Comment
  
  ColsOther=new Vector();
  if(ViewBuyPrice){PCore.concatVect(ColsOther, PCore.primArr(2));} // BuyPrice
  if(ViewBuyComment){PCore.concatVect(ColsOther, PCore.primArr(3));} // BuyComment
  if(ViewBuyUpdate){PCore.concatVect(ColsOther, PCore.primArr(4));} // BuyUpdate
  PCore.concatVect(ColsOther, PCore.primArr(1)); // IsActive
  
  PCore.concatVect(ret, false, ColsName, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 public static int[] getItemVart_ColumnsWidth(
  boolean ViewBuyPrice, boolean ViewBuyComment, boolean ViewBuyUpdate, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsName, ColsOther;
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  ColsName=new Vector();
  PCore.concatVect(ColsName, PCore.primArr(CGUI.ColTextSml-20)); // Variant
  if(ViewComment){PCore.concatVect(ColsName, PCore.primArr(CGUI.ColTextSml-20));} // Comment
  
  ColsOther=new Vector();
  if(ViewBuyPrice){PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColNumSep09_a));} // BuyPrice
  if(ViewBuyComment){PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColTextSml-20));} // BuyComment
  if(ViewBuyUpdate){PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColDate));} // BuyUpdate
  PCore.concatVect(ColsOther, PCore.primArr(CGUI.ColCheck)); // IsActive
  
  PCore.concatVect(ret, false, ColsName, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 static String getItemVart_Query_Condition(long[] Items,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   String[] ByIndependent_VariantIds){
  StringBuilder ret;
  boolean first;
  int[] coltype;
  Object[] ByStrict_AData;
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  ret=new StringBuilder(); first=true;
  
  if(!PCore.isArrayEmpty(Items, true)){
   if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
   ret.append(" Item in("+PText.toString(Items, 0, Items.length, ",")+")");
  }
  
  if(ByStrict){
   if(!PCore.isVectorEmpty(ByStrict_Data, true)){
    if(!ByStrict_SpecificRow){
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ret.append(" "+PSql.genCheckKey(PCore.refArr("Variant"), ByStrict_Data, getItemVart_ColumnsType(), PCore.primArr(0)));
    }
    else{
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ByStrict_AData=ByStrict_Data.elementAt(ByStrict_Row); coltype=getItemVart_ColumnsType();
     ret.append(" ("+PSql.genVarAndValue("Variant", ByStrict_AData[0], coltype[0], true)+")");
    }
   }
  }
  else{
   if(!PCore.isArrayEmpty(ByIndependent_VariantIds, true)){
    if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
    ret.append(" "+PSql.genCheckList("Variant", ByIndependent_VariantIds));
   }
  }
  
  return ret.toString();
 }
 public static String getItemVart_Query(long[] Items,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   String[] ByIndependent_VariantIds,
  boolean WithCompleteInfo){
  String ret=null;
  StringBuilder OrderBy;
  String Order_Normal;
  String ColInfo;
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  OrderBy=new StringBuilder(" order by");
  Order_Normal=" Variant asc";
  OrderBy.append(Order_Normal);

  ColInfo=PText.getString(WithCompleteInfo, ", ItemId, ItemName", "");
  
  ret=
   "select Variant, IsActive, BuyPrice, BuyPriceComment, BuyUpdate, Comment, PictureFile"+ColInfo+" from "+
    "(select tb1.*, Name as 'ItemName' from "+
     "(select Item as 'ItemId', Variant, IsActive, BuyPrice, BuyPriceComment, BuyUpdate, Comment, PictureFile from ItemXVariant"+
     getItemVart_Query_Condition(Items, ByStrict, ByStrict_Data, ByStrict_SpecificRow, ByStrict_Row, ByIndependent_VariantIds)+") as tb1 "+
    "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
   OrderBy.toString();
  
  return ret;
 }
 public static Vector<Object[]> getItemVart(Statement Stm, long Item, String[] VariantIds){
  Vector<Object[]> ret=new Vector();
  int result;
  
  result=PDatabase.queryToRows(Stm,
   getItemVart_Query(PCore.primArr(Item), false, null, false, -1, VariantIds, false), ret, getItemVart_ColumnsType());
  if(result==-1){ret=null;}
  
  return ret;
 }
 public static Vector<Object[]> getItemVart(Statement Stm, long Item){
  return getItemVart(Stm, Item, null);
 }
 
 public static OInfoItemVariant getItemVariantInfo(Statement Stm, long Item, String VariantId){
  OInfoItemVariant ret=new OInfoItemVariant();
  ResultSet Rs;
  boolean IsError;
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(getItemVart_Query(PCore.primArr(Item), false, null, false, -1, PCore.refArr(VariantId), false));
    if(!Rs.next()){IsError=true; break;}
    
    ret.Variant=Rs.getString(1);
    ret.IsActive=Rs.getBoolean(2);
    ret.BuyPrice=Rs.getDouble(3);
    ret.BuyComment=Rs.getString(4);
    ret.BuyUpdate=Rs.getDate(5);
    ret.Comment=Rs.getString(6);
    ret.PictureFile=Rs.getString(7);
   }while(false);    
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
   
  return ret;
 }
 
 // Subject Address
 public static String[] getSubjectAddr_ColumnsName(){
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  return PCore.refArr("Enumerasi", "Kota Id", "Kota", "Alamat", "Komentar");
 }
 public static int[] getSubjectAddr_ColumnsType(){
  return PCore.primArr(CCore.TypeInteger, CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString);
 }
 public static int[] getSubjectAddr_ColumnsShowOption(){
  return PCore.changeValue(PCore.newIntegerArray(getSubjectAddr_ColumnsType().length, OCustomTableModel.ShowOptionNormal), null, null);
 }
 public static boolean[] getSubjectAddr_ColumnsEditable(
  boolean EditableAddr, boolean EditableComment){
  int[] Editable=PCore.primArr(
   PCore.subtBool_Int(EditableAddr, 3, -1),
   PCore.subtBool_Int(EditableComment, 4, -1));
  
  return PCore.changeValue(PCore.newBooleanArray(getSubjectAddr_ColumnsType().length, false), Editable, PCore.newBooleanArray(Editable.length, true));
 }
 public static int[] getSubjectAddr_ColumnsVisible(
  boolean ViewCity, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  ColsComp=new Vector();
  
  ColsOther=new Vector();
  if(ViewCity){PCore.concatVect(ColsOther, PCore.primArr(2));} // City
  PCore.concatVect(ColsOther, PCore.primArr(3)); // Address
  if(ViewComment){PCore.concatVect(ColsOther, PCore.primArr(4));} // Comment
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 public static int[] getSubjectAddr_ColumnsWidth(
  boolean ViewCity, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  ColsComp=new Vector();
  
  ColsOther=new Vector();
  if(ViewCity){PCore.concatVect(ColsOther, PCore.primArr(130));} // City
  PCore.concatVect(ColsOther, PCore.primArr(330)); // Address
  if(ViewComment){PCore.concatVect(ColsOther, PCore.primArr(150));} // Comment
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 static String getSubjectAddr_Query_Condition(long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   int[] ByIndependent_CompanionIds){
  StringBuilder ret;
  boolean first;
  int[] coltype;
  Object[] ByStrict_AData;
  String ColMainId, ColCompId; // Comp = Companion
  
  ret=new StringBuilder(); first=true;

  ColMainId="Subject";
  ColCompId="Enumeration";
  
  if(!PCore.isArrayEmpty(MainIds, true)){
   if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
   ret.append(" "+ColMainId+" in("+PText.toString(MainIds, 0, MainIds.length, ",")+")");
  }
  
  if(ByStrict){
   if(!PCore.isVectorEmpty(ByStrict_Data, true)){
    if(!ByStrict_SpecificRow){
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ret.append(" "+PSql.genCheckKey(PCore.refArr(ColCompId), ByStrict_Data, getSubjectAddr_ColumnsType(), PCore.primArr(0)));
    }
    else{
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ByStrict_AData=ByStrict_Data.elementAt(ByStrict_Row); coltype=getSubjectAddr_ColumnsType();
     ret.append(" ("+PSql.genVarAndValue(ColCompId, ByStrict_AData[0], coltype[0], true)+")");
    }
   }
  }
  else{
   if(!PCore.isArrayEmpty(ByIndependent_CompanionIds, true)){
    if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
    ret.append(" "+PSql.genCheckList(ColCompId, ByIndependent_CompanionIds, true));
   }
  }
  
  return ret.toString();
 }
 public static String getSubjectAddr_Query(long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   int[] ByIndependent_CompanionIds,
  boolean WithCompleteInfo){
  String ret;
  StringBuilder OrderBy;
  String Order_Normal;
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  OrderBy=new StringBuilder(" order by");
  Order_Normal=" City.Name asc, Address asc";
  OrderBy.append(Order_Normal);
  
  ret=
   "select Enumeration, CityId, City.Name as 'CityName', Address, Comment from "+
    "(select Enumeration, Address, City as 'CityId', Comment from SubjectXAddress"+
    getSubjectAddr_Query_Condition(MainIds, ByStrict, ByStrict_Data, ByStrict_SpecificRow, ByStrict_Row, ByIndependent_CompanionIds)+") as tb1 "+
   "left join City on tb1.CityId=City.Id"+
   OrderBy.toString();
  
  return ret;
 }
 public static Vector<Object[]> getSubjectAddr(Statement Stm, long MainId, int[] CompanionIds){
  Vector<Object[]> ret=new Vector();
  int result;
  
  result=PDatabase.queryToRows(Stm,
   getSubjectAddr_Query(PCore.primArr(MainId), false, null, false, -1, CompanionIds, false), ret, getSubjectAddr_ColumnsType());
  if(result==-1){ret=null;}
  
  return ret;
 }
 public static Vector<Object[]> getSubjectAddr(Statement Stm, long MainId){
  return getSubjectAddr(Stm, MainId, null);
 }
 
 public static OInfoSubjectAddress getSubjectAddrInfo(Statement Stm, long MainId, int CompId){
  OInfoSubjectAddress ret=new OInfoSubjectAddress();
  ResultSet Rs;
  boolean IsError;
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(getSubjectAddr_Query(PCore.primArr(MainId), false, null, false, -1, PCore.primArr(CompId), false));
    if(!Rs.next()){IsError=true; break;}
    
    ret.Enumeration=Rs.getInt(1);
    ret.CityId=Rs.getInt(2); if(Rs.wasNull()){ret.CityId=-1;}
    ret.CityName=Rs.getString(3);
    ret.Address=Rs.getString(4);
    ret.Comment=Rs.getString(5);
   }while(false);
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
   
  return ret;
 }
 
 // Subject Contact
 public static String[] getSubjectCont_ColumnsName(){
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  return PCore.refArr("Enumerasi", "Tipe Kontak Id", "Tipe Kontak", "Kontak", "Komentar");
 }
 public static int[] getSubjectCont_ColumnsType(){
  return PCore.primArr(CCore.TypeInteger, CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString);
 }
 public static int[] getSubjectCont_ColumnsShowOption(){
  return PCore.changeValue(PCore.newIntegerArray(getSubjectCont_ColumnsType().length, OCustomTableModel.ShowOptionNormal), null, null);
 }
 public static boolean[] getSubjectCont_ColumnsEditable(
  boolean EditableCont, boolean EditableComment){
  int[] Editable=PCore.primArr(
   PCore.subtBool_Int(EditableCont, 3, -1),
   PCore.subtBool_Int(EditableComment, 4, -1));
  
  return PCore.changeValue(PCore.newBooleanArray(getSubjectCont_ColumnsType().length, false), Editable, PCore.newBooleanArray(Editable.length, true));
 }
 public static int[] getSubjectCont_ColumnsVisible(
  boolean ViewContactType, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  ColsComp=new Vector();
  
  ColsOther=new Vector();
  if(ViewContactType){PCore.concatVect(ColsOther, PCore.primArr(2));} // Contact Type
  PCore.concatVect(ColsOther, PCore.primArr(3)); // Contact
  if(ViewComment){PCore.concatVect(ColsOther, PCore.primArr(4));} // Comment
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 public static int[] getSubjectCont_ColumnsWidth(
  boolean ViewContactType, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  ColsComp=new Vector();
  
  ColsOther=new Vector();
  if(ViewContactType){PCore.concatVect(ColsOther, PCore.primArr(130));} // ContactType
  PCore.concatVect(ColsOther, PCore.primArr(330)); // Contact
  if(ViewComment){PCore.concatVect(ColsOther, PCore.primArr(150));} // Comment
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 static String getSubjectCont_Query_Condition(long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   int[] ByIndependent_CompanionIds){
  StringBuilder ret;
  boolean first;
  int[] coltype;
  Object[] ByStrict_AData;
  String ColMainId, ColCompId; // Comp = Companion
  
  ret=new StringBuilder(); first=true;

  ColMainId="Subject";
  ColCompId="Enumeration";
  
  if(!PCore.isArrayEmpty(MainIds, true)){
   if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
   ret.append(" "+ColMainId+" in("+PText.toString(MainIds, 0, MainIds.length, ",")+")");
  }
  
  if(ByStrict){
   if(!PCore.isVectorEmpty(ByStrict_Data, true)){
    if(!ByStrict_SpecificRow){
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ret.append(" "+PSql.genCheckKey(PCore.refArr(ColCompId), ByStrict_Data, getSubjectCont_ColumnsType(), PCore.primArr(0)));
    }
    else{
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ByStrict_AData=ByStrict_Data.elementAt(ByStrict_Row); coltype=getSubjectCont_ColumnsType();
     ret.append(" ("+PSql.genVarAndValue(ColCompId, ByStrict_AData[0], coltype[0], true)+")");
    }
   }
  }
  else{
   if(!PCore.isArrayEmpty(ByIndependent_CompanionIds, true)){
    if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
    ret.append(" "+PSql.genCheckList(ColCompId, ByIndependent_CompanionIds, true));
   }
  }
  
  return ret.toString();
 }
 public static String getSubjectCont_Query(long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   int[] ByIndependent_CompanionIds,
  boolean WithCompleteInfo){
  String ret;
  StringBuilder OrderBy;
  String Order_Normal;
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  OrderBy=new StringBuilder(" order by");
  Order_Normal=" ContactType.Name asc, Contact asc";
  OrderBy.append(Order_Normal);
  
  ret=
   "select Enumeration, ContactTypeId, ContactType.Name as 'ContactTypeName', Contact, Comment from "+
    "(select Enumeration, Contact, ContactType as 'ContactTypeId', Comment from SubjectXContact"+
    getSubjectCont_Query_Condition(MainIds, ByStrict, ByStrict_Data, ByStrict_SpecificRow, ByStrict_Row, ByIndependent_CompanionIds)+") as tb1 "+
   "left join ContactType on tb1.ContactTypeId=ContactType.Id"+
   OrderBy.toString();
  
  return ret;
 }
 public static Vector<Object[]> getSubjectCont(Statement Stm, long MainId, int[] CompanionIds){
  Vector<Object[]> ret=new Vector();
  int result;
  
  result=PDatabase.queryToRows(Stm,
   getSubjectCont_Query(PCore.primArr(MainId), false, null, false, -1, CompanionIds, false), ret, getSubjectCont_ColumnsType());
  if(result==-1){ret=null;}
  
  return ret;
 }
 public static Vector<Object[]> getSubjectCont(Statement Stm, long MainId){
  return getSubjectCont(Stm, MainId, null);
 }
 
 public static OInfoSubjectContact getSubjectContInfo(Statement Stm, long MainId, int CompId){
  OInfoSubjectContact ret=new OInfoSubjectContact();
  ResultSet Rs;
  boolean IsError;
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(getSubjectCont_Query(PCore.primArr(MainId), false, null, false, -1, PCore.primArr(CompId), false));
    if(!Rs.next()){IsError=true; break;}
    
    ret.Enumeration=Rs.getInt(1);
    ret.ContactTypeId=Rs.getInt(2); if(Rs.wasNull()){ret.ContactTypeId=-1;}
    ret.ContactTypeName=Rs.getString(3);
    ret.Cont=Rs.getString(4);
    ret.Comment=Rs.getString(5);
   }while(false);
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
   
  return ret;
 }
 
 // Subject Bank Account
 public static String[] getSubjectAcc_ColumnsName(){
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  return PCore.refArr("Enumerasi", "Bank Id", "Bank", "Rekening", "Komentar");
 }
 public static int[] getSubjectAcc_ColumnsType(){
  return PCore.primArr(CCore.TypeInteger, CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString);
 }
 public static int[] getSubjectAcc_ColumnsShowOption(){
  return PCore.changeValue(PCore.newIntegerArray(getSubjectAcc_ColumnsType().length, OCustomTableModel.ShowOptionNormal), null, null);
 }
 public static boolean[] getSubjectAcc_ColumnsEditable(
  boolean EditableAcc, boolean EditableComment){
  int[] Editable=PCore.primArr(
   PCore.subtBool_Int(EditableAcc, 3, -1),
   PCore.subtBool_Int(EditableComment, 4, -1));
  
  return PCore.changeValue(PCore.newBooleanArray(getSubjectAcc_ColumnsType().length, false), Editable, PCore.newBooleanArray(Editable.length, true));
 }
 public static int[] getSubjectAcc_ColumnsVisible(
  boolean ViewBankPlatform, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  ColsComp=new Vector();
  
  ColsOther=new Vector();
  if(ViewBankPlatform){PCore.concatVect(ColsOther, PCore.primArr(2));} // Bank Platform
  PCore.concatVect(ColsOther, PCore.primArr(3)); // Bank Account
  if(ViewComment){PCore.concatVect(ColsOther, PCore.primArr(4));} // Comment
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 public static int[] getSubjectAcc_ColumnsWidth(
  boolean ViewBankPlatform, boolean ViewComment){
  Vector<Integer> ret=new Vector();
  Vector<Integer> ColsComp, ColsOther;
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  ColsComp=new Vector();
  
  ColsOther=new Vector();
  if(ViewBankPlatform){PCore.concatVect(ColsOther, PCore.primArr(130));} // Bank Platform
  PCore.concatVect(ColsOther, PCore.primArr(330)); // Bank Account
  if(ViewComment){PCore.concatVect(ColsOther, PCore.primArr(150));} // Comment
  
  PCore.concatVect(ret, false, ColsComp, ColsOther);
  
  return PCore.primArr_VectInt(ret);
 }
 static String getSubjectAcc_Query_Condition(long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   int[] ByIndependent_CompanionIds){
  StringBuilder ret;
  boolean first;
  int[] coltype;
  Object[] ByStrict_AData;
  String ColMainId, ColCompId; // Comp = Companion
  
  ret=new StringBuilder(); first=true;

  ColMainId="Subject";
  ColCompId="Enumeration";
  
  if(!PCore.isArrayEmpty(MainIds, true)){
   if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
   ret.append(" "+ColMainId+" in("+PText.toString(MainIds, 0, MainIds.length, ",")+")");
  }
  
  if(ByStrict){
   if(!PCore.isVectorEmpty(ByStrict_Data, true)){
    if(!ByStrict_SpecificRow){
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ret.append(" "+PSql.genCheckKey(PCore.refArr(ColCompId), ByStrict_Data, getSubjectAcc_ColumnsType(), PCore.primArr(0)));
    }
    else{
     if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
     ByStrict_AData=ByStrict_Data.elementAt(ByStrict_Row); coltype=getSubjectAcc_ColumnsType();
     ret.append(" ("+PSql.genVarAndValue(ColCompId, ByStrict_AData[0], coltype[0], true)+")");
    }
   }
  }
  else{
   if(!PCore.isArrayEmpty(ByIndependent_CompanionIds, true)){
    if(first){ret.append(" where"); first=false;}else{ret.append(" and");}
    ret.append(" "+PSql.genCheckList(ColCompId, ByIndependent_CompanionIds, true));
   }
  }
  
  return ret.toString();
 }
 public static String getSubjectAcc_Query(long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data, boolean ByStrict_SpecificRow, int ByStrict_Row,
   int[] ByIndependent_CompanionIds,
  boolean WithCompleteInfo){
  String ret;
  StringBuilder OrderBy;
  String Order_Normal;
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  OrderBy=new StringBuilder(" order by");
  Order_Normal=" BankPlatform.Name asc, BankAccount asc";
  OrderBy.append(Order_Normal);
  
  ret=
   "select Enumeration, BankPlatformId, BankPlatform.Name as 'BankPlatformName', BankAccount, Comment from "+
    "(select Enumeration, BankAccount, BankPlatform as 'BankPlatformId', Comment from SubjectXBankAccount"+
    getSubjectAcc_Query_Condition(MainIds, ByStrict, ByStrict_Data, ByStrict_SpecificRow, ByStrict_Row, ByIndependent_CompanionIds)+") as tb1 "+
   "left join BankPlatform on tb1.BankPlatformId=BankPlatform.Id"+
   OrderBy.toString();
  
  return ret;
 }
 public static Vector<Object[]> getSubjectAcc(Statement Stm, long MainId, int[] CompanionIds){
  Vector<Object[]> ret=new Vector();
  int result;
  
  result=PDatabase.queryToRows(Stm,
   getSubjectAcc_Query(PCore.primArr(MainId), false, null, false, -1, CompanionIds, false), ret, getSubjectAcc_ColumnsType());
  if(result==-1){ret=null;}
  
  return ret;
 }
 public static Vector<Object[]> getSubjectAcc(Statement Stm, long MainId){
  return getSubjectAcc(Stm, MainId, null);
 }
 
 public static OInfoSubjectBankAccount getSubjectAccInfo(Statement Stm, long MainId, int CompId){
  OInfoSubjectBankAccount ret=new OInfoSubjectBankAccount();
  ResultSet Rs;
  boolean IsError;
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  IsError=false;
  try{
   do{
    Rs=Stm.executeQuery(getSubjectAcc_Query(PCore.primArr(MainId), false, null, false, -1, PCore.primArr(CompId), false));
    if(!Rs.next()){IsError=true; break;}
    
    ret.Enumeration=Rs.getInt(1);
    ret.BankPlatformId=Rs.getInt(2); if(Rs.wasNull()){ret.BankPlatformId=-1;}
    ret.BankPlatformName=Rs.getString(3);
    ret.Acc=Rs.getString(4);
    ret.Comment=Rs.getString(5);
   }while(false);
  }
  catch(Exception E){IsError=true;}
  
  if(IsError){ret=null;}
   
  return ret;
 }
 
 //
 public static Vector<Object[]> getListForComboBox_InfoIdName(Statement Stm, String Query, boolean IdIsInteger, OGetString GetNameMode,
  boolean AddUndefined, boolean AddQuery){
  Vector<Object[]> ret=new Vector();
  ResultSet Rs;
  Object[] objs;
  boolean bool, IsError;
  int[] ColType;
  int ColCount;
  OInfoIdName Info;
  
  /*
   "Id", "Name"
  */
  
  IsError=false;
  
  if(AddUndefined){
   Info=new OInfoIdName(IdIsInteger);
   Info.setVars(IdIsInteger, -1, "~", GetNameMode);
   ret.addElement(PCore.objArrVariant(Info.getName(), Info));
  }
  
  if(AddQuery){
   try{
    Rs=Stm.executeQuery(Query);

    ColType=PCore.primArr(PCore.subtBool_Int(IdIsInteger, CCore.TypeInteger, CCore.TypeLong), CCore.TypeString); ColCount=ColType.length;
    objs=new Object[ColCount];

    bool=true;
    do{
     if(!Rs.next()){break;}

     PCore.fillValue(objs, null);
     PDatabase.fillResultSetToRow(Rs, objs, ColType, false, null, null);

     Info=new OInfoIdName(IdIsInteger);
     Info.setVars(IdIsInteger, PCore.getValueIntLong(objs[0], IdIsInteger, -1L), PCore.objString(objs[1], null), GetNameMode);

     ret.addElement(PCore.objArrVariant(Info.getName(), Info));
    }while(bool);
   }
   catch(Exception E){IsError=true;}
  }
  
  if(IsError){}
  
  return ret;
 }
 
 public static String getQueryOfFindItemIds(String Id, boolean FindSubId, String Columns, String Conditions, boolean GroupById, String OrderBy, boolean LimitToSingleRecord){
  String ret=
   "select "+Columns+" from Item left join ItemXSecondaryId on Item.Id=ItemXSecondaryId.Item where "+
   PText.getString(!FindSubId, "(Item.Id="+Id+" or ItemXSecondaryId.SecondaryId="+Id+")",
    "("+PSql.genCheckWord("cast(Item.Id as char(18))", Id, true, true)+" or "+PSql.genCheckWord("cast(ItemXSecondaryId.SecondaryId as char(18))", Id, true, true)+")")+
   PText.getString(Conditions==null, "", " "+Conditions)+
   PText.getString(!GroupById, "", " group by Item.Id")+
   PText.getString(OrderBy==null, "", " "+OrderBy)+
   PText.getString(!LimitToSingleRecord, "", " limit 1");
  return ret;
 }
 public static String getQueryOfItemIds(boolean UnionAll, boolean WithOrderBy, boolean OrderByAsc){
  String ret=
   "select Id as 'ItemId' from Item "+
   "union "+PText.getString(!UnionAll, "distinct", "all")+" "+
   "select SecondaryId from ItemXSecondaryId"+
   PText.getString(!WithOrderBy, "", " order by ItemId "+PText.getString(OrderByAsc, "asc", "desc"));
  return ret;
 }
 public static Long generateNewIdOnItem(Statement Stm, OBarcodeGenerator IdGenerator){
  return PDatabase.generateNewId(IdGenerator, Stm, getQueryOfItemIds(false, true, true));
 }
 public static int checkExistIdOnItem(long Id, Statement Stm){
  // -1 error, 0 available, 1 exist
  return PDatabase.isQueryEmpty(Stm, "select * from ("+getQueryOfItemIds(false, false, true)+") as tb1 where ItemId="+Id, false);
 }
 
 public static boolean updateOpname(Statement Stm, String LockId, int TimeoutSecond, long[] ItemId,
  boolean UpdateOpStock, int UpdateOpStockMode, Double ValueOpStock,
  boolean UpdateOpExpire, int UpdateOpExpireMode, Date ValueOpExpire){
  boolean ret=false;
  boolean started=false;
  boolean locked=false;
  int temp;
  ResultSet Rs;
  
  int op_countmax, op_count, op_temp, length;
  StringBuilder columns;
  String str_columns;
  boolean columns_first;
  String str;
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    columns=new StringBuilder();
    columns_first=true;
    
    if(UpdateOpStock){
     if(columns_first){columns_first=false;}else{columns.append(",");}
     str=PText.getStringDouble2(ValueOpStock, CCore.vNull, false, false);
     switch(UpdateOpStockMode){
      case 0 : columns.append(" OpnameStock="+str); break;
      case 1 : columns.append(" OpnameStock="+CCore.vNull); break;
      case 2 : columns.append(" OpnameStock=ifnull(OpnameStock, 0)+ifnull("+str+", 0)"); break;
      case 3 : columns.append(" OpnameStock=ifnull(OpnameStock, 0)-ifnull("+str+", 0)"); break;
     }
    }
    
    if(UpdateOpExpire){
     if(columns_first){columns_first=false;}else{columns.append(",");}
     str=PDatabase.dateToSQLStringFormat(ValueOpExpire);
     switch(UpdateOpExpireMode){
      case 0 : columns.append(" OpnameExpire="+str); break;
      case 1 : columns.append(" OpnameExpire="+CCore.vNull); break;
      case 2 : columns.append(" OpnameExpire=if(ifnull("+str+", '9999-12-31')<ifnull(OpnameExpire, '9999-12-31'), "+str+", OpnameExpire)"); break;
      case 3 : columns.append(" OpnameExpire=if(ifnull("+str+", '1000-01-01')>ifnull(OpnameExpire, '1000-01-01'), "+str+", OpnameExpire)"); break;
     }
    }
    
    str_columns=columns.toString();
    op_countmax=1000;
    length=ItemId.length;
    op_temp=0;
    do{
     op_count=op_countmax; if(op_count>length-op_temp){op_count=length-op_temp;}
     Stm.execute("update Item set"+str_columns+" where Id in("+PText.toString(ItemId, op_temp, op_count, ",")+")");
     op_temp=op_temp+op_count;
    }while(op_temp!=length);
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(locked){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static String getTableOrderInfo(
  String OrderTargetBaseCalculation,
  String InfoOrderQty_OrderTarget, double InfoOrderQty_OrderTargetPercentage,
  String Condition, String Having){
  String Con=PText.getString(Condition, "", " where "+Condition, true);
  String Hav=PText.getString(Having, "", " having "+Having, true);
  
  return 
   
   "("+
    "select ord6.Id as 'Order_ItemId', vOrderEachPackQty, vOrderEachPackThreshold, vOrderMinPack, Qty, QtyInPack, QtyInPackRounded, "+
     "if(Qty<=0, 0, "+
      "if(QtyInPackRounded<=vOrderMinPack, vOrderMinPack*vOrderEachPackQty, QtyInPackRounded*vOrderEachPackQty)"+
     ") as 'QtyRounded' "+
    "from "+
     "(select ord5.*, "+
      "if(Qty<=0, 0, "+
       "if(mod(QtyInPack,1)=0 or mod(QtyInPack,1)<(vOrderEachPackThreshold/100), "+
        "floor(QtyInPack), "+
        "ceiling(QtyInPack)"+
       ")"+
      ") as 'QtyInPackRounded' "+
     "from "+
      "(select ord4.*, ("+InfoOrderQty_OrderTarget+"-"+OrderTargetBaseCalculation+") as 'Qty', ("+InfoOrderQty_OrderTarget+"-"+OrderTargetBaseCalculation+")/vOrderEachPackQty as 'QtyInPack' from "+
       "(select ord3.*, (Stock+ifnull(PreStockIn,0)-ifnull(PreStockOut,0)) as 'StockEst' from "+
        "(select ord2.*, Sum(PreTransXItemOut.Stock) as 'PreStockOut' from "+
         "(select ord1.*, Sum(PreTransXItemIn.Stock) as 'PreStockIn' from "+
          "(select Item.*, "+
           "if(OrderEachPackQty<=0, 1, OrderEachPackQty) as 'vOrderEachPackQty', if(OrderEachPackThreshold<=0, 1, OrderEachPackThreshold) as 'vOrderEachPackThreshold', if(OrderMinPack<=0, 1, OrderMinPack) as 'vOrderMinPack', "+
           "if((MaximalStock-MinimalStock)<=0, MinimalStock, MinimalStock+("+PText.doubleToString(InfoOrderQty_OrderTargetPercentage, false)+"/100)*(MaximalStock-MinimalStock)) as 'Prc' from Item"+Con+") as ord1 "+
         "left join PreTransXItemIn on ord1.Id=PreTransXItemIn.Item group by ord1.Id) as ord2 "+
        "left join PreTransXItemOut on ord2.Id=PreTransXItemOut.Item group by ord2.Id) as ord3 "+
       ") as ord4 "+
      ") as ord5 "+
     ") as ord6 "+
   Hav+
   ") as info_order";
 }
 public static boolean updateOrder(Statement Stm, String LockId, int TimeoutSecond, long[] ItemId,
  boolean UpdateOrderQty, int UpdateOrderQtyMode, double ValueOrderQty){
  boolean ret=false;
  boolean started=false;
  boolean locked=false;
  int temp;
  ResultSet Rs;
  
  int op_countmax, op_count, op_temp, length;
  StringBuilder columns;
  boolean columns_first;
  String Ids;
  
  boolean IncludeTableOrderInfo;
  String TableOrderInfo;
  String InfoOrderQty_OrderTarget=null;
  double InfoOrderQty_OrderTargetPercentage;
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    columns=new StringBuilder(); columns_first=true;
    
    IncludeTableOrderInfo=false; InfoOrderQty_OrderTarget=null; InfoOrderQty_OrderTargetPercentage=0;
    if(UpdateOrderQty){
     if(columns_first){columns_first=false;}else{columns.append(",");}
     columns.append(" OrderQuantity=");
     
     do{
      if(UpdateOrderQtyMode==0){columns.append(PText.getStringDouble(ValueOrderQty, CCore.vNull, -0.1, false, false)); break;}
      if(UpdateOrderQtyMode==1){columns.append(CCore.vNull); break;}
      
      IncludeTableOrderInfo=true;
      do{
       if(UpdateOrderQtyMode==2){InfoOrderQty_OrderTarget="MinimalStock"; break;}
       if(UpdateOrderQtyMode==3){InfoOrderQty_OrderTarget="MaximalStock"; break;}
       if(UpdateOrderQtyMode==4){InfoOrderQty_OrderTarget="Prc"; InfoOrderQty_OrderTargetPercentage=ValueOrderQty; break;}
      }while(false);
      columns.append("QtyRounded");
     }while(false);
    }
    
    op_countmax=1000;
    length=ItemId.length;
    op_temp=0;
    do{
     op_count=op_countmax; if(op_count>length-op_temp){op_count=length-op_temp;}
     
     Ids=PText.toString(ItemId, op_temp, op_count, ",");
     TableOrderInfo="";
     if(IncludeTableOrderInfo){
      TableOrderInfo=
       " inner join "+
       getTableOrderInfo("StockEst", InfoOrderQty_OrderTarget, InfoOrderQty_OrderTargetPercentage, "Item.Id in ("+Ids+")", null)+
       " on Item.Id=info_order.Order_ItemId";
     }
     Stm.execute("update Item"+TableOrderInfo+" set"+columns.toString()+" where Item.Id in("+Ids+")");
     
     op_temp=op_temp+op_count;
    }while(op_temp!=length);
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(locked){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }

 public static boolean removeTransactions(OFormInformProgress Progress, Statement Stm, String LockId, int TimeoutSecond, boolean IsPreTrans, long[] Id){
  String Tbl=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  return PDatabase.removeIdsWithLock(Progress, Stm, LockId, TimeoutSecond, Tbl, Id);
 }
 public static boolean cancelTransaction(Statement Stm, String LockId, int TimeoutSecond, boolean IsPreTrans, long TransId,
  boolean ForceFinish, Statement AdminStm){
  boolean ret=false;
  ResultSet Rs;
  int temp;
  boolean locked=false;
  boolean started=false;
  
  OCustomListModel mdl_in, mdl_out;
  int[] OverInputQty;
  boolean error;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  
  do{
   try{
    // prepare necessary action in order to finish operation successfully
    if(ForceFinish && !IsPreTrans){
     error=true;
     do{
      mdl_in=new OCustomListModel(false);
      mdl_in.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeDouble), 0); // Item Id, Quantity
      mdl_out=new OCustomListModel(false);
      mdl_out.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeDouble), 0); // Item Id, Quantity
      
      if(PDatabase.queryToRows(AdminStm, "select Item, Stock from "+Tbl+"XItemIn where "+Tbl+"="+TransId+";",
       mdl_in.getRows(), mdl_in.getColumnsType(), mdl_in, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1)==-1){break;}
      if(PDatabase.queryToRows(AdminStm, "select Item, Stock from "+Tbl+"XItemOut where "+Tbl+"="+TransId+";",
       mdl_out.getRows(), mdl_out.getColumnsType(), mdl_out, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1)==-1){break;}

      OverInputQty=checkOverInputOfItemStock(AdminStm, mdl_in.getRows(), 0, 1, true, mdl_out.getRows(), 0, 1);
      if(OverInputQty==null){break;}
      
      if(OverInputQty.length!=0){
       if(!assignItemsWithMismatchStock(AdminStm, mdl_in.getRows(), 0, OverInputQty)){break;}
      }
      
      error=false;
     }while(false);
     if(error){break;}
    }
    
    // doing operation
    Stm.execute("start transaction;");
    started=true;
    
    // remove record in table TransXItemOut, TransXItemIn, TransXPayment, and TransXPaymentIn
    Stm.executeUpdate("delete from "+Tbl+"XItemOut where "+Tbl+"="+TransId+";");
    Stm.executeUpdate("delete from "+Tbl+"XItemIn where "+Tbl+"="+TransId+";");
    Stm.executeUpdate("delete from "+Tbl+"XPayment where "+Tbl+"="+TransId+";");
    Stm.executeUpdate("delete from "+Tbl+"XPaymentIn where "+Tbl+"="+TransId+";");
    
    // delete trans id
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    Stm.executeUpdate("delete from "+Tbl+" where Id="+TransId+";");
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(locked){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }

 public static boolean convertTrans(Statement Stm, long SourceId, boolean SourceIsPreTrans,
  String PreTransLockId, int PreTransTimeoutSecond, String TransLockId, int TransTimeoutSecond,
  boolean AlsoCancelSource,
  boolean ForceFinish, Statement AdminStm){
  boolean ret=false;
  ResultSet Rs;
  Statement NewStm=null;
  int temp;
  boolean source_locked=false;
  boolean dest_locked=false;
  boolean started=false;
  
  Date Dt;
  long DestId, IdTemp;
  OInfoTrans SourceDet;
  String SourceLockId; int SourceTimeoutSecond; String SourceTbl;
  String DestLockId; int DestTimeoutSecond; String DestTbl;
  
  String
   
   TransTb,
   TransTb_ItemIn, TransTb_ItemOut, TransTb_PayOut, TransTb_PayIn,
   TransTb_ItemIn_Temp, TransTb_ItemOut_Temp, TransTb_PayOut_Temp, TransTb_PayIn_Temp,
   
   PreTransTb,
   PreTransTb_ItemIn, PreTransTb_ItemOut, PreTransTb_PayOut, PreTransTb_PayIn,
   PreTransTb_ItemIn_Temp, PreTransTb_ItemOut_Temp, PreTransTb_PayOut_Temp, PreTransTb_PayIn_Temp,
   
   SourceTb_ItemIn, SourceTb_ItemOut, SourceTb_PayOut, SourceTb_PayIn,
   
   DestTb_ItemIn, DestTb_ItemOut, DestTb_PayOut, DestTb_PayIn,
   DestTb_ItemIn_Temp, DestTb_ItemOut_Temp, DestTb_PayOut_Temp, DestTb_PayIn_Temp;
  
  int MaxEachInsert=100;
  boolean first, curr_record, error;
  StringBuilder query;
  
  OCustomListModel mdl_in, mdl_out;
  int[] OverInputQty;
  String str1, str2;
  
  // Trans
  TransTb="Trans";
  TransTb_ItemIn=TransTb+"XItemIn"; TransTb_ItemIn_Temp=CSQL.getTableTemp(TransTb_ItemIn);
  TransTb_ItemOut=TransTb+"XItemOut"; TransTb_ItemOut_Temp=CSQL.getTableTemp(TransTb_ItemOut);
  TransTb_PayOut=TransTb+"XPayment"; TransTb_PayOut_Temp=CSQL.getTableTemp(TransTb_PayOut);
  TransTb_PayIn=TransTb+"XPaymentIn"; TransTb_PayIn_Temp=CSQL.getTableTemp(TransTb_PayIn);
  
  // PreTrans
  PreTransTb="PreTrans";
  PreTransTb_ItemIn=PreTransTb+"XItemIn"; PreTransTb_ItemIn_Temp=CSQL.getTableTemp(PreTransTb_ItemIn);
  PreTransTb_ItemOut=PreTransTb+"XItemOut"; PreTransTb_ItemOut_Temp=CSQL.getTableTemp(PreTransTb_ItemOut);
  PreTransTb_PayOut=PreTransTb+"XPayment"; PreTransTb_PayOut_Temp=CSQL.getTableTemp(PreTransTb_PayOut);
  PreTransTb_PayIn=PreTransTb+"XPaymentIn"; PreTransTb_PayIn_Temp=CSQL.getTableTemp(PreTransTb_PayIn);
  
  //
  SourceLockId=PText.getString(SourceIsPreTrans, PreTransLockId, TransLockId);
  SourceTimeoutSecond=PCore.subtBool_Int(SourceIsPreTrans, PreTransTimeoutSecond, TransTimeoutSecond);
  
  SourceTbl=PText.getString(SourceIsPreTrans, PreTransTb, TransTb);
  
  SourceTb_ItemIn=PText.getString(SourceIsPreTrans, PreTransTb_ItemIn, TransTb_ItemIn);
  SourceTb_ItemOut=PText.getString(SourceIsPreTrans, PreTransTb_ItemOut, TransTb_ItemOut);
  SourceTb_PayOut=PText.getString(SourceIsPreTrans, PreTransTb_PayOut, TransTb_PayOut);
  SourceTb_PayIn=PText.getString(SourceIsPreTrans, PreTransTb_PayIn, TransTb_PayIn);
  
  //
  DestLockId=PText.getString(SourceIsPreTrans, TransLockId, PreTransLockId);
  DestTimeoutSecond=PCore.subtBool_Int(SourceIsPreTrans, TransTimeoutSecond, PreTransTimeoutSecond);
  
  DestTbl=PText.getString(SourceIsPreTrans, TransTb, PreTransTb);
  
  DestTb_ItemIn=PText.getString(SourceIsPreTrans, TransTb_ItemIn, PreTransTb_ItemIn);
  DestTb_ItemOut=PText.getString(SourceIsPreTrans, TransTb_ItemOut, PreTransTb_ItemOut);
  DestTb_PayOut=PText.getString(SourceIsPreTrans, TransTb_PayOut, PreTransTb_PayOut);
  DestTb_PayIn=PText.getString(SourceIsPreTrans, TransTb_PayIn, PreTransTb_PayIn);
  
  DestTb_ItemIn_Temp=PText.getString(SourceIsPreTrans, TransTb_ItemIn_Temp, PreTransTb_ItemIn_Temp);
  DestTb_ItemOut_Temp=PText.getString(SourceIsPreTrans, TransTb_ItemOut_Temp, PreTransTb_ItemOut_Temp);
  DestTb_PayOut_Temp=PText.getString(SourceIsPreTrans, TransTb_PayOut_Temp, PreTransTb_PayOut_Temp);
  DestTb_PayIn_Temp=PText.getString(SourceIsPreTrans, TransTb_PayIn_Temp, PreTransTb_PayIn_Temp);
  
  //
  do{
   try{
    // prepare necessary action in order to finish operation successfully
    if(ForceFinish && !(!SourceIsPreTrans && !AlsoCancelSource)){
     error=true;
     do{
      mdl_in=new OCustomListModel(false);
      mdl_in.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeDouble), 0); // Item Id, Quantity
      mdl_out=new OCustomListModel(false);
      mdl_out.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeDouble), 0); // Item Id, Quantity
      
      str1=PText.getString(SourceIsPreTrans, "PreTransXItemIn", "TransXItemOut");
      str2=PText.getString(SourceIsPreTrans, "PreTransXItemOut", "TransXItemIn");
      
      if(PDatabase.queryToRows(AdminStm, "select Item, Stock from "+str1+" where "+SourceTbl+"="+SourceId+";",
       mdl_in.getRows(), mdl_in.getColumnsType(), mdl_in, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1)==-1){break;}
      if(PDatabase.queryToRows(AdminStm, "select Item, Stock from "+str2+" where "+SourceTbl+"="+SourceId+";",
       mdl_out.getRows(), mdl_out.getColumnsType(), mdl_out, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1)==-1){break;}

      OverInputQty=checkOverInputOfItemStock(AdminStm, mdl_out.getRows(), 0, 1, true, mdl_in.getRows(), 0, 1);
      if(OverInputQty==null){break;}
      
      if(OverInputQty.length!=0){
       if(!assignItemsWithMismatchStock(AdminStm, mdl_out.getRows(), 0, OverInputQty)){break;}
      }
      
      error=false;
     }while(false);
     if(error){break;}
    }
    
    // doing operation
    Stm.execute("start transaction;");
    started=true;
    
    // copy source's data to destination
    
     // create destination Id
    SourceDet=getTransInfo(Stm, SourceIsPreTrans, SourceId);
    if(SourceDet==null){break;}
    
    Dt=new Date();
    DestId=(long)PText.dateInNumber(Dt)*100000000;
    
    Rs=Stm.executeQuery("select get_lock('"+DestLockId+"',"+DestTimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    dest_locked=true;
    
    Rs=Stm.executeQuery("select max(Id) from "+DestTbl+" where Id>"+DestId+" and Id<="+(DestId+99999999)+";");
    if(Rs.next()==true){
     IdTemp=Rs.getLong(1);
     if(Rs.wasNull()==false){DestId=IdTemp;}
    }
    DestId=DestId+1;
    
    Stm.executeUpdate("insert into "+DestTbl+" (Id, TransDate, TransType, Subject, IsImportant, Comment, Salesman, "+
     "CreditDays, Cash, CashIn, RepaymentPeriodStart, RepaymentPeriodEnd, InfoIdExternal, CashOutComment, CashInComment) values("+
     DestId+","+PDatabase.dateToSQLStringFormat(SourceDet.Dt)+","+PText.getString(SourceDet.TypeId, CCore.vNull, -1, false)+","+
     PText.getString(SourceDet.SubjectId, CCore.vNull, -1, false)+","+PText.getString(SourceDet.Important, CCore.vTrue, CCore.vFalse)+","+
     PText.getStringWithQuote(PSql.norm(SourceDet.Comment), CCore.vNull, '\'', true)+","+PText.getString(SourceDet.SalesmanId, CCore.vNull, -1, false)+","+
     PText.getString(SourceDet.CreditDays, CCore.vNull, -1, false)+","+PText.getString(SourceDet.CashOutId, CCore.vNull, -1, false)+","+
     PText.getString(SourceDet.CashInId, CCore.vNull, -1, false)+","+
     PDatabase.dateToSQLStringFormat(SourceDet.RepaymentPeriodStart)+","+PDatabase.dateToSQLStringFormat(SourceDet.RepaymentPeriodEnd)+","+
     PText.getStringWithQuote(PSql.norm(SourceDet.InfoIdExternal), CCore.vNull, '\'', true)+","+
     PText.getStringWithQuote(PSql.norm(SourceDet.CashOutComment), CCore.vNull, '\'', true)+","+
     PText.getStringWithQuote(PSql.norm(SourceDet.CashInComment), CCore.vNull, '\'', true)+");");
    
    Stm.execute("select release_lock('"+DestLockId+"');");
    dest_locked=false;
    
    /* old style
    
     // prepare copy operation
    NewStm=Stm.getConnection().createStatement();
    
     // copying
    Rs=Stm.executeQuery("select Item, Stock, Price, Comment from "+SourceTbl+"XItemIn where "+SourceTbl+"="+SourceId+";");
    curr_record=Rs.next();
    if(curr_record){
     error=false;
     do{
      query=new StringBuilder("insert into "+DestTbl+"XItemIn ("+DestTbl+", Item, Stock, Price, Comment) values ");
      first=true;
      temp=0;
      do{
       if(first){first=false;}
       else{query.append(",");}
       
       query.append("("+DestId+","+Rs.getLong(1)+","+PText.doubleToString(Rs.getDouble(2), false)+","+PText.doubleToString(Rs.getDouble(3), false)+","+
        PText.getStringWithQuote(PSql.norm(Rs.getString(4)), CCore.vNull, '\'', true)+")");
       temp=temp+1;
       
       curr_record=Rs.next();
       if(!curr_record){break;}
      }while(temp!=MaxEachInsert);
      query.append(";");
      NewStm.executeUpdate(query.toString());
     }while(curr_record);
     if(error){break;}
    }
    
     // cancelling source
    Stm.executeUpdate("delete from "+SourceTbl+"XItemOut where "+SourceTbl+"="+SourceId+";");
    Stm.executeUpdate("delete from "+SourceTbl+"XItemIn where "+SourceTbl+"="+SourceId+";");
    Stm.executeUpdate("delete from "+SourceTbl+"XPayment where "+SourceTbl+"="+SourceId+";");
    Stm.executeUpdate("delete from "+SourceTbl+"XPaymentIn where "+SourceTbl+"="+SourceId+";");
    
    Rs=Stm.executeQuery("select get_lock('"+SourceLockId+"',"+SourceTimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    source_locked=true;
    
    Stm.executeUpdate("delete from "+SourceTbl+" where Id="+SourceId+";");
    
    Stm.execute("select release_lock('"+SourceLockId+"');");
    source_locked=false;
    
    */
    
     // copy item in
    Stm.executeUpdate(
     "insert into "+DestTb_ItemIn_Temp+"("+DestTbl+", Item, Stock, Price, Comment, Checked) "+
      "select "+DestId+", Item, Stock, Price, Comment, Checked from "+SourceTb_ItemIn+" where "+SourceTb_ItemIn+"."+SourceTbl+"="+SourceId+"; ");
    
     // copy item out
    Stm.executeUpdate(
     "insert into "+DestTb_ItemOut_Temp+"("+DestTbl+", Item, Stock, Price, Comment, Checked) "+
      "select "+DestId+", Item, Stock, Price, Comment, Checked from "+SourceTb_ItemOut+" where "+SourceTb_ItemOut+"."+SourceTbl+"="+SourceId+"; ");
    
     // copy payment out
    Stm.executeUpdate(
     "insert into "+DestTb_PayOut_Temp+"("+DestTbl+", Enumeration, PaymentDate, Price, Comment, Cash) "+
      "select "+DestId+", Enumeration, PaymentDate, Price, Comment, Cash from "+SourceTb_PayOut+" where "+SourceTb_PayOut+"."+SourceTbl+"="+SourceId+"; ");
    
     // copy payment in
    Stm.executeUpdate(
     "insert into "+DestTb_PayIn_Temp+"("+DestTbl+", Enumeration, PaymentDate, Price, Comment, Cash) "+
      "select "+DestId+", Enumeration, PaymentDate, Price, Comment, Cash from "+SourceTb_PayIn+" where "+SourceTb_PayIn+"."+SourceTbl+"="+SourceId+"; ");
    
     // finalize
    Stm.executeUpdate("call "+DestTbl+"Insert("+DestId+");");
    
    // cancel source
    if(AlsoCancelSource){
     Stm.executeUpdate("call "+SourceTbl+"Cancel("+SourceId+");");
    }
    
    //
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(NewStm != null){
   try{NewStm.close();}catch(Exception E_){}
  }
  if(dest_locked){
   try{Stm.execute("select release_lock('"+DestLockId+"');");}catch(Exception E){}
  }
  if(source_locked){
   try{Stm.execute("select release_lock('"+SourceLockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }

 public static boolean cancelATransactionItem(Statement Stm, boolean IsPreTrans, boolean IsItemIn, long TransId, long ItemId){
  boolean ret=false;
  boolean started=false;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  String TblItem=null;
  if(!IsPreTrans){
   if(IsItemIn){TblItem="TransXItemIn";}
   else{TblItem="TransXItemOut";}
  }
  else{
   if(IsItemIn){TblItem="PreTransXItemIn";}
   else{TblItem="PreTransXItemOut";}
  }
  
  do{
   try{
    
    Stm.execute("start transaction;");
    started=true;
    
    // remove
    Stm.executeUpdate("delete from "+TblItem+" where "+Tbl+"="+TransId+" and Item="+ItemId+";");
     
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{Stm.executeQuery("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean editATransactionItem(Statement Stm, boolean IsPreTrans, boolean IsItemIn,
  long TransId, long ItemId, OEditTransItem Edit){
  boolean ret=false;
  boolean started=false;
  boolean first;
  StringBuilder cols;
  StringBuilder price_total;
  String str;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  String TblItem=null;
  if(!IsPreTrans){
   if(IsItemIn){TblItem="TransXItemIn";}
   else{TblItem="TransXItemOut";}
  }
  else{
   if(IsItemIn){TblItem="PreTransXItemIn";}
   else{TblItem="PreTransXItemOut";}
  }
  
  cols=new StringBuilder();
  first=true;
  
  if(Edit.EditQuantity || Edit.EditPriceTotal || Edit.EditPriceUnit){
   if(first){first=false;}else{cols.append(',');}
   price_total=new StringBuilder();
   do{
    /*
     price total = quantity X price unit
     price total will be changed directly only if IsEditPrice==true && IsPriceTotal==true
     otherwise, perform change to price total explicitly by detecting value change of quantity & price unit
    */
    if(Edit.EditPriceTotal){price_total.append(PText.doubleToString(Edit.EditedPriceTotal, false)); break;}
    // quantity
    if(!Edit.EditQuantity){price_total.append("Stock");}else{price_total.append(PText.doubleToString(Edit.EditedQuantity, false));}
    price_total.append("*");
    // price unit
    if(!Edit.EditPriceUnit){price_total.append("(Price/Stock)");}else{price_total.append(PText.doubleToString(Edit.EditedPriceUnit, false));}
   }while(false);
   cols.append("Price="+price_total.toString());
  }
  
  if(Edit.EditQuantity){
   if(first){first=false;}else{cols.append(',');}
   cols.append("Stock="+PText.doubleToString(Edit.EditedQuantity, false));
  }
  
  if(Edit.EditComment){
   if(first){first=false;}else{cols.append(',');}
   if(!Edit.ReplaceSubComment){
    str=PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true);
   }
   else{
    str="replace(Comment, '"+PSql.norm(Edit.SubComment)+"', '"+PSql.norm(Edit.EditedComment)+"')";
   }
   cols.append("Comment="+str);
  }
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    // update transaction's item in/out value
    Stm.executeUpdate("update "+TblItem+" set "+cols.toString()+" where "+Tbl+"="+TransId+" and Item="+ItemId+";");
    
    Stm.execute("commit;");
   }catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean addATransactionItem(Statement Stm, boolean IsPreTrans, boolean IsItemIn,
  long TransId, long ItemId, double Quantity, double Price, String Comment){
  // only add if kind of item hasn't been existed in transaction's item in/out list
  boolean ret=false;
  boolean started=false;
  
  String Proc=null;
  if(!IsPreTrans){
   if(IsItemIn){Proc="TransInAdd";}
   else{Proc="TransOutAdd";}
  }
  else{
   if(IsItemIn){Proc="PreTransInAdd";}
   else{Proc="PreTransOutAdd";}
  }
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    // insert new record to transaction's item in/out
    Stm.executeUpdate("call "+Proc+"("+TransId+","+ItemId+","+PText.doubleToString(Quantity, false)+","+PText.doubleToString(Price, false)+","+
     PText.getStringWithQuote(PSql.norm(Comment), CCore.vNull, '\'', true)+","+CApp.Default_TransItem_Checked+");");
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }

 public static boolean cancelATransactionPayment(Statement Stm, boolean IsPreTrans, boolean IsIn, long TransId, int Enumeration){
  boolean ret=false;
  boolean started=false;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  String TblPay=null;
  if(!IsPreTrans){
   if(IsIn){TblPay="TransXPaymentIn";}
   else{TblPay="TransXPayment";}
  }
  else{
   if(IsIn){TblPay="PreTransXPaymentIn";}
   else{TblPay="PreTransXPayment";}
  }
  
  do{
   try{
    
    Stm.execute("start transaction;");
    started=true;
    
    // remove
    Stm.executeUpdate("delete from "+TblPay+" where "+Tbl+"="+TransId+" and Enumeration="+Enumeration+";");
     
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{Stm.executeQuery("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean editATransactionPayment(Statement Stm, boolean IsPreTrans, boolean IsIn, long TransId, int Enumeration,
  boolean IsEditDate, Date PaymentDateNew, boolean IsEditCash, int CashNew,
  boolean IsEditPrice, double PriceNew, boolean IsEditComment, boolean IsEditCommentSub, String CommentSub, String CommentNew){
  boolean ret=false;
  boolean started=false;
  boolean first;
  StringBuilder cols;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  String TblPay=null;
  if(!IsPreTrans){
   if(IsIn){TblPay="TransXPaymentIn";}
   else{TblPay="TransXPayment";}
  }
  else{
   if(IsIn){TblPay="PreTransXPaymentIn";}
   else{TblPay="PreTransXPayment";}
  }
  
  cols=new StringBuilder();
  first=true;
  if(IsEditDate){
   if(first){first=false;}else{cols.append(',');}
   cols.append("PaymentDate="+PDatabase.dateToSQLStringFormat(PaymentDateNew));
  }
  if(IsEditCash){
   if(first){first=false;}else{cols.append(',');}
   cols.append("Cash="+PText.getString(CashNew, CCore.vNull, -1, false));
  }
  if(IsEditPrice){
   if(first){first=false;}else{cols.append(',');}
   cols.append("Price="+PText.doubleToString(PriceNew, false));
  }
  if(IsEditComment){
   if(first){first=false;}else{cols.append(',');}
   if(!IsEditCommentSub){
    cols.append("Comment="+PText.getStringWithQuote(PSql.norm(CommentNew), CCore.vNull, '\'', true));
   }
   else{
    cols.append("Comment=replace(Comment, '"+PSql.norm(CommentSub)+"', '"+PSql.norm(CommentNew)+"')");
   }
  }
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    // update transaction's payment data
    Stm.executeUpdate("update "+TblPay+" set "+cols.toString()+" where "+Tbl+"="+TransId+" and Enumeration="+Enumeration+";");
    
    Stm.execute("commit;");
   }catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static int addATransactionPayment(Statement Stm, boolean IsPreTrans, boolean IsIn,
  long TransId, Date PaymentDate, int Cash, double Price, String Comment){
  int ret=-1;
  boolean started=false;
  Long vEnumeration;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  String TblPay=null;
  if(!IsPreTrans){
   if(IsIn){TblPay="TransXPaymentIn";}
   else{TblPay="TransXPayment";}
  }
  else{
   if(IsIn){TblPay="PreTransXPaymentIn";}
   else{TblPay="PreTransXPayment";}
  }
  
  do{
   try{
    // pre-processing
    vEnumeration=PDatabase.generateNewId(null, Stm, "select Enumeration from "+TblPay+" where "+Tbl+"="+
     TransId+" order by Enumeration asc;");
    if(vEnumeration==null){break;}
    
    // processing
    Stm.execute("start transaction;");
    started=true;
    
    // insert new record to transaction's payment
    Stm.executeUpdate(
     "insert into "+TblPay+"("+Tbl+", Enumeration, PaymentDate, Cash, Price, Comment) values("+TransId+","+vEnumeration+
     ","+PDatabase.dateToSQLStringFormat(PaymentDate)+","+PText.getString(Cash, CCore.vNull, -1, false)+","+PText.doubleToString(Price, false)+
     ","+PText.getStringWithQuote(PSql.norm(Comment), CCore.vNull, '\'', true)+");");
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=vEnumeration.intValue();
  }while(false);
  if(started && ret==-1){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean addTransactionItems(
  OFormInformProgress Progress, Statement Stm, boolean IsPreTrans, boolean IsItemIn, boolean TransItemsAddUpdate,
  long TransId, Vector<Object[]> TransItems, int TransItems_ColId, int TransItems_ColQty, int TransItems_ColPrice,
  boolean AlsoResetItemsOrderQty, String OrderLockId, int OrderLockTimeoutSecond){
  boolean ret=false;
  boolean started=false;
  
  boolean error;
  String Proc;
  int length, temp;
  Object[] objs;
  long ItemId;
  double Quantity;
  double Price;
  
  Vector<Long> ResetItemsOrd;
  int ResetMax, ResetCurr, ResetUntil;
  long[] itemids;
  
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  boolean locked=false;
  ResultSet Rs;
  
  length=TransItems.size(); if(length==0){return true;}
  
  Proc=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  Proc=Proc+PText.getString(IsItemIn, "In", "Out");
  Proc=Proc+PText.getString(!TransItemsAddUpdate, "Add", "AddUpdate");
  
  ResetMax=1000;
  
  if(Progress!=null){
   increase_n_times=10;
   increase_every_n_records=length/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=length;}
   increase_size=100/increase_n_times;
  }
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    if(AlsoResetItemsOrderQty){
     Rs=Stm.executeQuery("select get_lock('"+OrderLockId+"',"+OrderLockTimeoutSecond+");");
     if(Rs.next()==false){break;}
     temp=Rs.getInt(1);
     if(Rs.wasNull()){break;}
     if(temp!=1){break;}
     locked=true;
    }
    
    temp=0; error=false;
    do{
  
     ResetItemsOrd=new Vector();
     ResetCurr=0; ResetUntil=ResetMax; if(ResetUntil>length-temp){ResetUntil=length-temp;}
     
     do{
      
      objs=TransItems.elementAt(temp);
      ItemId=(Long)objs[TransItems_ColId];
      Quantity=(Double)objs[TransItems_ColQty];
      Price=(Double)objs[TransItems_ColPrice];
      
      // insert new record to transaction's item in/out
      if(Quantity>0){
       Stm.executeUpdate("call "+Proc+"("+TransId+","+ItemId+","+PText.doubleToString(Quantity, false)+","+PText.doubleToString(Price, false)+","+CCore.vNull+","+CApp.Default_TransItem_Checked+");");
      }
      
      ResetItemsOrd.addElement(ItemId);
      
      temp=temp+1;
      ResetCurr=ResetCurr+1;
      if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     
     }while(ResetCurr!=ResetUntil);
     if(error){break;}
     
     if(AlsoResetItemsOrderQty){
      itemids=PCore.primArr_VectLong(ResetItemsOrd);
      Stm.executeUpdate("update Item set OrderQuantity="+CCore.vNull+" where Id in("+PText.toString(itemids, 0, itemids.length, ",")+")");
     }
     
    }while(temp!=length);
    if(error){break;}
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(locked){
   try{Stm.execute("select release_lock('"+OrderLockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean addItemsOrder(
  OFormInformProgress Progress, Statement Stm, String OrderLockId, int OrderLockTimeoutSecond,
  Vector<Object[]> Items, int Items_ColId, int Items_ColOrderQty,
  boolean AlsoRemoveItemsInTrans, long TransId, boolean IsPreTrans, boolean IsItemIn){
  boolean ret=false;
  boolean started=false;
  
  boolean error;
  int length, temp;
  int OpMax, OpCurr, OpUntil;
  Object[] objs;
  long ItemId;
  double OrderQty;
  
  Vector<Long> RemoveTransItems;
  long[] itemids;
  
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  boolean locked=false;
  ResultSet Rs;
  
  String TransTbl;
  String TransItemTbl;
  
  length=Items.size(); if(length==0){return true;}
  
  TransTbl=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  TransItemTbl=TransTbl+"XItem"+PText.getString(IsItemIn, "In", "Out");
  
  OpMax=1000;
  
  if(Progress!=null){
   increase_n_times=10;
   increase_every_n_records=length/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=length;}
   increase_size=100/increase_n_times;
  }
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    Rs=Stm.executeQuery("select get_lock('"+OrderLockId+"',"+OrderLockTimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    temp=0; error=false;
    do{
  
     RemoveTransItems=new Vector();
     OpCurr=0; OpUntil=OpMax; if(OpUntil>length-temp){OpUntil=length-temp;}
     
     do{
      
      objs=Items.elementAt(temp);
      ItemId=(Long)objs[Items_ColId];
      OrderQty=(Double)objs[Items_ColOrderQty];
      
      // insert new record to transaction's item in/out
      Stm.executeUpdate("update Item set OrderQuantity=ifnull(OrderQuantity,0)+"+PText.doubleToString(OrderQty, false)+" where Id="+ItemId);
      
      RemoveTransItems.addElement(ItemId);
      
      temp=temp+1;
      OpCurr=OpCurr+1;
      if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     
     }while(OpCurr!=OpUntil);
     if(error){break;}
     
     if(AlsoRemoveItemsInTrans){
      itemids=PCore.primArr_VectLong(RemoveTransItems);
      Stm.executeUpdate("delete from "+TransItemTbl+" where "+TransTbl+"="+TransId+" and Item in("+PText.toString(itemids, 0, itemids.length, ",")+")");
     }
     
    }while(temp!=length);
    if(error){break;}
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(locked){
   try{Stm.execute("select release_lock('"+OrderLockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }

 public static int[] checkOverInputOfItemStock(Statement Stm,
  Vector<Object[]> TransItems_Out, int IndexOfItemId_Out, int IndexOfQuantity_Out,
  boolean CalculateItemIn, Vector<Object[]> TransItems_In, int IndexOfItemId_In, int IndexOfQuantity_In){
  // return : null = error, ret.size()==0 = no over input, ret.size()>0 = indexes of TransItem which indicate items which over input of stock
  Vector<Integer> ret=new Vector();
  int count, temp, currprocess_count;
  int eachprocesscount=400;
  int findindex;
  ResultSet Rs;
  int[] objindex;
  boolean[] objwithquote;
  
  long Id;
  double Stock;
  Object[] Objs_Out, Objs_In;
  double Qty_In, Qty_Out;
  
  int findindex_in;
  
  count=TransItems_Out.size();
  
  objindex=PCore.primArr(IndexOfItemId_Out);
  objwithquote=PCore.primArr(false);
  temp=0;
  try{
   do{
    currprocess_count=eachprocesscount;
    if(currprocess_count>count-temp){currprocess_count=count-temp;}
    // get Items detail
    Rs=Stm.executeQuery("select Stock, Id from Item where Id in ("+
     PText.toStringWithQuote(TransItems_Out, temp, currprocess_count, ",", objindex, objwithquote, "", "", ",", "'", "", false)+
     ") and UpdateStockOnTransaction="+CCore.vTrue+";");
    
    // check
    if(Rs.next()){
     do{
      do{
       Stock=Rs.getDouble(1);
       Id=Rs.getLong(2);

       findindex=PTable.findNumber(TransItems_Out, Id, IndexOfItemId_Out, false, temp, currprocess_count);
       if(findindex==-1){break;}
       
       Objs_Out=TransItems_Out.elementAt(findindex);
       Qty_Out=(Double)Objs_Out[IndexOfQuantity_Out];
       
       if(CalculateItemIn){
        findindex_in=PTable.findNumber(TransItems_In, Id, IndexOfItemId_In, false, 0, TransItems_In.size());
        if(findindex_in!=-1){
         Objs_In=TransItems_In.elementAt(findindex_in);
         Qty_In=(Double)Objs_In[IndexOfQuantity_In];
         if(Qty_In>=Qty_Out){break;}
         Qty_Out=Qty_Out-Qty_In;
        }
       }
       
       if(Stock<Qty_Out){ret.addElement(findindex);}
      }while(false);
     }while(Rs.next());
    }
    
    temp=temp+currprocess_count;
   }while(temp!=count);
  }
  catch(Exception E_){ret=null;}
  
  return PCore.primArr_VectInt(ret);
 }
 public static boolean assignItemsWithMismatchStock(Statement Stm, Vector<Object[]> TransItems,
  int IndexOfItemId, int[] ChangeIndex){
  boolean ret=false;
  boolean started=false;
  int OpMaxCount=1000;
  int IndexCount, CurrIndex, OpCount;
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    IndexCount=ChangeIndex.length;
    CurrIndex=0;
    do{
     OpCount=OpMaxCount;
     if(OpCount>IndexCount-CurrIndex){OpCount=IndexCount-CurrIndex;}
     
     Stm.execute("update Item set MismatchStock="+CCore.vTrue+" where Id in ("+
      PGUI.getElementList(TransItems, PCore.subArr(ChangeIndex, CurrIndex, OpCount), IndexOfItemId, ",", "", false)+");");
     
     CurrIndex=CurrIndex+OpCount;
    }while(CurrIndex!=IndexCount);
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 
 public static long executeInsertConvRule(Statement Stm, OInfoConvertRule InfoConvRule) throws Exception{
  long Id=-1; // -1 error, >= 0 success
  Long result;
  
  do{
   result=PDatabase.generateNewId(null, Stm, "select Id from RuleOfConv order by Id asc"); if(result==null){break;}
   Stm.executeUpdate("insert into RuleOfConv (Id, Name, IsActive, LastUpdate) values ("+result+",'"+PSql.norm(InfoConvRule.Name)+"',"+
    PText.getString(InfoConvRule.IsActive, CCore.vTrue, CCore.vFalse)+","+PDatabase.dateToSQLStringFormat(InfoConvRule.LastUpdate)+")");
   Id=result;
  }while(false);
  
  return Id;
 }
 public static boolean executeDeleteConvRule(Statement Stm, long ConvRuleId) throws Exception{
  boolean ret=true;
  
  try{Stm.executeUpdate("delete from RuleOfConv where Id="+ConvRuleId);}catch(Exception E){ret=false;}
  
  return ret;
 }
 public static void executeInsertConvRuleItems(Statement Stm, boolean IsItemOut, boolean IsAddUpdate, long[] ConvRuleIds, Vector<Object[]> ListItems) throws Exception{
  String TableItems=PText.getString(IsItemOut, "RuleOfConvXSideA", "RuleOfConvXSideB");
  
  int temp, MaxInsert, itemcount, itemcurr, convcount, convcurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long ConvRuleId;
  
  convcount=ConvRuleIds.length;
  
  if(ListItems==null){return;}
  itemcount=ListItems.size(); if(itemcount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  convcurr=0;
  do{
   ConvRuleId=ConvRuleIds[convcurr];
   
   itemcurr=0;
   do{
    objs=ListItems.elementAt(itemcurr);
    
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+ConvRuleId+","+PCore.objLong(objs[0], null)+","+PText.doubleToString(PCore.objDouble(objs[2], -1D), false)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (itemcurr==itemcount-1 && convcurr==convcount-1)){
     Stm.executeUpdate("insert into "+TableItems+" (RuleOfConv, Item, Stock) values "+strb.toString()+PText.getString(!IsAddUpdate, "", " on duplicate key update Stock=Stock+values(Stock)"));
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    itemcurr=itemcurr+1;
   }while(itemcurr!=itemcount);
  
   convcurr=convcurr+1;
  }while(convcurr!=convcount);
 }
 public static void executeEditConvRuleItems(Statement Stm, boolean IsItemOut, long ConvRuleId, long[] Items, OEditConvertItem Edit) throws Exception{
  String TableItems=PText.getString(IsItemOut, "RuleOfConvXSideA", "RuleOfConvXSideB");
  StringBuilder columns;
  boolean first;
  
  columns=new StringBuilder(); first=true;
  
  if(Edit.EditQuantity){
   if(first){first=false;}else{columns.append(',');}
   columns.append("Stock="+PText.doubleToString(Edit.EditedQuantity, false));
  }
  
  Stm.executeUpdate("update "+TableItems+" set "+columns+" where RuleOfConv="+ConvRuleId+" and Item in ("+PText.toString(Items, 0, Items.length, ",")+")");
 }
 public static void executeDeleteConvRuleItems(Statement Stm, boolean IsItemOut, long[] ConvRuleIds, long[] Items) throws Exception{
  String TableItems=PText.getString(IsItemOut, "RuleOfConvXSideA", "RuleOfConvXSideB");
  int count, temp, MaxOp, currcount;
  String Con=null;
  
  count=ConvRuleIds.length; if(count==0){return;}
  
  if(PCore.isArrayEmpty(Items, true)){Con="";}
  else{Con=" and Item in ("+PText.toString(Items, 0, Items.length, ",")+")";}
  
  temp=0; MaxOp=1000;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   
   Stm.executeUpdate("delete from "+TableItems+" where RuleOfConv in ("+PText.toString(ConvRuleIds, temp, currcount, ",")+")"+Con);
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static long convRuleAdd(Statement Stm, String LockId, OInfoConvertRule Data){
  long ret=-1;
  boolean error;
  VBoolean Started;
  VInteger LockStatus;
  long Id;
  
  error=true; Started=new VBoolean(false); LockStatus=new VInteger(-1);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    PDatabase.lockingTable_Start(Stm, LockId, CApp.TableGetLockTimeout, LockStatus); if(LockStatus.Value!=1){break;}
    Id=executeInsertConvRule(Stm, Data); if(Id==-1){break;}
    executeInsertConvRuleItems(Stm, true, false, PCore.primArr(Id), Data.ListItemA);
    executeInsertConvRuleItems(Stm, false, false, PCore.primArr(Id), Data.ListItemB);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=Id; error=false;
  }while(false);
  if(error){PDatabase.transactionRollback(Stm, Started);}
  PDatabase.lockingTable_End(Stm, LockId, LockStatus);
  
  return ret;
 }
 public static int convRuleEdit(Statement Stm,
  long[] ConvRuleIds, boolean FetchDataOld, OInfoConvertRule DataOld, OEditConvertRule Edit, OFormInformProgress Progress){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Id has already exist
  long Id=0;
  OInfoConvertRule InfoConvRule=null;
  boolean first, error;
  VBoolean started;
  StringBuilder col;
  int count, MaxList, curridx, currlistcount;
  String columns;
  
  long[] ids;
  boolean op_query;
  double progress_inc=0;
  int progress_inc_times;
  boolean IsCheckWithOldValue;
  
  do{
   count=ConvRuleIds.length; Id=ConvRuleIds[0]; op_query=false;
   
   if(count==1){
    InfoConvRule=DataOld; if(InfoConvRule==null && FetchDataOld){InfoConvRule=PMyShop.getConvertRuleInfo(Stm, Id, true, false);}
   }
   IsCheckWithOldValue=(count==1 && InfoConvRule!=null);

   col=new StringBuilder(); first=true;

   if(Edit.EditName){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubName){
     col.append("Name="+PText.getStringWithQuote(PSql.norm(Edit.EditedName), CCore.vNull, '\'', true));
    }
    else{
     col.append("Name=replace(Name, '"+PSql.norm(Edit.SubName)+"', '"+PSql.norm(Edit.EditedName)+"')");
    }
    op_query=true;
   }
   if(Edit.EditIsActive){
    if(first){first=false;}else{col.append(',');}
    col.append("IsActive="+PText.getString(Edit.EditedIsActive, CCore.vTrue, CCore.vFalse));
    op_query=true;
   }
   if(Edit.EditLastUpdate){
    if(first){first=false;}else{col.append(',');}
    col.append("LastUpdate="+PDatabase.dateToSQLStringFormat(Edit.EditedLastUpdate));
    op_query=true;
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)
   

   // update
   error=false; started=new VBoolean(false);
   do{
    try{
     PDatabase.transactionStart(Stm, started);
     
     // Edit Header
     MaxList=1000;
     
     if(Progress!=null){
      progress_inc_times=PMath.round((double)count/(double)MaxList, 1); if(progress_inc_times==0){progress_inc_times=1;}
      progress_inc=(double)100/(double)progress_inc_times;
     }
     
     curridx=0; columns=col.toString();
     do{
      currlistcount=MaxList; if(curridx+currlistcount>count){currlistcount=count-curridx;}
      ids=PCore.subArr(ConvRuleIds, curridx, currlistcount);

      if(op_query){
       Stm.executeUpdate("update RuleOfConv set "+columns+" where Id in("+PText.toString(ids, 0, ids.length, ",")+");");
      }

      if(Progress!=null){Progress.inform(progress_inc, null, null);}

      curridx=curridx+currlistcount;
     }while(curridx!=count);
     if(error){break;}

     // Edit List-Items
     if(Edit.EditComplete){
      executeDeleteConvRuleItems(Stm, true, PCore.primArr(Id), null); executeInsertConvRuleItems(Stm, true, false, PCore.primArr(Id), Edit.InfoConvertRule.ListItemA);
      executeDeleteConvRuleItems(Stm, false, PCore.primArr(Id), null); executeInsertConvRuleItems(Stm, false, false, PCore.primArr(Id), Edit.InfoConvertRule.ListItemB);
     }

     PDatabase.transactionCommit(Stm, started);
    }
    catch(Exception E){error=true; break;}
   }while(false);
   if(error){PDatabase.transactionRollback(Stm, started); break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 public static Object[] convRuleRemove(Statement Stm, String LockId, long[] ConvRuleIds, OFormInformProgress Progress){
  Object[] ret=null; // null = error, {int RemovedCount, boolean[] IsRemove} = success
  boolean[] IsRemoved;
  VInteger LockStatus;
  int temp, RemovedCount;
  boolean result;
  double progress_inc=0;
  
  RemovedCount=0; IsRemoved=PCore.newBooleanArray(ConvRuleIds.length, false); LockStatus=new VInteger(-1);
  if(Progress!=null){progress_inc=(double)100/(double)ConvRuleIds.length;}
  do{
   try{
    PDatabase.lockingTable_Start(Stm, LockId, CApp.TableGetLockTimeout, LockStatus);
    
    temp=0;
    do{
     result=executeDeleteConvRule(Stm, ConvRuleIds[temp]);
     if(result){
      RemovedCount=RemovedCount+1;
      IsRemoved[temp]=true;
     }
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+1;
    }while(temp!=ConvRuleIds.length);
   }
   catch(Exception E){break;}
   ret=PCore.objArrVariant(RemovedCount, IsRemoved);
  }while(false);
  PDatabase.lockingTable_End(Stm, LockId, LockStatus);
  
  return ret;
 }
 public static boolean convRuleAddItems(boolean IsItemOut, boolean IsAddUpdate, Statement Stm, long[] ConvRuleIds, Vector<Object[]> Items){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeInsertConvRuleItems(Stm, IsItemOut, IsAddUpdate, ConvRuleIds, Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convRuleEditItems(boolean IsItemOut, Statement Stm, long ConvRuleId, long[] Items, OEditConvertItem Edit){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeEditConvRuleItems(Stm, IsItemOut, ConvRuleId, Items, Edit);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convRuleDeleteItems(boolean IsItemOut, Statement Stm, long ConvRuleId, long[] Items){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeDeleteConvRuleItems(Stm, IsItemOut, PCore.primArr(ConvRuleId), Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convRuleMoveItems(boolean IsItemOut, Statement Stm, long ConvRuleId, long[] Items){
  boolean ret=false;
  VBoolean Started;
  Vector<Object[]> ListItems;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    ListItems=getConvertItems(Stm, true, IsItemOut, ConvRuleId, false, Items); if(ListItems==null){break;}
    executeInsertConvRuleItems(Stm, !IsItemOut, true, PCore.primArr(ConvRuleId), ListItems);
    executeDeleteConvRuleItems(Stm, IsItemOut, PCore.primArr(ConvRuleId), Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 public static long executeInsertConverting(Statement Stm, OInfoConverting InfoConverting, boolean Finalize) throws Exception{
  long Id=-1; // -1 error, >= 0 success
  Long result;
  
  do{
   result=PDatabase.generateNewId(null, Stm, "select Id from Conv order by Id asc"); if(result==null){break;}
   Stm.executeUpdate("insert into Conv (Id, ConvDate, ReasonOfConv, RuleOfConv, RuleOfConvDirection, RuleOfConvCount, IsFinalized) values ("+
    result+","+PDatabase.dateToSQLStringFormat(InfoConverting.ConvDate)+","+
    PText.getString(InfoConverting.ReasonOfConvId, CCore.vNull, -1, false)+","+
    InfoConverting.ConvRule.Id+","+PText.getString(InfoConverting.ConvRuleDirection, CCore.vTrue, CCore.vFalse)+","+
    PText.doubleToString(InfoConverting.ConvRuleCount, false)+","+PText.getString(Finalize, CCore.vTrue, CCore.vFalse)+")");
   Id=result;
  }while(false);
  
  return Id;
 }
 public static void executeDeleteConverting(boolean IsCanceling, Statement Stm, long[] ConvertingIds) throws Exception{
  int count, temp, MaxOp, currcount;
  long[] Ids;
  
  count=ConvertingIds.length; if(count==0){return;}
  temp=0; MaxOp=1000;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   Ids=PCore.subArr(ConvertingIds, temp, currcount);
   
   if(IsCanceling){
    executeCancelConvertingItems(Stm, true, Ids, null);
    executeCancelConvertingItems(Stm, false, Ids, null);
   }
   Stm.executeUpdate("delete from Conv where Id in ("+PText.toString(Ids, 0, Ids.length, ",")+")");
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static void executeInsertConvertingItems(Statement Stm, boolean IsItemOut, boolean IsAddUpdate, long[] ConvertingIds, Vector<Object[]> ListItems) throws Exception{
  String TableItems=PText.getString(IsItemOut, "ConvXItemOut", "ConvXItemIn");
  
  int temp, MaxInsert, itemcount, itemcurr, convcount, convcurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long ConvertingId;
  
  convcount=ConvertingIds.length;
  
  if(ListItems==null){return;}
  itemcount=ListItems.size(); if(itemcount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  convcurr=0;
  do{
   ConvertingId=ConvertingIds[convcurr];
   
   itemcurr=0;
   do{
    objs=ListItems.elementAt(itemcurr);
    
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+ConvertingId+","+PCore.objLong(objs[0], null)+","+PText.doubleToString(PCore.objDouble(objs[2], -1D), false)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (itemcurr==itemcount-1 && convcurr==convcount-1)){
     Stm.executeUpdate("insert into "+TableItems+" (Conv, Item, Stock) values "+strb.toString()+PText.getString(!IsAddUpdate, "", " on duplicate key update Stock=Stock+values(Stock)"));
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    itemcurr=itemcurr+1;
   }while(itemcurr!=itemcount);
  
   convcurr=convcurr+1;
  }while(convcurr!=convcount);
 }
 public static void executeInsertConvertingItem2(Statement Stm, boolean IsItemOut, boolean IsAddUpdate, long[] ConvertingIds, Vector<Object[]> Items) throws Exception{
  int convcount, convcurr, itemcount, itemcurr;
  long ConvertingId;
  Object[] Item;
  String Proc=PText.getString(IsItemOut, "ConvOutAdd", "ConvInAdd")+PText.getString(!IsAddUpdate, "", "Update");
  
  convcount=ConvertingIds.length;
  
  if(Items==null){return;}
  itemcount=Items.size(); if(itemcount==0){return;}
  
  convcurr=0;
  do{
   ConvertingId=ConvertingIds[convcurr];
   
   itemcurr=0;
   do{
    Item=Items.elementAt(itemcurr);
    
    Stm.executeUpdate("call "+Proc+"("+ConvertingId+","+PCore.objLong(Item[0], -1L)+","+PText.doubleToString(PCore.objDouble(Item[2], -1D), false)+")");
    
    itemcurr=itemcurr+1;
   }while(itemcurr!=itemcount);
   
   convcurr=convcurr+1;
  }while(convcurr!=convcount);
 }
 public static void executeEditConvertingItems(Statement Stm, boolean IsItemOut, long ConvertingId, long[] Items, OEditConvertItem Edit) throws Exception{
  String TableItems=PText.getString(IsItemOut, "ConvXItemOut", "ConvXItemIn");
  StringBuilder columns;
  boolean first;
  
  columns=new StringBuilder(); first=true;
  
  if(Edit.EditQuantity){
   if(first){first=false;}else{columns.append(',');}
   columns.append("Stock="+PText.doubleToString(Edit.EditedQuantity, false));
  }
  
  Stm.executeUpdate("update "+TableItems+" set "+columns+" where Conv="+ConvertingId+" and Item in ("+PText.toString(Items, 0, Items.length, ",")+")");
 }
 public static void executeCancelConvertingItems(Statement Stm, boolean IsItemOut, long[] ConvertingIds, long[] Items) throws Exception{
  String TableItems=PText.getString(IsItemOut, "ConvXItemOut", "ConvXItemIn");
  int count, temp, MaxOp, currcount;
  String Con=null;
  
  count=ConvertingIds.length; if(count==0){return;}
  
  if(PCore.isArrayEmpty(Items, true)){Con="";}
  else{Con=" and Item in ("+PText.toString(Items, 0, Items.length, ",")+")";}
  
  temp=0; MaxOp=1000;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   
   Stm.executeUpdate("delete from "+TableItems+" where Conv in ("+PText.toString(ConvertingIds, temp, currcount, ",")+")"+Con);
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static long convertingAdd(Statement Stm, String LockId, OInfoConverting Data){
  long ret=-1;
  boolean error;
  VBoolean Started;
  VInteger LockStatus;
  long Id;
  OInfoConvertRule ConvRule;
  
  error=true; Started=new VBoolean(false); LockStatus=new VInteger(-1);
  do{
   try{
    // Completing data of Converting
    ConvRule=getConvertRuleInfo(Stm, Data.ConvRule.Id, true, false); if(ConvRule==null){break;}
    Data.ConvRule.fillValuesFrom(ConvRule);
    Data.ListItemOut=Data.ConvRule.generateListItemsToConverting(true, Data.ConvRuleDirection, Data.ConvRuleCount);
    Data.ListItemIn=Data.ConvRule.generateListItemsToConverting(false, Data.ConvRuleDirection, Data.ConvRuleCount);
    
    // Start operation of Converting
    PDatabase.transactionStart(Stm, Started);
    PDatabase.lockingTable_Start(Stm, LockId, CApp.TableGetLockTimeout, LockStatus); if(LockStatus.Value!=1){break;}
    
    Id=executeInsertConverting(Stm, Data, false); if(Id==-1){break;}
    Stm.execute("call ConvInsert("+Id+")");
    /*
    executeInsertConvertingItems(Stm, true, false, PCore.primArr(Id), Data.ListItemOut);
    executeInsertConvertingItems(Stm, false, false, PCore.primArr(Id), Data.ListItemIn);
    */
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=Id; error=false;
  }while(false);
  if(error){PDatabase.transactionRollback(Stm, Started);}
  PDatabase.lockingTable_End(Stm, LockId, LockStatus);
  
  return ret;
 }
 private static boolean convertingReplaceItems(Statement Stm, long ConvertingId, OEditConverting Edit) throws Exception{
  boolean ret=false;
  OInfoConverting Conv;
  boolean ConvRuleDirection;
  double ConvRuleCount;
  
  do{
   // completing data of list items
   Conv=getConvertingInfo(Stm, ConvertingId, true, false); if(Conv==null){break;}
   ConvRuleDirection=(Boolean)PCore.subtituteBool(Edit.EditConvRuleDirection, Edit.EditedConvRuleDirection, Conv.ConvRuleDirection);
   ConvRuleCount=(Double)PCore.subtituteBool(Edit.EditConvRuleCount, Edit.EditedConvRuleCount, Conv.ConvRuleCount);
   
   Conv.ListItemOut=Conv.ConvRule.generateListItemsToConverting(true, ConvRuleDirection, ConvRuleCount);
   Conv.ListItemIn=Conv.ConvRule.generateListItemsToConverting(false, ConvRuleDirection, ConvRuleCount);
   
   // start operation of replacing
   executeCancelConvertingItems(Stm, true, PCore.primArr(ConvertingId), null); executeInsertConvertingItems(Stm, true, false, PCore.primArr(ConvertingId), Conv.ListItemOut);
   executeCancelConvertingItems(Stm, false, PCore.primArr(ConvertingId), null); executeInsertConvertingItems(Stm, false, false, PCore.primArr(ConvertingId), Conv.ListItemIn);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 private static boolean convertingReplaceItems(Statement Stm, long[] ConvertingIds, OEditConverting Edit) throws Exception{
  int temp;
  
  temp=0;
  do{
   if(!convertingReplaceItems(Stm, ConvertingIds[temp], Edit)){break;}
   temp=temp+1;
  }while(temp!=ConvertingIds.length);
  
  return temp==ConvertingIds.length;
 }
 public static int convertingEdit(Statement Stm,
  long[] ConvertingIds, boolean FetchDataOld, OInfoConverting DataOld, OEditConverting Edit, OFormInformProgress Progress){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Id has already exist
  long Id=0;
  OInfoConverting InfoConverting=null;
  boolean first, error;
  VBoolean started;
  StringBuilder col;
  int count, MaxList, curridx, currlistcount;
  String columns;
  
  long[] ids;
  boolean op_query, op_convrule;
  double progress_inc=0;
  int progress_inc_times;
  boolean IsCheckWithOldValue;
  
  do{
   count=ConvertingIds.length; Id=ConvertingIds[0]; op_query=false; op_convrule=false;
   
   if(count==1){
    InfoConverting=DataOld; if(InfoConverting==null && FetchDataOld){InfoConverting=PMyShop.getConvertingInfo(Stm, Id, true, false);}
   }
   IsCheckWithOldValue=(count==1 && InfoConverting!=null);

   col=new StringBuilder(); first=true;

   if(Edit.EditConvDate){
    if(first){first=false;}else{col.append(',');}
    col.append("ConvDate="+PDatabase.dateToSQLStringFormat(Edit.EditedConvDate));
    op_query=true;
   }
   if(Edit.EditReasonOfConv){
    if(first){first=false;}else{col.append(',');}
    col.append("ReasonOfConv="+PText.getString(Edit.EditedReasonOfConvId, CCore.vNull, -1, false));
    op_query=true;
   }
   if(Edit.EditConvRuleDirection){
    if(first){first=false;}else{col.append(',');}
    col.append("RuleOfConvDirection="+PText.getString(Edit.EditedConvRuleDirection, CCore.vTrue, CCore.vFalse));
    op_query=true; op_convrule=true;
   }
   if(Edit.EditConvRuleCount){
    if(first){first=false;}else{col.append(',');}
    col.append("RuleOfConvCount="+PText.doubleToString(Edit.EditedConvRuleCount, false));
    op_query=true; op_convrule=true;
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)
   

   // update
   error=false; started=new VBoolean(false);
   do{
    try{
     PDatabase.transactionStart(Stm, started);
     
     MaxList=1000;
     
     if(Progress!=null){
      progress_inc_times=PMath.round((double)count/(double)MaxList, 1); if(progress_inc_times==0){progress_inc_times=1;}
      progress_inc=(double)100/(double)progress_inc_times;
     }
     
     curridx=0; columns=col.toString();
     do{
      currlistcount=MaxList; if(curridx+currlistcount>count){currlistcount=count-curridx;}
      ids=PCore.subArr(ConvertingIds, curridx, currlistcount);
      
      if(op_convrule){
       if(!convertingReplaceItems(Stm, ids, Edit)){break;}
      }

      if(op_query){
       Stm.executeUpdate("update Conv set "+columns+" where Id in ("+PText.toString(ids, 0, ids.length, ",")+");");
      }

      if(Progress!=null){Progress.inform(progress_inc, null, null);}

      curridx=curridx+currlistcount;
     }while(curridx!=count);
     if(error){break;}

     PDatabase.transactionCommit(Stm, started);
    }
    catch(Exception E){error=true; break;}
   }while(false);
   if(error){PDatabase.transactionRollback(Stm, started); break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 public static boolean convertingRemove(boolean IsCanceling, Statement Stm, String LockId, long[] ConvertingIds, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  VInteger LockStatus;
  int temp, MaxOp, currcount, count;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false); LockStatus=new VInteger(-1);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    PDatabase.lockingTable_Start(Stm, LockId, CApp.TableGetLockTimeout, LockStatus);
    
    temp=0; MaxOp=1000; count=ConvertingIds.length;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(ConvertingIds, temp, currcount);
     
     executeDeleteConverting(IsCanceling, Stm, Ids);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}

     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  PDatabase.lockingTable_End(Stm, LockId, LockStatus);
  
  return ret;
 }
 public static boolean convertingAddItems(boolean IsItemOut, boolean IsAddUpdate, Statement Stm, long[] ConvertingIds, Vector<Object[]> Items){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeInsertConvertingItems(Stm, IsItemOut, IsAddUpdate, ConvertingIds, Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convertingAddItem2(boolean IsItemOut, boolean IsAddUpdate, Statement Stm, long[] ConvertingIds, Vector<Object[]> Items){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeInsertConvertingItem2(Stm, IsItemOut, IsAddUpdate, ConvertingIds, Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convertingEditItems(boolean IsItemOut, Statement Stm, long ConvertingId, long[] Items, OEditConvertItem Edit){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeEditConvertingItems(Stm, IsItemOut, ConvertingId, Items, Edit);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convertingCancelItems(boolean IsItemOut, Statement Stm, long ConvertingId, long[] Items){
  boolean ret=false;
  VBoolean Started;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    executeCancelConvertingItems(Stm, IsItemOut, PCore.primArr(ConvertingId), Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convertingMoveItems(boolean IsItemOut, Statement Stm, long ConvertingId, long[] Items){
  boolean ret=false;
  VBoolean Started;
  Vector<Object[]> ListItems;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    ListItems=getConvertItems(Stm, false, IsItemOut, ConvertingId, false, Items); if(ListItems==null){break;}
    executeInsertConvertingItems(Stm, !IsItemOut, true, PCore.primArr(ConvertingId), ListItems);
    executeCancelConvertingItems(Stm, IsItemOut, PCore.primArr(ConvertingId), Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean convertingMoveItems2(boolean IsItemOut, Statement Stm, long ConvertingId, long[] Items){
  boolean ret=false;
  VBoolean Started;
  Vector<Object[]> ListItems;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    ListItems=getConvertItems(Stm, false, IsItemOut, ConvertingId, false, Items); if(ListItems==null){break;}
    executeInsertConvertingItem2(Stm, !IsItemOut, true, PCore.primArr(ConvertingId), ListItems);
    executeCancelConvertingItems(Stm, IsItemOut, PCore.primArr(ConvertingId), Items);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 // Revisi Stock
 
 public static long[] executeInsertRev(Statement Stm, Vector<Object[]> Data) throws Exception{
  Vector<Long> ret=null;
  Vector<Long> rettemp=new Vector();
  Statement Stm3=null;
  ResultSet Rs3;
  boolean error;
  int temp, count, MaxOpLength, OpLength, OpCurr;
  long GeneratedId;
  Vector<Long> Enums;
  VInteger phase=new VInteger();
  VLong enumeration=new VLong();
  VLong DbId=new VLong();
  Object[] Objs;
  
  int RevReason;
  Date RevDate;
  long RevItem;
  double RevStockDiff;
  
  error=false;
  do{
   try{
    // preparing auto-generated-increment-id
    Stm3=Stm.getConnection().createStatement();
    Rs3=Stm3.executeQuery("select Id from RevisiStock order by Id asc;");
    PDatabase.genNewId_Normal_Preparing(phase, enumeration, DbId, Rs3);

    //
    temp=0; count=Data.size(); MaxOpLength=1000;
    do{
     OpLength=MaxOpLength; if(temp+OpLength>count){OpLength=count-temp;}

     Enums=PDatabase.genNewId_Normal_Generating(phase, enumeration, DbId, Rs3, OpLength);
     if(Enums.size()!=OpLength){error=true; break;}

     OpCurr=0;
     do{
      GeneratedId=Enums.elementAt(OpCurr);
      Objs=Data.elementAt(temp+OpCurr);

      RevDate=PCore.objDate(Objs[0], null);
      RevReason=PCore.objInteger(Objs[1], -1);
      RevItem=PCore.objLong(Objs[2], -1L);
      RevStockDiff=PCore.objDouble(Objs[5], 0D);

      Stm.executeUpdate("call RevAdd("+GeneratedId+","+
       PDatabase.getSQLString(RevDate, CCore.TypeDate, CCore.vNull, false)+","+
       PDatabase.getSQLString(RevReason, CCore.TypeInteger, CCore.vNull, true)+","+
       PDatabase.getSQLString(RevItem, CCore.TypeLong, CCore.vNull, false)+","+
       PDatabase.getSQLString(RevStockDiff, CCore.TypeDouble, CCore.vNull, false)+")");
      
      rettemp.addElement(GeneratedId);

      OpCurr=OpCurr+1;
     }while(OpCurr!=OpLength);
     if(error){break;}

     temp=temp+OpLength;
    }while(temp!=count);
    if(error){break;}
    
   }catch(Exception E){error=true; break;}
   ret=rettemp;
  }while(false);
  
  if(Stm3!=null){try{Stm3.close();}catch(Exception E){} Stm3=null;}
  
  return PCore.primArr_VectLong(ret);
 }
 
 public static long[] revAdd(Statement Stm, String LockId, Vector<Object[]> Data){
  long[] ret=null;
  long[] rettemp=null;
  boolean error;
  VBoolean Started;
  VInteger LockStatus;
  
  error=true; Started=new VBoolean(false); LockStatus=new VInteger(-1);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    PDatabase.lockingTable_Start(Stm, LockId, CApp.TableGetLockTimeout, LockStatus); if(LockStatus.Value!=1){break;}
    
    rettemp=executeInsertRev(Stm, Data); if(rettemp==null){break;}
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=rettemp; error=false;
  }while(false);
  if(error){PDatabase.transactionRollback(Stm, Started);}
  PDatabase.lockingTable_End(Stm, LockId, LockStatus);
  
  return ret;
 }
 
 // Item Supplier
 
 /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
 public static void executeInsertItemSupp(Statement Stm, boolean StmIgnore, boolean ByItem, long[] MainIds, Vector<Object[]> Data) throws Exception{
  int temp, MaxInsert, datacount, datacurr, maincount, maincurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long MainId;
  String ColMainId, ColCompId;
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  ColMainId=PText.getString(ByItem, "Item", "Supplier");
  ColCompId=PText.getString(ByItem, "Supplier", "Item");
  
  maincount=MainIds.length;
  
  datacount=0; if(Data!=null){datacount=Data.size();}
  if(datacount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  maincurr=0;
  do{
   MainId=MainIds[maincurr];
   
   datacurr=0;
   do{
    objs=Data.elementAt(datacurr);
    
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+MainId+","+PCore.objLong(objs[0], null)+","+
     PDatabase.getSQLString(PCore.objDouble(objs[2], 0D), CCore.TypeDouble, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[3], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objDate(objs[4], null), CCore.TypeDate, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objBoolean(objs[5], true), CCore.TypeBoolean, CCore.vNull, true)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (datacurr==datacount-1 && maincurr==maincount-1)){
     Stm.executeUpdate("insert"+PText.getString(StmIgnore, " ignore", "")+
      " into ItemXSupplier ("+ColMainId+", "+ColCompId+", BuyPrice, BuyPriceComment, UpdateDate, IsActive) values "+strb.toString());
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    datacurr=datacurr+1;
   }while(datacurr!=datacount);
  
   maincurr=maincurr+1;
  }while(maincurr!=maincount);
 }
 public static void executeEditItemSupp(Statement Stm, boolean ByItem, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   long[] ByIndependent_CompIds,
  OEditItemSupplier Edit) throws Exception{
  String columns;
  int temp, count, currcount, MaxOp;
  long[] Ids;
  int lookupcurr, lookupcount;
  boolean ByStrictOneByOne;
  VBoolean WithTableInfo=new VBoolean();
  String TableInfo;
  String ColMainId, ColCompId;
  
  ColMainId=PText.getString(ByItem, "Item", "Supplier");
  ColCompId=PText.getString(ByItem, "Supplier", "Item");
  
  MaxOp=1000;
  count=MainIds.length;
  
  ByStrictOneByOne=
   (Edit.EditBuyPrc && Edit.EditBuyPrcMode==3) || (Edit.EditBuyComment && Edit.EditBuyCommentMode==3) ||
   (Edit.EditBuyUpdate && Edit.EditBuyUpdateMode==3) || (Edit.EditIsActive && Edit.EditIsActiveMode==3);
  
  if(!ByStrictOneByOne){
   columns=executeEditItemSupp_Columns(ByItem, MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, false, -1, WithTableInfo);

   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    TableInfo="";
    if(WithTableInfo.Value){
     TableInfo=
      " inner join "+
      "("+getItemSupp_Query(ByItem, Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds, false, true)+") as info_itemsupp"+
      " on ("+
       "ItemXSupplier."+ColMainId+"=info_itemsupp."+ColMainId+"Id and "+
       "ifnull(ItemXSupplier."+ColCompId+",-1)=ifnull(info_itemsupp."+ColCompId+"Id,-1)"+
      ")";
    }
    
    Stm.executeUpdate("update ItemXSupplier"+TableInfo+" set "+columns+
     getItemSupp_Query_Condition(ByItem, Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
    
    temp=temp+currcount;
   }while(temp!=count);
  }
  else{
   lookupcount=ByStrict_Data.size();
   
   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    lookupcurr=0;
    do{
     columns=executeEditItemSupp_Columns(ByItem, MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, true, lookupcurr, WithTableInfo);

     TableInfo="";
     if(WithTableInfo.Value){
      TableInfo=
       " inner join "+
       "("+getItemSupp_Query(ByItem, Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_CompIds, false, true)+") as info_itemsupp"+
       " on ("+
        "ItemXSupplier."+ColMainId+"=info_itemsupp."+ColMainId+"Id and "+
        "ifnull(ItemXSupplier."+ColCompId+",-1)=ifnull(info_itemsupp."+ColCompId+"Id,-1)"+
       ")";
     }

     Stm.executeUpdate("update ItemXSupplier"+TableInfo+" set "+columns+
      getItemSupp_Query_Condition(ByItem, Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_CompIds));

     lookupcurr=lookupcurr+1;
    }while(lookupcurr!=lookupcount);
    
    temp=temp+currcount;
   }while(temp!=count);
  }
 }
 private static String executeEditItemSupp_Columns(
  
  boolean ByItem, long[] MainIds,
  
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   long[] ByIndependent_CompIds,
  OEditItemSupplier Edit,
  
  boolean ByStrictOneByOne, int lookupcurr,
  VBoolean WithTableInfo){
  
  StringBuilder columns;
  boolean first;
  Object[] ConByStrict_AData=null;
  String str=null;
  
  String ColMainId, ColCompId;

  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  ColMainId=PText.getString(ByItem, "Item", "Supplier");
  ColCompId=PText.getString(ByItem, "Supplier", "Item");
  
  WithTableInfo.Value=false;
  columns=new StringBuilder(); first=true;
  
  if(ByStrictOneByOne){ConByStrict_AData=ByStrict_Data.elementAt(lookupcurr);}

  if(Edit.EditComp){
   if(first){first=false;}else{columns.append(',');}
   str=PDatabase.getSQLString(Edit.EditedCompId, CCore.TypeLong, CCore.vNull, true);
   columns.append(ColCompId+"="+str);
  }
  if(Edit.EditBuyPrc){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditBuyPrcMode){
    case 0 : str=PText.doubleToString(Edit.EditedBuyPrc, false); break;
    case 3 : str=PText.doubleToString(PCore.objDouble(ConByStrict_AData[2], 0D), false); break;
   }
   columns.append("BuyPrice="+str);
  }
  if(Edit.EditBuyComment){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditBuyCommentSub){
    switch(Edit.EditBuyCommentMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedBuyComment), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[3], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(BuyPriceComment, '"+PSql.norm(Edit.EditedBuyCommentSub)+"', '"+PSql.norm(Edit.EditedBuyComment)+"')";
   }
   columns.append("BuyPriceComment="+str);
  }
  if(Edit.EditBuyUpdate){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditBuyUpdateMode){
    case 0 : str=PDatabase.dateToSQLStringFormat(Edit.EditedBuyUpdate); break;
    case 3 : str=PDatabase.dateToSQLStringFormat(PCore.objDate(ConByStrict_AData[4], null)); break;
   }
   columns.append("UpdateDate="+str);
  }
  if(Edit.EditIsActive){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditIsActiveMode){
    case 0 : str=PDatabase.getSQLString(Edit.EditedIsActive, CCore.TypeBoolean, CCore.vNull, true); break;
    case 3 : str=PDatabase.getSQLString(PCore.objBoolean(ConByStrict_AData[5], true), CCore.TypeBoolean, CCore.vNull, true); break;
   }
   columns.append("IsActive="+str);
  }
  
  return columns.toString();
 }
 public static void executeDeleteItemSupp(Statement Stm, boolean StmIgnore, boolean ByItem, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   long[] ByIndependent_CompIds) throws Exception{
  int temp, count, currcount, MaxOp;
  long[] Ids;
  
  MaxOp=1000;
  
  count=MainIds.length;
  
  temp=0;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   Ids=PCore.subArr(MainIds, temp, currcount);
   
   Stm.executeUpdate("delete"+PText.getString(StmIgnore, " ignore", "")+" from ItemXSupplier"+
    getItemSupp_Query_Condition(ByItem, Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static boolean itemSuppAdd(Statement Stm, boolean StmIgnore, boolean ByItem, long[] MainIds, Vector<Object[]> Data, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeInsertItemSupp(Stm, StmIgnore, ByItem, Ids, Data);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean itemSuppEdit(Statement Stm, boolean ByItem,
  long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   long[] ByIndependent_CompIds,
  OEditItemSupplier Edit, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeEditItemSupp(Stm, ByItem, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean itemSuppRemove(Statement Stm, boolean StmIgnore, boolean ByItem, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   long[] ByIndependent_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeDeleteItemSupp(Stm, StmIgnore, ByItem, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 // Item Variant
 
 /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
 public static void executeInsertItemVart(Statement Stm, boolean StmIgnore, long[] Items, Vector<Object[]> Data) throws Exception{
  int temp, MaxInsert, datacount, datacurr, maincount, maincurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long ItemId;
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  maincount=Items.length;
  
  datacount=0; if(Data!=null){datacount=Data.size();}
  if(datacount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  maincurr=0;
  do{
   ItemId=Items[maincurr];
   
   datacurr=0;
   do{
    objs=Data.elementAt(datacurr);
    
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+ItemId+","+PDatabase.getSQLString(PCore.objString(objs[0], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objBoolean(objs[1], true), CCore.TypeBoolean, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objDouble(objs[2], 0D), CCore.TypeDouble, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[3], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objDate(objs[4], null), CCore.TypeDate, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[5], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[6], null), CCore.TypeString, CCore.vNull, true)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (datacurr==datacount-1 && maincurr==maincount-1)){
     Stm.executeUpdate("insert"+PText.getString(StmIgnore, " ignore", "")+
      " into ItemXVariant (Item, Variant, IsActive, BuyPrice, BuyPriceComment, BuyUpdate, Comment, PictureFile) values "+strb.toString());
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    datacurr=datacurr+1;
   }while(datacurr!=datacount);
  
   maincurr=maincurr+1;
  }while(maincurr!=maincount);
 }
 public static void executeEditItemVart(Statement Stm, long[] Items,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   String[] ByIndependent_VariantIds,
  OEditItemVariant Edit) throws Exception{
  String columns;
  int temp, count, currcount, MaxOp;
  long[] Ids;
  int lookupcurr, lookupcount;
  boolean ByStrictOneByOne;
  VBoolean WithTableInfo=new VBoolean();
  String TableInfo;
  
  MaxOp=1000;
  count=Items.length;
  
  ByStrictOneByOne=
   (Edit.EditVariant && Edit.EditVariantMode==3) || (Edit.EditIsActive && Edit.EditIsActiveMode==3) ||
   (Edit.EditBuyPrice && Edit.EditBuyPriceMode==3) || (Edit.EditBuyComment && Edit.EditBuyCommentMode==3) ||
   (Edit.EditBuyUpdate && Edit.EditBuyUpdateMode==3) || (Edit.EditComment && Edit.EditCommentMode==3) ||
   (Edit.EditPictureFile && Edit.EditPictureFileMode==3);
  
  if(!ByStrictOneByOne){
   columns=executeEditItemVart_Columns(Items, ByStrict, ByStrict_Data, ByIndependent_VariantIds, Edit, false, -1, WithTableInfo);

   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(Items, temp, currcount);
    
    TableInfo="";
    if(WithTableInfo.Value){
     TableInfo=
      " inner join "+
      "("+getItemVart_Query(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_VariantIds, true)+") as info_itemvariant"+
      " on ("+
       "ItemXVariant.Item=info_itemvariant.ItemId and "+
       "ifnull(ItemXVariant.Variant,-1)=ifnull(info_itemvariant.Variant,-1)"+
      ")";
    }
    
    Stm.executeUpdate("update ItemXVariant"+TableInfo+" set "+columns+
     getItemVart_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_VariantIds));
    
    temp=temp+currcount;
   }while(temp!=count);
  }
  else{
   lookupcount=ByStrict_Data.size();
   
   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(Items, temp, currcount);
    
    lookupcurr=0;
    do{
     columns=executeEditItemVart_Columns(Items, ByStrict, ByStrict_Data, ByIndependent_VariantIds, Edit, true, lookupcurr, WithTableInfo);

     TableInfo="";
     if(WithTableInfo.Value){
      TableInfo=
       " inner join "+
       "("+getItemVart_Query(Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_VariantIds, true)+") as info_itemvariant"+
       " on ("+
        "ItemXVariant.Item=info_itemvariant.ItemId and "+
        "ifnull(ItemVariant.Variant,-1)=ifnull(info_itemvariant.Variant,-1)"+
       ")";
     }

     Stm.executeUpdate("update ItemXVariant"+TableInfo+" set "+columns+
      getItemVart_Query_Condition(Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_VariantIds));

     lookupcurr=lookupcurr+1;
    }while(lookupcurr!=lookupcount);
    
    temp=temp+currcount;
   }while(temp!=count);
  }
 }
 private static String executeEditItemVart_Columns(
  
  long[] Items,
  
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   String[] ByIndependent_VariantIds,
  OEditItemVariant Edit,
  
  boolean ByStrictOneByOne, int lookupcurr,
  VBoolean WithTableInfo){
  
  StringBuilder columns;
  boolean first;
  Object[] ConByStrict_AData=null;
  String str=null;

  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
     
  WithTableInfo.Value=false;
  columns=new StringBuilder(); first=true;
  
  if(ByStrictOneByOne){ConByStrict_AData=ByStrict_Data.elementAt(lookupcurr);}

  if(Edit.EditVariant){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditVariantSub){
    switch(Edit.EditVariantMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedVariant), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[0], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Variant, '"+PSql.norm(Edit.EditedVariantSub)+"', '"+PSql.norm(Edit.EditedVariant)+"')";
   }
   columns.append("Variant="+str);
  }
  if(Edit.EditIsActive){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditIsActiveMode){
    case 0 : str=PDatabase.getSQLString(Edit.EditedIsActive, CCore.TypeBoolean, CCore.vNull, true); break;
    case 3 : str=PDatabase.getSQLString(PCore.objBoolean(ConByStrict_AData[1], true), CCore.TypeBoolean, CCore.vNull, true); break;
   }
   columns.append("IsActive="+str);
  }
  if(Edit.EditBuyPrice){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditBuyPriceMode){
    case 0 : str=PText.doubleToString(Edit.EditedBuyPrice, false); break;
    case 3 : str=PText.doubleToString(PCore.objDouble(ConByStrict_AData[2], 0D), false); break;
   }
   columns.append("BuyPrice="+str);
  }
  if(Edit.EditBuyComment){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditBuyCommentSub){
    switch(Edit.EditBuyCommentMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedBuyComment), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[3], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(BuyPriceComment, '"+PSql.norm(Edit.EditedBuyCommentSub)+"', '"+PSql.norm(Edit.EditedBuyComment)+"')";
   }
   columns.append("BuyPriceComment="+str);
  }
  if(Edit.EditBuyUpdate){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditBuyUpdateMode){
    case 0 : str=PDatabase.dateToSQLStringFormat(Edit.EditedBuyUpdate); break;
    case 3 : str=PDatabase.dateToSQLStringFormat(PCore.objDate(ConByStrict_AData[4], null)); break;
   }
   columns.append("BuyUpdate="+str);
  }
  if(Edit.EditComment){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditCommentSub){
    switch(Edit.EditCommentMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[5], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Comment, '"+PSql.norm(Edit.EditedCommentSub)+"', '"+PSql.norm(Edit.EditedComment)+"')";
   }
   columns.append("Comment="+str);
  }
  if(Edit.EditPictureFile){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditPictureFileMode){
    case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedPictureFile), CCore.vNull, '\'', true); break;
    case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[6], null), CCore.TypeString, CCore.vNull, true); break;
   }
   columns.append("PictureFile="+str);
  }
  
  return columns.toString();
 }
 public static void executeDeleteItemVart(Statement Stm, boolean StmIgnore, long[] Items,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   String[] ByIndependent_VariantIds) throws Exception{
  int temp, count, currcount, MaxOp;
  long[] Ids;
  
  MaxOp=1000;
  
  count=Items.length;
  
  temp=0;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   Ids=PCore.subArr(Items, temp, currcount);
   
   Stm.executeUpdate("delete"+PText.getString(StmIgnore, " ignore", "")+" from ItemXVariant"+
    getItemVart_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_VariantIds));
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static boolean itemVartAdd(Statement Stm, boolean StmIgnore, long[] Items, Vector<Object[]> Data, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=Items.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(Items, temp, currcount);
     
     executeInsertItemVart(Stm, StmIgnore, Ids, Data);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean itemVartEdit(Statement Stm,
  long[] Items,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   String[] ByIndependent_VariantIds,
  OEditItemVariant Edit, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=Items.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(Items, temp, currcount);
     
     executeEditItemVart(Stm, Ids, ByStrict, ByStrict_Data, ByIndependent_VariantIds, Edit);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean itemVartRemove(Statement Stm, boolean StmIgnore, long[] Items,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   String[] ByIndependent_VariantIds,
  OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=Items.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(Items, temp, currcount);
     
     executeDeleteItemVart(Stm, StmIgnore, Ids, ByStrict, ByStrict_Data, ByIndependent_VariantIds);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 // Subject Address
 
 /* "enumeration", "city_id", "city_name", "address", "comment" */
 public static void executeInsertSubjectAddr(Statement Stm, boolean StmIgnore, long[] MainIds, Vector<Object[]> Data) throws Exception{
  int temp, MaxInsert, datacount, datacurr, maincount, maincurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long MainId;
  String ColMainId, ColCompId;
  Long Enumeration;
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  maincount=1;
  
  datacount=0; if(Data!=null){datacount=Data.size();}
  if(datacount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  maincurr=0;
  do{
   MainId=MainIds[maincurr];
   
   datacurr=0;
   do{
    objs=Data.elementAt(datacurr);
    
    // create a new enumeration
    Enumeration=PDatabase.generateNewId(null, Stm,
     "select "+ColCompId+" from SubjectXAddress where "+ColMainId+"="+MainId+" order by "+ColCompId+" asc;");
    if(Enumeration==null){throw new Exception();}
    
    objs[0]=PCore.objNumberInteger(CCore.TypeLong, Enumeration, null);
    
    //
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+MainId+","+PCore.objInteger(objs[0], null)+","+
     PDatabase.getSQLString(PCore.objInteger(objs[1], null), CCore.TypeInteger, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[3], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[4], null), CCore.TypeString, CCore.vNull, true)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (datacurr==datacount-1 && maincurr==maincount-1)){
     Stm.executeUpdate("insert"+PText.getString(StmIgnore, " ignore", "")+
      " into SubjectXAddress ("+ColMainId+", "+ColCompId+", City, Address, Comment) values "+strb.toString());
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    datacurr=datacurr+1;
   }while(datacurr!=datacount);
  
   maincurr=maincurr+1;
  }while(maincurr!=maincount);
 }
 public static void executeEditSubjectAddr(Statement Stm, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectAddress Edit) throws Exception{
  String columns;
  int temp, count, currcount, MaxOp;
  long[] Ids;
  int lookupcurr, lookupcount;
  boolean ByStrictOneByOne;
  VBoolean WithTableInfo=new VBoolean();
  String TableInfo;
  String ColMainId, ColCompId;
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  MaxOp=1000;
  count=MainIds.length;
  
  ByStrictOneByOne=
   (Edit.EditCity && Edit.EditCityMode==3) || (Edit.EditAddr && Edit.EditAddrMode==3) || (Edit.EditComment && Edit.EditCommentMode==3);
  
  if(!ByStrictOneByOne){
   columns=executeEditSubjectAddr_Columns(MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, false, -1, WithTableInfo);

   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    TableInfo="";
    if(WithTableInfo.Value){}
    
    Stm.executeUpdate("update SubjectXAddress"+TableInfo+" set "+columns+
     getSubjectAddr_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
    
    temp=temp+currcount;
   }while(temp!=count);
  }
  else{
   lookupcount=ByStrict_Data.size();
   
   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    lookupcurr=0;
    do{
     columns=executeEditSubjectAddr_Columns(MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, true, lookupcurr, WithTableInfo);

     TableInfo="";
     if(WithTableInfo.Value){}

     Stm.executeUpdate("update SubjectXAddress"+TableInfo+" set "+columns+
      getSubjectAddr_Query_Condition(Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_CompIds));

     lookupcurr=lookupcurr+1;
    }while(lookupcurr!=lookupcount);
    
    temp=temp+currcount;
   }while(temp!=count);
  }
 }
 private static String executeEditSubjectAddr_Columns(
  
  long[] MainIds,
  
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectAddress Edit,
  
  boolean ByStrictOneByOne, int lookupcurr,
  VBoolean WithTableInfo){
  
  StringBuilder columns;
  boolean first;
  Object[] ConByStrict_AData=null;
  String str=null;
  
  String ColMainId, ColCompId;

  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  WithTableInfo.Value=false;
  columns=new StringBuilder(); first=true;
  
  if(ByStrictOneByOne){ConByStrict_AData=ByStrict_Data.elementAt(lookupcurr);}

  if(Edit.EditCity){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditCityMode){
    case 0 : str=PDatabase.getSQLString(Edit.EditedCityId, CCore.TypeInteger, CCore.vNull, true); break;
    case 3 : str=PDatabase.getSQLString(PCore.objInteger(ConByStrict_AData[1], null), CCore.TypeInteger, CCore.vNull, true); break;
   }
   columns.append("City="+str);
  }
  if(Edit.EditAddr){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditAddrSub){
    switch(Edit.EditAddrMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedAddr), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[3], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Address, '"+PSql.norm(Edit.EditedAddrSub)+"', '"+PSql.norm(Edit.EditedAddr)+"')";
   }
   columns.append("Address="+str);
  }
  if(Edit.EditComment){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditCommentSub){
    switch(Edit.EditCommentMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[4], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Comment, '"+PSql.norm(Edit.EditedCommentSub)+"', '"+PSql.norm(Edit.EditedComment)+"')";
   }
   columns.append("Comment="+str);
  }
  
  return columns.toString();
 }
 public static void executeDeleteSubjectAddr(Statement Stm, boolean StmIgnore, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds) throws Exception{
  int temp, count, currcount, MaxOp;
  long[] Ids;
  
  MaxOp=1000;
  
  count=MainIds.length;
  
  temp=0;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   Ids=PCore.subArr(MainIds, temp, currcount);
   
   Stm.executeUpdate("delete"+PText.getString(StmIgnore, " ignore", "")+" from SubjectXAddress"+
    getSubjectAddr_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static boolean subjectAddrAdd(Statement Stm, boolean StmIgnore, long[] MainIds, Vector<Object[]> Data, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeInsertSubjectAddr(Stm, StmIgnore, Ids, Data);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean subjectAddrEdit(Statement Stm,
  long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectAddress Edit, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeEditSubjectAddr(Stm, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean subjectAddrRemove(Statement Stm, boolean StmIgnore, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeDeleteSubjectAddr(Stm, StmIgnore, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 // Subject Contact
 
 /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
 public static void executeInsertSubjectCont(Statement Stm, boolean StmIgnore, long[] MainIds, Vector<Object[]> Data) throws Exception{
  int temp, MaxInsert, datacount, datacurr, maincount, maincurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long MainId;
  String ColMainId, ColCompId;
  Long Enumeration;
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  maincount=1;
  
  datacount=0; if(Data!=null){datacount=Data.size();}
  if(datacount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  maincurr=0;
  do{
   MainId=MainIds[maincurr];
   
   datacurr=0;
   do{
    objs=Data.elementAt(datacurr);
    
    // create a new enumeration
    Enumeration=PDatabase.generateNewId(null, Stm,
     "select "+ColCompId+" from SubjectXContact where "+ColMainId+"="+MainId+" order by "+ColCompId+" asc;");
    if(Enumeration==null){throw new Exception();}
    
    objs[0]=PCore.objNumberInteger(CCore.TypeLong, Enumeration, null);
    
    //
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+MainId+","+PCore.objInteger(objs[0], null)+","+
     PDatabase.getSQLString(PCore.objInteger(objs[1], null), CCore.TypeInteger, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[3], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[4], null), CCore.TypeString, CCore.vNull, true)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (datacurr==datacount-1 && maincurr==maincount-1)){
     Stm.executeUpdate("insert"+PText.getString(StmIgnore, " ignore", "")+
      " into SubjectXContact ("+ColMainId+", "+ColCompId+", ContactType, Contact, Comment) values "+strb.toString());
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    datacurr=datacurr+1;
   }while(datacurr!=datacount);
  
   maincurr=maincurr+1;
  }while(maincurr!=maincount);
 }
 public static void executeEditSubjectCont(Statement Stm, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectContact Edit) throws Exception{
  String columns;
  int temp, count, currcount, MaxOp;
  long[] Ids;
  int lookupcurr, lookupcount;
  boolean ByStrictOneByOne;
  VBoolean WithTableInfo=new VBoolean();
  String TableInfo;
  String ColMainId, ColCompId;
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  MaxOp=1000;
  count=MainIds.length;
  
  ByStrictOneByOne=
   (Edit.EditContactType && Edit.EditContactTypeMode==3) || (Edit.EditCont && Edit.EditContMode==3) || (Edit.EditComment && Edit.EditCommentMode==3);
  
  if(!ByStrictOneByOne){
   columns=executeEditSubjectCont_Columns(MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, false, -1, WithTableInfo);

   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    TableInfo="";
    if(WithTableInfo.Value){}
    
    Stm.executeUpdate("update SubjectXContact"+TableInfo+" set "+columns+
     getSubjectCont_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
    
    temp=temp+currcount;
   }while(temp!=count);
  }
  else{
   lookupcount=ByStrict_Data.size();
   
   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    lookupcurr=0;
    do{
     columns=executeEditSubjectCont_Columns(MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, true, lookupcurr, WithTableInfo);

     TableInfo="";
     if(WithTableInfo.Value){}

     Stm.executeUpdate("update SubjectXContact"+TableInfo+" set "+columns+
      getSubjectCont_Query_Condition(Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_CompIds));

     lookupcurr=lookupcurr+1;
    }while(lookupcurr!=lookupcount);
    
    temp=temp+currcount;
   }while(temp!=count);
  }
 }
 private static String executeEditSubjectCont_Columns(
  
  long[] MainIds,
  
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectContact Edit,
  
  boolean ByStrictOneByOne, int lookupcurr,
  VBoolean WithTableInfo){
  
  StringBuilder columns;
  boolean first;
  Object[] ConByStrict_AData=null;
  String str=null;
  
  String ColMainId, ColCompId;

  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  WithTableInfo.Value=false;
  columns=new StringBuilder(); first=true;
  
  if(ByStrictOneByOne){ConByStrict_AData=ByStrict_Data.elementAt(lookupcurr);}

  if(Edit.EditContactType){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditContactTypeMode){
    case 0 : str=PDatabase.getSQLString(Edit.EditedContactTypeId, CCore.TypeInteger, CCore.vNull, true); break;
    case 3 : str=PDatabase.getSQLString(PCore.objInteger(ConByStrict_AData[1], null), CCore.TypeInteger, CCore.vNull, true); break;
   }
   columns.append("ContactType="+str);
  }
  if(Edit.EditCont){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditContSub){
    switch(Edit.EditContMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedCont), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[3], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Contact, '"+PSql.norm(Edit.EditedContSub)+"', '"+PSql.norm(Edit.EditedCont)+"')";
   }
   columns.append("Contact="+str);
  }
  if(Edit.EditComment){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditCommentSub){
    switch(Edit.EditCommentMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[4], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Comment, '"+PSql.norm(Edit.EditedCommentSub)+"', '"+PSql.norm(Edit.EditedComment)+"')";
   }
   columns.append("Comment="+str);
  }
  
  return columns.toString();
 }
 public static void executeDeleteSubjectCont(Statement Stm, boolean StmIgnore, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds) throws Exception{
  int temp, count, currcount, MaxOp;
  long[] Ids;
  
  MaxOp=1000;
  
  count=MainIds.length;
  
  temp=0;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   Ids=PCore.subArr(MainIds, temp, currcount);
   
   Stm.executeUpdate("delete"+PText.getString(StmIgnore, " ignore", "")+" from SubjectXContact"+
    getSubjectCont_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static boolean subjectContAdd(Statement Stm, boolean StmIgnore, long[] MainIds, Vector<Object[]> Data, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeInsertSubjectCont(Stm, StmIgnore, Ids, Data);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean subjectContEdit(Statement Stm,
  long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectContact Edit, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeEditSubjectCont(Stm, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean subjectContRemove(Statement Stm, boolean StmIgnore, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeDeleteSubjectCont(Stm, StmIgnore, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 // Subject Bank Account
 
 /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
 public static void executeInsertSubjectAcc(Statement Stm, boolean StmIgnore, long[] MainIds, Vector<Object[]> Data) throws Exception{
  int temp, MaxInsert, datacount, datacurr, maincount, maincurr;
  StringBuilder strb;
  boolean first;
  Object[] objs;
  long MainId;
  String ColMainId, ColCompId;
  Long Enumeration;
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  maincount=1;
  
  datacount=0; if(Data!=null){datacount=Data.size();}
  if(datacount==0){return;}
  
  MaxInsert=1000;
  temp=0; strb=new StringBuilder(); first=true;
  
  maincurr=0;
  do{
   MainId=MainIds[maincurr];
   
   datacurr=0;
   do{
    objs=Data.elementAt(datacurr);
    
    // create a new enumeration
    Enumeration=PDatabase.generateNewId(null, Stm,
     "select "+ColCompId+" from SubjectXBankAccount where "+ColMainId+"="+MainId+" order by "+ColCompId+" asc;");
    if(Enumeration==null){throw new Exception();}
    
    objs[0]=PCore.objNumberInteger(CCore.TypeLong, Enumeration, null);
    
    //
    if(first){first=false;}else{strb.append(",");}
    strb.append("("+MainId+","+PCore.objInteger(objs[0], null)+","+
     PDatabase.getSQLString(PCore.objInteger(objs[1], null), CCore.TypeInteger, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[3], null), CCore.TypeString, CCore.vNull, true)+","+
     PDatabase.getSQLString(PCore.objString(objs[4], null), CCore.TypeString, CCore.vNull, true)+")");
    temp=temp+1;
    
    if(temp==MaxInsert || (datacurr==datacount-1 && maincurr==maincount-1)){
     Stm.executeUpdate("insert"+PText.getString(StmIgnore, " ignore", "")+
      " into SubjectXBankAccount ("+ColMainId+", "+ColCompId+", BankPlatform, BankAccount, Comment) values "+strb.toString());
     
     temp=0; strb=new StringBuilder(); first=true;
    }
    
    datacurr=datacurr+1;
   }while(datacurr!=datacount);
  
   maincurr=maincurr+1;
  }while(maincurr!=maincount);
 }
 public static void executeEditSubjectAcc(Statement Stm, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectBankAccount Edit) throws Exception{
  String columns;
  int temp, count, currcount, MaxOp;
  long[] Ids;
  int lookupcurr, lookupcount;
  boolean ByStrictOneByOne;
  VBoolean WithTableInfo=new VBoolean();
  String TableInfo;
  String ColMainId, ColCompId;
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  MaxOp=1000;
  count=MainIds.length;
  
  ByStrictOneByOne=
   (Edit.EditBankPlatform && Edit.EditBankPlatformMode==3) || (Edit.EditAcc && Edit.EditAccMode==3) || (Edit.EditComment && Edit.EditCommentMode==3);
  
  if(!ByStrictOneByOne){
   columns=executeEditSubjectAcc_Columns(MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, false, -1, WithTableInfo);

   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    TableInfo="";
    if(WithTableInfo.Value){}
    
    Stm.executeUpdate("update SubjectXBankAccount"+TableInfo+" set "+columns+
     getSubjectAcc_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
    
    temp=temp+currcount;
   }while(temp!=count);
  }
  else{
   lookupcount=ByStrict_Data.size();
   
   temp=0;
   do{
    currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
    Ids=PCore.subArr(MainIds, temp, currcount);
    
    lookupcurr=0;
    do{
     columns=executeEditSubjectAcc_Columns(MainIds, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit, true, lookupcurr, WithTableInfo);

     TableInfo="";
     if(WithTableInfo.Value){}
     
     Stm.executeUpdate("update SubjectXBankAccount"+TableInfo+" set "+columns+
      getSubjectAcc_Query_Condition(Ids, ByStrict, ByStrict_Data, true, lookupcurr, ByIndependent_CompIds));

     lookupcurr=lookupcurr+1;
    }while(lookupcurr!=lookupcount);
    
    temp=temp+currcount;
   }while(temp!=count);
  }
 }
 private static String executeEditSubjectAcc_Columns(
  
  long[] MainIds,
  
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectBankAccount Edit,
  
  boolean ByStrictOneByOne, int lookupcurr,
  VBoolean WithTableInfo){
  
  StringBuilder columns;
  boolean first;
  Object[] ConByStrict_AData=null;
  String str=null;
  
  String ColMainId, ColCompId;

  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  ColMainId="Subject";
  ColCompId="Enumeration";
  
  WithTableInfo.Value=false;
  columns=new StringBuilder(); first=true;
  
  if(ByStrictOneByOne){ConByStrict_AData=ByStrict_Data.elementAt(lookupcurr);}

  if(Edit.EditBankPlatform){
   if(first){first=false;}else{columns.append(',');}
   switch(Edit.EditBankPlatformMode){
    case 0 : str=PDatabase.getSQLString(Edit.EditedBankPlatformId, CCore.TypeInteger, CCore.vNull, true); break;
    case 3 : str=PDatabase.getSQLString(PCore.objInteger(ConByStrict_AData[1], null), CCore.TypeInteger, CCore.vNull, true); break;
   }
   columns.append("BankPlatform="+str);
  }
  if(Edit.EditAcc){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditAccSub){
    switch(Edit.EditAccMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedAcc), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[3], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(BankAccount, '"+PSql.norm(Edit.EditedAccSub)+"', '"+PSql.norm(Edit.EditedAcc)+"')";
   }
   columns.append("BankAccount="+str);
  }
  if(Edit.EditComment){
   if(first){first=false;}else{columns.append(',');}
   if(!Edit.EditCommentSub){
    switch(Edit.EditCommentMode){
     case 0 : str=PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true); break;
     case 3 : str=PDatabase.getSQLString(PCore.objString(ConByStrict_AData[4], null), CCore.TypeString, CCore.vNull, true); break;
    }
   }
   else{
    str="replace(Comment, '"+PSql.norm(Edit.EditedCommentSub)+"', '"+PSql.norm(Edit.EditedComment)+"')";
   }
   columns.append("Comment="+str);
  }
  
  return columns.toString();
 }
 public static void executeDeleteSubjectAcc(Statement Stm, boolean StmIgnore, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds) throws Exception{
  int temp, count, currcount, MaxOp;
  long[] Ids;
  
  MaxOp=1000;
  
  count=MainIds.length;
  
  temp=0;
  do{
   currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
   Ids=PCore.subArr(MainIds, temp, currcount);
   
   Stm.executeUpdate("delete"+PText.getString(StmIgnore, " ignore", "")+" from SubjectXBankAccount"+
    getSubjectAcc_Query_Condition(Ids, ByStrict, ByStrict_Data, false, -1, ByIndependent_CompIds));
   
   temp=temp+currcount;
  }while(temp!=count);
 }
 public static boolean subjectAccAdd(Statement Stm, boolean StmIgnore, long[] MainIds, Vector<Object[]> Data, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeInsertSubjectAcc(Stm, StmIgnore, Ids, Data);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean subjectAccEdit(Statement Stm,
  long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OEditSubjectBankAccount Edit, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeEditSubjectAcc(Stm, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds, Edit);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean subjectAccRemove(Statement Stm, boolean StmIgnore, long[] MainIds,
  boolean ByStrict,
   Vector<Object[]> ByStrict_Data,
   int[] ByIndependent_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids;
  double progress_inc=0;
  int progress_inc_times;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    temp=0; count=MainIds.length; MaxOp=1000;
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids=PCore.subArr(MainIds, temp, currcount);
     
     executeDeleteSubjectAcc(Stm, StmIgnore, Ids, ByStrict, ByStrict_Data, ByIndependent_CompIds);
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 
 //
	public static Vector<Object[]> getBillsInFromTrans(Statement Stm, Long[] TransIds, boolean IsPreTrans){
		/* Object[] of Bills contains (BillDate, BillAmount, BillAmountPaid) */
		Vector<Object[]> ret=null;
		Vector<Object[]> Bills=new Vector();
		String DbTbl;
		ResultSet Rs;
		
		Date BillDate;
		double PriceItemIn, PriceItemOut, PricePayOut, PricePayIn;
		double BillAmount, BillAmountPaid;
		
  if(TransIds==null){return ret;}
  if(TransIds.length==0){return Bills;}
		
		if(!IsPreTrans){DbTbl="Trans";}
		else{DbTbl="PreTrans";}
  
		do{
			try{
    Rs=Stm.executeQuery(
     "select tb4.*, Sum(Price) as 'PricePayIn' from "+
      "(select tb3.*, Sum(Price) as 'PricePayOut' from "+
       "(select tb2.*, Sum(Price) as 'PriceItemOut' from "+
        "(select tb1.*, Sum(Price) as 'PriceItemIn' from "+
         "(select Id, Date_Add(TransDate, Interval ifnull(CreditDays, 0) Day) as 'BillDate' from "+DbTbl+" where "+
          "Id in ("+PText.toString(PCore.primArr(TransIds), 0, TransIds.length, ",")+") and CreditDays is not "+CCore.vNull+") as tb1 "+
        "left join "+DbTbl+"XItemIn on tb1.Id="+DbTbl+"XItemIn."+DbTbl+" group by tb1.Id) as tb2 "+
       "left join "+DbTbl+"XItemOut on tb2.Id="+DbTbl+"XItemOut."+DbTbl+" group by tb2.Id) as tb3 "+
      "left join "+DbTbl+"XPayment on tb3.Id="+DbTbl+"XPayment."+DbTbl+" group by tb3.Id) as tb4 "+
     "left join "+DbTbl+"XPaymentIn on tb4.Id="+DbTbl+"XPaymentIn."+DbTbl+" group by tb4.Id"
    );
    if(Rs.next()){
     do{
      BillDate=Rs.getDate(2);
      PriceItemIn=Rs.getDouble(3); if(Rs.wasNull()){PriceItemIn=0;}
      PriceItemOut=Rs.getDouble(4); if(Rs.wasNull()){PriceItemOut=0;}
      PricePayOut=Rs.getDouble(5); if(Rs.wasNull()){PricePayOut=0;}
      PricePayIn=Rs.getDouble(6); if(Rs.wasNull()){PricePayIn=0;}
      BillAmount=PriceItemOut+PricePayOut;
      BillAmountPaid=PriceItemIn+PricePayIn; if(BillAmountPaid>BillAmount){BillAmountPaid=BillAmount;}
      if(BillAmount>0){Bills.addElement(PCore.objArrVariant(BillDate, BillAmount, BillAmountPaid));}
     }while(Rs.next());
    }
			}
			catch(Exception E){break;}
			ret=Bills;
		}while(false);
		
		return ret;
	}
	public static Vector<Object[]> getBillsOutFromTrans(Statement Stm, Long[] TransIds, boolean IsPreTrans){
		/* Object[] of Bills contains (BillDate, BillAmount, BillAmountPaid, RepayPeriodStart, RepayPeriodEnd) */
		Vector<Object[]> ret=null;
		Vector<Object[]> Bills=new Vector();
		String DbTbl;
		ResultSet Rs;
		
		Date BillDate;
		Date RepayPeriodStart;
		Date RepayPeriodEnd;
		double PriceItemIn, PriceItemOut, PricePayOut, PricePayIn;
		double BillAmount, BillAmountPaid;
		
  if(TransIds==null){return ret;}
  if(TransIds.length==0){return Bills;}
		
		if(!IsPreTrans){DbTbl="Trans";}
		else{DbTbl="PreTrans";}
		
		do{
			try{
    Rs=Stm.executeQuery(
     "select tb4.*, Sum(Price) as 'PricePayIn' from "+
      "(select tb3.*, Sum(Price) as 'PricePayOut' from "+
       "(select tb2.*, Sum(Price) as 'PriceItemOut' from "+
        "(select tb1.*, Sum(Price) as 'PriceItemIn' from "+
         "(select Id, Date_Add(TransDate, Interval ifnull(CreditDays, 0) Day) as 'BillDate', RepaymentPeriodStart, RepaymentPeriodEnd from "+DbTbl+" where "+
          "Id in ("+PText.toString(PCore.primArr(TransIds), 0, TransIds.length, ",")+") and CreditDays is not "+CCore.vNull+" and "+
          "RepaymentPeriodStart is not "+CCore.vNull+" and RepaymentPeriodEnd is not "+CCore.vNull+") as tb1 "+
        "left join "+DbTbl+"XItemIn on tb1.Id="+DbTbl+"XItemIn."+DbTbl+" group by tb1.Id) as tb2 "+
       "left join "+DbTbl+"XItemOut on tb2.Id="+DbTbl+"XItemOut."+DbTbl+" group by tb2.Id) as tb3 "+
      "left join "+DbTbl+"XPayment on tb3.Id="+DbTbl+"XPayment."+DbTbl+" group by tb3.Id) as tb4 "+
     "left join "+DbTbl+"XPaymentIn on tb4.Id="+DbTbl+"XPaymentIn."+DbTbl+" group by tb4.Id"
    );
    if(Rs.next()){
     do{
      BillDate=Rs.getDate(2);
      RepayPeriodStart=Rs.getDate(3);
      RepayPeriodEnd=Rs.getDate(4);
      PriceItemIn=Rs.getDouble(5); if(Rs.wasNull()){PriceItemIn=0;}
      PriceItemOut=Rs.getDouble(6); if(Rs.wasNull()){PriceItemOut=0;}
      PricePayOut=Rs.getDouble(7); if(Rs.wasNull()){PricePayOut=0;}
      PricePayIn=Rs.getDouble(8); if(Rs.wasNull()){PricePayIn=0;}
      BillAmount=PriceItemIn+PricePayIn;
      BillAmountPaid=PriceItemOut+PricePayOut;
      if(BillAmount>BillAmountPaid){Bills.addElement(PCore.objArrVariant(BillDate, BillAmount, BillAmountPaid, RepayPeriodStart, RepayPeriodEnd));}
     }while(Rs.next());
    }
			}
			catch(Exception E){break;}
			ret=Bills;
		}while(false);
		
		return ret;
	}
 
 // fore text + sqlquery (n records, custom columns/all column)
 public static OInstructionsText instructionsForText1(String ForeText, int NFirstRecords,
  boolean FetchDataFromCustomColumns, int[] CustomColumns, String SqlQuery, int[] SqlQueryColumnsType){
  OInstructionsText ret=new OInstructionsText();
  
  ret.ForeText=ForeText;
  ret.NFirstRecords=NFirstRecords;
  ret.FetchDataFromCustomColumns=FetchDataFromCustomColumns;
  ret.FetchCustomColumns=CustomColumns;
  ret.SqlQuery=SqlQuery;
		ret.SqlQueryColumnsType=SqlQueryColumnsType;
  ret.Instructions=PCore.primArr(1, 61, 71);
  
  return ret;
 }
 // fore text + previous data
 public static OInstructionsText instructionsForText2(String ForeText){
  OInstructionsText ret=new OInstructionsText();
  
  ret.ForeText=ForeText;
  ret.Instructions=PCore.primArr(1, 2);
  
  return ret;
 }
 
 // sqlquery without pass sumresult
 public static OInstructionsTable instructionsForTable1(
  String[] ColumnsName, int[] ColumnsType, int[] ColumnsShowOption, int[] ColumnsVisible, int[] ColumnsWidth, int[] ColumnId,
  String SqlQuery){
  OInstructionsTable ret=new OInstructionsTable();
  
  ret.ColumnsName=ColumnsName;
  ret.ColumnsType=ColumnsType;
  ret.ColumnsShowOption=ColumnsShowOption;
  ret.ColumnsVisible=ColumnsVisible;
  ret.ColumnsWidth=ColumnsWidth;
		ret.FillTableMode=2;
  ret.SqlQuery=SqlQuery;
  ret.ColumnId=ColumnId;
  ret.PassSumResult=false;
  ret.Instructions=PCore.primArr(1);
  
  return ret;
 }
 // sqlquery with pass sumresult
 public static OInstructionsTable instructionsForTable2(
  String[] ColumnsName, int[] ColumnsType, int[] ColumnsShowOption, int[] ColumnsVisible, int[] ColumnsWidth, int[] ColumnId,
  boolean[] SumColumn, double[] SumResult, int[] ColumnToBePassed, String SqlQuery){
  OInstructionsTable ret=new OInstructionsTable();
  
  ret.ColumnsName=ColumnsName;
  ret.ColumnsType=ColumnsType;
  ret.ColumnsShowOption=ColumnsShowOption;
  ret.ColumnsVisible=ColumnsVisible;
  ret.ColumnsWidth=ColumnsWidth;
		ret.FillTableMode=2;
  ret.SqlQuery=SqlQuery;
  ret.ColumnId=ColumnId;
  ret.PassSumResult=true;
  ret.SumColumn=SumColumn;
  ret.SumResult=SumResult;
  ret.ColumnsToBePassed=ColumnToBePassed;
  ret.Instructions=PCore.primArr(1);
  
  return ret;
 }
 // custom table data
 public static OInstructionsTable instructionsForTable3(
  String[] ColumnsName, int[] ColumnsType, int[] ColumnsShowOption, int[] ColumnsVisible, int[] ColumnsWidth, int[] ColumnId,
  Vector<Object[]> CustomTableData){
  OInstructionsTable ret=new OInstructionsTable();
  
  ret.ColumnsName=ColumnsName;
  ret.ColumnsType=ColumnsType;
  ret.ColumnsShowOption=ColumnsShowOption;
  ret.ColumnsVisible=ColumnsVisible;
  ret.ColumnsWidth=ColumnsWidth;
		ret.FillTableMode=1;
  ret.CustomTableData=CustomTableData;
  ret.ColumnId=ColumnId;
  ret.PassSumResult=false;
  ret.Instructions=PCore.primArr(1);
  
  return ret;
 }
 
 private static String getQueryBusinessBaseModality(double OrderTargetPercentage){
  String Con="IsActive="+CCore.vTrue+" and Item.UpdateStockOnTransaction="+CCore.vTrue+" and Item.IsReorder="+CCore.vTrue;
  
  return 
   "select tb1.Name as 'ItemName', tb1.Id as 'ItemId', MinimalStock, MaximalStock, QtyRounded, "+
   "StockUnit.Id as 'StockUnitId', StockUnit.Name as 'StockUnitName', BuyPriceEstimation, OrderPrice from "+
    "(select info_order.*, Item.*, (QtyRounded*BuyPriceEstimation) as 'OrderPrice' from "+
     getTableOrderInfo("0", "Prc", OrderTargetPercentage, Con, null)+" inner join Item on info_order.Order_ItemId=Item.Id"+
    ") as tb1 "+
   "left join StockUnit on tb1.StockUnit=StockUnit.Id";
 }
 private static Object[] genQueryBusinessBaseModality(int QueryId, double OrderTargetPercentage){
  Object[] ret;
  OInstructions Inst=null;
  String str;
  
  ret=new Object[4];
  ret[0]=QueryId;
  ret[1]="Besaran modal usaha ("+PText.priceToString(OrderTargetPercentage)+"%)";
  ret[2]="menampilkan besaran modal uang yang dibutuhkan untuk membangun usaha pada perkiraan "+
   "'"+PText.priceToString(OrderTargetPercentage)+"% antara Stok Minimal & Stok Maksimal dari masing-masing barang'.";
  str=getQueryBusinessBaseModality(OrderTargetPercentage);
  Inst=PMyShop.instructionsForText1("Besaran modal uang untuk membangun usaha pada perkiraan '"+PText.priceToString(OrderTargetPercentage)+"% antara Stok Minimal & Stok Maksimal' ialah : ",
   1, true, PCore.primArr(0), "select sum(tb_modality.OrderPrice) from ("+str+") as tb_modality;", PCore.primArr(CCore.TypeDouble));
  Inst.Next=PMyShop.instructionsForTable1(
			PCore.refArr("Nama Barang", "Id Barang", "Min Stok", "Max Stok", "Qty Order", "Id Satuan", "Satuan", "Kis Harga Beli", "Kis Harga Order"),
			PCore.primArr(CCore.TypeString, CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble),
   PCore.changeValue(PCore.newIntegerArray(9, OCustomTableModel.ShowOptionNormal), PCore.primArr(1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
			PCore.primArr(0, 1, 2, 3, 4, 6, 7, 8),
			PCore.primArr(CGUI.ColTextMed, CGUI.ColNum13, CGUI.ColNumSep04, CGUI.ColNumSep04, CGUI.ColNumSep04, CGUI.ColTextMini, CGUI.ColNumSep09, CGUI.ColNumSep09_a),
			PCore.primArr(1, 5),
   str+" order by OrderPrice desc, ItemName asc;");
  ret[3]=Inst;
  
  return ret;
 }
 public static Vector<Object[]> generateSimpleQueries(){
  Vector<Object[]> ret=new Vector();
  Object[] AQuery; // A Query contains : query_title, query_explanation, instructions
		OInstructions Inst=null;
  String str;
  
  // Query About Items
  AQuery=new Object[4]; ret.addElement(AQuery);
  AQuery[0]=1001;
  AQuery[1]="Variasi periode pengecekan expire pd semua data barang yg berkadaluarsa";
  AQuery[2]="menampilkan variasi periode pengecekan expire yang terdapat pada semua data barang yang berkadaluarsa.";
  str="select Name as 'ItemName', Id as 'ItemId', ExpireCheckPeriod, ExpireThreshold, HasExpireDate from Item "+
   "where HasExpireDate="+CCore.vTrue+" order by ExpireCheckPeriod asc, Name asc";
		Inst=PMyShop.instructionsForText1("Variasi periode pengecekan expire yang terdapat pada semua data barang yang berkadaluarsa ialah :"+
   "\n\n( Periode pengecekan expire, Jumlah data barang )\n",
   0, true, PCore.primArr(0, 1),
   "select ExpireCheckPeriod, count(ifnull(ExpireCheckPeriod,0)) from ("+str+") as tb1 group by ExpireCheckPeriod order by ExpireCheckPeriod asc;",
   PCore.primArr(CCore.TypeInteger, CCore.TypeLong));
  Inst.Next=PMyShop.instructionsForTable1(
			PCore.refArr("Nama Barang", "Id Barang", "Cek Exp", "Batas Exp", "Exp"),
			PCore.primArr(CCore.TypeString, CCore.TypeLong, CCore.TypeInteger, CCore.TypeInteger, CCore.TypeBoolean),
   PCore.changeValue(PCore.newIntegerArray(5, OCustomTableModel.ShowOptionNormal), PCore.primArr(1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
			PCore.primArr(0, 1, 2, 3, 4),
			PCore.primArr(CGUI.ColTextMed, CGUI.ColNum13, CGUI.ColNumSep06, CGUI.ColNumSep06, CGUI.ColCheck),
			PCore.primArr(1), str);
  AQuery[3]=Inst;
  
  AQuery=new Object[4]; ret.addElement(AQuery);
  AQuery[0]=1002;
  AQuery[1]="100 jenis barang yang paling sering keluar dalam 30 hari terakhir";
  AQuery[2]="menampilkan jenis-jenis barang yang paling sering keluar dalam 30 hari terakhir (maks. 100 data)";
  // nama barang, id barang, jumlah transaksi
  AQuery[3]=PMyShop.instructionsForTable1(
   PCore.refArr("Nama Brg", "Id Brg", "Jumlah Transaksi"), PCore.primArr(1, 3, 2),
   PCore.changeValue(PCore.newIntegerArray(3, OCustomTableModel.ShowOptionNormal), PCore.primArr(1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(0, 1, 2),
   PCore.primArr(CGUI.ColTextMed, CGUI.ColNum16, CGUI.ColNumSep06),
   PCore.primArr(1),
   "select Item.Name, TransXItemOut.Item, count(TransXItemOut.Item) as 'TransCount' from TransXItemOut, Item, Trans where "+
   "TransXItemOut.Trans=Trans.Id and TransXItemOut.Item=Item.Id and (Trans.TransDate>=subdate(curdate(), interval 30 day) and Trans.TransDate<=curdate()) "+
   "group by TransXItemOut.Item order by TransCount desc, Item.Name asc limit 100;");

  // Query About Subjects
  

  // Query About Transactions
  

  // Query About Accounting
  AQuery=new Object[4]; ret.addElement(AQuery);
  AQuery[0]=4001;
  AQuery[1]="Potensi harta dalam bentuk barang (berdasarkan harga beli)";
  AQuery[2]="menampilkan hasil akumulasi (sisa_stok x kisaran_harga_beli) dari masing-masing barang";
  str="select Name as 'ItemName', Id as 'ItemId', Stock, StockUnit, BuyPriceEstimation, (Stock*BuyPriceEstimation) as 'ItemValue' from Item "+
   "where UpdateStockOnTransaction="+CCore.vTrue+" and (Stock*BuyPriceEstimation)>0";
		Inst=PMyShop.instructionsForText1("Hasil akumulasi (sisa_stok x kisaran_harga_beli) dari masing-masing jenis barang ialah :",
   1, true, PCore.primArr(0), "select sum(tb1.ItemValue) from ("+str+") as tb1;", PCore.primArr(CCore.TypeDouble));
  Inst.Next=PMyShop.instructionsForTable1(
			PCore.refArr("Nama Barang", "Id Barang", "Stok", "Id Satuan", "Satuan", "Kis Harga Beli", "Potensi Harta"),
			PCore.primArr(CCore.TypeString, CCore.TypeLong, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble),
   PCore.changeValue(PCore.newIntegerArray(7, OCustomTableModel.ShowOptionNormal), PCore.primArr(1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
			PCore.primArr(0, 1, 2, 4, 5, 6),
			PCore.primArr(CGUI.ColTextMed+50, CGUI.ColNum13, CGUI.ColNumSep06, CGUI.ColTextTiny, CGUI.ColNumSep09_a, CGUI.ColCur09_02),
			PCore.primArr(1, 3),
   "select ItemName, ItemId, Stock, StockUnit, StockUnit.Name as 'ItemStockUnitName', BuyPriceEstimation, ItemValue from "+
    "("+str+") as tb1 "+
   "left join StockUnit on tb1.StockUnit=StockUnit.Id "+
			"order by ItemValue desc, ItemName asc;");
  AQuery[3]=Inst;
  
  AQuery=new Object[4]; ret.addElement(AQuery);
  AQuery[0]=4002;
  AQuery[1]="Potensi harta dalam bentuk barang (berdasarkan harga jual)";
  AQuery[2]="menampilkan hasil akumulasi (sisa_stok x harga_jual) dari masing-masing barang";
  str="select Name as 'ItemName', Id as 'ItemId', Stock, StockUnit, SellPrice, (Stock*SellPrice) as 'ItemValue' from Item "+
   "where UpdateStockOnTransaction="+CCore.vTrue+" and (Stock*SellPrice)>0";
		Inst=PMyShop.instructionsForText1("Hasil akumulasi (sisa_stok x harga_jual) dari masing-masing jenis barang ialah :",
   1, true, PCore.primArr(0), "select sum(tb1.ItemValue) from ("+str+") as tb1;", PCore.primArr(CCore.TypeDouble));
  Inst.Next=PMyShop.instructionsForTable1(
			PCore.refArr("Nama Barang", "Id Barang", "Stok", "Id Satuan", "Satuan", "Harga Jual", "Potensi Harta"),
			PCore.primArr(CCore.TypeString, CCore.TypeLong, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble),
   PCore.changeValue(PCore.newIntegerArray(7, OCustomTableModel.ShowOptionNormal), PCore.primArr(1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
			PCore.primArr(0, 1, 2, 4, 5, 6),
			PCore.primArr(CGUI.ColTextMed+50, CGUI.ColNum13, CGUI.ColNumSep06, CGUI.ColTextTiny, CGUI.ColNumSep09_a, CGUI.ColCur09_02),
			PCore.primArr(1, 3),
   "select ItemName, ItemId, Stock, StockUnit, StockUnit.Name as 'ItemStockUnitName', SellPrice, ItemValue from "+
    "("+str+") as tb1 "+
   "left join StockUnit on tb1.StockUnit=StockUnit.Id "+
			"order by ItemValue desc, ItemName asc;");
  AQuery[3]=Inst;
  
  AQuery=genQueryBusinessBaseModality(4101, 25); ret.addElement(AQuery);
  AQuery=genQueryBusinessBaseModality(4102, 50); ret.addElement(AQuery);
  AQuery=genQueryBusinessBaseModality(4103, 75); ret.addElement(AQuery);
  AQuery=genQueryBusinessBaseModality(4104, 100); ret.addElement(AQuery);
  
  return ret;
 }

 public static Vector<OPaper> getPaperReport(OPaperMargin MgSt){
  Vector<OPaper> ret=new Vector();
  
  ret.addElement(CPrint.A4.cloneWithMargin(MgSt));
  ret.addElement(CPrint.A5.cloneWithMargin(MgSt));
  
  return ret;
 }
 public static Vector<OPaper> getPaperReceipt(OPaperMargin MgSt, OPaperMargin MgTher){
  Vector<OPaper> ret=new Vector();
  
  ret.addElement(CPrint.A5.cloneWithMargin(MgSt));
  ret.addElement(CPrint.A6.cloneWithMargin(MgSt));
  ret.addElement(CPrint.Thermal57.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal60.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal62.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal65.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal67.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal70.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal72.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal75.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal77.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal80.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal100.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal102.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal105.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal107.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal110.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal112.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal115.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal117.cloneWithMargin(MgTher));
  ret.addElement(CPrint.Thermal120.cloneWithMargin(MgTher));
  
  return ret;
 }
 public static Vector<OLabelCreator> getLabelCreatorsItem(
  OFont FontStandard, OFont FontCustom, OPaperMargin MgSt, OPaperMargin MgTh){
  Vector<OLabelCreator> ret=new Vector();
  
  ret.addElement(new OLabelCreatorItemBarcode(FontStandard, new OFontLayout(6.5f, false, false), FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemMiniID(FontStandard, new OFontLayout(6.5f, false, false), FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemPriceTag(FontStandard, null, FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemPriceTag_Barcode(FontStandard, null, FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemMiniPriceTagA(FontStandard, new OFontLayout(8.5f, false, false), FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemMiniPriceTagA_Barcode(FontStandard, new OFontLayout(8.5f, false, false), FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemMiniPriceTagB(FontStandard, new OFontLayout(8.5f, false, false), FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemMiniPriceTagB_Barcode1(FontStandard, new OFontLayout(8.5f, false, false), FontCustom, MgSt, MgTh));
  ret.addElement(new OLabelCreatorItemMiniPriceTagB_Barcode2(FontStandard, new OFontLayout(8.5f, false, false), FontCustom, MgSt, MgTh));
  
  /* for testing only
  ret.addElement(new OLabelCreatorTestPrint(FontStandard, new OFontLayout(6.5f, false, false), FontCustom, MgSt, MgTh));
  */
  
  return ret;
 }
 
 public static OBarcodePatterns patternize(long Id){
  OBarcodePatterns ret=null;
  OBarcodePatternizer Patternizer;
  
  do{
   if(OBarcodeGeneratorEAN.checkCodeValidity(Id, 8)){Patternizer=PattEAN08; break;}
   if(OBarcodeGeneratorEAN.checkCodeValidity(Id, 13)){Patternizer=PattEAN13; break;}
   Patternizer=PattCode128SetC;
  }while(false);
  Patternizer.patternize(Id, 8);
  ret=Patternizer.getResult();
  
  return ret;
 }
 
 public static long[] getItemsNonCompatibleToSupportedBarcodes(Statement Stm){
  Vector<Long> ret=null; // null : error , 0 : empty , >=1 : there are
  Vector<Long> rettemp=null;
  long[] ids;
  int temp;
  long Id;
  boolean compatible;
  boolean error;
  
  do{
   try{
    
    error=false;
    do{
     // get all items's primary id
     ids=PCore.primArrLong_VectObj(PDatabase.getListFromQuery(Stm, "select Id from Item", CCore.TypeLong, false, null));
     if(ids==null){error=true; break;}

     // check the compabilitiness of every item's primary id to minimal one of supported barcode formats
     rettemp=new Vector();
     if(ids.length==0){break;}
     
     temp=0;
     do{
      Id=ids[temp];
      compatible=isIdCompatibleWithSupportedBarcodes(Id);
      if(compatible==false){rettemp.addElement(Id);}

      temp=temp+1;
     }while(temp!=ids.length);
    }while(false);
    if(error){break;}
   
   }
   catch(Exception E_){break;}
   ret=rettemp;
  }while(false);
  
  return PCore.primArr_VectLong(ret);
 }
 
 public static Vector<Object[]> convertItemsIdToSupportedBarcodes(
  Statement Stm, long[] ItemsId, OBarcodeGenerator IdGenerator, int Mode) throws Exception{
  Vector<Object[]> ret=null; // return only 'Id of changed items' (old id, new id)
  Vector<Object[]> rettemp=null;
  Long OldId, NewId;
  boolean error;
  boolean PreserveOldId;
  
  Vector<Object[]> ListPreserveOldId;
  int CurrIndex, MaxOp, CurrOpLength, CurrOpIndex;
  boolean compatible;
  
  do{
   switch(Mode){
    case 1  : PreserveOldId=false; break;
    case 2  : PreserveOldId=true; break;
    default : PreserveOldId=true; break;
   }
   
   error=false; MaxOp=1000;
   rettemp=new Vector();

   CurrIndex=0;
   do{
    CurrOpLength=MaxOp; if(CurrIndex+CurrOpLength>ItemsId.length){CurrOpLength=ItemsId.length-CurrIndex;}
    ListPreserveOldId=new Vector();

    CurrOpIndex=0;
    do{
     OldId=ItemsId[CurrIndex+CurrOpIndex];

     // check if compatible or not
     compatible=isIdCompatibleWithSupportedBarcodes(OldId);

     if(!compatible){
      NewId=generateNewIdOnItem(Stm, IdGenerator);
      if(NewId==null){error=true; break;}

      Stm.executeUpdate("update Item set Id="+NewId+" where Id="+OldId);

      rettemp.addElement(PCore.objArrVariant(OldId, NewId));
      if(PreserveOldId){ListPreserveOldId.addElement(PCore.objArrVariant(NewId, OldId));}
     }

     CurrOpIndex=CurrOpIndex+1;
    }while(CurrOpIndex!=CurrOpLength);
    if(error){break;}

    if(PreserveOldId && ListPreserveOldId.size()!=0){
     Stm.executeUpdate("insert into ItemXSecondaryId(Item, SecondaryId) values "+
      PText.toStringWithQuote(ListPreserveOldId, 0, ListPreserveOldId.size(), ",",
       PCore.primArr(0, 1), PCore.primArr(false, false), "(", ")", ",", "", null, true));
    }

    CurrIndex=CurrIndex+CurrOpLength;
   }while(CurrIndex!=ItemsId.length);
   if(error){break;}
   
   ret=rettemp;
  }while(false);
  
  return ret;
 }
 public static boolean isIdCompatibleWithSupportedBarcodes(long Id){
  boolean ret=false;
  
  // check the compabilitiness of an Id to minimal one of supported barcode formats
  do{

   if(OBarcodeGeneratorEAN.checkCodeValidity(Id, 8)){ret=true; break;}
   if(OBarcodeGeneratorEAN.checkCodeValidity(Id, 13)){ret=true; break;}

  }while(false);
  
  return ret;
 }

 public static Object[] dataIdNameImportAdd(
  OFormInformProgress Progress,
  OFileCsv FromFile, int FileFieldName,
  Statement Stm, String ToTable){
  Vector<OCsvImportValue> ColsValuePK, ColsValueNonPK;
  ColsValuePK=new Vector();
  ColsValuePK.addElement(new OCsvImportValueAutoId(null, Stm, "select Id from "+ToTable+" order by Id asc;"));
  ColsValueNonPK=new Vector();
  ColsValueNonPK.addElement(new OCsvImportValueSelect(new OCsvImportValueFile(true, FileFieldName, CCore.TypeString), null, null, null));
  return PEtc.csvImportAdd(Progress, FromFile, Stm, ToTable, PCore.vect("Id"), new OCsvImportValuesForInsert(ColsValuePK), PCore.vect("Name"), new OCsvImportValuesForInsert(ColsValueNonPK), false);
 }
 
 public static long printItemCSV(
  OFormInformProgress Progress, Statement Stm,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator,
  
  long[] ItemsId,
  
  boolean OptDataCategorized,
  
  boolean OptCategory, boolean OptVariants, boolean OptVariants_ActiveYes, boolean OptVariants_ActiveNo, boolean OptIsActive, boolean OptComment, boolean OptPictureFile,
  boolean OptIsStockUpdated, boolean OptStock, boolean OptStockPre, boolean OptStockEst, boolean OptStockMinMax, boolean OptStockUnit,
  boolean OptIsOpname, boolean OptIsReorder, boolean OptOrderEachPackQty, boolean OptOrderEachPackThreshold, boolean OptOrderMinPack,
  boolean OptIsExpire, boolean OptExpCheckPeriod, boolean OptExpThreshold, boolean OptExpThresholdDate,
  boolean OptSellPrice, boolean OptSellComment, boolean OptSellUpdate, boolean OptBuyPriceEst, boolean OptBuyComment, boolean OptBuyUpdate,
  boolean OptOpnameStock, boolean OptOpnameExp, boolean OptOrderQty, boolean OptOrderPriceEst,
  
  boolean OptListCategory, boolean OptListTag, boolean OptListSecondaryId, boolean OptListVariant, boolean OptListVariantActiveYes, boolean OptListVariantActiveNo, boolean OptListPicture, boolean OptListSupplier,
  
  boolean ShowBuyPrice, boolean ShowListItemSupplier){
  
  String Query, QueryCondition, QueryOrderBy;
  int[] ColumnsType;
  String[] Header;
  int[] HeaderCols;
  
  Vector<String> List_SubQueryBeforeId;
  Vector<String[]> List_SubIdFromMainColsName;
  int[] SubIdFromMainCols;
  Vector<String> List_SubQueryAfterId;
  Vector<int[]> List_SubColumnsType;
  Vector<String[]> List_SubHeader;
  Vector<int[]> List_SubHeaderCols;
  
  String SubQueryBeforeId;
  String[] SubIdFromMainColsName;
  String SubQueryAfterId;
  int[] SubColumnsType;
  Vector<String> hdr;
  Vector<Integer> hdrcols;
  
  String con_variant;
  StringBuilder strb;
  boolean first;
  
  // Query
  strb=new StringBuilder(); first=true;
  if(OptVariants){
   if(OptVariants_ActiveYes){
    if(first){first=false;}else{strb.append(" or");}
    strb.append(" ItemXVariant.IsActive="+CCore.vTrue);
   }
   if(OptVariants_ActiveNo){
    if(first){first=false;}else{strb.append(" or");}
    strb.append(" ItemXVariant.IsActive="+CCore.vFalse);
   }
   if(!first){
    strb=new StringBuilder(" and("+strb.toString()+")");
   }
  }
  con_variant=strb.toString();
  
  QueryCondition=""; if(ItemsId!=null){if(ItemsId.length!=0){QueryCondition=" where Id in("+PText.toString(ItemsId, 0, ItemsId.length, ",")+")";}}
  QueryOrderBy=" order by"+PText.getString(!OptDataCategorized, " tb6.Name asc", " CategoryOfItem.Name asc, tb6.Name asc");
  Query=
   "select tb6.*, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
    "(select tb5.*, (Stock+ifnull(PreStockIn,0)-ifnull(PreStockOut,0)) as 'StockEst', Min(ItemXPicture.FileName) as 'PictureFile' from "+
     "(select tb4.*, Sum(PreTransXItemOut.Stock) as 'PreStockOut' from "+
      "(select tb3.*, Sum(PreTransXItemIn.Stock) as 'PreStockIn' from "+
       "(select tb2.*, Group_Concat(Variant Order By Variant asc Separator ', ') as 'Variants' from "+
        "(select tb1.*, StockUnit.Name as 'StockUnitName' from "+
         "(select Id, Name, IsActive, Comment, "+
          "UpdateStockOnTransaction, StockUnit, Stock, MinimalStock, MaximalStock, "+
          "IsOpname, IsReorder, OrderEachPackQty, OrderEachPackThreshold, OrderMinPack, "+
          "HasExpireDate, ExpireCheckPeriod, ExpireThreshold, if(ExpireThreshold is "+CCore.vNull+", "+CCore.vNull+", Date_Add(CurDate(), Interval ifnull(ExpireThreshold,0) Day)) as 'ExpireThresholdDate', "+
          "SellPrice, SellPriceComment, SellUpdate, BuyPriceEstimation, BuyPriceComment, BuyUpdate, "+
          "OpnameStock, OpnameExpire, OrderQuantity, if(OrderQuantity is "+CCore.vNull+", "+CCore.vNull+", ifnull(OrderQuantity,0)*BuyPriceEstimation) as 'OrderPriceEst' from Item"+QueryCondition+") as tb1 "+
        "left join StockUnit on tb1.StockUnit=StockUnit.Id) as tb2 "+
       "left join ItemXVariant on tb2.Id=ItemXVariant.Item"+con_variant+" group by Id) as tb3 "+
      "left join PreTransXItemIn on tb3.Id=PreTransXItemIn.Item group by Id) as tb4 "+
     "left join PreTransXItemOut on tb4.Id=PreTransXItemOut.Item group by Id) as tb5 "+
    "left join ItemXPicture on tb5.Id=ItemXPicture.Item group by tb5.Id) as tb6 "+
   "left join ItemXCategory on tb6.Id=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb6.Id"+
			QueryOrderBy;
  
  // ColumnsType
  ColumnsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString,
   CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeBoolean, CCore.TypeBoolean, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeInteger, CCore.TypeDate,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeDouble, CCore.TypeString, CCore.TypeDate,
   CCore.TypeDouble, CCore.TypeDate, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeString, CCore.TypeInteger, CCore.TypeString);
  
  // Header
  hdr=new Vector(); hdrcols=new Vector();
  if(OptDataCategorized){hdr.addElement("Kategori"); hdrcols.addElement(35);}
  hdr.addElement("Nama Barang"); hdrcols.addElement(1);
  if(OptVariants){hdr.addElement("Varian"); hdrcols.addElement(29);}
  hdr.addElement("Id Barang"); hdrcols.addElement(0);
  if(OptCategory && !OptDataCategorized){hdr.addElement("Kategori"); hdrcols.addElement(35);}
  if(OptIsActive){hdr.addElement("Aktif"); hdrcols.addElement(2);}
  if(OptComment){hdr.addElement("Komentar"); hdrcols.addElement(3);}
  if(OptPictureFile){hdr.addElement("File Gambar"); hdrcols.addElement(33);}
  if(OptIsStockUpdated){hdr.addElement("Perbarui Stok"); hdrcols.addElement(4);}
  if(OptStock){hdr.addElement("Stok"); hdrcols.addElement(6);}
  if(OptStockPre){hdr.addElement("Pra-Masuk"); hdrcols.addElement(30); hdr.addElement("Pra-Keluar"); hdrcols.addElement(31);}
  if(OptStockEst){hdr.addElement("Kisaran Stok"); hdrcols.addElement(32);}
  if(OptStockMinMax){hdr.addElement("Stok Minimal"); hdrcols.addElement(7); hdr.addElement("Stok Maksimal"); hdrcols.addElement(8);}
  if(OptStockUnit){hdr.addElement("Satuan Stok"); hdrcols.addElement(28);}
  if(OptIsOpname){hdr.addElement("Di-Opname"); hdrcols.addElement(9);}
  if(OptIsReorder){hdr.addElement("Di-Reorder"); hdrcols.addElement(10);}
  if(OptOrderEachPackQty){hdr.addElement("Order Qty / Pak"); hdrcols.addElement(11);}
  if(OptOrderEachPackThreshold){hdr.addElement("Pembulatan / Pak"); hdrcols.addElement(12);}
  if(OptOrderMinPack){hdr.addElement("Order Min Pak"); hdrcols.addElement(13);}
  if(OptIsExpire){hdr.addElement("Berkadaluarsa"); hdrcols.addElement(14);}
  if(OptExpCheckPeriod){hdr.addElement("Periode Cek Exp"); hdrcols.addElement(15);}
  if(OptExpThreshold){hdr.addElement("Batas Exp"); hdrcols.addElement(16);}
  if(OptExpThresholdDate){hdr.addElement("Tgl Jelang Exp"); hdrcols.addElement(17);}
  if(OptSellPrice){hdr.addElement("Harga Jual"); hdrcols.addElement(18);}
  if(OptSellComment){hdr.addElement("Keterangan Jual"); hdrcols.addElement(19);}
  if(OptSellUpdate){hdr.addElement("Tgl Pembaruan Jual"); hdrcols.addElement(20);}
  if(OptBuyPriceEst && ShowBuyPrice){hdr.addElement("Harga Beli"); hdrcols.addElement(21);}
  if(OptBuyComment && ShowBuyPrice){hdr.addElement("Keterangan Beli"); hdrcols.addElement(22);}
  if(OptBuyUpdate){hdr.addElement("Tgl Pembaruan Beli"); hdrcols.addElement(23);}
  if(OptOpnameStock){hdr.addElement("Opname Stok (Selisih)"); hdrcols.addElement(24);}
  if(OptOpnameExp){hdr.addElement("Opname Expire"); hdrcols.addElement(25);}
  if(OptOrderQty){hdr.addElement("Qty Order"); hdrcols.addElement(26);}
  if(OptOrderPriceEst && ShowBuyPrice){hdr.addElement("Kisaran Harga Order"); hdrcols.addElement(27);}
  Header=PCore.refArr_VectStr(hdr); HeaderCols=PCore.primArr_VectInt(hdrcols);
  
  // SubQueries
  List_SubQueryBeforeId=new Vector(); List_SubIdFromMainColsName=new Vector(); SubIdFromMainCols=PCore.primArr(0); List_SubQueryAfterId=new Vector();
  List_SubColumnsType=new Vector(); List_SubHeader=new Vector(); List_SubHeaderCols=new Vector();
  
  if(OptListCategory){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select CategoryOfItem from ItemXCategory";
   SubIdFromMainColsName=PCore.refArr("Item");
   SubQueryAfterId=
     ") as tb1 "+
    "inner join CategoryOfItem on tb1.CategoryOfItem=CategoryOfItem.Id "+
    "order by Name asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString);
   hdr=PCore.vect("Kategori (Daftar)");
   hdrcols=PCore.vect(1);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListTag){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select TagOfItem from ItemXTag";
   SubIdFromMainColsName=PCore.refArr("Item");
   SubQueryAfterId=
     ") as tb1 "+
    "inner join TagOfItem on tb1.TagOfItem=TagOfItem.Id "+
    "order by Name asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString);
   hdr=PCore.vect("Tag (Daftar)");
   hdrcols=PCore.vect(1);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListSecondaryId){
   SubQueryBeforeId="select SecondaryId from ItemXSecondaryId";
   SubIdFromMainColsName=PCore.refArr("Item");
   SubQueryAfterId="order by SecondaryId asc";
   SubColumnsType=PCore.primArr(CCore.TypeLong);
   hdr=PCore.vect("Secondary-Id (Daftar)");
   hdrcols=PCore.vect(0);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListVariant){
   strb=new StringBuilder(); first=true;
   if(OptVariants){
    if(OptVariants_ActiveYes){
     if(first){first=false;}else{strb.append(" or");}
     strb.append(" IsActive="+CCore.vTrue);
    }
    if(OptVariants_ActiveNo){
     if(first){first=false;}else{strb.append(" or");}
     strb.append(" IsActive="+CCore.vFalse);
    }
    if(!first){
     strb=new StringBuilder(" and("+strb.toString()+")");
    }
   }
   con_variant=strb.toString();
   
   SubQueryBeforeId=
    "select Variant, IsActive, BuyPrice, BuyPriceComment, BuyUpdate, Comment, PictureFile from "+
     "(select tb1.*, Name as 'ItemName' from "+
      "(select Item as 'ItemId', Variant, IsActive, BuyPrice, BuyPriceComment, BuyUpdate, Comment, PictureFile from ItemXVariant";
   SubIdFromMainColsName=PCore.refArr("Item");
   SubQueryAfterId=
      con_variant+") as tb1 "+
     "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
    "order by Variant asc";
   SubColumnsType=PCore.primArr(
    CCore.TypeString, CCore.TypeBoolean, CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeString, CCore.TypeString);
   
   hdr=new Vector(); hdrcols=new Vector();
   hdr.addElement("Varian (Daftar)"); hdrcols.addElement(0);
   hdr.addElement("Keterangan"); hdrcols.addElement(5);
   hdr.addElement("Aktif"); hdrcols.addElement(1);
   if(ShowBuyPrice){hdr.addElement("Harga Beli"); hdrcols.addElement(2);}
   if(ShowBuyPrice){hdr.addElement("Ket. Harga Beli"); hdrcols.addElement(3);}
   if(ShowBuyPrice){hdr.addElement("Tgl Pembaruan"); hdrcols.addElement(4);}
   hdr.addElement("File Gambar"); hdrcols.addElement(6);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListPicture){
   SubQueryBeforeId="select FileName from ItemXPicture";
   SubIdFromMainColsName=PCore.refArr("Item");
   SubQueryAfterId="order by FileName asc";
   SubColumnsType=PCore.primArr(CCore.TypeString);
   hdr=PCore.vect("File Gambar (Daftar)");
   hdrcols=PCore.vect(0);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListSupplier && ShowListItemSupplier){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select Supplier, BuyPrice, BuyPriceComment, UpdateDate, IsActive from ItemXSupplier";
   SubIdFromMainColsName=PCore.refArr("Item");
   SubQueryAfterId=
     ") as tb1 "+
    "inner join Subject on tb1.Supplier=Subject.Id "+
    "order by Name asc";
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeBoolean, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   hdr.addElement("Suplier (Daftar)"); hdrcols.addElement(5);
   if(ShowBuyPrice){
    hdr.addElement("Harga Beli"); hdrcols.addElement(1);
    hdr.addElement("Keterangan Harga Beli"); hdrcols.addElement(2);
    hdr.addElement("Tgl Pembaruan"); hdrcols.addElement(3);
   }
   hdr.addElement("Aktif"); hdrcols.addElement(4);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  return PEtc.csvExport(Progress,
   Stm, Query, ColumnsType, Header, HeaderCols,
   List_SubQueryBeforeId, List_SubIdFromMainColsName, SubIdFromMainCols, List_SubQueryAfterId, List_SubColumnsType, List_SubHeader, List_SubHeaderCols,
   false, ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 
 public static long printSubjectCSV(
  OFormInformProgress Progress, Statement Stm,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator,
  
  long[] SubjectsId,
  
  boolean OptCategory, boolean OptPictureFile, boolean OptBirthday, boolean OptComment,

  boolean OptListCategory, boolean OptListTag, boolean OptListPicture,
  boolean OptListAddress, boolean OptListContact, boolean OptListBankAccount, boolean OptListItem, boolean OptListItemCategorized,
  
  boolean ShowBuyPrice, boolean ShowListItemSupplier){
  
  String Query, QueryCondition, QueryOrderBy;
  int[] ColumnsType;
  String[] Header;
  int[] HeaderCols;
  
  Vector<String> List_SubQueryBeforeId;
  Vector<String[]> List_SubIdFromMainColsName;
  int[] SubIdFromMainCols;
  Vector<String> List_SubQueryAfterId;
  Vector<int[]> List_SubColumnsType;
  Vector<String[]> List_SubHeader;
  Vector<int[]> List_SubHeaderCols;
  
  String SubQueryBeforeId;
  String[] SubIdFromMainColsName;
  String SubQueryAfterId;
  int[] SubColumnsType;
  Vector<String> hdr;
  Vector<Integer> hdrcols;
  
  // Query
  QueryCondition=""; if(SubjectsId!=null){if(SubjectsId.length!=0){QueryCondition=" where Id in("+PText.toString(SubjectsId, 0, SubjectsId.length, ",")+")";}}
  QueryOrderBy=" order by tb2.Name asc";
  Query=
   "select tb2.*, CategoryOfSubject.Id as 'CategoryId', Min(CategoryOfSubject.Name) as 'CategoryName' from "+
    "(select tb1.*, Min(SubjectXPicture.FileName) as 'PictureFile' from "+
     "(select Id, Name, Birthday, Comment from Subject"+QueryCondition+") as tb1 "+
    "left join SubjectXPicture on tb1.Id=SubjectXPicture.Subject group by tb1.Id) as tb2 "+
   "left join SubjectXCategory on tb2.Id=SubjectXCategory.Subject left join CategoryOfSubject on SubjectXCategory.CategoryOfSubject=CategoryOfSubject.Id group by tb2.Id"+
			QueryOrderBy;
  
  // ColumnsType
  ColumnsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeString, CCore.TypeDate, CCore.TypeString, CCore.TypeString, CCore.TypeInteger, CCore.TypeString);
  
  // Header
  hdr=new Vector(); hdrcols=new Vector();
  hdr.addElement("Nama Subjek"); hdrcols.addElement(1);
  if(OptCategory){hdr.addElement("Kategori"); hdrcols.addElement(6);}
  if(OptBirthday){hdr.addElement("Tanggal Lahir"); hdrcols.addElement(2);}
  if(OptComment){hdr.addElement("Komentar"); hdrcols.addElement(3);}
  if(OptPictureFile){hdr.addElement("File Gambar"); hdrcols.addElement(4);}
  Header=PCore.refArr_VectStr(hdr); HeaderCols=PCore.primArr_VectInt(hdrcols);
  
  // SubQueries
  List_SubQueryBeforeId=new Vector(); List_SubIdFromMainColsName=new Vector(); SubIdFromMainCols=PCore.primArr(0); List_SubQueryAfterId=new Vector();
  List_SubColumnsType=new Vector(); List_SubHeader=new Vector(); List_SubHeaderCols=new Vector();
  
  if(OptListCategory){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select CategoryOfSubject from SubjectXCategory";
   SubIdFromMainColsName=PCore.refArr("Subject");
   SubQueryAfterId=
     ") as tb1 "+
    "inner join CategoryOfSubject on tb1.CategoryOfSubject=CategoryOfSubject.Id "+
    "order by Name asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString);
   hdr=PCore.vect("Kategori (Daftar)");
   hdrcols=PCore.vect(1);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListTag){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select TagOfSubject from SubjectXTag";
   SubIdFromMainColsName=PCore.refArr("Subject");
   SubQueryAfterId=
     ") as tb1 "+
    "inner join TagOfSubject on tb1.TagOfSubject=TagOfSubject.Id "+
    "order by Name asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString);
   hdr=PCore.vect("Tag (Daftar)");
   hdrcols=PCore.vect(1);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListPicture){
   SubQueryBeforeId="select FileName from SubjectXPicture";
   SubIdFromMainColsName=PCore.refArr("Subject");
   SubQueryAfterId="order by FileName asc";
   SubColumnsType=PCore.primArr(CCore.TypeString);
   hdr=PCore.vect("File Gambar (Daftar)");
   hdrcols=PCore.vect(0);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListAddress){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select City, Address, Comment from SubjectXAddress";
   SubIdFromMainColsName=PCore.refArr("Subject");
   SubQueryAfterId=
     ") as tb1 "+
    "left join City on tb1.City=City.Id "+
    "order by Name asc, Address asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString);
   hdr=PCore.vect("Kota (Daftar)", "Alamat", "Keterangan");
   hdrcols=PCore.vect(3, 1, 2);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListContact){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select ContactType, Contact, Comment from SubjectXContact";
   SubIdFromMainColsName=PCore.refArr("Subject");
   SubQueryAfterId=
     ") as tb1 "+
    "left join ContactType on tb1.ContactType=ContactType.Id "+
    "order by Name asc, Contact asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString);
   hdr=PCore.vect("Tipe Kontak (Daftar)", "Kontak", "Keterangan");
   hdrcols=PCore.vect(3, 1, 2);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListBankAccount){
   SubQueryBeforeId=
    "select tb1.*, Name from "+
     "(select BankPlatform, BankAccount, Comment from SubjectXBankAccount";
   SubIdFromMainColsName=PCore.refArr("Subject");
   SubQueryAfterId=
     ") as tb1 "+
    "left join BankPlatform on tb1.BankPlatform=BankPlatform.Id "+
    "order by Name asc, BankAccount asc";
   SubColumnsType=PCore.primArr(CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeString);
   hdr=PCore.vect("Bank (Daftar)", "Rekening", "Keterangan");
   hdrcols=PCore.vect(3, 1, 2);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListItem && ShowListItemSupplier){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select tb2.*, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb1.*, Item.Name as 'ItemName' from "+
      "(select Item, BuyPrice, BuyPriceComment, UpdateDate, IsActive from ItemXSupplier";
   SubIdFromMainColsName=PCore.refArr("Supplier");
   SubQueryAfterId=
      ") as tb1 "+
     "inner join Item on tb1.Item=Item.Id group by tb1.Item) as tb2 "+
    "left join ItemXCategory on tb2.Item=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb2.Item"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(
    CCore.TypeLong, CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeBoolean, CCore.TypeString, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(7);}
   hdr.addElement("Nama Barang (Daftar)"); hdrcols.addElement(5);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   if(ShowBuyPrice){
    hdr.addElement("Harga Beli"); hdrcols.addElement(1);
    hdr.addElement("Keterangan Harga Beli"); hdrcols.addElement(2);
    hdr.addElement("Tgl Pembaruan"); hdrcols.addElement(3);
   }
   hdr.addElement("Aktif"); hdrcols.addElement(4);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  return PEtc.csvExport(Progress,
   Stm, Query, ColumnsType, Header, HeaderCols,
   List_SubQueryBeforeId, List_SubIdFromMainColsName, SubIdFromMainCols, List_SubQueryAfterId, List_SubColumnsType, List_SubHeader, List_SubHeaderCols,
   false, ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 
 public static long printTransCSV(
  OFormInformProgress Progress, Statement Stm,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator,
  
  long[] TransId, boolean IsPreTrans,
  
  boolean OptComment,
  boolean OptTransDate, boolean OptCreditDays, boolean OptBillDate, boolean OptRepaymentPeriod,
  boolean OptSubject, boolean OptSalesman,
  boolean OptCashOut, boolean OptCashOutComment, boolean OptCashIn, boolean OptCashInComment,
  boolean OptId, boolean OptIdExt, boolean OptImportant,
  boolean OptItemIn, boolean OptPayOut, boolean OptItemOut, boolean OptPayIn, boolean OptItemOutBasicPrice,

  boolean OptListItemIn, boolean OptListPayOut, boolean OptListItemOut, boolean OptListPayIn, boolean OptListItemOutBasicPrice,
  boolean OptListItemCategorized,
  
  boolean ShowListItemIn, boolean ShowListItemOut, boolean ShowBuyPrice){
  
  String Query, QueryCondition, QueryOrderBy;
  int[] ColumnsType;
  String[] Header;
  int[] HeaderCols;
  
  Vector<String> List_SubQueryBeforeId;
  Vector<String[]> List_SubIdFromMainColsName;
  int[] SubIdFromMainCols;
  Vector<String> List_SubQueryAfterId;
  Vector<int[]> List_SubColumnsType;
  Vector<String[]> List_SubHeader;
  Vector<int[]> List_SubHeaderCols;
  
  String SubQueryBeforeId;
  String[] SubIdFromMainColsName;
  String SubQueryAfterId;
  int[] SubColumnsType;
  Vector<String> hdr;
  Vector<Integer> hdrcols;
  
  String TbTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  String TransName=PText.getString(!IsPreTrans, "Transaksi", "Pra-Transaksi");
  
  // Query
  QueryCondition=""; if(TransId!=null){if(TransId.length!=0){QueryCondition=" where Id in("+PText.toString(TransId, 0, TransId.length, ",")+")";}}
  QueryOrderBy=" order by tb7.TransTypeName asc, tb7.TransDate desc, tb7.SubjectName asc, tb7.BillDate asc, tb7.Id desc";
  Query=
   "select tb7.*, Count("+TbTrans+"XPaymentIn.Price) as 'CountPaymentIn', Sum("+TbTrans+"XPaymentIn.Price) as 'PricePaymentIn' from "+
    "(select tb6.*, Count("+TbTrans+"XPayment.Price) as 'CountPaymentOut', Sum("+TbTrans+"XPayment.Price) as 'PricePaymentOut' from "+
     "(select tb5.Id, tb5.InfoIdExternal, tb5.IsImportant, tb5.Comment, tb5.TransType, tb5.TransTypeName, "+
       "tb5.TransDate, tb5.CreditDays, tb5.BillDate, tb5.RepaymentPeriodStart, tb5.RepaymentPeriodEnd, "+
       "tb5.Subject, tb5.SubjectName, tb5.Salesman, tb5.SalesmanName, "+
       "tb5.Cash, tb5.CashOutName, tb5.CashOutComment, tb5.CashIn, tb5.CashInName, tb5.CashInComment, "+
       "CountItemIn, PriceItemIn, Count(tb5.ItemOut_Price) as 'CountItemOut', Sum(tb5.ItemOut_Price) as 'PriceItemOut', Sum(tb5.ItemOut_Stock*BuyPriceEstimation) as 'BasicPriceItemOut' from "+
      "(select tb4.*, "+TbTrans+"XItemOut.Item as 'ItemOut_Item', "+TbTrans+"XItemOut.Stock as 'ItemOut_Stock', "+TbTrans+"XItemOut.Price as 'ItemOut_Price' from "+
        "(select tb3.*, Count("+TbTrans+"XItemIn.Price) as 'CountItemIn', Sum("+TbTrans+"XItemIn.Price) as 'PriceItemIn' from "+
         "(select tb2.*, Subject.Name as 'SalesmanName', Cash.Name as 'CashInName' from "+
          "(select tb1.*, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName', Cash.Name as 'CashOutName' from "+
            "(select "+TbTrans+".*, if(CreditDays is "+CCore.vNull+", "+CCore.vNull+", Date_Add(TransDate, Interval ifnull(CreditDays, 0) Day)) as 'BillDate' "+
            "from "+TbTrans+QueryCondition+") as tb1 "+
          "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id left join Cash on tb1.Cash=Cash.Id) as tb2 "+
         "left join Subject on tb2.Salesman=Subject.Id left join Cash on tb2.CashIn=Cash.Id) as tb3 "+
        "left join "+TbTrans+"XItemIn on tb3.Id="+TbTrans+"XItemIn."+TbTrans+" group by tb3.Id) as tb4 "+
      "left join "+TbTrans+"XItemOut on tb4.Id="+TbTrans+"XItemOut."+TbTrans+") as tb5 "+
     "left join Item on tb5.ItemOut_Item=Item.Id group by tb5.Id) as tb6 "+
    "left join "+TbTrans+"XPayment on tb6.Id="+TbTrans+"XPayment."+TbTrans+" group by tb6.Id) as tb7 "+
   "left join "+TbTrans+"XPaymentIn on tb7.Id="+TbTrans+"XPaymentIn."+TbTrans+" group by tb7.Id "+
			QueryOrderBy;
  
  // ColumnsType
  ColumnsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString, CCore.TypeInteger, CCore.TypeString,
   CCore.TypeDate, CCore.TypeInteger, CCore.TypeDate, CCore.TypeDate, CCore.TypeDate,
   CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeInteger, CCore.TypeString, CCore.TypeString, CCore.TypeInteger, CCore.TypeString, CCore.TypeString,
   CCore.TypeInteger, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeInteger, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeDouble);
  
  // Header
  hdr=new Vector(); hdrcols=new Vector();
  hdr.addElement("Jenis Trans"); hdrcols.addElement(5);
  if(OptTransDate){hdr.addElement("Tgl"); hdrcols.addElement(6);}
  if(OptCreditDays){hdr.addElement("Lama Kredit"); hdrcols.addElement(7);}
  if(OptBillDate){hdr.addElement("Tgl Tagih"); hdrcols.addElement(8);}
  if(OptRepaymentPeriod){hdr.addElement("Cicil Awal"); hdrcols.addElement(9); hdr.addElement("Cicil Akhir"); hdrcols.addElement(10);}
  if(OptSubject){hdr.addElement("Subjek"); hdrcols.addElement(12);}
  if(OptSalesman){hdr.addElement("Salesman"); hdrcols.addElement(14);}
  if(OptCashOut){hdr.addElement("Kas Tunai Klr"); hdrcols.addElement(16);}
  if(OptCashOutComment){hdr.addElement("Ket. Kas Tunai Klr"); hdrcols.addElement(17);}
  if(OptCashIn){hdr.addElement("Kas Tunai Msk"); hdrcols.addElement(19);}
  if(OptCashInComment){hdr.addElement("Ket. Kas Tunai Msk"); hdrcols.addElement(20);}
  if(OptId){hdr.addElement("Id "+TransName); hdrcols.addElement(0);}
  if(OptIdExt){hdr.addElement("{Id-External}"); hdrcols.addElement(1);}
  if(OptImportant){hdr.addElement("Penting"); hdrcols.addElement(2);}
  if(OptItemIn){hdr.addElement("Jml Brg Msk"); hdrcols.addElement(21); hdr.addElement("Hrg Brg Msk"); hdrcols.addElement(22);}
  if(OptPayOut){hdr.addElement("{Jml Byr Klr}"); hdrcols.addElement(26); hdr.addElement("{Hrg Byr Klr}"); hdrcols.addElement(27);}
  if(OptItemOut){hdr.addElement("Jml Brg Klr"); hdrcols.addElement(23); hdr.addElement("Hrg Brg Klr"); hdrcols.addElement(24);}
  if(OptItemOutBasicPrice && ShowBuyPrice){hdr.addElement("{HPP}"); hdrcols.addElement(25);}
  if(OptPayIn){hdr.addElement("{Jml Byr Msk}"); hdrcols.addElement(28); hdr.addElement("{Hrg Byr Msk}"); hdrcols.addElement(29);}
  if(OptComment){hdr.addElement("Komentar"); hdrcols.addElement(3);}
  Header=PCore.refArr_VectStr(hdr); HeaderCols=PCore.primArr_VectInt(hdrcols);
  
  // SubQueries
  List_SubQueryBeforeId=new Vector(); List_SubIdFromMainColsName=new Vector(); SubIdFromMainCols=PCore.primArr(0); List_SubQueryAfterId=new Vector();
  List_SubColumnsType=new Vector(); List_SubHeader=new Vector(); List_SubHeaderCols=new Vector();
  
  if(OptListItemIn && ShowListItemIn){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select tb3.*, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
      "(select tb1.*, Item.Name as 'ItemName', "+genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit from "+
       "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
       "from "+TbTrans+"XItemIn";
   SubIdFromMainColsName=PCore.refArr(TbTrans);
   SubQueryAfterId=
       ") as tb1 "+
      "inner join Item on tb1.TransItem=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
    "left join ItemXCategory on tb3.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.TransItem"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeBoolean,
    CCore.TypeString, CCore.TypeString, CCore.TypeInteger, CCore.TypeString, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(11);}
   hdr.addElement("Barang Masuk (Daftar)"); hdrcols.addElement(7);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   hdr.addElement("Qty"); hdrcols.addElement(1);
   hdr.addElement(""); hdrcols.addElement(9);
   hdr.addElement("Hrg Satuan"); hdrcols.addElement(3);
   hdr.addElement("Hrg Total"); hdrcols.addElement(2);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListItemOut && ShowListItemOut){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select tb3.*, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
      "(select tb1.*, Item.Name as 'ItemName', "+genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit, BuyPriceEstimation, TransItemQty*BuyPriceEstimation as 'TransItemPriceTotalBasic' from "+
       "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
       "from "+TbTrans+"XItemOut";
   SubIdFromMainColsName=PCore.refArr(TbTrans);
   SubQueryAfterId=
       ") as tb1 "+
      "inner join Item on tb1.TransItem=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
    "left join ItemXCategory on tb3.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.TransItem"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeBoolean,
    CCore.TypeString, CCore.TypeString, CCore.TypeInteger, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(13);}
   hdr.addElement("Barang Keluar (Daftar)"); hdrcols.addElement(7);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   hdr.addElement("Qty"); hdrcols.addElement(1);
   hdr.addElement(""); hdrcols.addElement(11);
   hdr.addElement("Hrg Satuan"); hdrcols.addElement(3);
   hdr.addElement("Hrg Total"); hdrcols.addElement(2);
   if(OptListItemOutBasicPrice && ShowBuyPrice){hdr.addElement("HPP"); hdrcols.addElement(10);}
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListPayOut){
   SubQueryBeforeId=
    "select tb1.*, Cash.Name as 'CashName' from "+
     "(select PaymentDate, Cash, Price, Comment from "+TbTrans+"XPayment";
   SubIdFromMainColsName=PCore.refArr(TbTrans);
   SubQueryAfterId=
     ") as tb1 "+
    "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, Cash.Name asc;";
   SubColumnsType=PCore.primArr(CCore.TypeDate, CCore.TypeInteger, CCore.TypeDouble, CCore.TypeString, CCore.TypeString);
   hdr=PCore.vect("Tgl Bayar Klr (Daftar)", "Kas Kredit Klr", "Jumlah", "Keterangan");
   hdrcols=PCore.vect(0, 4, 2, 3);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  if(OptListPayIn){
   SubQueryBeforeId=
    "select tb1.*, Cash.Name as 'CashName' from "+
     "(select PaymentDate, Cash, Price, Comment from "+TbTrans+"XPaymentIn";
   SubIdFromMainColsName=PCore.refArr(TbTrans);
   SubQueryAfterId=
     ") as tb1 "+
    "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, Cash.Name asc;";
   SubColumnsType=PCore.primArr(CCore.TypeDate, CCore.TypeInteger, CCore.TypeDouble, CCore.TypeString, CCore.TypeString);
   hdr=PCore.vect("Tgl Bayar Msk (Daftar)", "Kas Kredit Msk", "Jumlah", "Keterangan");
   hdrcols=PCore.vect(0, 4, 2, 3);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  return PEtc.csvExport(Progress,
   Stm, Query, ColumnsType, Header, HeaderCols,
   List_SubQueryBeforeId, List_SubIdFromMainColsName, SubIdFromMainCols, List_SubQueryAfterId, List_SubColumnsType, List_SubHeader, List_SubHeaderCols,
   false, ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 
 public static long printConvRuleCSV(
  OFormInformProgress Progress, Statement Stm,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator,
  
  long[] Ids,
  
  boolean OptIsActive, boolean OptLastUpdate,

  boolean OptListItem, boolean OptListItemCategorized){
  
  String Query, QueryCondition, QueryOrderBy;
  int[] ColumnsType;
  String[] Header;
  int[] HeaderCols;
  
  Vector<String> List_SubQueryBeforeId;
  Vector<String[]> List_SubIdFromMainColsName;
  int[] SubIdFromMainCols;
  Vector<String> List_SubQueryAfterId;
  Vector<int[]> List_SubColumnsType;
  Vector<String[]> List_SubHeader;
  Vector<int[]> List_SubHeaderCols;
  
  String SubQueryBeforeId;
  String[] SubIdFromMainColsName;
  String SubQueryAfterId;
  int[] SubColumnsType;
  Vector<String> hdr;
  Vector<Integer> hdrcols;
  
  // Query
  QueryCondition=""; if(Ids!=null){if(Ids.length!=0){QueryCondition=" where Id in("+PText.toString(Ids, 0, Ids.length, ",")+")";}}
  QueryOrderBy=" order by tb2.Name asc";
  Query=
   "select tb2.*, Count(RuleOfConvXSideB.Item) as 'ItemsBCount' from "+
    "(select tb1.*, Count(RuleOfConvXSideA.Item) as 'ItemsACount' from "+
     "(select Id, Name, IsActive, LastUpdate from RuleOfConv"+QueryCondition+") as tb1 "+
    "left join RuleOfConvXSideA on tb1.Id=RuleOfConvXSideA.RuleOfConv group by tb1.Id) as tb2 "+
   "left join RuleOfConvXSideB on tb2.Id=RuleOfConvXSideB.RuleOfConv group by tb2.Id "+
			QueryOrderBy;
  
  // ColumnsType
  ColumnsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeDate, CCore.TypeInteger, CCore.TypeInteger);
  
  // Header
  hdr=new Vector(); hdrcols=new Vector();
  hdr.addElement("Nama"); hdrcols.addElement(1);
  if(OptIsActive){hdr.addElement("Aktif"); hdrcols.addElement(2);}
  if(OptLastUpdate){hdr.addElement("Tgl Update"); hdrcols.addElement(3);}
  Header=PCore.refArr_VectStr(hdr); HeaderCols=PCore.primArr_VectInt(hdrcols);
  
  // SubQueries
  List_SubQueryBeforeId=new Vector(); List_SubIdFromMainColsName=new Vector(); SubIdFromMainCols=PCore.primArr(0); List_SubQueryAfterId=new Vector();
  List_SubColumnsType=new Vector(); List_SubHeader=new Vector(); List_SubHeaderCols=new Vector();
  
  // List Items Out
  if(OptListItem){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select ItemId, ItemName, Qty, StockUnitId, StockUnitName, IsUpdate, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, StockUnit.Name as 'StockUnitName' from "+
      "(select tb1.*, Name as 'ItemName', StockUnit as 'StockUnitId', UpdateStockOnTransaction as 'IsUpdate' from "+
       "(select Item as 'ItemId', Stock as 'Qty' from RuleOfConvXSideA";
   SubIdFromMainColsName=PCore.refArr("RuleOfConv");
   SubQueryAfterId=
       ") as tb1 "+
      "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnitId=StockUnit.Id) as tb3 "+
    "left join ItemXCategory on tb3.ItemId=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.ItemId"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble,
    CCore.TypeInteger, CCore.TypeString, CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(7);}
   hdr.addElement("Barang Sisi A (Daftar)"); hdrcols.addElement(1);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   hdr.addElement("Qty"); hdrcols.addElement(2);
   hdr.addElement(""); hdrcols.addElement(4);
   hdr.addElement("Diperbarui"); hdrcols.addElement(5);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  // List Items In
  if(OptListItem){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select ItemId, ItemName, Qty, StockUnitId, StockUnitName, IsUpdate, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, StockUnit.Name as 'StockUnitName' from "+
      "(select tb1.*, Name as 'ItemName', StockUnit as 'StockUnitId', UpdateStockOnTransaction as 'IsUpdate' from "+
       "(select Item as 'ItemId', Stock as 'Qty' from RuleOfConvXSideB";
   SubIdFromMainColsName=PCore.refArr("RuleOfConv");
   SubQueryAfterId=
       ") as tb1 "+
      "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnitId=StockUnit.Id) as tb3 "+
    "left join ItemXCategory on tb3.ItemId=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.ItemId"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble,
    CCore.TypeInteger, CCore.TypeString, CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(7);}
   hdr.addElement("Barang Sisi B (Daftar)"); hdrcols.addElement(1);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   hdr.addElement("Qty"); hdrcols.addElement(2);
   hdr.addElement(""); hdrcols.addElement(4);
   hdr.addElement("Diperbarui"); hdrcols.addElement(5);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  return PEtc.csvExport(Progress,
   Stm, Query, ColumnsType, Header, HeaderCols,
   List_SubQueryBeforeId, List_SubIdFromMainColsName, SubIdFromMainCols, List_SubQueryAfterId, List_SubColumnsType, List_SubHeader, List_SubHeaderCols,
   false, ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 
 public static long printConvertingCSV(
  OFormInformProgress Progress, Statement Stm,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator,
  
  long[] Ids,

  int OrderMode,
  boolean OptListItem, boolean OptListItemCategorized){
  
  String Query, QueryCondition, QueryOrderBy;
  int[] ColumnsType;
  String[] Header;
  int[] HeaderCols;
  
  Vector<String> List_SubQueryBeforeId;
  Vector<String[]> List_SubIdFromMainColsName;
  int[] SubIdFromMainCols;
  Vector<String> List_SubQueryAfterId;
  Vector<int[]> List_SubColumnsType;
  Vector<String[]> List_SubHeader;
  Vector<int[]> List_SubHeaderCols;
  
  String SubQueryBeforeId;
  String[] SubIdFromMainColsName;
  String SubQueryAfterId;
  int[] SubColumnsType;
  Vector<String> hdr;
  Vector<Integer> hdrcols;
  
  StringBuilder strb;
  String Order_Date, Order_Reason, Order_Rule;
  String[] QueryColumns;
  int[] Cols=null;
  int temp;
  
  // Query
  QueryCondition=""; if(!PCore.isArrayEmpty(Ids, true)){QueryCondition=" where Id in("+PText.toString(Ids, 0, Ids.length, ",")+")";}
  
  strb=new StringBuilder();
  strb.append(" order by");
  Order_Date   = " ConvDate desc";
  Order_Reason = " ReasonOfConvName asc";
  Order_Rule   = " RuleOfConvName asc";
  switch(OrderMode){
   case 0 : strb.append(Order_Date+","+Order_Rule+","+Order_Reason); break;
   case 1 : strb.append(Order_Date+","+Order_Reason+","+Order_Rule); break;
   case 2 : strb.append(Order_Rule+","+Order_Date+","+Order_Reason); break;
   case 3 : strb.append(Order_Rule+","+Order_Reason+","+Order_Date); break;
   case 4 : strb.append(Order_Reason+","+Order_Date+","+Order_Rule); break;
   case 5 : strb.append(Order_Reason+","+Order_Rule+","+Order_Date); break;
  }
  strb.append(", tb4.Id desc");
  QueryOrderBy=strb.toString();
  
  Query=
   "select tb4.Id, ConvDate, ReasonOfConv, ReasonOfConvName, "+
   "RuleOfConv, RuleOfConvName, IsActive, LastUpdate, "+
   "if(RuleOfConvDirection,"+CApp.ConvRuleDirForwardSQL()+","+CApp.ConvRuleDirBackwardSQL()+"), RuleOfConvCount, ItemOutCount, Count(ConvXItemIn.Conv) as 'ItemInCount' from "+
    "(select tb3.*, Count(ConvXItemOut.Conv) as 'ItemOutCount' from "+
     "(select tb2.*, RuleOfConv.Name as 'RuleOfConvName', IsActive, LastUpdate from "+
      "(select tb1.*, ReasonOfConv.Name as 'ReasonOfConvName' from "+
       "(select Conv.* from Conv"+QueryCondition+") as tb1 "+
      "left join ReasonOfConv on tb1.ReasonOfConv=ReasonOfConv.Id) as tb2 "+
     "inner join RuleOfConv on tb2.RuleOfConv=RuleOfConv.Id) as tb3 "+
    "left join ConvXItemOut on tb3.Id=ConvXItemOut.Conv group by tb3.Id) as tb4 "+
   "left join ConvXItemIn on tb4.Id=ConvXItemIn.Conv group by tb4.Id"+
			QueryOrderBy;
  
  QueryColumns=PCore.refArr(
   "Id Konversi", "Tgl Konversi", "Id Alasan Konversi", "Alasan Konversi",
   "Id Aturan Konversi", "Aturan Konversi", "Aktif", "Tgl Update",
   "Arah", "Jumlah", "Total Jumlah Barang Keluar", "Total Jumlah Barang Masuk");
  
  // ColumnsType
  ColumnsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeDate, CCore.TypeInteger, CCore.TypeString,
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeDate,
   CCore.TypeString, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeInteger);
  
  // Header
  switch(OrderMode){
   case 0 : Cols=PCore.primArr(1, 5, 3, 8, 9, 10, 11); break;
   case 1 : Cols=PCore.primArr(1, 3, 5, 8, 9, 10, 11); break;
   case 2 : Cols=PCore.primArr(5, 1, 3, 8, 9, 10, 11); break;
   case 3 : Cols=PCore.primArr(5, 3, 1, 8, 9, 10, 11); break;
   case 4 : Cols=PCore.primArr(3, 1, 5, 8, 9, 10, 11); break;
   case 5 : Cols=PCore.primArr(3, 5, 1, 8, 9, 10, 11); break;
  }
  
  hdr=new Vector(); hdrcols=new Vector();
  temp=0;
  do{
   hdr.addElement(QueryColumns[Cols[temp]]);
   hdrcols.addElement(Cols[temp]);
   temp=temp+1;
  }while(temp!=Cols.length);
  Header=PCore.refArr_VectStr(hdr); HeaderCols=PCore.primArr_VectInt(hdrcols);
  
  // SubQueries
  List_SubQueryBeforeId=new Vector(); List_SubIdFromMainColsName=new Vector(); SubIdFromMainCols=PCore.primArr(0); List_SubQueryAfterId=new Vector();
  List_SubColumnsType=new Vector(); List_SubHeader=new Vector(); List_SubHeaderCols=new Vector();
  
  // List Items Out
  if(OptListItem){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select ItemId, ItemName, Qty, StockUnitId, StockUnitName, IsUpdate, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, StockUnit.Name as 'StockUnitName' from "+
      "(select tb1.*, Name as 'ItemName', StockUnit as 'StockUnitId', UpdateStockOnTransaction as 'IsUpdate' from "+
       "(select Item as 'ItemId', Stock as 'Qty' from ConvXItemOut";
   SubIdFromMainColsName=PCore.refArr("Conv");
   SubQueryAfterId=
       ") as tb1 "+
      "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnitId=StockUnit.Id) as tb3 "+
    "left join ItemXCategory on tb3.ItemId=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.ItemId"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble,
    CCore.TypeInteger, CCore.TypeString, CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(7);}
   hdr.addElement("Barang Keluar (Daftar)"); hdrcols.addElement(1);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   hdr.addElement("Qty"); hdrcols.addElement(2);
   hdr.addElement(""); hdrcols.addElement(4);
   hdr.addElement("Diperbarui"); hdrcols.addElement(5);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  // List Items In
  if(OptListItem){
   QueryOrderBy=" order by"+PText.getString(!OptListItemCategorized, " ItemName asc", " CategoryOfItem.Name asc, ItemName asc");
   SubQueryBeforeId=
    "select ItemId, ItemName, Qty, StockUnitId, StockUnitName, IsUpdate, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb2.*, StockUnit.Name as 'StockUnitName' from "+
      "(select tb1.*, Name as 'ItemName', StockUnit as 'StockUnitId', UpdateStockOnTransaction as 'IsUpdate' from "+
       "(select Item as 'ItemId', Stock as 'Qty' from ConvXItemIn";
   SubIdFromMainColsName=PCore.refArr("Conv");
   SubQueryAfterId=
       ") as tb1 "+
      "inner join Item on tb1.ItemId=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnitId=StockUnit.Id) as tb3 "+
    "left join ItemXCategory on tb3.ItemId=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb3.ItemId"+
    QueryOrderBy;
   SubColumnsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble,
    CCore.TypeInteger, CCore.TypeString, CCore.TypeBoolean, CCore.TypeInteger, CCore.TypeString);
   hdr=new Vector(); hdrcols=new Vector();
   if(OptListItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(7);}
   hdr.addElement("Barang Masuk (Daftar)"); hdrcols.addElement(1);
   hdr.addElement("Id Barang"); hdrcols.addElement(0);
   hdr.addElement("Qty"); hdrcols.addElement(2);
   hdr.addElement(""); hdrcols.addElement(4);
   hdr.addElement("Diperbarui"); hdrcols.addElement(5);
   
   List_SubQueryBeforeId.addElement(SubQueryBeforeId); List_SubIdFromMainColsName.addElement(SubIdFromMainColsName); List_SubQueryAfterId.addElement(SubQueryAfterId);
   List_SubColumnsType.addElement(SubColumnsType); List_SubHeader.addElement(PCore.refArr_VectStr(hdr)); List_SubHeaderCols.addElement(PCore.primArr_VectInt(hdrcols));
  }
  
  return PEtc.csvExport(Progress,
   Stm, Query, ColumnsType, Header, HeaderCols,
   List_SubQueryBeforeId, List_SubIdFromMainColsName, SubIdFromMainCols, List_SubQueryAfterId, List_SubColumnsType, List_SubHeader, List_SubHeaderCols,
   false, ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 
 public static long printRevStockCSV(
  OFormInformProgress Progress, Statement Stm,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator,
  
  long[] RevStockId,
  
  int OrderMode, boolean ItemCategorized){
  
  String Query, QueryCondition, QueryOrderBy;
  int[] ColumnsType;
  String[] QueryColumns;
  String[] Header;
  int[] HeaderCols;
  
  Vector<String> hdr;
  Vector<Integer> hdrcols;
  StringBuilder strb;
  boolean first;
  
  String Order_Date, Order_Reason, Order_Item;
  int temp;
  int PosName=0;
  int[] Cols=null;
  
  // Query
  QueryCondition=""; if(RevStockId!=null){if(RevStockId.length!=0){QueryCondition=" where Id in("+PText.toString(RevStockId, 0, RevStockId.length, ",")+")";}}
  
  strb=new StringBuilder(); first=true;
  strb.append(" order by");
  /*
  if(OrderByRevDate){if(first){first=false;}else{strb.append(",");} strb.append(" RevisiDate desc");}
  if(ItemCategorized){if(first){first=false;}else{strb.append(",");} strb.append(" CategoryOfItem.Name asc");}
  if(first){first=false;}else{strb.append(",");} strb.append(" ItemName asc");
  if(!OrderByRevDate){if(first){first=false;}else{strb.append(",");} strb.append(" RevisiDate desc");}
  if(first){first=false;}else{strb.append(",");} strb.append(" tb4.Id desc");
  */
  Order_Date   = " RevisiDate desc";
  Order_Reason = " ReasonOfRevisiName asc";
  Order_Item   = " ItemName asc"; if(ItemCategorized){Order_Item=" CategoryName asc,"+Order_Item;}
  switch(OrderMode){
   case 0 : strb.append(Order_Date+","+Order_Item+","+Order_Reason); break;
   case 1 : strb.append(Order_Date+","+Order_Reason+","+Order_Item); break;
   case 2 : strb.append(Order_Item+","+Order_Date+","+Order_Reason); break;
   case 3 : strb.append(Order_Item+","+Order_Reason+","+Order_Date); break;
   case 4 : strb.append(Order_Reason+","+Order_Date+","+Order_Item); break;
   case 5 : strb.append(Order_Reason+","+Order_Item+","+Order_Date); break;
  }
  strb.append(", tb4.Id desc");
  QueryOrderBy=strb.toString();
  
  Query=
   "select tb4.*, CategoryOfItem.Id as 'CategoryId', Min(CategoryOfItem.Name) as 'CategoryName' from "+
    "(select tb3.*, StockUnit.Name as 'StockUnitName' from "+
     "(select tb2.*, Item.Name as 'ItemName', Item.StockUnit, Item.UpdateStockOnTransaction from "+
      "(select tb1.*, ReasonOfRevisi.Name as 'ReasonOfRevisiName' from "+
       "(select Id, RevisiDate, ReasonOfRevisi, Item, StockOld, StockNew, (StockNew-StockOld) as 'Different' from RevisiStock"+QueryCondition+") as tb1 "+
      "left join ReasonOfRevisi on tb1.ReasonOfRevisi=ReasonOfRevisi.Id) as tb2 "+
     "inner join Item on tb2.Item=Item.Id) as tb3 "+
    "left join StockUnit on tb3.StockUnit=StockUnit.Id) as tb4 "+
   "left join ItemXCategory on tb4.Item=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.Id"+
			QueryOrderBy;
  
  QueryColumns=PCore.refArr(
   "Id Revisi", "Tgl Revisi", "Id Alasan Revisi", "Id Barang", "Stok Lama", "Stok Baru", "Selisih",
   "Alasan Revisi", "Nama Barang", "Id Satuan Stok", "Diperbarui", "Satuan Stok", "Id Kategori Barang", "Kategori Barang");
  
  // ColumnsType
  ColumnsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeDate, CCore.TypeInteger, CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeString, CCore.TypeString, CCore.TypeInteger, CCore.TypeBoolean, CCore.TypeString, CCore.TypeInteger, CCore.TypeString);
  
  // Header
  /*
  hdr=new Vector(); hdrcols=new Vector();
  if(OrderByRevDate){hdr.addElement("Tgl Revisi"); hdrcols.addElement(1);}
  if(ItemCategorized){hdr.addElement("Kategori Barang"); hdrcols.addElement(11);}
  hdr.addElement("Nama Barang"); hdrcols.addElement(6); hdr.addElement("Id Barang"); hdrcols.addElement(2);
  if(!OrderByRevDate){hdr.addElement("Tgl Revisi"); hdrcols.addElement(1);}
  hdr.addElement("Stok Lama"); hdrcols.addElement(3);
  hdr.addElement("Stok Baru"); hdrcols.addElement(4);
  hdr.addElement("Selisih"); hdrcols.addElement(5);
  hdr.addElement("Satuan Stok"); hdrcols.addElement(9);
  */
  switch(OrderMode){
   case 0 : Cols=PCore.primArr(1, 8, 3, 7, 4, 5, 6, 11); PosName=1; break;
   case 1 : Cols=PCore.primArr(1, 7, 8, 3, 4, 5, 6, 11); PosName=2; break;
   case 2 : Cols=PCore.primArr(8, 3, 1, 7, 4, 5, 6, 11); PosName=0; break;
   case 3 : Cols=PCore.primArr(8, 3, 7, 1, 4, 5, 6, 11); PosName=0; break;
   case 4 : Cols=PCore.primArr(7, 1, 8, 3, 4, 5, 6, 11); PosName=2; break;
   case 5 : Cols=PCore.primArr(7, 8, 3, 1, 4, 5, 6, 11); PosName=1; break;
  }
  if(ItemCategorized){Cols=PCore.insert(Cols, PosName, 13);}
  
  hdr=new Vector(); hdrcols=new Vector();
  temp=0;
  do{
   hdr.addElement(QueryColumns[Cols[temp]]);
   hdrcols.addElement(Cols[temp]);
   temp=temp+1;
  }while(temp!=Cols.length);
  Header=PCore.refArr_VectStr(hdr); HeaderCols=PCore.primArr_VectInt(hdrcols);
  
  return PEtc.csvExport(Progress, Stm, Query, ColumnsType, Header, HeaderCols, ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 
 public static String getQueryOfItem_Picture(String TbOp, long[] Items){
  String ret=null;
  StringBuilder Con_TblItem;
  boolean ConFirst_TblItem;
  
  //
  Con_TblItem=new StringBuilder(); ConFirst_TblItem=true;
  
  if(!PCore.isArrayEmpty(Items, true)){
   if(ConFirst_TblItem){Con_TblItem.append(" where"); ConFirst_TblItem=false;}else{Con_TblItem.append(" and");}
   Con_TblItem.append(" Id in ("+PText.toString(Items, 0, Items.length, ",")+")");
  }
  
  //
  ret=
   "select "+TbOp+"_1.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
    "(select Id as 'ItemId' from Item"+Con_TblItem.toString()+") as "+TbOp+"_1 "+
   "left join ItemXPicture on "+TbOp+"_1.ItemId=ItemXPicture.Item group by "+TbOp+"_1.ItemId";
  
  return ret;
 }
 public static String getQueryOfItem_Category(String TbOp, long[] Items){
  String ret=null;
  StringBuilder Con_TblItem;
  boolean ConFirst_TblItem;
  
  //
  Con_TblItem=new StringBuilder(); ConFirst_TblItem=true;
  
  if(!PCore.isArrayEmpty(Items, true)){
   if(ConFirst_TblItem){Con_TblItem.append(" where"); ConFirst_TblItem=false;}else{Con_TblItem.append(" and");}
   Con_TblItem.append(" Id in ("+PText.toString(Items, 0, Items.length, ",")+")");
  }
  
  //
  ret=
   "select "+TbOp+"_1.*, Min(CategoryOfItem.Name) as 'CategoryOfItemName' from "+
    "(select Id as 'ItemId' from Item"+Con_TblItem.toString()+") as "+TbOp+"_1 "+
   "left join ItemXCategory on "+TbOp+"_1.ItemId=ItemXCategory.Item "+
   "left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by "+TbOp+"_1.ItemId";
  
  return ret;
 }
 public static String getQueryOfSubject_Picture(String TbOp, long[] Subjects){
  String ret=null;
  StringBuilder Con_TblSubject;
  boolean ConFirst_TblSubject;
  
  //
  Con_TblSubject=new StringBuilder(); ConFirst_TblSubject=true;
  
  if(!PCore.isArrayEmpty(Subjects, true)){
   if(ConFirst_TblSubject){Con_TblSubject.append(" where"); ConFirst_TblSubject=false;}else{Con_TblSubject.append(" and");}
   Con_TblSubject.append(" Id in ("+PText.toString(Subjects, 0, Subjects.length, ",")+")");
  }
  
  //
  ret=
   "select "+TbOp+"_1.*, Min(SubjectXPicture.FileName) as 'PictureFile' from "+
    "(select Id as 'SubjectId' from Subject"+Con_TblSubject.toString()+") as "+TbOp+"_1 "+
   "left join SubjectXPicture on "+TbOp+"_1.SubjectId=SubjectXPicture.Subject group by "+TbOp+"_1.SubjectId";
  
  return ret;
 }
 
 public static void viewFormInfo(Object AKey, XFormPreview FPreview){
  if(!FPreview.proceed(AKey)){JOptionPane.showMessageDialog(null, "Tidak dapat melihat ket. "+FPreview.getName()+" !"); return;}
  if(FPreview.showForm()==false){return;}
 }
 public static void viewFormInfo_FromTable(JTable Tbl, OCustomTableModel TableMdl, int Column, XFormPreview FPreview){
  int[] rows;
  Object AKey;
  
  rows=Tbl.getSelectedRows();
  if(rows.length==0){return;}
  
  AKey=TableMdl.Mdl.Rows.elementAt(rows[0])[Column];
  if(AKey==null){return;}
  
  viewFormInfo(AKey, FPreview);
 }
 public static void viewFormInfo_FromComboBox(JComboBox CmB, OCustomComboBoxModel ComboMdl, int Column, XFormPreview FPreview){
  int SelectedIndex;
  Object AKey;
  
  SelectedIndex=CmB.getSelectedIndex(); if(SelectedIndex==-1){return;}
  
  AKey=ComboMdl.Mdl.Rows.elementAt(SelectedIndex)[Column];
  if(AKey==null){return;}
  
  viewFormInfo(AKey, FPreview);
 }
 
 public static void viewFormInfo_SpecificTrans_FromTable(JTable Tbl, OCustomTableModel TableMdl, int Column, XFormPreview FPreview,
  boolean IsPreTrans, boolean IsPending){
  int[] rows;
  Object AKey;
  
  rows=Tbl.getSelectedRows();
  if(rows.length==0){return;}
  
  AKey=TableMdl.Mdl.Rows.elementAt(rows[0])[Column];
  if(AKey==null){return;}
  
  viewFormInfo(PCore.objArrVariant(IsPreTrans, IsPending, AKey), FPreview);
 }
 
 public static void viewFormInfo_SpecificConvertRule_FromTable(JTable Tbl, OCustomTableModel TableMdl, int Column, XFormPreview FPreview,
  boolean IsFromConverting){
  int[] rows;
  Object AKey;
  
  rows=Tbl.getSelectedRows();
  if(rows.length==0){return;}
  
  AKey=TableMdl.Mdl.Rows.elementAt(rows[0])[Column];
  if(AKey==null){return;}
  
  viewFormInfo(PCore.objArrVariant(IsFromConverting, AKey), FPreview);
 }
 
 public static void tempListAdd(XFormDialog Fm, OFormWithTempList FmTL, long[] DataIds, boolean IsAdd){
  FmTL.fillTempList(DataIds, IsAdd);
 }
 public static void tempListSave(XFormDialog Fm, OFormWithTempList FmTL,
  OQuickListOfLong TempList, JFileChooser FileChooser, FileFilter FlFilter, OFormInformProgress Progress){
  File f;
  String fstr;
  
  FileChooser.setFileFilter(FlFilter);
  FileChooser.setMultiSelectionEnabled(false);
  if(FileChooser.showSaveDialog(Fm)!=JFileChooser.APPROVE_OPTION){return;}
   
  f=FileChooser.getSelectedFile();
  if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
   JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
   return;
  }
  try{
   fstr=f.getCanonicalPath();
   if(PFile.compareIgnoreCaseExtension(fstr, "report")==false){
    f=new File(fstr+".report");
   }
  }
  catch(Exception E){JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !"); return;}
  if(!PEtc.saveIdToFile(TempList.getElements(), f, false, Progress, true, Fm, "Menulis Data DaftarKu")){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data report ke file !");
  }
 }
 public static void tempListLoad(XFormDialog Fm, OFormWithTempList FmTL,
  OQuickListOfLong TempList, JFileChooser FileChooser, FileFilter FlFilter, OFormInformProgress Progress){
  File f;
  long[] tlist;
  
  FileChooser.setFileFilter(FlFilter);
  FileChooser.setMultiSelectionEnabled(false);
  if(FileChooser.showDialog(Fm, "Load")!=JFileChooser.APPROVE_OPTION){return;}
  f=FileChooser.getSelectedFile();
  if(!PFile.compareIgnoreCaseExtension(f.getName(), "report")){
   JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+"Ekstensi file harus '.report'.");
   return;
  }
  tlist=PEtc.loadIdFromFile(f, false,
   Progress, true, Fm, "Membaca Data DaftarKu");
  if(tlist==null){JOptionPane.showMessageDialog(null, "Gagal membaca data report dari file !"); return;}
  
  FmTL.clearTempList();
  FmTL.fillTempList(tlist, true);
 }
 public static void tempListClear(XFormDialog Fm, OFormWithTempList FmTL){
  if(JOptionPane.showConfirmDialog(null, "Kosongkan data pada 'Daftarku' ?", "Konfirmasi Pengosongan Data Pada 'Daftarku'",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  FmTL.clearTempList();
 }
 
 public static String genTransItemNameDbCol(String DbCol_GenName, String DbCol_ItemName, String DbCol_TransItemComment){
  return "concat("+DbCol_ItemName+", if("+DbCol_TransItemComment+" is null or "+DbCol_TransItemComment+"='', '', concat(' {', "+DbCol_TransItemComment+", '}'))) as '"+DbCol_GenName+"'";
 }
 public static String genTransItemName(String ItemName, String TransItemComment){
  String ret;
  
  ret=ItemName+PText.getString(TransItemComment, "", " {"+TransItemComment+"}", true);
  
  return ret;
 }
 public static String getReadWriteCsvInfo(boolean IsRead){
  StringBuilder ret=new StringBuilder();
  
  ret.append(
   PText.getString(!IsRead, "Mengekspor", "Dapat membaca")+" file CSV dengan format sbb :"+
    "\n- Charset = UTF-8"+
    "\n- Field Delimiter = kutip ganda (\") , kutip tunggal (')"+
    "\n- Fields Separator = koma (,) , semicolon (;) , tab"+
    "\n- Records Separator = enter"+
    "\n- Record (baris) ke-1 sebagai 'header tabel', record ke-2 dst sebagai 'isi data tabel'."
  );
  if(IsRead){
   ret.append(
    "\n- Impor data akan dilakukan mulai dari record ke-2 dst."+
    "\n- Semua record harus memiliki jumlah field (kolom) yang sama."+
    "\n- Sebuah field boleh multi baris asalkan berkutip 'Field Delimiter'."+
    "\n- Karakter 'Field Delimiter' (karakter \") dlm sebuah field harus digandakan,"+
    "\n    sebagai contoh \"aplikasi \"MiniMart\" gratis lhoo...\" menjadi \"aplikasi \"\"MiniMart\"\" gratis lhoo...\""+
    "\n- Pada field yg tdk berkutip 'Field Delimiter', trailing dan tailing space akan diabaikan."
   );
  }
  
  return ret.toString();
 }
 public static String getCSVErrorMessage(){
  return "Pastikan bahwa file CSV yg akan diakses tdk sedang dibuka oleh aplikasi lain !";
 }
 public static String getLabelCommentInputInfo(){
  return 
   "Catatan !\n"+
   "----\n"+
   "Komentar tidak dimaksudkan utk diisi dgn promo-promo tertentu (seperti beli 2 gratis 1 atau diskon 10%)\n"+
   "karena aplikasi ini tidak mendukung otomatisasi penentuan harga barang berdasarkan promo-promo tertentu.\n"+
   "----\n"+
   "Namun komentar hanya dimaksudkan utk diisi dgn penjelasan yg tidak berhubungan dengan promo-promo tertentu,\n"+
   "seperti 'New Item', 'Barang tersedia dlm warna merah & biru', 'Bergaransi 1 tahun', dll.";
 }
 public static Object[] getWelcomeMessage(){
  return PCore.objArr(
     "Meaning Of Life"
   
   // bussiness
   , "Sudah Tiba Waktunya Untuk Bekerja Dengan Sepenuh Hati"
   , "Ayo Bersemangat Untuk Meraih Cita-Cita"
   , "Melayani Dengan Hati"
   , "Aku Mencintai Pekerjaanku ...."
   , "Jaminan Kualitas"
   , "My Priority Is Not On Money, But On Responsibility"
   , "Welcome Home"
   
   // learning
   , "Belajar Tanpa Henti"
   , "Kreatif dan Inovatif"
   , "Tekun dan Pantang Menyerah"
   , "Dedikasi Adalah Kunci Keberhasilan Dalam Berusaha"
   
   // relation with another people
   , "Saling Menolong"
   , "Saling Berbagi"
   , "Saling Sepenanggungan"
   
   // soul
   , "Harta Hatiku"
   , "Jujur & Tulus Apa Adanya"
   , "I Will Always Remember You, Mother"
   , "Indah Pada Waktunya"
   
   // love
   , "Sarang Hae"
   
   // other
   , "Hard Mission ? I Am Possible !"
   , "Quickly ? No, Do It Slowly ... But Sure !"
   , "Membuktikan Dengan Tindakan"
   , "Kecil-Kecil Tapi Cabe Rawit"
   , "Ari ... Gato ..."
   
   // emoticon
   , "( ^ v ^ )"
  );
 }
 
}