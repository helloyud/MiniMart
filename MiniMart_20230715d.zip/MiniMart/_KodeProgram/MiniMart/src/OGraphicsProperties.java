public class OGraphicsProperties {
 
 OScaleFactor scalefactor_image;
 double scalefactor_image_max;
 OScaleFactor scalefactor_image_diff;

 public OGraphicsProperties(OScaleFactor scalefactor_image_) {
  this.scalefactor_image=scalefactor_image_;
  scalefactor_image_max=PMath.getMinMaxDouble(scalefactor_image.X, scalefactor_image.Y, false);
  scalefactor_image_diff=new OScaleFactor(1, 1);
  if(scalefactor_image.X!=scalefactor_image.Y){
   if(scalefactor_image.X<scalefactor_image.Y){scalefactor_image_diff.X=scalefactor_image.X/scalefactor_image.Y;}
   else{scalefactor_image_diff.Y=scalefactor_image.Y/scalefactor_image.X;}
  }
 }
 
}