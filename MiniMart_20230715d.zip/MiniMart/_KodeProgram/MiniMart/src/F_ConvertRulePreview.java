import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;

public class F_ConvertRulePreview extends XFormPreview {
 
 // set
 boolean wIsFromConverting;
 long wId;
 OInfoConvertRule wInfoConvertRule;
 
  // Table - List Items
	String[] TableConvItemsColsName;
	int[] TableConvItemsColsType, TableConvItemsColsShowOption;
	boolean[] TableConvItemsColsEditable;
	
 OCustomTableModel TableMdlConvItemsOut;
 VIntegerArray TableConvItemsOutColsVisible, TableConvItemsOutColsWidth;
 
 VInteger LastSelectedRowConvItemsOut;
 VBoolean InfoConvItemsOutClear;
 
 OCustomTableModel TableMdlConvItemsIn;
 VIntegerArray TableConvItemsInColsVisible, TableConvItemsInColsWidth;
 
 VInteger LastSelectedRowConvItemsIn;
 VBoolean InfoConvItemsInClear;

 public F_ConvertRulePreview(MInterFormVariables IFV_) {
  int[] Editable;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
   // Table - List Items
  TableConvItemsColsName=PMyShop.getConvertItems_ColumnsName();
  TableConvItemsColsType=PMyShop.getConvertItems_ColumnsType();
  TableConvItemsColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableConvItemsColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(-1);
  TableConvItemsColsEditable=PCore.changeValue(PCore.newBooleanArray(TableConvItemsColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));

    // Item Out
  TableMdlConvItemsOut=new OCustomTableModel(); Tbl_ItemOut.setModel(TableMdlConvItemsOut);
  TableConvItemsOutColsVisible=new VIntegerArray();
  TableConvItemsOutColsWidth=new VIntegerArray();

  LastSelectedRowConvItemsOut=new VInteger(-1);
  InfoConvItemsOutClear=new VBoolean(true);
  
  CB_ItemOutViewCategorized.setSelected(false);
  buildTableConvItemsViewStructure(true, true);
  updateTableConvItemsView(true, false);
  
  Pnl_ItemOutInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

    // Item In
  TableMdlConvItemsIn=new OCustomTableModel(); Tbl_ItemIn.setModel(TableMdlConvItemsIn);
  TableConvItemsInColsVisible=new VIntegerArray();
  TableConvItemsInColsWidth=new VIntegerArray();

  LastSelectedRowConvItemsIn=new VInteger(-1);
  InfoConvItemsInClear=new VBoolean(true);
  
  CB_ItemInViewCategorized.setSelected(false);
  buildTableConvItemsViewStructure(false, true);
  updateTableConvItemsView(false, false);
  
  Pnl_ItemInInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    ),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
 }
 void clearComponents(){
  clearHeader();
  clearConvItems(true); clearConvItems(false);
 }
 
 public boolean proceed(Object AKey){
  boolean ret=false;
  Object[] objs;
  OInfoConverting InfoConverting;
  
  do{
   objs=(Object[])AKey;
   
   wIsFromConverting=(Boolean)objs[0];
   wId=(Long)objs[1];
   
   wInfoConvertRule=null;
   do{
    if(!wIsFromConverting){
     wInfoConvertRule=PMyShop.getConvertRuleInfo(IFV.Stm, wId);
    }
    else{
     InfoConverting=PMyShop.getConvertingInfo(IFV.Stm, wId); if(InfoConverting==null){break;}
     wInfoConvertRule=InfoConverting.ConvRule;
    }
   }while(false);
   if(wInfoConvertRule==null){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public String getName(){return "aturan konversi";}
 
 // Header
 void fillHeader(){
  TF_LastUpdate.setText("Tanggal Update : "+PText.dateToString(wInfoConvertRule.LastUpdate, 2));
  CB_IsActive.setSelected(wInfoConvertRule.IsActive);
  TA_Name.setText(wInfoConvertRule.Name);
 }
 void clearHeader(){
  TF_LastUpdate.setText("");
  CB_IsActive.setSelected(false);
  TA_Name.setText("");
 }
 
 // List Items
 void updateTableConvItemsView(boolean IsItemOut, boolean Requery){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  VIntegerArray ColsVisible=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsVisible, TableConvItemsInColsVisible);
  VIntegerArray ColsWidth=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsWidth, TableConvItemsInColsWidth);
  
  TableMdl.updateColumnsInfo(TableConvItemsColsName, TableConvItemsColsType, TableConvItemsColsShowOption,
   ColsVisible.Value, TableConvItemsColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl, ColsWidth.Value);
  if(!Requery){onSelectedRowChangedConvItems(IsItemOut, false);}
  else{fillConvItems(IsItemOut, false);}
 }
 void buildTableConvItemsColumns(boolean IsItemOut){
  JToggleButton CB_ViewCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  VIntegerArray ColsVisible=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsVisible, TableConvItemsInColsVisible);
  VIntegerArray ColsWidth=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsWidth, TableConvItemsInColsWidth);
  
  ColsVisible.Value=PMyShop.getConvertItems_ColumnsVisible(IsCategorized);
  ColsWidth.Value=PMyShop.getConvertItems_ColumnsWidth(IsCategorized);
 }
 void buildTableConvItemsViewStructure(boolean IsItemOut, boolean RebuildColumns){
  if(RebuildColumns){buildTableConvItemsColumns(IsItemOut);}
 }
 void changeConvItemsViewByCategorized(boolean IsItemOut){
  buildTableConvItemsViewStructure(IsItemOut, true);
  updateTableConvItemsView(IsItemOut, true);
 }
 
 void onSelectedRowChangedConvItems(boolean IsItemOut, boolean UpdateAnyway){
  VInteger LastSelectedRow=(VInteger)PCore.subtituteBool(IsItemOut, LastSelectedRowConvItemsOut, LastSelectedRowConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int row=Tbl.getSelectedRow();
  
  if(LastSelectedRow.Value==row && !UpdateAnyway){return;}
  
  LastSelectedRow.Value=row;
  
  if(row==-1){clearConvItemsInfo(IsItemOut); return;}
  
  fillConvItemsInfo(IsItemOut, row);
 }
 
 void refreshConvItemsCount(boolean IsItemOut){
  JTextField TF_Count=(JTextField)PCore.subtituteBool(IsItemOut, TF_ItemOutCount, TF_ItemInCount);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  TF_Count.setText(PText.intToString(TableMdl.getRowCount()));
 }
 void fillConvItems(boolean IsItemOut, boolean SelectAData){
  JToggleButton CB_ViewCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  OInfoConverting Converting;
  Vector<Object[]> result;
  
  clearConvItems(IsItemOut);
  
  result=null;
  do{
   if(!wIsFromConverting){
    result=PMyShop.getConvertItems(IFV.Stm, true, IsItemOut, wId, CB_ViewCategorized.isSelected());
   }
   else{
    Converting=PMyShop.getConvertingInfo(IFV.Stm, wId, true, CB_ViewCategorized.isSelected()); if(Converting==null){break;}
    result=(Vector<Object[]>)PCore.subtituteBool(IsItemOut, Converting.ConvRule.ListItemA, Converting.ConvRule.ListItemB);
   }
  }while(false);
  if(result==null){return;}
  
  TableMdl.append(result);
  refreshConvItemsCount(IsItemOut);
  
  if(!SelectAData || TableMdl.getRowCount()==0){return;}
  Tbl.changeSelection(0, 0, false, false); onSelectedRowChangedConvItems(IsItemOut, false);
 }
 void clearConvItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  TableMdl.removeAll(); onSelectedRowChangedConvItems(IsItemOut, true);
  refreshConvItemsCount(IsItemOut);
 }
 void fillConvItemsInfo(boolean IsItemOut, int Row){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  JTextArea TA_InfoCategory=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoCategory, TA_ItemInInfoCategory);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  VBoolean InfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, InfoConvItemsOutClear, InfoConvItemsInClear);
  
  Object[] objs=TableMdl.Mdl.Rows.elementAt(Row);
  
  TA_InfoCategory.setText(PCore.objString(objs[6], ""));
  TA_InfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+PCore.objString(objs[1], ""));
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, objs[5]);
  
  InfoClear.Value=false;
 }
 void clearConvItemsInfo(boolean IsItemOut){
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  JTextArea TA_InfoCategory=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoCategory, TA_ItemInInfoCategory);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  VBoolean InfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, InfoConvItemsOutClear, InfoConvItemsInClear);
  
  if(InfoClear.Value){return;}
  
  TA_InfoCategory.setText("");
  TA_InfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoClear.Value=true;
 }
 
 // Others
 void fillComponentsWithSetVariables(){
  fillHeader();
  fillConvItems(true, false); fillConvItems(false, false);
 }
 void initPrivGUIShow(){
  
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jPanel11 = new javax.swing.JPanel();
  jPanel9 = new javax.swing.JPanel();
  jPanel14 = new javax.swing.JPanel();
  jLabel3 = new javax.swing.JLabel();
  TF_ItemInCount = new javax.swing.JTextField();
  CB_ItemInViewCategorized = new javax.swing.JToggleButton();
  jPanel15 = new javax.swing.JPanel();
  Pnl_ItemInInfoPreview = new XImgBoxURL();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_ItemInInfoCategory = new javax.swing.JTextArea();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_ItemInInfoName = new javax.swing.JTextArea();
  jScrollPane7 = new javax.swing.JScrollPane();
  Tbl_ItemIn = new XTable();
  jPanel8 = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  jLabel2 = new javax.swing.JLabel();
  TF_ItemOutCount = new javax.swing.JTextField();
  CB_ItemOutViewCategorized = new javax.swing.JToggleButton();
  jPanel13 = new javax.swing.JPanel();
  Pnl_ItemOutInfoPreview = new XImgBoxURL();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemOutInfoCategory = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_ItemOutInfoName = new javax.swing.JTextArea();
  jScrollPane4 = new javax.swing.JScrollPane();
  Tbl_ItemOut = new XTable();
  jPanel1 = new javax.swing.JPanel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_Name = new javax.swing.JTextArea();
  jPanel2 = new javax.swing.JPanel();
  CB_IsActive = new javax.swing.JCheckBox();
  TF_LastUpdate = new javax.swing.JTextField();

  setTitle("Keterangan Aturan Konversi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel9.setBackground(new java.awt.Color(204, 255, 102));
  jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel14.setOpaque(false);

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("Sisi B");

  TF_ItemInCount.setEditable(false);
  TF_ItemInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CB_ItemInViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemInViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemInViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemInViewCategorized.setText("K");
  CB_ItemInViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemInViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemInViewCategorized.setIconTextGap(0);
  CB_ItemInViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemInViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemInViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(jLabel3)
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_ItemInViewCategorized))
  );

  Pnl_ItemInInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemInInfoCategory.setEditable(false);
  TA_ItemInInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoCategory.setColumns(20);
  TA_ItemInInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoCategory.setLineWrap(true);
  TA_ItemInInfoCategory.setRows(1);
  TA_ItemInInfoCategory.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_ItemInInfoCategory);

  TA_ItemInInfoName.setEditable(false);
  TA_ItemInInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoName.setColumns(20);
  TA_ItemInInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoName.setLineWrap(true);
  TA_ItemInInfoName.setRows(1);
  TA_ItemInInfoName.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_ItemInInfoName);

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane5)
     .addComponent(jScrollPane6)))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel15Layout.createSequentialGroup()
    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemIn.setRowHeight(17);
  Tbl_ItemIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemInMouseReleased(evt);
   }
  });
  Tbl_ItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemInKeyReleased(evt);
   }
  });
  jScrollPane7.setViewportView(Tbl_ItemIn);

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 483, Short.MAX_VALUE)
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel8.setBackground(new java.awt.Color(255, 204, 153));
  jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel5.setOpaque(false);

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel2.setText("Sisi A");

  TF_ItemOutCount.setEditable(false);
  TF_ItemOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CB_ItemOutViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutViewCategorized.setText("K");
  CB_ItemOutViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemOutViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutViewCategorized.setIconTextGap(0);
  CB_ItemOutViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(jLabel2)
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_ItemOutViewCategorized))
  );

  Pnl_ItemOutInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemOutInfoCategory.setEditable(false);
  TA_ItemOutInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoCategory.setColumns(20);
  TA_ItemOutInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoCategory.setLineWrap(true);
  TA_ItemOutInfoCategory.setRows(1);
  TA_ItemOutInfoCategory.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemOutInfoCategory);

  TA_ItemOutInfoName.setEditable(false);
  TA_ItemOutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoName.setColumns(20);
  TA_ItemOutInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoName.setLineWrap(true);
  TA_ItemOutInfoName.setRows(1);
  TA_ItemOutInfoName.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_ItemOutInfoName);

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addComponent(jScrollPane3)))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemOut.setRowHeight(17);
  Tbl_ItemOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemOutMouseReleased(evt);
   }
  });
  Tbl_ItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemOutKeyReleased(evt);
   }
  });
  jScrollPane4.setViewportView(Tbl_ItemOut);

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 483, Short.MAX_VALUE)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TA_Name.setEditable(false);
  TA_Name.setBackground(new java.awt.Color(204, 255, 204));
  TA_Name.setColumns(20);
  TA_Name.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_Name.setLineWrap(true);
  TA_Name.setRows(1);
  TA_Name.setWrapStyleWord(true);
  jScrollPane1.setViewportView(TA_Name);

  CB_IsActive.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_IsActive.setText("Aktif");
  CB_IsActive.setEnabled(false);
  CB_IsActive.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
  CB_IsActive.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TF_LastUpdate.setEditable(false);
  TF_LastUpdate.setBackground(new java.awt.Color(204, 255, 204));
  TF_LastUpdate.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addComponent(TF_LastUpdate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_IsActive))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_IsActive)
    .addComponent(TF_LastUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void Pnl_ItemInInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemIn, TableMdlConvItemsIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInInfoPreviewMouseClicked

 private void Tbl_ItemInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemInMouseReleased
  onSelectedRowChangedConvItems(false, false);
 }//GEN-LAST:event_Tbl_ItemInMouseReleased

 private void Tbl_ItemInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemInKeyReleased
  onSelectedRowChangedConvItems(false, false);
 }//GEN-LAST:event_Tbl_ItemInKeyReleased

 private void Pnl_ItemOutInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemOut, TableMdlConvItemsOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutInfoPreviewMouseClicked

 private void Tbl_ItemOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemOutMouseReleased
  onSelectedRowChangedConvItems(true, false);
 }//GEN-LAST:event_Tbl_ItemOutMouseReleased

 private void Tbl_ItemOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemOutKeyReleased
  onSelectedRowChangedConvItems(true, false);
 }//GEN-LAST:event_Tbl_ItemOutKeyReleased

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;

  initPrivGUIShow();

  fillComponentsWithSetVariables();
 }//GEN-LAST:event_formWindowActivated

 private void CB_ItemOutViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutViewCategorizedActionPerformed
  changeConvItemsViewByCategorized(true);
 }//GEN-LAST:event_CB_ItemOutViewCategorizedActionPerformed

 private void CB_ItemInViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemInViewCategorizedActionPerformed
  changeConvItemsViewByCategorized(false);
 }//GEN-LAST:event_CB_ItemInViewCategorizedActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JCheckBox CB_IsActive;
 private javax.swing.JToggleButton CB_ItemInViewCategorized;
 private javax.swing.JToggleButton CB_ItemOutViewCategorized;
 private XImgBoxURL Pnl_ItemInInfoPreview;
 private XImgBoxURL Pnl_ItemOutInfoPreview;
 private javax.swing.JTextArea TA_ItemInInfoCategory;
 private javax.swing.JTextArea TA_ItemInInfoName;
 private javax.swing.JTextArea TA_ItemOutInfoCategory;
 private javax.swing.JTextArea TA_ItemOutInfoName;
 private javax.swing.JTextArea TA_Name;
 private javax.swing.JTextField TF_ItemInCount;
 private javax.swing.JTextField TF_ItemOutCount;
 private javax.swing.JTextField TF_LastUpdate;
 private XTable Tbl_ItemIn;
 private XTable Tbl_ItemOut;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 // End of variables declaration//GEN-END:variables
}
