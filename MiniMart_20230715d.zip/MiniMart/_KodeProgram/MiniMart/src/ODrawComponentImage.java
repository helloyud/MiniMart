import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.imageio.ImageIO;

public class ODrawComponentImage extends ODrawComponent {

 boolean IsInBox;
 double BoxWidth, BoxHeight;
 OAlignment BoxAlignment;
 double ScaleFactor;
 boolean ReadSourceFromFile;
 String ImgDir;
 String ImgFile;
 BufferedImage MemImage;

 public ODrawComponentImage(double OffsetX, double OffsetY, double BoxWidth, double BoxHeight, OAlignment BoxAlignment,
  String ImgDir, String ImgFile) {
  this.IsInBox = true;
  this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
  this.BoxWidth = BoxWidth;
  this.BoxHeight = BoxHeight;
  this.BoxAlignment=BoxAlignment;
  this.ReadSourceFromFile = true;
  this.ImgDir = ImgDir;
  this.ImgFile = ImgFile;
 }
 public ODrawComponentImage(double OffsetX, double OffsetY, double BoxWidth, double BoxHeight, OAlignment BoxAlignment,
  BufferedImage MemImage) {
  this.IsInBox = true;
  this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
  this.BoxWidth = BoxWidth;
  this.BoxHeight = BoxHeight;
  this.BoxAlignment=BoxAlignment;
  this.ReadSourceFromFile = false;
  this.MemImage = MemImage;
 }
 public ODrawComponentImage(double OffsetX, double OffsetY, double ScaleFactor,
  String ImgDir, String ImgFile) {
  this.IsInBox = false;
  this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
  this.ScaleFactor = ScaleFactor;
  this.ReadSourceFromFile = true;
  this.ImgDir = ImgDir;
  this.ImgFile = ImgFile;
 }
 public ODrawComponentImage(double OffsetX, double OffsetY, double ScaleFactor,
  BufferedImage MemImage) {
  this.IsInBox = false;
  this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
  this.ScaleFactor = ScaleFactor;
  this.ReadSourceFromFile = false;
  this.MemImage = MemImage;
 }
 
 private BufferedImage getImage(){
  BufferedImage ret=null;
  
  if(ReadSourceFromFile){
   try{ret=ImageIO.read(new URL(ImgDir+ImgFile));}
   catch(Exception E_){ret=null;}
  }
  else{ret=MemImage;}
  
  return ret;
 }
 public void draw(Graphics2D graphics, OGraphicsProperties Prop){
  BufferedImage MemImg;
  
  MemImg=getImage();

  if(IsInBox){PGraphics.paintImageInBox(graphics, OffsetX, OffsetY, MemImg, false, Prop.scalefactor_image_diff, 1, CGraph.Rotate_000Degree, BoxWidth, BoxHeight, BoxAlignment, true);}
  else{PGraphics.paintImageXY(graphics, OffsetX, OffsetY, MemImg, true, Prop.scalefactor_image_diff, ScaleFactor, CGraph.Rotate_000Degree);}
 }
 
 public ODimension calcDrawDimension(){
  ODimension ret=new ODimension(0, 0);
  BufferedImage MemImg;
  
  if(IsInBox){
   ret.setSize(BoxWidth, BoxHeight);
  }
  else{
   MemImg=getImage();
   if(MemImg!=null){ret.setSize(MemImg.getWidth()*ScaleFactor, MemImg.getHeight()*ScaleFactor);}
  }
  
  return ret;
 }
 
}