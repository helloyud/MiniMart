public class OParam {
 Object[] Param;
 void setParamCount(int ParamCount){
  Param=new Object[ParamCount];
 }
 void passParam(int AtIndex, Object AParameter){
  Param[AtIndex]=AParameter;
 }
}