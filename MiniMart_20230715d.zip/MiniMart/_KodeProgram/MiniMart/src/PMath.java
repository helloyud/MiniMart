public class PMath {

 public static boolean isFraction(double ANumber){
  if(ANumber%1!=0d){return true;}
  else{return false;}
 }

 public static long roundLong(double Number, int RoundMode){
  // RoundMode : 0 normal, 1 round up, 2 round down
  long ret=(long)Number;
  if(Number>=0){
   if(RoundMode==1){
    if(Number%1>=0.0001){ret=ret+1;}
   }
   else if(RoundMode==0){
    if(Number%1>0.4999){ret=ret+1;}
   }
  }
  else{
   if(RoundMode==2){
    if(Number%1<=-1*0.0001){ret=ret-1;}
   }
   else if(RoundMode==0){
    if(Number%1<=-1*(1-0.4999)){ret=ret-1;}
   }
  }
  return ret;
 }
 public static long roundLongCustom(double Number, double Threshold){
  long ret=(long)Number;
  if(Number>=0){
   if(Number%1>=Threshold){ret=ret+1;}
  }
  else{
   if(Number%1<-1*(1-Threshold)){ret=ret-1;}
  }
  return ret;
 }
 public static int round(double Number, int RoundMode){
  return (int)roundLong(Number, RoundMode);
 }
 public static int roundCustom(double Number, double Threshold){
  return (int)roundLongCustom(Number, Threshold);
 }
 
 public static double roundDouble(double Number, int FractionDigit, int RoundDigit){
  OPreciseDecimal ret=new OPreciseDecimal(Number, FractionDigit, RoundDigit);
  return ret.Rounded_Value.Value;
 }

 public static boolean compare(double Num1, double Num2, double Tolerance){
  double Difference;
  double Tol=Tolerance;
  
  Difference=Num2-Num1;
  if(Difference!=0){
   if(Difference<0){Difference=Difference*-1;}
   if(Tol<0){Tol=Tol*-1;}
   if(Difference>Tolerance){return false;}
  }
  
  return true;
 }

 public static Integer getMinMaxInt(Integer Value1, Integer Value2, boolean ChooseSmallestValue){
  Integer ret=null;
  
  do{
   if(Value1==null && Value2==null){break;}

   if(Value2==null){ret=Value1; break;}
   if(Value1==null){ret=Value2; break;}
   
   ret=Value1;
   if(ChooseSmallestValue){if(Value2<Value1){ret=Value2;}}
   else{if(Value2>Value1){ret=Value2;}}
  }while(false);
  
  return ret;
 }
 public static Long getMinMaxLong(Long Value1, Long Value2, boolean ChooseSmallestValue){
  Long ret=null;
  
  do{
   if(Value1==null && Value2==null){break;}

   if(Value2==null){ret=Value1; break;}
   if(Value1==null){ret=Value2; break;}
   
   ret=Value1;
   if(ChooseSmallestValue){if(Value2<Value1){ret=Value2;}}
   else{if(Value2>Value1){ret=Value2;}}
  }while(false);
  
  return ret;
 }
 public static Double getMinMaxDouble(Double Value1, Double Value2, boolean ChooseSmallestValue){
  Double ret=null;
  
  do{
   if(Value1==null && Value2==null){break;}

   if(Value2==null){ret=Value1; break;}
   if(Value1==null){ret=Value2; break;}
   
   ret=Value1;
   if(ChooseSmallestValue){if(Value2<Value1){ret=Value2;}}
   else{if(Value2>Value1){ret=Value2;}}
  }while(false);
  
  return ret;
 }
 
 public static double calculate(double Operand1, double Operand2, int MathOperation,
		boolean IsChangeNegativeResult, double ChangeNegativeResult){
  double ret=0;
  
  switch(MathOperation){
   case CMath.Add : ret=Operand1+Operand2; break;
   case CMath.Minus : ret=Operand1-Operand2; break;
   case CMath.Times : ret=Operand1*Operand2; break;
   case CMath.Divide : ret=Operand1/Operand2; break;
   case CMath.Mod : ret=Operand1%Operand2; break;
  }
		
		if(ret<0 && IsChangeNegativeResult){
			ret=ChangeNegativeResult;
		}
  
  return ret;
 }
 
 public static int sumInt(Integer... Values){
  int ret=0;
  int temp, length;
  Integer Value;
  
  if(Values==null){return ret;}
  length=Values.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   Value=Values[temp];
   if(Value!=null){ret=ret+Value;}
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static long sumLong(Long... Values){
  long ret=0;
  int temp, length;
  Long Value;
  
  if(Values==null){return ret;}
  length=Values.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   Value=Values[temp];
   if(Value!=null){ret=ret+Value;}
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static double sumDouble(Double... Values){
  double ret=0;
  int temp, length;
  Double Value;
  
  if(Values==null){return ret;}
  length=Values.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   Value=Values[temp];
   if(Value!=null){ret=ret+Value;}
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static int sumInt(int[] Values){
  int ret=0;
  int temp, length;
  
  if(Values==null){return ret;}
  length=Values.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   ret=ret+Values[temp];
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static long sumLong(long[] Values){
  long ret=0;
  int temp, length;
  
  if(Values==null){return ret;}
  length=Values.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   ret=ret+Values[temp];
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static double sumDouble(double[] Values){
  double ret=0;
  int temp, length;
  
  if(Values==null){return ret;}
  length=Values.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   ret=ret+Values[temp];
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static long getMultiplierOfTen(int Count){
  long ret=1;
  int temp;
  
  if(Count<=0){return ret;}
  
  temp=0;
  do{
   ret=ret*10;
   temp=temp+1;
  }while(temp!=Count);
  
  return ret;
 }

}