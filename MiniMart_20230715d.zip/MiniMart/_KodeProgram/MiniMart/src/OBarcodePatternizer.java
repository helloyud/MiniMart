public abstract class OBarcodePatternizer {
 
 // for numberic only
 long Number;
 int MinimalDigitCount;
 
 // for alpha-numeric
 String AlphaNumeric;
 
 OBarcodePatterns PatternResult;
 
 // additional
 OBarcodePatterns Patterns;
 
 public void patternize(long Number, int MinimalDigitCount){
  this.Number=Number;
  this.MinimalDigitCount=MinimalDigitCount;
  PatternResult=patternizing();
 }
 public void patternize(String AlphaNumeric){
  this.AlphaNumeric=AlphaNumeric;
  PatternResult=patternizing();
 }
 public OBarcodePatterns getResult(){return PatternResult;}
 
 protected abstract OBarcodePatterns patternizing();
 
}