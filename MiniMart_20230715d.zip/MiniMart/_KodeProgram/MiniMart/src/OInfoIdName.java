public class OInfoIdName extends OInfoAThing{

 long Id; boolean IdIsInteger;
 String Name;

 public OInfoIdName(boolean IdIsInteger){
  this(IdIsInteger, -1, null, new OGetStringByNormal());
 }
 public OInfoIdName(boolean IdIsInteger, long Id, String Name){
  this(IdIsInteger, Id, Name, new OGetStringByNormal());
 }
 public OInfoIdName(boolean IdIsInteger, long Id, String Name, OGetString GetNameMode){
  setVars(IdIsInteger, Id, Name, GetNameMode);
 }
 
 public void init(OInfoIdName Info) {
  setVars(Info.IdIsInteger, Info.Id, Info.Name, Info.GetNameMode);
 }
 
 public void setVars(boolean IdIsInteger, long Id, String Name, OGetString GetNameMode){
  setIdIsInteger(IdIsInteger);
  setIdName(Id, Name);
  setGetNameMode(GetNameMode);
 }
 public void setIdIsInteger(boolean IdIsInteger){
  this.IdIsInteger=IdIsInteger;
 }
 public void setIdName(long Id, String Name){
  this.Id=Id; this.Name=Name;
 }
 
 public String getName(){return PText.getString(Id, -1, GetNameMode.getString(Name), "~");}
 
 public long[] getId(){
  return PCore.primArr(Id);
 }

 public Object clone(){
  OInfoIdName ret=new OInfoIdName(IdIsInteger);
  ret.init(this);
  return ret;
 }
 
}