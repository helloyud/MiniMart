import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.util.Vector;

public class OAPage implements Printable {
 
 Vector<ODrawComponent> DrawComponents;
 int Orientation;

 OAPage(int Orientation, Vector<ODrawComponent> DrawComponents) {
  this.Orientation=Orientation;
  this.DrawComponents = DrawComponents;
 }
 
 @Override
 public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
  print2((Graphics2D)graphics, pageFormat, true, 0);
  return PAGE_EXISTS;
 }
 void print2(Graphics2D graphics, PageFormat pageFormat,
  boolean ScaleByBounds, double CustomScaleFactor) throws PrinterException{
  int temp, DrawComponentsCount;
  AffineTransform at;
  OScaleFactor scalefactor_printer, scalefactor_image, scalefactor, scalefactor_temp;
  double move_x, move_y;
  double rotate;
  
  OGraphicsProperties Prop;
  
  scalefactor_printer=new OScaleFactor(); scalefactor_image=new OScaleFactor(); scalefactor=new OScaleFactor(); scalefactor_temp=new OScaleFactor();
  
  // save printer's original transform
  at=graphics.getTransform();
  
  // fix graphics's FontRenderContext to enable FractionalMetrics
  graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
  
  // converting userspace coordinate to device coordinate (from 72 dpi to printer's dpi)
   // normalizing current transfrom's scale factor from ? dpi (not factor 1) to 72 dpi (factor 1)
  scalefactor.X=(double)1/at.getScaleX();
  scalefactor.Y=(double)1/at.getScaleY();
  scalefactor_image.X=(double)1;
  scalefactor_image.Y=(double)1;
  
   // convert scale factor from 72 dpi to printer's dpi
  if(ScaleByBounds){
   scalefactor_printer.X=graphics.getDeviceConfiguration().getBounds().getWidth()/pageFormat.getWidth();
   scalefactor_printer.Y=graphics.getDeviceConfiguration().getBounds().getHeight()/pageFormat.getHeight();
   scalefactor_temp.X=scalefactor_printer.X;
   scalefactor_temp.Y=scalefactor_printer.Y;
  }
  else{
   scalefactor_temp.X=CustomScaleFactor;
   scalefactor_temp.Y=CustomScaleFactor;
  }
  scalefactor.X=scalefactor.X*scalefactor_temp.X;
  scalefactor.Y=scalefactor.Y*scalefactor_temp.Y;
  scalefactor_image.X=scalefactor_image.X*scalefactor_temp.X;
  scalefactor_image.Y=scalefactor_image.Y*scalefactor_temp.Y;
   // set graphics's scale factor
  graphics.scale(scalefactor.X, scalefactor.Y);
  
  // moving base of x & y
  /* translate(a, b) = moving graphic's base coordinate x & y following this formula :
                       base_x=base_x+a*graphics.getTransform().getScaleX()
                       base_y=base_y+b*graphics.getTransform().getScaleY()
  */
  move_x=pageFormat.getImageableX(); move_y=pageFormat.getImageableY(); rotate=0;
  switch(Orientation){
   case PageFormat.LANDSCAPE : move_y=move_y+pageFormat.getImageableHeight(); rotate=270; break;
   case PageFormat.REVERSE_LANDSCAPE : move_x=move_x+pageFormat.getImageableWidth(); rotate=90; break;
  }
  graphics.translate(move_x, move_y);
  graphics.rotate(Math.toRadians(rotate));
  
  // fill print information to be used while drawing
  Prop=new OGraphicsProperties(scalefactor_image);

  // drawing
  DrawComponentsCount=DrawComponents.size();
  if(DrawComponentsCount!=0){
   temp=0;
   do{
    DrawComponents.elementAt(temp).draw(graphics, Prop);
    temp=temp+1;
   }while(temp!=DrawComponentsCount);
  }

  // restore printer's original transform
  graphics.setTransform(at);
 }

}