public class OTableCellUpdaterByObject
 extends OTableCellUpdater{
 
 Object Value;

 public OTableCellUpdaterByObject(int TableColumnIndex,
  Object Value){
  init(TableColumnIndex);
  this.Value = Value;
 }

 public void update(int TableRowIndex) {
  getRows().elementAt(TableRowIndex)[TableColumnIndex]=Value;
 }

}