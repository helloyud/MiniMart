import java.util.Vector;

public abstract class OCsvImportValueCheckable extends OCsvImportValue {

 /*
  this class must be paired with OCsvImportValueSelect
 */
 
 // 'the available check result'
 public static final int CheckError=1;
 public static final int CheckEmpty=2;
 public static final int CheckValid=3;
 
 //
 public boolean GetValidFromThisClass;
 
 //
 OGeneratedSQLValue GeneratedSQLValue;

 //
 public OCsvImportValueCheckable(boolean GetValidFromThisClass) {
  initVariables(GetValidFromThisClass);
 }
 
 public void initVariables(boolean GetValidFromThisClass){
  this.GetValidFromThisClass = GetValidFromThisClass;
  GeneratedSQLValue=new OGeneratedSQLValue();
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  preGenerateSQLValue(LastReadRecordFromFile);
 }
 public int checkAndGenerateSQLValue(){
  // check() always return one of 'the available check result' in this class
  GeneratedSQLValue.ungenerateSQLValue();
  return checkAndGenSQLValue();
 }
 public OGeneratedSQLValue generateSQLValue() {return GeneratedSQLValue;}
 
 public abstract int checkAndGenSQLValue();
 
}