public class OInfoSubjectAddress {
 
 int Enumeration;
 String Address;
 int CityId; String CityName;
 String Comment;

}