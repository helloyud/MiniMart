import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.JTextComponent;

public class F_SubjectImportAdd extends XFormDialog {
 
 OCustomTableModel TableMdlFilePreview;
 int PreviewMaxRows;
 
 OFileCsv ChoosedFile;
 
 //
 
 OFileCsv FileCsv;
 
 VInteger NameFileField;
 VBoolean BirthdayByFile; VInteger BirthdayFileField; VDate Birthday;
 VBoolean CommentByFile; VInteger CommentFileField; VString Comment;
 
 public F_SubjectImportAdd(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  TableMdlFilePreview=new OCustomTableModel();
  Tbl_FilePreview.setModel(TableMdlFilePreview);
  PreviewMaxRows=10;
  
  NameFileField=new VInteger();
  BirthdayByFile=new VBoolean(); BirthdayFileField=new VInteger(); Birthday=new VDate();
  CommentByFile=new VBoolean(); CommentFileField=new VInteger(); Comment=new VString();
  
  Tbl_FilePreview.setToolTipText("preview isi file (maksimal "+PreviewMaxRows+" baris data)");
  
  clearComponents();
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_ChooseFile,
    Tbl_FilePreview,
    
    TF_NameFile,
    CB_BirthdayFile, TF_BirthdayFile, CB_BirthdayDefIsSet, TF_BirthdayDefY, CmB_BirthdayDefM, CmB_BirthdayDefD,
    CB_CommentFile, TF_CommentFile, TA_CommentDef,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  setFileCsv(null, CCore.CsvDefaultFieldDelimiter, CCore.CsvFieldsSeparators, CCore.CsvRecordsSeparators, true);
  
  Lbl_Name.setForeground(CGUI.Color_Label_InputRight); TF_NameFile.setText("");
  clearAttribute(Lbl_Birthday, CB_BirthdayFile, TF_BirthdayFile); CB_BirthdayDefIsSet.setSelected(false); CB_BirthdayDefIsSetActionPerformed(null);
  clearAttribute(Lbl_Comment, CB_CommentFile, TF_CommentFile); setText(TA_CommentDef, "");
 }
 
 boolean setFileCsv(File f, char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators, boolean ShowMessage){
  OFileCsv f_csv;
  
  if(f==null){
   ChoosedFile=null; clearFileCsv();
   return true;
  }
  
  IFV.FSplashScreen.appear(this, "Membaca File CSV");
  f_csv=new OFileCsv(f, FieldDelimiter, FieldsSeparators, RecordsSeparators, false, PreviewMaxRows, IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  
  if(f_csv.IsValid.IsValid){ChoosedFile=f_csv; fillFileCsv();}
  
  if(!f_csv.IsValid.IsValid && ShowMessage){
   IFV.FMessage.showMessage("Terjadi kegagalan dalam membaca file ("+PMyShop.getCSVErrorMessage()+") :\n"+f_csv.IsValid.getError());
  }
  
  return f_csv.IsValid.IsValid;
 }
 void fillFileCsv(){
  TF_File.setText(ChoosedFile.FileName);
  fillFileInfo();
 }
 void clearFileCsv(){
  TF_File.setText("");
  clearFileInfo();
 }
 void fillFileInfo(){
  int temp, length;
  String[] ColsName;
  String ColName;
  Vector<String> Record;
  
  // clear
  clearFileInfo();
  
  // fill File Info
  TF_FileInfo.setText(PText.intToString(ChoosedFile.RecordsCount)+" record ( "+PText.intToString(ChoosedFile.FieldsCount)+" field )");
  
  // fill File Preview
  if(ChoosedFile.FieldsCount==0){return;}
  
  ColsName=new String[ChoosedFile.FieldsCount];
  temp=0;
  do{
   ColName=ChoosedFile.Header.elementAt(temp);
   ColsName[temp]="("+(temp+1)+")"+PText.getString(ColName, "", " "+ColName, true);
   temp=temp+1;
  }while(temp!=ChoosedFile.FieldsCount);
  
  TableMdlFilePreview.updateColumnsInfo(
   ColsName, PCore.newIntegerArray(ChoosedFile.FieldsCount, CCore.TypeString),
   PCore.newIntegerArrayInOrderedSequence(ChoosedFile.FieldsCount, 0, 1), true);
  
  PGUI.resizeTableColumn(Tbl_FilePreview, PCore.newIntegerArray(ChoosedFile.FieldsCount, CGUI.ColTextSml));
  
  length=ChoosedFile.SampleRecords.size();
  if(length==0){return;}
  temp=0;
  do{
   Record=ChoosedFile.SampleRecords.elementAt(temp);
   TableMdlFilePreview.append(PCore.objArr_Vect(Record));
   temp=temp+1;
  }while(temp!=length);
 }
 void clearFileInfo(){
  TF_FileInfo.setText("");
  TableMdlFilePreview.emptyColumnsInfo();
 }
 
 void clearAttribute(JLabel Lbl, JCheckBox CB_File, JTextField TF_File){
  Lbl.setForeground(CGUI.Color_Label_InputRight);
  selectFileField(false, CB_File, TF_File);
 }
 void selectFileField(boolean Select, JCheckBox CB_File, JTextField TF_File){
  CB_File.setSelected(Select);
  enableFileField(CB_File, TF_File);
 }
 void enableFileField(JCheckBox CB_File, JTextField TF_File){
  boolean enable=CB_File.isSelected();
  TF_File.setEnabled(enable);
  TF_File.setBackground((Color)PCore.subtituteBool(enable, CGUI.Color_TextBox_FocusOff, CGUI.Gray240));
  if(!enable){TF_File.setText("");}
 }
 void setText(JTextComponent TextComponent, String str){
  TextComponent.setText(str);
 }
 int fileFieldIsValid(JTextField TF_File){
  int ret=-1;
  int temp;
  String str;
  do{
   str=TF_File.getText();
   if(!PText.checkInput(str, false, CCore.CharsCount_Int(), 2, 7, 0, 0)){break;}
   temp=Integer.parseInt(str)-1;
   if(temp<0 || temp>ChoosedFile.FieldsCount-1){break;}
   ret=temp;
  }while(false);
  return ret;
 }
 void checkString(
  VBoolean AttrByFile, VInteger AttrByFileField, VString AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JTextComponent TF_ByDef,
  JLabel Lbl_Attr, OValidation IsValid,
  boolean AcceptEmpty, int MaxInputLength){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   if(!PGUI.checkInputString(TF_ByDef, AttrByDef, AcceptEmpty, MaxInputLength, false, true)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid);
 }
 void checkDate(
  VBoolean AttrByFile, VInteger AttrByFileField, VDate AttrByDef,
  JCheckBox CB_ByFile, JTextField TF_ByFileField, JCheckBox CB_ByDefEnable, JTextField TF_ByDefYear, JComboBox CmB_ByDefMonth, JComboBox CmB_ByDefDay,
  JLabel Lbl_Attr, OValidation IsValid){
  boolean CurrValid=false;
  
  do{
   if(!checkFileField(AttrByFile, AttrByFileField, CB_ByFile, TF_ByFileField)){break;}
   if(!PGUI.checkInputDate(CB_ByDefEnable, TF_ByDefYear, CmB_ByDefMonth, CmB_ByDefDay, AttrByDef)){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Attr, IsValid);
 }
 boolean checkFileField(VBoolean AttrByFile, VInteger AttrByFileField,
  JCheckBox CB_ByFile, JTextField TF_ByFileField){
  boolean ret=true;
  
  AttrByFile.Value=CB_ByFile.isSelected();
  if(AttrByFile.Value){
   AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){ret=false;}
  }
   
  return ret;
 }
 void setValid(boolean Valid, JLabel Lbl_Attr, OValidation IsValid){
  if(Valid){Lbl_Attr.setForeground(CGUI.Color_Label_InputRight);}else{Lbl_Attr.setForeground(CGUI.Color_Label_InputWrong); IsValid.setValid(false);}
 }
 
 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Id = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  TF_File = new javax.swing.JTextField();
  Btn_ChooseFile = new javax.swing.JButton();
  Lbl_File = new javax.swing.JLabel();
  TF_FileInfo = new javax.swing.JTextField();
  Lbl_FileHelp = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_FilePreview = new XTable();
  jPanel4 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_ImportInfo = new javax.swing.JLabel();
  jLabel3 = new javax.swing.JLabel();
  jPanel5 = new javax.swing.JPanel();
  jLabel1 = new javax.swing.JLabel();
  Lbl_FileField1 = new javax.swing.JLabel();
  jLabel6 = new javax.swing.JLabel();
  TF_NameFile = new javax.swing.JTextField();
  Lbl_Name = new javax.swing.JLabel();
  CB_BirthdayFile = new javax.swing.JCheckBox();
  TF_BirthdayFile = new javax.swing.JTextField();
  CmB_BirthdayDefM = new javax.swing.JComboBox<>();
  CmB_BirthdayDefD = new javax.swing.JComboBox<>();
  TF_BirthdayDefY = new javax.swing.JTextField();
  CB_BirthdayDefIsSet = new javax.swing.JCheckBox();
  Lbl_Birthday = new javax.swing.JLabel();
  CB_CommentFile = new javax.swing.JCheckBox();
  TF_CommentFile = new javax.swing.JTextField();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_CommentDef = new javax.swing.JTextArea();
  Lbl_CommentDefHelp = new javax.swing.JLabel();
  Lbl_Comment = new javax.swing.JLabel();

  setTitle("Impor-Tambah Data Barang");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_File.setEditable(false);
  TF_File.setBackground(new java.awt.Color(204, 255, 204));

  Btn_ChooseFile.setText("...");
  Btn_ChooseFile.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseFileActionPerformed(evt);
   }
  });
  Btn_ChooseFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseFileKeyPressed(evt);
   }
  });

  Lbl_File.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_File.setText("File CSV");

  TF_FileInfo.setEditable(false);
  TF_FileInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_FileInfo.setToolTipText("jumlah record & jumlah field pada file");

  Lbl_FileHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileHelp.setText("(?)");
  Lbl_FileHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileHelpMouseClicked(evt);
   }
  });

  Tbl_FilePreview.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_FilePreview.setToolTipText("preview isi file (maksimal n baris data)");
  Tbl_FilePreview.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
  Tbl_FilePreview.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_FilePreview.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_FilePreviewKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_FilePreview);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(Lbl_File)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_File, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FileInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ChooseFile)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_FileHelp))
   .addComponent(jScrollPane1)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_File, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ChooseFile)
     .addComponent(Lbl_File)
     .addComponent(Lbl_FileHelp)
     .addComponent(TF_FileInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE))
  );

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_ImportInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ImportInfo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ImportInfo.setText("{ Klik utk melihat aturan impor-tambah }");
  Lbl_ImportInfo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ImportInfo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ImportInfoMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(Lbl_ImportInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok)
    .addComponent(Lbl_ImportInfo))
  );

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("- - - Defenisikan Data Yg Akan Di-impor - - -");

  jLabel1.setBackground(new java.awt.Color(204, 204, 255));
  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("Atribut");
  jLabel1.setOpaque(true);

  Lbl_FileField1.setBackground(new java.awt.Color(204, 204, 255));
  Lbl_FileField1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileField1.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileField1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_FileField1.setText("Field Pd File");
  Lbl_FileField1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileField1.setOpaque(true);
  Lbl_FileField1.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileField1MouseClicked(evt);
   }
  });

  jLabel6.setBackground(new java.awt.Color(204, 204, 255));
  jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel6.setText("Defenisi Sendiri");
  jLabel6.setOpaque(true);

  TF_NameFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_NameFileFocusGained(evt);
   }
  });
  TF_NameFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameFileKeyPressed(evt);
   }
  });

  Lbl_Name.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Name.setText("Nama Subjek");

  CB_BirthdayFile.setText(" ");
  CB_BirthdayFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_BirthdayFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BirthdayFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BirthdayFileActionPerformed(evt);
   }
  });
  CB_BirthdayFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BirthdayFileKeyPressed(evt);
   }
  });

  TF_BirthdayFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BirthdayFileFocusGained(evt);
   }
  });
  TF_BirthdayFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BirthdayFileKeyPressed(evt);
   }
  });

  CmB_BirthdayDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_BirthdayDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BirthdayDefMKeyPressed(evt);
   }
  });

  CmB_BirthdayDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_BirthdayDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BirthdayDefDKeyPressed(evt);
   }
  });

  TF_BirthdayDefY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BirthdayDefYFocusGained(evt);
   }
  });
  TF_BirthdayDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BirthdayDefYKeyPressed(evt);
   }
  });

  CB_BirthdayDefIsSet.setText(" ");
  CB_BirthdayDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BirthdayDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BirthdayDefIsSetActionPerformed(evt);
   }
  });
  CB_BirthdayDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BirthdayDefIsSetKeyPressed(evt);
   }
  });

  Lbl_Birthday.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Birthday.setText("Tgl Lahir");

  CB_CommentFile.setText(" ");
  CB_CommentFile.setToolTipText("centang utk mengambil nilai 'Atribut' dari 'Field Pada File'");
  CB_CommentFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CommentFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_CommentFileActionPerformed(evt);
   }
  });
  CB_CommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentFileKeyPressed(evt);
   }
  });

  TF_CommentFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CommentFileFocusGained(evt);
   }
  });
  TF_CommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CommentFileKeyPressed(evt);
   }
  });

  TA_CommentDef.setColumns(20);
  TA_CommentDef.setLineWrap(true);
  TA_CommentDef.setWrapStyleWord(true);
  TA_CommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentDefKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_CommentDef);

  Lbl_CommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentDefHelp.setText("(?)");
  Lbl_CommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentDefHelpMouseClicked(evt);
   }
  });

  Lbl_Comment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Comment.setText("Keterangan");

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_Name, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
     .addComponent(Lbl_Birthday, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_Comment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addGap(6, 6, 6)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
      .addComponent(CB_CommentFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_CommentFile))
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
      .addComponent(CB_BirthdayFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BirthdayFile))
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
      .addGap(29, 29, 29)
      .addComponent(TF_NameFile))
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
      .addComponent(Lbl_FileField1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, Short.MAX_VALUE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addComponent(CB_BirthdayDefIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_BirthdayDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BirthdayDefM, 0, 167, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BirthdayDefD, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CommentDefHelp))))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel1)
     .addComponent(Lbl_FileField1)
     .addComponent(jLabel6))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_NameFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Name))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BirthdayFile)
     .addComponent(TF_BirthdayFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BirthdayDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BirthdayDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_BirthdayDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BirthdayDefIsSet)
     .addComponent(Lbl_Birthday))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
        .addComponent(CB_CommentFile)
        .addComponent(TF_CommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addComponent(Lbl_Comment))
       .addComponent(Lbl_CommentDefHelp))
      .addContainerGap(153, Short.MAX_VALUE))
     .addComponent(jScrollPane2)))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel3)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation IsValid;
  boolean CurrValid;
  
  // validate file csv
  if(ChoosedFile==null){
   JOptionPane.showMessageDialog(null, "Belum ada file CSV yg dipilih !");
   return;
  }
  FileCsv=ChoosedFile;
  
  // validate import data input
  IsValid=new OValidation(true);
  
  CurrValid=false;
  do{
   NameFileField.Value=fileFieldIsValid(TF_NameFile); if(NameFileField.Value==-1){break;}
   CurrValid=true;
  }while(false);
  setValid(CurrValid, Lbl_Name, IsValid);
  
  // check date
  checkDate(BirthdayByFile, BirthdayFileField, Birthday, CB_BirthdayFile, TF_BirthdayFile, CB_BirthdayDefIsSet, TF_BirthdayDefY, CmB_BirthdayDefM, CmB_BirthdayDefD, Lbl_Birthday, IsValid);
  
  // check string
  checkString(CommentByFile, CommentFileField, Comment, CB_CommentFile, TF_CommentFile, TA_CommentDef, Lbl_Comment, IsValid, true, CApp.DbVarcharMaxSize);
  
  if(!IsValid.getValid()){
   JOptionPane.showMessageDialog(null, "Inputan data masih salah !"+
    "\nSilahkan koreksi inputan data pada label berwarna merah !");
   return;
  }
  
  clearComponents();
  DialogResult=1;
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_ChooseFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseFileActionPerformed
  File f;
  F_CsvReadOption fm=IFV.FCsvReadOption;
  
  f=PGUI.showLoadDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  setFileCsv(f, fm.FieldDelimiter, fm.FieldsSeparators, CCore.CsvRecordsSeparators, true);
 }//GEN-LAST:event_Btn_ChooseFileActionPerformed

 private void Lbl_FileHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileHelpMouseClicked
  JOptionPane.showMessageDialog(null, PMyShop.getReadWriteCsvInfo(true));
 }//GEN-LAST:event_Lbl_FileHelpMouseClicked

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  DialogResult=0;
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  Activ=true;
 }//GEN-LAST:event_formWindowActivated

 private void Lbl_ImportInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ImportInfoMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Hanya mengimpor data barang jika Nama dari barang tsb belum ada di database."+"\n"+
   "- Semua nilai 'Definisi Sendiri' harus diisi dengan benar."+"\n"+
   "- Dalam proses mengimpor, nilai dari sebuah 'Atribut' akan diutamakan diambil dari 'Field Pada File',"+"\n"+
   "    tetapi jika gagal, maka nilai 'Definisi Sendiri' yg diambil."
   );
 }//GEN-LAST:event_Lbl_ImportInfoMouseClicked

 private void CB_BirthdayFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BirthdayFileActionPerformed
  enableFileField(CB_BirthdayFile, TF_BirthdayFile);
 }//GEN-LAST:event_CB_BirthdayFileActionPerformed

 private void CB_CommentFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_CommentFileActionPerformed
  enableFileField(CB_CommentFile, TF_CommentFile);
 }//GEN-LAST:event_CB_CommentFileActionPerformed

 private void Lbl_CommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_CommentDefHelpMouseClicked

 private void CB_BirthdayDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BirthdayDefIsSetActionPerformed
  PGUI.enableInput(CB_BirthdayDefIsSet.isSelected(), TF_BirthdayDefY, CmB_BirthdayDefM, CmB_BirthdayDefD, false);
 }//GEN-LAST:event_CB_BirthdayDefIsSetActionPerformed

 private void Lbl_FileField1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileField1MouseClicked
  JOptionPane.showMessageDialog(null,
   "Isi inputan dgn posisi field pd file."+
   "\n(jangkauan nilai mulai dari nilai 1 hingga 'jumlah field pada file').");
 }//GEN-LAST:event_Lbl_FileField1MouseClicked

 private void Btn_ChooseFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseFileKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseFileKeyPressed

 private void Tbl_FilePreviewKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_FilePreviewKeyReleased
  PNav.onKey_Tbl(this, Tbl_FilePreview, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_NameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Tbl_FilePreviewKeyReleased

 private void TF_NameFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameFileKeyPressed
  PNav.onKey_TF(this, TF_NameFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BirthdayFile, CB_BirthdayFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameFileKeyPressed

 private void CB_BirthdayFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BirthdayFileKeyPressed
  PNav.onKey_CB(this, CB_BirthdayFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_CommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BirthdayFile, CB_BirthdayDefIsSet)));
 }//GEN-LAST:event_CB_BirthdayFileKeyPressed

 private void TF_BirthdayFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BirthdayFileKeyPressed
  PNav.onKey_TF(this, TF_BirthdayFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CommentFile, CB_CommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BirthdayFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_BirthdayDefIsSet)));
 }//GEN-LAST:event_TF_BirthdayFileKeyPressed

 private void CB_BirthdayDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BirthdayDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_BirthdayDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_CommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BirthdayFile, CB_BirthdayFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BirthdayDefY)));
 }//GEN-LAST:event_CB_BirthdayDefIsSetKeyPressed

 private void TF_BirthdayDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BirthdayDefYKeyPressed
  PNav.onKey_TF(this, TF_BirthdayDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_CommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BirthdayDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BirthdayDefM)));
 }//GEN-LAST:event_TF_BirthdayDefYKeyPressed

 private void CmB_BirthdayDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BirthdayDefMKeyPressed
  PNav.onKey_CmB(this, CmB_BirthdayDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BirthdayDefY, CB_BirthdayDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BirthdayDefD)));
 }//GEN-LAST:event_CmB_BirthdayDefMKeyPressed

 private void CmB_BirthdayDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BirthdayDefDKeyPressed
  PNav.onKey_CmB(this, CmB_BirthdayDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BirthdayDefM, CB_BirthdayDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_CommentDef)));
 }//GEN-LAST:event_CmB_BirthdayDefDKeyPressed

 private void CB_CommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentFileKeyPressed
  PNav.onKey_CB(this, CB_CommentFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BirthdayFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CommentFile, TA_CommentDef)));
 }//GEN-LAST:event_CB_CommentFileKeyPressed

 private void TF_CommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CommentFileKeyPressed
  PNav.onKey_TF(this, TF_CommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BirthdayFile, CB_BirthdayFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_CommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_CommentDef)));
 }//GEN-LAST:event_TF_CommentFileKeyPressed

 private void TA_CommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentDefKeyPressed
  PNav.onKey_TA(this, TA_CommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BirthdayDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CommentFile, CB_CommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_CommentDefKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_CommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_CommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_NameFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_NameFileFocusGained
  PGUI.text_SelectAll(TF_NameFile);
 }//GEN-LAST:event_TF_NameFileFocusGained

 private void TF_BirthdayFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BirthdayFileFocusGained
  PGUI.text_SelectAll(TF_BirthdayFile);
 }//GEN-LAST:event_TF_BirthdayFileFocusGained

 private void TF_CommentFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CommentFileFocusGained
  PGUI.text_SelectAll(TF_CommentFile);
 }//GEN-LAST:event_TF_CommentFileFocusGained

 private void TF_BirthdayDefYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BirthdayDefYFocusGained
  PGUI.text_SelectAll(TF_BirthdayDefY);
 }//GEN-LAST:event_TF_BirthdayDefYFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseFile;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_BirthdayDefIsSet;
 private javax.swing.JCheckBox CB_BirthdayFile;
 private javax.swing.JCheckBox CB_CommentFile;
 private javax.swing.JComboBox<String> CmB_BirthdayDefD;
 private javax.swing.JComboBox<String> CmB_BirthdayDefM;
 private javax.swing.JLabel Lbl_Birthday;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_CommentDefHelp;
 private javax.swing.JLabel Lbl_File;
 private javax.swing.JLabel Lbl_FileField1;
 private javax.swing.JLabel Lbl_FileHelp;
 private javax.swing.JLabel Lbl_ImportInfo;
 private javax.swing.JLabel Lbl_Name;
 private javax.swing.ButtonGroup RG_Id;
 private javax.swing.JTextArea TA_CommentDef;
 private javax.swing.JTextField TF_BirthdayDefY;
 private javax.swing.JTextField TF_BirthdayFile;
 private javax.swing.JTextField TF_CommentFile;
 private javax.swing.JTextField TF_File;
 private javax.swing.JTextField TF_FileInfo;
 private javax.swing.JTextField TF_NameFile;
 private XTable Tbl_FilePreview;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 // End of variables declaration//GEN-END:variables
}
