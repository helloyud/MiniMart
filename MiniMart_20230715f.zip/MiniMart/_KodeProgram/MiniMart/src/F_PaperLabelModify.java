import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_PaperLabelModify extends XFormDialog {
 
 boolean LastSelectedIsRollPaper;
 
 // set
 int wMode; // 1 Normal, 2 Edit, 3 View
 OInfoCustomPaperLabel wData;
 
 // get
 OInfoCustomPaperLabel Data;
 
 //
 Object[] FocusOrdered;
 
 public F_PaperLabelModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  Lbl_PaperWidth.setText("- Lebar (0.00 - "+PText.priceToString(OUnit.pixel_to_mm(CPrint.PaperWidthMax))+")");
  Lbl_PaperHeight.setText("- Tinggi (0.00 - "+PText.priceToString(OUnit.pixel_to_mm(CPrint.PaperHeightMax))+")");
  
  RB_DrawCutLineN.setSelected(true);
  
  Data=new OInfoCustomPaperLabel();
  
  CmB_PaperKind.setSelectedIndex(0); CmB_PaperKind.repaint(); changeInputMode(true);
 }
 public void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  FocusOrdered=PCore.objArrVariant(
   TF_Name, CmB_PaperKind,
   TF_PaperWidth, TF_PaperHeight,
   TF_MarginLeft, TF_MarginTop,
   TF_LabelWidth, TF_LabelHeight,
   TF_LabelGapHorizontal, TF_LabelGapVerticalA, TF_LabelGapVerticalB,
   PCore.cmpArr(RB_DrawCutLineY, RB_DrawCutLineN),
   PCore.cmpArr(Btn_Ok, Btn_Cancel));
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   FocusOrdered,
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     if(Btn_Ok.isVisible()){Btn_OkActionPerformed(null);}
    }
   });
 }
 void clearComponents(){
  Lbl_Name.setForeground(CGUI.Color_Label_InputRight); TF_Name.setText("");
  CmB_PaperKind.setSelectedIndex(0); CmB_PaperKind.repaint(); changeInputMode(false);
  RB_DrawCutLineN.setSelected(true);
  Lbl_PaperWidth.setForeground(CGUI.Color_Label_InputRight); TF_PaperWidth.setText("");
  if(TF_PaperHeight.isEditable()){Lbl_PaperHeight.setForeground(CGUI.Color_Label_InputRight); TF_PaperHeight.setText("");}
  Lbl_MarginLeft.setForeground(CGUI.Color_Label_InputRight); TF_MarginLeft.setText("");
  if(TF_MarginTop.isEditable()){Lbl_MarginTop.setForeground(CGUI.Color_Label_InputRight); TF_MarginTop.setText("");}
  Lbl_LabelWidth.setForeground(CGUI.Color_Label_InputRight); TF_LabelWidth.setText("");
  Lbl_LabelHeight.setForeground(CGUI.Color_Label_InputRight); TF_LabelHeight.setText("");
  Lbl_LabelGapHorizontal.setForeground(CGUI.Color_Label_InputRight); TF_LabelGapHorizontal.setText("");
  if(TF_LabelGapVerticalA.isEditable()){Lbl_LabelGapVerticalA.setForeground(CGUI.Color_Label_InputRight); TF_LabelGapVerticalA.setText("");}
  Lbl_LabelGapVerticalB.setForeground(CGUI.Color_Label_InputRight); TF_LabelGapVerticalB.setText("");
  clearSetVariables();
 }
 void clearSetVariables(){
  wData=null;
 }
 void fillData(){
  TF_Name.setText(wData.PaperName);
  CmB_PaperKind.setSelectedIndex(PCore.subtBool_Int(!wData.IsRollPaper, 0, 1)); CmB_PaperKind.repaint(); changeInputMode(false);
  PGUI.selectRadioButton(wData.DrawCutLine, RB_DrawCutLineY, RB_DrawCutLineN);
  TF_PaperWidth.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.PaperWidth), true));
  if(TF_PaperHeight.isEditable()){TF_PaperHeight.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.PaperHeight), true));}
  TF_MarginLeft.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.MarginLeft), true));
  if(TF_MarginTop.isEditable()){TF_MarginTop.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.MarginTop), true));}
  TF_LabelWidth.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.LabelWidth), true));
  TF_LabelHeight.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.LabelHeight), true));
  TF_LabelGapHorizontal.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.LabelGapHorizontal), true));
  if(TF_LabelGapVerticalA.isEditable()){TF_LabelGapVerticalA.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.LabelGapVerticalA), true));}
  TF_LabelGapVerticalB.setText(PText.doubleToString(OUnit.pixel_to_mm(wData.LabelGapVerticalB), true));
 }
 void changeInputMode(boolean ProcessAnyway){
  boolean IsRollPaper=CmB_PaperKind.getSelectedIndex()==1;
  BufferedImage Img=null;
  String SamplePreview;
  
  if(LastSelectedIsRollPaper==IsRollPaper && !ProcessAnyway){return;}
  LastSelectedIsRollPaper=IsRollPaper;
  
  TF_PaperHeight.setEditable(!IsRollPaper);
  TF_PaperHeight.setText(PText.getString(TF_PaperHeight.isEditable(), "", "~"));
  if(!TF_PaperHeight.isEditable()){Lbl_PaperHeight.setForeground(CGUI.Color_Label_InputRight);}
  TF_PaperHeight.setBackground((Color)PCore.subtituteBool(TF_PaperHeight.isEditable(), CGUI.Color_TextBox_FocusOff, CGUI.Color_TextBox_Uneditable));
  
  TF_MarginTop.setEditable(!IsRollPaper);
  TF_MarginTop.setText(PText.getString(TF_MarginTop.isEditable(), "", "0"));
  if(!TF_MarginTop.isEditable()){Lbl_MarginTop.setForeground(CGUI.Color_Label_InputRight);}
  TF_MarginTop.setBackground((Color)PCore.subtituteBool(TF_MarginTop.isEditable(), CGUI.Color_TextBox_FocusOff, CGUI.Color_TextBox_Uneditable));
  
  TF_LabelGapVerticalA.setEditable(IsRollPaper);
  TF_LabelGapVerticalA.setText(PText.getString(TF_LabelGapVerticalA.isEditable(), "", "0"));
  if(!TF_LabelGapVerticalA.isEditable()){Lbl_LabelGapVerticalA.setForeground(CGUI.Color_Label_InputRight);}
  TF_LabelGapVerticalA.setBackground((Color)PCore.subtituteBool(TF_LabelGapVerticalA.isEditable(), CGUI.Color_TextBox_FocusOff, CGUI.Color_TextBox_Uneditable));
  
  SamplePreview=PText.getString(!IsRollPaper, "/pic/SampleOfPaperLabel_Normal.jpg", "/pic/SampleOfPaperLabel_Roll.jpg");
  try{Img=ImageIO.read(getClass().getResource(SamplePreview));}catch(Exception E){Img=null;}
  Panel_InputInfo.setImageSource(Img); Panel_InputInfo.repaint();
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_DrawCutLineAtTheEnd = new javax.swing.ButtonGroup();
  RG_IsRollPaper = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  TF_Name = new javax.swing.JTextField();
  Lbl_Name = new javax.swing.JLabel();
  TF_PaperWidth = new javax.swing.JTextField();
  jLabel2 = new javax.swing.JLabel();
  Lbl_PaperWidth = new javax.swing.JLabel();
  TF_PaperHeight = new javax.swing.JTextField();
  jLabel4 = new javax.swing.JLabel();
  Lbl_PaperHeight = new javax.swing.JLabel();
  jLabel6 = new javax.swing.JLabel();
  TF_MarginLeft = new javax.swing.JTextField();
  jLabel7 = new javax.swing.JLabel();
  Lbl_MarginLeft = new javax.swing.JLabel();
  TF_MarginTop = new javax.swing.JTextField();
  jLabel9 = new javax.swing.JLabel();
  Lbl_MarginTop = new javax.swing.JLabel();
  jLabel11 = new javax.swing.JLabel();
  TF_LabelWidth = new javax.swing.JTextField();
  jLabel12 = new javax.swing.JLabel();
  Lbl_LabelWidth = new javax.swing.JLabel();
  TF_LabelHeight = new javax.swing.JTextField();
  jLabel14 = new javax.swing.JLabel();
  Lbl_LabelHeight = new javax.swing.JLabel();
  jLabel16 = new javax.swing.JLabel();
  TF_LabelGapHorizontal = new javax.swing.JTextField();
  jLabel17 = new javax.swing.JLabel();
  Lbl_LabelGapHorizontal = new javax.swing.JLabel();
  jLabel19 = new javax.swing.JLabel();
  TF_LabelGapVerticalA = new javax.swing.JTextField();
  jLabel20 = new javax.swing.JLabel();
  Lbl_LabelGapVerticalA = new javax.swing.JLabel();
  RB_DrawCutLineY = new javax.swing.JRadioButton();
  RB_DrawCutLineN = new javax.swing.JRadioButton();
  Lbl_DrawCutLine = new javax.swing.JLabel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_NameHelp = new javax.swing.JLabel();
  Lbl_Title = new javax.swing.JLabel();
  Lbl_PaperKind = new javax.swing.JLabel();
  TF_LabelGapVerticalB = new javax.swing.JTextField();
  jLabel3 = new javax.swing.JLabel();
  Lbl_LabelGapVerticalB = new javax.swing.JLabel();
  CmB_PaperKind = new javax.swing.JComboBox<>();
  Panel_InputInfo = new XImgBoxMemory();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameKeyPressed(evt);
   }
  });

  Lbl_Name.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Name.setText("Nama Kertas");

  TF_PaperWidth.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaperWidthFocusGained(evt);
   }
  });
  TF_PaperWidth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaperWidthKeyPressed(evt);
   }
  });

  jLabel2.setText("mm");

  Lbl_PaperWidth.setText("- Lebar (0.01 - ??)");

  TF_PaperHeight.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaperHeightFocusGained(evt);
   }
  });
  TF_PaperHeight.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaperHeightKeyPressed(evt);
   }
  });

  jLabel4.setText("mm");

  Lbl_PaperHeight.setText("- Tinggi (0.01 - ??)");

  jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel6.setText("Ukuran Kertas");

  TF_MarginLeft.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_MarginLeftFocusGained(evt);
   }
  });
  TF_MarginLeft.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_MarginLeftKeyPressed(evt);
   }
  });

  jLabel7.setText("mm");

  Lbl_MarginLeft.setText("- Kiri (>= 0.00)");

  TF_MarginTop.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_MarginTopFocusGained(evt);
   }
  });
  TF_MarginTop.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_MarginTopKeyPressed(evt);
   }
  });

  jLabel9.setText("mm");

  Lbl_MarginTop.setText("- Atas (>= 0.00)");

  jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel11.setText("Margin Kertas");

  TF_LabelWidth.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelWidthFocusGained(evt);
   }
  });
  TF_LabelWidth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelWidthKeyPressed(evt);
   }
  });

  jLabel12.setText("mm");

  Lbl_LabelWidth.setText("- Lebar (> 0.00)");

  TF_LabelHeight.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelHeightFocusGained(evt);
   }
  });
  TF_LabelHeight.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelHeightKeyPressed(evt);
   }
  });

  jLabel14.setText("mm");

  Lbl_LabelHeight.setText("- Tinggi (> 0.00)");

  jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel16.setText("Ukuran Label");

  TF_LabelGapHorizontal.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelGapHorizontalFocusGained(evt);
   }
  });
  TF_LabelGapHorizontal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelGapHorizontalKeyPressed(evt);
   }
  });

  jLabel17.setText("mm");

  Lbl_LabelGapHorizontal.setText("- Horizontal (>= 0.00)");

  jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel19.setText("Gap Antar Label");

  TF_LabelGapVerticalA.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelGapVerticalAFocusGained(evt);
   }
  });
  TF_LabelGapVerticalA.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelGapVerticalAKeyPressed(evt);
   }
  });

  jLabel20.setText("mm");

  Lbl_LabelGapVerticalA.setText("- Vertikal A (>= 0.00)");

  RG_DrawCutLineAtTheEnd.add(RB_DrawCutLineY);
  RB_DrawCutLineY.setText("Ya");
  RB_DrawCutLineY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_DrawCutLineY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_DrawCutLineYKeyPressed(evt);
   }
  });

  RG_DrawCutLineAtTheEnd.add(RB_DrawCutLineN);
  RB_DrawCutLineN.setText("Tidak");
  RB_DrawCutLineN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_DrawCutLineN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_DrawCutLineNKeyPressed(evt);
   }
  });

  Lbl_DrawCutLine.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DrawCutLine.setText("Gambar Garis Potong");

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_NameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_NameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_NameHelp.setText("(?)");
  Lbl_NameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_NameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_NameHelpMouseClicked(evt);
   }
  });

  Lbl_Title.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_Title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_Title.setText("Tambah / Ubah Kertas Label");

  Lbl_PaperKind.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PaperKind.setText("Jenis Kertas");

  TF_LabelGapVerticalB.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_LabelGapVerticalBFocusGained(evt);
   }
  });
  TF_LabelGapVerticalB.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_LabelGapVerticalBKeyPressed(evt);
   }
  });

  jLabel3.setText("mm");

  Lbl_LabelGapVerticalB.setText("- Vertikal B (>= 0.00)");

  CmB_PaperKind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Kertas Biasa", "Kertas Rol" }));
  CmB_PaperKind.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_PaperKindActionPerformed(evt);
   }
  });
  CmB_PaperKind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PaperKindKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Btn_Cancel))
   .addComponent(Lbl_Title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
      .addGroup(jPanel1Layout.createSequentialGroup()
       .addComponent(Lbl_Name)
       .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
       .addComponent(Lbl_NameHelp))
      .addComponent(Lbl_LabelWidth, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_LabelGapVerticalA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_LabelGapHorizontal, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
      .addComponent(Lbl_LabelHeight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_MarginLeft, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_MarginTop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_PaperWidth, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_PaperHeight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_DrawCutLine, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(Lbl_PaperKind, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addComponent(Lbl_LabelGapVerticalB))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_Name)
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_LabelHeight)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel14))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_LabelGapHorizontal)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel17))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_LabelGapVerticalA)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel20))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
      .addComponent(TF_PaperWidth)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel2))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
      .addComponent(TF_PaperHeight)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel4))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_MarginLeft)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel7))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_MarginTop)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel12))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_LabelWidth)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel9))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(TF_LabelGapVerticalB)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel3))
     .addGroup(jPanel1Layout.createSequentialGroup()
      .addComponent(RB_DrawCutLineY)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(RB_DrawCutLineN)
      .addGap(0, 176, Short.MAX_VALUE))
     .addComponent(CmB_PaperKind, 0, 271, Short.MAX_VALUE)))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(Lbl_Title)
    .addGap(30, 30, 30)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Name)
     .addComponent(Lbl_NameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_PaperKind)
     .addComponent(CmB_PaperKind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel6)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaperWidth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2)
     .addComponent(Lbl_PaperWidth))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaperHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel4)
     .addComponent(Lbl_PaperHeight))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_MarginLeft, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_MarginLeft)
     .addComponent(jLabel7))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_MarginTop)
     .addComponent(jLabel12)
     .addComponent(TF_MarginTop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel16)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelWidth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel9)
     .addComponent(Lbl_LabelWidth))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel14)
     .addComponent(Lbl_LabelHeight))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel19)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelGapHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel17)
     .addComponent(Lbl_LabelGapHorizontal))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelGapVerticalA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel20)
     .addComponent(Lbl_LabelGapVerticalA))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelGapVerticalB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel3)
     .addComponent(Lbl_LabelGapVerticalB))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_DrawCutLine)
     .addComponent(RB_DrawCutLineY)
     .addComponent(RB_DrawCutLineN))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)))
  );

  Panel_InputInfo.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(Panel_InputInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Panel_InputInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  String str=null;
  
  if(Activ){return;}
  Activ=true;
  
  switch(wMode){
   case 1 : str="Tambah Kertas Label"; break;
   case 2 : str="Ubah Kertas Label"; break;
   default : str="Data Kertas Label"; break;
  }
  setTitle(str); Lbl_Title.setText(str);
  
  if(wMode!=1){fillData();}
  
  Btn_Ok.setVisible(wMode==1 || wMode==2);
  if(wMode==1 || wMode==2){str="Batal {Esc}";}else{str="Tutup {Esc}";}
  Btn_Cancel.setText(str);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  String str;
  double dbl;
  OValidation Error;
  
  // validate input
  IsValid=true;
  
  str=TF_Name.getText();
  if(!PText.checkInput(str, false, 150, 0, 1, 1, 0)){Lbl_Name.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_Name.setForeground(CGUI.Color_Label_InputRight); Data.PaperName=str;}
  
  Data.IsRollPaper=CmB_PaperKind.getSelectedIndex()==1;
  
  Data.DrawCutLine=RB_DrawCutLineY.isSelected();
  
  dbl=PText.parseDouble(TF_PaperWidth.getText(), -1D, -1D);
  if(dbl<=0 || dbl>OUnit.pixel_to_mm(CPrint.PaperWidthMax)){Lbl_PaperWidth.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_PaperWidth.setForeground(CGUI.Color_Label_InputRight); Data.PaperWidth=OUnit.mm_to_pixel(dbl);}
  
  if(TF_PaperHeight.isEditable()){
   dbl=PText.parseDouble(TF_PaperHeight.getText(), -1D, -1D);
   if(dbl<=0 || dbl>OUnit.pixel_to_mm(CPrint.PaperHeightMax)){Lbl_PaperHeight.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
   else{Lbl_PaperHeight.setForeground(CGUI.Color_Label_InputRight); Data.PaperHeight=OUnit.mm_to_pixel(dbl);}
  }
  
  dbl=PText.parseDouble(TF_MarginLeft.getText(), -1D, -1D);
  if(dbl<0){Lbl_MarginLeft.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_MarginLeft.setForeground(CGUI.Color_Label_InputRight); Data.MarginLeft=OUnit.mm_to_pixel(dbl);}
  
  if(TF_MarginTop.isEditable()){
   dbl=PText.parseDouble(TF_MarginTop.getText(), -1D, -1D);
   if(dbl<0){Lbl_MarginTop.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
   else{Lbl_MarginTop.setForeground(CGUI.Color_Label_InputRight); Data.MarginTop=OUnit.mm_to_pixel(dbl);}
  }
  
  dbl=PText.parseDouble(TF_LabelWidth.getText(), -1D, -1D);
  if(dbl<=0){Lbl_LabelWidth.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_LabelWidth.setForeground(CGUI.Color_Label_InputRight); Data.LabelWidth=OUnit.mm_to_pixel(dbl);}
  
  dbl=PText.parseDouble(TF_LabelHeight.getText(), -1D, -1D);
  if(dbl<=0){Lbl_LabelHeight.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_LabelHeight.setForeground(CGUI.Color_Label_InputRight); Data.LabelHeight=OUnit.mm_to_pixel(dbl);}
  
  dbl=PText.parseDouble(TF_LabelGapHorizontal.getText(), -1D, -1D);
  if(dbl<0){Lbl_LabelGapHorizontal.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_LabelGapHorizontal.setForeground(CGUI.Color_Label_InputRight); Data.LabelGapHorizontal=OUnit.mm_to_pixel(dbl);}
  
  if(TF_LabelGapVerticalA.isEditable()){
   dbl=PText.parseDouble(TF_LabelGapVerticalA.getText(), -1D, -1D);
   if(dbl<0){Lbl_LabelGapVerticalA.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
   else{Lbl_LabelGapVerticalA.setForeground(CGUI.Color_Label_InputRight); Data.LabelGapVerticalA=OUnit.mm_to_pixel(dbl);}
  }
  
  dbl=PText.parseDouble(TF_LabelGapVerticalB.getText(), -1D, -1D);
  if(dbl<0){Lbl_LabelGapVerticalB.setForeground(CGUI.Color_Label_InputWrong); IsValid=false;}
  else{Lbl_LabelGapVerticalB.setForeground(CGUI.Color_Label_InputRight); Data.LabelGapVerticalB=OUnit.mm_to_pixel(dbl);}
  
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat inputan yang salah !\n"+
    "Silahkan koreksi inputan pada parameter yg bertanda merah !");
   return;
  }
  
  Error=new OValidation(true);
  
  do{
   if(!TF_MarginTop.isEditable()){Data.MarginTop=OUnit.mm_to_pixel(0);}
   if(!TF_LabelGapVerticalA.isEditable()){Data.LabelGapVerticalA=OUnit.mm_to_pixel(0);}
   if(!TF_PaperHeight.isEditable()){Data.PaperHeight=Data.MarginTop+Data.LabelGapVerticalA+Data.LabelHeight+Data.LabelGapVerticalB;}

   if(Data.PaperHeight>CPrint.PaperHeightMax){
    Error.addError("\n- Untuk kertas rol, 'Gap Vertikal-A' + 'Tinggi Label' + 'Gap Vertikal-B' harus <= "+
     PText.priceToString(OUnit.pixel_to_mm(CPrint.PaperHeightMax))+" mm.");
   }
   
   if(!Error.getValid()){break;}
   
   if(OPaperLabel.validate(
    Data.PaperWidth, Data.PaperHeight, Data.MarginLeft, Data.MarginTop,
    Data.PaperWidth-Data.MarginLeft, Data.PaperHeight-Data.MarginTop,
    Data.IsRollPaper,
    Data.LabelWidth, Data.LabelHeight,
    Data.LabelGapHorizontal, Data.LabelGapVerticalA, Data.LabelGapVerticalB)==false){
    Error.addError("\n- Hasil perhitungan tidak dapat membuat sebuah kertas label yang valid.");
   }
   
   if(!Error.getValid()){break;}
  }while(false);
  
  if(!Error.getValid()){
   JOptionPane.showMessageDialog(null, "Tidak dapat memproses :"+Error.getError());
   return;
  }
  
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Lbl_NameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_NameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 150, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_NameHelpMouseClicked

 private void CmB_PaperKindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_PaperKindActionPerformed
  changeInputMode(false);
 }//GEN-LAST:event_CmB_PaperKindActionPerformed

 private void TF_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameKeyPressed
  PNav.onKey_TF(this, TF_Name, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameKeyPressed

 private void CmB_PaperKindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PaperKindKeyPressed
  PNav.onKey_CmB(this, CmB_PaperKind, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsOrdr_Lf.init(false, false, false, FocusOrdered),
   /* Right */  CNav.B_FcsOrdr_Rg.init(false, false, true, FocusOrdered));
 }//GEN-LAST:event_CmB_PaperKindKeyPressed

 private void TF_PaperWidthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaperWidthKeyPressed
  PNav.onKey_TF(this, TF_PaperWidth, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_PaperWidthKeyPressed

 private void TF_PaperHeightKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaperHeightKeyPressed
  PNav.onKey_TF(this, TF_PaperHeight, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_PaperHeightKeyPressed

 private void TF_MarginLeftKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_MarginLeftKeyPressed
  PNav.onKey_TF(this, TF_MarginLeft, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_MarginLeftKeyPressed

 private void TF_MarginTopKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_MarginTopKeyPressed
  PNav.onKey_TF(this, TF_MarginTop, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_MarginTopKeyPressed

 private void TF_LabelWidthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelWidthKeyPressed
  PNav.onKey_TF(this, TF_LabelWidth, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_LabelWidthKeyPressed

 private void TF_LabelHeightKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelHeightKeyPressed
  PNav.onKey_TF(this, TF_LabelHeight, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_LabelHeightKeyPressed

 private void TF_LabelGapHorizontalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelGapHorizontalKeyPressed
  PNav.onKey_TF(this, TF_LabelGapHorizontal, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_LabelGapHorizontalKeyPressed

 private void TF_LabelGapVerticalAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelGapVerticalAKeyPressed
  PNav.onKey_TF(this, TF_LabelGapVerticalA, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_LabelGapVerticalAKeyPressed

 private void TF_LabelGapVerticalBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_LabelGapVerticalBKeyPressed
  PNav.onKey_TF(this, TF_LabelGapVerticalB, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_LabelGapVerticalBKeyPressed

 private void RB_DrawCutLineYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_DrawCutLineYKeyPressed
  PNav.onKey_RB(this, RB_DrawCutLineY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_DrawCutLineN)));
 }//GEN-LAST:event_RB_DrawCutLineYKeyPressed

 private void RB_DrawCutLineNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_DrawCutLineNKeyPressed
  PNav.onKey_RB(this, RB_DrawCutLineN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_DrawCutLineY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_RB_DrawCutLineNKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsOrdr_Up.init(false, false, false, FocusOrdered),
   /* Down  */  CNav.B_FcsOrdr_Dw.init(false, false, true, FocusOrdered),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_PaperWidthFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaperWidthFocusGained
  PGUI.text_SelectAll(TF_PaperWidth);
 }//GEN-LAST:event_TF_PaperWidthFocusGained

 private void TF_PaperHeightFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaperHeightFocusGained
  PGUI.text_SelectAll(TF_PaperHeight);
 }//GEN-LAST:event_TF_PaperHeightFocusGained

 private void TF_MarginLeftFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_MarginLeftFocusGained
  PGUI.text_SelectAll(TF_MarginLeft);
 }//GEN-LAST:event_TF_MarginLeftFocusGained

 private void TF_MarginTopFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_MarginTopFocusGained
  PGUI.text_SelectAll(TF_MarginTop);
 }//GEN-LAST:event_TF_MarginTopFocusGained

 private void TF_LabelWidthFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelWidthFocusGained
  PGUI.text_SelectAll(TF_LabelWidth);
 }//GEN-LAST:event_TF_LabelWidthFocusGained

 private void TF_LabelHeightFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelHeightFocusGained
  PGUI.text_SelectAll(TF_LabelHeight);
 }//GEN-LAST:event_TF_LabelHeightFocusGained

 private void TF_LabelGapHorizontalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelGapHorizontalFocusGained
  PGUI.text_SelectAll(TF_LabelGapHorizontal);
 }//GEN-LAST:event_TF_LabelGapHorizontalFocusGained

 private void TF_LabelGapVerticalAFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelGapVerticalAFocusGained
  PGUI.text_SelectAll(TF_LabelGapVerticalA);
 }//GEN-LAST:event_TF_LabelGapVerticalAFocusGained

 private void TF_LabelGapVerticalBFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_LabelGapVerticalBFocusGained
  PGUI.text_SelectAll(TF_LabelGapVerticalB);
 }//GEN-LAST:event_TF_LabelGapVerticalBFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JComboBox<String> CmB_PaperKind;
 private javax.swing.JLabel Lbl_DrawCutLine;
 private javax.swing.JLabel Lbl_LabelGapHorizontal;
 private javax.swing.JLabel Lbl_LabelGapVerticalA;
 private javax.swing.JLabel Lbl_LabelGapVerticalB;
 private javax.swing.JLabel Lbl_LabelHeight;
 private javax.swing.JLabel Lbl_LabelWidth;
 private javax.swing.JLabel Lbl_MarginLeft;
 private javax.swing.JLabel Lbl_MarginTop;
 private javax.swing.JLabel Lbl_Name;
 private javax.swing.JLabel Lbl_NameHelp;
 private javax.swing.JLabel Lbl_PaperHeight;
 private javax.swing.JLabel Lbl_PaperKind;
 private javax.swing.JLabel Lbl_PaperWidth;
 private javax.swing.JLabel Lbl_Title;
 private XImgBoxMemory Panel_InputInfo;
 private javax.swing.JRadioButton RB_DrawCutLineN;
 private javax.swing.JRadioButton RB_DrawCutLineY;
 private javax.swing.ButtonGroup RG_DrawCutLineAtTheEnd;
 private javax.swing.ButtonGroup RG_IsRollPaper;
 private javax.swing.JTextField TF_LabelGapHorizontal;
 private javax.swing.JTextField TF_LabelGapVerticalA;
 private javax.swing.JTextField TF_LabelGapVerticalB;
 private javax.swing.JTextField TF_LabelHeight;
 private javax.swing.JTextField TF_LabelWidth;
 private javax.swing.JTextField TF_MarginLeft;
 private javax.swing.JTextField TF_MarginTop;
 private javax.swing.JTextField TF_Name;
 private javax.swing.JTextField TF_PaperHeight;
 private javax.swing.JTextField TF_PaperWidth;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel12;
 private javax.swing.JLabel jLabel14;
 private javax.swing.JLabel jLabel16;
 private javax.swing.JLabel jLabel17;
 private javax.swing.JLabel jLabel19;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel20;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 // End of variables declaration//GEN-END:variables
}
