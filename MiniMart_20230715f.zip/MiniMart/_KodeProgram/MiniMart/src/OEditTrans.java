import java.util.Date;

public class OEditTrans {
 
 boolean EditTransInfoIdExternal; boolean ReplaceSubTransInfoIdExternal; String SubTransInfoIdExternal; String EditedTransInfoIdExternal;
 boolean EditTransImportant; Boolean EditedTransImportant;
 boolean EditTransDate; Date EditedTransDate;
 boolean EditTransCreditDays; Integer EditedTransCreditDays;
	boolean EditTransRepayPeriod; Date EditedTransRepayPeriodStart; Date EditedTransRepayPeriodEnd;
 boolean EditTransType; Integer EditedTransTypeId; String EditedTransTypeName;
 boolean EditCashOut; Integer EditedCashOutId; String EditedCashOutName;
 boolean EditCashOutComment; boolean ReplaceSubCashOutComment; String SubCashOutComment; String EditedCashOutComment;
 boolean EditCashIn; Integer EditedCashInId; String EditedCashInName;
 boolean EditCashInComment; boolean ReplaceSubCashInComment; String SubCashInComment; String EditedCashInComment;
 boolean EditTransSubject; Long EditedTransSubjectId; String EditedTransSubjectName;
 boolean EditTransSalesman; Long EditedTransSalesmanId; String EditedTransSalesmanName;
 boolean EditTransComment; boolean ReplaceSubTransComment; String SubTransComment; String EditedTransComment;

 public OEditTrans(){clearAll();}
 
 OEditTrans clearAll(){
  init(
   false, false, null, null,
   false, false,
   false, null,
   false, -1,
   false, null, null,
   false, -1, null,
   false, -1, null,
   false, false, null, null,
   false, -1, null,
   false, false, null, null,
   false, -1, null,
   false, -1, null,
   false, false, null, null);
  
  return this;
 }
 
 OEditTrans init(
  boolean EditTransInfoIdExternal, boolean ReplaceSubTransInfoIdExternal, String SubTransInfoIdExternal, String EditedTransInfoIdExternal,
  boolean EditTransImportant, boolean EditedTransImportant,
  boolean EditTransDate, Date EditedTransDate,
  boolean EditTransCreditDays, int EditedTransCreditDays,
  boolean EditTransRepayPeriod, Date EditedTransRepayPeriodStart, Date EditedTransRepayPeriodEnd,
  boolean EditTransType, int EditedTransTypeId, String EditedTransTypeName,
  boolean EditCashOut, int EditedCashOutId, String EditedCashOutName,
  boolean EditCashOutComment, boolean ReplaceSubCashOutComment, String SubCashOutComment, String EditedCashOutComment,
  boolean EditCashIn, int EditedCashInId, String EditedCashInName,
  boolean EditCashInComment, boolean ReplaceSubCashInComment, String SubCashInComment, String EditedCashInComment,
  boolean EditTransSubject, long EditedTransSubjectId, String EditedTransSubjectName,
  boolean EditTransSalesman, long EditedTransSalesmanId, String EditedTransSalesmanName,
  boolean EditTransComment, boolean ReplaceSubTransComment, String SubTransComment, String EditedTransComment) {
  
  this.EditTransInfoIdExternal = EditTransInfoIdExternal; this.ReplaceSubTransInfoIdExternal = ReplaceSubTransInfoIdExternal; this.SubTransInfoIdExternal = SubTransInfoIdExternal; this.EditedTransInfoIdExternal = EditedTransInfoIdExternal;
  this.EditTransImportant = EditTransImportant; this.EditedTransImportant = EditedTransImportant;
  this.EditTransDate = EditTransDate; this.EditedTransDate = EditedTransDate;
  this.EditTransCreditDays = EditTransCreditDays; this.EditedTransCreditDays = EditedTransCreditDays;
  this.EditTransRepayPeriod = EditTransRepayPeriod; this.EditedTransRepayPeriodStart = EditedTransRepayPeriodStart; this.EditedTransRepayPeriodEnd = EditedTransRepayPeriodEnd;
  this.EditTransType = EditTransType; this.EditedTransTypeId = EditedTransTypeId; this.EditedTransTypeName = EditedTransTypeName;
  this.EditCashOut = EditCashOut; this.EditedCashOutId = EditedCashOutId; this.EditedCashOutName = EditedCashOutName;
  this.EditCashOutComment = EditCashOutComment; this.ReplaceSubCashOutComment = ReplaceSubCashOutComment; this.SubCashOutComment = SubCashOutComment; this.EditedCashOutComment = EditedCashOutComment;
  this.EditCashIn = EditCashIn; this.EditedCashInId = EditedCashInId; this.EditedCashInName = EditedCashInName;
  this.EditCashInComment = EditCashInComment; this.ReplaceSubCashInComment = ReplaceSubCashInComment; this.SubCashInComment = SubCashInComment; this.EditedCashInComment = EditedCashInComment;
  this.EditTransSubject = EditTransSubject; this.EditedTransSubjectId = EditedTransSubjectId; this.EditedTransSubjectName = EditedTransSubjectName;
  this.EditTransSalesman = EditTransSalesman; this.EditedTransSalesmanId = EditedTransSalesmanId; this.EditedTransSalesmanName = EditedTransSalesmanName;
  this.EditTransComment = EditTransComment; this.ReplaceSubTransComment = ReplaceSubTransComment; this.SubTransComment = SubTransComment; this.EditedTransComment = EditedTransComment;
  
  return this;
 }
 
}