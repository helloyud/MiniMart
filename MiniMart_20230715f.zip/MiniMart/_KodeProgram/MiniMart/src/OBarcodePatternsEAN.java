public class OBarcodePatternsEAN extends OBarcodePatterns {
 
 /*
  EAN Specification
  - X-Dimension = 13 mil at magnification 100% (acceptable magnification in range 80% - 200%)
 */
 
 public static String[] getLeftPatternsA(){
  String[] ret=new String[10]; // 0 - 9
  
  ret[  0] = "0001101";
  ret[  1] = "0011001";
  ret[  2] = "0010011";
  ret[  3] = "0111101";
  ret[  4] = "0100011";
  ret[  5] = "0110001";
  ret[  6] = "0101111";
  ret[  7] = "0111011";
  ret[  8] = "0110111";
  ret[  9] = "0001011";
  
  return ret;
 }
 public static String[] getRightPatterns(){
  String[] ret=new String[10]; // 0 - 9
  
  ret[  0] = "1110010";
  ret[  1] = "1100110";
  ret[  2] = "1101100";
  ret[  3] = "1000010";
  ret[  4] = "1011100";
  ret[  5] = "1001110";
  ret[  6] = "1010000";
  ret[  7] = "1000100";
  ret[  8] = "1001000";
  ret[  9] = "1110100";
  
  return ret;
 }
 public static String getStartEndMarker(){return "101";}
 public static String getCenterMarker(){return "01010";}
 
}
