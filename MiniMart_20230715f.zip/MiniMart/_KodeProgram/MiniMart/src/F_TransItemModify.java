import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_TransItemModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 int wMode; // 0 Add_new, 1 edit
 long wItemId;
 double wQuantity;
 double wPriceTotal;
 String wTransItemComment;
 
 // get
 // Add Item
  // Item
 boolean RecheckId;
 long CheckedId, I_CheckedId;
 OInfoItem ItemInfo, I_ItemInfo;
 boolean InputInfoClearedItem;
 
 String I_TransItemComment, TransItemComment;
 
  // Qty
 double Qty, I_Qty;
 
  // Price
 double PriceUnit, I_PriceUnit;
 double PriceTotal, I_PriceTotal;
 boolean InputInfoClearedPrice;
 
  // Others
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 
 public F_TransItemModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  TF_TransItemComment.setToolTipText("isi komentar barang di sini .... (max "+PText.intToString(CApp.DbVarcharMaxSize)+" karakter)");
  
  I_ItemInfo=new OInfoItem();
  
  EnableDocumentListener=new VBoolean(true);
  
  TF_ItemId.setToolTipText("{F6} ket brg, {Spasi} cari brg, {Enter} tbh brg, {Down} ubah qty & hrg");
  TF_ItemId.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    
   });
  TF_Quantity.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    
   });
  TF_PriceUnit.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener.Value){
      inputPriceUnit();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener.Value){
      inputPriceUnit();
     }
    }
    
   });
  TF_PriceTotal.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==3 && EnableDocumentListener.Value){
      inputPriceTotal();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==3 && EnableDocumentListener.Value){
      inputPriceTotal();
     }
    }
    
   });
  
  RB_PriceUnit.addItemListener(new ItemListener(){
   public void itemStateChanged(ItemEvent evt){
    if(RB_PriceUnit.isSelected() && EnableDocumentListener.Value){switchInputPrice();}
   }
  });
  RB_PriceTotal.addItemListener(new ItemListener(){
   public void itemStateChanged(ItemEvent evt){
    if(RB_PriceTotal.isSelected() && EnableDocumentListener.Value){switchInputPrice();}
   }
  });
  
  EnableDocumentListener.Value=true;
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  I_CheckedId=-1; RecheckId=false;
  I_Qty=-1;
  I_PriceUnit=-1;
  I_PriceTotal=-1;
  I_TransItemComment=null;
  
  InputInfoClearedItem=true;
  InputInfoClearedPrice=true;
  
  // init components value
  RB_PriceUnit.setSelected(true);
  enableEditPrice(false);
  CmB_Price.setSelectedIndex(2);
 }
 
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_ChooseItem, TF_ItemId,
    TF_TransItemComment,
    TF_Quantity,
    CB_Price, CmB_Price, RB_PriceUnit, TF_PriceUnit, RB_PriceTotal, TF_PriceTotal,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearInputItem();
 }
 
 // Input Item Methods
  // Item
 void inputItem(){
  if(!changeItemMetadata()){return;}
  afterChangeItemMetadata();
 }
 boolean changeItemMetadata(){
  boolean ret=false;
  OInfoItem InfoItem;
  
  do{
   // Parse TF_ItemId
   try{I_CheckedId=Long.parseLong(TF_ItemId.getText());}catch(Exception E){break;}
   
   // Check if Item is exist in database
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId, false); if(InfoItem==null){break;}
   
   // init input-item's non-gui variables
   I_ItemInfo=InfoItem;
   changeItemQuantityPrice();
   
   ret=true;
  }while(false);
  
  if(!ret){I_CheckedId=-1; clearItem();}
  
  RecheckId=false;
  
  return ret;
 }
 void afterChangeItemMetadata(){
  // init input-item's gui variables
  setIQty(I_Qty, false);
  setIPriceUnit(I_PriceUnit, false);
  setIPriceTotal(I_PriceTotal, false);
  
  fillInputInfoItem();
  fillInputInfoPrice();
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
  I_PriceUnit=getPriceUnit(false, 0);
  I_PriceTotal=I_Qty*I_PriceUnit;
 }
 void fillInputInfoItem(){
  if(I_CheckedId==-1){clearInputInfoItem(); return;}
  
  TA_ItemName.setText(I_ItemInfo.Name);
  TF_ItemStock.setText(PText.priceToString(I_ItemInfo.Stock)+PText.getString(I_ItemInfo.StockUnit, -1, " "+I_ItemInfo.StockUnitName, ""));
  CB_ItemUpStock.setSelected(I_ItemInfo.UpdateStock);
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  PGUI.clearText(TA_ItemName, TF_ItemStock);
  CB_ItemUpStock.setSelected(false);
  
  InputInfoClearedItem=true;
 }
 void clearItem(){
  clearInputInfoItem();
  
  clearInputInfoPrice();
 }
 void focusItem(){
  PGUI.requestFocusInWindow(TF_ItemId);
 }
 void fillTransItemComment(String TransItemComment){TF_TransItemComment.setText(PText.getString(TransItemComment, "", false));}
 void clearTransItemComment(){TF_TransItemComment.setText("");}
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, "");}}
 }
 void inputQuantity(){
  I_Qty=PText.parseDouble(TF_Quantity.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}
  
  if(I_Qty<=0){return;}
  
  if(I_PriceUnit>=0){setIPriceTotal(I_PriceUnit*I_Qty, false);}
 }
 void focusQty(){
  PGUI.requestFocusInWindow(TF_Quantity);
 }
  // Price
 void setIPriceUnit(double Value, boolean ClearInvalidValue){
  I_PriceUnit=Value;
  
  if(I_PriceUnit>=0){PGUI.changeDocument(EnableDocumentListener, TF_PriceUnit, PText.doubleToString(I_PriceUnit, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_PriceUnit, "");}}
 }
 void setIPriceTotal(double Value, boolean ClearInvalidValue){
  I_PriceTotal=Value;
  
  if(I_PriceTotal>=0){PGUI.changeDocument(EnableDocumentListener, TF_PriceTotal, PText.doubleToString(I_PriceTotal, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_PriceTotal, "");}}
 }
 void fillInputInfoPrice(){
  String str=null;
  double PriceUnit;
  
  if(I_CheckedId==-1){clearInputInfoPrice(); return;}
  
  PriceUnit=getPriceUnit(false, 0);
  
  switch(CmB_Price.getSelectedIndex()){
   case 1 :
    if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){
     str=PText.priceToString(PriceUnit)+
      PText.getString(!PText.isEmptyString(I_ItemInfo.BuyPriceComment, true, true), "\n{ "+I_ItemInfo.BuyPriceComment+" }", "");
    }
    break;
   case 2 :
    str=PText.priceToString(PriceUnit)+
      PText.getString(!PText.isEmptyString(I_ItemInfo.SellPriceComment, true, true), "\n{ "+I_ItemInfo.SellPriceComment+" }", "");
    break;
  }
  
  TA_ItemPriceComment.setText(PText.getString(str, "", false));
  
  InputInfoClearedPrice=false;
 }
 void clearInputInfoPrice(){
  if(InputInfoClearedPrice){return;}
  
  PGUI.clearText(TA_ItemPriceComment);
  
  InputInfoClearedPrice=true;
 }
 double getPriceUnit(boolean KeepPresentUSPriceUnit, double PresentUSPriceUnit){
  // KeepPresentUSPriceUnit = keep present unit standard's price unit
  double ret=0;
  
  if(I_CheckedId==-1){return ret;}

  switch(CmB_Price.getSelectedIndex()){
   case 1 : 
    if(KeepPresentUSPriceUnit && PresentUSPriceUnit>0){ret=PresentUSPriceUnit;}
    else{if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){ret=I_ItemInfo.BuyPriceEstimation;}}
    break;
   case 2 : ret=I_ItemInfo.SellPrice; break;
  }
  
  return ret;
 }
 void inputPriceUnit(){
  I_PriceUnit=PText.parseDouble(TF_PriceUnit.getText(), -1D, -1D); if(I_PriceUnit<0){I_PriceUnit=-1;}

  if(I_PriceUnit<0){return;}
  
  if(I_Qty>0){setIPriceTotal(I_Qty*I_PriceUnit, false);}
 }
 void inputPriceTotal(){
  I_PriceTotal=PText.parseDouble(TF_PriceTotal.getText(), -1D, -1D); if(I_PriceTotal<0){I_PriceTotal=-1;}

  if(I_PriceTotal<0){return;}
  
  if(I_Qty>0){setIPriceUnit(I_PriceTotal/I_Qty, false);}
 }
 void focusPrice(){
  if(CB_Price.isSelected()){
   PGUI.requestFocusInWindow((Component)PCore.subtituteBool(RB_PriceUnit.isSelected(), TF_PriceUnit, TF_PriceTotal));
  }
 }
  // Others
 void fillInputVariablesIntoRealVariables(){
  CheckedId=I_CheckedId;
  ItemInfo=I_ItemInfo;
  
  Qty=I_Qty;
  PriceTotal=I_PriceTotal;
  PriceUnit=PriceTotal/Qty;
  
  TransItemComment=PText.getString(I_TransItemComment, null, true);
 }
 void clearInputItem(){
  EnableDocumentListener.Value=false;
  
  TF_ItemId.setText(""); I_CheckedId=-1; RecheckId=false; clearItem();
  setIQty(-1, true);
  setIPriceUnit(-1, true);
  setIPriceTotal(-1, true);
  clearTransItemComment();
  
  EnableDocumentListener.Value=true;
 }
 void changeDocument(JTextField TF, String Str){
  EnableDocumentListener.Value=false;
  TF.setText(Str);
  EnableDocumentListener.Value=true;
 }
 void focus(JTextField TF){
  TF.requestFocusInWindow();
 }
 void enableItemIdEdit(boolean Enable){
  TF_ItemId.setEditable(Enable);
  if(Enable){TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOff);}
  else{TF_ItemId.setBackground(CGUI.Color_TextBox_Uneditable);}
  Btn_ChooseItem.setEnabled(Enable);
 }
 void enablePriceUnit(boolean Enable){
  TF_PriceUnit.setEditable(Enable);
  if(Enable==true){
   if(TF_PriceUnit.isFocusOwner()){TF_PriceUnit.setBackground(CGUI.Color_TextBox_FocusOn);}
   else{TF_PriceUnit.setBackground(CGUI.Color_TextBox_FocusOff);}
  }
  else{TF_PriceUnit.setBackground(CGUI.Color_TextBox_Uneditable);}
 }
 void enablePriceTotal(boolean Enable){
  TF_PriceTotal.setEditable(Enable);
  if(Enable==true){
   if(TF_PriceTotal.isFocusOwner()){TF_PriceTotal.setBackground(CGUI.Color_TextBox_FocusOn);}
   else{TF_PriceTotal.setBackground(CGUI.Color_TextBox_FocusOff);}
  }
  else{TF_PriceTotal.setBackground(CGUI.Color_TextBox_Uneditable);}
 }
 void enableEditPrice(boolean Enable){
  RB_PriceUnit.setEnabled(Enable);
  RB_PriceTotal.setEnabled(Enable);
  if(Enable){
   if(RB_PriceUnit.isSelected()){enablePriceUnit(true);}
   else{enablePriceTotal(true);}
  }
  else{
   enablePriceUnit(false);
   enablePriceTotal(false);
  }
 }
 void switchInputPrice(){
  boolean PriceEditable=CB_Price.isSelected();
  boolean IsInputPriceUnit=RB_PriceUnit.isSelected();
  
  if(!PriceEditable){return;}
  enablePriceUnit(IsInputPriceUnit);
  enablePriceTotal(!IsInputPriceUnit);
 }
 
 //
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Price = new javax.swing.ButtonGroup();
  TF_PriceUnit = new javax.swing.JTextField();
  TF_PriceTotal = new javax.swing.JTextField();
  Lbl_ItemId = new javax.swing.JLabel();
  TF_Quantity = new javax.swing.JTextField();
  Lbl_Quantity = new javax.swing.JLabel();
  TF_ItemId = new javax.swing.JTextField();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  TF_ItemStock = new javax.swing.JTextField();
  CB_ItemUpStock = new javax.swing.JCheckBox();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  RB_PriceUnit = new javax.swing.JRadioButton();
  RB_PriceTotal = new javax.swing.JRadioButton();
  Btn_ChooseItem = new javax.swing.JButton();
  CB_Price = new javax.swing.JCheckBox();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemPriceComment = new javax.swing.JTextArea();
  CmB_Price = new javax.swing.JComboBox<>();
  TF_TransItemComment = new javax.swing.JTextField();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_PriceUnit.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_PriceUnit.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_PriceUnit.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PriceUnitFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_PriceUnitFocusLost(evt);
   }
  });
  TF_PriceUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PriceUnitKeyPressed(evt);
   }
  });

  TF_PriceTotal.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_PriceTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_PriceTotal.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PriceTotalFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_PriceTotalFocusLost(evt);
   }
  });
  TF_PriceTotal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PriceTotalKeyPressed(evt);
   }
  });

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Barang");
  Lbl_ItemId.setRequestFocusEnabled(false);

  TF_Quantity.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_Quantity.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_Quantity.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusLost(evt);
   }
  });
  TF_Quantity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QuantityKeyPressed(evt);
   }
  });

  Lbl_Quantity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Quantity.setText("Kuantitas");

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_ItemId.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_ItemId.setToolTipText("");
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(20);
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setToolTipText("klik utk melihat keterangan barang");
  TA_ItemName.setWrapStyleWord(true);
  TA_ItemName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_ItemName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_ItemNameMouseClicked(evt);
   }
  });
  jScrollPane1.setViewportView(TA_ItemName);

  TF_ItemStock.setEditable(false);
  TF_ItemStock.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemStock.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_ItemStock.setToolTipText("Jumlah Stok");

  CB_ItemUpStock.setToolTipText("Pembaruan Stok Saat Transaksi");
  CB_ItemUpStock.setEnabled(false);
  CB_ItemUpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemUpStock.setRequestFocusEnabled(false);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  RG_Price.add(RB_PriceUnit);
  RB_PriceUnit.setText("/ Unit");
  RB_PriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_PriceUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_PriceUnitKeyPressed(evt);
   }
  });

  RG_Price.add(RB_PriceTotal);
  RB_PriceTotal.setText("Total");
  RB_PriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_PriceTotal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_PriceTotalKeyPressed(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setToolTipText("Pilih sebuah barang");
  Btn_ChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });
  Btn_ChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseItemKeyPressed(evt);
   }
  });

  CB_Price.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_Price.setToolTipText("centang utk mengubah harga secara manual");
  CB_Price.setIconTextGap(0);
  CB_Price.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Price.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_PriceActionPerformed(evt);
   }
  });
  CB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PriceKeyPressed(evt);
   }
  });

  TA_ItemPriceComment.setEditable(false);
  TA_ItemPriceComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemPriceComment.setColumns(20);
  TA_ItemPriceComment.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TA_ItemPriceComment.setLineWrap(true);
  TA_ItemPriceComment.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemPriceComment);

  CmB_Price.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_Price.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hrg", "Beli", "Jual" }));
  CmB_Price.setToolTipText("pilih jenis harga yg akan digunakan sebagai nilai awal");
  CmB_Price.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_PriceActionPerformed(evt);
   }
  });
  CmB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PriceKeyPressed(evt);
   }
  });

  TF_TransItemComment.setBackground(new java.awt.Color(255, 204, 204));
  TF_TransItemComment.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_TransItemComment.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TransItemComment.setToolTipText("");
  TF_TransItemComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransItemCommentKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_ItemId)
       .addComponent(Lbl_Quantity)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_Price)
        .addGap(0, 0, 0)
        .addComponent(CmB_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(layout.createSequentialGroup()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(RB_PriceUnit)
         .addComponent(RB_PriceTotal))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(TF_PriceUnit)
         .addComponent(TF_PriceTotal)))
       .addGroup(layout.createSequentialGroup()
        .addComponent(Btn_ChooseItem)
        .addGap(0, 0, 0)
        .addComponent(TF_ItemId))
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_ItemStock)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_ItemUpStock))
       .addComponent(jScrollPane1)
       .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE)
       .addComponent(TF_Quantity, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_TransItemComment))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_ItemId)
     .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ChooseItem))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_ItemUpStock, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ItemStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TransItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Quantity))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_Price, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_PriceUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(RB_PriceUnit)
      .addComponent(CmB_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PriceTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_PriceTotal))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 133, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation Valid;
  
  if(RecheckId){changeItemMetadata();}
  
  Valid=new OValidation(true);
  
  if(I_CheckedId==-1 || I_Qty<=0 || I_PriceUnit<0 || I_PriceTotal<0){
   Valid.addError("\n- Salah satu inputan di antara \"Id Brg, Qty, Hrg Sat, Hrg Total\" belum benar.");
  }
  
  I_TransItemComment=TF_TransItemComment.getText();
  if(!PText.checkInput(I_TransItemComment, true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)){
   Valid.addError("\n- Inputan \"Komentar Brg\" belum benar.");
  }
  
  if(!Valid.getValid()){JOptionPane.showMessageDialog(null, "Inputan belum benar !\n"+Valid.getError()); return;}
  
  fillInputVariablesIntoRealVariables();
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  closingForm(0);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  OInfoItem InfoItem;
  
  if(Activ){return;}
  
  Activ=true;

  I_CheckedId=-1; RecheckId=false;
  I_Qty=-1;
  I_PriceUnit=-1;
  I_PriceTotal=-1;
  I_TransItemComment=null;
  
  if(wMode==0){
   setTitle("Tambah Barang Baru Pada Transaksi");
   enableItemIdEdit(true);

   TF_ItemId.requestFocusInWindow();
  }
  else{
   setTitle("Ubah Barang Pada Transaksi");
   enableItemIdEdit(false);

   EnableDocumentListener.Value=false;
   
   I_CheckedId=wItemId; RecheckId=false;

   TF_ItemId.setText(String.valueOf(I_CheckedId));
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId, false); if(InfoItem==null){InfoItem=new OInfoItem();}
   I_ItemInfo=InfoItem;
   
   I_Qty=wQuantity;
   I_PriceTotal=wPriceTotal;
   I_PriceUnit=I_PriceTotal/I_Qty;
   I_TransItemComment=wTransItemComment;
   
   setIQty(I_Qty, false);
   setIPriceUnit(I_PriceUnit, false);
   setIPriceTotal(I_PriceTotal, false);
   fillTransItemComment(I_TransItemComment);

   fillInputInfoItem();
   fillInputInfoPrice();

   EnableDocumentListener.Value=true;

   CB_Price.setSelected(true);
   enableEditPrice(true);
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void CB_PriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_PriceActionPerformed
  enableEditPrice(CB_Price.isSelected());
 }//GEN-LAST:event_CB_PriceActionPerformed

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  if(Activ && RecheckId){inputItem();}
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  if(!PGUI.isEnabled(TF_ItemId)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_ItemId, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : case KeyEvent.VK_DOWN :
    if(wMode==0){
     if(Activ && RecheckId){inputItem();}
     focus(TF_Quantity);
    }
    break;
   case KeyEvent.VK_F6 :
    if(wMode==0){
     if(RecheckId){inputItem();}
    }
    break;
   case KeyEvent.VK_SPACE :
    evt.consume();
    if(wMode==0){Btn_ChooseItemActionPerformed(null);}
    break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void TF_QuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QuantityKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Quantity, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : if(CB_Price.isSelected()){focusPrice();}else{Btn_Ok.requestFocusInWindow();} break;
   case KeyEvent.VK_DOWN : if(CB_Price.isSelected()){focusPrice();}else{Btn_Ok.requestFocusInWindow();} break;
   case KeyEvent.VK_UP : if(TF_ItemId.isEditable()){focus(TF_ItemId);} break;
  }
 }//GEN-LAST:event_TF_QuantityKeyPressed

 private void TF_PriceUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PriceUnitKeyPressed
  if(!PGUI.isEnabled(TF_PriceUnit)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_PriceUnit, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_PriceUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focus(TF_Quantity); break;
   case KeyEvent.VK_ENTER : Btn_Ok.requestFocusInWindow(); break;
   case KeyEvent.VK_DOWN : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_TF_PriceUnitKeyPressed

 private void TF_PriceTotalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PriceTotalKeyPressed
  if(!PGUI.isEnabled(TF_PriceTotal)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_PriceTotal, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_PriceTotal)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focus(TF_Quantity); break;
   case KeyEvent.VK_ENTER : Btn_Ok.requestFocusInWindow(); break;
   case KeyEvent.VK_DOWN : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_TF_PriceTotalKeyPressed

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  if(!Btn_ChooseItem.isEnabled()){return;}
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult==1){
   // change ItemDet's variables directly from FItem
   I_CheckedId=IFV.FItem.ChoosedId[0];
   changeDocument(TF_ItemId, String.valueOf(I_CheckedId));
   inputItem();
   
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void TF_QuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusGained
  DocumentListenerFocus=1;
  PGUI.text_SelectAll(TF_Quantity);
 }//GEN-LAST:event_TF_QuantityFocusGained

 private void TF_QuantityFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_QuantityFocusLost

 private void TF_PriceUnitFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceUnitFocusGained
  DocumentListenerFocus=2;
  PGUI.text_SelectAll(TF_PriceUnit);
 }//GEN-LAST:event_TF_PriceUnitFocusGained

 private void TF_PriceUnitFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceUnitFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_PriceUnitFocusLost

 private void TF_PriceTotalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceTotalFocusGained
  DocumentListenerFocus=3;
  PGUI.text_SelectAll(TF_PriceTotal);
 }//GEN-LAST:event_TF_PriceTotalFocusGained

 private void TF_PriceTotalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceTotalFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_PriceTotalFocusLost

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : if(CB_Price.isSelected()){focusPrice();}else{TF_Quantity.requestFocusInWindow();} break;
   case KeyEvent.VK_RIGHT : Btn_Cancel.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : if(CB_Price.isSelected()){focusPrice();}else{TF_Quantity.requestFocusInWindow();} break;
   case KeyEvent.VK_LEFT : Btn_Ok.requestFocusInWindow(); break;
  }
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  PGUI.text_SelectAll(TF_ItemId);
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void CmB_PriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_PriceActionPerformed
  fillInputInfoPrice();
 }//GEN-LAST:event_CmB_PriceActionPerformed

 private void TA_ItemNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_ItemNameMouseClicked
  if(I_CheckedId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_ItemNameMouseClicked

 private void Btn_ChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseItemKeyPressed
  if(!PGUI.isEnabled(Btn_ChooseItem)){return;}
  
  int consumed=PNav.onKey_Btn(this, Btn_ChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ItemId)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Btn_ChooseItemKeyPressed

 private void RB_PriceUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_PriceUnitKeyPressed
  if(!PGUI.isEnabled(RB_PriceUnit)){return;}
  
  PNav.onKey_RB(this, RB_PriceUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_PriceTotal)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PriceUnit)));
 }//GEN-LAST:event_RB_PriceUnitKeyPressed

 private void RB_PriceTotalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_PriceTotalKeyPressed
  if(!PGUI.isEnabled(RB_PriceTotal)){return;}
  
  PNav.onKey_RB(this, RB_PriceTotal, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_PriceUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PriceTotal)));
 }//GEN-LAST:event_RB_PriceTotalKeyPressed

 private void CB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PriceKeyPressed
  PNav.onKey_CB(this, CB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_Price)));
 }//GEN-LAST:event_CB_PriceKeyPressed

 private void CmB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PriceKeyPressed
  PNav.onKey_CmB(this, CmB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_PriceUnit)));
 }//GEN-LAST:event_CmB_PriceKeyPressed

 private void TF_TransItemCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransItemCommentKeyPressed
  PNav.onKey_TF(this, TF_TransItemComment, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_TransItemCommentKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_ItemUpStock;
 private javax.swing.JCheckBox CB_Price;
 private javax.swing.JComboBox<String> CmB_Price;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_Quantity;
 private javax.swing.JRadioButton RB_PriceTotal;
 private javax.swing.JRadioButton RB_PriceUnit;
 private javax.swing.ButtonGroup RG_Price;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextArea TA_ItemPriceComment;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_ItemStock;
 private javax.swing.JTextField TF_PriceTotal;
 private javax.swing.JTextField TF_PriceUnit;
 private javax.swing.JTextField TF_Quantity;
 private javax.swing.JTextField TF_TransItemComment;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 // End of variables declaration//GEN-END:variables
}
