import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.util.Date;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_ConvertingModify extends XFormDialog{
 
 // set
 int wMode; // 1 Add, 2 Edit
 long wModeAdd_InitConvRule;
 
 // get
 OInfoConverting InfoConverting;
 
 // Converting
 OCustomComboBoxModel ComboMdlReasonOfConv;
 
 // Add Convert Rule
 long CheckedId; OInfoConvertRule ConvRuleDet;
 boolean CheckedDirection;
 double CheckedQuantity;
 
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 
 int LastSelectedConvRuleDirectionIndex;
 
 // Item Out
 OCustomTableModel TableMdlItemOut;
 VInteger LastSelectedRowItemOut;
 VBoolean ItemOutClear;
 VBoolean ItemOutInfoClear;
 
 // Item In
 OCustomTableModel TableMdlItemIn;
 VInteger LastSelectedRowItemIn;
 VBoolean ItemInClear;
 VBoolean ItemInInfoClear;
 
 public F_ConvertingModify(MInterFormVariables IFV_){
  String[] ColName;
  int[] ColType, ColShowOption, ColVisible, Editable, ColWidth;
  boolean[] ColEditable;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  this.IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Header
  ComboMdlReasonOfConv=new OCustomComboBoxModel();
  ComboMdlReasonOfConv.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_ReasonOfConv.setModel(ComboMdlReasonOfConv);
  
  // Add Convert Rule
  ConvRuleDet=new OInfoConvertRule();
  
  EnableDocumentListener=new VBoolean(true);
  DocumentListenerFocus=-1;
  
  TF_AddConvRuleQty.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){inputQuantity();}
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){inputQuantity();}
    }
   });
  
  RB_ConvRuleDirectionForward.addItemListener(new ItemListener(){
   public void itemStateChanged(ItemEvent evt){
    if(RB_ConvRuleDirectionForward.isSelected() && EnableDocumentListener.Value){inputDirection();}
   }
  });
  RB_ConvRuleDirectionBackward.addItemListener(new ItemListener(){
   public void itemStateChanged(ItemEvent evt){
    if(RB_ConvRuleDirectionBackward.isSelected() && EnableDocumentListener.Value){inputDirection();}
   }
  });
  
  PGUI.changeDocument(EnableDocumentListener, RB_ConvRuleDirectionForward); updateLastSelectedIndexConvRuleDirection();
  
  CheckedId=-1;
  CheckedDirection=RB_ConvRuleDirectionForward.isSelected();
  CheckedQuantity=-1;
  
  // List Items
  ColName=PMyShop.getConvertItems_ColumnsName();
  ColType=PMyShop.getConvertItems_ColumnsType();
  ColShowOption=PCore.changeValue(PCore.newIntegerArray(ColName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  ColVisible=PCore.primArr(1, 2, 3, 0, 4);
  Editable=PCore.primArr(-1);
  ColEditable=PCore.changeValue(PCore.newBooleanArray(ColName.length, false),
   Editable, PCore.newBooleanArray(Editable.length, true));
  ColWidth=PCore.primArr(CGUI.ColTextLrg, CGUI.ColNumSep04, CGUI.ColTextTiny, CGUI.ColNum13, CGUI.ColCheck);
  
  TableMdlItemOut=new OCustomTableModel(false, false, false, true, 0); TableMdlItemOut.setColumnsInfo(ColName, ColType, ColShowOption, ColVisible, ColEditable);
  Tbl_ItemOut.setModel(TableMdlItemOut); PGUI.resizeTableColumn(Tbl_ItemOut, ColWidth);
  refreshItemCount(true);
  LastSelectedRowItemOut=new VInteger(-1);
  ItemOutClear=new VBoolean(true);
  ItemOutInfoClear=new VBoolean(true);
  
  Pnl_ItemOutInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  TableMdlItemIn=new OCustomTableModel(false, false, false, true, 0); TableMdlItemIn.setColumnsInfo(ColName, ColType, ColShowOption, ColVisible, ColEditable);
  Tbl_ItemIn.setModel(TableMdlItemIn); PGUI.resizeTableColumn(Tbl_ItemIn, ColWidth);
  refreshItemCount(false);
  LastSelectedRowItemIn=new VInteger(-1);
  ItemInClear=new VBoolean(true);
  ItemInInfoClear=new VBoolean(true);
  
  Pnl_ItemInInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  //
  clearComponents();
 }
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD,
    CmB_ReasonOfConv,
    
    Btn_AddConvRuleChooseId,
    RB_ConvRuleDirectionForward, RB_ConvRuleDirectionBackward,
    TF_AddConvRuleQty,
    
    Tbl_ItemOut,
    
    Tbl_ItemIn,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+K
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_K, InputEvent.CTRL_DOWN_MASK, false), "ctrl_k");
  act.put("ctrl_k", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddConvRuleChooseIdActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearInputHeader();
  clearAddConvRuleInput(); DocumentListenerFocus=-1;
 }
 
 // Header
 void clearInputHeader(){
  ComboMdlReasonOfConv.removeAll();
 }
 
 // Add Convert Rule
 void changeConvRule(long Id, OInfoConvertRule InfoConvertRule){
  if(!changeConvRuleMetadata(Id, InfoConvertRule)){return;}
  afterChangeItemMetadata();
 }
 void changeConvRuleQuantityPrice(){
  CheckedDirection=true;
  if(CheckedQuantity==-1){CheckedQuantity=1;}
 }
 boolean changeConvRuleMetadata(long Id, OInfoConvertRule InfoConvertRule){
  boolean ret=false;
  OInfoConvertRule InfoConvRule;
  do{
   // Parse TF_ItemId
   CheckedId=Id;
   if(CheckedId==-1){clearAddConvRuleInfo(); clearItems(); break;}
   
   // Check if Item is exist in database
   InfoConvRule=InfoConvertRule;
   if(InfoConvRule==null){
    InfoConvRule=PMyShop.getConvertRuleInfo(IFV.Stm, CheckedId, true, false);
    if(InfoConvRule==null){CheckedId=-1; clearAddConvRuleInfo(); clearItems(); break;}
   }
   
   // Fill info item
   ConvRuleDet=InfoConvRule;
   changeConvRuleQuantityPrice();
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void afterChangeItemMetadata(){
  JRadioButton RB_ConvRuleDirection=(JRadioButton)PCore.subtituteBool(CheckedDirection, RB_ConvRuleDirectionForward, RB_ConvRuleDirectionBackward);
  
  fillAddConvRuleInfo();
  PGUI.changeDocument(EnableDocumentListener, RB_ConvRuleDirection); updateLastSelectedIndexConvRuleDirection();
  PGUI.changeDocument(EnableDocumentListener, TF_AddConvRuleQty, PText.doubleToString(CheckedQuantity, true));
  fillItems();
 }
 void inputDirection(){
  int ConvRuleDirectionIndex;
  
  ConvRuleDirectionIndex=getConvRuleDirectionIndex();
  if(LastSelectedConvRuleDirectionIndex==ConvRuleDirectionIndex){return;}
  
  LastSelectedConvRuleDirectionIndex=ConvRuleDirectionIndex;
  
  CheckedDirection=RB_ConvRuleDirectionForward.isSelected();
  
  // fill effected things
  fillItems();
 }
 void inputQuantity(){
  try{CheckedQuantity=Double.parseDouble(TF_AddConvRuleQty.getText());}catch(Exception E){CheckedQuantity=-1; clearItems(); return;}
  if(CheckedQuantity<=0){CheckedQuantity=-1; clearItems(); return;}

  // fill effected things
  fillItems();
 }
 void clearAddConvRuleInput(){
  CheckedId=-1; clearAddConvRuleInfo();
  PGUI.changeDocument(EnableDocumentListener, RB_ConvRuleDirectionForward); updateLastSelectedIndexConvRuleDirection(); CheckedDirection=RB_ConvRuleDirectionForward.isSelected();
  PGUI.changeDocument(EnableDocumentListener, TF_AddConvRuleQty, ""); CheckedQuantity=-1;
  clearItems();
 }
 
 void fillAddConvRuleInfo(){
  TA_AddConvRuleIdInfoName.setText(ConvRuleDet.Name);
 }
 void clearAddConvRuleInfo(){
  TA_AddConvRuleIdInfoName.setText("");
 }
 
 void focusConvRuleId(){
  if(!Btn_AddConvRuleChooseId.isEnabled()){return;}
  PGUI.requestFocusInWindow(Btn_AddConvRuleChooseId);
 }
 void focusConvRuleDirection(){
  PGUI.requestFocusInWindow(RB_ConvRuleDirectionForward, RB_ConvRuleDirectionBackward);
 }
 void focusConvRuleQty(){
  PGUI.requestFocusInWindow(TF_AddConvRuleQty);
 }
 
 int getConvRuleDirectionIndex(){
  int ret=-1;
  
  do{
   if(RB_ConvRuleDirectionForward.isSelected()){ret=1; break;}
   if(RB_ConvRuleDirectionBackward.isSelected()){ret=2; break;}
  }while(false);
  
  return ret;
 }
 void updateLastSelectedIndexConvRuleDirection(){
  LastSelectedConvRuleDirectionIndex=getConvRuleDirectionIndex();
 }
 
 // List Items
 void onSelectedRowChangedItem(boolean IsItemOut, boolean UpdateAnyway){
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  VInteger LastSelectedRow=(VInteger)PCore.subtituteBool(IsItemOut, LastSelectedRowItemOut, LastSelectedRowItemIn);
  
  int row;
  
  row=Tbl.getSelectedRow();
  if(LastSelectedRow.Value==row && !UpdateAnyway){return;}
  
  LastSelectedRow.Value=row;
  if(row==-1){clearItemInfo(IsItemOut);}
  else{fillItemInfo(IsItemOut, row);}
 }
 
 void refreshItemCount(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  JTextField TF_ItemCount=(JTextField)PCore.subtituteBool(IsItemOut, TF_ItemOutSumCount, TF_ItemInSumCount);
  
  TF_ItemCount.setText(PText.intToString(TableMdl.getRowCount()));
 }
 
 void fillItems(){
  if(CheckedId==-1 || CheckedQuantity==-1){return;}
  fillInputItems(true); fillInputItems(false);
 }
 void clearItems(){clearInputItems(true); clearInputItems(false);}
 void fillInputItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  Vector<Object[]> Data;
  VBoolean ItemClear=(VBoolean)PCore.subtituteBool(IsItemOut, ItemOutClear, ItemInClear);
  
  clearInputItems(IsItemOut);
  
  Data=ConvRuleDet.generateListItemsToConverting(IsItemOut, CheckedDirection, CheckedQuantity);
  TableMdl.append(Data);
  refreshItemCount(IsItemOut);
  
  ItemClear.Value=false;
 }
 void clearInputItems(boolean IsItemOut){
  VBoolean ItemClear=(VBoolean)PCore.subtituteBool(IsItemOut, ItemOutClear, ItemInClear);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  
  if(ItemClear.Value){return;}
  
  TableMdl.removeAll(); onSelectedRowChangedItem(IsItemOut, false);
  refreshItemCount(IsItemOut);
  
  ItemClear.Value=true;
 }
 void fillItemInfo(boolean IsItemOut, int row){
  VBoolean ItemInfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, ItemOutInfoClear, ItemInInfoClear);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  Object[] objs;
  
  objs=TableMdl.Mdl.Rows.elementAt(row);
  TA_InfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[1]);
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, objs[5]);
  
  ItemInfoClear.Value=false;
 }
 void clearItemInfo(boolean IsItemOut){
  VBoolean ItemInfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, ItemOutInfoClear, ItemInInfoClear);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  
  if(ItemInfoClear.Value){return;}
  
  TA_InfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, null);
  
  ItemInfoClear.Value=true;
 }
 
 // Others
 void fillComponentsWithSetVariables(){
  fillWithSetVariables_Header();
  fillWithSetVariables_ConvRule();
 }
 void fillWithSetVariables_Header(){
  PGUI.setDateComponent(InfoConverting.ConvDate, TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD);
  PGUI.findAndSelect_Number_ComboBox(ComboMdlReasonOfConv, CmB_ReasonOfConv, 0, InfoConverting.ReasonOfConvId, true, -1, true, 0, true, 0);
 }
 void fillWithSetVariables_ConvRule(){
  JRadioButton RB_ConvRuleDirection;
  
  CheckedId=-1; if(InfoConverting.ConvRule!=null){CheckedId=InfoConverting.ConvRule.Id; ConvRuleDet=InfoConverting.ConvRule;}
  if(CheckedId!=-1){fillAddConvRuleInfo();}else{clearAddConvRuleInfo();}
  
  CheckedDirection=InfoConverting.ConvRuleDirection;
  RB_ConvRuleDirection=(JRadioButton)PCore.subtituteBool(CheckedDirection, RB_ConvRuleDirectionForward, RB_ConvRuleDirectionBackward);
  PGUI.changeDocument(EnableDocumentListener, RB_ConvRuleDirection); updateLastSelectedIndexConvRuleDirection();
  
  CheckedQuantity=InfoConverting.ConvRuleCount; PGUI.changeDocument(EnableDocumentListener, TF_AddConvRuleQty, PText.doubleToString(CheckedQuantity, true));
  
  fillItems();
 }
 
 void setMode(){
  Btn_AddConvRuleChooseId.setEnabled(wMode==1);
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_ConvRuleDirection = new javax.swing.ButtonGroup();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  TF_ItemOutSumCount = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_ItemOut = new XTable();
  jPanel5 = new javax.swing.JPanel();
  Pnl_ItemOutInfoPreview = new XImgBoxURL();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemOutInfoName = new javax.swing.JTextArea();
  jPanel6 = new javax.swing.JPanel();
  jScrollPane5 = new javax.swing.JScrollPane();
  Tbl_ItemIn = new XTable();
  jPanel12 = new javax.swing.JPanel();
  TF_ItemInSumCount = new javax.swing.JTextField();
  jLabel10 = new javax.swing.JLabel();
  jPanel13 = new javax.swing.JPanel();
  Pnl_ItemInInfoPreview = new XImgBoxURL();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_ItemInInfoName = new javax.swing.JTextArea();
  jSeparator2 = new javax.swing.JSeparator();
  jPanel7 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  jPanel14 = new javax.swing.JPanel();
  CmB_ConvDateD = new javax.swing.JComboBox<>();
  CmB_ConvDateM = new javax.swing.JComboBox<>();
  Lbl_ConvDate = new javax.swing.JLabel();
  TF_ConvDateY = new javax.swing.JTextField();
  CmB_ReasonOfConv = new javax.swing.JComboBox<>();
  Lbl_ReasonOfConv = new javax.swing.JLabel();
  jSeparator1 = new javax.swing.JSeparator();
  jSeparator4 = new javax.swing.JSeparator();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_AddConvRuleIdInfoName = new javax.swing.JTextArea();
  Lbl_AddConvRuleId = new javax.swing.JLabel();
  Btn_AddConvRuleChooseId = new javax.swing.JButton();
  TF_AddConvRuleQty = new javax.swing.JTextField();
  Lbl_AddConvRuleQty = new javax.swing.JLabel();
  Lbl_ConvRuleDirection = new javax.swing.JLabel();
  RB_ConvRuleDirectionForward = new javax.swing.JRadioButton();
  RB_ConvRuleDirectionBackward = new javax.swing.JRadioButton();
  jLabel5 = new javax.swing.JLabel();
  jSeparator3 = new javax.swing.JSeparator();
  jSeparator5 = new javax.swing.JSeparator();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel3.setBackground(new java.awt.Color(255, 204, 153));
  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel4.setOpaque(false);

  TF_ItemOutSumCount.setEditable(false);
  TF_ItemOutSumCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutSumCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("Barang Keluar (Dari)");

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(TF_ItemOutSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_ItemOutSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel1))
  );

  Tbl_ItemOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemOut.setRowHeight(17);
  Tbl_ItemOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemOutMouseReleased(evt);
   }
  });
  Tbl_ItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemOutKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_ItemOut);

  Pnl_ItemOutInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemOutInfoName.setEditable(false);
  TA_ItemOutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoName.setColumns(20);
  TA_ItemOutInfoName.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_ItemOutInfoName.setLineWrap(true);
  TA_ItemOutInfoName.setRows(1);
  TA_ItemOutInfoName.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemOutInfoName);

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
   .addComponent(jScrollPane2)
  );

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel6.setBackground(new java.awt.Color(204, 255, 102));
  jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Tbl_ItemIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemIn.setRowHeight(17);
  Tbl_ItemIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemInMouseReleased(evt);
   }
  });
  Tbl_ItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemInKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(Tbl_ItemIn);

  jPanel12.setOpaque(false);

  TF_ItemInSumCount.setEditable(false);
  TF_ItemInSumCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInSumCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel10.setText("Barang Masuk (Ke)");

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
    .addComponent(TF_ItemInSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_ItemInSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel10))
  );

  Pnl_ItemInInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemInInfoName.setEditable(false);
  TA_ItemInInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoName.setColumns(20);
  TA_ItemInInfoName.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_ItemInInfoName.setLineWrap(true);
  TA_ItemInInfoName.setRows(1);
  TA_ItemInInfoName.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_ItemInInfoName);

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane6)
  );

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane5)
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  Btn_Cancel.setText("Cancel {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok))
  );

  jPanel14.setBackground(new java.awt.Color(221, 219, 192));

  CmB_ConvDateD.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  CmB_ConvDateD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_ConvDateD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ConvDateDKeyPressed(evt);
   }
  });

  CmB_ConvDateM.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  CmB_ConvDateM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
  CmB_ConvDateM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ConvDateMKeyPressed(evt);
   }
  });

  Lbl_ConvDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ConvDate.setText("Tanggal");

  TF_ConvDateY.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_ConvDateY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ConvDateYFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ConvDateYFocusLost(evt);
   }
  });
  TF_ConvDateY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ConvDateYKeyPressed(evt);
   }
  });

  CmB_ReasonOfConv.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  CmB_ReasonOfConv.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ReasonOfConvKeyPressed(evt);
   }
  });

  Lbl_ReasonOfConv.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ReasonOfConv.setText("Alasan");

  TA_AddConvRuleIdInfoName.setEditable(false);
  TA_AddConvRuleIdInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_AddConvRuleIdInfoName.setColumns(20);
  TA_AddConvRuleIdInfoName.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_AddConvRuleIdInfoName.setLineWrap(true);
  TA_AddConvRuleIdInfoName.setRows(1);
  TA_AddConvRuleIdInfoName.setToolTipText("");
  TA_AddConvRuleIdInfoName.setWrapStyleWord(true);
  TA_AddConvRuleIdInfoName.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
  jScrollPane4.setViewportView(TA_AddConvRuleIdInfoName);

  Lbl_AddConvRuleId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_AddConvRuleId.setText("Aturan");

  Btn_AddConvRuleChooseId.setText("{Ctrl+K}");
  Btn_AddConvRuleChooseId.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddConvRuleChooseId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddConvRuleChooseIdActionPerformed(evt);
   }
  });
  Btn_AddConvRuleChooseId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddConvRuleChooseIdKeyPressed(evt);
   }
  });

  TF_AddConvRuleQty.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_AddConvRuleQty.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_AddConvRuleQtyFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_AddConvRuleQtyFocusLost(evt);
   }
  });
  TF_AddConvRuleQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_AddConvRuleQtyKeyPressed(evt);
   }
  });

  Lbl_AddConvRuleQty.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_AddConvRuleQty.setText("Jumlah");

  Lbl_ConvRuleDirection.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ConvRuleDirection.setText("Arah");

  RG_ConvRuleDirection.add(RB_ConvRuleDirectionForward);
  RB_ConvRuleDirectionForward.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  RB_ConvRuleDirectionForward.setText("A ke B");
  RB_ConvRuleDirectionForward.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ConvRuleDirectionForward.setOpaque(false);
  RB_ConvRuleDirectionForward.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ConvRuleDirectionForwardKeyPressed(evt);
   }
  });

  RG_ConvRuleDirection.add(RB_ConvRuleDirectionBackward);
  RB_ConvRuleDirectionBackward.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  RB_ConvRuleDirectionBackward.setText("B ke A");
  RB_ConvRuleDirectionBackward.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ConvRuleDirectionBackward.setOpaque(false);
  RB_ConvRuleDirectionBackward.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ConvRuleDirectionBackwardKeyPressed(evt);
   }
  });

  jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel5.setText("Konversi Barang");

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel14Layout.createSequentialGroup()
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_ReasonOfConv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_ConvDate, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
     .addComponent(Lbl_ConvRuleDirection, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_AddConvRuleId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jSeparator4)
     .addComponent(jSeparator3)
     .addComponent(Lbl_AddConvRuleQty, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jSeparator5)
     .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(CmB_ReasonOfConv, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(TF_AddConvRuleQty)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
      .addComponent(TF_ConvDateY, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_ConvDateM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_ConvDateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel14Layout.createSequentialGroup()
      .addComponent(RB_ConvRuleDirectionForward)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(RB_ConvRuleDirectionBackward)
      .addContainerGap())
     .addGroup(jPanel14Layout.createSequentialGroup()
      .addComponent(Btn_AddConvRuleChooseId)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 322, Short.MAX_VALUE))))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addComponent(jLabel5)
    .addGap(18, 18, 18)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator5)
     .addComponent(jSeparator3))
    .addGap(18, 18, 18)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_ConvDateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_ConvDateM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ConvDateY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ConvDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_ReasonOfConv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ReasonOfConv))
    .addGap(18, 18, 18)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator1)
     .addComponent(jSeparator4))
    .addGap(18, 18, 18)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_AddConvRuleId)
     .addComponent(jScrollPane4)
     .addComponent(Btn_AddConvRuleChooseId, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_ConvRuleDirection)
     .addComponent(RB_ConvRuleDirectionForward)
     .addComponent(RB_ConvRuleDirectionBackward))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_AddConvRuleQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_AddConvRuleQty))
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation valid;
  Object[] objs;
  
  InfoConverting=new OInfoConverting(); valid=new OValidation(true);
  
  InfoConverting.ConvDate=PGUI.valueOfDateComponent(TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD);
  if(InfoConverting.ConvDate==null){valid.addError("\n- Inputan Tanggal belum benar.");}
  
  objs=ComboMdlReasonOfConv.Mdl.Rows.elementAt(CmB_ReasonOfConv.getSelectedIndex());
  InfoConverting.ReasonOfConvId=PCore.objInteger(objs[0], -1);
  InfoConverting.ReasonOfConvName=PCore.objString(objs[1], null);
  
  InfoConverting.ConvRule=new OInfoConvertRule();
  InfoConverting.ConvRule.Id=CheckedId; InfoConverting.ConvRule.fillValuesFrom(ConvRuleDet);
  InfoConverting.ConvRuleDirection=CheckedDirection;
  InfoConverting.ConvRuleCount=CheckedQuantity;
  if(InfoConverting.ConvRule.Id==-1 || InfoConverting.ConvRuleCount==-1){valid.addError("\n- Isian aturan konversi masih salah.");}
  
  if(!valid.getValid()){JOptionPane.showMessageDialog(null, "Inputan masih salah !\n"+valid.getError()); return;}
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void TF_AddConvRuleQtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_AddConvRuleQtyFocusGained
  DocumentListenerFocus=1;
  TF_AddConvRuleQty.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_AddConvRuleQty);
 }//GEN-LAST:event_TF_AddConvRuleQtyFocusGained

 private void TF_AddConvRuleQtyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_AddConvRuleQtyFocusLost
  DocumentListenerFocus=-1;
  TF_AddConvRuleQty.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_AddConvRuleQtyFocusLost

 private void TF_AddConvRuleQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_AddConvRuleQtyKeyPressed
  int consumed=PNav.onKey_TF(this, TF_AddConvRuleQty, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusConvRuleDirection(); break;
  }
 }//GEN-LAST:event_TF_AddConvRuleQtyKeyPressed

 private void Tbl_ItemOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemOutKeyReleased
  onSelectedRowChangedItem(true, false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ItemOut, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_ItemOutKeyReleased

 private void Tbl_ItemOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemOutMouseReleased
  onSelectedRowChangedItem(true, false);
 }//GEN-LAST:event_Tbl_ItemOutMouseReleased

 private void Tbl_ItemInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemInKeyReleased
  onSelectedRowChangedItem(false, false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ItemIn, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_ItemInKeyReleased

 private void Tbl_ItemInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemInMouseReleased
  onSelectedRowChangedItem(false, false);
 }//GEN-LAST:event_Tbl_ItemInMouseReleased

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  
  PDatabase.queryToComboBox(IFV.Stm, "select Id, Name from ReasonOfConv", ComboMdlReasonOfConv, true, PCore.refArr("Tidak Didefenisikan")); CmB_ReasonOfConv.setSelectedIndex(0);
  setMode();
  
  if(wMode==1){
   setTitle("Tambah Data Konversi");
   
   PGUI.setDateComponent(new Date(), TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD);
   
   if(wModeAdd_InitConvRule==-1){focusConvRuleId();}
   else{
    CheckedId=wModeAdd_InitConvRule;
    changeConvRule(CheckedId, null);

    focusConvRuleDirection();
   }
  }
  else{
   setTitle("Ubah Data Konversi");
   
   fillComponentsWithSetVariables();
   
   focusConvRuleQty();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void Pnl_ItemOutInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemOut, TableMdlItemOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutInfoPreviewMouseClicked

 private void Pnl_ItemInInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemIn, TableMdlItemIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInInfoPreviewMouseClicked

 private void Btn_AddConvRuleChooseIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddConvRuleChooseIdActionPerformed
  if(!Btn_AddConvRuleChooseId.isEnabled()){return;}
  
  IFV.FConvertRule.wMode=1;
  IFV.FConvertRule.wDialogWithFItem=true;
  IFV.FConvertRule.wAllowMultipleSelection=false;
  IFV.FConvertRule.wChooseActiveOnly=true;

  if(!IFV.FConvertRule.showForm()){return;}
  if(IFV.FConvertRule.DialogResult!=1){return;}

  // change ConvRuleDet's variables directly from FConvertRule
  CheckedId=IFV.FConvertRule.ChoosedId[0];
  changeConvRule(CheckedId, null);

  focusConvRuleDirection();
 }//GEN-LAST:event_Btn_AddConvRuleChooseIdActionPerformed

 private void RB_ConvRuleDirectionForwardKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ConvRuleDirectionForwardKeyPressed
  int consumed=PNav.onKey_RB(this, RB_ConvRuleDirectionForward, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP :
    evt.consume();
    do{
     if(Btn_AddConvRuleChooseId.isEnabled()){focusConvRuleId(); break;}
     PGUI.requestFocusInWindow(CmB_ReasonOfConv); break;
    }while(false);
    break;
   case KeyEvent.VK_LEFT : evt.consume(); break;
   case KeyEvent.VK_RIGHT : evt.consume(); RB_ConvRuleDirectionBackward.setSelected(true); PGUI.requestFocusInWindow(RB_ConvRuleDirectionBackward); break;
   case KeyEvent.VK_DOWN : evt.consume(); focusConvRuleQty(); break;
  }
 }//GEN-LAST:event_RB_ConvRuleDirectionForwardKeyPressed

 private void RB_ConvRuleDirectionBackwardKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ConvRuleDirectionBackwardKeyPressed
  int consumed=PNav.onKey_RB(this, RB_ConvRuleDirectionBackward, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP :
    evt.consume();
    do{
     if(Btn_AddConvRuleChooseId.isEnabled()){focusConvRuleId(); break;}
     PGUI.requestFocusInWindow(CmB_ReasonOfConv); break;
    }while(false);
    break;
   case KeyEvent.VK_LEFT : evt.consume(); RB_ConvRuleDirectionForward.setSelected(true); PGUI.requestFocusInWindow(RB_ConvRuleDirectionForward); break;
   case KeyEvent.VK_RIGHT : evt.consume(); break;
   case KeyEvent.VK_DOWN : evt.consume(); focusConvRuleQty(); break;
  }
 }//GEN-LAST:event_RB_ConvRuleDirectionBackwardKeyPressed

 private void Btn_AddConvRuleChooseIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddConvRuleChooseIdKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_AddConvRuleChooseId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_ReasonOfConv)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_DOWN : focusConvRuleDirection(); break;
  }
 }//GEN-LAST:event_Btn_AddConvRuleChooseIdKeyPressed

 private void CmB_ReasonOfConvKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ReasonOfConvKeyPressed
  int consumed=PNav.onKey_CmB(this, CmB_ReasonOfConv, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ConvDateY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_RIGHT :
    do{
     if(Btn_AddConvRuleChooseId.isEnabled()){focusConvRuleId(); break;}
     focusConvRuleDirection(); break;
    }while(false);
    break;
  }
 }//GEN-LAST:event_CmB_ReasonOfConvKeyPressed

 private void TF_ConvDateYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ConvDateYKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ConvDateY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_ReasonOfConv)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_ConvDateM)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_ConvDateYKeyPressed

 private void TF_ConvDateYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ConvDateYFocusGained
  TF_ConvDateY.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_ConvDateY);
 }//GEN-LAST:event_TF_ConvDateYFocusGained

 private void TF_ConvDateYFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ConvDateYFocusLost
  TF_ConvDateY.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_ConvDateYFocusLost

 private void CmB_ConvDateMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ConvDateMKeyPressed
  int consumed=PNav.onKey_CmB(this, CmB_ConvDateM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ConvDateY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_ConvDateD)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_CmB_ConvDateMKeyPressed

 private void CmB_ConvDateDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ConvDateDKeyPressed
  int consumed=PNav.onKey_CmB(this, CmB_ConvDateD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_ConvDateM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_ReasonOfConv)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_CmB_ConvDateDKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusConvRuleQty(); break;
  }
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  int consumed=PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusConvRuleQty(); break;
  }
 }//GEN-LAST:event_Btn_CancelKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_AddConvRuleChooseId;
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JComboBox<String> CmB_ConvDateD;
 private javax.swing.JComboBox<String> CmB_ConvDateM;
 private javax.swing.JComboBox<String> CmB_ReasonOfConv;
 private javax.swing.JLabel Lbl_AddConvRuleId;
 private javax.swing.JLabel Lbl_AddConvRuleQty;
 private javax.swing.JLabel Lbl_ConvDate;
 private javax.swing.JLabel Lbl_ConvRuleDirection;
 private javax.swing.JLabel Lbl_ReasonOfConv;
 private XImgBoxURL Pnl_ItemInInfoPreview;
 private XImgBoxURL Pnl_ItemOutInfoPreview;
 private javax.swing.JRadioButton RB_ConvRuleDirectionBackward;
 private javax.swing.JRadioButton RB_ConvRuleDirectionForward;
 private javax.swing.ButtonGroup RG_ConvRuleDirection;
 private javax.swing.JTextArea TA_AddConvRuleIdInfoName;
 private javax.swing.JTextArea TA_ItemInInfoName;
 private javax.swing.JTextArea TA_ItemOutInfoName;
 private javax.swing.JTextField TF_AddConvRuleQty;
 private javax.swing.JTextField TF_ConvDateY;
 private javax.swing.JTextField TF_ItemInSumCount;
 private javax.swing.JTextField TF_ItemOutSumCount;
 private XTable Tbl_ItemIn;
 private XTable Tbl_ItemOut;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 // End of variables declaration//GEN-END:variables
}
