import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Vector;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;
import javax.swing.text.JTextComponent;

public class PGUI {
	
 public static void setDateComponent(Date Dt, JTextField CYear, JComboBox CMonth, JComboBox CDay){
  OGregorianCalendar Cal;
  
		if(Dt==null){return;}
  
  Cal=new OGregorianCalendar(); Cal.setNewTime(Dt);
  
		CYear.setText(String.valueOf(Cal.get(Calendar.YEAR)));
  CMonth.setSelectedIndex(Cal.get(GregorianCalendar.MONTH));
  CDay.setSelectedIndex(Cal.get(GregorianCalendar.DAY_OF_MONTH)-1);
 }
 public static void setDateComponent(Date Dt, JCheckBox CEnable, JTextField CYear, JComboBox CMonth, JComboBox CDay, boolean ClearNotEnable){
  if(CEnable!=null){
   CEnable.setSelected(Dt!=null);
   enableInput(Dt!=null, CYear, CMonth, CDay, ClearNotEnable);
  }
  setDateComponent(Dt, CYear, CMonth, CDay);
 }
 public static void clearDateComponent(JTextField CYear, JComboBox CMonth, JComboBox CDay){
  CYear.setText("");
  CMonth.setSelectedIndex(0);
  CDay.setSelectedIndex(0);
 }
 public static Date valueOfDateComponent(JTextField CYear, JComboBox CMonth, JComboBox CDay){
  // Year only in range 1-999999
  Date ret=null;
  int year, month, day;
  String str;
		OGregorianCalendar Cal=new OGregorianCalendar();
  
  do{
   str=CYear.getText();
   if(!PText.checkInput(str, false, 6, 2, 7, 0, 0)){break;}
   year=Integer.parseInt(str);
   month=CMonth.getSelectedIndex();
   day=CDay.getSelectedIndex()+1;
   if(!Cal.setNewTime(year, month, day)){break;}
   ret=Cal.getTime();
  }while(false);
  
  return ret;
 }
 
 public static void selectRadioButton(boolean Value, JRadioButton RB_TrueValue, JRadioButton RB_FalseValue){
  if(Value){RB_TrueValue.setSelected(true);}else{RB_FalseValue.setSelected(true);}
 }

 public static void resizeTableColumn(JTable Tbl, int[] ColumnsIndex, int[] ColumnsWidth){
  int temp, tblcolcount, colidx;
  TableColumnModel ColMdl;
  
  tblcolcount=Tbl.getColumnCount();
  if(tblcolcount==0 || ColumnsIndex.length==0){return;}
  
  ColMdl=Tbl.getColumnModel();
  temp=0;
  do{
   colidx=ColumnsIndex[temp];
   if(colidx>=0 && colidx<tblcolcount){
    ColMdl.getColumn(colidx).setPreferredWidth(ColumnsWidth[temp]);
   }
   temp=temp+1;
  }while(temp!=ColumnsIndex.length);
 }
 public static void resizeTableColumn(JTable Tbl, int[] ColumnsWidth){
  resizeTableColumn(Tbl, PCore.newIntegerArrayInOrderedSequence(ColumnsWidth.length, 0, 1), ColumnsWidth);
 }

 public static void alignTableColumnText(JTable Tbl, int[] ColumnsIndex, int[] ColumnsHorizontalAlignment){
  // ColumnsHorizontalAlignment's value must be : SwingConstants.LEFT, CENTER, RIGHT, LEADING, TRAILING
  int temp, tblcolcount, colidx;
  TableColumnModel ColMdl;
  DefaultTableCellRenderer renderer;
  
  tblcolcount=Tbl.getColumnCount();
  if(tblcolcount==0 || ColumnsIndex.length==0){return;}
  
  ColMdl=Tbl.getColumnModel();
  temp=0;
  do{
   colidx=ColumnsIndex[temp];
   if(colidx>=0 && colidx<tblcolcount){
    renderer=new DefaultTableCellRenderer();
    renderer.setHorizontalAlignment(ColumnsHorizontalAlignment[temp]);
    ColMdl.getColumn(colidx).setCellRenderer(renderer);
   }
   temp=temp+1;
  }while(temp!=ColumnsIndex.length);
 }

 public static void repaint(JComponent AComponent){
  AComponent.paintImmediately(0, 0, AComponent.getWidth(), AComponent.getHeight());
 }

 public static void fillNumberToComboBox(OCustomComboBoxModel ComboMdl, int StartNumber, int Count, String PreText, String PostText){
  // Fill format : Number (in String)
  int temp=0;
  Object[] Obj;
  int mdl_size=ComboMdl.getSize();
  do{
   Obj=new Object[1];
   Obj[0]=PreText+(StartNumber+temp)+PostText;
   ComboMdl.Mdl.Rows.addElement(Obj);
   temp=temp+1;
  }while(temp!=Count);
  ComboMdl.refreshInsert(mdl_size, mdl_size+(Count-1));
 }

 public static int findString(OCustomModel Mdl, int Column, String Word){
  return PTable.findString(Mdl.getRows(), Column, Word);
 }
 public static int findInsertPos(OCustomModel Mdl, int Column, String Word,
		boolean IgnoreFoundIndex, boolean ReturnFirstFoundIndex, boolean ReturnPositiveIndex){
  return PTable.findInsertPos(Mdl.getRows(), Column, Word, IgnoreFoundIndex, ReturnFirstFoundIndex, ReturnPositiveIndex);
 }
 public static int findInsertPos(OCustomModel Mdl, int Column, Date Value,
		boolean IgnoreFoundIndex, boolean ReturnFirstFoundIndex, boolean ReturnPositiveIndex){
  return PTable.findInsertPos(Mdl.getRows(), Column, Value, IgnoreFoundIndex, ReturnFirstFoundIndex, ReturnPositiveIndex);
 }
 public static int findLong(OCustomModel Mdl, int Column, long Number){
  Vector<Object[]> Rows=Mdl.getRows();
  return PTable.findNumber(Rows, Number, Column, Mdl.getColumnsType()[Column]==CCore.TypeInteger, 0, Rows.size());
 }
 public static int[] inspectLong(long[] Number, OCustomModel Mdl, int Column, boolean ReturnFound, boolean ReturnIndexFromModel){
  return PTable.inspectLong(Number, Mdl.getRows(), Column, Mdl.getColumnsType()[Column]==CCore.TypeInteger, ReturnFound, ReturnIndexFromModel);
 }

 public static int[] getPickedRows(int[] Rows, boolean[] Pick, boolean PickByTrueValue){
  Vector<Integer> ret=new Vector();
  int temp, RowsLength;
  
  RowsLength=Rows.length;
  if(RowsLength!=0){
   temp=0;
   do{
    if(Pick[temp]==PickByTrueValue){ret.addElement(Rows[temp]);}
    temp=temp+1;
   }while(temp!=RowsLength);
  }
  
  return PCore.primArr_VectInt(ret);
 }

 public static Vector<Object[]> subDataFromSelectedRows(OCustomModel Mdl, int[] SelectedRows, int[] ColumnIndex){
  return PTable.subData(Mdl.getRows(), SelectedRows, ColumnIndex);
 }
 public static Object[] getObjectsFromSelectedRows(OCustomModel Mdl, int[] SelectedRows, int ColumnIndex){
  return PTable.subDataOfObjects(Mdl.getRows(), SelectedRows, ColumnIndex);
 }
 public static long[] getIdsFromSelectedRows(OCustomModel Mdl, int[] SelectedRows, int ColumnIndex){
  return PTable.subDataOfIds(Mdl.getRows(), Mdl.getColumnsType(), SelectedRows, ColumnIndex);
 }

 public static String getElementList(Vector<Object[]> Data, int ColumnIndex, String ListSeparator, String Quote, boolean WithSqlNormalize){
  return getElementList(Data, PCore.newIntegerArrayInOrderedSequence(Data.size(), 0, 1), ColumnIndex, ListSeparator, Quote, WithSqlNormalize);
 }
 public static String getElementList(Vector<Object[]> Data, int[] Rows, int ColumnIndex, String ListSeparator, String Quote, boolean WithSqlNormalize){
  StringBuilder ret=new StringBuilder();
  int temp, temp2;
		Object Obj;
		boolean first;
  String str;
  
  temp=Rows.length;
  if(temp==0 || Data.size()==0){return ret.toString();}
  
  temp2=0;
		first=true;
  do{
			Obj=Data.elementAt(Rows[temp2])[ColumnIndex];
			if(Obj!=null){
				if(first){first=false;}else{ret.append(ListSeparator);}
    str=Obj.toString(); if(WithSqlNormalize){str=PSql.norm(str);}
				ret.append(Quote+str+Quote);
			}
   temp2=temp2+1;
  }while(temp2!=temp);
		
  return ret.toString();
 }

 public static Object[] changeElements(Vector<Object[]> Data, int[] ColumnsType, int[] Rows, Vector<OTableCellUpdater> Columns){
  Object[] ret=null;
  int temprow, rowcount, tempcol, columncount, currindex, index1, index2;
  OTableCellUpdater CurrColumn;
  
  rowcount=Rows.length;
  if(rowcount==0){return ret;}
  
  // change data
  columncount=Columns.size();
		if(columncount==0){return ret;}
  index1=Rows[0]; index2=index1;
  
  tempcol=0;
  do{
   Columns.elementAt(tempcol).setModel(null, Data, ColumnsType);
   tempcol=tempcol+1;
  }while(tempcol!=columncount);
  
  temprow=0;
  do{
   currindex=Rows[temprow];
   if(currindex<index1){index1=currindex;}
   else if(currindex>index2){index2=currindex;}
   
   tempcol=0;
   do{
    CurrColumn=Columns.elementAt(tempcol);
    if(CurrColumn.TableColumnIndex>=0){
     CurrColumn.update(currindex);
    }
    tempcol=tempcol+1;
   }while(tempcol!=columncount);
   
   temprow=temprow+1;
  }while(temprow!=rowcount);
  
  ret=PCore.objArrVariant(index1, index2);
  
  return ret;
 }
 public static void changeElements(OCustomModel Mdl, int[] Rows, Vector<OTableCellUpdater> Columns){
  Object[] result;
  
  result=changeElements(Mdl.getRows(), Mdl.getColumnsType(), Rows, Columns); if(result==null){return;}
  
  // update gui
  Mdl.refreshUpdate(PCore.objInteger(result[0], -1), PCore.objInteger(result[1], -1));
 }

 public static Object[] sumColumns(OCustomModel Mdl, int[] ColumnsIndex){
		return PTable.sumColumns(Mdl.getRows(), Mdl.getColumnsType(), ColumnsIndex);
 }
 public static Object[] sumColumns(OCustomModel Mdl, int[] ColumnsIndex, int[] SelectedRows){
  return PTable.sumColumns(Mdl.getRows(), Mdl.getColumnsType(), ColumnsIndex, SelectedRows);
 }

 public static double sumDrawTableColumnWidth(int[] ColumnIndex, ODrawTableColumnMetadata[] Columns){
  double ret=0;
  int temp, sumlength, columnslength, index;
  ODrawTableColumnMetadata Column;
  
  if(ColumnIndex==null || Columns==null){return ret;}
  
  sumlength=ColumnIndex.length;
  columnslength=Columns.length;
  if(sumlength==0 || columnslength==0){return ret;}
  
  temp=0;
  do{
   index=ColumnIndex[temp];
   if(index>=0 && index<columnslength){
    Column=Columns[index];
    if(Column!=null){ret=ret+Column.Width;}
   }
   
   temp=temp+1;
  }while(temp!=sumlength);
  
  return ret;
 }
 public static int searchInlist(OCustomListModel ListMdl,
  String FindText, int LastFindIndex, int Mode){
  // Mode : 0 first, 1 next, 2 before
  int ret=-1;
  int temp, temp_;
  int end_pos;
  boolean from_middle;
  do{
   // preparing searching strategy
   temp=ListMdl.getSize();
   end_pos=temp;
   from_middle=false;
   if(Mode==1){
    if(LastFindIndex!=-1){
     if(LastFindIndex+1<temp){
      from_middle=true;
      end_pos=LastFindIndex+1;
     }
    }
   }
   else if(Mode==2){
    if(LastFindIndex>0){
     from_middle=true;
     end_pos=LastFindIndex-1;
    }
    else{end_pos=-1;}
   }
   // search forward
   if(Mode==0 || Mode==1){
    // searching from (LastFindIndex+1 - end of list)
    if(from_middle==true){
     temp_=LastFindIndex+1;
     do{
      if(PText.findSubString(PText.getString(ListMdl.getNativeElementAt(temp_), "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
      temp_=temp_+1;
     }while(temp_!=temp);
     if(temp_!=temp){
      ret=temp_;
      break;
     }
    }
    // searching from (begin of list - end_pos)
    temp_=0;
    do{
     if(PText.findSubString(PText.getString(ListMdl.getNativeElementAt(temp_), "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
     temp_=temp_+1;
    }while(temp_!=end_pos);
    if(temp_!=end_pos){
     ret=temp_;
    }
   }
   // search backward
   else{
    // searching from (LastFindIndex-1 - begin of list)
    if(from_middle==true){
     temp_=LastFindIndex-1;
     do{
      if(PText.findSubString(PText.getString(ListMdl.getNativeElementAt(temp_), "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
      temp_=temp_-1;
     }while(temp_!=-1);
     if(temp_!=-1){
      ret=temp_;
      break;
     }
    }
    // searching from (end of list - end_pos)
    temp_=ListMdl.Mdl.Rows.size()-1;
    do{
     if(PText.findSubString(PText.getString(ListMdl.getNativeElementAt(temp_), "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
     temp_=temp_-1;
    }while(temp_!=end_pos);
    if(temp_!=end_pos){
     ret=temp_;
    }
   }
  }while(false);
  return ret;
 }
 public static int searchInTable(OCustomTableModel TableMdl, int Column, int ColumnType,
  String FindText, int LastFindIndex, int Mode){
  // Mode : 0 first, 1 next, 2 before
  int ret=-1;
  int temp, temp_;
  int end_pos;
  boolean from_middle;
  do{
   // preparing searching strategy
   temp=TableMdl.Mdl.Rows.size();
   end_pos=temp;
   from_middle=false;
   if(Mode==1){
    if(LastFindIndex!=-1){
     if(LastFindIndex+1<temp){
      from_middle=true;
      end_pos=LastFindIndex+1;
     }
    }
   }
   else if(Mode==2){
    if(LastFindIndex>0){
     from_middle=true;
     end_pos=LastFindIndex-1;
    }
    else{end_pos=-1;}
   }
   // search forward
   if(Mode==0 || Mode==1){
    // searching from (LastFindIndex+1 - end of list)
    if(from_middle==true){
     temp_=LastFindIndex+1;
					do{
						if(PText.findSubString(PText.getStringObj(TableMdl.Mdl.Rows.elementAt(temp_)[Column], "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
						temp_=temp_+1;
					}while(temp_!=temp);
     if(temp_!=temp){ret=temp_; break;}
    }
    // searching from (begin of list - end_pos)
    temp_=0;
				do{
					if(PText.findSubString(PText.getStringObj(TableMdl.Mdl.Rows.elementAt(temp_)[Column], "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
					temp_=temp_+1;
				}while(temp_!=end_pos);
    if(temp_!=end_pos){ret=temp_;}
   }
   // search backward
   else{
    // searching from (LastFindIndex-1 - begin of list)
    if(from_middle==true){
     temp_=LastFindIndex-1;
					do{
						if(PText.findSubString(PText.getStringObj(TableMdl.Mdl.Rows.elementAt(temp_)[Column], "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
						temp_=temp_-1;
					}while(temp_!=-1);
     if(temp_!=-1){ret=temp_; break;}
    }
    // searching from (end of list - end_pos)
    temp_=TableMdl.Mdl.Rows.size()-1;
				do{
					if(PText.findSubString(PText.getStringObj(TableMdl.Mdl.Rows.elementAt(temp_)[Column], "", false), FindText, false, true, CCore.Chars_Separator, false, true)){break;}
					temp_=temp_-1;
				}while(temp_!=end_pos);
    if(temp_!=end_pos){ret=temp_;}
   }
  }while(false);
  return ret;
 }

	public static void enableInput(boolean Enable, JTextField CYear, JComboBox CMonth, JComboBox CDay, boolean ClearNotEnable){
		CYear.setEnabled(Enable); CMonth.setEnabled(Enable); CDay.setEnabled(Enable);
		if(!Enable && ClearNotEnable){CYear.setText("");}
	}
	public static void enableInput(boolean Enable, JTextField TF1, JTextField TF2, boolean ClearNotEnable){
		enableInput(Enable, TF1, ClearNotEnable);
  enableInput(Enable, TF2, ClearNotEnable);
	}
	public static void enableInput(boolean Enable, JTextField TF, boolean ClearNotEnable){
		TF.setEnabled(Enable);
		if(!Enable && ClearNotEnable){TF.setText("");}
	}
 public static void editableInput(boolean Editable, JTextField TF, Color Color_Uneditable, Color Editable_FocusOn, Color Editable_FocusOff){
  TF.setEditable(Editable);
  if(Editable){TF.setBackground((Color)PCore.subtituteBool(TF.isFocusOwner(), Editable_FocusOn, Editable_FocusOff));}
  else{TF.setBackground(Color_Uneditable);}
 }
 public static void editableInput(boolean Editable, JTextField TF){
  editableInput(Editable, TF, CGUI.Color_TextBox_Uneditable, CGUI.Color_TextBox_FocusOn, CGUI.Color_TextBox_FocusOff);
 }
	
 public static File showSaveDialog(JFileChooser FileChooser, FileFilter Filter, String FileExtension){
  File ret=null;
  File f;
  String fstr;
  
  do{
   FileChooser.setFileFilter(Filter);
   FileChooser.setMultiSelectionEnabled(false);
   if(FileChooser.showSaveDialog(null)!=JFileChooser.APPROVE_OPTION){break;}

   f=FileChooser.getSelectedFile();
   if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
    JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
    break;
   }
   try{
    fstr=f.getCanonicalPath();
    if(PFile.compareIgnoreCaseExtension(fstr, FileExtension)==false){
     f=new File(fstr+"."+FileExtension);
    }
   }
   catch(Exception E){
    JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !");
    break;
   }
   ret=f;
  }while(false);
  
  return ret;
 }
 public static File showLoadDialog(JFileChooser FileChooser, FileFilter Filter, String FileExtension){
  File ret=null;
  File f;
  
  do{
   FileChooser.setFileFilter(Filter);
   FileChooser.setMultiSelectionEnabled(false);
   if(FileChooser.showDialog(null, "Load")!=JFileChooser.APPROVE_OPTION){break;}
   f=FileChooser.getSelectedFile();
   if(PFile.compareIgnoreCaseExtension(f.getName(), FileExtension)==false){
    JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+
     "Ekstensi file harus '."+FileExtension+"'.");
    break;
   }
   ret=f;
  }while(false);
  
  return ret;
 }
 
 public static boolean checkInputBoolean(
  JRadioButton FromGuiInputYes, JRadioButton FromGuiInputNo, VBoolean ToData){
  ToData.Value=FromGuiInputYes.isSelected();
  return true;
 }
 public static boolean checkInputBoolean(
  JComboBox FromGuiInput, VBoolean ToData){
  // ComboBox must contain : index 0 = yes, index 1 = no
  ToData.Value=FromGuiInput.getSelectedIndex()==0;
  return true;
 }
 public static boolean checkInputBoolean(
  JCheckBox FromGuiInput, VBoolean ToData){
  ToData.Value=FromGuiInput.isSelected();
  return true;
 }
 public static boolean checkInputInteger(
  JTextField FromGuiInput, VInteger ToData,
  boolean AcceptEmptyInput, boolean AcceptZero, boolean PositiveOnly,
  boolean WithinRange, int Range1, int Range2){
  boolean ret=false;
  String str;
  Integer value;
  int length;
  
  str=FromGuiInput.getText();
  length=str.length();
  do{
   value=PText.parseInt(str, PCore.subtBool_Int(AcceptEmptyInput, -1, null), null, AcceptZero, PositiveOnly, WithinRange, Range1, Range2);
   if(value==null){break;}
   ret=true;
  }while(false);
  if(ret){
   if(length==0){ToData.Value=-1;}else{ToData.Value=value;}
  }
  
  return ret;
 }
 public static boolean checkInputLong(
  JTextField FromGuiInput, VLong ToData,
  boolean AcceptEmptyInput, boolean AcceptZero, boolean PositiveOnly,
  boolean WithinRange, long Range1, long Range2){
  boolean ret=false;
  String str;
  Long value;
  int length;
  
  str=FromGuiInput.getText();
  length=str.length();
  do{
   value=PText.parseLong(str, PCore.subtBool_Long(AcceptEmptyInput, -1L, null), null, AcceptZero, PositiveOnly, WithinRange, Range1, Range2);
   if(value==null){break;}
   ret=true;
  }while(false);
  if(ret){
   if(length==0){ToData.Value=-1;}else{ToData.Value=value;}
  }
  
  return ret;
 }
 public static boolean checkInputDouble(
  JTextField FromGuiInput, VDouble ToData,
  boolean AcceptEmptyInput, boolean AcceptZero, boolean PositiveOnly,
  boolean WithinRange, double Range1, double Range2){
  boolean ret=false;
  String str;
  Double value;
  int length;
  
  str=FromGuiInput.getText();
  length=str.length();
  do{
   value=PText.parseDouble(str, PCore.subtBool_Double(AcceptEmptyInput, -1D, null), null, AcceptZero, PositiveOnly, WithinRange, Range1, Range2);
   if(value==null){break;}
   ret=true;
  }while(false);
  if(ret){
   if(length==0){ToData.Value=-1;}else{ToData.Value=value;}
  }
  
  return ret;
 }
 public static boolean checkInputString(
  JTextComponent FromGuiInput, VString ToData,
  boolean AcceptEmptyInput, int MaxInputLength, boolean AcceptTrailingAndTailingSpace,
  boolean ReturnEmptyStringAsNull){
  boolean ret=false;
  String str;
  int CheckFirst, CheckLast;
  
  do{
   str=FromGuiInput.getText();
   CheckFirst=0; CheckLast=0; if(!AcceptTrailingAndTailingSpace){CheckFirst=1; CheckLast=1;}
   if(!PText.checkInput(str, AcceptEmptyInput, MaxInputLength, 0, CheckFirst, CheckLast, 0)){break;}
   if(ReturnEmptyStringAsNull){if(str.length()==0){str=null;}}
   ToData.Value=str;
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean checkInputDate(
  JCheckBox FromGuiInputEnable, JTextField FromGuiInputYear, JComboBox FromGuiInputMonth, JComboBox FromGuiInputDay, VDate ToData){
  boolean ret=false;
  Date dt;
  
  do{
   if(FromGuiInputEnable!=null){
    if(!FromGuiInputEnable.isSelected()){
     ToData.Value=null;
     ret=true;
     break;
    }
   }
   dt=valueOfDateComponent(FromGuiInputYear, FromGuiInputMonth, FromGuiInputDay);
   if(dt==null){break;}
   ToData.Value=dt;
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean checkInputDate(
  JTextField FromGuiInput, VDate ToData, boolean AcceptEmptyInput){
  boolean ret=false;
  Date dt;
  String str;
  
  do{
   str=FromGuiInput.getText();
   
   if(AcceptEmptyInput){
    if(PText.isAllWhiteChar(str)){
     ToData.Value=null;
     ret=true;
     break;
    }
   }
   
   dt=PDate.parseDate(str);
   if(dt==null){break;}
   ToData.Value=dt;
   ret=true;
  }while(false);
  
  return ret;
 }
 public static void fillPanelPictureURL(XImgBoxURL Pnl_Picture, String PictureDirectory, Object PictureFile){
  String URL, URLDir;
  
  URL=null;
  if(!PText.isEmptyString(PCore.objString(PictureFile, null), false, true)){
   URLDir=PFile.toDirectory(PictureDirectory, '/');
   URL=URLDir+(String)PictureFile;
  }
  
  Pnl_Picture.setImageSource(URL);
  Pnl_Picture.repaint();
 }
 public static void hide(JTextComponent TextGUI, boolean IsHide, Color UnhideForeground){
  TextGUI.setForeground((Color)PCore.subtituteBool(IsHide, TextGUI.getBackground(), UnhideForeground));
 }
 public static void setSelected(boolean Value, JToggleButton... ToggleButton){setSelected(Value, false, ToggleButton);}
 public static void setSelected(boolean Value, boolean CheckIfComponentIsEnabled, JToggleButton... ToggleButton){
  int[] Index=null; if(ToggleButton!=null){Index=PCore.newIntegerArrayInOrderedSequence(ToggleButton.length, 0, 1);}
  setSelected(Value, CheckIfComponentIsEnabled, Index, ToggleButton);
 }
 public static void setSelected(boolean Value, boolean CheckIfComponentIsEnabled, int[] ToggleButtonIndex, JToggleButton... ToggleButton){
  int temp, selectionlength, togglelength, toggleindex;
  JToggleButton TBtn;
  
  if(ToggleButtonIndex==null || ToggleButton==null){return;}
  
  selectionlength=ToggleButtonIndex.length;
  togglelength=ToggleButton.length;
  if(selectionlength==0 || togglelength==0){return;}
  
  temp=0;
  do{
   do{
    toggleindex=ToggleButtonIndex[temp]; if(toggleindex<0 || toggleindex>=togglelength){break;}
    TBtn=ToggleButton[toggleindex]; if(CheckIfComponentIsEnabled){if(!isEnabled(TBtn)){break;}}
    
    TBtn.setSelected(Value);
   }while(false);
   
   temp=temp+1;
  }while(temp!=selectionlength);
 }
 public static void setSelected(int Value, JComboBox... ComboBox){setSelected(Value, false, ComboBox);}
 public static void setSelected(int Value, boolean CheckIfComponentIsEnabled, JComboBox... ComboBox){
  int temp, length;
  JComboBox CmB;
  
  if(ComboBox==null){return;}
  
  length=ComboBox.length;
  if(length==0){return;}
  
  temp=0;
  do{
   do{
    CmB=ComboBox[temp]; if(CheckIfComponentIsEnabled){if(!isEnabled(CmB)){break;}}
    
    CmB.setSelectedIndex(Value);
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
 }
 public static void setEnabled(boolean Enable,
  boolean ChangeValueOnDisable, boolean ValueOnDisable,
  boolean ChangeValueOnEnable, boolean ValueOnEnable,
  JCheckBox... Components){
  int temp, length;
  
  if(Components==null){return;}
  length=Components.length;
  if(length==0){return;}
  
  temp=0;
  do{
   if(Components[temp]!=null){
    Components[temp].setEnabled(Enable);
    if(!Enable && ChangeValueOnDisable){Components[temp].setSelected(ValueOnDisable);}
    else if(Enable && ChangeValueOnEnable){Components[temp].setSelected(ValueOnEnable);}
   }
   temp=temp+1;
  }while(temp!=length);
 }
 public static void setEnabled(boolean Enable, JComponent... Components){
  int temp, length;
  
  if(Components==null){return;}
  length=Components.length;
  if(length==0){return;}
  
  temp=0;
  do{
   if(Components[temp]!=null){Components[temp].setEnabled(Enable);}
   temp=temp+1;
  }while(temp!=length);
 }
 public static void setEnabled(boolean Value, Color ColorEnable, Color ColorNotEnable, JTextField TF){
  if(TF==null){return;}
  TF.setEnabled(Value);
  TF.setBackground((Color)PCore.subtituteObj(Value, ColorEnable, ColorNotEnable));
 }
 public static void setEnabled(boolean Value, Color ColorEnable, Color ColorNotEnable, JTextField... TF){
  int temp, length;
  
  if(TF==null){return;}
  length=TF.length;
  if(length==0){return;}
  
  temp=0;
  do{
   setEnabled(Value, ColorEnable, ColorNotEnable, TF[temp]);
   temp=temp+1;
  }while(temp!=length);
 }
 public static void setText(String Value, JTextComponent... TC){
  int temp, length;
  JTextComponent A_TC;
  
  if(TC==null){return;}
  length=TC.length;
  if(length==0){return;}
  
  temp=0;
  do{
   A_TC=TC[temp];
   if(A_TC!=null){A_TC.setText(Value);}
   temp=temp+1;
  }while(temp!=length);
 }
 public static void clearText(JTextComponent... TC){setText("", TC);}
 public static boolean isEnabled(Component Component){
  boolean ret;
  JTextComponent TC;
  
  ret=false;
  do{
   if(!Component.isVisible() || !Component.isEnabled()){break;}
   
   if(Component instanceof JTextComponent){
    TC=(JTextComponent)Component;
    if(!TC.isEditable()){break;}
   }
   
   ret=true;
  }while(false);
  
  return ret;
 }
 
 public static void findAndSelect_Number_ComboBox(
  OCustomComboBoxModel ComboMdl, JComboBox CmB, int FindColumnIndex,
  long Number, boolean ProcessThreshold, long ProcessThreshold_Number, boolean ProcessThreshold_AbortSelect, int ProcessThreshold_AbortSelectIndex,
  boolean NotFound_Select, int NotFound_SelectIndex){
  int foundindex;
  
  if(ProcessThreshold && Number<=ProcessThreshold_Number){
   if(ProcessThreshold_AbortSelect){CmB.setSelectedIndex(ProcessThreshold_AbortSelectIndex);}
   return;
  }
  
  foundindex=findLong(ComboMdl, FindColumnIndex, Number);
  if(foundindex==-1){
   if(NotFound_Select){CmB.setSelectedIndex(NotFound_SelectIndex);}
   return;
  }
  
  CmB.setSelectedIndex(foundindex);
 }
 public static void findAndSelect_OInfoAThing_ComboBox(
  OCustomComboBoxModel ComboMdl, JComboBox CmB, int FindColumnIndex,
  OInfoAThing Data,
  boolean NotFound_Select, int NotFound_SelectIndex){
  int foundindex;
  
  foundindex=findData(ComboMdl, FindColumnIndex, Data);
  if(foundindex==-1){
   if(NotFound_Select){CmB.setSelectedIndex(NotFound_SelectIndex);}
   return;
  }
  
  CmB.setSelectedIndex(foundindex);
 }
 public static int findData(OCustomComboBoxModel ComboMdl, int FindColumnIndex,
  OInfoAThing Data){
  int ret=-1;
  int temp, count;
  long[] DataId, CurrDataId;
  OInfoAThing CurrData;
  
  do{
   count=ComboMdl.Mdl.Rows.size();
   if(count==0 || Data==null){break;}
   
   DataId=Data.getId();
   
   temp=0;
   do{
    CurrData=(OInfoAThing)ComboMdl.Mdl.Rows.elementAt(temp)[FindColumnIndex];
    CurrDataId=CurrData.getId();
    
    if(PCore.compareValue(DataId, CurrDataId)){ret=temp; break;}
    
    temp=temp+1;
   }while(temp!=count);
  }while(false);
  
  return ret;
 }
 
 public static void fillCount(boolean IsVisible, JTextField TF, long Count){
  TF.setText(PText.getString(IsVisible, PText.intToString(Count), ""));
 }
 public static void fillCountAndChecked(boolean IsVisible, JTextField TF, long Count, long CheckedCount){
  TF.setText(PText.getString(IsVisible, PText.intToString(Count)+"  ( "+PText.intToString(CheckedCount)+" )", ""));
 }
 public static void fillPrice(boolean IsVisible, JTextField TF, double Price){
  TF.setText(PText.getString(IsVisible, PText.priceToString(Price), ""));
 }
 
 public static void changeDocument(VBoolean EnableDocumentListener, JTextField TF, String Str){
  EnableDocumentListener.Value=false;
  TF.setText(Str);
  EnableDocumentListener.Value=true;
 }
 public static void changeDocument(VBoolean EnableDocumentListener, JRadioButton RB){
  EnableDocumentListener.Value=false;
  RB.setSelected(true);
  EnableDocumentListener.Value=true;
 }
 public static void changeDocument(VBoolean EnableDocumentListener, JComboBox CmB, int Row){
  EnableDocumentListener.Value=false;
  CmB.setSelectedIndex(Row);
  EnableDocumentListener.Value=true;
 }
 
 public static void clear(JCheckBox CB, JTextField TF){
  CB.setSelected(false); TF.setText("");
 }
 public static void clear(JCheckBox CB, JTextField TF1, JTextField TF2){
  CB.setSelected(false); TF1.setText(""); TF2.setText("");
 }
 public static void clear(JCheckBox CB, JTextField StartY, JComboBox StartM, JComboBox StartD, JTextField EndY, JComboBox EndM, JComboBox EndD){
  CB.setSelected(false); StartY.setText(""); EndY.setText("");
 }
 
 public static int[] findComponent(Object[] V_Cmps, Component Cmp){
  int[] ret=PCore.primArr(-1, -1);
  int temp, count, found;
  Object obj;
  Component Cmp_;
  Component[] Cmps;
  Object[] V_Cmps2;
  int[] found2;
  
  count=0; if(V_Cmps!=null){count=V_Cmps.length;} if(count==0){return ret;}
  
  temp=0;
  do{
   obj=V_Cmps[temp];
   
   if(obj!=null){
    
    if(obj instanceof Component){
     Cmp_=(Component)obj;
     if(isSameComponent(Cmp, Cmp_)){ret[0]=temp; break;}
    }
    else if(obj instanceof Component[]){
     Cmps=(Component[])obj;
     found=findComponent(Cmps, Cmp);
     if(found!=-1){ret[0]=temp; ret[1]=found; break;}
    }
    else if(obj instanceof Object[]){
     V_Cmps2=(Object[])obj;
     found2=findComponent(V_Cmps2, Cmp);
     if(found2[0]!=-1){ret[0]=temp; break;}
    }
    
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 public static int findComponent(Component[] Cmps, Component Cmp){
  int ret=-1;
  int temp, count;
  Component Cmp_;
  
  count=0; if(Cmps!=null){count=Cmps.length;} if(count==0){return ret;}
  
  temp=0;
  do{
   Cmp_=Cmps[temp];
   
   if(isSameComponent(Cmp, Cmp_)){ret=temp; break;}
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 public static boolean isSameComponent(Component SourceCmp, Component TargetCmp){
  return SourceCmp==TargetCmp;
 }
 
 public static boolean requestFocusInWindow(Component DestCmp){
  boolean ret;
  
  ret=false;
  do{
   if(DestCmp==null){break;}
   if(!isEnabled(DestCmp)){break;}
   DestCmp.requestFocusInWindow();
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean requestFocusInWindow(Component[] DestCmps){return requestFocusInWindow(DestCmps, 0, true);}
 public static boolean requestFocusInWindow(Component[] DestCmps, int StartIndex, boolean IsForward){
  boolean ret;
  int temp, count, end, add;
  Component DestCmp;
  
  ret=false;
  do{
   count=0; if(DestCmps!=null){count=DestCmps.length;} if(count==0){break;}
   
   add=PCore.subtBool_Int(IsForward, 1, -1);
   end=PCore.subtBool_Int(IsForward, count, -1);
   
   if((IsForward && StartIndex>=end) || (!IsForward && StartIndex<=end)){break;}
   
   temp=StartIndex;
   do{
    DestCmp=DestCmps[temp];
    
    if(requestFocusInWindow(DestCmp)){break;}
    
    temp=temp+add;
   }while(temp!=end);
   if(temp==end){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean requestFocusInWindow(Object[] V_Cmps){return requestFocusInWindow(V_Cmps, 0, true);}
 public static boolean requestFocusInWindow(Object[] V_Cmps, int StartIndex, boolean IsForward){
  boolean ret=false;
  int temp, count, end, add;
  Object obj;
  Component Cmp_;
  Component[] Cmps;
  Object[] V_Cmps2;
  
  ret=false;
  do{
   count=0; if(V_Cmps!=null){count=V_Cmps.length;} if(count==0){break;}
   
   add=PCore.subtBool_Int(IsForward, 1, -1);
   end=PCore.subtBool_Int(IsForward, count, -1);
   
   if((IsForward && StartIndex>=end) || (!IsForward && StartIndex<=end)){break;}
   
   temp=StartIndex;
   do{
    obj=V_Cmps[temp];

    if(obj!=null){

     if(obj instanceof Component){
      Cmp_=(Component)obj;
      if(requestFocusInWindow(Cmp_)){break;}
     }
     else if(obj instanceof Component[]){
      Cmps=(Component[])obj;
      if(requestFocusInWindow(Cmps, 0, true)){break;}
     }
     else if(obj instanceof Object[]){
      V_Cmps2=(Object[])obj;
      if(requestFocusInWindow(V_Cmps2, 0, true)){break;}
     }

    }
    
    temp=temp+add;
   }while(temp!=end);
   if(temp==end){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean requestFocusInWindow(Object[] V_Cmps, Component Cmp, boolean IsForward){
  VBoolean IPV_CmpSourceFound=new VBoolean(false);
  
  return requestFocusInWindow_(V_Cmps, Cmp, IsForward, IPV_CmpSourceFound);
 }
 public static boolean requestFocusInWindow_(Object[] V_Cmps, Component Cmp, boolean IsForward,
  
  // put inter-procedures-variables here
  VBoolean IPV_CmpSourceFound){
  
  boolean ret;
  
  int temp, add, end, count;
  Object obj;
  
  ret=false;
  do{
   
   count=0; if(V_Cmps!=null){count=V_Cmps.length;} if(count==0){break;}

   temp=PCore.subtBool_Int(IsForward, 0, count-1); add=PCore.subtBool_Int(IsForward, 1, -1); end=PCore.subtBool_Int(IsForward, count, -1);
   do{
    obj=V_Cmps[temp];

    if(requestFocusInWindow_(obj, Cmp, IsForward, IPV_CmpSourceFound)){break;}

    temp=temp+add;
   }while(temp!=end);
   if(temp==end){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean requestFocusInWindow_(Component[] Cmps, Component Cmp, boolean IsForward,
  
  // put inter-procedures-variables here
  VBoolean IPV_CmpSourceFound){
  
  boolean ret;
  
  int temp, add, end, count;
  Object obj;
  
  ret=false;
  do{
   
   count=0; if(Cmps!=null){count=Cmps.length;} if(count==0){break;}

   temp=PCore.subtBool_Int(IsForward, 0, count-1); add=PCore.subtBool_Int(IsForward, 1, -1); end=PCore.subtBool_Int(IsForward, count, -1);
   do{
    obj=Cmps[temp];

    if(requestFocusInWindow_(obj, Cmp, IsForward, IPV_CmpSourceFound)){break;}

    temp=temp+add;
   }while(temp!=end);
   if(temp==end){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean requestFocusInWindow_(Object obj, Component Cmp, boolean IsForward,
  
  // put inter-procedures-variables here
  VBoolean IPV_CmpSourceFound){
  
  boolean ret=false;
  
  Component Cmp_;
  Component[] Cmps2;
  Object[] V_Cmps2;
  boolean IsComponent;
  
  do{
   
   if(obj==null){break;}
   
   IsComponent=false;

   if(obj instanceof Component){
    IsComponent=true;
   }
   else if(obj instanceof Component[]){
    Cmps2=(Component[])obj;
    if(requestFocusInWindow_(Cmps2, Cmp, IsForward, IPV_CmpSourceFound)){ret=true; break;}
   }
   else if(obj instanceof Object[]){
    V_Cmps2=(Object[])obj;
    if(requestFocusInWindow_(V_Cmps2, Cmp, IsForward, IPV_CmpSourceFound)){ret=true; break;}
   }

   if(IsComponent){

    Cmp_=(Component)obj;

    // if component-source has not found, then do search & compare until found
    if(IPV_CmpSourceFound.Value==false){
     if(isSameComponent(Cmp_, Cmp)){IPV_CmpSourceFound.Value=true;}
    }

    // if component-source has already found, then do request focus until true (focus transfered)
    else{
     if(requestFocusInWindow(Cmp_)){ret=true; break;}
    }

   }
   
  }while(false);
  
  return ret;
 }
 public static boolean requestFocusInWindow_Ordered(boolean MoveInside, boolean MoveInside_OnlyMoveInside, boolean IsForward, Object[] OrderedCmps, Component Cmp){
  boolean ret;
  int temp, count, end, add;
  int[] found;
  Object obj;
  Component DestCmp;
  Component[] DestCmps;
  Object[] V_Cmps;
  
  ret=false;
  do{
   count=0; if(OrderedCmps!=null){count=OrderedCmps.length;} if(count==0){break;}
   
   found=findComponent(OrderedCmps, Cmp); if(found[0]==-1){break;}
   
   if(MoveInside){
    obj=OrderedCmps[found[0]];
    
    if(obj instanceof Component[]){
     DestCmps=(Component[])OrderedCmps[found[0]]; add=PCore.subtBool_Int(IsForward, 1, -1);
     if(requestFocusInWindow(DestCmps, found[1]+add, IsForward)){ret=true; break;}
    }
    else if(obj instanceof Object[]){
     V_Cmps=(Object[])obj;
     if(requestFocusInWindow(V_Cmps, Cmp, IsForward)){ret=true; break;}
    }
    
    if(MoveInside_OnlyMoveInside){break;}
   }
   
   temp=found[0]; add=PCore.subtBool_Int(IsForward, 1, -1); end=PCore.subtBool_Int(IsForward, count, -1);
   temp=temp+add; if(temp==end){break;}
   
   do{
    obj=OrderedCmps[temp];
    
    if(obj!=null){
     
     if(obj instanceof Component){
      DestCmp=(Component)obj;
      if(requestFocusInWindow(DestCmp)){break;}
     }
     else if(obj instanceof Component[]){
      DestCmps=(Component[])obj;
      if(requestFocusInWindow(DestCmps, 0, true)){break;}
     }
     else if(obj instanceof Object[]){
      V_Cmps=(Object[])obj;
      if(requestFocusInWindow(V_Cmps, 0, true)){break;}
     }
     
    }
    
    temp=temp+add;
   }while(temp!=end);
   if(temp==end){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static void requestFocusInWindow(JRadioButton... RBs){
  int count, temp;
  JRadioButton RB=null;
  
  if(RBs==null){return;}
  count=RBs.length; if(count==0){return;}
  
  temp=0;
  do{
   RB=RBs[temp];
   
   if(RB!=null){
    if(RB.isSelected()){break;}
   }
   
   temp=temp+1;
  }while(temp!=count);
  if(temp==count){return;}
  
  requestFocusInWindow(RB);
 }
 
 public static void focus(JTextComponent TC, boolean SelectAll){
  TC.requestFocusInWindow();
  if(SelectAll){TC.selectAll();}
 }
 
 public static void setSelectedRow(JList List, int Row){
  List.setSelectedIndex(Row);
  List.ensureIndexIsVisible(Row);
 }
 public static void setSelectedRow(JTable Tbl, int Row, int Col){
  Tbl.changeSelection(Row, Col, false, false);
 }
 
 public static void text_SelectAll(JTextComponent TC, boolean DoAnyway){
  do{
   if(!DoAnyway){
    if(!TC.isEnabled() || !TC.isEditable()){break;}
   }
   
   TC.selectAll();
  }while(false);
 }
 public static void text_SelectAll(JTextComponent TC){
  text_SelectAll(TC, false);
 }
 
}