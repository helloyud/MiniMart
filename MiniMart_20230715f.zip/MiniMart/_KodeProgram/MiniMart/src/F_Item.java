import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.sql.ResultSet;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class F_Item extends XFormDialog
 implements OFormSupportsComponentShortcut{

 private class CheckerAttrInputOpt{
  String Name;
  boolean EnableInput;
  boolean EnableInputClearAfterProcess;
  OInput InputType;

  public CheckerAttrInputOpt(String Name, boolean EnableInput, boolean EnableInputClearAfterProcess, OInput InputType) {
   this.Name = Name;
   this.EnableInput = EnableInput;
   this.EnableInputClearAfterProcess=EnableInputClearAfterProcess;
   this.InputType=InputType;
  }
 }
 private class CheckerAttr{
  boolean Enable;
  String Name;
  Vector<CheckerAttrInputOpt> InputOpts;
  int LastSelectedInputOpt;

  public CheckerAttr(){Enable=false;}
  
  public void init(
   String Name,
   Vector<CheckerAttrInputOpt> InputOpts, int LastSelectedInputOpt) {
   this.Name = Name;
   this.InputOpts = InputOpts;
   this.LastSelectedInputOpt = LastSelectedInputOpt;
   Enable=true;
  }
 }
 private class Checker{
  boolean Enable;
  String Name;
  CheckerAttr[] Attrs;
  
  public Checker(String Name, int AttrsCount) {
   this.Name = Name;
   initAttrs(AttrsCount);
   Enable=false;
  }
  
  private void initAttrs(int AttrsCount){
   int temp;
   Attrs=new CheckerAttr[AttrsCount];
   temp=0;
   do{
    Attrs[temp]=new CheckerAttr();
    temp=temp+1;
   }while(temp!=AttrsCount);
  }
  
  public void init(int AttrIndex,
   String Name,
   Vector<CheckerAttrInputOpt> InputOpts, int LastSelectedInputOpt) {
   Attrs[AttrIndex].init(Name, InputOpts, LastSelectedInputOpt);
   Enable=true;
  }
 }
 
 // set
 int wMode; // 0 Normal (New, Edit, Remove), 1 Choose (Choose)
 boolean wDialogWithFSubject;
 boolean wAllowMultipleSelection;
 
 // get
 Long[] ChoosedId;
 String[] ChoosedName;
 String[] ChoosedPicture;
 String[] ChoosedCategory;
 Double[] ChoosedSellPrice;
 /*
 Double[] ChoosedStock;
 String[] ChoosedStockUnit;
 Boolean[] ChoosedUpStock;
 Double[] ChoosedBuyPrice;
 */
 
 // Index of Item Information (det, cat, pic, sup)
  // re-query sign
 boolean IIEmptyAll;
 boolean IIDet;
 boolean IIEtc;
 boolean IIPic;
 boolean IIVrs;
 boolean IISupp;
 boolean IITrans;
  // contents cleared sign
 boolean IIDetClear;
 boolean IIEtcClear;
 boolean IIPicClear;
 boolean IIVrsClear;
 boolean IISuppClear;
 boolean IITransClear;
 
 // Table Item
 OCustomTableModel TableItemMdl;
 boolean[] SumColumn;
 double[] SumResult;
 int LastSelectedRow;
	
	String[] TableItemColsName;
	int[] TableItemColsType, TableItemColsShowOption, TableItemColsVisible, TableItemColsWidth;
	boolean[] TableItemColsEditable;
	
 boolean LastQueryDefined;
 int LastQueryOperationBy;
	int LQ_Limit;
 // Static Filter
 String LQ_StaticSourceTable, LQ_StaticCondition, LQ_StaticPostCondition;
 boolean LQ_StaticConditionDefined, LQ_StaticPostConditionDefined;
 // Dynamic Filter
 int LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
 // Additional Filter
 boolean LQ_WithAdditionalFilter;
 // Order By
 String LQ_OrderBy;
 
 String QHavingTbl;
 
 int LastResultFilterSubset;
 int LastResultFilterIsActive;
 int LastResultFilterIsUpdateStock;
 int LastResultFilterIsOpname;
 int LastResultFilterIsReorder;
 int LastResultFilterHasExpire;
 
 double OrderTotalPrice_Tbl;
 double OrderTotalPrice_TempList;
 double OrderTotalPrice_All;
 
 // Panel Checker
 final int AttrsCount=2;
 
	int[] TF_CheckerId_ShortcutKeys;
	int[] TF_Checker1_ShortcutKeys;
	int[] TF_Checker2_ShortcutKeys;
 
 long CheckerItemId;
 OInfoItem CheckerItemDet;
 long CheckerItemIdCheck;
 
 Vector<Checker> Checkers;
 
 Checker CurrChecker;
 
 OCustomComboBoxModel ComboMdlCheckerAttr1;
 CheckerAttr CurrCheckerAttr1;
 
 OCustomComboBoxModel ComboMdlCheckerAttr2;
 CheckerAttr CurrCheckerAttr2;
 
 // Panel View
 OCustomComboBoxModel ComboMdlViewMode;
 int LastSelectedViewMode;
 
 // Tab Search
 OCustomListModel ListMdlQStockUnit;
 OCustomListModel ListMdlQCat;
 OCustomListModel ListMdlQTag;
 OCustomListModel ListMdlQPic;
 OCustomListModel ListMdlQSup;
 Component LastFocusedCmpSearch;
 // Tab Detail
 OInfoItem DetItem;
 // Tab Category
 OCustomListModel ListMdlCat;
 int LastSelectedRowCat;
 boolean ListMdlCatFilled;
 int LastSelectedCatQueryType;
 boolean CatQueryWithCheck;
 boolean CatQueryWithoutCheckByTempList;
 // Tab etc
 OCustomListModel ListMdlItemCat;
 OCustomListModel ListMdlItemTag;
 // Tab pic
 OCustomListModel ListMdlItemPic;
 int LastSelectedRowPic;
 boolean PanelImageClear;
 // Tab vrs
  // Secondary Id
 boolean IISecClear;
 OCustomListModel ListMdlSec;
 int LastSelectedRowSec;
 boolean InfoSecClear;
 int SecsCount;
  // Variant
 boolean IIVartClear;
 OCustomTableModel TableMdlVart;
	String[] TableMdlVartColsName;
	int[] TableMdlVartColsType, TableMdlVartColsShowOption, TableMdlVartColsVisible, TableVartColsWidth;
	boolean[] TableMdlVartColsEditable;
 int LastSelectedRowVart;
 boolean InfoVartClear;
 // Tab supp
 OCustomTableModel TableMdlSupp;
	String[] TableMdlSuppColsName;
	int[] TableMdlSuppColsType, TableMdlSuppColsShowOption, TableMdlSuppColsVisible, TableSuppColsWidth;
	boolean[] TableMdlSuppColsEditable;
 int LastSelectedRowSupp;
 boolean InfoSuppClear;
 // Tab trans
 boolean IsQueryTransComponentsInitialized;
 
 boolean LastSelectedIsPreTrans;
 
 OCustomComboBoxModel ComboMdlTransType;
 int LastSelectedRowTransType;
 
 OCustomComboBoxModel ComboMdlTransSubject;
 int LastSelectedRowTransSubject;
 
 int QueryTransLimit;
 
 OCustomTableModel TableMdlTransIn;
	String[] TableTransInColsName;
	int[] TableTransInColsType, TableTransInColsShowOption, TableTransInColsVisible, TableTransInColsWidth;
 String QueryTransInOrderBy, QueryTransInTbHaving;
 int LastSelectedRowTransIn;
 boolean InfoTransInClear;
 
 OCustomTableModel TableMdlTransOut;
	String[] TableTransOutColsName;
	int[] TableTransOutColsType, TableTransOutColsShowOption, TableTransOutColsVisible, TableTransOutColsWidth;
 String QueryTransOutOrderBy, QueryTransOutTbHaving;
 int LastSelectedRowTransOut;
 boolean InfoTransOutClear;
 
 //
 OQuickListOfLong TempList;
 
 //
 boolean QuickSaveFirst;
 boolean ShowBuyPrice;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 public F_Item(MInterFormVariables IFV_) {
  int[] ColumnsType, Editable;
  Vector<CheckerAttrInputOpt> CheckerAttrInputOpts;
  Checker Checker;
  int temp, length;
  String[] Header;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  //
  QuickSaveFirst=true;

  // Tab Search
  ListMdlQStockUnit=new OCustomListModel(false);
  ListMdlQStockUnit.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QStockUnit.setModel(ListMdlQStockUnit);
  ListMdlQCat=new OCustomListModel(false);
  ListMdlQCat.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QCat.setModel(ListMdlQCat);
  ListMdlQTag=new OCustomListModel(false);
  ListMdlQTag.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QTag.setModel(ListMdlQTag);
  ListMdlQPic=new OCustomListModel(false);
  ListMdlQPic.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  List_QPic.setModel(ListMdlQPic);
  ListMdlQSup=new OCustomListModel(false);
  ListMdlQSup.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeString), 1);
  List_QSup.setModel(ListMdlQSup);
  CmB_QExpRange.setSelectedIndex(0);
  
  // Tab det
  CB_DetBuy.setSelected(false); CmB_DetBuy.setSelectedIndex(0); fillDetBuy();
  CB_DetSell.setSelected(true); CmB_DetSell.setSelectedIndex(0); fillDetSell();
  
  // Tab etc
  ListMdlItemCat=new OCustomListModel(false);
  ColumnsType=new int[2]; // (item_id), cat_id, cat_name
  ColumnsType[0]=2;
  ColumnsType[1]=1;
  ListMdlItemCat.setColumnsInfo(ColumnsType, 1);
  List_ItemCategory.setModel(ListMdlItemCat);
  
  ListMdlItemTag=new OCustomListModel(false);
  ColumnsType=new int[2]; // (item_id), tag_id, tag_name
  ColumnsType[0]=2;
  ColumnsType[1]=1;
  ListMdlItemTag.setColumnsInfo(ColumnsType, 1);
  List_ItemTag.setModel(ListMdlItemTag);
  
  // Tab pic
  ListMdlItemPic=new OCustomListModel(false);
  ColumnsType=new int[1]; // (item_id), filename
  ColumnsType[0]=1;
  ListMdlItemPic.setColumnsInfo(ColumnsType, 0);
  List_ItemPicture.setModel(ListMdlItemPic);
  
  LastSelectedRowPic=-1;
  PanelImageClear=true;
  
  // Tab vrs
  IIVrsClear=true;
  
   // Secondary Id
  IISecClear=true;
  
  ListMdlSec=new OCustomListModel(false);
  ListMdlSec.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeString), 1); // secondary_id, secondary_id's formatted_text
  List_Sec.setModel(ListMdlSec);
  
  LastSelectedRowSec=-1;
  InfoSecClear=true;
  
   // Variant
  IIVartClear=true;
  
  TableMdlVart=new OCustomTableModel();
  Tbl_Vart.setModel(TableMdlVart);
  
  TableMdlVartColsName=PMyShop.getItemVart_ColumnsName();
  TableMdlVartColsType=PMyShop.getItemVart_ColumnsType();
  TableMdlVartColsShowOption=PMyShop.getItemVart_ColumnsShowOption();
  TableMdlVartColsEditable=PMyShop.getItemVart_ColumnsEditable(true, true, true, true, true);
  LastSelectedRowVart=-1;
  InfoVartClear=true;
  
  PGUI.setSelected(true, CB_VartViewComment, CB_VartViewBuyPrice, CB_VartViewBuyComment);
  
  buildTableVartViewStructure(true, true);
  updateTableVartView(false);
  
  Tbl_Vart.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableVart();}
   };
  
  Pnl_VartInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Tab supp
  IISuppClear=true;
  
  TableMdlSupp=new OCustomTableModel();
  Tbl_Supp.setModel(TableMdlSupp);
  
  TableMdlSuppColsName=PMyShop.getItemSupp_ColumnsName(true);
  TableMdlSuppColsType=PMyShop.getItemSupp_ColumnsType();
  TableMdlSuppColsShowOption=PMyShop.getItemSupp_ColumnsShowOption();
  TableMdlSuppColsEditable=PMyShop.getItemSupp_ColumnsEditable(true, true, true);
  LastSelectedRowSupp=-1;
  InfoSuppClear=true;
  
  PGUI.setSelected(true, CB_SuppViewBuyPrc, CB_SuppViewBuyComment);
  
  buildTableSuppViewStructure(true, true);
  updateTableSuppView(false);
  
  Tbl_Supp.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableSupp();}
   };
  
  CmB_SuppFind.setSelectedIndex(0);
  
  // Tab trans
  IFV.PreventAutoFire.doPrevent(true); RB_TransIsPreTransN.setSelected(true);
  LastSelectedIsPreTrans=RB_TransIsPreTransY.isSelected();
  
  ComboMdlTransType=new OCustomComboBoxModel();
  ComboMdlTransType.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  CmB_TransType.setModel(ComboMdlTransType);
  LastSelectedRowTransType=-1;
  
  ComboMdlTransSubject=new OCustomComboBoxModel();
  ComboMdlTransSubject.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeString), 1);
  CmB_TransSubject.setModel(ComboMdlTransSubject);
  LastSelectedRowTransSubject=-1;
  
  QueryTransLimit=CApp.FormQueryLimit;
  
  IsQueryTransComponentsInitialized=false;
  
   // trans in
  TableMdlTransIn=new OCustomTableModel();
  Tbl_TransIn.setModel(TableMdlTransIn);
  TableTransInColsName=PCore.refArr("Tgl", "Jenis Trans", "Id Subjek", "Subjek", "Id Sales", "Sales", "Id Trans", "{Id-Ext}",
   "Qty", "Satuan Stok", "Hrg Sat.", "Hrg Total", "Komentar");
	 TableTransInColsType=PCore.primArr(CCore.TypeDate, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString);
  TableTransInColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableTransInColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(6), PCore.primArr(OCustomTableModel.ShowOptionObject));
  QueryTransInTbHaving="tb2";
  
  LastSelectedRowTransIn=-1;
  InfoTransInClear=true;
  
  PGUI.setSelected(true, CB_TransInDate, CB_TransInType, CB_TransInSubject, CB_TransInPriceUnit);
  buildTableTransInViewStructure(true, true);
  updateTableTransInView(false);
  
  CmB_TransInFind.setSelectedIndex(0);
  
   // trans out
  TableMdlTransOut=new OCustomTableModel();
  Tbl_TransOut.setModel(TableMdlTransOut);
  TableTransOutColsName=PCore.refArr("Tgl", "Jenis Trans", "Id Subjek", "Subjek", "Id Sales", "Sales", "Id Trans", "{Id-Ext}",
   "Qty", "Satuan Stok", "Hrg Sat.", "Hrg Total", "Komentar", "H-Beli Sat.", "HPP");
	 TableTransOutColsType=PCore.primArr(CCore.TypeDate, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble);
  TableTransOutColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableTransOutColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(6), PCore.primArr(OCustomTableModel.ShowOptionObject));
  QueryTransOutTbHaving="tb2";
  
  LastSelectedRowTransOut=-1;
  InfoTransOutClear=true;
  
  PGUI.setSelected(true, CB_TransOutDate, CB_TransOutType, CB_TransOutSubject, CB_TransOutPriceUnit);
  buildTableTransOutViewStructure(true, true);
  updateTableTransOutView(false);
  
  CmB_TransOutFind.setSelectedIndex(0);
  
  // Tab Category
  ListMdlCat=new OCustomListModel(true, false, "~ ~  ", "");
  ColumnsType=new int[2]; // id, name
  ColumnsType[0]=2;
  ColumnsType[1]=1;
  ListMdlCat.setColumnsInfo(ColumnsType, 1);
  List_Category.setModel(ListMdlCat);
  LastSelectedRowCat=-1;
  
  setCatQueryTypeNewState();
  
  ListMdlCatFilled=false;
  
  // Tabbed Pane
  TabbedPane.addChangeListener(new ChangeListener(){
    public void stateChanged(ChangeEvent e) {onTabbedPaneChanged();}
   });
  TabbedPane.setSelectedIndex(0);
  
  // Table Item
  TableItemMdl=new OCustomTableModel(true, false, true);
  Tbl_Item.setModel(TableItemMdl);
		TableItemColsName=PCore.refArr(
   "Id", "Nama", "Aktif",
   "Stok", "St-Min", "St-Max",
   "Pak-Qty", "Pak-%", "Min-Pak", "Opname", "Reorder",
   "Id Satuan", "Satuan", "Diperbarui",
   "Cek Exp", "Bts Exp", "Jelang Exp", "Exp",
   "Harga Jual", "Ket. Jual", "Pbruan Jual", "Harga Beli", "Ket. Beli", "Pbruan Beli",
   "Op-Stok (Selisih)", "Op-Exp",
   "Order Qty", "Harga Order",
   "Pra-Msk", "Pra-Klr", "Kis-Stok",
   "File Gambar", "Kategori");
		TableItemColsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean,
   CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeBoolean, CCore.TypeBoolean,
   CCore.TypeInteger, CCore.TypeString, CCore.TypeBoolean,
   CCore.TypeInteger, CCore.TypeInteger, CCore.TypeDate, CCore.TypeBoolean,
   CCore.TypeDouble, CCore.TypeString, CCore.TypeDate, CCore.TypeDouble, CCore.TypeString, CCore.TypeDate,
   CCore.TypeDouble, CCore.TypeDate,
   CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble,
   CCore.TypeString, CCore.TypeString);
  TableItemColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableItemColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(4, 5, 6, 7, 8, 14, 15, 18, 19, 20, 21, 22, 23, 24, 25, 26);
  TableItemColsEditable=PCore.changeValue(PCore.newBooleanArray(TableItemColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
		SumColumn=PCore.newBooleanArray(TableItemColsName.length, false);
  SumColumn[27]=true;
  SumResult=new double[SumColumn.length];
  LastSelectedRow=-1;
  IIEmptyAll=true;
  IIDet=false; IIDetClear=true;
  IIEtc=false; IIEtcClear=true;
  IIPic=false; IIPicClear=true;
  IISupp=false; IISuppClear=true;
  IITrans=false; IITransClear=true;
  
  QHavingTbl="tb5";
  
  updateQueryCount();
  clearLastQuery();
  
  LastResultFilterSubset=CmB_ResultFilterSubset.getSelectedIndex();
  LastResultFilterIsActive=CmB_ResultFilterActive.getSelectedIndex();
  LastResultFilterIsOpname=CmB_ResultFilterIsOpname.getSelectedIndex();
  LastResultFilterIsReorder=CmB_ResultFilterIsReorder.getSelectedIndex();
  LastResultFilterIsUpdateStock=CmB_ResultFilterUpdateStock.getSelectedIndex();
  LastResultFilterHasExpire=CmB_ResultFilterExpire.getSelectedIndex();
  
  OrderTotalPrice_Tbl=0;
  
  Tbl_Item.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem();}
   };
  
  // Panel Checker
		TF_CheckerId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
		TF_Checker1_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
		TF_Checker2_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  clearCheckerItemId();
  CmB_CheckerIdInput.setSelectedIndex(1); CmB_CheckerIdInputActionPerformed(null);
		
  ComboMdlCheckerAttr1=new OCustomComboBoxModel(); ComboMdlCheckerAttr1.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  CmB_CheckerAttr1.setModel(ComboMdlCheckerAttr1);
  
  ComboMdlCheckerAttr2=new OCustomComboBoxModel(); ComboMdlCheckerAttr2.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  CmB_CheckerAttr2.setModel(ComboMdlCheckerAttr2);
  
  Checkers=new Vector();
  
  Checker=new Checker("- Normal -", AttrsCount); Checkers.addElement(Checker);
  
  Checker=new Checker("Opname", AttrsCount); Checkers.addElement(Checker);
   //
  CheckerAttrInputOpts=new Vector();
  Checker.init(0, "Opname Stok (Selisih)", CheckerAttrInputOpts, 0);
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("Op St", true, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, false, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("Rset", false, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("St (+)", true, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("St (-)", true, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
   //
  CheckerAttrInputOpts=new Vector();
  Checker.init(1, "Opname Expire", CheckerAttrInputOpts, 0);
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("Op Exp", true, false, new OInputDateGUIText(TF_CheckerAttr2, false)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("Rset", false, false, new OInputDateGUIText(TF_CheckerAttr2, false)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("E (Min)", true, false, new OInputDateGUIText(TF_CheckerAttr2, false)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("E (Max)", true, false, new OInputDateGUIText(TF_CheckerAttr2, false)));
  
  Checker=new Checker("Order", AttrsCount); Checkers.addElement(Checker);
   //
  CheckerAttrInputOpts=new Vector();
  Checker.init(0, "Order Quantity", CheckerAttrInputOpts, 4);
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("Qty", true, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("Rset", false, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("(Min St)", false, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("(Max St)", false, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  CheckerAttrInputOpts.addElement(new CheckerAttrInputOpt("(Mid N%)", true, false, new OInputDoubleGUIText(TF_CheckerAttr1, false, true, true, false, 0, 0)));
  
  CheckerItemDet=new OInfoItem();
  Pnl_CheckerItemPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // TempList
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  clearTempList();
  
  // Panel View
  ComboMdlViewMode=new OCustomComboBoxModel(); ComboMdlViewMode.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  CmB_ViewMode.setModel(ComboMdlViewMode);
  temp=0; length=Checkers.size();
  do{
   ComboMdlViewMode.append(PCore.objArrVariant(Checkers.elementAt(temp).Name));
   temp=temp+1;
  }while(temp!=length);
  
  CB_ViewCategorized.setSelected(IFV.Conf.ItemCategorized);
  PGUI.setSelected(true,
   CB_ViewStock, CB_ViewStockUnit, CB_ViewStockIsUpdate,
   CB_ViewSellPrice, CB_ViewSellPriceComment);
  LastSelectedViewMode=-1; CmB_ViewMode.setSelectedIndex(0); onSelectedViewModeChanged(false);
  
  CmB_Find.setSelectedIndex(1);
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
  Btn_Query.setToolTipText("hasil pencarian terbatas hingga "+PText.intToString(CApp.FormQueryLimit)+" data");
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Query,
    CB_QCheck, CmB_QCheck,
    CB_QId, CmB_QId, TF_QId,
    CB_QName, TF_QName,
    CB_QComment, CmB_QComment, TF_QComment,
    CB_QExpList, CmB_QExpList, TF_QExpList,
    CB_QStock, CmB_QStock, TF_QStock1, TF_QStock2,
    CB_QOrderPack, CmB_QOrderPack, TF_QOrderPack1, TF_QOrderPack2,
    CB_QExpRange, CmB_QExpRange, TF_QExpRange1, TF_QExpRange2,
    CB_QPrice, CmB_QPrice, TF_QPrice1, TF_QPrice2,
    CB_QPriceUpdate, CmB_QPriceUpdate, TF_QPriceUpdate1, TF_QPriceUpdate2,
    CB_QOrder, CmB_QOrder, TF_QOrder1, TF_QOrder2,
    CB_QStockUnit, CB_QStockUnitEmpty, List_QStockUnit, Btn_QStockUnitAdd, Btn_QStockUnitRemove,
    CB_QCat, CB_QCatNon, List_QCat, Btn_QCatAdd, Btn_QCatRemove,
    CB_QTag, CB_QTagNon, List_QTag, Btn_QTagAdd, Btn_QTagRemove,
    CB_QPic, CB_QPicNon, List_QPic, Btn_QPicAdd, Btn_QPicRemove,
    CB_QSup, CB_QSupNon, List_QSup, Btn_QSupAdd, Btn_QSupRemove,
    
    Btn_CatRefresh, CmB_CatQueryType, Btn_TempListAddByCategory, Btn_TempListRemoveByCategory,
    List_Category,
    TF_FindCategory, Btn_FCatBefore, Btn_FCatNext, Btn_CatAdd, Btn_CatEdit, Btn_CatRemove,
    
    TF_Find, Tbl_Item,
    
    TF_SuppFind, Tbl_Supp,
    
    TF_TransInFind, Tbl_TransIn,
    TF_TransOutFind, Tbl_TransOut),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_NewActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
  
  // f4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0, true), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f5
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0, false), "f5");
  act.put("f5", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CheckerExecuteActionPerformed(null);
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 0 : Btn_QueryActionPerformed(null); break;
      case 1 : Btn_CatAddActionPerformed(null); break;
      case 4 : Btn_ItemPictureAddActionPerformed(null); break;
      case 6 : Btn_SuppAddActionPerformed(null); break;
     }
    }
   });
  
  // f7
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0, true), "f7");
  act.put("f7", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 1 : Btn_CatEditActionPerformed(null); break;
      case 6 : Btn_SuppEditActionPerformed(null); break;
     }
    }
   });
  
  // f8
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F8, 0, true), "f8");
  act.put("f8", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 1 : Btn_CatRemoveActionPerformed(null); break;
      case 4 : Btn_ItemPictureRemoveActionPerformed(null); break;
      case 6 : Btn_SuppRemoveActionPerformed(null); break;
     }
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // cancel table editing
  Tbl_Item.editingCanceled(null);
  Tbl_Supp.editingCanceled(null);
  
  // Tab Search
  CB_QId.setSelected(false); TF_QId.setText("");
  CB_QName.setSelected(false); TF_QName.setText("");
  CB_QComment.setSelected(false); TF_QComment.setText("");
  CB_QCheck.setSelected(false);
  CB_QExpList.setSelected(false); TF_QExpList.setText("");
		CB_QStock.setSelected(false); TF_QStock1.setText(""); TF_QStock2.setText("");
  CB_QOrderPack.setSelected(false); TF_QOrderPack1.setText(""); TF_QOrderPack2.setText("");
  CB_QPrice.setSelected(false); TF_QPrice1.setText(""); TF_QPrice2.setText("");
  CB_QExpRange.setSelected(false); TF_QExpRange1.setText(""); TF_QExpRange2.setText("");
  CB_QPriceUpdate.setSelected(false); TF_QPriceUpdate1.setText(""); TF_QPriceUpdate2.setText("");
  CB_QOrder.setSelected(false); TF_QOrder1.setText(""); TF_QOrder2.setText("");
  CB_QStockUnit.setSelected(false); CB_QStockUnitEmpty.setSelected(false); ListMdlQStockUnit.removeAll();
  CB_QCat.setSelected(false); CB_QCatNon.setSelected(false); ListMdlQCat.removeAll();
  CB_QTag.setSelected(false); CB_QTagNon.setSelected(false); ListMdlQTag.removeAll();
  CB_QPic.setSelected(false); CB_QPicNon.setSelected(false); ListMdlQPic.removeAll();
  CB_QSup.setSelected(false); CB_QSupNon.setSelected(false); ListMdlQSup.removeAll();
  
  // Tab Category
  clearListModelCategory(false);
  TF_FindCategory.setText("");
  
  // Table Item
  clearTable();
  clearLastQuery();
  TF_Find.setText("");
  
  // Panel Opname
  clearCheckerAttrsInput(true, true);
  
  // Tab det, cat, tag, pic, vrs, supp, trans
  clearDet();
  clearEtc();
  clearPic();
  clearVrs();
  clearSupp();
  clearTrans(); clearTransQueryComponents();
  
  // TabbedPane
  TabbedPane.setSelectedIndex(0);
  
  //
  QuickSaveFirst=true;
 }
 void initTransQueryComponents(){
  if(IsQueryTransComponentsInitialized==true){return;}
  
  PDatabase.queryToComboBox(IFV.Stm,
   "select Id, Name from TransType order by Name asc;", ComboMdlTransType, true, PCore.refArr("Semua"));
  IFV.PreventAutoFire.doPrevent(true); CmB_TransType.setSelectedIndex(0); LastSelectedRowTransType=CmB_TransType.getSelectedIndex();
  
  PDatabase.queryToComboBox(IFV.Stm,
   "select Id, Name from Subject order by Name asc;", ComboMdlTransSubject, true, PCore.refArr("Semua"));
  IFV.PreventAutoFire.doPrevent(true); CmB_TransSubject.setSelectedIndex(0); LastSelectedRowTransSubject=CmB_TransSubject.getSelectedIndex();
  
  IsQueryTransComponentsInitialized=true;
 }
 void clearTransQueryComponents(){
  if(IsQueryTransComponentsInitialized==false){return;}
  
  ComboMdlTransType.removeAll(); LastSelectedRowTransType=-1;
  ComboMdlTransSubject.removeAll(); LastSelectedRowTransSubject=-1;
  
  IsQueryTransComponentsInitialized=false;
 }
 
 //
 void updateTableItemView(boolean Requery){
  TableItemMdl.updateColumnsInfo(TableItemColsName, TableItemColsType, TableItemColsShowOption, TableItemColsVisible, TableItemColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Item, TableItemColsWidth);
  if(!Requery){onTableSelectedRowChanged(false);}else{fillTable();}
 }
 void buildTableItemViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  // Check Sign Of TempList
  ColsWidth.addElement(25);
  
  // Name, Id, IsActive
  ColsVisible.addElement(1); ColsWidth.addElement(400);
  ColsVisible.addElement(2); ColsWidth.addElement(25);
  
  // Stock
  if(CB_ViewStock.isSelected()){ColsVisible.addElement(3); ColsWidth.addElement(55);}
  if(CB_ViewStockPre.isSelected()){
   ColsVisible.addElement(28); ColsWidth.addElement(55);
   ColsVisible.addElement(29); ColsWidth.addElement(55);
  }
  if(CB_ViewStockEst.isSelected()){ColsVisible.addElement(30); ColsWidth.addElement(55);}
  if(CB_ViewStockMinMax.isSelected()){
   ColsVisible.addElement(4); ColsWidth.addElement(55);
   ColsVisible.addElement(5); ColsWidth.addElement(55);
  }
  
  if(CB_ViewIsOpname.isSelected()){ColsVisible.addElement(9); ColsWidth.addElement(25);}
  
  if(CB_ViewIsReorder.isSelected()){ColsVisible.addElement(10); ColsWidth.addElement(25);}
  
  if(CB_ViewOrderPackQty.isSelected()){ColsVisible.addElement(6); ColsWidth.addElement(45);}
  
  if(CB_ViewStockUnit.isSelected()){ColsVisible.addElement(12); ColsWidth.addElement(65);}
  
  if(CB_ViewOrderPackThreshold.isSelected()){ColsVisible.addElement(7); ColsWidth.addElement(45);}
  if(CB_ViewOrderPackMin.isSelected()){ColsVisible.addElement(8); ColsWidth.addElement(45);}
  
  if(CB_ViewStockIsUpdate.isSelected()){ColsVisible.addElement(13); ColsWidth.addElement(25);}
  
  // Price
  if(CB_ViewBuyPrice.isSelected()){ColsVisible.addElement(21); ColsWidth.addElement(100);}
  if(CB_ViewBuyPriceComment.isSelected()){ColsVisible.addElement(22); ColsWidth.addElement(150);}
  if(CB_ViewBuyUpdate.isSelected()){ColsVisible.addElement(23); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_ViewSellPrice.isSelected()){ColsVisible.addElement(18); ColsWidth.addElement(100);}
  if(CB_ViewSellPriceComment.isSelected()){ColsVisible.addElement(19); ColsWidth.addElement(150);}
  if(CB_ViewSellUpdate.isSelected()){ColsVisible.addElement(20); ColsWidth.addElement(CGUI.ColDate);}
  
  // Expire
  if(CB_ViewExpCheckPeriod.isSelected()){ColsVisible.addElement(14); ColsWidth.addElement(55);}
  if(CB_ViewExpThreshold.isSelected()){ColsVisible.addElement(15); ColsWidth.addElement(55);}
  if(CB_ViewHasExp.isSelected()){ColsVisible.addElement(17); ColsWidth.addElement(25);}
  
  TableItemColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableItemColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableItemColumns(){
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  switch(CmB_ViewMode.getSelectedIndex()){
   case 1 :
    TableItemColsVisible=PCore.primArr(1, 2, 3, 24, 13, 16, 25, 17);
    TableItemColsWidth=PCore.primArr(25, 400, 25, 55, 55, 25, CGUI.ColDate, CGUI.ColDate, 25);
    break;
   case 2 :
    TableItemColsVisible=PCore.primArr(1, 2, 30, 4, 5, 6, 8, 13, 21, 26, 27);
    TableItemColsWidth=PCore.primArr(20, 400, 20, 40, 40, 40, 40, 40, 20, 100, 40, 100);
    break;
   default : buildTableItemViewColumnsByNormalMode(); break;
  }
  if(!IsCategorized){
   TableItemColsVisible=PCore.insert(TableItemColsVisible, 1, 0);
   TableItemColsWidth=PCore.insert(TableItemColsWidth, 2, 115);
  }
  else{
   TableItemColsVisible=PCore.insert(TableItemColsVisible, 0, 32);
   TableItemColsWidth=PCore.insert(TableItemColsWidth, 1, 130);
  }
 }
 void buildTableItemOrderBy(){
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  LQ_OrderBy=PText.getString(!IsCategorized, " order by "+QHavingTbl+".Name asc", " order by CategoryOfItem.Name asc, "+QHavingTbl+".Name asc");
 }
 void buildTableItemViewStructure(boolean RefreshTableColumns, boolean RefreshOrderBy){
  if(RefreshTableColumns){buildTableItemColumns();}
  if(RefreshOrderBy){buildTableItemOrderBy();}
 }
 void changeTableItemViewByNormalMode(){
  buildTableItemViewStructure(true, false);
  updateTableItemView(false);
 }
 void changeTableItemViewByCategorized(){
  buildTableItemViewStructure(true, true);
  updateTableItemView(true);
 }
	void changeTableItemViewMode(){
		// change table view structure
  buildTableItemViewStructure(true, true);
		updateTableItemView(false);
  
  // change checker
  changeCurrChecker();
  
  // change other GUI
  changeTableItemViewModeGUI();
	}
 void changeTableItemViewModeGUI(){
  boolean IsNormalMode=CmB_ViewMode.getSelectedIndex()==0;
  
  changeCheckerInfoGUI();
  Pnl_ViewNormalMode.setVisible(IsNormalMode);
  Pnl_CheckerInput.setVisible(!IsNormalMode);
 }
 void changeCheckerInfoGUI(){
  int ViewMode=CmB_ViewMode.getSelectedIndex();
  boolean Visible;
  String txt, tooltip;
  
  Visible=false; txt=null; tooltip=null;
  switch(ViewMode){
   case 1 : Visible=true; txt="Start"; tooltip="mulai proses opname pd semua data barang"; break;
   case 2 : Visible=true; txt="Start"; tooltip="mulai proses re-order pd semua data barang"; break;
  }
  Btn_CheckerP1.setVisible(Visible);
  Btn_CheckerP1.setText(PText.getString(txt, "-", true));
  Btn_CheckerP1.setToolTipText(PText.getString(tooltip, "-", true));
  
  Visible=false; txt=null; tooltip=null;
  switch(ViewMode){
   case 1 : Visible=true; txt="Done"; tooltip="selesaikan proses opname pd semua data barang"; break;
   case 2 : Visible=true; txt="Done"; tooltip="selesaikan proses re-order pd semua data barang"; break;
  }
  Btn_CheckerP2.setVisible(Visible);
  Btn_CheckerP2.setText(PText.getString(txt, "-", true));
  Btn_CheckerP2.setToolTipText(PText.getString(tooltip, "-", true));
 }
 
 
 void updateTableTransInView(boolean Requery){
  long ItemId;
  int RowItem;
  
  TableMdlTransIn.updateColumnsInfo(TableTransInColsName, TableTransInColsType, TableTransInColsShowOption, TableTransInColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_TransIn, TableTransInColsWidth);
  if(!Requery){onTableTransInSelectedRowChanged(false);}
  else{
   ItemId=-1; RowItem=Tbl_Item.getSelectedRow(); if(RowItem!=-1){ItemId=(Long)TableItemMdl.Mdl.Rows.elementAt(RowItem)[0];}
   fillTransIn(ItemId);
  }
 }
 void buildTableTransInViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  if(CB_TransInDate.isSelected()){ColsVisible.addElement(0); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_TransInType.isSelected()){ColsVisible.addElement(1); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInSubject.isSelected()){ColsVisible.addElement(3); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInSalesman.isSelected()){ColsVisible.addElement(5); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInId.isSelected()){ColsVisible.addElement(6); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInIdExternal.isSelected()){ColsVisible.addElement(7); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransInItemComment.isSelected()){ColsVisible.addElement(12); ColsWidth.addElement(CGUI.ColTextSml);}
  ColsVisible.addElement(8); ColsWidth.addElement(CGUI.ColNumSep04); // Qty
  if(CB_TransInPriceUnit.isSelected()){ColsVisible.addElement(10); ColsWidth.addElement(CGUI.ColNumSep09);}
  if(CB_TransInPriceTotal.isSelected()){ColsVisible.addElement(11); ColsWidth.addElement(CGUI.ColNumSep09_a);}
  
  TableTransInColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableTransInColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableTransInColumns(){
  buildTableTransInViewColumnsByNormalMode();
 }
 void buildTableTransInOrderBy(){
  QueryTransInOrderBy=" order by TransDate desc, TransTypeName asc, SubjectName asc, SalesmanName asc, TransId desc";
 }
 void buildTableTransInViewStructure(boolean RefreshTableColumns, boolean RefreshOrderBy){
  if(RefreshTableColumns){buildTableTransInColumns();}
  if(RefreshOrderBy){buildTableTransInOrderBy();}
 }
 void changeTableTransInViewByNormalMode(){
  buildTableTransInViewStructure(true, false);
  updateTableTransInView(false);
 }
 
 void updateTableTransOutView(boolean Requery){
  long ItemId;
  int RowItem;
  
  TableMdlTransOut.updateColumnsInfo(TableTransOutColsName, TableTransOutColsType, TableTransOutColsShowOption, TableTransOutColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_TransOut, TableTransOutColsWidth);
  if(!Requery){onTableTransOutSelectedRowChanged(false);}
  else{
   ItemId=-1; RowItem=Tbl_Item.getSelectedRow(); if(RowItem!=-1){ItemId=(Long)TableItemMdl.Mdl.Rows.elementAt(RowItem)[0];}
   fillTransOut(ItemId);
  }
 }
 void buildTableTransOutViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  if(CB_TransOutDate.isSelected()){ColsVisible.addElement(0); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_TransOutType.isSelected()){ColsVisible.addElement(1); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutSubject.isSelected()){ColsVisible.addElement(3); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutSalesman.isSelected()){ColsVisible.addElement(5); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutId.isSelected()){ColsVisible.addElement(6); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutIdExternal.isSelected()){ColsVisible.addElement(7); ColsWidth.addElement(CGUI.ColTextSml);}
  if(CB_TransOutItemComment.isSelected()){ColsVisible.addElement(12); ColsWidth.addElement(CGUI.ColTextSml);}
  ColsVisible.addElement(8); ColsWidth.addElement(CGUI.ColNumSep04); // Qty
  if(CB_TransOutPriceUnit.isSelected()){ColsVisible.addElement(10); ColsWidth.addElement(CGUI.ColNumSep09);}
  if(CB_TransOutPriceTotal.isSelected()){ColsVisible.addElement(11); ColsWidth.addElement(CGUI.ColNumSep09_a);}
  if(CB_TransOutPriceBasic.isSelected()){ColsVisible.addElement(14); ColsWidth.addElement(CGUI.ColNumSep09_a);}
  
  TableTransOutColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableTransOutColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableTransOutColumns(){
  buildTableTransOutViewColumnsByNormalMode();
 }
 void buildTableTransOutOrderBy(){
  QueryTransOutOrderBy=" order by TransDate desc, TransTypeName asc, SubjectName asc, SalesmanName asc, TransId desc";
 }
 void buildTableTransOutViewStructure(boolean RefreshTableColumns, boolean RefreshOrderBy){
  if(RefreshTableColumns){buildTableTransOutColumns();}
  if(RefreshOrderBy){buildTableTransOutOrderBy();}
 }
 void changeTableTransOutViewByNormalMode(){
  buildTableTransOutViewStructure(true, false);
  updateTableTransOutView(false);
 }
 
 //
 void setLastQuery(int LastQueryOperationBy, int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConDefined, String StaticPostCondition, boolean StaticPostConDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  this.LastQueryOperationBy=LastQueryOperationBy;
  
		LQ_Limit=Limit;
  
		LQ_StaticSourceTable=StaticSourceTable;
		LQ_StaticCondition=StaticCondition; LQ_StaticConditionDefined=StaticConDefined;
		LQ_StaticPostCondition=StaticPostCondition; LQ_StaticPostConditionDefined=StaticPostConDefined;
  
  LQ_DynamicTempList=DynamicTempList;
  
  LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  LastQueryDefined=true;
 }
 void clearLastQuery(){
  LastQueryDefined=false;
 }
 void dialogWithFSubject(boolean Enable){
  Btn_SuppAdd.setEnabled(Enable);
  Btn_SuppEdit.setEnabled(Enable);
  Btn_MultipleItemsSupAdd.setEnabled(Enable);
  Btn_MultipleItemsSupRemove.setEnabled(Enable);
  Btn_QSupAdd.setEnabled(Enable);
 }

 void onSelectedViewModeChanged(boolean UpdateAnyway){
  int CurrRow=CmB_ViewMode.getSelectedIndex();
  
  if(CurrRow==LastSelectedViewMode && !UpdateAnyway){return;}
  
  LastSelectedViewMode=CurrRow;
  
  // change table view
  changeTableItemViewMode();
 }
 void onTabbedPaneChanged(){
  int CurrTab=TabbedPane.getSelectedIndex();
  int row;
  if(CurrTab!=0 && CurrTab!=1){
   if(CurrTab==7){initTransQueryComponents();}
   
   row=Tbl_Item.getSelectedRow();
   if(row!=-1){
    fillAnActiveTab(CurrTab, (Long)TableItemMdl.Mdl.Rows.elementAt(row)[0]);
   }
   else{
    clearAnActiveTab(CurrTab);
   }
  }
  else{
   if(CurrTab==1){fillListModelCategory(1);}
   
   if(CurrTab==0){focusQuery();}
   else if(CurrTab==1){PGUI.requestFocusInWindow(TF_FindCategory);}
  }
 }
 void onTableSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_Item.getSelectedRow();
  int tab;
  if(row!=LastSelectedRow || UpdateAnyway){
   LastSelectedRow=row;
   updateCheckerInput(true, row);
   clearItemInformationIndex();
   tab=TabbedPane.getSelectedIndex();
   if(tab!=0 && tab!=1){
    if(row!=-1){
     fillAnActiveTab(tab, (Long)TableItemMdl.Mdl.Rows.elementAt(row)[0]);
    }
    else{
     clearAnActiveTab(tab);
    }
   }
  }
 }
 void onListCategoryRowSelected(boolean UpdateAnyway){
  int row=List_Category.getSelectedIndex();
  if(LastSelectedRowCat!=row || LastQueryOperationBy!=2 || UpdateAnyway){
   LastSelectedRowCat=row;
   if(row!=-1){
    setLastQuery(2, 0,
     ", ItemXCategory", " where Item.Id=ItemXCategory.Item and ItemXCategory.CategoryOfItem="+ListMdlCat.Mdl.Rows.elementAt(row)[0], true, "", false,
     0, true);
    fillTable();
   }
  }
 }
 void onListPicRowSelected(boolean UpdateAnyway){
  int row=List_ItemPicture.getSelectedIndex();
  if(LastSelectedRowPic!=row || UpdateAnyway){
   LastSelectedRowPic=row;
   if(row!=-1){fillPanelImage(ListMdlItemPic.getElementAt(row));}
   else{clearPanelImage();}
   Panel_Image.repaint();
  }
 }
 void onTableTransInSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_TransIn.getSelectedRow();
  
  if(!UpdateAnyway && LastSelectedRowTransIn==row){return;}
  
  LastSelectedRowTransIn=row;
  if(row!=-1){fillInfoTransIn(LastSelectedRowTransIn);}
  else{clearInfoTransIn();}
 }
 void onTableTransOutSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_TransOut.getSelectedRow();
  
  if(!UpdateAnyway && LastSelectedRowTransOut==row){return;}
  
  LastSelectedRowTransOut=row;
  if(row!=-1){fillInfoTransOut(LastSelectedRowTransOut);}
  else{clearInfoTransOut();}
 }
 void onQueryTransComponentsChanged(){
  boolean SelectedIsPreTrans=RB_TransIsPreTransY.isSelected();
  int SelectedTransType=CmB_TransType.getSelectedIndex();
  int SelectedTransSubject=CmB_TransSubject.getSelectedIndex();
  
  long ItemId; int ItemRow;
  
  if(
   LastSelectedIsPreTrans==SelectedIsPreTrans &&
   LastSelectedRowTransType==SelectedTransType &&
   LastSelectedRowTransSubject==SelectedTransSubject){
   return;
  }
  
  LastSelectedIsPreTrans=SelectedIsPreTrans;
  LastSelectedRowTransType=SelectedTransType;
  LastSelectedRowTransSubject=SelectedTransSubject;
  
  ItemRow=Tbl_Item.getSelectedRow();
  if(ItemRow==-1){return;}
  
  ItemId=(Long)TableItemMdl.Mdl.Rows.elementAt(ItemRow)[0];
  fillTrans(ItemId);
 }
 
 void onEditingTableItem(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=Tbl_Item.Editing_Row;
  Col=TableItemMdl.convertColumnIndexFromViewToModel(Tbl_Item.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableItemMdl.Mdl.ColumnsType[Col], null, Tbl_Item.Editing_ValueOld, true, null, Tbl_Item.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableItem_Check(Row); break;}
   if(Col==24 || Col==25){result=onEditingTableItem_Opname(Row, Col); break;}
   if(Col==26){result=onEditingTableItem_Order(Row, Col); break;}
   result=onEditingTableItem_Item(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableItem_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  fillTempList(PGUI.getIdsFromSelectedRows(TableItemMdl, PCore.primArr(Row), 0), PCore.objBoolean(Tbl_Item.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingTableItem_Opname(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  boolean valid;
  boolean UpdateOpStock; Double vOpStock;
  boolean UpdateOpExp; Date vOpExp;
  
  do{
   UpdateOpStock=false; vOpStock=null;
   UpdateOpExp=false; vOpExp=null;

   valid=true;
   switch(Col){
    case 24 : UpdateOpStock=true; vOpStock=PCore.objDouble(Tbl_Item.Editing_ValueNew, null); break;
    case 25 : UpdateOpExp=true; vOpExp=PCore.objDate(Tbl_Item.Editing_ValueNew, null); break;
   }
   if(!valid){ret=-2; break;}

   if(!updateOpname(PCore.primArr((Long)TableItemMdl.Mdl.Rows.elementAt(Row)[0]), true, PCore.primArr(Row),
    UpdateOpStock, 0, vOpStock, UpdateOpExp, 0, vOpExp)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 int onEditingTableItem_Order(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  boolean valid;
  double vOrderQty;
  
  do{
   valid=true;
   vOrderQty=-1;
   if(Tbl_Item.Editing_ValueNew!=null){
    vOrderQty=(Double)Tbl_Item.Editing_ValueNew;
    if(vOrderQty<0){valid=false;}
   }
   if(!valid){ret=-2; break;}

   if(!updateOrder(PCore.primArr((Long)TableItemMdl.Mdl.Rows.elementAt(Row)[0]), true, PCore.primArr(Row),
    true, 0, vOrderQty)){ret=-1; break;}
  }while(false);
   
  return ret;
 }
 int onEditingTableItem_Item(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  boolean valid, FetchDataOld;
  OEditItem Edit;
  
  do{
   Edit=new OEditItem();
   FetchDataOld=false;
   valid=true;
   switch(Col){
    // boolean not null
    case 2 : Edit.EditIsActive=true; Edit.EditedIsActive=PCore.objBoolean(Tbl_Item.Editing_ValueNew, false); break;
    case 13 : Edit.EditUpdateStock=true; Edit.EditedUpdateStock=PCore.objBoolean(Tbl_Item.Editing_ValueNew, false); break;
    case 9 : Edit.EditIsOpname=true; Edit.EditedIsOpname=PCore.objBoolean(Tbl_Item.Editing_ValueNew, false); break;
    case 10 : Edit.EditIsReorder=true; Edit.EditedIsReorder=PCore.objBoolean(Tbl_Item.Editing_ValueNew, false); break;
    case 17 : Edit.EditExp=true; Edit.EditedExp=PCore.objBoolean(Tbl_Item.Editing_ValueNew, false); break;
    
    // integer null, positive only, >=0
    case 15 : Edit.EditExpThreshold=true; Edit.EditedExpThreshold=-1; if(Tbl_Item.Editing_ValueNew!=null){Edit.EditedExpThreshold=(Integer)Tbl_Item.Editing_ValueNew; if(Edit.EditedExpThreshold<0){valid=false;}} break;
    
    // integer null, positive only, >0
    case 14 : Edit.EditExpCheckPeriod=true; Edit.EditedExpCheckPeriod=-1; if(Tbl_Item.Editing_ValueNew!=null){Edit.EditedExpCheckPeriod=(Integer)Tbl_Item.Editing_ValueNew; if(Edit.EditedExpCheckPeriod<=0){valid=false;}} break;
    
    // long not null, positive only, >=0
    case 0 : Edit.EditId=true; Edit.EditedId=PCore.objLong(Tbl_Item.Editing_ValueNew, -1L); if(Edit.EditedId<0){valid=false;} break;
    
    // double null
    case 24 : Edit.EditOpStock=true; Edit.EditedOpStock=PCore.objDouble(Tbl_Item.Editing_ValueNew, null); break;
    
    // double null, positive only, >=0
    case 26 : Edit.EditOrderQty=true; Edit.EditedOrderQty=-1D; if(Tbl_Item.Editing_ValueNew!=null){Edit.EditedOrderQty=(Double)Tbl_Item.Editing_ValueNew; if(Edit.EditedOrderQty<0){valid=false;}} break;
    
    // double null, positive only, >0
    case 6 : Edit.EditOrderPackQty=true; Edit.EditedOrderPackQty=-1D; if(Tbl_Item.Editing_ValueNew!=null){Edit.EditedOrderPackQty=(Double)Tbl_Item.Editing_ValueNew; if(Edit.EditedOrderPackQty<=0){valid=false;}} break;
    case 8 : Edit.EditOrderMinPack=true; Edit.EditedOrderMinPack=-1D; if(Tbl_Item.Editing_ValueNew!=null){Edit.EditedOrderMinPack=(Double)Tbl_Item.Editing_ValueNew; if(Edit.EditedOrderMinPack<=0){valid=false;}} break;
    case 7 : Edit.EditOrderPackThreshold=true; Edit.EditedOrderPackThreshold=-1D; if(Tbl_Item.Editing_ValueNew!=null){Edit.EditedOrderPackThreshold=(Double)Tbl_Item.Editing_ValueNew; if(Edit.EditedOrderPackThreshold<=0 || Edit.EditedOrderPackThreshold>100){valid=false;}} break;
    
    // double not null, positive & negative
    case 3 : Edit.EditStock=true; Edit.EditedStock=PCore.objDouble(Tbl_Item.Editing_ValueNew, null); if(Edit.EditedStock==null){valid=false;} break;
    
    // double not null, positive only, >=0
    case 4 : Edit.EditMinStock=true; Edit.EditedMinStock=PCore.objDouble(Tbl_Item.Editing_ValueNew, -1D); if(Edit.EditedMinStock<0){valid=false;} break;
    case 5 : Edit.EditMaxStock=true; Edit.EditedMaxStock=PCore.objDouble(Tbl_Item.Editing_ValueNew, -1D); if(Edit.EditedMaxStock<0){valid=false;} break;
    case 18 :
     Edit.EditSellPrice=true; Edit.EditedSellPrice=PCore.objDouble(Tbl_Item.Editing_ValueNew, -1D);
     Edit.EditSellUpdate=true; Edit.EditedSellUpdate=PDate.generateDate(new Date(), false);
     if(Edit.EditedSellPrice<0){valid=false;} break;
    case 21 :
     Edit.EditBuyPrice=true; Edit.EditedBuyPrice=PCore.objDouble(Tbl_Item.Editing_ValueNew, -1D);
     Edit.EditBuyUpdate=true; Edit.EditedBuyUpdate=PDate.generateDate(new Date(), false);
     if(Edit.EditedBuyPrice<0){valid=false;} break;
    
    // date null
    case 20 : Edit.EditSellUpdate=true; Edit.EditedSellUpdate=PCore.objDate(Tbl_Item.Editing_ValueNew, null); break;
    case 23 : Edit.EditBuyUpdate=true; Edit.EditedBuyUpdate=PCore.objDate(Tbl_Item.Editing_ValueNew, null); break;
    case 25 : Edit.EditOpExp=true; Edit.EditedOpExp=PCore.objDate(Tbl_Item.Editing_ValueNew, null); break;
    
    // string null
    case 19 :
     Edit.EditSellComment=true; Edit.ReplaceSubSellComment=false; Edit.EditedSellComment=PCore.objString(Tbl_Item.Editing_ValueNew, null); break;
    case 22 :
     Edit.EditBuyComment=true; Edit.ReplaceSubBuyComment=false; Edit.EditedBuyComment=PCore.objString(Tbl_Item.Editing_ValueNew, null); break;
    
    // string not null
    case 1 : Edit.EditName=true; Edit.EditedName=PCore.objString(Tbl_Item.Editing_ValueNew, null); if(PText.isEmptyString(Edit.EditedName, true, true)){valid=false;} break;
   }
   if(!valid){ret=-2; break;}

   if(editItems(PCore.primArr(Row), FetchDataOld, null, Edit, false)!=0){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void clearItemInformationIndex(){
  if(IIEmptyAll==false){
   IIDet=false;
   IIEtc=false;
   IIPic=false;
   IIVrs=false;
   IISupp=false;
   IITrans=false;
   IIEmptyAll=true;
  }
 }
 
 void updateTempListQuantity(){TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));}
 void fillTempList(long[] Items, boolean IsAdd){
  long[] AffectItems;
  double dbl;
  
  if(Items.length==0){return;}
  
  AffectItems=PCore.subArr(Items, TempList.addElements(Items, IsAdd));
  if(AffectItems.length==0){return;}
  
  updateTempListQuantity();
  fillSignItems(AffectItems, IsAdd);
  fillSignCategories(AffectItems, IsAdd, false);
  
  try{
   dbl=PCore.objDouble(PDatabase.getFirstRecord(IFV.Stm,
    "select sum(ifnull(OrderQuantity,0)*BuyPriceEstimation) from Item where Id in("+PText.toString(AffectItems, 0, AffectItems.length, ",")+")",
    0, CCore.TypeDouble), 0D);
  }
  catch(Exception E){dbl=0;}
  addOrderTotalPriceTempList(dbl, IsAdd);
  refreshCheckerInfo();
 }
 void clearTempList(){
  TempList.removeAll();
  updateTempListQuantity();
  
  clearSignItems();
  clearSignCategories(false);
  clearBackgroundVariables_TempList();
  refreshCheckerInfo();
 }
 void fillTempListByCategory(long[] Categories, boolean IsAdd){
  long[] Items;
  
  Items=PCore.primArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm,
   "select Item from ItemXCategory where CategoryOfItem in ("+PText.toString(Categories, 0, Categories.length, ",")+") group by Item;",
   CCore.TypeLong, false, null));
  
  if(Items==null){
   JOptionPane.showMessageDialog(null, "Gagal "+PText.getString(IsAdd, "menambah", "mengurangi")+" barang2 pada kategori2 yg dipilih "+
    PText.getString(IsAdd, "ke", "dari")+" \"DaftarKu\"");
   return;
  }
  
  fillTempList(Items, IsAdd);
 }
 void updateQueryCount(){TF_QueryCount.setText(PText.intToString(TableItemMdl.getRowCount()));}
 void fillTable(){
  String Query, Limit;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  long[] tlist;
  boolean con_defined, conpost_defined;
  
  clearTable();
  
  if(!LastQueryDefined){return;}
  
  Query=null;
  do{
   // build query
   con_defined=LQ_StaticConditionDefined; conpost_defined=LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   if(LQ_DynamicTempList!=0){
    if(TempList.ElementsCount==0){if(LQ_DynamicTempList==1){break;}}
    else{
     if(!con_defined){con_defined=true; DynamicCondition.append(" where");}else{DynamicCondition.append(" and");}
     tlist=TempList.getElements();
     DynamicCondition.append(" Item.Id"+PText.getString(LQ_DynamicTempList, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
    }
   }
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   if(LQ_WithAdditionalFilter){
    if(LastResultFilterSubset!=0){
     if(LastResultFilterSubset!=LQ_DynamicTempList){
      if(LQ_DynamicTempList!=0){break;}
      if(TempList.ElementsCount==0){if(LastResultFilterSubset==1){break;}}
      else{
       if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
       tlist=TempList.getElements();
       AdditionalCondition.append(" Item.Id"+PText.getString(LastResultFilterSubset, 1, 2, " in", " not in", null)+
        "("+PText.toString(tlist, 0, tlist.length, ",")+")");
      }
     }
    }
    if(LastResultFilterIsActive!=0){
     if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
     AdditionalCondition.append(" Item.IsActive="+PText.getString(LastResultFilterIsActive, 1, 2, CCore.vTrue, CCore.vFalse, null));
    }
    if(LastResultFilterIsUpdateStock!=0){
     if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
     AdditionalCondition.append(" Item.UpdateStockOnTransaction="+PText.getString(LastResultFilterIsUpdateStock, 1, 2, CCore.vTrue, CCore.vFalse, null));
    }
    if(LastResultFilterIsOpname!=0){
     if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
     AdditionalCondition.append(" Item.IsOpname="+PText.getString(LastResultFilterIsOpname, 1, 2, CCore.vTrue, CCore.vFalse, null));
    }
    if(LastResultFilterIsReorder!=0){
     if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
     AdditionalCondition.append(" Item.IsReorder="+PText.getString(LastResultFilterIsReorder, 1, 2, CCore.vTrue, CCore.vFalse, null));
    }
    if(LastResultFilterHasExpire!=0){
     if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
     AdditionalCondition.append(" Item.HasExpireDate="+PText.getString(LastResultFilterHasExpire, 1, 2, CCore.vTrue, CCore.vFalse, null));
    }
   }
   
    // finally, build query
   Limit=PText.getString(LQ_Limit, 0, " limit "+LQ_Limit, "");
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
   Query=
    "select tb5.*, Min(CategoryOfItem.Name) as 'CategoryName' from "+
     "(select tb4.*, (Stock+ifnull(PreStockIn,0)-ifnull(PreStockOut,0)) as 'StockEst', Min(ItemXPicture.FileName) as 'PictureFile' from "+
      "(select tb3.*, Sum(PreTransXItemOut.Stock) as 'PreStockOut' from "+
       "(select tb2.*, Sum(PreTransXItemIn.Stock) as 'PreStockIn' from "+
        "(select "+
         "tb1.Id, tb1.Name, tb1.IsActive, "+
         "tb1.Stock, tb1.MinimalStock, tb1.MaximalStock, "+
         "tb1.OrderEachPackQty, tb1.OrderEachPackThreshold, tb1.OrderMinPack, tb1.IsOpname, tb1.IsReorder, "+
         "tb1.StockUnit, StockUnit.Name as 'StockUnitName', tb1.UpdateStockOnTransaction, "+
         "tb1.ExpireCheckPeriod, tb1.ExpireThreshold, tb1.ExpireThresholdDate, tb1.HasExpireDate, "+
         "tb1.SellPrice, tb1.SellPriceComment, tb1.SellUpdate, tb1.BuyPriceEstimation, tb1.BuyPriceComment, tb1.BuyUpdate, "+
         "tb1.OpnameStock, tb1.OpnameExpire, "+
         "tb1.OrderQuantity, tb1.OrderPriceEstimation "+
        "from "+
         "(select Item.*, "+
          "if(Item.ExpireThreshold is "+CCore.vNull+", "+CCore.vNull+", Date_Add(CurDate(), Interval ifnull(Item.ExpireThreshold, 0) Day)) as 'ExpireThresholdDate', "+
          "if(Item.OrderQuantity is "+CCore.vNull+", "+CCore.vNull+", ifnull(Item.OrderQuantity, 0)*Item.BuyPriceEstimation) as 'OrderPriceEstimation' "+
         "from Item"+LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
          LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+") as tb1 "+
        "left join StockUnit on tb1.StockUnit=StockUnit.Id) as tb2 "+
       "left join PreTransXItemIn on tb2.Id=PreTransXItemIn.Item group by tb2.Id) as tb3 "+
      "left join PreTransXItemOut on tb3.Id=PreTransXItemOut.Item group by tb3.Id) as tb4 "+
     "left join ItemXPicture on tb4.Id=ItemXPicture.Item group by tb4.Id) as tb5 "+
    "left join ItemXCategory on tb5.Id=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb5.Id"+
				LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+LQ_OrderBy+Limit;
  }while(false);
  
  if(Query==null){return;}
  if(PDatabase.queryToTableWithSum(IFV.Stm, Query, TableItemMdl, SumColumn, SumResult, false, true, TempList, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil data dari database !");
  }
  OrderTotalPrice_Tbl=SumResult[27];
  updateQueryCount();
  updateQueryTempListCount();
  refreshCheckerInfo();
 }
 void clearTable(){
  TableItemMdl.removeAll();
  onTableSelectedRowChanged(true);
  
  OrderTotalPrice_Tbl=0;
  refreshCheckerInfo();
  
  updateQueryCount();
  updateQueryTempListCount();
 }
 void updateQueryTempListCount(){TF_QueryTempListCount.setText("( "+PText.intToString(TableItemMdl.getCheckedCount())+" )");}
 void fillSignItems(long[] Items, boolean SignValue){
  TableItemMdl.check(Items, SignValue, 0);
  updateQueryTempListCount();
 }
 void clearSignItems(){
  TableItemMdl.checkAll(false);
  updateQueryTempListCount();
 }
 void setCatQueryTypeNewState(){
  // set new state of CatQueryType
  LastSelectedCatQueryType=CmB_CatQueryType.getSelectedIndex();
  switch(LastSelectedCatQueryType){
   case 0 : CatQueryWithCheck=true; break;
   case 1 : CatQueryWithCheck=false; CatQueryWithoutCheckByTempList=true; break;
   case 2 : CatQueryWithCheck=false; CatQueryWithoutCheckByTempList=false; break;
   default : CatQueryWithCheck=true; break;
  }
  updateCategoryCount();
 }
 void updateCatQueryType(){
  // clearing current CatQueryType's components state
  ListMdlCat.removeAll(); LastSelectedRowCat=-1;
  updateCategoryCount(); if(CatQueryWithCheck){updateCategoryCheckedCount();}
  
  setCatQueryTypeNewState();
 }
 void updateCategoryCount(){TF_CategoryCount.setText(PText.intToString(ListMdlCat.getSize()));}
 String genQueryCat(boolean TempListMode, boolean ByTempList, boolean WithCategoryName){
  String ret=null;
  boolean buildquery;
  StringBuilder sourcetable;
  StringBuilder con;
  long[] tlist;
  
  buildquery=true;
  sourcetable=new StringBuilder(); con=new StringBuilder();
  do{
   if(!TempListMode){break;}
   if(TempList.ElementsCount==0){
    if(ByTempList){buildquery=false;}
    break;
   }
   tlist=TempList.getElements();
   /*
   sourcetable.append(", "+
    "(select CategoryOfItem from ItemXCategory, "+
     "(select Id from Item where Id "+PText.getString(CatQueryWithoutCheckByTempList, "in", "not in")+" ("+PText.toString(tlist, 0, tlist.length, ",")+")) as ItemList "+
    "where ItemList.Id=ItemXCategory.Item group by CategoryOfItem) as Cat_ItemList");
   
   con.append(" where CategoryOfItem.Id=Cat_ItemList.CategoryOfItem");
   */
   sourcetable.append(" "+
    "left join "+
     "(select CategoryOfItem from ItemXCategory where Item in ("+PText.toString(tlist, 0, tlist.length, ",")+") group by CategoryOfItem) as Cat_ItemList "+
    "on CategoryOfItem.Id=Cat_ItemList.CategoryOfItem");
   
   con.append(" where Cat_ItemList.CategoryOfItem "+PText.getString(ByTempList, "is not", "is")+" "+CCore.vNull);
  }while(false);
  
  if(buildquery){
   ret=
    "select Id"+PText.getString(WithCategoryName, ", Name", "")+" from CategoryOfItem"+sourcetable.toString()+con.toString()+
    PText.getString(WithCategoryName, " order by Name asc", "");
  }
  
  return ret;
 }
 void fillListModelCategory(int FillMode){
  // FillMode : 1 check FirstTime, 2 check QueryType, ? otherwise fill anyway
  switch(FillMode){
   case 1  : if(ListMdlCatFilled){return;} break;
   case 2  :
    if(CmB_CatQueryType.getSelectedIndex()==LastSelectedCatQueryType){return;}
    updateCatQueryType(); break;
  }
  
  clearListModelCategory(true);
  fillQueryToCategory();
  
  ListMdlCatFilled=true;
 }
 void fillQueryToCategory(){
  String Query;
  
  Query=genQueryCat(!CatQueryWithCheck, CatQueryWithoutCheckByTempList, true);
  if(Query==null){return;}
  
  if(PDatabase.queryToList(IFV.Stm, Query, ListMdlCat, false, null, -1, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Terjadi error dalam proses mengambil Kategori Barang dari database !");
  }
  updateCategoryCount();
  if(CatQueryWithCheck){fillSignCategories(TempList.getElements(), true, true);}
 }
 void clearListModelCategory(boolean ClearAnyway){
  if(!ListMdlCatFilled && !ClearAnyway){return;}
  
  ListMdlCat.removeAll(); LastSelectedRowCat=-1;
  updateCategoryCount(); updateCategoryCheckedCount();
  
  ListMdlCatFilled=false;
 }
 void updateCategoryCheckedCount(){TF_CategoryCheckedCount.setText("( "+PText.intToString(ListMdlCat.getCheckedCount())+" )");}
 void fillSignCategories(long[] AffectedData, boolean TempListIsAdd, boolean FillAnyway){
  String Query=null;
  long[] ids;
  int[] index;
  Vector<Object[]> data;
  int temp, length;
  Object[] Objs;
		int insert_index;
  String query_cat;
  boolean SignValue;
  int query_type=0;
  
  if(!ListMdlCatFilled && !FillAnyway){return;}
  
  SignValue=(Boolean)PCore.subtituteBool(CatQueryWithCheck, TempListIsAdd, (CatQueryWithoutCheckByTempList && TempListIsAdd) || (!CatQueryWithoutCheckByTempList && !TempListIsAdd));
  
  if(AffectedData.length==0 || (!SignValue && ListMdlCat.Mdl.Rows.size()==0)){return;}
  
  if(!SignValue){query_type=3;}
  else{
   if(!CatQueryWithCheck && !CatQueryWithoutCheckByTempList){query_type=1;}
   else{query_type=2;}
  }
  
  if(query_type==1){Query=genQueryCat(true, (Boolean)PCore.subtituteBool(CatQueryWithCheck, true, CatQueryWithoutCheckByTempList), false);}
  else{
   Query="select CategoryOfItem from ItemXCategory where Item in ("+PText.toString(AffectedData, 0, AffectedData.length, ",")+") group by CategoryOfItem";
   if(query_type==3){
    query_cat=genQueryCat(true, (Boolean)PCore.subtituteBool(CatQueryWithCheck, true, CatQueryWithoutCheckByTempList), false);
    if(query_cat!=null){
     Query=
      // columns in source tables
      "select tb1.CategoryOfItem from "+
        // source tables : comes from join operation between tables
          "("+Query+") as tb1 "+
        "left join "+
          "("+query_cat+") as tb2 "+
        "on tb1.CategoryOfItem=tb2.Id "+
      // conditions
      "where tb2.Id is "+CCore.vNull;
    }
   }
  }

  ids=PCore.primArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm, Query, CCore.TypeLong, false, null));
  if(ids==null){
   JOptionPane.showMessageDialog(null, "Terjadi error dalam proses mencentang kategori !");
   return;
  }

  if(ids.length==0){return;}
  
  if(CatQueryWithCheck){
   ListMdlCat.check(ids, SignValue, 0);
   updateCategoryCheckedCount();
   return;
  }
  
  if(SignValue){
   ids=PCore.subArr(ids, PGUI.inspectLong(ids, ListMdlCat, 0, false, false));
   if(ids.length==0){return;}
   data=new Vector();
   PDatabase.queryToRows(IFV.Stm, "select Id, Name from CategoryOfItem where Id in ("+
    PText.toString(ids, 0, ids.length, ",")+")", data, ListMdlCat.getColumnsType());
   length=data.size();
   if(length==0){return;}
   temp=0;
   do{
    Objs=data.elementAt(temp);
    ListMdlCat.insert(PGUI.findInsertPos(ListMdlCat, 1, (String)Objs[1], false, true, true), Objs);
    temp=temp+1;
   }while(temp!=length);
  }
  else{
   index=PGUI.inspectLong(ids, ListMdlCat, 0, true, true);
   if(index.length==0){return;}
   PCore.sort(index, index.length);
   ListMdlCat.remove(index);
  }
  if(LastSelectedRowCat!=-1){LastSelectedRowCat=-1;}
  updateCategoryCount();
 }
 void clearSignCategories(boolean ClearAnyway){
  if(!ListMdlCatFilled && !ClearAnyway){return;}
  
  if(CatQueryWithCheck){
   ListMdlCat.checkAll(false);
   updateCategoryCheckedCount();
   return;
  }
  
  ListMdlCat.removeAll(); LastSelectedRowCat=-1;
  updateCategoryCount();
  fillQueryToCategory();
 }
 void fillDet(long Id){
  OInfoItem InfoItem;
  
  if(Id==-1){clearDet(); return;}
  
  InfoItem=PMyShop.getItemInfo(IFV.Stm, Id, true);
  if(InfoItem==null){
   clearDet();
   JOptionPane.showMessageDialog(null, "Gagal mengambil keterangan barang dari database !");
   return;
  }
  
  fillDetComponents(Id, InfoItem);
  IIDet=true; IIDetClear=false; IIEmptyAll=false;
 }
 void fillDetComponents(long Id, OInfoItem InfoItem){
  StringBuilder strb;
  boolean first;
  
  DetItem=InfoItem;
  
  CB_DetIsActive.setSelected(InfoItem.IsActive);
  TA_DetIdName.setText("("+PText.separate(String.valueOf(Id), " - ", 5)+")"+" "+InfoItem.Name);
  TA_DetComment.setText(PText.getString(InfoItem.Comment, "", false));
  
  TF_DetStock.setText(
   PText.priceToString(InfoItem.Stock)+" "+
   "( "+PText.priceToString(InfoItem.MinStock)+" - "+PText.priceToString(InfoItem.MaxStock)+" )"+
   PText.getString(InfoItem.StockUnit, -1, " "+InfoItem.StockUnitName, ""));
  CB_DetUpdateStock.setSelected(InfoItem.UpdateStock);
  
  CB_DetIsOpname.setSelected(InfoItem.IsOpname);
  
  TF_DetOrderSpec.setText(
   "Min "+PText.priceToString(InfoItem.OrderMinPack)+" Pak, "+
   "@ "+PText.priceToString(InfoItem.OrderEachPackQty)+PText.getString(InfoItem.StockUnitName, "", " "+InfoItem.StockUnitName, true)+
   " ( "+PText.priceToString(InfoItem.OrderEachPackThreshold)+" % )");
  CB_DetIsReorder.setSelected(InfoItem.IsReorder);
  
  strb=new StringBuilder();
  first=true;
  if(InfoItem.ExpireCheckPeriod!=-1){
   if(first){first=false;}else{strb.append(", ");}
   strb.append("Cek "+PDate.spellDaysCount(InfoItem.ExpireCheckPeriod, 1));
  }
  if(InfoItem.ExpireThreshold!=-1){
   if(first){first=false;}else{strb.append(", ");}
   strb.append("Batas "+PDate.spellDaysCount(InfoItem.ExpireThreshold, 1));
  }
  TF_DetExpire.setText(strb.toString());
  CB_DetExp.setSelected(InfoItem.HasExpireDate);
  
  fillDetSell();
  fillDetBuy();
 }
 void fillDetSell(){
  String str=null;
  if(DetItem!=null){
   if(CB_DetSell.isSelected()){
    switch(CmB_DetSell.getSelectedIndex()){
     case 0 : str=PText.getStringObj(DetItem.SellUpdate, "", "~ "+PText.dateToString(DetItem.SellUpdate, 2)+" ~\n", false)+PText.priceToString(DetItem.SellPrice)+PText.getString(DetItem.SellPriceComment, "", "\n"+"{ "+DetItem.SellPriceComment+" }", true); break;
     case 1 : str=PText.getStringObj(DetItem.SellUpdate, "", "~ "+PText.dateToString(DetItem.SellUpdate, 2)+" ~\n", false)+PText.priceToString(DetItem.SellPrice); break;
     case 2 : str=PText.getStringObj(DetItem.SellUpdate, "", "~ "+PText.dateToString(DetItem.SellUpdate, 2)+" ~\n", false)+PText.getString(DetItem.SellPriceComment, "", false); break;
    }
   }
   TA_DetSell.setText(PText.getString(str, "", false));
  }
 }
 void fillDetBuy(){
  String str=null;
  if(DetItem!=null){
   if(CB_DetBuy.isSelected()){
    switch(CmB_DetBuy.getSelectedIndex()){
     case 0 : str=PText.getStringObj(DetItem.BuyUpdate, "", "~ "+PText.dateToString(DetItem.BuyUpdate, 2)+" ~\n", false)+PText.priceToString(DetItem.BuyPriceEstimation)+PText.getString(DetItem.BuyPriceComment, "", "\n"+"{ "+DetItem.BuyPriceComment+" }", true); break;
     case 1 : str=PText.getStringObj(DetItem.BuyUpdate, "", "~ "+PText.dateToString(DetItem.BuyUpdate, 2)+" ~\n", false)+PText.priceToString(DetItem.BuyPriceEstimation); break;
     case 2 : str=PText.getStringObj(DetItem.BuyUpdate, "", "~ "+PText.dateToString(DetItem.BuyUpdate, 2)+" ~\n", false)+PText.getString(DetItem.BuyPriceComment, "", false); break;
    }
   }
   TA_DetBuy.setText(PText.getString(str, "", false));
  }
 }
 void clearDet(){
  if(IIDetClear==false){
   TA_DetIdName.setText("");
   CB_DetIsActive.setSelected(false);
   TA_DetComment.setText("");
   
   TF_DetStock.setText("");
   CB_DetUpdateStock.setSelected(false);
   
   CB_DetIsOpname.setSelected(false);
   
   TF_DetOrderSpec.setText("");
   CB_DetIsReorder.setSelected(false);
   
   TF_DetExpire.setText("");
   CB_DetExp.setSelected(false);
   
   TA_DetSell.setText("");
   TA_DetBuy.setText("");
   
   DetItem=null;
   
   IIDetClear=true;
  }
 }
 void fillEtc(long Id){
  boolean error;
  
  if(Id==-1){clearEtc(); return;}
  
  // clear list and list index, but not other components and index
  if(IIEtcClear==false){
   ListMdlItemCat.removeAll();
   ListMdlItemTag.removeAll();
  }
  
  // fetch list data
  error=true;
  do{
   
   if(PDatabase.queryToList(IFV.Stm,
    "select ItemXCategory.CategoryOfItem, CategoryOfItem.Name from ItemXCategory, CategoryOfItem where "+
    "ItemXCategory.Item="+Id+" and ItemXCategory.CategoryOfItem=CategoryOfItem.Id order by CategoryOfItem.Name asc;",
    ListMdlItemCat, false, null, -1, false, -1)==-1){break;}
   
   if(PDatabase.queryToList(IFV.Stm,
    "select ItemXTag.TagOfItem, TagOfItem.Name from ItemXTag, TagOfItem where "+
    "ItemXTag.Item="+Id+" and ItemXTag.TagOfItem=TagOfItem.Id order by TagOfItem.Name asc;",
    ListMdlItemTag, false, null, -1, false, -1)==-1){break;}
   
   error=false;
  }while(false);
  IIEtcClear=false;
  
  if(error==false){
   IIEtc=true; if(IIEmptyAll==true){IIEmptyAll=false;}
  }
  else{
   clearEtc();
   JOptionPane.showMessageDialog(null, "Gagal mengambil data-data dari database !");
  }
 }
 void clearEtc(){
  if(IIEtcClear==false){
   ListMdlItemCat.removeAll();
   ListMdlItemTag.removeAll();
   IIEtcClear=true;
  }
 }
 void fillPanelImage(String FileName){
  Panel_Image.setImageSource(IFV.Conf.ImageDirItem+FileName);
  PanelImageClear=false;
 }
 void fillPic(long Id){
  int datacount;
  // clear list and list index, but not other components and index
  if(IIPicClear==false){
   ListMdlItemPic.removeAll();
   LastSelectedRowPic=-1;
  }
  // fetch list data
  datacount=PDatabase.queryToList(IFV.Stm,
   "select ItemXPicture.FileName from ItemXPicture where "+
   "ItemXPicture.Item="+Id+" order by ItemXPicture.FileName asc;", ListMdlItemPic, false, null, -1, false, -1);
  IIPicClear=false;
  if(datacount!=-1){
   IIPic=true;
   if(IIEmptyAll==true){IIEmptyAll=false;}
   if(datacount>0){
    List_ItemPicture.setSelectedIndex(0);
    onListPicRowSelected(false);
   }
   else{
    clearPanelImage();
    Panel_Image.repaint();
   }
  }
  else{
   clearPic();
   Panel_Image.repaint();
   JOptionPane.showMessageDialog(null, "Gagal mengambil daftar gambar barang dari database !");
  }
 }
 void clearPanelImage(){
  if(PanelImageClear==false){
   // clear
   Panel_Image.setImageSource(null);
   PanelImageClear=true;
  }
 }
 void clearPic(){
  if(IIPicClear==false){
   ListMdlItemPic.removeAll();
   LastSelectedRowPic=-1;
   clearPanelImage();
   IIPicClear=true;
  }
 }
 void fillTrans(long Id){
  boolean success;
  
  clearTrans();
  
  do{
   success=fillTransIn(Id); if(!success){break;}
   success=fillTransOut(Id); if(!success){break;}
  }while(false);
  IITransClear=false;
  
  if(!success){
   clearTrans();
   JOptionPane.showMessageDialog(null, "Gagal mengambil daftar transaksi barang dari database !");
   return;
  }
  
  IITrans=true; IIEmptyAll=false;
 }
 void clearTrans(){
  if(IITransClear==true){return;}
  
  clearTransIn();
  clearTransOut();
  
  IITransClear=true;
 }
 String getQueryOfItemTrans(
  int Limit, boolean IsItemIn,
  long ItemId,
  boolean IsPreTrans, int TransType, long Subject){
  String ret=null;
  String QLimit, TblTransItem, TblTrans, OrderBy;
  StringBuilder Con_TblTransItem, Con_TblTrans;
  boolean confirst_TblTransItem, confirst_TblTrans;
  
  //
  QLimit=PText.getString(Limit, 0, " limit "+Limit, "");
  
  TblTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  TblTransItem=TblTrans+"XItem"+PText.getString(IsItemIn, "In", "Out");
  
  OrderBy=PText.getString(IsItemIn, QueryTransInOrderBy, QueryTransOutOrderBy);
  
  //
  Con_TblTransItem=new StringBuilder(); confirst_TblTransItem=true;
  
  if(confirst_TblTransItem){Con_TblTransItem.append(" where"); confirst_TblTransItem=false;}else{Con_TblTransItem.append(" and");}
  Con_TblTransItem.append(" Item="+ItemId);
  
  //
  Con_TblTrans=new StringBuilder(); confirst_TblTrans=true;
  
  if(TransType!=-1){
   if(confirst_TblTrans){Con_TblTrans.append(" where"); confirst_TblTrans=false;}else{Con_TblTrans.append(" and");}
   Con_TblTrans.append(" TransType="+TransType);
  }
  
  if(Subject!=-1){
   if(confirst_TblTrans){Con_TblTrans.append(" where"); confirst_TblTrans=false;}else{Con_TblTrans.append(" and");}
   Con_TblTrans.append(" (Subject="+Subject+" or Salesman="+Subject+")");
  }
  
  //
  ret=
   "select TransDate, TransTypeName, SubjectId, SubjectName, SalesmanId, SalesmanName, TransId, InfoIdExternal, "+
    "Qty, StockUnitName, PriceUnit, PriceTotal, TransItemComment, BuyPriceEstimation, PriceTotalBasic from "+
    "(select tb2d.*, StockUnit.Name as 'StockUnitName' from "+
     "(select tb2c.*, StockUnit as 'StockUnitId', BuyPriceEstimation, Qty*BuyPriceEstimation as 'PriceTotalBasic' from "+
      "(select tb2b.*, Subject.Name as 'SalesmanName' from "+
       "(select tb2a.*, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName' from "+
        "(select tb1.*, InfoIdExternal, TransDate, TransType as 'TransTypeId', Subject as 'SubjectId', Salesman as 'SalesmanId' from "+
         "(select "+TblTrans+" as 'TransId', Item as 'ItemId', Stock as 'Qty', Price/Stock as 'PriceUnit', Price as 'PriceTotal', Comment as 'TransItemComment' from "+TblTransItem+Con_TblTransItem.toString()+") as tb1 "+
        "inner join "+TblTrans+" on tb1.TransId="+TblTrans+".Id"+Con_TblTrans.toString()+") as tb2a "+
       "left join TransType on tb2a.TransTypeId=TransType.Id left join Subject on tb2a.SubjectId=Subject.Id) as tb2b "+
      "left join Subject on tb2b.SalesmanId=Subject.Id) as tb2c "+
     "inner join Item on tb2c.ItemId=Item.Id) as tb2d "+
    "left join StockUnit on tb2d.StockUnitId=StockUnit.Id) as tb2 "+
   OrderBy+QLimit;
  
  return ret;
 }
 boolean fillTransIn(long ItemId){
  boolean ret=false;
  boolean IsPreTrans;
  int TransType;
  long Subject;
  int datacount;
  
  IsPreTrans=RB_TransIsPreTransY.isSelected();
  TransType=PCore.objInteger(ComboMdlTransType.Mdl.Rows.elementAt(CmB_TransType.getSelectedIndex())[0], -1);
  Subject=PCore.objLong(ComboMdlTransSubject.Mdl.Rows.elementAt(CmB_TransSubject.getSelectedIndex())[0], -1L);
  
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, getQueryOfItemTrans(QueryTransLimit, true, ItemId, IsPreTrans, TransType, Subject),
    TableMdlTransIn, false, false, null, -1, false, -1);
   if(datacount==-1){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void clearTransIn(){
  TableMdlTransIn.removeAll();
  LastSelectedRowTransIn=-1;
  clearInfoTransIn();
 }
 void fillInfoTransIn(int RowIndex){
  Object[] Objs;
  
  if(RowIndex==-1){return;}
  
  //
  
  InfoTransInClear=false;
 }
 void clearInfoTransIn(){
  if(InfoTransInClear==true){return;}
  
  //
  
  InfoTransInClear=true;
 }
 boolean fillTransOut(long ItemId){
  boolean ret=false;
  boolean IsPreTrans;
  int TransType;
  long Subject;
  int datacount;
  
  IsPreTrans=RB_TransIsPreTransY.isSelected();
  TransType=PCore.objInteger(ComboMdlTransType.Mdl.Rows.elementAt(CmB_TransType.getSelectedIndex())[0], -1);
  Subject=PCore.objLong(ComboMdlTransSubject.Mdl.Rows.elementAt(CmB_TransSubject.getSelectedIndex())[0], -1L);
  
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, getQueryOfItemTrans(QueryTransLimit, false, ItemId, IsPreTrans, TransType, Subject),
    TableMdlTransOut, false, false, null, -1, false, -1);
   if(datacount==-1){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void clearTransOut(){
  TableMdlTransOut.removeAll();
  LastSelectedRowTransOut=-1;
  clearInfoTransOut();
 }
 void fillInfoTransOut(int RowIndex){
  Object[] Objs;
  
  if(RowIndex==-1){return;}
  
  //
  
  InfoTransOutClear=false;
 }
 void clearInfoTransOut(){
  if(InfoTransOutClear==true){return;}
  
  //
  
  InfoTransOutClear=true;
 }

 void fillAnActiveTab(int tab, long Id){
  switch(tab){
   case 2 : if(IIDet==false){fillDet(Id);} break; // tab det
   case 3 : if(IIEtc==false){fillEtc(Id);} break; // tab etc
   case 4 : if(IIPic==false){fillPic(Id);} break; // tab pic
   case 5 : if(IIVrs==false){fillVrs(Id);} break; // tab vrs
   case 6 : if(IISupp==false){fillSupp(Id);} break; // tab sup
   case 7 : if(IITrans==false){fillTrans(Id);} break; // tab trans
  }
 }
 void clearAnActiveTab(int tab){
  switch(tab){
   case 2 : clearDet(); break; // tab det
   case 3 : clearEtc(); break; // tab etc
   case 4 : clearPic(); if(PanelImageClear==false){Panel_Image.repaint();} break; // tab pic
   case 5 : clearVrs(); break; // tab vrs
   case 6 : clearSupp(); break; // tab sup
   case 7 : clearTrans(); break; // tab trans
  }
 }
 
 void runQuery(){
  boolean input_valid, list_defined, confirst;
  String str1=null;
  String str2=null;
  boolean bool1, isempty1, isempty2, isconpost;
  long[] numbers, ids;
  Long lg1, lg2;
  Double dbl1, dbl2;
  Date dt1, dt2;
  VBoolean Con_Defined;
  StringBuilder StcCon;
  
  StringBuilder StcSourceTable;
  StringBuilder StcCondition;
  StringBuilder StcPostConditions;
  
  boolean query_defined;
  VBoolean stc_con_defined;
  VBoolean stc_conpost_defined;
  
  int WithTempList;
  
  // validating input
  input_valid=false;
  do{
   if(CB_QId.isSelected()){
    if(!PText.checkInput(TF_QId.getText(), false, CCore.CharsCount_Long(), 2, 0, 0, 0)){break;}
   }
   if(CB_QName.isSelected()){
    if(!PText.checkInput(TF_QName.getText(), false, 150, 0, 0, 0, 0)){break;}
   }
   if(CB_QComment.isSelected()){
    if(!PText.checkInput(TF_QComment.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_QStock.isSelected()){
    str1=TF_QStock1.getText(); str2=TF_QStock2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QOrderPack.isSelected()){
    str1=TF_QOrderPack1.getText(); str2=TF_QOrderPack2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_Deci(), 6, 6, 6, 6)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_Deci(), 6, 6, 6, 6)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QExpList.isSelected()){
    numbers=PText.parseNumbersToLong(TF_QExpList.getText());
    if(numbers==null){break;}
    if(numbers.length==0){break;}
    if(!PCore.betweenRange(numbers, 0, Integer.MAX_VALUE, false, false)){break;}
   }
   if(CB_QExpRange.isSelected()){
    str1=TF_QExpRange1.getText(); str2=TF_QExpRange2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_Int(), 2, 3, 0, 0)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_Int(), 2, 3, 0, 0)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QPrice.isSelected()){
    str1=TF_QPrice1.getText(); str2=TF_QPrice2.getText();
    isempty1=PText.isEmptyString(str1, true, true); dbl1=PText.parseDouble(str1, null, null, true, true, false, 0, 0); if(!isempty1 && dbl1==null){break;}
    isempty2=PText.isEmptyString(str2, true, true); dbl2=PText.parseDouble(str2, null, null, true, true, false, 0, 0); if(!isempty2 && dbl2==null){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QPriceUpdate.isSelected()){
    str1=TF_QPriceUpdate1.getText(); str2=TF_QPriceUpdate2.getText();
    isempty1=PText.isEmptyString(str1, true, true); dt1=PDate.parseDate(str1); if(!isempty1 && dt1==null){break;}
    isempty2=PText.isEmptyString(str2, true, true); dt2=PDate.parseDate(str2); if(!isempty2 && dt2==null){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QOrder.isSelected()){
    str1=TF_QOrder1.getText(); str2=TF_QOrder2.getText();
    isempty1=PText.isEmptyString(str1, true, true); dbl1=PText.parseDouble(str1, null, null, true, true, false, 0, 0); if(!isempty1 && dbl1==null){break;}
    isempty2=PText.isEmptyString(str2, true, true); dbl2=PText.parseDouble(str2, null, null, true, true, false, 0, 0); if(!isempty2 && dbl2==null){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QStockUnit.isSelected()){
    if(ListMdlQStockUnit.Mdl.Rows.size()==0 && !CB_QStockUnitEmpty.isSelected()){break;}
   }
   if(CB_QCat.isSelected()){
    if(ListMdlQCat.Mdl.Rows.size()==0 && !CB_QCatNon.isSelected()){break;}
   }
   if(CB_QTag.isSelected()){
    if(ListMdlQTag.Mdl.Rows.size()==0 && !CB_QTagNon.isSelected()){break;}
   }
   if(CB_QPic.isSelected()){
    if(ListMdlQPic.Mdl.Rows.size()==0 && !CB_QPicNon.isSelected()){break;}
   }
   if(CB_QSup.isSelected()){
    if(ListMdlQSup.Mdl.Rows.size()==0 && !CB_QSupNon.isSelected()){break;}
   }
   input_valid=true;
  }while(false);
  if(!input_valid){
   JOptionPane.showMessageDialog(null, "Tidak dapat mencari : masukan masih salah / belum lengkap !");
   return;
  }
  
  if(!IFV.canAccessGUI(3, true,
    (
    
      ( !IFV.PrivGUIShowBuyPrice && /* PrivGUI - Buy Price */
        ( (CB_QPrice.isSelected() && CmB_QPrice.getSelectedIndex()==1) || // Buy Price
          (CB_QComment.isSelected() && CmB_QComment.getSelectedIndex()==1) || // Buy Price Comment
          (CB_QOrder.isSelected() && CmB_QOrder.getSelectedIndex()==1) // Order Price
        )
      ) ||

      ( !IFV.PrivGUIShowItemSupplierList && CB_QSup.isSelected() ) /* PrivGUI - Item Supplier List */
    
    )==false
  )){return;}
  
  // build query
  query_defined=true;
  stc_con_defined=new VBoolean(false);
  stc_conpost_defined=new VBoolean(false);
  
  StcSourceTable=new StringBuilder();
  StcCondition=new StringBuilder();
  StcPostConditions=new StringBuilder();
  
  WithTempList=0;

  if(CB_QId.isSelected()){
   bool1=CmB_QId.getSelectedIndex()==0;
   
   StcSourceTable.append(", ("+
    PMyShop.getQueryOfFindItemIds(
     PText.getString(bool1, String.valueOf(Long.parseLong(TF_QId.getText())), TF_QId.getText()), !bool1, "Item.Id", null, true, null, false
    )+") as item_ids");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Item.Id=item_ids.Id");
  }

  if(CB_QName.isSelected()){
   StcSourceTable.append(", ("+
     "(select Id as 'ItemId' from Item where "+PSql.genCheckWord("Name", TF_QName.getText(), true, true)+") "+
     "union distinct "+
     "(select Item from ItemXVariant where "+PSql.genCheckWord("Variant", TF_QName.getText(), true, true)+" group by Item) "+
    ") as item_name");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Item.Id=item_name.ItemId");
  }

  if(CB_QComment.isSelected()){
   if(CmB_QComment.getSelectedIndex()==0){
    StcSourceTable.append(", ("+
      "(select Id as 'ItemId' from Item where "+PSql.genCheckWord("Comment", TF_QComment.getText(), true, true)+") "+
      "union distinct "+
      "(select Item from ItemXVariant where "+PSql.genCheckWord("Comment", TF_QComment.getText(), true, true)+") "+
     ") as item_comment");

    if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
    StcCondition.append(" Item.Id=item_comment.ItemId");
   }
   else{
    switch(CmB_QComment.getSelectedIndex()){
     case 1 : str1="Item.BuyPriceComment"; break;
     case 2 : str1="Item.SellPriceComment"; break;
    }
    if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
    StcCondition.append(" "+PSql.genCheckWord(str1, TF_QComment.getText(), true, true));
   }
  }

  if(CB_QCheck.isSelected()){
   switch(CmB_QCheck.getSelectedIndex()){
    case 0 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.UpdateStockOnTransaction="+CCore.vTrue+" and Item.IsOpname="+CCore.vTrue); break;
    case 1 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.UpdateStockOnTransaction="+CCore.vTrue); break;
    case 2 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.UpdateStockOnTransaction="+CCore.vTrue+" and Item.Stock<0"); break;
    case 3 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.HasExpireDate="+CCore.vTrue+" and Item.IsOpname="+CCore.vTrue); break;
    case 4 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.HasExpireDate="+CCore.vTrue); break;
    case 5 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameStock is "+CCore.vNull); break;
    case 6 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameStock is not "+CCore.vNull); break;
    case 7 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameStock is not "+CCore.vNull+" and ifnull(Item.OpnameStock, 0)<>0"); break;
    case 8 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameStock is not "+CCore.vNull+" and ifnull(Item.OpnameStock, 0)=0"); break;
    case 9 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameExpire is "+CCore.vNull); break;
    case 10 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameExpire is not "+CCore.vNull); break;
    case 11 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameExpire is not "+CCore.vNull+
      " and ifnull(Item.OpnameExpire, Date_Add(CurDate(), Interval 100000 Day))<=Date_Add(CurDate(), Interval ifnull(Item.ExpireThreshold, 100000) Day)"+
      " and Item.ExpireThreshold is not "+CCore.vNull); break;
    case 12 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OpnameExpire is not "+CCore.vNull+
      " and ifnull(Item.OpnameExpire, Date_Add(CurDate(), Interval 100000 Day))>Date_Add(CurDate(), Interval ifnull(Item.ExpireThreshold, 100000) Day)"+
      " and Item.ExpireThreshold is not "+CCore.vNull); break;
    case 13 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.IsActive="+CCore.vTrue+" and Item.UpdateStockOnTransaction="+CCore.vTrue+" and Item.IsReorder="+CCore.vTrue);
     
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" StockEst<MinimalStock"); break;
    case 14 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.IsActive="+CCore.vTrue+" and Item.UpdateStockOnTransaction="+CCore.vTrue+" and Item.IsReorder="+CCore.vTrue);
     
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" StockEst<MaximalStock"); break;
    case 15 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.IsActive="+CCore.vTrue+" and Item.UpdateStockOnTransaction="+CCore.vTrue);
     
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" StockEst<MinimalStock"); break;
    case 16 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.IsActive="+CCore.vTrue+" and Item.UpdateStockOnTransaction="+CCore.vTrue);
     
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" StockEst<MaximalStock"); break;
    case 17 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OrderQuantity is "+CCore.vNull); break;
    case 18 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OrderQuantity is not "+CCore.vNull); break;
    case 19 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OrderQuantity is not "+CCore.vNull+" and ifnull(Item.OrderQuantity,0)>0"); break;
    case 20 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.OrderQuantity is not "+CCore.vNull+" and ifnull(Item.OrderQuantity,0)=0"); break;
    case 21 :
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" OrderQuantity is not "+CCore.vNull+
      " and StockEst+ifnull(OrderQuantity,0)>=MinimalStock"+
      " and StockEst+ifnull(OrderQuantity,0)<=MaximalStock"); break;
    case 22 :
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" OrderQuantity is not "+CCore.vNull+
      " and StockEst+ifnull(OrderQuantity,0)<MinimalStock"); break;
    case 23 :
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" OrderQuantity is not "+CCore.vNull+
      " and StockEst+ifnull(OrderQuantity,0)>MaximalStock"); break;
    case 24 :
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.MinimalStock>Item.MaximalStock"); break;
    case 25 :
     StcSourceTable.append(", "+
      "(select Id from Item left join ItemXCategory on Item.Id=ItemXCategory.Item where ItemXCategory.Item is "+CCore.vNull+") as non_category");
     
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.Id=non_category.Id"); break;
    case 26 :
     StcSourceTable.append(", "+
      "(select Item, count(CategoryOfItem) as 'CategoryCount' from ItemXCategory group by Item having CategoryCount>1) as multi_categories");
     
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.Id=multi_categories.Item"); break;
    case 27 :
     StcSourceTable.append(", "+"(select Item from ItemXSecondaryId group by Item) as item_has_sec_ids");
     
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.Id=item_has_sec_ids.Item"); break;
    case 28 :
     StcSourceTable.append(", "+"(select Item from ItemXVariant group by Item) as item_has_varts");
     
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.Id=item_has_varts.Item"); break;
    case 29 :
     StcSourceTable.append(", "+
      "("+
       "select Item.Id from Item "+
       "left join (select Item from ItemXVariant group by Item) as item_has_varts on Item.Id=item_has_varts.Item "+
       "where item_has_varts.Item is "+CCore.vNull+
      ") as item_non_varts");
     
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.Id=item_non_varts.Id"); break;
    case 30 :
     StcSourceTable.append(", "+
      "(select prim_sec_ids.PrimaryId from "+
       "(select Item.Id as 'PrimaryId', ItemXSecondaryId.SecondaryId from Item left join ItemXSecondaryId on Item.Id=ItemXSecondaryId.Item) as prim_sec_ids, "+
       "(select ItemId, count(*) as 'ItemIdCount' from ("+PMyShop.getQueryOfItemIds(true, false, true)+
        ") as tb_ids group by ItemId having ItemIdCount>1) as dup_ids "+
      "where prim_sec_ids.PrimaryId=dup_ids.ItemId or prim_sec_ids.SecondaryId=dup_ids.ItemId "+
      "group by prim_sec_ids.PrimaryId) as duplicate_ids"
     );
     
     if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
     StcCondition.append(" Item.Id=duplicate_ids.PrimaryId"); break;
    case 31 :
     ids=PMyShop.getItemsNonCompatibleToSupportedBarcodes(IFV.Stm);
     
     do{
      if(ids==null){query_defined=false; break;}
      if(ids.length==0){query_defined=false; break;}
      
      if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
      StcCondition.append(" Item.Id in ("+PText.toString(ids, 0, ids.length, ",")+")");
     }while(false); break;
   }
  }

  if(CB_QStock.isSelected()){
   isconpost=false;
   switch(CmB_QStock.getSelectedIndex()){
    case 0 : str1="Item.Stock"; break;
    case 1 : str1="ifnull(PreStockIn,0)"; isconpost=true; break;
    case 2 : str1="ifnull(PreStockOut,0)"; isconpost=true; break;
    case 3 : str1="StockEst"; isconpost=true; break;
    case 4 : str1="Item.MinimalStock"; break;
    case 5 : str1="Item.MaximalStock"; break;
   }
   dbl1=PText.parseDouble(TF_QStock1.getText(), null, null); dbl2=PText.parseDouble(TF_QStock2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostConditions);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCon.append(")");
  }

  if(CB_QOrderPack.isSelected()){
   isconpost=false;
   switch(CmB_QOrderPack.getSelectedIndex()){
    case 0 : str1="Item.OrderEachPackQty"; break;
    case 1 : str1="Item.OrderEachPackThreshold"; break;
    case 2 : str1="Item.OrderMinPack"; break;
   }
   dbl1=PText.parseDouble(TF_QOrderPack1.getText(), null, null); dbl2=PText.parseDouble(TF_QOrderPack2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostConditions);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCon.append(")");
  }

  if(CB_QPrice.isSelected()){
   isconpost=false;
   switch(CmB_QPrice.getSelectedIndex()){
    case 0 : str1="Item.SellPrice"; break;
    case 1 : str1="Item.BuyPriceEstimation"; break;
   }
   dbl1=PText.parseDouble(TF_QPrice1.getText(), null, null); dbl2=PText.parseDouble(TF_QPrice2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostConditions);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCon.append(")");
  }

  if(CB_QExpList.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   switch(CmB_QExpList.getSelectedIndex()){
    case 0 : str1="ifnull(Item.ExpireCheckPeriod,0)"; break;
    case 1 : str1="ifnull(Item.ExpireThreshold,0)"; break;
   }
   numbers=PText.parseNumbersToLong(TF_QExpList.getText());
   StcCondition.append(" "+str1+" in ("+PText.toString(numbers, 0, numbers.length, ",")+")");
  }

  if(CB_QExpRange.isSelected()){
   isconpost=false;
   switch(CmB_QExpRange.getSelectedIndex()){
    case 0 : str1="ifnull(Item.ExpireCheckPeriod,0)"; break;
    case 1 : str1="ifnull(Item.ExpireThreshold,0)"; break;
   }
   lg1=PText.parseLong(TF_QExpRange1.getText(), null, null); lg2=PText.parseLong(TF_QExpRange2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostConditions);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(lg1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PMath.getMinMaxLong(lg1, lg2, true));
   }
   if(lg2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PMath.getMinMaxLong(lg1, lg2, false));
   }
   StcCon.append(")");
  }
  
  if(CB_QPriceUpdate.isSelected()){
   isconpost=false;
   switch(CmB_QPriceUpdate.getSelectedIndex()){
    case 0 : str1="Item.SellUpdate"; break;
    case 1 : str1="Item.BuyUpdate"; break;
   }
   dt1=PDate.parseDate(TF_QPriceUpdate1.getText()); dt2=PDate.parseDate(TF_QPriceUpdate2.getText());
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostConditions);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   StcCon.append(")");
  }

  if(CB_QOrder.isSelected()){
   isconpost=false;
   switch(CmB_QOrder.getSelectedIndex()){
    case 0 : str1="ifnull(Item.OrderQuantity,0)"; str2=" and Item.OrderQuantity is not "+CCore.vNull; break;
    case 1 : str1="ifnull(OrderPriceEstimation,0)"; str2=" and OrderQuantity is not "+CCore.vNull; isconpost=true; break;
   }
   dbl1=PText.parseDouble(TF_QOrder1.getText(), null, null); dbl2=PText.parseDouble(TF_QOrder2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostConditions);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCon.append(str2);
   StcCon.append(")");
  }
  
  if(CB_QStockUnit.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" (");
   list_defined=false;
   if(ListMdlQStockUnit.Mdl.Rows.size()!=0){
    StcCondition.append(" Item.StockUnit in ("+PGUI.getElementList(ListMdlQStockUnit.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QStockUnitEmpty.isSelected()){
    if(list_defined){StcCondition.append(" or");} StcCondition.append(" Item.StockUnit is "+CCore.vNull);
   }
   StcCondition.append(")");
  }

  if(CB_QCat.isSelected()){
   StcSourceTable.append(", (select Id from Item left join ItemXCategory on Item.Id=ItemXCategory.Item where");
   list_defined=false;
   if(ListMdlQCat.getSize()!=0){
    StcSourceTable.append(" CategoryOfItem in ("+PGUI.getElementList(ListMdlQCat.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QCatNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" ItemXCategory.Item is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as cat");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Item.Id=cat.Id");
  }

  if(CB_QTag.isSelected()){
   StcSourceTable.append(", (select Id from Item left join ItemXTag on Item.Id=ItemXTag.Item where");
   list_defined=false;
   if(ListMdlQTag.getSize()!=0){
    StcSourceTable.append(" TagOfItem in ("+PGUI.getElementList(ListMdlQTag.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QTagNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" ItemXTag.Item is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as tag");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Item.Id=tag.Id");
  }

  if(CB_QPic.isSelected()){
   //
   StcSourceTable.append(", (");
   
   StcSourceTable.append("(select Id from Item left join ItemXPicture on Item.Id=ItemXPicture.Item where");
   list_defined=false;
   if(ListMdlQPic.getSize()!=0){
    StcSourceTable.append(" FileName in ("+PGUI.getElementList(ListMdlQPic.Mdl.Rows, 0, ",", "'", true)+")"); list_defined=true;
   }
   if(CB_QPicNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" ItemXPicture.Item is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) ");
   
   StcSourceTable.append("union distinct ");
   
   StcSourceTable.append("(select Item from ItemXVariant where");
   list_defined=false;
   if(ListMdlQPic.getSize()!=0){
    StcSourceTable.append(" PictureFile in ("+PGUI.getElementList(ListMdlQPic.Mdl.Rows, 0, ",", "'", true)+")"); list_defined=true;
   }
   if(CB_QPicNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" PictureFile is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Item) ");
   
   StcSourceTable.append(") as pic");

   //
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Item.Id=pic.Id");
  }

  if(CB_QSup.isSelected()){
   StcSourceTable.append(", (select Id from Item left join ItemXSupplier on Item.Id=ItemXSupplier.Item where");
   list_defined=false;
   if(ListMdlQSup.getSize()!=0){
    StcSourceTable.append(" Supplier in ("+PGUI.getElementList(ListMdlQSup.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QSupNon.isSelected()){
    if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" ItemXSupplier.Item is "+CCore.vNull);
   }
   StcSourceTable.append(" group by Id) as sup");

   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Item.Id=sup.Id");
  }
  
  if(query_defined){
   setLastQuery(1, CApp.FormQueryLimit,
    StcSourceTable.toString(), StcCondition.toString(), stc_con_defined.Value, StcPostConditions.toString(), stc_conpost_defined.Value,
    WithTempList, true);
  }
  else{
   clearLastQuery();
  }
  fillTable();
 }
 void findItemInTable(int Mode){
  int Selected, FindIndex;
  int Column;
  int ColumnType;
  String str=TF_Find.getText();
  if(str.length()!=0){
   if(TableItemMdl.Mdl.Rows.size()!=0){
    switch(CmB_Find.getSelectedIndex()){
     case 1 : Column=1; break;
     case 2 : Column=32; break;
     case 3 : Column=22; break;
     case 4 : Column=19; break;
     default : Column=0; break;
    }
    ColumnType=TableItemMdl.Mdl.ColumnsType[Column];
    Selected=Tbl_Item.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableItemMdl, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_Item.changeSelection(FindIndex, 0, false, false);
      onTableSelectedRowChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !");
   }
  }
 }
 void findCategoryInList(int Mode){
  int Selected, FindIndex;
  String str=TF_FindCategory.getText();
  if(str.length()!=0){
   if(ListMdlCat.Mdl.Rows.size()!=0){
    Selected=List_Category.getSelectedIndex();
    FindIndex=PGUI.searchInlist(ListMdlCat, str, Selected, Mode);
    if(FindIndex!=-1){
     if(FindIndex!=Selected){
      List_Category.setSelectedIndex(FindIndex);
      List_Category.ensureIndexIsVisible(FindIndex);
      onListCategoryRowSelected(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di daftar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Daftar dalam keadaan kosong !");
   }
  }
 }
 void findTransIn(int Mode){
  int Selected, FindIndex;
  int Column;
  int ColumnType;
  String str=TF_TransInFind.getText();
  if(str.length()!=0){
   if(TableMdlTransIn.Mdl.Rows.size()!=0){
    switch(CmB_TransInFind.getSelectedIndex()){
     case 1 : Column=3; break;
     case 2 : Column=5; break;
     case 3 : Column=6; break;
     case 4 : Column=7; break;
     case 5 : Column=12; break;
     default : Column=1; break;
    }
    ColumnType=TableMdlTransIn.Mdl.ColumnsType[Column];
    Selected=Tbl_TransIn.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlTransIn, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_TransIn.changeSelection(FindIndex, 0, false, false);
      onTableTransInSelectedRowChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang masuk !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang masuk dalam keadaan kosong !");
   }
  }
 }
 void findTransOut(int Mode){
  int Selected, FindIndex;
  int Column;
  int ColumnType;
  String str=TF_TransOutFind.getText();
  if(str.length()!=0){
   if(TableMdlTransOut.Mdl.Rows.size()!=0){
    switch(CmB_TransOutFind.getSelectedIndex()){
     case 1 : Column=3; break;
     case 2 : Column=5; break;
     case 3 : Column=6; break;
     case 4 : Column=7; break;
     case 5 : Column=12; break;
     default : Column=1; break;
    }
    ColumnType=TableMdlTransOut.Mdl.ColumnsType[Column];
    Selected=Tbl_TransOut.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlTransOut, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_TransOut.changeSelection(FindIndex, 0, false, false);
      onTableTransOutSelectedRowChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang keluar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang keluar dalam keadaan kosong !");
   }
  }
 }
 void printReport(){
  int temp, temp_;
  LinkedList<Long> Id;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  boolean CategorizedPrinting;
		F_PrintItemReport fm=IFV.FPrintItemReport;
  do{
   temp=TableItemMdl.Mdl.Rows.size();
   if(temp==0){break;}
			
			
			if(fm.showForm()==false){return;}
			if(fm.DialogResult!=1){return;}
   
   IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
   IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
   IFV.FPrintDialog.wPrintSettingMode=2;
			IFV.FPrintDialog.wEnableOption=true;
			IFV.FPrintDialog.wEnableColumnar=true;
			IFV.FPrintDialog.wMaxColumnarCount=3;
			IFV.FPrintDialog.wColumnarCount=2;
   IFV.FPrintDialog.wEnableSimplePrint=false;
   IFV.FPrintDialog.wEnableAllowRedundant=true;
   IFV.FPrintDialog.wAllowRedundant=false;
   IFV.FPrintDialog.wEnablePrintResultPresentation=true;
   IFV.FPrintDialog.wNormalPrintingText="Urut abjad";
   IFV.FPrintDialog.wCategorizedPrintingText="Organisasikan berdasar kategori, lalu urut abjad";
   IFV.FPrintDialog.wPrintResultPresentation=2;
   IFV.FPrintDialog.wEnablePagination=true;
   IFV.FPrintDialog.wPagination=false;
   
   if(IFV.FPrintDialog.showForm()==false){return;}
   if(IFV.FPrintDialog.DialogResult!=1){break;}
   PaperType=IFV.FPrintDialog.PaperType;
   Printer=IFV.FPrintDialog.Printer;
   CategorizedPrinting=(IFV.FPrintDialog.PrintResultPresentation!=1);
   
   TempRows=TableItemMdl.Mdl.Rows;
   Id=new LinkedList();
   temp_=0;
   do{
    Id.addLast((Long)TempRows.elementAt(temp_)[0]);
    temp_=temp_+1;
   }while(temp_!=temp);

   IFV.PrintGenItem.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Id, CategorizedPrinting, IFV.FPrintDialog.Pagination,
				IFV.FPrintDialog.ColumnarCount, IFV.FPrintDialog.AllowRedundant, (IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice),
				fm.OptVariants, true, !fm.OptVariantsOnlyActive, false,
    false, fm.OptStock, fm.OptStockPre, fm.OptStockEst, fm.OptStockMinMax, false, false, fm.OptOrderMinPack, fm.OptOrderEachPackQty, fm.OptOrderEachPackThreshold,
    false, fm.OptExpCheckPeriod, fm.OptExpThreshold, fm.OptExpThresholdDate,
    fm.OptSellPrice, fm.OptSellComment, fm.OptSellUpdate, fm.OptBuyPriceEst, fm.OptBuyComment, fm.OptBuyUpdate,
    fm.OptComment,
    fm.OptOpnameStock, fm.OptOpnameExp,
    fm.OptOrderQty, fm.OptOrderPriceEst);
   IFV.FSplashScreen.appear(this, "Membuat Data Print");
   bk=IFV.PrintGenItem.generateBook(IFV.FSplashScreen);
   IFV.FSplashScreen.disappear();
   if(bk==null){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
    break;
   }
   
   if(IFV.FPrintDialog.ChoosePage){
    IFV.FPrintPage.wBook=bk;
    
    if(IFV.FPrintPage.showForm()==false){return;}
    if(IFV.FPrintPage.DialogResult!=1){break;}
    if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
   }

   if(!PPrint.print(bk, Printer, "LapBrg_"+PText.dateToString(new Date(), 101), false)){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
    break;
   }
  }while(false);
 }
 void printCheckList(){
  int temp, temp_;
  LinkedList<Long> Id;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  
  F_PrintItemReport fm;
  
  temp=TableItemMdl.Mdl.Rows.size();
  if(temp==0){return;}

  fm=IFV.FPrintItemReport;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
  IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
  IFV.FPrintDialog.wPrintSettingMode=2;
		IFV.FPrintDialog.wEnableOption=true;
		IFV.FPrintDialog.wEnableColumnar=true;
		IFV.FPrintDialog.wMaxColumnarCount=2;
		IFV.FPrintDialog.wColumnarCount=2;
		IFV.FPrintDialog.wEnableSimplePrint=false;
  IFV.FPrintDialog.wEnableAllowRedundant=false;
  IFV.FPrintDialog.wEnablePrintResultPresentation=false;
  
  if(IFV.FPrintDialog.showForm()==false){return;}
  if(IFV.FPrintDialog.DialogResult!=1){return;}
  PaperType=IFV.FPrintDialog.PaperType;
  Printer=IFV.FPrintDialog.Printer;

  TempRows=TableItemMdl.Mdl.Rows;
  Id=new LinkedList();
  temp_=0;
  do{
   Id.addLast((Long)TempRows.elementAt(temp_)[0]);
   temp_=temp_+1;
  }while(temp_!=temp);
  
  IFV.PrintGenItemCheckList.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Id, IFV.FPrintDialog.ColumnarCount, (IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice),
				fm.OptVariants, true, !fm.OptVariantsOnlyActive, false,
    false, fm.OptStock, fm.OptStockPre, fm.OptStockEst, fm.OptStockMinMax, false, false, fm.OptOrderMinPack, fm.OptOrderEachPackQty, fm.OptOrderEachPackThreshold,
    false, fm.OptExpCheckPeriod, fm.OptExpThreshold, fm.OptExpThresholdDate,
    fm.OptSellPrice, fm.OptSellComment, fm.OptSellUpdate, fm.OptBuyPriceEst, fm.OptBuyComment, fm.OptBuyUpdate,
    fm.OptComment,
    fm.OptOpnameStock, fm.OptOpnameExp,
    fm.OptOrderQty, fm.OptOrderPriceEst);
  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  bk=IFV.PrintGenItemCheckList.generateBook(IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  if(bk==null){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
   return;
  }

  if(IFV.FPrintDialog.ChoosePage){
   IFV.FPrintPage.wBook=bk;
   
   if(IFV.FPrintPage.showForm()==false){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
  }

  if(!PPrint.print(bk, Printer, "ChkListBrg_"+PText.dateToString(new Date(), 101), false)){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
   return;
  }
 }
 void printCatalog(){
  int temp, temp_;
  LinkedList<Long> Id;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  boolean CategorizedPrinting;
  do{
   temp=TableItemMdl.Mdl.Rows.size();
   if(temp==0){break;}
   
   IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
   IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
   IFV.FPrintDialog.wPrintSettingMode=2;
			IFV.FPrintDialog.wEnableOption=true;
			IFV.FPrintDialog.wEnableColumnar=false;
   IFV.FPrintDialog.wEnableSimplePrint=false;
   IFV.FPrintDialog.wEnableAllowRedundant=true;
   IFV.FPrintDialog.wAllowRedundant=false;
   IFV.FPrintDialog.wEnablePrintResultPresentation=true;
   IFV.FPrintDialog.wNormalPrintingText="Urut abjad";
   IFV.FPrintDialog.wCategorizedPrintingText="Organisasikan berdasar kategori, lalu urut abjad";
   IFV.FPrintDialog.wPrintResultPresentation=2;
   IFV.FPrintDialog.wEnablePagination=true;
   IFV.FPrintDialog.wPagination=false;
   
   if(IFV.FPrintDialog.showForm()==false){return;}
   if(IFV.FPrintDialog.DialogResult!=1){break;}
   PaperType=IFV.FPrintDialog.PaperType;
   Printer=IFV.FPrintDialog.Printer;
   CategorizedPrinting=(IFV.FPrintDialog.PrintResultPresentation!=1);
   
   TempRows=TableItemMdl.Mdl.Rows;
   Id=new LinkedList();
   temp_=0;
   do{
    Id.addLast((Long)TempRows.elementAt(temp_)[0]);
    temp_=temp_+1;
   }while(temp_!=temp);

   IFV.PrintGenItemCatalog.setPrintVariables(PaperType, IFV.FontPrint,
    IFV.Stm, Id, IFV.Conf.ImageDirItem, CategorizedPrinting, IFV.FPrintDialog.Pagination, IFV.FPrintDialog.AllowRedundant);
   IFV.FSplashScreen.appear(this, "Membuat Data Print");
   bk=IFV.PrintGenItemCatalog.generateBook(IFV.FSplashScreen);
   IFV.FSplashScreen.disappear();
   if(bk==null){
    JOptionPane.showMessageDialog(null,
     "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !"+
     "\nMungkin karena tidak ada data gambar pd barang-barang yg akan dicetak.");
    break;
   }
   
   if(IFV.FPrintDialog.ChoosePage){
    IFV.FPrintPage.wBook=bk;
    
    if(IFV.FPrintPage.showForm()==false){return;}
    if(IFV.FPrintPage.DialogResult!=1){break;}
    if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
   }

   if(!PPrint.print(bk, Printer, "KtlgBrg_"+PText.dateToString(new Date(), 101), false)){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
    break;
   }
  }while(false);
 }
 void printOrder(){
  int temp, temp_;
  LinkedList<Long> Id;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  do{
   temp=TableItemMdl.Mdl.Rows.size();
   if(temp==0){break;}
   
   IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
   IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
   IFV.FPrintDialog.wPrintSettingMode=2;
   IFV.FPrintDialog.wEnableOption=false;
   
   if(IFV.FPrintDialog.showForm()==false){return;}
   if(IFV.FPrintDialog.DialogResult!=1){break;}
   PaperType=IFV.FPrintDialog.PaperType;
   Printer=IFV.FPrintDialog.Printer;
   
   TempRows=TableItemMdl.Mdl.Rows;
   Id=new LinkedList();
   temp_=0;
   do{
    Id.addLast((Long)TempRows.elementAt(temp_)[0]);
    temp_=temp_+1;
   }while(temp_!=temp);

   IFV.PrintGenItemOrder.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Id, (IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice),
    false, true, false);
   IFV.FSplashScreen.appear(this, "Membuat Data Print");
   bk=IFV.PrintGenItemOrder.generateBook(IFV.FSplashScreen);
   IFV.FSplashScreen.disappear();
   if(bk==null){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
    break;
   }
   
   if(IFV.FPrintDialog.ChoosePage){
    IFV.FPrintPage.wBook=bk;
    
    if(IFV.FPrintPage.showForm()==false){return;}
    if(IFV.FPrintPage.DialogResult!=1){break;}
    if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
   }

   if(!PPrint.print(bk, Printer, "OrderBrg_"+PText.dateToString(new Date(), 101), false)){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
    break;
   }
  }while(false);
 }
 void printCSV(){
  F_PrintItemCSV fm1=IFV.FPrintItemCSV;
  F_CsvWriteOption fm2=IFV.FCsvWriteOption;
  File f;
  long OperationResult;
  long[] Ids;
  
  if(TableItemMdl.Mdl.Rows.size()==0){return;}
  
  if(fm1.showForm()==false){return;}
  if(fm1.DialogResult!=1){return;}
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm2.showForm()==false){return;}
  if(fm2.DialogResult!=1){return;}
  
  Ids=TableItemMdl.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableItemMdl.Mdl.Rows.size(), 0, 1));
  
  IFV.FSplashScreen.appear(this, "Print Data Ke File CSV");
  OperationResult=PMyShop.printItemCSV(
   IFV.FSplashScreen, IFV.Stm, f, fm2.FieldDelimiter, fm2.FieldsSeparator, CCore.CsvDefaultRecordsSeparator, Ids,
   
   fm1.OptDataCategorized, fm1.OptCategory, fm1.OptVariants, true, !fm1.OptVariantsOnlyActive, fm1.OptIsActive, fm1.OptComment, fm1.OptPictureFile,
   fm1.OptIsStockUpdated, fm1.OptStock, fm1.OptStockPre, fm1.OptStockEst, fm1.OptStockMinMax, fm1.OptStockUnit,
   fm1.OptIsOpname, fm1.OptIsReorder, fm1.OptOrderEachPackQty, fm1.OptOrderEachPackThreshold, fm1.OptOrderMinPack,
   fm1.OptIsExpire, fm1.OptExpCheckPeriod, fm1.OptExpThreshold, fm1.OptExpThresholdDate,
   fm1.OptSellPrice, fm1.OptSellComment, fm1.OptSellUpdate, fm1.OptBuyPriceEst, fm1.OptBuyComment, fm1.OptBuyUpdate,
   fm1.OptOpnameStock, fm1.OptOpnameExp, fm1.OptOrderQty, fm1.OptOrderPriceEst,
   fm1.OptListCategory, fm1.OptListTag, fm1.OptListSecondaryId, fm1.OptListVariant, true, !fm1.OptListVariantOnlyActive, fm1.OptListPicture, fm1.OptListSupplier,
   
   IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice, IFV.CurrentUserIsAdmin || IFV.PrivGUIShowItemSupplierList);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses print data ke file CSV !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Operasi berhasil !\n"+
   "Total data yg di-print ke file CSV = "+PText.intToString(OperationResult));
  */
 }
 int editItems(int[] Rows, boolean FetchDataOld, OInfoItem DataOld, OEditItem Edit, boolean WithSplashScreen){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Id has already exist
  long Id=0;
  OInfoItem InfoItem=null;
  boolean first, error, started, process;
  Object[] RowData, SumTblOld, SumTblNew, SumTempListOld, SumTempListNew;
  StringBuilder col;
  int result, Row, count, MaxList, curridx, currlistcount;
  String columns;
  Vector<OTableCellUpdater> Values, PostValues;
  OTableCellReference[] CellsRef;
  int[] CheckedRows;
  OCustomListModel ListMultiId=null;
  Vector<Object[]> list_elements;
  
  long[] ids;
  boolean op_query, op_multiid;
  double progress_inc=0;
  int progress_inc_times;
  boolean IsCheckWithOldValue;
  
  do{
   count=Rows.length;
   op_query=false;
   op_multiid=false;

   if(count==1){
    RowData=TableItemMdl.Mdl.Rows.elementAt(Rows[0]);
    Id=(Long)RowData[0];
    InfoItem=DataOld; if(InfoItem==null && FetchDataOld){InfoItem=PMyShop.getItemInfo(IFV.Stm, Id, false);}
   }
   IsCheckWithOldValue=(count==1 && InfoItem!=null);

   Values=new Vector(); PostValues=new Vector();
   col=new StringBuilder();
   first=true;

   if(Edit.EditId){
    process=true; if(IsCheckWithOldValue){process=Edit.EditedId!=Id;}
    if(process){
     if(Edit.IdSingleItem){
      result=PMyShop.checkExistIdOnItem(Edit.EditedId, IFV.Stm);
      if(result==-1){break;}
      if(result==1){ret=-2; break;}

      if(first){first=false;}else{col=col.append(',');}
      col=col.append("Id="+Edit.EditedId);
      Values.addElement(new OTableCellUpdaterByObject(0, Edit.EditedId));
      op_query=true;
     }
     else{
      ListMultiId=new OCustomListModel(false); ListMultiId.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeLong), 0);
      Values.addElement(new OTableCellUpdaterByList(0, PCore.primArr(0), ListMultiId, PCore.primArr(0), 1, false, null));
      op_multiid=true;
     }
    }
   }
   if(Edit.EditName){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubName){
     col.append("Name="+PText.getStringWithQuote(PSql.norm(Edit.EditedName), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedName, null, true)));
    }
    else{
     col.append("Name=replace(Name, '"+PSql.norm(Edit.SubName)+"', '"+PSql.norm(Edit.EditedName)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(1, true, Edit.SubName, Edit.EditedName));
    }
    op_query=true;
   }
   if(Edit.EditIsActive){
    if(first){first=false;}else{col.append(',');}
    col.append("IsActive="+PText.getString(Edit.EditedIsActive, CCore.vTrue, CCore.vFalse));
    Values.addElement(new OTableCellUpdaterByObject(2, Edit.EditedIsActive));
    op_query=true;
   }
   if(Edit.EditComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubComment){
     col.append("Comment="+PText.getStringWithQuote(PSql.norm(Edit.EditedComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(-1, PText.getString(Edit.EditedComment, null, true)));
    }
    else{
     col.append("Comment=replace(Comment, '"+PSql.norm(Edit.SubComment)+"', '"+PSql.norm(Edit.EditedComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(-1, true, Edit.SubComment, Edit.EditedComment));
    }
    op_query=true;
   }

   if(Edit.EditStockUnit){
    if(first){first=false;}else{col.append(',');}
    col.append("StockUnit="+PText.getString(Edit.EditedStockUnitId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(11, PCore.subtituteLong(Edit.EditedStockUnitId, -1, Edit.EditedStockUnitId, null)));
    Values.addElement(new OTableCellUpdaterByObject(12, PCore.subtituteLong(Edit.EditedStockUnitId, -1, Edit.EditedStockUnitName, null)));
    
    op_query=true;
   }
   process=true; if(IsCheckWithOldValue){process=Edit.EditedStock!=InfoItem.Stock;}
   if(Edit.EditStock && process){
    if(first){first=false;}else{col.append(',');}
    col.append("Stock="+PText.doubleToString(Edit.EditedStock, false));
    Values.addElement(new OTableCellUpdaterByObject(3, Edit.EditedStock));
    op_query=true;
   }
   process=true; if(IsCheckWithOldValue){process=Edit.EditedUpdateStock!=InfoItem.UpdateStock;}
   if(Edit.EditUpdateStock && process){
    if(first){first=false;}else{col.append(',');}
    col.append("UpdateStockOnTransaction="+PText.getString(Edit.EditedUpdateStock, CCore.vTrue, CCore.vFalse));
    Values.addElement(new OTableCellUpdaterByObject(13, Edit.EditedUpdateStock));
    op_query=true;
   }
   if(Edit.EditMinStock){
    if(first){first=false;}else{col.append(',');}
    col.append("MinimalStock="+PText.doubleToString(Edit.EditedMinStock, false));
    Values.addElement(new OTableCellUpdaterByObject(4, Edit.EditedMinStock));
    op_query=true;
   }
   if(Edit.EditMaxStock){
    if(first){first=false;}else{col.append(',');}
    col.append("MaximalStock="+PText.doubleToString(Edit.EditedMaxStock, false));
    Values.addElement(new OTableCellUpdaterByObject(5, Edit.EditedMaxStock));
    op_query=true;
   }

   if(Edit.EditIsOpname){
    if(first){first=false;}else{col.append(',');}
    col.append("IsOpname="+PText.getString(Edit.EditedIsOpname, CCore.vTrue, CCore.vFalse));
    Values.addElement(new OTableCellUpdaterByObject(9, Edit.EditedIsOpname));
    op_query=true;
   }
   if(Edit.EditIsReorder){
    if(first){first=false;}else{col.append(',');}
    col.append("IsReorder="+PText.getString(Edit.EditedIsReorder, CCore.vTrue, CCore.vFalse));
    Values.addElement(new OTableCellUpdaterByObject(10, Edit.EditedIsReorder));
    op_query=true;
   }
   if(Edit.EditOrderPackQty){
    if(first){first=false;}else{col.append(',');}
    col.append("OrderEachPackQty="+PText.doubleToString(Edit.EditedOrderPackQty, false));
    Values.addElement(new OTableCellUpdaterByObject(6, Edit.EditedOrderPackQty));
    op_query=true;
   }
   if(Edit.EditOrderPackThreshold){
    if(first){first=false;}else{col.append(',');}
    col.append("OrderEachPackThreshold="+PText.doubleToString(Edit.EditedOrderPackThreshold, false));
    Values.addElement(new OTableCellUpdaterByObject(7, Edit.EditedOrderPackThreshold));
    op_query=true;
   }
   if(Edit.EditOrderMinPack){
    if(first){first=false;}else{col.append(',');}
    col.append("OrderMinPack="+PText.doubleToString(Edit.EditedOrderMinPack, false));
    Values.addElement(new OTableCellUpdaterByObject(8, Edit.EditedOrderMinPack));
    op_query=true;
   }

   if(Edit.EditExp){
    if(first){first=false;}else{col.append(',');}
    col.append("HasExpireDate="+PText.getString(Edit.EditedExp, CCore.vTrue, CCore.vFalse));
    Values.addElement(new OTableCellUpdaterByObject(17, Edit.EditedExp));
    op_query=true;
   }
   if(Edit.EditExpCheckPeriod){
    if(first){first=false;}else{col.append(',');}
    col.append("ExpireCheckPeriod="+PText.getString(Edit.EditedExpCheckPeriod, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(14, PCore.subtituteLong(Edit.EditedExpCheckPeriod, -1, Edit.EditedExpCheckPeriod, null)));
    op_query=true;
   }
   if(Edit.EditExpThreshold){
    if(first){first=false;}else{col.append(',');}
    col.append("ExpireThreshold="+PText.getString(Edit.EditedExpThreshold, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(15, PCore.subtituteLong(Edit.EditedExpThreshold, -1, Edit.EditedExpThreshold, null)));
    Values.addElement(new OTableCellUpdaterByObject(16, PCore.subtituteLong(Edit.EditedExpThreshold, -1, PDate.calculateDateByDay(new Date(), Edit.EditedExpThreshold, 1), null)));
    op_query=true;
   }

   if(Edit.EditSellPrice){
    if(first){first=false;}else{col.append(',');}
    col.append("SellPrice="+PText.doubleToString(Edit.EditedSellPrice, false));
    Values.addElement(new OTableCellUpdaterByObject(18, Edit.EditedSellPrice));
    op_query=true;
   }
   if(Edit.EditSellComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubSellComment){
     col.append("SellPriceComment="+PText.getStringWithQuote(PSql.norm(Edit.EditedSellComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(19, PText.getString(Edit.EditedSellComment, null, true)));
    }
    else{
     col.append("SellPriceComment=replace(SellPriceComment, '"+PSql.norm(Edit.SubSellComment)+"', '"+PSql.norm(Edit.EditedSellComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(19, true, Edit.SubSellComment, Edit.EditedSellComment));
    }
    op_query=true;
   }
   if(Edit.EditSellUpdate){
    if(first){first=false;}else{col.append(',');}
    col.append("SellUpdate="+PDatabase.dateToSQLStringFormat(Edit.EditedSellUpdate));
    Values.addElement(new OTableCellUpdaterByObject(20, Edit.EditedSellUpdate));
    op_query=true;
   }
   if(Edit.EditBuyPrice){
    if(first){first=false;}else{col.append(',');}
    col.append("BuyPriceEstimation="+PText.doubleToString(Edit.EditedBuyPrice, false));
    Values.addElement(new OTableCellUpdaterByObject(21, Edit.EditedBuyPrice));
    
    op_query=true;
   }
   if(Edit.EditBuyComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubBuyComment){
     col.append("BuyPriceComment="+PText.getStringWithQuote(PSql.norm(Edit.EditedBuyComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(22, PText.getString(Edit.EditedBuyComment, null, true)));
    }
    else{
     col.append("BuyPriceComment=replace(BuyPriceComment, '"+PSql.norm(Edit.SubBuyComment)+"', '"+PSql.norm(Edit.EditedBuyComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(22, true, Edit.SubBuyComment, Edit.EditedBuyComment));
    }
    op_query=true;
   }
   if(Edit.EditBuyUpdate){
    if(first){first=false;}else{col.append(',');}
    col.append("BuyUpdate="+PDatabase.dateToSQLStringFormat(Edit.EditedBuyUpdate));
    Values.addElement(new OTableCellUpdaterByObject(23, Edit.EditedBuyUpdate));
    op_query=true;
   }

   if(Edit.EditOpStock){
    if(first){first=false;}else{col.append(',');}
    col.append("OpnameStock="+PText.getStringDouble2(Edit.EditedOpStock, CCore.vNull, false, false));
    Values.addElement(new OTableCellUpdaterByObject(24, Edit.EditedOpStock));
    op_query=true;
   }
   if(Edit.EditOpExp){
    if(first){first=false;}else{col.append(',');}
    col.append("OpnameExpire="+PDatabase.dateToSQLStringFormat(Edit.EditedOpExp));
    Values.addElement(new OTableCellUpdaterByObject(25, Edit.EditedOpExp));
    op_query=true;
   }
   if(Edit.EditOrderQty){
    if(first){first=false;}else{col.append(',');}
    col.append("OrderQuantity="+PText.getStringDouble(Edit.EditedOrderQty, CCore.vNull, -0.1, false, false));
    Values.addElement(new OTableCellUpdaterByObject(26, PCore.subtituteDouble(Edit.EditedOrderQty, -0.1, Edit.EditedOrderQty, null)));
    op_query=true;
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)
   if(Edit.EditBuyPrice || Edit.EditOrderQty){
    CellsRef=new OTableCellReference[1]; CellsRef[0]=new OTableCellReference(0, -1, 0, -1);
    PostValues.addElement(
     new OTableCellUpdaterSelect(
      new OTableCellUpdaterSelectCheckerNull(true, 26, CellsRef),
      new OTableCellUpdaterByObject(27, null),
      new OTableCellUpdaterByCalculation(27,
       new OCalculationOperandTableCell(TableItemMdl, 21, 0, -1, 0, -1, 0, 0),
       new OCalculation(
        new OCalculationOperandTableCell(TableItemMdl, 26, 0, -1, 0, -1, 0, 0),
        CMath.Times, true, 0))
     )
    );
   }
   if(Edit.EditStock){
    PostValues.addElement(new OTableCellUpdaterByCalculation(30,
     new OCalculationOperandTableCell(TableItemMdl, 3, 0, -1, 0, -1, 0, 0),
     new OCalculation(new OCalculationOperandTableCell(TableItemMdl, 28, 0, -1, 0, -1, 0, 0), CMath.Add, false, 0).nextCalculation(
     new OCalculation(new OCalculationOperandTableCell(TableItemMdl, 29, 0, -1, 0, -1, 0, 0), CMath.Minus, false, 0))));
   }

   // update
   if(WithSplashScreen){IFV.FSplashScreen.appear(this, "Mengubah Data Barang");}
   
   if(WithSplashScreen){IFV.FSplashScreen.inform(0, "Mengubah "+PText.intToString(count)+" data barang, harap menunggu ...", null);}
   
   error=false;
   MaxList=1000;
   do{
    if(WithSplashScreen){
     IFV.FSplashScreen.setProgressIncreasePercentage(75);
     progress_inc_times=PMath.round((double)count/(double)MaxList, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    columns=col.toString();
    
    curridx=0;
    started=false;
    do{
     try{
      IFV.Stm.executeUpdate("start transaction;");
      started=true;

      do{
       currlistcount=MaxList;
       if(curridx+currlistcount>count){currlistcount=count-curridx;}
       ids=TableItemMdl.getIds(0, PCore.subArr(Rows, curridx, currlistcount));

       if(op_query){
        IFV.Stm.executeUpdate("update Item set "+columns+" where Id in("+PText.toString(ids, 0, ids.length, ",")+");");
       }
       if(op_multiid){
        list_elements=PMyShop.convertItemsIdToSupportedBarcodes(IFV.Stm, ids, IFV.BarcodeGenEAN, Edit.IdOption);
        if(list_elements==null){error=true; break;}
        ListMultiId.append(list_elements);
       }
       
       if(WithSplashScreen){IFV.FSplashScreen.inform(progress_inc, null, null);}

       curridx=curridx+currlistcount;
      }while(curridx!=count);
      if(error){break;}

      IFV.Stm.executeUpdate("commit;");
     }
     catch(Exception E){error=true; break;}
    }while(false);
    if(error){
     if(started){try{IFV.Stm.executeUpdate("rollback;");}catch(Exception E){}}
     break;
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(100);}

    // post-update
    CheckedRows=TableItemMdl.getChecked(Rows, true);

    SumTblOld=PGUI.sumColumns(TableItemMdl, PCore.primArr(27), Rows);
    SumTempListOld=PGUI.sumColumns(TableItemMdl, PCore.primArr(27), CheckedRows);

     // update table
    PGUI.changeElements(TableItemMdl, Rows, Values);
    PGUI.changeElements(TableItemMdl, Rows, PostValues);

    if(Edit.EditId){
     TableItemMdl.check(TempList.getElements(), 0, Rows, 0, true, true, 0, true, false);
     updateQueryTempListCount();
     CheckedRows=TableItemMdl.getChecked(Rows, true);
    }

    SumTblNew=PGUI.sumColumns(TableItemMdl, PCore.primArr(27), Rows);
    SumTempListNew=PGUI.sumColumns(TableItemMdl, PCore.primArr(27), CheckedRows);

    addOrderTotalPriceTbl((Double)SumTblNew[0]-(Double)SumTblOld[0], true);
    addOrderTotalPriceTempList((Double)SumTempListNew[0]-(Double)SumTempListOld[0], true);

    refreshCheckerInfo();
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(20, null, null);}

     // update detail
    Id=-1; Row=Tbl_Item.getSelectedRow(); if(Row!=-1){Id=(Long)TableItemMdl.Mdl.Rows.elementAt(Row)[0];}

    if(IIDet || TabbedPane.getSelectedIndex()==2){
     fillDet(Id);
    }

    if(IIEtc && (
     (Edit.EditId && !Edit.IdSingleItem)
     )){
     fillEtc(Id);
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(5, null, null);}
   }while(false);
   if(WithSplashScreen){IFV.FSplashScreen.disappear();}
   
   if(error){break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 void editSingle(int Row){
  long Id;
  OInfoItem InfoItem=null;
  Object[] RowData;
  F_ItemModify fm=IFV.FItemModify;
  OEditItem Edit;
  int result;
  
  RowData=TableItemMdl.Mdl.Rows.elementAt(Row);
  Id=(Long)RowData[0];
  InfoItem=PMyShop.getItemInfo(IFV.Stm, Id, false);
  if(InfoItem==null){
   JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : terjadi kesalahan ketika mengambil data dari database !");
   return;
  }
  fm.wId=Id;
  fm.wInfoItem=InfoItem;
  fm.wMode=1;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}

  Edit=new OEditItem();
  Edit.init(
   true, true, fm.Id, -1,
   true, false, null, fm.Name,
   true, fm.IsActive,
   true, false, null, fm.Comment,
   true, fm.StockUnitId, fm.StockUnitName,
   true, fm.Stock,
   true, fm.UpdateStock,
   true, fm.MinStock,
   true, fm.MaxStock,
   true, fm.IsOpname,
   true, fm.IsReorder,
   true, fm.OrderEachPackQty,
   true, fm.OrderEachPackThreshold,
   true, fm.OrderMinPack,
   true, fm.HasExpireDate,
   true, fm.ExpireCheckPeriod,
   true, fm.ExpireThreshold,
   true, fm.SellPrice,
   true, false, null, fm.SellPriceComment,
   true, fm.SellUpdate,
   true, fm.BuyPriceEst,
   true, false, null, fm.BuyPriceComment,
   true, fm.BuyUpdate,
   true, fm.OpStock,
   true, fm.OpExpire,
   true, fm.OrderQty);
  
  if(Edit.EditedSellUpdate==null ||
   ((Edit.EditedSellPrice!=InfoItem.SellPrice) && PDate.grading(Edit.EditedSellUpdate, InfoItem.SellUpdate, 0)==0)){
   Edit.EditedSellUpdate=PDate.generateDate(new Date(), false);
  }
  if(Edit.EditedBuyUpdate==null ||
   ((Edit.EditedBuyPrice!=InfoItem.BuyPriceEstimation) && PDate.grading(Edit.EditedBuyUpdate, InfoItem.BuyUpdate, 0)==0)){
   Edit.EditedBuyUpdate=PDate.generateDate(new Date(), false);
  }
  
  result=editItems(PCore.primArr(Row), true, InfoItem, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi, mungkin dikarenakan :\n- Id atau Nama barang sudah ada.");}
  else if(result==-2){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : Id / Secondary-Id sudah ada !");}
 }
 void editMultiple(int[] Rows){
  int count=Rows.length;
  F_ItemModifyMulti fm=IFV.FItemModifyMulti;
  OEditItem Edit;
  int result;
  
  fm.wDataCount=count;
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  Edit=new OEditItem();
  Edit.init(
   fm.ChangeId, false, -1, fm.IdOption,
   fm.ChangeName, true, fm.NameFind, fm.NameReplace,
   fm.ChangeIsActive, fm.IsActive,
   fm.ChangeComment, fm.ChangeCommentSubString, fm.CommentFind, fm.Comment,
   fm.ChangeStockUnit, fm.StockUnitId, fm.StockUnitName,
   fm.ChangeStock, fm.Stock,
   fm.ChangeUpdateStock, fm.UpdateStock,
   fm.ChangeMinStock, fm.MinStock,
   fm.ChangeMaxStock, fm.MaxStock,
   fm.ChangeIsOpname, fm.IsOpname,
   fm.ChangeIsReorder, fm.IsReorder,
   fm.ChangeOrderEachPackQty, fm.OrderEachPackQty,
   fm.ChangeOrderEachPackThreshold, fm.OrderEachPackThreshold,
   fm.ChangeOrderMinPack, fm.OrderMinPack,
   fm.ChangeHasExpireDate, fm.HasExpireDate,
   fm.ChangeExpireCheckPeriod, fm.ExpireCheckPeriod,
   fm.ChangeExpireThreshold, fm.ExpireThreshold,
   fm.ChangeSellPrice, fm.SellPrice,
   fm.ChangeSellPriceComment, fm.ChangeSellPriceCommentSubString, fm.SellPriceCommentFind, fm.SellPriceComment,
   fm.ChangeSellUpdate, fm.SellUpdate,
   fm.ChangeBuyPriceEst, fm.BuyPriceEst,
   fm.ChangeBuyPriceComment, fm.ChangeBuyPriceCommentSubString, fm.BuyPriceCommentFind, fm.BuyPriceComment,
   fm.ChangeBuyUpdate, fm.BuyUpdate,
   fm.ChangeOpStock, fm.OpStock,
   fm.ChangeOpExpire, fm.OpExpire,
   fm.ChangeOrderQty, fm.OrderQty);
  
  if((Edit.EditBuyPrice) && !Edit.EditBuyUpdate){
   Edit.EditBuyUpdate=true; Edit.EditedBuyUpdate=PDate.generateDate(new Date(), false);
  }
  if((Edit.EditSellPrice) && !Edit.EditSellUpdate){
   Edit.EditSellUpdate=true; Edit.EditedSellUpdate=PDate.generateDate(new Date(), false);
  }
  
  result=editItems(Rows, false, null, Edit, true);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi, mungkin dikarenakan :\n- Id atau Nama barang sudah ada.");}
  else if(result==-2){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : Id / Secondary-Id sudah ada !");}
 }
 void QuickSave(){
  boolean bool;
  File Backupdir;
  if(QuickSaveFirst){
   if(JOptionPane.showConfirmDialog(null, "Simpan data 'DaftarKu' ke file sementara ?",
    "Konfirmasi Penyimpanan Data", JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION){return;}
  }
  
  bool=false;
  do{
   Backupdir=new File(IFV.BackupDirectory);
   if(Backupdir.isDirectory()==false){
    if(Backupdir.mkdirs()==false){break;}
   }
   if(PEtc.saveIdToFile(TempList.getElements(), new File(IFV.BackupDirectory+"temp_brg"), false,
    IFV.FSplashScreen, true, this, "Menulis Data DaftarKu")==false){break;}
   bool=true;
  }while(false);
  if(!bool){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data ke file sementara !");
   return;
  }
  
  if(QuickSaveFirst){QuickSaveFirst=false;}
 }
 void QuickLoad(){
  boolean bool;
  long[] Item=null;
  if(JOptionPane.showConfirmDialog(null, "Pulihkan data 'DaftarKu' dari file sementara ?",
   "Konfirmasi Pemulihan Data", JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION){
   return;
  }
  
  bool=false;
  do{
   Item=PEtc.loadIdFromFile(new File(IFV.BackupDirectory+"temp_brg"), false,
    IFV.FSplashScreen, true, this, "Membaca Data DaftarKu");
   if(Item==null){break;}
   bool=true;
  }while(false);
  if(!bool){
   JOptionPane.showMessageDialog(null, "Gagal membaca data dari file sementara !");
   return;
  }
  
  clearTempList();
  fillTempList(Item, true);
  
  if(QuickSaveFirst){QuickSaveFirst=false;}
 }
 
 void chooseData(){
  int[] row=Tbl_Item.getSelectedRows();
  int temp, temp_;
  Object[] objs;
  temp=row.length;
  if(temp!=0){
   ChoosedId=new Long[temp];
   ChoosedName=new String[temp];
   ChoosedPicture=new String[temp];
   ChoosedCategory=new String[temp];
   ChoosedSellPrice=new Double[temp];
   temp_=0;
   do{
    objs=TableItemMdl.Mdl.Rows.elementAt(row[temp_]);
    ChoosedId[temp_]=(Long)objs[0];
    ChoosedName[temp_]=(String)objs[1];
    ChoosedPicture[temp_]=PCore.objString(objs[31], null);
    ChoosedCategory[temp_]=PCore.objString(objs[32], null);
    ChoosedSellPrice[temp_]=(Double)objs[18];
    temp_=temp_+1;
   }while(temp_!=temp);
   DialogResult=1;
   clearComponents();
   Activ=false;
   setVisible(false);
  }
  else{
   JOptionPane.showMessageDialog(null, "Anda harus memilih sebuah barang pada tabel !");
  }
 }
 void csvImportExport(){
  IFV.FCsvImportExport.setEnableImport(true, true);
  IFV.FCsvImportExport.wImportOption=1;
  IFV.FCsvImportExport.setEnableExport(true, true, true);
  IFV.FCsvImportExport.wExportOption=2;
  IFV.FCsvImportExport.wIsImport=false;
  
  if(IFV.FCsvImportExport.showForm()==false){return;}
  if(IFV.FCsvImportExport.DialogResult!=1){return;}
  
  if(IFV.FCsvImportExport.IsImport){
   switch(IFV.FCsvImportExport.ImportOption){
    case 1 : csvImportAdd(); break;
    case 2 : csvImportUpdate(); break;
   }
   return;
  }
  else{
   switch(IFV.FCsvImportExport.ExportOption){
    case 1 : csvExportDb(false); break;
    case 2 : csvExportDb(true); break;
    case 3 : csvExportSample(); break;
   }
   return;
  }
 }
 void csvImportAdd(){
  Vector<String> PKCols;
  Vector<OCsvImportValue> PKColsValue;
  Vector<String> NonPKCols;
  Vector<OCsvImportValue> NonPKColsValue;
  F_ItemImportAdd fm;
  OCsvImportValue ColValue;
  OCsvImportValue ColErrorValue;
  OCsvImportValue ColEmptyValue;
  Vector<OCsvImportValue> ColsValueTemp;
  OCsvImportValueCheckable ColValueCheckable;
  int FileField;
  Object[] ImportResult;
  OCsvImportValue ColValueNull, ColValueDateToday;
  Date DateToday, SellUpdate, BuyUpdate;
  
  fm=IFV.FItemImportAdd;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  // build primary keys
  PKCols=new Vector(); PKColsValue=new Vector();
  
  ColValueNull=new OCsvImportValueObject(CCore.vNull);
  DateToday=PDate.generateDate(new Date(), false);
  ColValueDateToday=new OCsvImportValueObject(PDatabase.getSQLString(DateToday, CCore.TypeDate, CCore.vNull, false));
  
  ColErrorValue=new OCsvImportValueAutoId(IFV.BarcodeGenEAN, IFV.Stm, PMyShop.getQueryOfItemIds(false, true, true));
  FileField=-1; if(fm.IdByFile.Value){FileField=fm.IdFileField.Value;}
  ColValueCheckable=new OCsvImportValueFile(false, FileField, CCore.TypeLong);
  ColsValueTemp=new Vector(); ColsValueTemp.addElement(ColValueCheckable);
  ColValue=
   new OCsvImportValueSelect(ColValueCheckable, ColErrorValue, ColErrorValue,
    new OCsvImportValueSelect(
     new OCsvImportValueDbCheck(
      true, IFV.Stm, "select * from ("+PMyShop.getQueryOfItemIds(false, false, true)+") as tb1 where",
      new OCsvImportValuesInColsAndValues(PCore.vect(""), PCore.vect("ItemId"), PCore.vect("="), ColsValueTemp), false,
      OCsvImportValueCheckable.CheckError, null,
      OCsvImportValueCheckable.CheckValid, ColValueCheckable,
      OCsvImportValueCheckable.CheckError, null
     ), null, null, null
    )
   );
  PKCols.addElement("Id"); PKColsValue.addElement(ColValue);
  
  // build non primary keys
  NonPKCols=new Vector(); NonPKColsValue=new Vector();
  
  FileField=fm.NameFileField.Value;
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeString), null, null, null);
  NonPKCols.addElement("Name"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.StockUnitId.Value, CCore.TypeInteger, CCore.vNull, true));
  ColEmptyValue=ColValueNull;
  FileField=-1; if(fm.StockUnitByFile.Value){FileField=fm.StockUnitFileField.Value;}
  ColValueCheckable=new OCsvImportValueFile(false, FileField, CCore.TypeString);
  ColsValueTemp=new Vector(); ColsValueTemp.addElement(new OCsvImportValueTextAdd(ColValueCheckable, "lower(", ")"));
  ColValue=
   new OCsvImportValueSelect(
    ColValueCheckable, ColErrorValue, ColEmptyValue,
    new OCsvImportValueSelect(
     new OCsvImportValueDbLookup(
      true, IFV.Stm, "select Id from StockUnit where",
      new OCsvImportValuesInColsAndValues(PCore.vect(""), PCore.vect("lower(Name)"), PCore.vect("="), ColsValueTemp),
      CCore.TypeInteger
     ),
     ColErrorValue, ColEmptyValue, null
    )
   );
  NonPKCols.addElement("StockUnit"); NonPKColsValue.addElement(ColValue);
  
  // boolean
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.UpStock.Value, CCore.TypeBoolean, CCore.vNull, false));
  FileField=-1; if(fm.UpStockByFile.Value){FileField=fm.UpStockFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeBoolean), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("UpdateStockOnTransaction"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.IsOpname.Value, CCore.TypeBoolean, CCore.vNull, false));
  FileField=-1; if(fm.IsOpnameByFile.Value){FileField=fm.IsOpnameFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeBoolean), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("IsOpname"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.IsReorder.Value, CCore.TypeBoolean, CCore.vNull, false));
  FileField=-1; if(fm.IsReorderByFile.Value){FileField=fm.IsReorderFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeBoolean), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("IsReorder"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.IsActive.Value, CCore.TypeBoolean, CCore.vNull, false));
  FileField=-1; if(fm.IsActiveByFile.Value){FileField=fm.IsActiveFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeBoolean), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("IsActive"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.HasExp.Value, CCore.TypeBoolean, CCore.vNull, false));
  FileField=-1; if(fm.HasExpByFile.Value){FileField=fm.HasExpFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeBoolean), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("HasExpireDate"); NonPKColsValue.addElement(ColValue);
  
  // double can not be null
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.Stock.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.StockByFile.Value){FileField=fm.StockFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("Stock"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.StockMin.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.StockMinByFile.Value){FileField=fm.StockMinFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("MinimalStock"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.StockMax.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.StockMaxByFile.Value){FileField=fm.StockMaxFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("MaximalStock"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderEachPackQty.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.OrderEachPackQtyByFile.Value){FileField=fm.OrderEachPackQtyFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("OrderEachPackQty"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderMinPack.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.OrderMinPackByFile.Value){FileField=fm.OrderMinPackFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("OrderMinPack"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderEachPackThreshold.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.OrderEachPackThresholdByFile.Value){FileField=fm.OrderEachPackThresholdFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("OrderEachPackThreshold"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.SellPrice.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.SellPriceByFile.Value){FileField=fm.SellPriceFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("SellPrice"); NonPKColsValue.addElement(ColValue);
  
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.BuyPriceEst.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.BuyPriceEstByFile.Value){FileField=fm.BuyPriceEstFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColErrorValue, null);
  NonPKCols.addElement("BuyPriceEstimation"); NonPKColsValue.addElement(ColValue);
  
  // double can be null
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OpStock.Value, CCore.TypeDouble, CCore.vNull, false));
  FileField=-1; if(fm.OpStockByFile.Value){FileField=fm.OpStockFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("OpnameStock"); NonPKColsValue.addElement(ColValue);
  
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderQty.Value, CCore.TypeDouble, CCore.vNull, true));
  FileField=-1; if(fm.OrderQtyByFile.Value){FileField=fm.OrderQtyFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDouble), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("OrderQuantity"); NonPKColsValue.addElement(ColValue);
  
  // integer can be null
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.ExpCheckPeriod.Value, CCore.TypeInteger, CCore.vNull, true));
  FileField=-1; if(fm.ExpCheckPeriodByFile.Value){FileField=fm.ExpCheckPeriodFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeInteger), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("ExpireCheckPeriod"); NonPKColsValue.addElement(ColValue);
  
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.ExpThreshold.Value, CCore.TypeInteger, CCore.vNull, true));
  FileField=-1; if(fm.ExpThresholdByFile.Value){FileField=fm.ExpThresholdFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeInteger), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("ExpireThreshold"); NonPKColsValue.addElement(ColValue);
  
  // date can be null
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OpExp.Value, CCore.TypeDate, CCore.vNull, false));
  FileField=-1; if(fm.OpExpByFile.Value){FileField=fm.OpExpFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDate), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("OpnameExpire"); NonPKColsValue.addElement(ColValue);
  
  ColEmptyValue=ColValueDateToday;
  SellUpdate=fm.SellUpdate.Value; if(SellUpdate==null){SellUpdate=DateToday;}
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(SellUpdate, CCore.TypeDate, CCore.vNull, false));
  FileField=-1; if(fm.SellUpdateByFile.Value){FileField=fm.SellUpdateFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDate), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("SellUpdate"); NonPKColsValue.addElement(ColValue);
  
  ColEmptyValue=ColValueDateToday;
  BuyUpdate=fm.BuyUpdate.Value; if(BuyUpdate==null){BuyUpdate=DateToday;}
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(BuyUpdate, CCore.TypeDate, CCore.vNull, false));
  FileField=-1; if(fm.BuyUpdateByFile.Value){FileField=fm.BuyUpdateFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeDate), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("BuyUpdate"); NonPKColsValue.addElement(ColValue);
  
  // string
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.Comment.Value, CCore.TypeString, CCore.vNull, false));
  FileField=-1; if(fm.CommentByFile.Value){FileField=fm.CommentFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeString), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("Comment"); NonPKColsValue.addElement(ColValue);
  
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.SellComment.Value, CCore.TypeString, CCore.vNull, false));
  FileField=-1; if(fm.SellCommentByFile.Value){FileField=fm.SellCommentFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeString), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("SellPriceComment"); NonPKColsValue.addElement(ColValue);
  
  ColEmptyValue=ColValueNull;
  ColErrorValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.BuyComment.Value, CCore.TypeString, CCore.vNull, false));
  FileField=-1; if(fm.BuyCommentByFile.Value){FileField=fm.BuyCommentFileField.Value;}
  ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, FileField, CCore.TypeString), ColErrorValue, ColEmptyValue, null);
  NonPKCols.addElement("BuyPriceComment"); NonPKColsValue.addElement(ColValue);
  
  IFV.FSplashScreen.appear(this, "Mengimpor-Tambah Data Barang");
  ImportResult=PEtc.csvImportAdd(IFV.FSplashScreen, fm.FileCsv, IFV.Stm, CApp.getTable(CApp.TblItem),
   PKCols, new OCsvImportValuesForInsert(PKColsValue), NonPKCols, new OCsvImportValuesForInsert(NonPKColsValue), false);
  IFV.FSplashScreen.disappear();
  
  if(ImportResult==null){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan pada saat mengimpor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  refreshBackgroundVariables_All();
  refreshBackgroundVariables_TempList();
  refreshCheckerInfo();
  
  /*
  JOptionPane.showMessageDialog(null,
   "Berhasil mengimpor-tambah data barang !"+"\n"+
   "Data yg dibaca : "+PText.intToString((Long)ImportResult[0])+"\n"+
   "Data yg ditambah : "+PText.intToString((Long)ImportResult[1]));
  */
 }
 void csvImportUpdate(){
  F_ItemImportUpdate fm;
  
  OCsvImportValue ColValue;
  OCsvImportValue ColEmptyValue;
  OCsvImportValue ColValueNull;
  OCsvImportValueCheckable ColValueCheckable;
  
  Vector<String> BodyCols;
  Vector<OCsvImportValue> BodyColsValue;
  
  Object[] ImportResult;
  long successcount;
  
  Vector<OCsvImportValue> ColsValueTemp;
  
  String ConditionCol;
  OCsvImportValue ConditionColValue;
  
  Date DateToday;
  OCsvImportValue ColValueDateToday;
  
  fm=IFV.FItemImportUpdate;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  BodyCols=new Vector();
  BodyColsValue=new Vector();
  
  ColValueNull=new OCsvImportValueObject(CCore.vNull);
  DateToday=PDate.generateDate(new Date(), false);
  ColValueDateToday=new OCsvImportValueObject(PDatabase.getSQLString(DateToday, CCore.TypeDate, CCore.vNull, false));
  
  // 
  if(fm.UpdateId.Value){
   ColValueCheckable=new OCsvImportValueFile(false, fm.IdFileField.Value, CCore.TypeLong);
   ColsValueTemp=new Vector(); ColsValueTemp.addElement(ColValueCheckable);
   ColValue=
    new OCsvImportValueSelect(ColValueCheckable, null, null,
     new OCsvImportValueSelect(
      new OCsvImportValueDbCheck(
       true, IFV.Stm, "select * from ("+PMyShop.getQueryOfItemIds(false, false, true)+") as tb1 where",
       new OCsvImportValuesInColsAndValues(PCore.vect(""), PCore.vect("ItemId"), PCore.vect("="), ColsValueTemp), false,
       OCsvImportValueCheckable.CheckError, null,
       OCsvImportValueCheckable.CheckValid, ColValueCheckable,
       OCsvImportValueCheckable.CheckError, null
      ), null, null, null
     )
    );
   BodyCols.addElement("Id"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateName.Value){
   ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.NameFileField.Value, CCore.TypeString), null, null, null);
   BodyCols.addElement("Name"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateStockUnit.Value){
   if(fm.StockUnitByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValueCheckable=new OCsvImportValueFile(false, fm.StockUnitFileField.Value, CCore.TypeString);
    ColsValueTemp=new Vector(); ColsValueTemp.addElement(new OCsvImportValueTextAdd(ColValueCheckable, "lower(", ")"));
    ColValue=
     new OCsvImportValueSelect(
      ColValueCheckable, null, ColEmptyValue,
      new OCsvImportValueSelect(
       new OCsvImportValueDbLookup(
        true, IFV.Stm, "select Id from StockUnit where",
        new OCsvImportValuesInColsAndValues(PCore.vect(""), PCore.vect("lower(Name)"), PCore.vect("="), ColsValueTemp),
        CCore.TypeInteger
       ),
       null, ColEmptyValue, null
      )
     );
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.StockUnitId.Value, CCore.TypeInteger, CCore.vNull, true));
   }
   BodyCols.addElement("StockUnit"); BodyColsValue.addElement(ColValue);
  }
  
  // double can not be null
  if(fm.UpdateStock.Value){
   if(fm.StockByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.StockFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.Stock.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("Stock"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateStockMin.Value){
   if(fm.StockMinByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.StockMinFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.StockMin.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("MinimalStock"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateStockMax.Value){
   if(fm.StockMaxByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.StockMaxFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.StockMax.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("MaximalStock"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateOrderEachPackQty.Value){
   if(fm.OrderEachPackQtyByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.OrderEachPackQtyFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderEachPackQty.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("OrderEachPackQty"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateOrderMinPack.Value){
   if(fm.OrderMinPackByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.OrderMinPackFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderMinPack.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("OrderMinPack"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateOrderEachPackThreshold.Value){
   if(fm.OrderEachPackThresholdByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.OrderEachPackThresholdFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderEachPackThreshold.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("OrderEachPackThreshold"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateSellPrice.Value){
   if(fm.SellPriceByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.SellPriceFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.SellPrice.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("SellPrice"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateBuyPriceEst.Value){
   if(fm.BuyPriceEstByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.BuyPriceEstFileField.Value, CCore.TypeDouble), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.BuyPriceEst.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("BuyPriceEstimation"); BodyColsValue.addElement(ColValue);
  }
  
  // double can be null
  if(fm.UpdateOpStock.Value){
   if(fm.OpStockByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.OpStockFileField.Value, CCore.TypeDouble), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OpStock.Value, CCore.TypeDouble, CCore.vNull, false));
   }
   BodyCols.addElement("OpnameStock"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateOrderQty.Value){
   if(fm.OrderQtyByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.OrderQtyFileField.Value, CCore.TypeDouble), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OrderQty.Value, CCore.TypeDouble, CCore.vNull, true));
   }
   BodyCols.addElement("OrderQuantity"); BodyColsValue.addElement(ColValue);
  }
  
  // integer can be null
  if(fm.UpdateExpCheckPeriod.Value){
   if(fm.ExpCheckPeriodByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.ExpCheckPeriodFileField.Value, CCore.TypeInteger), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.ExpCheckPeriod.Value, CCore.TypeInteger, CCore.vNull, true));
   }
   BodyCols.addElement("ExpireCheckPeriod"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateExpThreshold.Value){
   if(fm.ExpThresholdByFile.Value){
    ColEmptyValue=new OCsvImportValueObject(CCore.vNull);
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.ExpThresholdFileField.Value, CCore.TypeInteger), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.ExpThreshold.Value, CCore.TypeInteger, CCore.vNull, true));
   }
   BodyCols.addElement("ExpireThreshold"); BodyColsValue.addElement(ColValue);
  }
  
  // boolean
  if(fm.UpdateUpStock.Value){
   if(fm.UpStockByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.UpStockFileField.Value, CCore.TypeBoolean), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.UpStock.Value, CCore.TypeBoolean, CCore.vNull, false));
   }
   BodyCols.addElement("UpdateStockOnTransaction"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateIsOpname.Value){
   if(fm.IsOpnameByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.IsOpnameFileField.Value, CCore.TypeBoolean), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.IsOpname.Value, CCore.TypeBoolean, CCore.vNull, false));
   }
   BodyCols.addElement("IsOpname"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateIsReorder.Value){
   if(fm.IsReorderByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.IsReorderFileField.Value, CCore.TypeBoolean), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.IsReorder.Value, CCore.TypeBoolean, CCore.vNull, false));
   }
   BodyCols.addElement("IsReorder"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateIsActive.Value){
   if(fm.IsActiveByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.IsActiveFileField.Value, CCore.TypeBoolean), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.IsActive.Value, CCore.TypeBoolean, CCore.vNull, false));
   }
   BodyCols.addElement("IsActive"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateHasExp.Value){
   if(fm.HasExpByFile.Value){
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.HasExpFileField.Value, CCore.TypeBoolean), null, null, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.HasExp.Value, CCore.TypeBoolean, CCore.vNull, false));
   }
   BodyCols.addElement("HasExpireDate"); BodyColsValue.addElement(ColValue);
  }
  
  // date
  if(fm.UpdateOpExp.Value){
   if(fm.OpExpByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.OpExpFileField.Value, CCore.TypeDate), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.OpExp.Value, CCore.TypeDate, CCore.vNull, false));
   }
   BodyCols.addElement("OpnameExpire"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateSellUpdate.Value){
   if(fm.SellUpdateByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.SellUpdateFileField.Value, CCore.TypeDate), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.SellUpdate.Value, CCore.TypeDate, CCore.vNull, false));
   }
   BodyCols.addElement("SellUpdate"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateBuyUpdate.Value){
   if(fm.BuyUpdateByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.BuyUpdateFileField.Value, CCore.TypeDate), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.BuyUpdate.Value, CCore.TypeDate, CCore.vNull, false));
   }
   BodyCols.addElement("BuyUpdate"); BodyColsValue.addElement(ColValue);
  }
  
  if((fm.UpdateSellPrice.Value || fm.UpdateSellComment.Value) && !fm.UpdateSellUpdate.Value){
   ColValue=ColValueDateToday;
   BodyCols.addElement("SellUpdate"); BodyColsValue.addElement(ColValue);
  }
  
  if((fm.UpdateBuyPriceEst.Value || fm.UpdateBuyComment.Value) && !fm.UpdateBuyUpdate.Value){
   ColValue=ColValueDateToday;
   BodyCols.addElement("BuyUpdate"); BodyColsValue.addElement(ColValue);
  }
  
  // string
  if(fm.UpdateComment.Value){
   if(fm.CommentByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.CommentFileField.Value, CCore.TypeString), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.Comment.Value, CCore.TypeString, CCore.vNull, false));
   }
   BodyCols.addElement("Comment"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateSellComment.Value){
   if(fm.SellCommentByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.SellCommentFileField.Value, CCore.TypeString), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.SellComment.Value, CCore.TypeString, CCore.vNull, false));
   }
   BodyCols.addElement("SellPriceComment"); BodyColsValue.addElement(ColValue);
  }
  
  if(fm.UpdateBuyComment.Value){
   if(fm.BuyCommentByFile.Value){
    ColEmptyValue=ColValueNull;
    ColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.BuyCommentFileField.Value, CCore.TypeString), null, ColEmptyValue, null);
   }
   else{
    ColValue=new OCsvImportValueObject(PDatabase.getSQLString(fm.BuyComment.Value, CCore.TypeString, CCore.vNull, false));
   }
   BodyCols.addElement("BuyPriceComment"); BodyColsValue.addElement(ColValue);
  }
  
  // condition
  ConditionCol="Id";
  ConditionColValue=new OCsvImportValueSelect(new OCsvImportValueFile(true, fm.BasedFileField.Value, CCore.TypeLong), null, null, null);
  
  //
  IFV.FSplashScreen.appear(this, "Mengimpor-Perbaharui Data Barang");
  ColsValueTemp=new Vector(); ColsValueTemp.addElement(ConditionColValue);
  ImportResult=PEtc.csvImportUpdate(IFV.FSplashScreen, fm.FileCsv, IFV.Stm, CApp.getTable(CApp.TblItem),
   new OCsvImportValuesForUpdateBody(BodyCols, BodyColsValue),
   new OCsvImportValuesInColsAndValues(PCore.vect(PCore.refArr("")), PCore.vect(PCore.refArr(ConditionCol)), PCore.vect(PCore.refArr("=")), ColsValueTemp));
  IFV.FSplashScreen.disappear();
  
  if(ImportResult==null){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan pada saat mengimpor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  successcount=(Long)ImportResult[1];
  
  if(successcount>0){
   refreshBackgroundVariables_All();
   refreshBackgroundVariables_TempList();
   fillTable();
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Berhasil mengimpor-perbaharui data barang !"+"\n"+
   "Data yg dibaca : "+PText.intToString((Long)ImportResult[0])+"\n"+
   "Data yg diperbaharui : "+PText.intToString(successcount));
  */
 }
 void csvExportDb(boolean FromListInTheForm){
  String title;
  File f;
  long OperationResult;
  long[] Ids;
  F_CsvWriteOption fm=IFV.FCsvWriteOption;
  String[] Header;
  
  if(FromListInTheForm){
   if(TableItemMdl.Mdl.Rows.size()==0){
    JOptionPane.showMessageDialog(null,
     "Tidak dapat mengekspor !"+
     "\nTabel barang dalam keadaan kosong !");
    return;
   }
  }
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  if(!FromListInTheForm){
   title="Semua Data Barang";
   Ids=null;
  }
  else{
   title="Data Barang Pd Form";
   Ids=TableItemMdl.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableItemMdl.Mdl.Rows.size(), 0, 1));
  }
  
  IFV.FSplashScreen.appear(this, "Mengekspor "+title);
  Header=CApp.getExportColumnsHeader(CApp.TblItem, fm.FieldDelimiter);
  OperationResult=PEtc.csvExport(
   IFV.FSplashScreen,
   IFV.Stm, CApp.getExportQuery(CApp.TblItem, Ids), CApp.getExportColumnsType(CApp.TblItem), Header, PCore.newIntegerArrayInOrderedSequence(Header.length, 0, 1),
   f, fm.FieldDelimiter, fm.FieldsSeparator, CCore.CsvDefaultRecordsSeparator);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengekspor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Sukses mengekspor data !\n"+
   "Total data yg diekspor = "+PText.intToString(OperationResult));
  */
 }
 void csvExportSample(){
  File f;
  long OperationResult;
  F_CsvWriteOption fm=IFV.FCsvWriteOption;
  String[] Header;
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Mengekspor Sampel Data Barang");
  Header=CApp.getExportColumnsHeader(CApp.TblItem, fm.FieldDelimiter);
  OperationResult=PEtc.csvExport(
   IFV.FSplashScreen,
   CApp.getExportSample(CApp.TblItem), CApp.getExportColumnsType(CApp.TblItem), Header, PCore.newIntegerArrayInOrderedSequence(Header.length, 0, 1),
   f, fm.FieldDelimiter, fm.FieldsSeparator, CCore.CsvDefaultRecordsSeparator);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengekspor sampel data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Sukses mengekspor sampel data !\n"+
   "Total sampel data yg diekspor = "+PText.intToString(OperationResult));
  */
 }
 
 // Checker
 
  // Checker Item
 boolean checkCheckerItemChanged(){
  CheckerItemIdCheck=-1;
  try{CheckerItemIdCheck=Long.parseLong(TF_CheckerItemId.getText());}catch(Exception E){CheckerItemIdCheck=-1;}
  if(CheckerItemIdCheck<0){CheckerItemIdCheck=-1;}
  return CheckerItemId!=CheckerItemIdCheck;
 }
 void updateCheckerInput(boolean ByTable, int row){
  boolean process;
  if(ByTable){process=changeCheckerItemByTable(row);}
  else{process=changeCheckerItemByInput();}
  if(!process){return;}
  
  if(CheckerItemId==-1){clearCheckerItemDet(); return;}
  fillCheckerItemDet();
 }
 boolean changeCheckerItemByInput(){
  OInfoItem info_item;
  
  if(!checkCheckerItemChanged()){return false;}
  do{
   CheckerItemId=CheckerItemIdCheck; if(CheckerItemId==-1){break;}
   info_item=PMyShop.getItemInfo(IFV.Stm, CheckerItemId, true);
   if(info_item==null){CheckerItemId=-1; break;}
   CheckerItemId=info_item.PrimaryId;
   CheckerItemDet=info_item;
  }while(false);
   
  return true;
 }
 boolean changeCheckerItemByTable(int row){
  Object[] Objs;
  if(row==-1){return false;}
  Objs=TableItemMdl.Mdl.Rows.elementAt(row);
  CheckerItemId=(Long)Objs[0];
  CheckerItemDet.Name=(String)Objs[1];
  CheckerItemDet.CategoryName=PCore.objString(Objs[32], null);
  CheckerItemDet.PictureFile=PCore.objString(Objs[31], null);
  TF_CheckerItemId.setText(String.valueOf(CheckerItemId));
  return true;
 }
 void clearCheckerItemId(){TF_CheckerItemId.setText(""); CheckerItemId=-1; clearCheckerItemDet();}
 void fillCheckerItemDet(){
  TA_CheckerItemName.setText("("+PText.separate(String.valueOf(CheckerItemId), " - ", 5)+") "+CheckerItemDet.Name+PText.getString(CheckerItemDet.CategoryName, "", " {"+CheckerItemDet.CategoryName+"}", true));
  PGUI.fillPanelPictureURL(Pnl_CheckerItemPreview, IFV.Conf.ImageDirItem, CheckerItemDet.PictureFile);
 }
 void clearCheckerItemDet(){
  TA_CheckerItemName.setText("");
  PGUI.fillPanelPictureURL(Pnl_CheckerItemPreview, IFV.Conf.ImageDirItem, null);
 }
 
  // Checker Mode
 void fillCheckerAttr(CheckerAttr CheckerAttr, JCheckBox CB_CheckerAttr,
  JComboBox CmB_CheckerAttr, OCustomComboBoxModel Mdl_CheckerAttr, JTextField TF_CheckerAttr){
  int temp, length;
  
  CB_CheckerAttr.setEnabled(CheckerAttr.Enable); if(!CB_CheckerAttr.isEnabled()){CB_CheckerAttr.setSelected(false);}
  CmB_CheckerAttr.setEnabled(CheckerAttr.Enable); Mdl_CheckerAttr.removeAll(); //CmB_CheckerAttr.repaint();
  enableInputOfCheckerAttr(CheckerAttr.Enable, TF_CheckerAttr);
  
  if(CheckerAttr.Enable){
   length=CheckerAttr.InputOpts.size();
   temp=0;
   do{
    Mdl_CheckerAttr.append(PCore.objArrVariant(CheckerAttr.InputOpts.elementAt(temp).Name));
    temp=temp+1;
   }while(temp!=length);
   CmB_CheckerAttr.setSelectedIndex(CheckerAttr.LastSelectedInputOpt); CmB_CheckerAttr.repaint();
   onCheckerAttrInputOptChanged(true, CheckerAttr, CmB_CheckerAttr, TF_CheckerAttr);
  }
 }
 void changeCurrChecker(){
  CurrChecker=Checkers.elementAt(CmB_ViewMode.getSelectedIndex());
  
  // change checker input item
  CmB_CheckerIdInput.setEnabled(CurrChecker.Enable); TF_CheckerItemId.setEnabled(CurrChecker.Enable && CmB_CheckerIdInput.getSelectedIndex()==0);
  
  // change checker attributes input
  CurrCheckerAttr1=CurrChecker.Attrs[0]; fillCheckerAttr(CurrCheckerAttr1, CB_CheckerAttr1, CmB_CheckerAttr1, ComboMdlCheckerAttr1, TF_CheckerAttr1);
  CurrCheckerAttr2=CurrChecker.Attrs[1]; fillCheckerAttr(CurrCheckerAttr2, CB_CheckerAttr2, CmB_CheckerAttr2, ComboMdlCheckerAttr2, TF_CheckerAttr2);
  
  // change checker execute
  Btn_CheckerExecute.setEnabled(CurrChecker.Enable);
  
  // change checker info
  refreshCheckerInfo();
 }
 
  // Checker Info
 void refreshCheckerInfo(){
  String str=null;
  switch(CmB_ViewMode.getSelectedIndex()){
   case 0 : break;
   case 1 : break;
   case 2 : str="Kis. Hrg Order"+
    " - Tbl : "+PText.priceToString(OrderTotalPrice_Tbl)+
    " - DftrKu : "+PText.priceToString(OrderTotalPrice_TempList)+
    " - Smua : "+PText.priceToString(OrderTotalPrice_All); break;
  }
  TF_CheckerInfo.setText(PText.getString(str, "", false));
 }
 
  // Checker Attributes's Input
 void clearCheckerAttrInput(JTextField TF_AttrInput){TF_AttrInput.setText("");}
 void clearCheckerAttrInput(JTextField TF_AttrInput, CheckerAttr CheckerAttr, boolean ClearAttrAnyway){
  CheckerAttrInputOpt CurrCheckerAttrInputOpt;
  if(CheckerAttr.Enable){
   CurrCheckerAttrInputOpt=CheckerAttr.InputOpts.elementAt(CheckerAttr.LastSelectedInputOpt);
   if(ClearAttrAnyway || (CurrCheckerAttrInputOpt.EnableInput && CurrCheckerAttrInputOpt.EnableInputClearAfterProcess)){clearCheckerAttrInput(TF_AttrInput);}
  }
 }
 void enableInputOfCheckerAttr(boolean Enable, JTextField TF_CheckerAttrInput){
  TF_CheckerAttrInput.setEnabled(Enable);
  // if(!TF_CheckerAttrInput.isEnabled()){clearCheckerAttrInput(TF_CheckerAttrInput);}
 }
 void clearCheckerAttrsInput(boolean AlsoClearItem, boolean ClearAttrAnyway){
  if(AlsoClearItem){clearCheckerItemId();}
  
  clearCheckerAttrInput(TF_CheckerAttr1, CurrCheckerAttr1, ClearAttrAnyway);
  clearCheckerAttrInput(TF_CheckerAttr2, CurrCheckerAttr2, ClearAttrAnyway);
 }
	boolean changeFocusToCheckerAttributesInput(){
		boolean ret=false;
		
		do{
			if(!TF_CheckerAttr1.isEnabled() && !TF_CheckerAttr2.isEnabled()){break;}
			if(TF_CheckerAttr1.isEnabled() && CB_CheckerAttr1.isSelected()){TF_CheckerAttr1.requestFocusInWindow(); ret=true; break;}
			if(TF_CheckerAttr2.isEnabled() && CB_CheckerAttr2.isSelected()){TF_CheckerAttr2.requestFocusInWindow(); ret=true; break;}
		}while(false);
		
		return ret;
	}
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_CheckerItemId){TF_CheckerItemIdKeyPressed(e);}
		if(Cmp==TF_CheckerAttr1){TF_CheckerAttr1KeyPressed(e);}
		if(Cmp==TF_CheckerAttr2){TF_CheckerAttr2KeyPressed(e);}
 }
 
  // Checker Attributes
 void onCheckerAttrInputOptChanged(boolean UpdateAnyway, CheckerAttr CheckerAttr, JComboBox CmB_AttrInputOpts, JTextField TF_AttrInput){
  int CurrRow=CmB_AttrInputOpts.getSelectedIndex();
  CheckerAttrInputOpt AttrInputOpt;
  
  if(CheckerAttr.LastSelectedInputOpt==CurrRow && !UpdateAnyway){return;}
  
  CheckerAttr.LastSelectedInputOpt=CurrRow;
  
  AttrInputOpt=CheckerAttr.InputOpts.elementAt(CurrRow);
  
  enableInputOfCheckerAttr(AttrInputOpt.EnableInput, TF_AttrInput);
 }
 
  // Checker Execute
 void validateCheckerAttrInput(CheckerAttr CheckerAttr, JCheckBox CB_CheckerAttr, JComboBox CmB_CheckerAttr, OValidation Valid, VBoolean SelectedAttr){
  boolean isvalid=true;
  CheckerAttrInputOpt AttrInputOpt;
  
  do{
   if(!CheckerAttr.Enable){break;}
   if(!CB_CheckerAttr.isSelected()){break;}
   SelectedAttr.Value=true;
   AttrInputOpt=CheckerAttr.InputOpts.elementAt(CmB_CheckerAttr.getSelectedIndex());
   if(!AttrInputOpt.EnableInput){break;}
   if(AttrInputOpt.InputType.isValid()){break;}
   isvalid=false;
  }while(false);
  
  if(!isvalid){Valid.addError("\n- Inputan atribut "+CheckerAttr.Name+" belum benar.");}
 }
 void checkerExecute(){
  int[] rows=Tbl_Item.getSelectedRows();;
  OValidation Valid;
  VBoolean SelectedAttr;
  long[] Ids=null;
  
  boolean UpdateTable;
		int[] UpdateTableRows=null;
		int find_index;
  
  // validate input
  Valid=new OValidation(true);
  
   // validate Input Item
  if(CmB_CheckerIdInput.getSelectedIndex()==0){
   updateCheckerInput(false, -1);
   if(CheckerItemId==-1){Valid.addError("\n- Inputan \"Id Barang\" belum valid.");}
  }
  else{
   if(rows.length==0){Valid.addError("\n- Belum ada data barang yg dipilih pd tabel.");}
  }
  
   // validate Input Attributes
  SelectedAttr=new VBoolean(false);
  validateCheckerAttrInput(CurrCheckerAttr1, CB_CheckerAttr1, CmB_CheckerAttr1, Valid, SelectedAttr);
  validateCheckerAttrInput(CurrCheckerAttr2, CB_CheckerAttr2, CmB_CheckerAttr2, Valid, SelectedAttr);
  if(!SelectedAttr.Value){Valid.addError("\n- Belum ada atribut pembaharuan yang dipilih.");}
  
  if(!Valid.getValid()){
   JOptionPane.showMessageDialog(null, "Inputan masih salah / belum lengkap :\n"+Valid.getError());
   return;
  }
  
  if(CmB_CheckerIdInput.getSelectedIndex()==0){Ids=PCore.primArr(CheckerItemId);}
  else{Ids=PGUI.getIdsFromSelectedRows(TableItemMdl, rows, 0);}
  
  // update GUI
			// table item
		UpdateTable=true;
		UpdateTableRows=rows;
		do{
			if(CmB_CheckerIdInput.getSelectedIndex()==1){break;}
			if(rows.length!=0){
				if(CheckerItemId==(Long)TableItemMdl.Mdl.Rows.elementAt(rows[0])[0]){
				 UpdateTableRows=PCore.primArr(rows[0]); break;
				}
			}
			find_index=PGUI.findLong(TableItemMdl, 0, CheckerItemId);
			if(find_index==-1){UpdateTable=false; break;}
			UpdateTableRows=PCore.primArr(find_index);
		}while(false);
  
  if(!update(Ids, UpdateTable, UpdateTableRows)){
   JOptionPane.showMessageDialog(null, "Gagal memperbaharui atribut-atribut !");
   return;
  }
  
  clearCheckerAttrsInput(false, false);
  if(CmB_CheckerIdInput.getSelectedIndex()==0){TF_CheckerItemId.requestFocusInWindow(); PGUI.text_SelectAll(TF_CheckerItemId);}
		else{Tbl_Item.requestFocusInWindow();}
 }
 void updateGUITable(int[] UpdateTableRows, Vector<OTableCellUpdater> TableUpdaters, Vector<OTableCellUpdater> PostTableUpdaters){
  int SelectedRow;
  
  // update table
		PGUI.changeElements(TableItemMdl, UpdateTableRows, TableUpdaters);
  PGUI.changeElements(TableItemMdl, UpdateTableRows, PostTableUpdaters);

  /* update tab detail (currently, this operation is not needed)
  SelectedRow=Tbl_Item.getSelectedRow();
  if(SelectedRow==-1){return;}
  if(PCore.findAValueInArray(-1, UpdateTableRows, SelectedRow)==-1){return;}
  fillDet((Long)TableItemMdl.Rows.elementAt(SelectedRow)[0]);
  */
 }
 boolean update(long[] Ids, boolean UpdateTable, int[] UpdateTableRows){
  boolean ret=false;
  CheckerAttrInputOpt AttrInputOpt1, AttrInputOpt2;
  
  switch(CmB_ViewMode.getSelectedIndex()){
   case 1 :
    AttrInputOpt1=CurrCheckerAttr1.InputOpts.elementAt(CmB_CheckerAttr1.getSelectedIndex());
    AttrInputOpt2=CurrCheckerAttr2.InputOpts.elementAt(CmB_CheckerAttr2.getSelectedIndex());
    
    ret=updateOpname(Ids, UpdateTable, UpdateTableRows,
     CB_CheckerAttr1.isSelected(), CmB_CheckerAttr1.getSelectedIndex(), PCore.objDouble(AttrInputOpt1.InputType.getValue(), 0D),
     CB_CheckerAttr2.isSelected(), CmB_CheckerAttr2.getSelectedIndex(), PCore.objDate(AttrInputOpt2.InputType.getValue(), null));
    break;
   case 2 :
    AttrInputOpt1=CurrCheckerAttr1.InputOpts.elementAt(CmB_CheckerAttr1.getSelectedIndex());
    
    ret=updateOrder(Ids, UpdateTable, UpdateTableRows,
     CB_CheckerAttr1.isSelected(), CmB_CheckerAttr1.getSelectedIndex(), PCore.objDouble(AttrInputOpt1.InputType.getValue(), 0D));
    break;
  }
  
  return ret;
 }
 boolean updateOpname(long[] Ids, boolean UpdateTable, int[] UpdateTableRows,
  boolean UpdateOpStock, int UpdateOpStockMode, Double vStock, boolean UpdateOpExp, int UpdateOpExpMode, Date vExp){
  OTableCellUpdater TableUpdater=null;
		Vector<OTableCellUpdater> TableUpdaters, PostTableUpdaters;
  
  if(PMyShop.updateOpname(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.OpnameLock, 10, Ids,
   UpdateOpStock, UpdateOpStockMode, vStock, UpdateOpExp, UpdateOpExpMode, vExp)==false){
   return false;
  }
  
  if(UpdateTable){
   TableUpdaters=new Vector(); PostTableUpdaters=new Vector();
   
   // for TableUpdater
   if(UpdateOpStock){
    switch(UpdateOpStockMode){
     case 0 : TableUpdater=new OTableCellUpdaterByObject(24, vStock); break;
     case 1 : TableUpdater=new OTableCellUpdaterByObject(24, null); break;
     case 2 : TableUpdater=new OTableCellUpdaterByCalculation(24, new OCalculationOperandTableCell(TableItemMdl, 24, 0, 0, 0, 0, 0, 0),
      new OCalculation(new OCalculationOperandConstanta(vStock), CMath.Add, false, 0)); break;
     case 3 : TableUpdater=new OTableCellUpdaterByCalculation(24, new OCalculationOperandTableCell(TableItemMdl, 24, 0, 0, 0, 0, 0, 0),
      new OCalculation(new OCalculationOperandConstanta(vStock), CMath.Minus, false, 0)); break;
    }
    TableUpdaters.addElement(TableUpdater);
   }
   if(UpdateOpExp){
    switch(UpdateOpExpMode){
     case 0 : TableUpdater=new OTableCellUpdaterByObject(25, vExp); break;
     case 1 : TableUpdater=new OTableCellUpdaterByObject(25, null); break;
     case 2 : TableUpdater=new OTableCellUpdaterByDateComparation(25, vExp, 1); break;
     case 3 : TableUpdater=new OTableCellUpdaterByDateComparation(25, vExp, 2); break;
    }
    TableUpdaters.addElement(TableUpdater);
   }
   
   updateGUITable(UpdateTableRows, TableUpdaters, PostTableUpdaters);
  }
  
  refreshCheckerInfo();
  
  return true;
 }
 boolean updateOrder(long[] Ids, boolean UpdateTable, int[] UpdateTableRows,
  boolean UpdateOrderQty, int UpdateOrderQtyMode, double vOrderQty){
  OTableCellUpdater TableUpdater=null;
  OTableCellReference[] CellsRef;
  double OrderPriceSumTblOld, OrderPriceSumTblNew, OrderPriceSumTempListOld, OrderPriceSumTempListNew;
  OCustomListModel ListEtc;
		Vector<OTableCellUpdater> TableUpdaters, PostTableUpdaters;
  int[] CheckedRows;
  
  if(PMyShop.updateOrder(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.OrderLock, 10, Ids,
   UpdateOrderQty, UpdateOrderQtyMode, vOrderQty)==false){
   return false;
  }
  
  if(UpdateTable){
   TableUpdaters=new Vector(); PostTableUpdaters=new Vector();
   
   // for TableUpdater
   if(UpdateOrderQty){
    switch(UpdateOrderQtyMode){
     case 0 : TableUpdater=new OTableCellUpdaterByObject(26, PCore.subtituteDouble(vOrderQty, -0.1, vOrderQty, null)); break;
     case 1 : TableUpdater=new OTableCellUpdaterByObject(26, null); break;
     case 2 :
     case 3 :
     case 4 :
      ListEtc=new OCustomListModel(false); ListEtc.setColumnsInfo(PCore.primArr(CCore.TypeLong, CCore.TypeDouble), 0);
      PDatabase.queryToList(IFV.Stm, "select Id, OrderQuantity from Item where Id in("+
       PGUI.getElementList(TableItemMdl.getRows(), UpdateTableRows, 0, ",", "", false)+")", ListEtc, false, null, -1, false, -1);
      TableUpdater=new OTableCellUpdaterByList(26, PCore.primArr(0), ListEtc, PCore.primArr(0), 1, true, null);
      break;
    }
    TableUpdaters.addElement(TableUpdater);
   }

   // for PostTableUpdaters
   if(UpdateOrderQty){
    CellsRef=new OTableCellReference[1]; CellsRef[0]=new OTableCellReference(0, -1, 0, -1);
    TableUpdater=new OTableCellUpdaterSelect(
      new OTableCellUpdaterSelectCheckerNull(true, 26, CellsRef),
      new OTableCellUpdaterByObject(27, null),
      new OTableCellUpdaterByCalculation(27,
       new OCalculationOperandTableCell(TableItemMdl, 21, 0, -1, 0, -1, 0, 0),
       new OCalculation(
        new OCalculationOperandTableCell(TableItemMdl, 26, 0, -1, 0, -1, 0, 0),
        CMath.Times, true, 0))
     );
    PostTableUpdaters.addElement(TableUpdater);
   }
   
   CheckedRows=TableItemMdl.getChecked(UpdateTableRows, true);
   
   OrderPriceSumTblOld=(Double)PGUI.sumColumns(TableItemMdl, PCore.primArr(27), UpdateTableRows)[0];
   OrderPriceSumTempListOld=(Double)PGUI.sumColumns(TableItemMdl, PCore.primArr(27), CheckedRows)[0];

   updateGUITable(UpdateTableRows, TableUpdaters, PostTableUpdaters);

   OrderPriceSumTblNew=(Double)PGUI.sumColumns(TableItemMdl, PCore.primArr(27), UpdateTableRows)[0];
   OrderPriceSumTempListNew=(Double)PGUI.sumColumns(TableItemMdl, PCore.primArr(27), CheckedRows)[0];
   
   addOrderTotalPriceTbl(OrderPriceSumTblNew-OrderPriceSumTblOld, true);
   addOrderTotalPriceTempList(OrderPriceSumTempListNew-OrderPriceSumTempListOld, true);
  }
  else{
   refreshBackgroundVariables_All();
   refreshBackgroundVariables_TempList();
  }
  
  refreshCheckerInfo();
  
  return true;
 }
 
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF.getCaretPosition()==QTF.getDocument().getLength()){
     focusQueryResult();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange1(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF1.getCaretPosition()==QTF1.getDocument().getLength()){
     QTF2.requestFocusInWindow();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange2(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_LEFT:
    if(QTF2.getCaretPosition()==0){
     QTF1.requestFocusInWindow();
    }
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF2.getCaretPosition()==QTF2.getDocument().getLength()){
     focusQueryResult();
    }
    break;
  }
 }
 
 void checkerOpnameStart(){
  if(JOptionPane.showConfirmDialog(null,
   "Mulai proses opname pd semua data barang ?"+
   "\n- Mereset nilai Op-Stok."+
   "\n- Mereset nilai Op-Expire.",
   "Konfirmasi Mulai Proses Opname", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!PDatabase.executeBatchQueries(IFV.Stm, PCore.refArr(
   "update Item set OpnameStock="+CCore.vNull+", OpnameExpire="+CCore.vNull))){
   JOptionPane.showMessageDialog(null, "Gagal memulai proses Opname !"); return;
  }
  
  fillTable();
 }
 void checkerOpnameDone(){
  boolean success;
  if(JOptionPane.showConfirmDialog(null,
   "Selesaikan proses opname pd semua data barang ?"+
   "\n- Melakukan revisi stok berdasarkan hasil Opname-Stok.",
   "Konfirmasi Penyelesaian Proses Opname", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  success=false;
  do{
   if(!PDatabase.insert_MultiRecords_AutoIncrement_ByQuery(IFV.Stm, "RevisiStock", PText.getString(IFV.CurrentDatabase, "", false)+IFV.RevStockLock, 10,
    null, null, null,
    "Id",
    PCore.refArr("RevisiDate", "Item", "StockOld", "StockNew"), PCore.primArr(CCore.TypeDate, CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble),
    "select CurDate(), Id, Stock, Stock+OpnameStock from Item where OpnameStock is not "+CCore.vNull+" and ifnull(OpnameStock,0)<>0")){
    break;
   }
   
   PDatabase.executeBatchQueries(IFV.Stm, PCore.refArr(
    "update Item set OpnameStock="+CCore.vNull));
   
   success=true;
  }while(false);
  if(!success){
   JOptionPane.showMessageDialog(null, "Gagal menyelesaikan proses opname !"); return;
  }
  
  fillTable();
 }
 void checkerOrderStart(){
  if(JOptionPane.showConfirmDialog(null,
   "Mulai proses re-order pd semua data barang ?"+
   "\n- Mereset nilai Order-Qty.",
   "Konfirmasi Mulai Proses Re-Order", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!PDatabase.executeBatchQueries(IFV.Stm, PCore.refArr(
   "update Item set OrderQuantity="+CCore.vNull))){
   JOptionPane.showMessageDialog(null, "Gagal memulai proses Re-Order !"); return;
  }
  
  refreshBackgroundVariables_All();
  refreshBackgroundVariables_TempList();
  fillTable();
 }
 void checkerOrderDone(){
  IFV.FMessage.showMessage(
   "Untuk menyelesaikan proses re-order barang :\n\n"+
   "- Masuk ke menu 'Lihat Pra-Transaksi', lalu pilih tab 'Order'.\n"+
   "- Buat data-data pra-transaksi baru, lalu masukkan data-data order barang yg diinginkan ke dlm data-data pra-transaksi tsb.");
 }
 
 void addOrderTotalPriceTbl(double Value, boolean IsAdd){
  double AddValue=PCore.subtBool_Double(IsAdd, Value, -1*Value);
  OrderTotalPrice_Tbl=OrderTotalPrice_Tbl+AddValue;
  addOrderTotalPriceAll(Value, IsAdd);
 }
 void addOrderTotalPriceTempList(double Value, boolean IsAdd){
  double AddValue=PCore.subtBool_Double(IsAdd, Value, -1*Value);
  OrderTotalPrice_TempList=OrderTotalPrice_TempList+AddValue;
 }
 void addOrderTotalPriceAll(double Value, boolean IsAdd){
  double AddValue=PCore.subtBool_Double(IsAdd, Value, -1*Value);
  OrderTotalPrice_All=OrderTotalPrice_All+AddValue;
 }
 
 void refreshBackgroundVariables_TempList(){
  ResultSet Rs;
  boolean error;
  long[] Ids;
  
  clearBackgroundVariables_TempList();
  
  if(TempList.ElementsCount==0){return;}
  
  error=true;
  do{
   try{
    Ids=TempList.getElements();
    Rs=IFV.Stm.executeQuery("select sum(ifnull(OrderQuantity,0)*BuyPriceEstimation) from Item where Id in("+PText.toString(Ids, 0, Ids.length, ",")+")");
    if(!Rs.next()){break;}
    
    OrderTotalPrice_TempList=Rs.getDouble(1);
   }
   catch(Exception E){break;}
   error=false;
  }while(false);
  if(error){clearBackgroundVariables_TempList();}
 }
 void clearBackgroundVariables_TempList(){
  // initialize the variables on the assumption if the temp-list is empty
  OrderTotalPrice_TempList=0;
 }
 
 void refreshBackgroundVariables_All(){
  ResultSet Rs;
  boolean error;
  
  clearBackgroundVariables_All();
  
  error=true;
  do{
   try{
    Rs=IFV.Stm.executeQuery("select sum(ifnull(OrderQuantity,0)*BuyPriceEstimation) from Item");
    if(!Rs.next()){break;}
    
    OrderTotalPrice_All=Rs.getDouble(1);
   }
   catch(Exception E){break;}
   error=false;
  }while(false);
  if(error){clearBackgroundVariables_All();}
 }
 void clearBackgroundVariables_All(){
  OrderTotalPrice_All=0;
 }
 
 void setItemActive(boolean ActiveValue){
  int[] Rows=Tbl_Item.getSelectedRows();
  OEditItem Edit;
  int result;
  
  if(Rows.length==0){return;}
  
  Edit=new OEditItem();
  Edit.EditIsActive=true; Edit.EditedIsActive=ActiveValue;
  
  result=editItems(Rows, false, null, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
 }
 void setItemIsOpname(boolean Value){
  int[] Rows=Tbl_Item.getSelectedRows();
  OEditItem Edit;
  int result;
  
  if(Rows.length==0){return;}
  
  Edit=new OEditItem();
  Edit.EditIsOpname=true; Edit.EditedIsOpname=Value;
  
  result=editItems(Rows, false, null, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
 }
 void setItemIsReorder(boolean Value){
  int[] Rows=Tbl_Item.getSelectedRows();
  OEditItem Edit;
  int result;
  
  if(Rows.length==0){return;}
  
  Edit=new OEditItem();
  Edit.EditIsReorder=true; Edit.EditedIsReorder=Value;
  
  result=editItems(Rows, false, null, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
 }
 
 void initPrivGUIShow(){
  boolean ShowData;
  boolean ShowTrans, ShowPreTrans, ShowTransIn, ShowTransOut, ShowBuyPrice;
  int tab;
  
  // Buy Price
  ShowData=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;
  this.ShowBuyPrice=ShowData;
  
  PGUI.setEnabled(ShowData, Btn_Edit);
  PGUI.setEnabled(ShowData || wMode==1, Btn_Choose);
  
  PGUI.setEnabled(ShowData, CmB_ViewMode);
  if(!ShowData && CmB_ViewMode.getSelectedIndex()!=0){CmB_ViewMode.setSelectedIndex(0); CmB_ViewModeActionPerformed(null);}
  
  if(CmB_ViewMode.getSelectedIndex()==0){PGUI.setEnabled(ShowData, CB_ViewBuyPrice, CB_ViewBuyPriceComment);}
  if(!ShowData && (CB_ViewBuyPrice.isSelected() || CB_ViewBuyPriceComment.isSelected())){PGUI.setSelected(false, CB_ViewBuyPrice, CB_ViewBuyPriceComment); changeTableItemViewByNormalMode();}

  PGUI.setEnabled(ShowData, CB_DetBuy);
  if(!ShowData && CB_DetBuy.isSelected()){CB_DetBuy.setSelected(false); CB_DetBuyActionPerformed(null);}
  
  PGUI.setEnabled(ShowData, CB_SuppViewBuyPrc, CB_SuppViewBuyComment, CB_SuppViewBuyUpdate);
  if(!ShowData && (CB_SuppViewBuyPrc.isSelected() || CB_SuppViewBuyComment.isSelected() || CB_SuppViewBuyUpdate.isSelected())){
   PGUI.setSelected(false, CB_SuppViewBuyPrc, CB_SuppViewBuyComment, CB_SuppViewBuyUpdate); changeSuppViewByNormal();}
  
  PGUI.setEnabled(ShowData, Btn_SuppEdit);
  
  PGUI.setEnabled(ShowData, CB_VartViewBuyPrice, CB_VartViewBuyComment, CB_VartViewBuyUpdate);
  if(!ShowData && (CB_VartViewBuyPrice.isSelected() || CB_VartViewBuyComment.isSelected() || CB_VartViewBuyUpdate.isSelected())){
   PGUI.setSelected(false, CB_VartViewBuyPrice, CB_VartViewBuyComment, CB_VartViewBuyUpdate); changeVartViewByNormal();}
  
  PGUI.setEnabled(ShowData, Btn_VartEdit);
  
  // Item-Supplier List
  ShowData=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowItemSupplierList;
  
  tab=6;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
  
  PGUI.setEnabled(ShowData, CB_QSup);
  if(!ShowData && CB_QSup.isSelected()){CB_QSup.setSelected(false);}
  
  // Trans List
  do{
   ShowTrans=IFV.CurrentUserIsAdmin || (IFV.PrivGUIShowTransList && (IFV.PrivGUIShowTransItemIn || IFV.PrivGUIShowTransItemOut));
   
   ShowPreTrans=IFV.CurrentUserIsAdmin || (IFV.PrivGUIShowPreTransList && (IFV.PrivGUIShowPreTransItemIn || IFV.PrivGUIShowPreTransItemOut));
   
   ShowBuyPrice=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;
   
   ShowTransIn=IFV.CurrentUserIsAdmin || (
    ((IFV.PrivGUIShowTransList && IFV.PrivGUIShowTransItemIn) || (IFV.PrivGUIShowPreTransList && IFV.PrivGUIShowPreTransItemIn)) &&
    IFV.PrivGUIShowBuyPrice
    );

   ShowTransOut=IFV.CurrentUserIsAdmin || (
    ((IFV.PrivGUIShowTransList && IFV.PrivGUIShowTransItemOut) || (IFV.PrivGUIShowPreTransList && IFV.PrivGUIShowPreTransItemOut))
    );

   ShowData=IFV.CurrentUserIsAdmin || (ShowTransIn || ShowTransOut);
   
   tab=7;
   TabbedPane.setEnabledAt(tab, ShowData);
   if(!ShowData){
    if(TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
    break;
   }
   
   RB_TransIsPreTransN.setEnabled(ShowTrans);
   if(!ShowTrans){IFV.PreventAutoFire.doPrevent(true); RB_TransIsPreTransY.setSelected(true);}
   
   RB_TransIsPreTransY.setEnabled(ShowPreTrans);
   if(!ShowPreTrans){IFV.PreventAutoFire.doPrevent(true); RB_TransIsPreTransN.setSelected(true);}
   
   tab=0;
   TabbedPane_TransList.setEnabledAt(tab, ShowTransIn);
   if(!ShowTransIn && TabbedPane_TransList.getSelectedIndex()==tab){TabbedPane_TransList.setSelectedIndex(1);}
   
   tab=1;
   TabbedPane_TransList.setEnabledAt(tab, ShowTransOut);
   if(!ShowTransOut && TabbedPane_TransList.getSelectedIndex()==tab){TabbedPane_TransList.setSelectedIndex(0);}
   
   PGUI.setEnabled(ShowBuyPrice, CB_TransOutPriceBasic);
   if(!ShowBuyPrice && CB_TransOutPriceBasic.isSelected()){CB_TransOutPriceBasic.setSelected(false); CB_TransOutPriceBasicActionPerformed(null);}
  }while(false);
 }
 
 // Supp
 void onSelectedRowSuppChanged(boolean UpdateAnyway){
  int row=Tbl_Supp.getSelectedRow();
  if(LastSelectedRowSupp==row && !UpdateAnyway){return;}
  LastSelectedRowSupp=row;
  if(row==-1){clearInfoSupp(); return;}
  fillInfoSupp(row);
 }
 
 void fillSupp(long MainId){
  boolean ret=false;
  int datacount;
  
  clearSupp();
  if(MainId==-1){return;}
  
  IISuppClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getItemSupp_Query(true, PCore.primArr(MainId), false, null, false, -1, null, false, false),
    TableMdlSupp, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Supp.changeSelection(0, 0, false, false); onSelectedRowSuppChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearSupp(); return;}
  
  IISupp=true; if(IIEmptyAll==true){IIEmptyAll=false;}
 }
 void clearSupp(){
  if(IISuppClear){return;}
  
  TableMdlSupp.removeAll();
  LastSelectedRowSupp=-1;
  clearInfoSupp();
  
  IISuppClear=true;
 }
 void fillInfoSupp(int row){
  Object[] objs;
  long Id;
  String Name, BuyComment, PictureFile, Category, str;
  double BuyPrice;
  Date BuyUpdate;
  boolean IsActive;
  
  if(row==-1){return;}
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  objs=TableMdlSupp.Mdl.Rows.elementAt(row);
  Id=PCore.objLong(objs[0], -1L);
  Name=PCore.objString(objs[1], null);
  BuyPrice=PCore.objDouble(objs[2], 0D);
  BuyComment=PCore.objString(objs[3], null);
  BuyUpdate=PCore.objDate(objs[4], null);
  IsActive=PCore.objBoolean(objs[5], false);
  PictureFile=PCore.objString(objs[6], null);
  Category=PCore.objString(objs[7], null);
  
  TF_SuppInfoName.setText(Name);
  CB_SuppInfoActive.setSelected(IsActive);
  str=null;
  if(ShowBuyPrice){
   str=
    PText.getStringObj(BuyUpdate, "", "~ "+PText.dateToString(BuyUpdate, 2)+" ~\n", false)+
    PText.priceToString(BuyPrice)+
    PText.getString(BuyComment, "", "   { "+BuyComment+" }", true);
  }
  TA_SuppInfoBuy.setText(PText.getString(str, "", true));
  
  InfoSuppClear=false;
 }
 void clearInfoSupp(){
  if(InfoSuppClear){return;}
  
  PGUI.clearText(TF_SuppInfoName, TA_SuppInfoBuy);
  CB_SuppInfoActive.setSelected(false);
  
  InfoSuppClear=true;
 }
 
 void updateTableSuppView(boolean Requery){
  long MainId;
  int RowMain;
  
  TableMdlSupp.updateColumnsInfo(TableMdlSuppColsName, TableMdlSuppColsType, TableMdlSuppColsShowOption,
   TableMdlSuppColsVisible, TableMdlSuppColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Supp, TableSuppColsWidth);
  if(!Requery){onSelectedRowSuppChanged(false);}
  else{
   MainId=-1; RowMain=Tbl_Item.getSelectedRow(); if(RowMain!=-1){MainId=(Long)TableItemMdl.Mdl.Rows.elementAt(RowMain)[0];}
   fillSupp(MainId);
  }
 }
 void buildTableSuppColumns(){
  TableMdlSuppColsVisible=PMyShop.getItemSupp_ColumnsVisible(true, false,
   CB_SuppViewBuyPrc.isSelected(), CB_SuppViewBuyComment.isSelected(), CB_SuppViewBuyUpdate.isSelected());
  TableSuppColsWidth=PMyShop.getItemSupp_ColumnsWidth(true, false,
   CB_SuppViewBuyPrc.isSelected(), CB_SuppViewBuyComment.isSelected(), CB_SuppViewBuyUpdate.isSelected());
 }
 void buildTableSuppOrderBy(){}
 void buildTableSuppViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableSuppColumns();}
  if(RebuildOrderBy){buildTableSuppOrderBy();}
 }
 void changeSuppViewByNormal(){
  buildTableSuppViewStructure(true, false);
  updateTableSuppView(false);
 }
 void changeSuppViewByCategorized(){
  buildTableSuppViewStructure(true, false);
  updateTableSuppView(true);
 }
 
 void onEditingTableSupp(){
  int SuppRow, SuppCol;
  int result=0;
  boolean IsSame;
  
  SuppRow=Tbl_Supp.Editing_Row;
  SuppCol=TableMdlSupp.convertColumnIndexFromViewToModel(Tbl_Supp.Editing_Col);
  
  if(SuppCol!=-1){
   IsSame=PCore.grading(TableMdlSupp.Mdl.ColumnsType[SuppCol], null, Tbl_Supp.Editing_ValueOld, true, null, Tbl_Supp.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(SuppCol==-1){result=0; break;}
   result=onEditingTableSupp_Supp(SuppRow, SuppCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut supplier !");}
 }
 int onEditingTableSupp_Supp(int SuppRow, int SuppCol){
  int ret=0;
  
  boolean valid;
  int MainRow;
  OEditItemSupplier Edit;
  
  do{
   MainRow=Tbl_Item.getSelectedRow(); if(MainRow==-1){break;}
   
   /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
   
   Edit=new OEditItemSupplier();
   valid=true;
   switch(SuppCol){
    // double not null, positive only, >=0
    case  2 :
     Edit.EditBuyPrc=true; Edit.EditBuyPrcMode=0; Edit.EditedBuyPrc=PCore.objDouble(Tbl_Supp.Editing_ValueNew, -1D); if(Edit.EditedBuyPrc<0){valid=false;}
     Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(PDate.generateDate(new Date(), false), null);
     break;
     
    // String null
    case 3 :
     Edit.EditBuyComment=true; Edit.EditBuyCommentMode=0; Edit.EditBuyCommentSub=false; Edit.EditedBuyComment=PCore.objString(Tbl_Supp.Editing_ValueNew, null);
     Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(PDate.generateDate(new Date(), false), null);
     break;
    
    // date null
    case 4 : Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(Tbl_Supp.Editing_ValueNew, null); break;
   }
   if(!valid){ret=-2; break;}

   if(!editSupp(PCore.primArr(MainRow), MainRow, 1, PCore.primArr(SuppRow), null, null, Edit, null)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void addSupp(){
  int MainRow;
  long MainId;
  String MainName;
  Date Update=null;
  Object[] NewSupp;
  F_ItemSupplierModify fm=IFV.FItemSupplierModify;
  
  MainRow=Tbl_Item.getSelectedRow();
  if(!PGUI.isEnabled(Btn_SuppAdd) || !IISupp || MainRow==-1){return;}
  
  MainId=(Long)TableItemMdl.Mdl.Rows.elementAt(MainRow)[0];
  MainName=(String)TableItemMdl.Mdl.Rows.elementAt(MainRow)[1];
  
  fm.wMode=0;
  fm.wId=MainId;
  fm.wName=MainName;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  if(fm.Update==null){Update=PDate.generateDate(new Date(), false);}else{Update=fm.Update.getTime();}
  
  NewSupp=PCore.objArrVariant(
   fm.ChooseId, fm.ChooseName, fm.BuyPrc, PText.getString(fm.BuyPriceComment, null, true), Update, fm.Active, null, null);
  
  if(!addSupp(false, PCore.primArr(MainRow), MainRow, PCore.toMultiRows2(NewSupp), null)){
   JOptionPane.showMessageDialog(null, "Gagal menambah supplier, mungkin dikarenakan :\n"+
    "Supplier sudah ada pada daftar supplier barang."); return;
  }
 }
 boolean addSupp(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Supps, OFormInformProgress Progress){
  boolean ret=false;
  int result;
  
  if(Progress!=null){Progress.appear(this, "Menambah Supplier");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   result=addSupp_(StmIgnore, MainRows, MainRow, Supps, Progress); if(result==-2){break;}
   
   if(result!=-1){
    Tbl_Supp.changeSelection(result, 0, false, false); onSelectedRowSuppChanged(true);
   }
   
   IISupp=true; IISuppClear=false; IIEmptyAll=false;
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 int addSupp_(boolean StmIgnore, int[] MainRows, int MainRow, Vector<Object[]> Supps, OFormInformProgress Progress){
  int ret=-2; // -2 error, -1 success & not added, >=0 success & added
  long[] MainIds=TableItemMdl.getIds(0, MainRows);
  
  do{
   if(!PMyShop.itemSuppAdd(IFV.Stm, StmIgnore, true, MainIds, Supps, Progress)){break;}
   ret=addSupp_GUI(MainRow, Supps);
  }while(false);
  
  return ret;
 }
 int addSupp_GUI(int MainRow, Vector<Object[]> Supps){
  int ret=-1;
  int temp, count;
  long MainId;
  long[] CompIds;
  int[] coltype, colcheck, AllRows;
  Object[] Supp;
  Vector<Object[]> Data, QSupps;
  
  coltype=TableMdlSupp.getColumnsType();
  colcheck=PCore.primArr(0);
  Data=TableMdlSupp.getRows();
  AllRows=PCore.newIntegerArrayInOrderedSequence(Supps.size(), 0, 1);
  
  if(MainRow==-1 || !IISupp){return ret;}
  
  MainId=(Long)TableItemMdl.Mdl.Rows.elementAt(MainRow)[0];
  CompIds=PTable.subDataOfIds(Supps, coltype, AllRows, 0);
  
  QSupps=PMyShop.getItemSupp(IFV.Stm, true, MainId, CompIds, false);
  count=0; if(QSupps!=null){count=QSupps.size();} if(count==0){return ret;}
  
  temp=0;
  do{
   Supp=QSupps.elementAt(temp);
   
   if(PTable.findData(coltype, true, Data, colcheck, Supp, colcheck)==-1){
    // add to list supp
    ret=Data.size();
    TableMdlSupp.insert(ret, Supp);
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 Vector<Object[]> getSuppChecksData(long[] ByIds_CompIds){
  Vector<Object[]> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(PCore.objArr_PrimArr(ByIds_CompIds));
  }
  
  return ret;
 }
 Vector<Integer> getSuppChecksColumn(long[] ByIds_CompIds){
  Vector<Integer> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_CompIds, true)){
   ret.addElement(0);
  }
  
  return ret;
 }
 void editSupp(){
  boolean bool;
  int MainRow;
  long MainId;
  String MainName;
  int[] CompRows;
  long CompId;
  String CompName;
  Date Update=null;
  OInfoItemSupplier InfoItemSupp=null;
  OEditItemSupplier Edit=new OEditItemSupplier();
  F_ItemSupplierModify fm1=IFV.FItemSupplierModify;
  F_ItemSupplierModifyMulti fm2=IFV.FItemSupplierModifyMulti;
  
  MainRow=Tbl_Item.getSelectedRow();
  CompRows=Tbl_Supp.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SuppEdit) || !IISupp || MainRow==-1 || CompRows.length==0){return;}
  
  if(CompRows.length==1){
   bool=false;
   do{
    MainId=(Long)TableItemMdl.Mdl.Rows.elementAt(MainRow)[0];
    MainName=(String)TableItemMdl.Mdl.Rows.elementAt(MainRow)[1];
    CompId=(Long)TableMdlSupp.Mdl.Rows.elementAt(CompRows[0])[0];
    CompName=(String)TableMdlSupp.Mdl.Rows.elementAt(CompRows[0])[1];
    InfoItemSupp=PMyShop.getItemSupplierInfo(IFV.Stm, true, MainId, CompId); if(InfoItemSupp==null){break;}

    bool=true;
   }while(false);
   if(!bool){JOptionPane.showMessageDialog(null, "Gagal mengambil info supplier !"); return;}

   fm1.wMode=1;
   fm1.wId=MainId;
   fm1.wName=MainName;
   fm1.wChooseId=CompId;
   fm1.wChooseName=CompName;
   fm1.wBuyPrc=InfoItemSupp.BuyPrc;
   fm1.wBuyPriceComment=InfoItemSupp.BuyComment;
   fm1.wUpdate=InfoItemSupp.Update;
   fm1.wActive=InfoItemSupp.IsActive;

   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}

   if(fm1.Update==null){Update=PDate.generateDate(new Date(), false);}else{Update=PDate.generateDate(fm1.Update.getTime(), false);}
   
   Edit.init(
    true, fm1.ChooseId, fm1.ChooseName,
    true, 0, fm1.BuyPrc,
    true, 0, false, null, PText.getString(fm1.BuyPriceComment, null, true),
    true, 0, Update,
    true, 0, fm1.Active);
  }
  else{
   fm2.wDataCount=CompRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Update=fm2.Update; if(Update==null){Update=PDate.generateDate(new Date(), false);}
   
   Edit.init(
    false, -1, null,
    fm2.ChangeBuyPrc, 0, fm2.BuyPrc,
    fm2.ChangeBuyPriceComment, 0, fm2.ChangeBuyPriceCommentSub, fm2.BuyPriceCommentSub, fm2.BuyPriceComment,
    fm2.ChangeUpdate, 0, Update,
    fm2.ChangeActive, 0, fm2.Active);
  }
  
  if(!editSupp(PCore.primArr(MainRow), MainRow, 1, CompRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data supplier, mungkin dikarenakan :\n"+
    "Supplier sudah ada pada daftar supplier barang.");
   return;
  }
 }
 boolean editSupp(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_SuppRows,
   Vector<Object[]> ByVect_Data,
   long[] ByIds_CompIds,
  OEditItemSupplier Edit, OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  int SuppRow;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null;
  OCustomListModel List;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  long[] ByIds=null;
  
  MainIds=TableItemMdl.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlSupp.getRows(), ByTable_SuppRows, PCore.newIntegerArrayInOrderedSequence(TableMdlSupp.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_SuppRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(IISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(IISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), getSuppChecksData(ByIds_CompIds),
      getSuppChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Mengubah Supplier");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  do{
   Updater=new Vector();
   
   List=new OCustomListModel(false); List.setColumnsInfo(TableMdlSupp.getColumnsType(), 1); if(ByVect!=null){List.append(ByVect);}
   
   // Updater
   if(Edit.EditComp){
    Updater.addElement(new OTableCellUpdaterByObject(0, Edit.EditedCompId));
    Updater.addElement(new OTableCellUpdaterByObject(1, Edit.EditedCompName));
   }
   if(Edit.EditBuyPrc){
    switch(Edit.EditBuyPrcMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(2, Edit.EditedBuyPrc); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(2, PCore.primArr(0), List, PCore.primArr(0), 2, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyComment){
    if(!Edit.EditBuyCommentSub){
     switch(Edit.EditBuyCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedBuyComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(3, PCore.primArr(0), List, PCore.primArr(0), 3, false, null); break;
     }
    }
    else{
     switch(Edit.EditBuyCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(3, true, Edit.EditedBuyCommentSub, Edit.EditedBuyComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyUpdate){
    switch(Edit.EditBuyUpdateMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(4, Edit.EditedBuyUpdate); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(4, PCore.primArr(0), List, PCore.primArr(0), 4, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditIsActive){
    switch(Edit.EditIsActiveMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(5, Edit.EditedIsActive); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(5, PCore.primArr(0), List, PCore.primArr(0), 5, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   
   if(!PMyShop.itemSuppEdit(IFV.Stm, true, MainIds, IsByVect, ByVect, ByIds, Edit, Progress)){break;}
   
   PGUI.changeElements(TableMdlSupp, TableRows, Updater);
   
   if(IISupp){
    SuppRow=Tbl_Supp.getSelectedRow();
    fillInfoSupp(SuppRow);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 void removeSupp(){
  int MainRow;
  int[] SuppRows;
  
  MainRow=Tbl_Item.getSelectedRow();
  SuppRows=Tbl_Supp.getSelectedRows();
  if(!PGUI.isEnabled(Btn_SuppRemove) || !IISupp || MainRow==-1 || SuppRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+SuppRows.length+" supplier yang dipilih ?",
   "Konfirmasi Penghapusan Supplier", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!removeSupp(PCore.primArr(MainRow), MainRow, 1, SuppRows, null, null, null)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data supplier !"); return;}
 }
 boolean removeSupp(int[] MainRows, int MainRow,
  int ModeKey,
   int[] ByTable_SuppRows,
   Vector<Object[]> ByVect_Data,
   long[] ByIds_CompIds,
  OFormInformProgress Progress){
  boolean ret=false;
  long[] MainIds=null;
  int[] TableRows=null;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  long[] ByIds=null;
  
  MainIds=TableItemMdl.getIds(0, MainRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlSupp.getRows(), ByTable_SuppRows, PCore.newIntegerArrayInOrderedSequence(TableMdlSupp.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_SuppRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(IISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_CompIds;
    
    TableRows=new int[0];
    if(IISupp){
     TableRows=PTable.findAll(TableMdlSupp.getRows(), TableMdlSupp.getColumnsType(), getSuppChecksData(ByIds_CompIds),
      getSuppChecksColumn(ByIds_CompIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Menghapus Supplier");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   if(!PMyShop.itemSuppRemove(IFV.Stm, true, true, MainIds, IsByVect, ByVect, ByIds, Progress)){break;}
   
   TableMdlSupp.remove(TableRows); onSelectedRowSuppChanged(true);
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 void findSupp(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str;
  
  str=TF_SuppFind.getText();
  if(str.length()==0){return;}
  
  if(TableMdlSupp.Mdl.Rows.size()==0){
   JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !");
   return;
  }
  
  switch(CmB_SuppFind.getSelectedIndex()){
   case 1 : Column=3;  break;
   default : Column=1; break;
  }
  ColumnType=TableMdlSupp.getColumnsType()[Column];
  Selected=Tbl_Supp.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlSupp, Column, ColumnType, str, Selected, Mode);
  
  if(FindIndex==-1){
   JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !");
   return;
  }
  
  if(Selected==FindIndex){return;}
  
  Tbl_Supp.changeSelection(FindIndex, 0, false, false);
  onSelectedRowSuppChanged(false);
 }
 
 void setItemSuppActive(boolean ActiveValue){
  int MainRow=Tbl_Item.getSelectedRow();
  int[] SuppRows=Tbl_Supp.getSelectedRows();
  OEditItemSupplier Edit;
  
  if(MainRow==-1 || SuppRows.length==0){return;}
  
  Edit=new OEditItemSupplier();
  Edit.EditIsActive=true; Edit.EditIsActiveMode=0; Edit.EditedIsActive=ActiveValue;
  
  if(!editSupp(PCore.primArr(MainRow), MainRow, 1, SuppRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !"); return;}
 }
 
 // Vrs
 void fillVrs(long Id){
  boolean bool;
  
  clearVrs();
  
  IIVrsClear=false;
  
  bool=false;
  do{
   if(!fillSec(Id)){break;}
   if(!fillVart(Id)){break;}
   bool=true;
  }while(false);
  if(!bool){clearVrs(); return;}
  
  IIVrs=true; if(IIEmptyAll==true){IIEmptyAll=false;}
 }
 void clearVrs(){
  if(IIVrsClear){return;}
  
  clearSec();
  clearVart();
  
  IIVrsClear=true;
 }
 
  // Sec
 void onSecRowSelected(boolean UpdateAnyway){
  int row=List_Sec.getSelectedIndex();
  
  if(LastSelectedRowSec==row && !UpdateAnyway){return;}
  
  LastSelectedRowSec=row;
  if(row==-1){clearInfoSec(); return;}
  fillInfoSec(row);
 }
 String formatSecondaryId(long SecondaryId){
  return PText.separate(String.valueOf(SecondaryId), " - ", 5);
 }
 void formatListSecondaryId(){
  int temp, length;
  Vector<Object[]> Data=ListMdlSec.getRows();
  Object[] AData;
  length=Data.size();
  if(length==0){return;}
  temp=0;
  do{
   AData=Data.elementAt(temp);
   AData[1]=formatSecondaryId((Long)AData[0]);
   temp=temp+1;
  }while(temp!=length);
  ListMdlSec.refreshUpdate(0, length-1);
 }
 boolean fillSec(long Id){
  boolean ret=false;
  int datacount;
  
  clearSec();
  
  IISecClear=false;
  do{
   datacount=PDatabase.queryToList(IFV.Stm,
    "select SecondaryId, '' from ItemXSecondaryId where Item="+Id+" order by SecondaryId asc",
    ListMdlSec, false, null, -1, false, -1);
   if(datacount==-1){break;}
   formatListSecondaryId();
   SecsCount=datacount;
   if(datacount>0){List_Sec.setSelectedIndex(0); onSecRowSelected(true);}
   
   ret=true;
  }while(false);
  if(!ret){clearSec();}
  
  return ret;
 }
 void clearSec(){
  if(IISecClear){return;}
  
  ListMdlSec.removeAll();
  LastSelectedRowSec=-1;
  clearInfoSec();
  SecsCount=0;
  
  IISecClear=true;
 }
 void fillInfoSec(int SecRowSelected){
  Object[] Objs=ListMdlSec.Mdl.Rows.elementAt(SecRowSelected);
  
  
  
  InfoSecClear=false;
 }
 void clearInfoSec(){
  if(InfoSecClear){return;}
  
  
  
  InfoSecClear=true;
 }
 
 // Vart
 void onSelectedRowVartChanged(boolean UpdateAnyway){
  int row=Tbl_Vart.getSelectedRow();
  if(LastSelectedRowVart==row && !UpdateAnyway){return;}
  LastSelectedRowVart=row;
  if(row==-1){clearInfoVart(); return;}
  fillInfoVart(row);
 }
 
 boolean fillVart(long ItemId){
  boolean ret=false;
  int datacount;
  
  clearVart();
  if(ItemId==-1){return true;}
  
  IIVartClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getItemVart_Query(PCore.primArr(ItemId), false, null, false, -1, null, false),
    TableMdlVart, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Vart.changeSelection(0, 0, false, false); onSelectedRowVartChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearVart();}
  
  return ret;
 }
 void clearVart(){
  if(IIVartClear){return;}
  
  TableMdlVart.removeAll();
  LastSelectedRowVart=-1;
  clearInfoVart();
  
  IIVartClear=true;
 }
 String getInfoVart_Name(Object[] objs){
  StringBuilder ret=new StringBuilder();
  String Name, Comment;
  
  Name=PCore.objString(objs[0], null);
  Comment=PCore.objString(objs[5], null);
  
  ret.append(Name);
  ret.append(PText.getString(Comment, "", "   { "+Comment+" }", true));
  
  return ret.toString();
 }
 String getInfoVart_Buy(Object[] objs){
  StringBuilder ret=new StringBuilder();
  double BuyPrice;
  String BuyComment;
  Date BuyUpdate;
  
  BuyPrice=PCore.objDouble(objs[2], 0D);
  BuyComment=PCore.objString(objs[3], null);
  BuyUpdate=PCore.objDate(objs[4], null);
  
  if(ShowBuyPrice){
   ret.append(PText.getStringObj(BuyUpdate, "", "~ "+PText.dateToString(BuyUpdate, 2)+" ~\n", false));
   ret.append(PText.priceToString(BuyPrice));
   ret.append(PText.getString(BuyComment, "", "   { "+BuyComment+" }", true));
  }
  
  return ret.toString();
 }
 void fillInfoVart(int row){
  Object[] objs;
  
  if(row==-1){return;}
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  objs=TableMdlVart.Mdl.Rows.elementAt(row);
  TA_VartInfoName.setText(getInfoVart_Name(objs));
  TA_VartInfoBuy.setText(getInfoVart_Buy(objs));
  PGUI.fillPanelPictureURL(Pnl_VartInfoPreview, IFV.Conf.ImageDirItem, PCore.objString(objs[6], null));
  
  InfoVartClear=false;
 }
 void clearInfoVart(){
  if(InfoVartClear){return;}
  
  PGUI.clearText(TA_VartInfoName, TA_VartInfoBuy);
  PGUI.fillPanelPictureURL(Pnl_VartInfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoVartClear=true;
 }
 
 void updateTableVartView(boolean Requery){
  long ItemId;
  int RowItem;
  
  TableMdlVart.updateColumnsInfo(TableMdlVartColsName, TableMdlVartColsType, TableMdlVartColsShowOption,
   TableMdlVartColsVisible, TableMdlVartColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Vart, TableVartColsWidth);
  if(!Requery){onSelectedRowVartChanged(false);}
  else{
   ItemId=-1; RowItem=Tbl_Item.getSelectedRow(); if(RowItem!=-1){ItemId=(Long)TableItemMdl.Mdl.Rows.elementAt(RowItem)[0];}
   fillVart(ItemId);
  }
 }
 void buildTableVartColumns(){
  TableMdlVartColsVisible=PMyShop.getItemVart_ColumnsVisible(
   CB_VartViewBuyPrice.isSelected(), CB_VartViewBuyComment.isSelected(), CB_VartViewBuyUpdate.isSelected(), CB_VartViewComment.isSelected());
  TableVartColsWidth=PMyShop.getItemVart_ColumnsWidth(
   CB_VartViewBuyPrice.isSelected(), CB_VartViewBuyComment.isSelected(), CB_VartViewBuyUpdate.isSelected(), CB_VartViewComment.isSelected());
 }
 void buildTableVartOrderBy(){}
 void buildTableVartViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableVartColumns();}
  if(RebuildOrderBy){buildTableVartOrderBy();}
 }
 void changeVartViewByNormal(){
  buildTableVartViewStructure(true, false);
  updateTableVartView(false);
 }
 
 void onEditingTableVart(){
  int VartRow, VartCol;
  int result=0;
  boolean IsSame;
  
  VartRow=Tbl_Vart.Editing_Row;
  VartCol=TableMdlVart.convertColumnIndexFromViewToModel(Tbl_Vart.Editing_Col);
  
  if(VartCol!=-1){
   IsSame=PCore.grading(TableMdlVart.Mdl.ColumnsType[VartCol], null, Tbl_Vart.Editing_ValueOld, true, null, Tbl_Vart.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(VartCol==-1){result=0; break;}
   result=onEditingTableVart_Vart(VartRow, VartCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut varian, mungkin dikarenakan :\n"+
   "Nama varian sudah ada pada daftar varian barang.");}
 }
 int onEditingTableVart_Vart(int VartRow, int VartCol){
  int ret=0;
  
  boolean valid;
  int ItemRow;
  OEditItemVariant Edit;
  
  do{
   ItemRow=Tbl_Item.getSelectedRow(); if(ItemRow==-1){break;}
   
   /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
   
   Edit=new OEditItemVariant();
   valid=true;
   switch(VartCol){
    // double not null, positive only, >=0
    case  2 :
     Edit.EditBuyPrice=true; Edit.EditBuyPriceMode=0; Edit.EditedBuyPrice=PCore.objDouble(Tbl_Vart.Editing_ValueNew, -1D); if(Edit.EditedBuyPrice<0){valid=false;}
     Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(PDate.generateDate(new Date(), false), null);
     break;
     
    // String null
    case 3 :
     Edit.EditBuyComment=true; Edit.EditBuyCommentMode=0; Edit.EditBuyCommentSub=false; Edit.EditedBuyComment=PCore.objString(Tbl_Vart.Editing_ValueNew, null);
     Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(PDate.generateDate(new Date(), false), null);
     break;
    case 5 :
     Edit.EditComment=true; Edit.EditCommentMode=0; Edit.EditCommentSub=false; Edit.EditedComment=PCore.objString(Tbl_Vart.Editing_ValueNew, null);
     break;
    
    // string not null
    case 0 : Edit.EditVariant=true; Edit.EditVariantMode=0; Edit.EditVariantSub=false; Edit.EditedVariant=PCore.objString(Tbl_Vart.Editing_ValueNew, null); if(PText.isEmptyString(Edit.EditedVariant, true, true)){valid=false;} break;
    
    // date null
    case 4 : Edit.EditBuyUpdate=true; Edit.EditBuyUpdateMode=0; Edit.EditedBuyUpdate=PCore.objDate(Tbl_Vart.Editing_ValueNew, null); break;
   }
   if(!valid){ret=-2; break;}

   if(!editVart(PCore.primArr(ItemRow), ItemRow, 1, PCore.primArr(VartRow), null, null, Edit, null)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void addVart(){
  int ItemRow;
  Date Update=null;
  Object[] NewVart;
  F_ItemVariantModify fm=IFV.FItemVariantModify;
  
  ItemRow=Tbl_Item.getSelectedRow();
  if(!PGUI.isEnabled(Btn_VartAdd) || !IIVrs || ItemRow==-1){return;}
  
  fm.wMode=1;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  Update=fm.Info.BuyUpdate; if(Update==null){Update=PDate.generateDate(new Date(), false);}
  
  NewVart=PCore.objArrVariant(
   fm.Info.Variant, fm.Info.IsActive, fm.Info.BuyPrice, fm.Info.BuyComment, fm.Info.BuyUpdate,
   PText.getString(fm.Info.Comment, null, true), PText.getString(fm.Info.PictureFile, null, true));
  
  if(!addVart(false, PCore.primArr(ItemRow), ItemRow, PCore.toMultiRows2(NewVart), null)){
   JOptionPane.showMessageDialog(null, "Gagal menambah varian, mungkin dikarenakan :\n"+
    "Nama varian sudah ada pada daftar varian barang."); return;
  }
 }
 boolean addVart(boolean StmIgnore, int[] ItemRows, int ItemRow, Vector<Object[]> Varts, OFormInformProgress Progress){
  boolean ret=false;
  int result;
  
  if(Progress!=null){Progress.appear(this, "Menambah Varian");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   result=addVart_(StmIgnore, ItemRows, ItemRow, Varts, Progress); if(result==-2){break;}
   
   if(result!=-1){
    Tbl_Vart.changeSelection(result, 0, false, false); onSelectedRowVartChanged(true);
   }
   
   if(IIVrs){IIVrsClear=false; IIVartClear=false;}
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 int addVart_(boolean StmIgnore, int[] ItemRows, int ItemRow, Vector<Object[]> Varts, OFormInformProgress Progress){
  int ret=-2; // -2 error, -1 success & not added, >=0 success & added
  long[] ItemIds=TableItemMdl.getIds(0, ItemRows);
  
  do{
   if(!PMyShop.itemVartAdd(IFV.Stm, StmIgnore, ItemIds, Varts, Progress)){break;}
   ret=addVart_GUI(ItemRow, Varts);
  }while(false);
  
  return ret;
 }
 int addVart_GUI(int ItemRow, Vector<Object[]> Varts){
  int ret=-1;
  int temp, count;
  long ItemId;
  String[] VariantIds;
  int[] coltype, colcheck, AllRows;
  Object[] Vart;
  Vector<Object[]> Data, QVarts;
  
  coltype=TableMdlVart.getColumnsType();
  colcheck=PCore.primArr(0);
  Data=TableMdlVart.getRows();
  AllRows=PCore.newIntegerArrayInOrderedSequence(Varts.size(), 0, 1);
  
  if(!IIVrs){return ret;}
  
  ItemId=(Long)TableItemMdl.Mdl.Rows.elementAt(ItemRow)[0];
  VariantIds=PTable.subDataOfStrings(Varts, coltype, AllRows, 0);
  
  QVarts=PMyShop.getItemVart(IFV.Stm, ItemId, VariantIds);
  count=0; if(QVarts!=null){count=QVarts.size();} if(count==0){return ret;}
  
  temp=0;
  do{
   Vart=QVarts.elementAt(temp);
   
   if(PTable.findData(coltype, true, Data, colcheck, Vart, colcheck)==-1){
    // add to list vart
    ret=Data.size();
    TableMdlVart.insert(ret, Vart);
   }
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 Vector<Object[]> getVartChecksData(String[] ByIds_VariantIds){
  Vector<Object[]> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_VariantIds, true)){
   ret.addElement(PCore.objArr(ByIds_VariantIds));
  }
  
  return ret;
 }
 Vector<Integer> getVartChecksColumn(String[] ByIds_VariantIds){
  Vector<Integer> ret=new Vector();
  
  if(!PCore.isArrayEmpty(ByIds_VariantIds, true)){
   ret.addElement(0);
  }
  
  return ret;
 }
 void editVart(){
  boolean bool;
  int ItemRow;
  long ItemId;
  int[] VariantRows;
  String VariantId;
  Date Update=null;
  OInfoItemVariant InfoItemVart=null;
  OEditItemVariant Edit=new OEditItemVariant();
  F_ItemVariantModify fm1=IFV.FItemVariantModify;
  F_ItemVariantModifyMulti fm2=IFV.FItemVariantModifyMulti;
  
  ItemRow=Tbl_Item.getSelectedRow();
  VariantRows=Tbl_Vart.getSelectedRows();
  if(!PGUI.isEnabled(Btn_VartEdit) || !IIVrs || ItemRow==-1 || VariantRows.length==0){return;}
  
  if(VariantRows.length==1){
   bool=false;
   do{
    ItemId=(Long)TableItemMdl.Mdl.Rows.elementAt(ItemRow)[0];
    VariantId=(String)TableMdlVart.Mdl.Rows.elementAt(VariantRows[0])[0];
    InfoItemVart=PMyShop.getItemVariantInfo(IFV.Stm, ItemId, VariantId); if(InfoItemVart==null){break;}

    bool=true;
   }while(false);
   if(!bool){JOptionPane.showMessageDialog(null, "Gagal mengambil info varian !"); return;}

   fm1.wMode=2;
   fm1.wInfo=InfoItemVart;

   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}

   Update=fm1.Info.BuyUpdate; if(Update==null){Update=PDate.generateDate(new Date(), false);}
   
   Edit.init(
    true, 0, false, null, fm1.Info.Variant,
    true, 0, fm1.Info.IsActive,
    true, 0, fm1.Info.BuyPrice,
    true, 0, false, null, PText.getString(fm1.Info.BuyComment, null, true),
    true, 0, Update,
    true, 0, false, null, PText.getString(fm1.Info.Comment, null, true),
    true, 0, PText.getString(fm1.Info.PictureFile, null, true));
  }
  else{
   fm2.wDataCount=VariantRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit=fm2.Edit;
   
   if(Edit.EditedBuyUpdate==null){Edit.EditedBuyUpdate=PDate.generateDate(new Date(), false);}
  }
  
  if(!editVart(PCore.primArr(ItemRow), ItemRow, 1, VariantRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data varian, mungkin dikarenakan :\n"+
    "Nama varian sudah ada pada daftar varian barang.");
   return;
  }
 }
 boolean editVart(int[] ItemRows, int ItemRow,
  int ModeKey,
   int[] ByTable_VartRows,
   Vector<Object[]> ByVect_Data,
   String[] ByIds_VariantIds,
  OEditItemVariant Edit, OFormInformProgress Progress){
  boolean ret=false;
  long[] ItemIds=null;
  int[] TableRows=null;
  int VartRow;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null;
  OCustomListModel List;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  String[] ByIds=null;
  
  ItemIds=TableItemMdl.getIds(0, ItemRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlVart.getRows(), ByTable_VartRows, PCore.newIntegerArrayInOrderedSequence(TableMdlVart.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_VartRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(IIVrs){
     TableRows=PTable.findAll(TableMdlVart.getRows(), TableMdlVart.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_VariantIds;
    
    TableRows=new int[0];
    if(IIVrs){
     TableRows=PTable.findAll(TableMdlVart.getRows(), TableMdlVart.getColumnsType(), getVartChecksData(ByIds_VariantIds),
      getVartChecksColumn(ByIds_VariantIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Mengubah Varian");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  do{
   Updater=new Vector();
   
   List=new OCustomListModel(false); List.setColumnsInfo(TableMdlVart.getColumnsType(), 0); if(ByVect!=null){List.append(ByVect);}
   
   // Updater
   if(Edit.EditVariant){
    if(!Edit.EditVariantSub){
     switch(Edit.EditVariantMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(0, PText.getString(Edit.EditedVariant, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(0, PCore.primArr(0), List, PCore.primArr(0), 0, false, null); break;
     }
    }
    else{
     switch(Edit.EditVariantMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(0, true, Edit.EditedVariantSub, Edit.EditedVariant); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditIsActive){
    switch(Edit.EditIsActiveMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(1, Edit.EditedIsActive); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(1, PCore.primArr(0), List, PCore.primArr(0), 1, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyPrice){
    switch(Edit.EditBuyPriceMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(2, Edit.EditedBuyPrice); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(2, PCore.primArr(0), List, PCore.primArr(0), 2, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyComment){
    if(!Edit.EditBuyCommentSub){
     switch(Edit.EditBuyCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedBuyComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(3, PCore.primArr(0), List, PCore.primArr(0), 3, false, null); break;
     }
    }
    else{
     switch(Edit.EditBuyCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(3, true, Edit.EditedBuyCommentSub, Edit.EditedBuyComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditBuyUpdate){
    switch(Edit.EditBuyUpdateMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(4, Edit.EditedBuyUpdate); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(4, PCore.primArr(0), List, PCore.primArr(0), 4, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditComment){
    if(!Edit.EditCommentSub){
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterByObject(5, PText.getString(Edit.EditedComment, null, true)); break;
      case 3  : CellUpdater=new OTableCellUpdaterByList(5, PCore.primArr(0), List, PCore.primArr(0), 5, false, null); break;
     }
    }
    else{
     switch(Edit.EditCommentMode){
      case 0  : CellUpdater=new OTableCellUpdaterBySubString(5, true, Edit.EditedCommentSub, Edit.EditedComment); break;
     }
    }
    Updater.addElement(CellUpdater);
   }
   if(Edit.EditPictureFile){
    switch(Edit.EditPictureFileMode){
     case 0  : CellUpdater=new OTableCellUpdaterByObject(6, Edit.EditedPictureFile); break;
     case 3  : CellUpdater=new OTableCellUpdaterByList(6, PCore.primArr(0), List, PCore.primArr(0), 6, false, null); break;
    }
    Updater.addElement(CellUpdater);
   }
   
   if(!PMyShop.itemVartEdit(IFV.Stm, ItemIds, IsByVect, ByVect, ByIds, Edit, Progress)){break;}
   
   PGUI.changeElements(TableMdlVart, TableRows, Updater);
   
   if(IIVrs){
    VartRow=Tbl_Vart.getSelectedRow();
    fillInfoVart(VartRow);
   }
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 void removeVart(){
  int ItemRow;
  int[] VartRows;
  
  ItemRow=Tbl_Item.getSelectedRow();
  VartRows=Tbl_Vart.getSelectedRows();
  if(!PGUI.isEnabled(Btn_VartRemove) || !IIVrs || ItemRow==-1 || VartRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+VartRows.length+" varian yang dipilih ?",
   "Konfirmasi Penghapusan Varian", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!removeVart(PCore.primArr(ItemRow), ItemRow, 1, VartRows, null, null, null)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data varian !"); return;}
 }
 boolean removeVart(int[] ItemRows, int ItemRow,
  int ModeKey,
   int[] ByTable_VartRows,
   Vector<Object[]> ByVect_Data,
   String[] ByIds_VariantIds,
  OFormInformProgress Progress){
  boolean ret=false;
  long[] ItemIds=null;
  int[] TableRows=null;
  
  boolean IsByVect=false;
  Vector<Object[]> ByVect=null;
  String[] ByIds=null;
  
  ItemIds=TableItemMdl.getIds(0, ItemRows);
  switch(ModeKey){
   case 1 :
    IsByVect=true;
    ByVect=PTable.subData(TableMdlVart.getRows(), ByTable_VartRows, PCore.newIntegerArrayInOrderedSequence(TableMdlVart.getColumnsType().length, 0, 1));
    
    TableRows=ByTable_VartRows;
    break;
   case 2 :
    IsByVect=true;
    ByVect=ByVect_Data;
    
    TableRows=new int[0];
    if(IIVrs){
     TableRows=PTable.findAll(TableMdlVart.getRows(), TableMdlVart.getColumnsType(), PCore.primArr(0), ByVect_Data, PCore.primArr(0), true);
    }
    break;
   case 3 :
    IsByVect=false;
    ByIds=ByIds_VariantIds;
    
    TableRows=new int[0];
    if(IIVrs){
     TableRows=PTable.findAll(TableMdlVart.getRows(), TableMdlVart.getColumnsType(), getVartChecksData(ByIds_VariantIds),
      getVartChecksColumn(ByIds_VariantIds), true, true);
    }
    break;
  }
  
  if(Progress!=null){Progress.appear(this, "Menghapus Varian");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  
  do{
   if(!PMyShop.itemVartRemove(IFV.Stm, true, ItemIds, IsByVect, ByVect, ByIds, Progress)){break;}
   
   TableMdlVart.remove(TableRows); onSelectedRowVartChanged(true);
   
   ret=true;
  }while(false);
  
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 void setItemVartActive(boolean ActiveValue){
  int ItemRow=Tbl_Item.getSelectedRow();
  int[] VartRows=Tbl_Vart.getSelectedRows();
  OEditItemVariant Edit;
  
  if(ItemRow==-1 || VartRows.length==0){return;}
  
  Edit=new OEditItemVariant();
  Edit.EditIsActive=true; Edit.EditIsActiveMode=0; Edit.EditedIsActive=ActiveValue;
  
  if(!editVart(PCore.primArr(ItemRow), ItemRow, 1, VartRows, null, null, Edit, null)){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !"); return;}
 }
 
 void categoryEdit(){
  int[] Rows;
  int result, count;
  boolean FetchDataOld;
  Object[] UpdateData;
  OInfoIdName InfoIdName;
  OEditIdName Edit;
  OFormInformProgress Progress;
  F_EditName fm1=IFV.FEditName;
  F_IdNameModifyMulti fm2=IFV.FIdNameModifyMulti;
  
  if(!PGUI.isEnabled(Btn_Edit)){return;}
  
  Rows=List_Category.getSelectedIndices();
  count=Rows.length; if(count==0){return;}
  
  Edit=new OEditIdName();
  if(count==1){
   UpdateData=ListMdlCat.Mdl.Rows.elementAt(Rows[0]);
   fm1.wTitle="Ubah nilai Kategori Barang";
   fm1.wCurrValue=PCore.objString(UpdateData[1], null);
   fm1.wCheckEmpty=false;
   fm1.wCheckLength=150;
   fm1.wCheckAll=0;
   fm1.wCheckFirst=1;
   fm1.wCheckLast=1;
   fm1.wCheckOther=0;
   
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}
   
   FetchDataOld=true;
   InfoIdName=new OInfoIdName(true, PCore.getValueIntLong(UpdateData[0], true, -1), PCore.objString(UpdateData[1], null));
   Edit.init(true, false, null, fm1.UpdateValue);
   Progress=null;
  }
  else{
   fm2.wDataCount=count;
   
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   FetchDataOld=false;
   InfoIdName=null;
   Edit.init(true, true, fm2.NameFind, fm2.NameReplace);
   Progress=IFV.FSplashScreen;
  }
  
  result=categoryEdit(Rows, FetchDataOld, InfoIdName, Edit, Progress);
  if(result==-1){JOptionPane.showMessageDialog(null,
   "Terjadi error ketika melakukan operasi, mungkin dikarenakan :"+
   "\n- Nama kategori sudah ada."+
   "\n- Nama kategori melebihi batasan panjang kata yang diperbolehkan.");}
  else if(result==-2){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : Nama kategori sudah ada !");}
 }
 int categoryEdit(int[] Rows, boolean FetchDataOld, OInfoIdName DataOld, OEditIdName Edit, OFormInformProgress Progress){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Name has already exist
  int insertrow, idx, temp, count;
  
  Vector<OTableCellUpdater> Updater, UpdaterItemCat;
  OTableCellUpdater CellUpdater=null;
  OTableCellUpdaterSelectCheckerKey CellUpdaterItemCat_Checker=null;
  
  long[] Ids;
  Object[] objs;
  boolean Checked;
  String Name;
  
  Vector<Object[]> Edited_Data; Vector<Boolean> Edited_Checked;
  
  int increase_n_times=0;
  long increase_every_n_records=0;
  double increase_size=0;
  
  if(Progress!=null){Progress.appear(this, "Mengubah Kategori");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  do{
   // pre-processing
   count=Rows.length;
   
   Updater=new Vector(); UpdaterItemCat=new Vector();
   
   if(Edit.EditName){
    if(!Edit.ReplaceSubName){
     CellUpdater=new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedName, null, true));
    }
    else{
     CellUpdater=new OTableCellUpdaterBySubString(1, true, Edit.SubName, Edit.EditedName);
    }
    Updater.addElement(CellUpdater);
    
    CellUpdaterItemCat_Checker=new OTableCellUpdaterSelectCheckerKey(PCore.primArr(0), null, PCore.primArr(0));
    UpdaterItemCat.addElement(new OTableCellUpdaterSelect(CellUpdaterItemCat_Checker, CellUpdater, new OTableCellUpdaterByNone(1)));
   }
   
   // process : update in database
   if(Progress!=null){Progress.setProgressIncreasePercentage(65);}
   
   Ids=ListMdlCat.getIds(0, Rows);
   if(!PDatabase.editRecordsIdName(IFV.Stm, "CategoryOfItem", Ids, Edit, Progress)){break;}
   
   if(Progress!=null){Progress.setProgressIncreasePercentage(100);}
   
   // process : update GUI
   if(Progress!=null){
    increase_n_times=10;
    increase_every_n_records=count/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=count;}
    increase_size=(100-Progress.getProgress())/increase_n_times;
   }
   
   PGUI.changeElements(ListMdlCat, Rows, Updater);
   
   Edited_Data=PTable.subData(ListMdlCat.getRows(), Rows, PCore.newIntegerArrayInOrderedSequence(ListMdlCat.getColumnsCount(), 0, 1));
   Edited_Checked=ListMdlCat.getCheckList(Rows);
   
   CellUpdaterItemCat_Checker.Key=Edited_Data;
   
   ListMdlCat.remove(Rows);
   
   temp=0;
   do{
    objs=Edited_Data.elementAt(temp); Checked=Edited_Checked.elementAt(temp);
    Name=PCore.objString(objs[1], null);
    
    insertrow=PGUI.findInsertPos(ListMdlCat, 1, Name, false, true, true);
    ListMdlCat.insert(insertrow, objs); ListMdlCat.setChecked(insertrow, Checked);
    
    temp=temp+1;
    if(Progress!=null){
     if(temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
    }
   }while(temp!=count);
   
   idx=insertrow;
   List_Category.setSelectedIndex(idx); List_Category.ensureIndexIsVisible(idx);
   
   if(LastSelectedRowCat!=-1){
    LastSelectedRowCat=PCore.subtBool_Int(count==1, idx, -1);
   }
   
   // optional operation, just to update another related data with this operation
   if(TabbedPane.getSelectedIndex()==3 || IIEtc){
    PGUI.changeElements(ListMdlItemCat, PCore.newIntegerArrayInOrderedSequence(ListMdlItemCat.Mdl.Rows.size(), 0, 1), UpdaterItemCat);
   }
   
   //
   ret=0;
  }while(false);
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 //
 void focusQueryResult(){
  if(TableItemMdl.Mdl.Rows.isEmpty()){return;}
  if(Tbl_Item.getSelectedRow()==-1){Tbl_Item.changeSelection(0, 0, false, false); onTableSelectedRowChanged(false);}
  Tbl_Item.requestFocusInWindow();
 }
 void focusQuery(){
  if(LastFocusedCmpSearch==null){LastFocusedCmpSearch=TF_QName;}
  LastFocusedCmpSearch.requestFocusInWindow();
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Find = new javax.swing.ButtonGroup();
  RG_Query = new javax.swing.ButtonGroup();
  RG_Stock = new javax.swing.ButtonGroup();
  RG_UpdateStock = new javax.swing.ButtonGroup();
  RG_HasExpire = new javax.swing.ButtonGroup();
  RG_IsActive = new javax.swing.ButtonGroup();
  RG_QMismatch = new javax.swing.ButtonGroup();
  RG_ViewTransIsPreTrans = new javax.swing.ButtonGroup();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_Query = new javax.swing.JPanel();
  TF_QId = new javax.swing.JTextField();
  Btn_Query = new javax.swing.JButton();
  TF_QName = new javax.swing.JTextField();
  TF_QStock1 = new javax.swing.JTextField();
  TF_QPrice1 = new javax.swing.JTextField();
  CB_QName = new javax.swing.JCheckBox();
  CB_QCat = new javax.swing.JCheckBox();
  CB_QCheck = new javax.swing.JCheckBox();
  CB_QPrice = new javax.swing.JCheckBox();
  Btn_QCatAdd = new javax.swing.JButton();
  Btn_QCatRemove = new javax.swing.JButton();
  Lbl_QIdHelp = new javax.swing.JLabel();
  Lbl_QNameHelp = new javax.swing.JLabel();
  Lbl_QStockHelp = new javax.swing.JLabel();
  Lbl_QPriceHelp = new javax.swing.JLabel();
  CB_QComment = new javax.swing.JCheckBox();
  TF_QComment = new javax.swing.JTextField();
  Lbl_QCommentHelp = new javax.swing.JLabel();
  CmB_QCheck = new javax.swing.JComboBox<>();
  CB_QExpRange = new javax.swing.JCheckBox();
  TF_QExpRange2 = new javax.swing.JTextField();
  TF_QExpRange1 = new javax.swing.JTextField();
  Lbl_QExpRangeHelp = new javax.swing.JLabel();
  jLabel17 = new javax.swing.JLabel();
  jLabel19 = new javax.swing.JLabel();
  TF_QStock2 = new javax.swing.JTextField();
  TF_QPrice2 = new javax.swing.JTextField();
  jLabel18 = new javax.swing.JLabel();
  CB_QTag = new javax.swing.JCheckBox();
  Btn_QTagAdd = new javax.swing.JButton();
  Btn_QTagRemove = new javax.swing.JButton();
  CB_QStock = new javax.swing.JCheckBox();
  CmB_QStock = new javax.swing.JComboBox<>();
  CmB_QComment = new javax.swing.JComboBox<>();
  CB_QCatNon = new javax.swing.JCheckBox();
  CB_QTagNon = new javax.swing.JCheckBox();
  Btn_QPicAdd = new javax.swing.JButton();
  Btn_QPicRemove = new javax.swing.JButton();
  Btn_QSupAdd = new javax.swing.JButton();
  CB_QPic = new javax.swing.JCheckBox();
  CB_QPicNon = new javax.swing.JCheckBox();
  CB_QSup = new javax.swing.JCheckBox();
  CB_QSupNon = new javax.swing.JCheckBox();
  CB_QId = new javax.swing.JCheckBox();
  CmB_QId = new javax.swing.JComboBox<>();
  jLabel14 = new javax.swing.JLabel();
  CmB_QPrice = new javax.swing.JComboBox<>();
  CmB_QExpRange = new javax.swing.JComboBox<>();
  TF_QPriceUpdate2 = new javax.swing.JTextField();
  TF_QPriceUpdate1 = new javax.swing.JTextField();
  CB_QPriceUpdate = new javax.swing.JCheckBox();
  CmB_QPriceUpdate = new javax.swing.JComboBox<>();
  Lbl_QPriceUpdateHelp = new javax.swing.JLabel();
  jLabel9 = new javax.swing.JLabel();
  CB_QOrderPack = new javax.swing.JCheckBox();
  CmB_QOrderPack = new javax.swing.JComboBox<>();
  Lbl_QOrderPackHelp = new javax.swing.JLabel();
  TF_QOrderPack1 = new javax.swing.JTextField();
  jLabel13 = new javax.swing.JLabel();
  TF_QOrderPack2 = new javax.swing.JTextField();
  CB_QOrder = new javax.swing.JCheckBox();
  CmB_QOrder = new javax.swing.JComboBox<>();
  Lbl_QOrderHelp = new javax.swing.JLabel();
  TF_QOrder1 = new javax.swing.JTextField();
  jLabel21 = new javax.swing.JLabel();
  TF_QOrder2 = new javax.swing.JTextField();
  CB_QStockUnit = new javax.swing.JCheckBox();
  CB_QStockUnitEmpty = new javax.swing.JCheckBox();
  Btn_QStockUnitAdd = new javax.swing.JButton();
  Btn_QStockUnitRemove = new javax.swing.JButton();
  Btn_QSupRemove = new javax.swing.JButton();
  TF_QExpList = new javax.swing.JTextField();
  CB_QExpList = new javax.swing.JCheckBox();
  Lbl_QExpListHelp = new javax.swing.JLabel();
  CmB_QExpList = new javax.swing.JComboBox<>();
  jScrollPane24 = new javax.swing.JScrollPane();
  List_QStockUnit = new XList();
  jScrollPane25 = new javax.swing.JScrollPane();
  List_QCat = new XList();
  jScrollPane5 = new javax.swing.JScrollPane();
  List_QTag = new XList();
  jScrollPane13 = new javax.swing.JScrollPane();
  List_QPic = new XList();
  jScrollPane8 = new javax.swing.JScrollPane();
  List_QSup = new XList();
  Panel_CategorizedView = new javax.swing.JPanel();
  jPanel2 = new javax.swing.JPanel();
  TF_CategoryCount = new javax.swing.JTextField();
  TF_CategoryCheckedCount = new javax.swing.JTextField();
  Btn_CatRefresh = new javax.swing.JButton();
  CmB_CatQueryType = new javax.swing.JComboBox<>();
  Btn_TempListAddByCategory = new javax.swing.JButton();
  Btn_TempListRemoveByCategory = new javax.swing.JButton();
  jPanel4 = new javax.swing.JPanel();
  Btn_FCatNext = new javax.swing.JButton();
  Btn_FCatBefore = new javax.swing.JButton();
  TF_FindCategory = new javax.swing.JTextField();
  Pnl_CatModify = new javax.swing.JPanel();
  Btn_CatAdd = new javax.swing.JButton();
  Btn_CatEdit = new javax.swing.JButton();
  Btn_CatRemove = new javax.swing.JButton();
  jScrollPane15 = new javax.swing.JScrollPane();
  List_Category = new XList();
  Panel_ItemDetail = new javax.swing.JPanel();
  jLabel5 = new javax.swing.JLabel();
  TF_DetStock = new javax.swing.JTextField();
  CB_DetIsActive = new javax.swing.JCheckBox();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_DetSell = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_DetBuy = new javax.swing.JTextArea();
  jLabel3 = new javax.swing.JLabel();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_DetComment = new javax.swing.JTextArea();
  jScrollPane10 = new javax.swing.JScrollPane();
  TA_DetIdName = new javax.swing.JTextArea();
  TF_DetExpire = new javax.swing.JTextField();
  jSeparator2 = new javax.swing.JSeparator();
  jSeparator3 = new javax.swing.JSeparator();
  jSeparator4 = new javax.swing.JSeparator();
  CmB_DetBuy = new javax.swing.JComboBox<>();
  CmB_DetSell = new javax.swing.JComboBox<>();
  CB_DetSell = new javax.swing.JCheckBox();
  CB_DetBuy = new javax.swing.JCheckBox();
  jLabel2 = new javax.swing.JLabel();
  jLabel4 = new javax.swing.JLabel();
  jLabel10 = new javax.swing.JLabel();
  TF_DetOrderSpec = new javax.swing.JTextField();
  CB_DetUpdateStock = new javax.swing.JCheckBox();
  CB_DetIsReorder = new javax.swing.JCheckBox();
  CB_DetExp = new javax.swing.JCheckBox();
  CB_DetIsOpname = new javax.swing.JCheckBox();
  Panel_ItemEtc = new javax.swing.JPanel();
  jPanel10 = new javax.swing.JPanel();
  Btn_ItemCategoryAdd = new javax.swing.JButton();
  Btn_ItemCategoryRemove = new javax.swing.JButton();
  jLabel12 = new javax.swing.JLabel();
  jScrollPane4 = new javax.swing.JScrollPane();
  List_ItemCategory = new XList();
  jPanel11 = new javax.swing.JPanel();
  Btn_ItemTagAdd = new javax.swing.JButton();
  Btn_ItemTagRemove = new javax.swing.JButton();
  jLabel16 = new javax.swing.JLabel();
  jScrollPane7 = new javax.swing.JScrollPane();
  List_ItemTag = new XList();
  Panel_ItemPicture = new javax.swing.JPanel();
  Btn_ItemPictureAdd = new javax.swing.JButton();
  Btn_ItemPictureRemove = new javax.swing.JButton();
  Panel_Image = new XImgBoxURL();
  jScrollPane12 = new javax.swing.JScrollPane();
  List_ItemPicture = new XList();
  Panel_ItemVariant = new javax.swing.JPanel();
  jPanel12 = new javax.swing.JPanel();
  Btn_SecAdd = new javax.swing.JButton();
  Btn_SecEdit = new javax.swing.JButton();
  Btn_SecRemove = new javax.swing.JButton();
  jLabel22 = new javax.swing.JLabel();
  jScrollPane11 = new javax.swing.JScrollPane();
  List_Sec = new XList();
  jPanel24 = new javax.swing.JPanel();
  jScrollPane23 = new javax.swing.JScrollPane();
  Tbl_Vart = new XTable();
  Btn_VartRemove = new javax.swing.JButton();
  Btn_VartEdit = new javax.swing.JButton();
  Btn_VartAdd = new javax.swing.JButton();
  jPanel25 = new javax.swing.JPanel();
  Pnl_VartInfoPreview = new XImgBoxURL();
  jPanel26 = new javax.swing.JPanel();
  jPanel27 = new javax.swing.JPanel();
  CB_VartViewComment = new javax.swing.JToggleButton();
  CB_VartViewBuyPrice = new javax.swing.JToggleButton();
  CB_VartViewBuyComment = new javax.swing.JToggleButton();
  CB_VartViewBuyUpdate = new javax.swing.JToggleButton();
  jPanel28 = new javax.swing.JPanel();
  jScrollPane20 = new javax.swing.JScrollPane();
  TA_VartInfoBuy = new javax.swing.JTextArea();
  jScrollPane22 = new javax.swing.JScrollPane();
  TA_VartInfoName = new javax.swing.JTextArea();
  Btn_VartActiveAdd = new javax.swing.JButton();
  Btn_VartActiveRemove = new javax.swing.JButton();
  jLabel35 = new javax.swing.JLabel();
  jLabel34 = new javax.swing.JLabel();
  Panel_ItemSupplier = new javax.swing.JPanel();
  Btn_SuppRemove = new javax.swing.JButton();
  Btn_SuppEdit = new javax.swing.JButton();
  Btn_SuppAdd = new javax.swing.JButton();
  Btn_SuppTempListAdd = new javax.swing.JButton();
  Btn_SuppTempListRemove = new javax.swing.JButton();
  jLabel8 = new javax.swing.JLabel();
  jPanel13 = new javax.swing.JPanel();
  Btn_SuppFindBef = new javax.swing.JButton();
  Btn_SuppFindNext = new javax.swing.JButton();
  TF_SuppFind = new javax.swing.JTextField();
  CmB_SuppFind = new javax.swing.JComboBox<>();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_Supp = new XTable();
  Btn_SuppActiveRemove = new javax.swing.JButton();
  Btn_SuppActiveAdd = new javax.swing.JButton();
  jLabel30 = new javax.swing.JLabel();
  Btn_SuppInfo = new javax.swing.JButton();
  jPanel1 = new javax.swing.JPanel();
  jPanel8 = new javax.swing.JPanel();
  CB_SuppViewBuyUpdate = new javax.swing.JToggleButton();
  CB_SuppViewBuyComment = new javax.swing.JToggleButton();
  CB_SuppViewBuyPrc = new javax.swing.JToggleButton();
  jPanel23 = new javax.swing.JPanel();
  CB_SuppInfoActive = new javax.swing.JCheckBox();
  TF_SuppInfoName = new javax.swing.JTextField();
  jScrollPane9 = new javax.swing.JScrollPane();
  TA_SuppInfoBuy = new javax.swing.JTextArea();
  Panel_Trans = new javax.swing.JPanel();
  jPanel14 = new javax.swing.JPanel();
  CmB_TransType = new javax.swing.JComboBox<>();
  jLabel1 = new javax.swing.JLabel();
  jLabel23 = new javax.swing.JLabel();
  RB_TransIsPreTransN = new javax.swing.JRadioButton();
  RB_TransIsPreTransY = new javax.swing.JRadioButton();
  CmB_TransSubject = new javax.swing.JComboBox<>();
  jLabel26 = new javax.swing.JLabel();
  Btn_TransSubjectInfo = new javax.swing.JButton();
  TabbedPane_TransList = new javax.swing.JTabbedPane();
  Panel_TransIn = new javax.swing.JPanel();
  jScrollPane14 = new javax.swing.JScrollPane();
  Tbl_TransIn = new XTable();
  jPanel20 = new javax.swing.JPanel();
  CB_TransInDate = new javax.swing.JToggleButton();
  CB_TransInType = new javax.swing.JToggleButton();
  CB_TransInSubject = new javax.swing.JToggleButton();
  CB_TransInSalesman = new javax.swing.JToggleButton();
  CB_TransInId = new javax.swing.JToggleButton();
  CB_TransInIdExternal = new javax.swing.JToggleButton();
  CB_TransInItemComment = new javax.swing.JToggleButton();
  CB_TransInPriceUnit = new javax.swing.JToggleButton();
  CB_TransInPriceTotal = new javax.swing.JToggleButton();
  jPanel21 = new javax.swing.JPanel();
  Btn_TransInFindNext = new javax.swing.JButton();
  Btn_TransInFindBef = new javax.swing.JButton();
  TF_TransInFind = new javax.swing.JTextField();
  CmB_TransInFind = new javax.swing.JComboBox<>();
  jPanel19 = new javax.swing.JPanel();
  Btn_TransInSalesmanTempListRemove = new javax.swing.JButton();
  Btn_TransInSalesmanTempListAdd = new javax.swing.JButton();
  jLabel24 = new javax.swing.JLabel();
  Btn_TransInSubjectTempListRemove = new javax.swing.JButton();
  Btn_TransInSubjectTempListAdd = new javax.swing.JButton();
  jLabel25 = new javax.swing.JLabel();
  Btn_TransInSalesmanInfo = new javax.swing.JButton();
  Btn_TransInSubjectInfo = new javax.swing.JButton();
  Btn_TransInTransInfo = new javax.swing.JButton();
  Btn_TransInTransTempListRemove = new javax.swing.JButton();
  Btn_TransInTransTempListAdd = new javax.swing.JButton();
  jLabel31 = new javax.swing.JLabel();
  Panel_TransOut = new javax.swing.JPanel();
  jScrollPane19 = new javax.swing.JScrollPane();
  Tbl_TransOut = new XTable();
  jPanel15 = new javax.swing.JPanel();
  CB_TransOutDate = new javax.swing.JToggleButton();
  CB_TransOutType = new javax.swing.JToggleButton();
  CB_TransOutSubject = new javax.swing.JToggleButton();
  CB_TransOutSalesman = new javax.swing.JToggleButton();
  CB_TransOutId = new javax.swing.JToggleButton();
  CB_TransOutIdExternal = new javax.swing.JToggleButton();
  CB_TransOutItemComment = new javax.swing.JToggleButton();
  CB_TransOutPriceUnit = new javax.swing.JToggleButton();
  CB_TransOutPriceTotal = new javax.swing.JToggleButton();
  CB_TransOutPriceBasic = new javax.swing.JToggleButton();
  jPanel18 = new javax.swing.JPanel();
  Btn_TransOutFindNext = new javax.swing.JButton();
  Btn_TransOutFindBef = new javax.swing.JButton();
  CmB_TransOutFind = new javax.swing.JComboBox<>();
  TF_TransOutFind = new javax.swing.JTextField();
  jPanel22 = new javax.swing.JPanel();
  Btn_TransOutSalesmanTempListRemove = new javax.swing.JButton();
  Btn_TransOutSalesmanTempListAdd = new javax.swing.JButton();
  jLabel27 = new javax.swing.JLabel();
  Btn_TransOutSubjectTempListRemove = new javax.swing.JButton();
  Btn_TransOutSubjectTempListAdd = new javax.swing.JButton();
  jLabel28 = new javax.swing.JLabel();
  Btn_TransOutSalesmanInfo = new javax.swing.JButton();
  Btn_TransOutSubjectInfo = new javax.swing.JButton();
  Btn_TransOutTransInfo = new javax.swing.JButton();
  Btn_TransOutTransTempListRemove = new javax.swing.JButton();
  Btn_TransOutTransTempListAdd = new javax.swing.JButton();
  jLabel32 = new javax.swing.JLabel();
  jPanel5 = new javax.swing.JPanel();
  jPanel6 = new javax.swing.JPanel();
  TF_QueryCount = new javax.swing.JTextField();
  TF_QueryTempListCount = new javax.swing.JTextField();
  CmB_ResultFilterExpire = new javax.swing.JComboBox<>();
  CmB_ResultFilterUpdateStock = new javax.swing.JComboBox<>();
  CmB_ResultFilterActive = new javax.swing.JComboBox<>();
  CmB_ResultFilterSubset = new javax.swing.JComboBox<>();
  Btn_QueryRefresh = new javax.swing.JButton();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel15 = new javax.swing.JLabel();
  Btn_TempListClear = new javax.swing.JButton();
  CmB_ResultFilterIsReorder = new javax.swing.JComboBox<>();
  CmB_ResultFilterIsOpname = new javax.swing.JComboBox<>();
  jPanel7 = new javax.swing.JPanel();
  Btn_Choose = new javax.swing.JButton();
  Lbl_MultipleSelection = new javax.swing.JLabel();
  Btn_New = new javax.swing.JButton();
  Btn_Edit = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  Btn_Report = new javax.swing.JButton();
  CmB_ReportType = new javax.swing.JComboBox<>();
  jPanel9 = new javax.swing.JPanel();
  Btn_MultipleItemsSupRemove = new javax.swing.JButton();
  Btn_MultipleItemsSupAdd = new javax.swing.JButton();
  jLabel11 = new javax.swing.JLabel();
  Btn_MultipleItemsPicRemove = new javax.swing.JButton();
  Btn_MultipleItemsPicAdd = new javax.swing.JButton();
  jLabel7 = new javax.swing.JLabel();
  Btn_MultipleItemsTagRemove = new javax.swing.JButton();
  Btn_MultipleItemsTagAdd = new javax.swing.JButton();
  jLabel20 = new javax.swing.JLabel();
  Btn_MultipleItemsCategoryRemove = new javax.swing.JButton();
  Btn_MultipleItemsCategoryAdd = new javax.swing.JButton();
  jLabel6 = new javax.swing.JLabel();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBefore = new javax.swing.JButton();
  CmB_Find = new javax.swing.JComboBox<>();
  TF_Find = new javax.swing.JTextField();
  Btn_MultipleItemsActiveRemove = new javax.swing.JButton();
  Btn_MultipleItemsActiveAdd = new javax.swing.JButton();
  jLabel29 = new javax.swing.JLabel();
  Btn_MultipleItemsIsReorderRemove = new javax.swing.JButton();
  Btn_MultipleItemsIsReorderAdd = new javax.swing.JButton();
  jLabel33 = new javax.swing.JLabel();
  Btn_MultipleItemsVartRemove = new javax.swing.JButton();
  Btn_MultipleItemsVartAdd = new javax.swing.JButton();
  jLabel36 = new javax.swing.JLabel();
  Btn_MultipleItemsIsOpnameRemove = new javax.swing.JButton();
  Btn_MultipleItemsIsOpnameAdd = new javax.swing.JButton();
  jLabel37 = new javax.swing.JLabel();
  jScrollPane18 = new javax.swing.JScrollPane();
  Tbl_Item = new XTable();
  Pnl_Checker = new javax.swing.JPanel();
  Pnl_CheckerItemPreview = new XImgBoxURL();
  jPanel16 = new javax.swing.JPanel();
  jPanel17 = new javax.swing.JPanel();
  jScrollPane21 = new javax.swing.JScrollPane();
  TA_CheckerItemName = new javax.swing.JTextArea();
  jPanel3 = new javax.swing.JPanel();
  CmB_ViewMode = new javax.swing.JComboBox<>();
  Pnl_ViewNormalMode = new javax.swing.JPanel();
  CB_ViewHasExp = new javax.swing.JToggleButton();
  CB_ViewExpThreshold = new javax.swing.JToggleButton();
  CB_ViewExpCheckPeriod = new javax.swing.JToggleButton();
  CB_ViewSellUpdate = new javax.swing.JToggleButton();
  CB_ViewSellPriceComment = new javax.swing.JToggleButton();
  CB_ViewSellPrice = new javax.swing.JToggleButton();
  CB_ViewBuyUpdate = new javax.swing.JToggleButton();
  CB_ViewBuyPriceComment = new javax.swing.JToggleButton();
  CB_ViewBuyPrice = new javax.swing.JToggleButton();
  CB_ViewStockIsUpdate = new javax.swing.JToggleButton();
  CB_ViewStockUnit = new javax.swing.JToggleButton();
  CB_ViewOrderPackMin = new javax.swing.JToggleButton();
  CB_ViewOrderPackThreshold = new javax.swing.JToggleButton();
  CB_ViewOrderPackQty = new javax.swing.JToggleButton();
  CB_ViewIsReorder = new javax.swing.JToggleButton();
  CB_ViewIsOpname = new javax.swing.JToggleButton();
  CB_ViewStockMinMax = new javax.swing.JToggleButton();
  CB_ViewStockEst = new javax.swing.JToggleButton();
  CB_ViewStockPre = new javax.swing.JToggleButton();
  CB_ViewStock = new javax.swing.JToggleButton();
  Pnl_CheckerInfo = new javax.swing.JPanel();
  TF_CheckerInfo = new javax.swing.JTextField();
  Btn_CheckerP1 = new javax.swing.JButton();
  Btn_CheckerP2 = new javax.swing.JButton();
  CB_ViewCategorized = new javax.swing.JToggleButton();
  Pnl_CheckerInput = new javax.swing.JPanel();
  TF_CheckerAttr2 = new javax.swing.JTextField();
  CmB_CheckerAttr2 = new javax.swing.JComboBox<>();
  CB_CheckerAttr2 = new javax.swing.JCheckBox();
  TF_CheckerAttr1 = new javax.swing.JTextField();
  CmB_CheckerAttr1 = new javax.swing.JComboBox<>();
  CB_CheckerAttr1 = new javax.swing.JCheckBox();
  TF_CheckerItemId = new javax.swing.JTextField();
  CmB_CheckerIdInput = new javax.swing.JComboBox<>();
  Btn_CheckerExecute = new javax.swing.JButton();

  setTitle("Item");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TabbedPane.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
  TabbedPane.setToolTipText("");
  TabbedPane.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N

  Panel_Query.setPreferredSize(new java.awt.Dimension(380, 630));

  TF_QId.setToolTipText("");
  TF_QId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QIdFocusGained(evt);
   }
  });
  TF_QId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QIdKeyPressed(evt);
   }
  });

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setToolTipText("");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });
  Btn_Query.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QueryKeyPressed(evt);
   }
  });

  TF_QName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QNameFocusGained(evt);
   }
  });
  TF_QName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QNameKeyPressed(evt);
   }
  });

  TF_QStock1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QStock1FocusGained(evt);
   }
  });
  TF_QStock1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QStock1KeyPressed(evt);
   }
  });

  TF_QPrice1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QPrice1FocusGained(evt);
   }
  });
  TF_QPrice1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QPrice1KeyPressed(evt);
   }
  });

  CB_QName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QName.setText("Nama");
  CB_QName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QNameKeyPressed(evt);
   }
  });

  CB_QCat.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QCat.setText("Ktgr...");
  CB_QCat.setToolTipText("kategori barang");
  CB_QCat.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCat.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCatKeyPressed(evt);
   }
  });

  CB_QCheck.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QCheck.setText("Cek");
  CB_QCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCheckKeyPressed(evt);
   }
  });

  CB_QPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPriceKeyPressed(evt);
   }
  });

  Btn_QCatAdd.setText("+");
  Btn_QCatAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCatAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCatAddActionPerformed(evt);
   }
  });
  Btn_QCatAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCatAddKeyPressed(evt);
   }
  });

  Btn_QCatRemove.setText("-");
  Btn_QCatRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCatRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCatRemoveActionPerformed(evt);
   }
  });
  Btn_QCatRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCatRemoveKeyPressed(evt);
   }
  });

  Lbl_QIdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QIdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QIdHelp.setText("(?)");
  Lbl_QIdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QIdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QIdHelpMouseClicked(evt);
   }
  });

  Lbl_QNameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QNameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QNameHelp.setText("(?)");
  Lbl_QNameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QNameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QNameHelpMouseClicked(evt);
   }
  });

  Lbl_QStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QStockHelp.setText("(?)");
  Lbl_QStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QStockHelpMouseClicked(evt);
   }
  });

  Lbl_QPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QPriceHelp.setText("(?)");
  Lbl_QPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QPriceHelpMouseClicked(evt);
   }
  });

  CB_QComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QComment.setToolTipText("mencari pd ket. tambahan, ket. hrg jual, & ket. hrg beli");
  CB_QComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCommentKeyPressed(evt);
   }
  });

  TF_QComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QCommentFocusGained(evt);
   }
  });
  TF_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QCommentKeyPressed(evt);
   }
  });

  Lbl_QCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QCommentHelp.setText("(?)");
  Lbl_QCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QCommentHelpMouseClicked(evt);
   }
  });

  CmB_QCheck.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Op Cari) Stok Diperbarui (Op)", "Op Cari) Stok Diperbarui", "Op Cari) Stok < 0", "Op Cari) Berkadaluarsa (Op)", "Op Cari) Berkadaluarsa", "Op Hasil) Op Stok = Reset", "Op Hasil) Op Stok != Reset", "Op Hasil) Op Stok != 0", "Op Hasil) Op Stok = 0", "Op Hasil) Op Exp = Reset", "Op Hasil) Op Exp != Reset", "Op Hasil) Op Exp <= Jelang Exp", "Op Hasil) Op Exp > Jelang Exp", "Ord Cari) Kisaran Stok < Stok Min (R)", "Ord Cari) Kisaran Stok < Stok Max (R)", "Ord Cari) Kisaran Stok < Stok Min", "Ord Cari) Kisaran Stok < Stok Max", "Ord Hasil) Order Qty = Reset", "Ord Hasil) Order Qty != Reset", "Ord Hasil) Order Qty > 0", "Ord Hasil) Order Qty = 0", "Kis Stok + Ord Qty = St Min ... Max", "Kis Stok + Ord Qty < St Min", "Kis Stok + Ord Qty > St Max", "Dll) Stok Min > Stok Max", "Dll) Non Kategori", "Dll) Memiliki Kategori > 1", "Dll) Memiliki Secondary Id", "Dll) Memiliki Varian", "Dll) Non Varian", "Dll) Id Duplikat", "Dll) Id Utama != EAN-8/13" }));
  CmB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCheckKeyPressed(evt);
   }
  });

  CB_QExpRange.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QExpRange.setToolTipText("");
  CB_QExpRange.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QExpRange.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QExpRangeKeyPressed(evt);
   }
  });

  TF_QExpRange2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QExpRange2FocusGained(evt);
   }
  });
  TF_QExpRange2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QExpRange2KeyPressed(evt);
   }
  });

  TF_QExpRange1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QExpRange1FocusGained(evt);
   }
  });
  TF_QExpRange1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QExpRange1KeyPressed(evt);
   }
  });

  Lbl_QExpRangeHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QExpRangeHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QExpRangeHelp.setText("(?)");
  Lbl_QExpRangeHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QExpRangeHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QExpRangeHelpMouseClicked(evt);
   }
  });

  jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel17.setText("-");

  jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel19.setText("-");

  TF_QStock2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QStock2FocusGained(evt);
   }
  });
  TF_QStock2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QStock2KeyPressed(evt);
   }
  });

  TF_QPrice2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QPrice2FocusGained(evt);
   }
  });
  TF_QPrice2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QPrice2KeyPressed(evt);
   }
  });

  jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel18.setText("-");

  CB_QTag.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QTag.setText("Tag...");
  CB_QTag.setToolTipText("tag barang");
  CB_QTag.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QTag.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QTagKeyPressed(evt);
   }
  });

  Btn_QTagAdd.setText("+");
  Btn_QTagAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QTagAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QTagAddActionPerformed(evt);
   }
  });
  Btn_QTagAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QTagAddKeyPressed(evt);
   }
  });

  Btn_QTagRemove.setText("-");
  Btn_QTagRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QTagRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QTagRemoveActionPerformed(evt);
   }
  });
  Btn_QTagRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QTagRemoveKeyPressed(evt);
   }
  });

  CB_QStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QStockKeyPressed(evt);
   }
  });

  CmB_QStock.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QStock.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Stok", "Pr-Msk", "Pr-Klr", "Kis", "Min", "Max" }));
  CmB_QStock.setToolTipText("Pilih 'Stok', 'Stok Minimal', 'Stok Maksimal'");
  CmB_QStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QStockKeyPressed(evt);
   }
  });

  CmB_QComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QComment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ket", "Beli", "Jual" }));
  CmB_QComment.setToolTipText("Pilih 'Keterangan', 'Keterangan Harga Beli', 'Keterangan Harga Jual'");
  CmB_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCommentKeyPressed(evt);
   }
  });

  CB_QCatNon.setText("non");
  CB_QCatNon.setToolTipText("centang utk mengikutsertakan barang yg tdk memiliki daftar kategori");
  CB_QCatNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCatNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCatNonKeyPressed(evt);
   }
  });

  CB_QTagNon.setText("non");
  CB_QTagNon.setToolTipText("centang utk mengikutsertakan barang yg tdk memiliki daftar tag");
  CB_QTagNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QTagNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QTagNonKeyPressed(evt);
   }
  });

  Btn_QPicAdd.setText("+");
  Btn_QPicAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QPicAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QPicAddActionPerformed(evt);
   }
  });
  Btn_QPicAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QPicAddKeyPressed(evt);
   }
  });

  Btn_QPicRemove.setText("-");
  Btn_QPicRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QPicRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QPicRemoveActionPerformed(evt);
   }
  });
  Btn_QPicRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QPicRemoveKeyPressed(evt);
   }
  });

  Btn_QSupAdd.setText("+");
  Btn_QSupAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSupAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSupAddActionPerformed(evt);
   }
  });
  Btn_QSupAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSupAddKeyPressed(evt);
   }
  });

  CB_QPic.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QPic.setText("Gbr...");
  CB_QPic.setToolTipText("gambar barang");
  CB_QPic.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPicKeyPressed(evt);
   }
  });

  CB_QPicNon.setText("non");
  CB_QPicNon.setToolTipText("centang utk mengikutsertakan barang yg tdk memiliki daftar gambar");
  CB_QPicNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPicNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPicNonKeyPressed(evt);
   }
  });

  CB_QSup.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QSup.setText("Sup...");
  CB_QSup.setToolTipText("suplier / distributor");
  CB_QSup.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSup.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSupKeyPressed(evt);
   }
  });

  CB_QSupNon.setText("non");
  CB_QSupNon.setToolTipText("centang utk mengikutsertakan barang yg tdk memiliki daftar suplier");
  CB_QSupNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSupNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSupNonKeyPressed(evt);
   }
  });

  CB_QId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QIdKeyPressed(evt);
   }
  });

  CmB_QId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QId.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id", "Sub" }));
  CmB_QId.setToolTipText("Pilih 'Id', 'Sub-Id (mencari dalam sub-bagian Id)'");
  CmB_QId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QIdKeyPressed(evt);
   }
  });

  jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel14.setText("-- Filter (kosongkan smua utk cari smua)");

  CmB_QPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QPrice.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "H-Jual", "H-Beli" }));
  CmB_QPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QPriceKeyPressed(evt);
   }
  });

  CmB_QExpRange.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QExpRange.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ck Exp", "Bt Exp" }));
  CmB_QExpRange.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QExpRangeKeyPressed(evt);
   }
  });

  TF_QPriceUpdate2.setToolTipText("Tanggal B (format input : tahun-bulan-tanggal, contohnya 2018-03-17)");
  TF_QPriceUpdate2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QPriceUpdate2FocusGained(evt);
   }
  });
  TF_QPriceUpdate2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QPriceUpdate2KeyPressed(evt);
   }
  });

  TF_QPriceUpdate1.setToolTipText("Tanggal A (format input : tahun-bulan-tanggal, contohnya 2018-03-17)");
  TF_QPriceUpdate1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QPriceUpdate1FocusGained(evt);
   }
  });
  TF_QPriceUpdate1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QPriceUpdate1KeyPressed(evt);
   }
  });

  CB_QPriceUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPriceUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPriceUpdateKeyPressed(evt);
   }
  });

  CmB_QPriceUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QPriceUpdate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pbr Jual", "Pbr Beli" }));
  CmB_QPriceUpdate.setToolTipText("pilih tanggal pembaruan harga");
  CmB_QPriceUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QPriceUpdateKeyPressed(evt);
   }
  });

  Lbl_QPriceUpdateHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QPriceUpdateHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QPriceUpdateHelp.setText("(?)");
  Lbl_QPriceUpdateHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QPriceUpdateHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QPriceUpdateHelpMouseClicked(evt);
   }
  });

  jLabel9.setText("-");

  CB_QOrderPack.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QOrderPack.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QOrderPackKeyPressed(evt);
   }
  });

  CmB_QOrderPack.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QOrderPack.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pk-Qty", "Pk-%", "Pk-Min" }));
  CmB_QOrderPack.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QOrderPackKeyPressed(evt);
   }
  });

  Lbl_QOrderPackHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QOrderPackHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QOrderPackHelp.setText("(?)");
  Lbl_QOrderPackHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QOrderPackHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QOrderPackHelpMouseClicked(evt);
   }
  });

  TF_QOrderPack1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QOrderPack1FocusGained(evt);
   }
  });
  TF_QOrderPack1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QOrderPack1KeyPressed(evt);
   }
  });

  jLabel13.setText("-");

  TF_QOrderPack2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QOrderPack2FocusGained(evt);
   }
  });
  TF_QOrderPack2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QOrderPack2KeyPressed(evt);
   }
  });

  CB_QOrder.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QOrder.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QOrderKeyPressed(evt);
   }
  });

  CmB_QOrder.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QOrder.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Odr-Qty", "Odr-Hrg" }));
  CmB_QOrder.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QOrderKeyPressed(evt);
   }
  });

  Lbl_QOrderHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QOrderHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QOrderHelp.setText("(?)");
  Lbl_QOrderHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QOrderHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QOrderHelpMouseClicked(evt);
   }
  });

  TF_QOrder1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QOrder1FocusGained(evt);
   }
  });
  TF_QOrder1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QOrder1KeyPressed(evt);
   }
  });

  jLabel21.setText("-");

  TF_QOrder2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QOrder2FocusGained(evt);
   }
  });
  TF_QOrder2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QOrder2KeyPressed(evt);
   }
  });

  CB_QStockUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QStockUnit.setText("Sat-Stok...");
  CB_QStockUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QStockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QStockUnitKeyPressed(evt);
   }
  });

  CB_QStockUnitEmpty.setText("kosong");
  CB_QStockUnitEmpty.setToolTipText("centang utk mengikutsertakan barang dgn satuan stok yg tidak didefenisikan");
  CB_QStockUnitEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QStockUnitEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QStockUnitEmptyKeyPressed(evt);
   }
  });

  Btn_QStockUnitAdd.setText("+");
  Btn_QStockUnitAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QStockUnitAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QStockUnitAddActionPerformed(evt);
   }
  });
  Btn_QStockUnitAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QStockUnitAddKeyPressed(evt);
   }
  });

  Btn_QStockUnitRemove.setText("-");
  Btn_QStockUnitRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QStockUnitRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QStockUnitRemoveActionPerformed(evt);
   }
  });
  Btn_QStockUnitRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QStockUnitRemoveKeyPressed(evt);
   }
  });

  Btn_QSupRemove.setText("-");
  Btn_QSupRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSupRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSupRemoveActionPerformed(evt);
   }
  });
  Btn_QSupRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSupRemoveKeyPressed(evt);
   }
  });

  TF_QExpList.setToolTipText("Format input : angka, angka, dst ... ; Contohnya : 0, 1, 3, 7, 15, 30");
  TF_QExpList.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QExpListFocusGained(evt);
   }
  });
  TF_QExpList.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QExpListKeyPressed(evt);
   }
  });

  CB_QExpList.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QExpList.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QExpList.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QExpListKeyPressed(evt);
   }
  });

  Lbl_QExpListHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QExpListHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QExpListHelp.setText("(?)");
  Lbl_QExpListHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QExpListHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QExpListHelpMouseClicked(evt);
   }
  });

  CmB_QExpList.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_QExpList.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ck Exp", "Bt Exp" }));
  CmB_QExpList.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QExpListKeyPressed(evt);
   }
  });

  List_QStockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QStockUnitKeyReleased(evt);
   }
  });
  jScrollPane24.setViewportView(List_QStockUnit);

  List_QCat.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QCatKeyReleased(evt);
   }
  });
  jScrollPane25.setViewportView(List_QCat);

  List_QTag.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QTagKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(List_QTag);

  List_QPic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QPicKeyReleased(evt);
   }
  });
  jScrollPane13.setViewportView(List_QPic);

  List_QSup.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QSupKeyReleased(evt);
   }
  });
  jScrollPane8.setViewportView(List_QSup);

  javax.swing.GroupLayout Panel_QueryLayout = new javax.swing.GroupLayout(Panel_Query);
  Panel_Query.setLayout(Panel_QueryLayout);
  Panel_QueryLayout.setHorizontalGroup(
   Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addComponent(jLabel14)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QName)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QNameHelp))
     .addComponent(CB_QCat)
     .addComponent(CB_QTag)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QComment)
      .addGap(0, 0, 0)
      .addComponent(CmB_QComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QCommentHelp))
     .addComponent(CB_QPic)
     .addComponent(CB_QSup)
     .addComponent(CB_QCheck)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QId)
      .addGap(0, 0, 0)
      .addComponent(CmB_QId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QIdHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QStock)
      .addGap(0, 0, 0)
      .addComponent(CmB_QStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QStockHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QExpRange)
      .addGap(0, 0, 0)
      .addComponent(CmB_QExpRange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QExpRangeHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QPriceUpdate)
      .addGap(0, 0, 0)
      .addComponent(CmB_QPriceUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QPriceUpdateHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QPrice)
      .addGap(0, 0, 0)
      .addComponent(CmB_QPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QPriceHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QOrderPack)
      .addGap(0, 0, 0)
      .addComponent(CmB_QOrderPack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QOrderPackHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QOrder)
      .addGap(0, 0, 0)
      .addComponent(CmB_QOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QOrderHelp))
     .addComponent(CB_QStockUnit)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QExpList)
      .addGap(0, 0, 0)
      .addComponent(CmB_QExpList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QExpListHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_QCatNon)
       .addComponent(CB_QTagNon)
       .addComponent(CB_QPicNon)
       .addComponent(CB_QSupNon)
       .addComponent(CB_QStockUnitEmpty))))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QCatAdd, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Btn_QCatRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QTagAdd, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Btn_QTagRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addComponent(CmB_QCheck, 0, 273, Short.MAX_VALUE)
     .addComponent(TF_QId)
     .addComponent(TF_QName)
     .addComponent(TF_QComment)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
       .addComponent(TF_QOrder1)
       .addComponent(TF_QOrderPack1, javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_QPriceUpdate1)
       .addComponent(TF_QExpRange1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
       .addComponent(TF_QStock1)
       .addComponent(TF_QPrice1))
      .addGap(2, 2, 2)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(jLabel18)
         .addComponent(jLabel9)
         .addComponent(jLabel17))
        .addGap(1, 1, 1)
        .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(TF_QPrice2)
         .addComponent(TF_QPriceUpdate2)
         .addComponent(TF_QExpRange2)))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(jLabel19)
         .addComponent(jLabel13))
        .addGap(2, 2, 2)
        .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(TF_QOrderPack2)
         .addComponent(TF_QStock2)))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(jLabel21)
        .addGap(2, 2, 2)
        .addComponent(TF_QOrder2))))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QStockUnitAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QStockUnitRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
       .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
       .addComponent(Btn_QPicRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QPicAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QSupAdd)
       .addComponent(Btn_QSupRemove, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addComponent(TF_QExpList)))
  );
  Panel_QueryLayout.setVerticalGroup(
   Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Query)
     .addComponent(jLabel14))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_QCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QCheck))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QIdHelp)
     .addComponent(CB_QId)
     .addComponent(CmB_QId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QName)
     .addComponent(TF_QName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QNameHelp))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QComment, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_QComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_QCommentHelp)
      .addComponent(CmB_QComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QExpList, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_QExpList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_QExpList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_QExpListHelp)))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QStock, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_QStock2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_QStockHelp)
      .addComponent(jLabel19)
      .addComponent(TF_QStock1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_QStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QOrderPack)
     .addComponent(CmB_QOrderPack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QOrderPackHelp)
     .addComponent(TF_QOrderPack1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel13)
     .addComponent(TF_QOrderPack2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QExpRange1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QExpRange, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel18)
     .addComponent(TF_QExpRange2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QExpRange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QExpRangeHelp))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QPrice2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_QPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel17)
     .addComponent(CB_QPrice)
     .addComponent(CmB_QPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QPriceHelp))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QPriceUpdate2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_QPriceUpdate1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QPriceUpdate)
     .addComponent(CmB_QPriceUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QPriceUpdateHelp)
     .addComponent(jLabel9))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QOrder)
     .addComponent(CmB_QOrder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QOrderHelp)
     .addComponent(TF_QOrder1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel21)
     .addComponent(TF_QOrder2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QStockUnit)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QStockUnitEmpty))
       .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QCat)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QCatNon))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QCatAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QCatRemove))
       .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QTag)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QTagNon))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QTagAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QTagRemove))
       .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addGap(3, 3, 3)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QPicAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QPicRemove))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QPic)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QPicNon))
       .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QStockUnitAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QStockUnitRemove)))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(CB_QSup)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QSupNon))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QSupAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QSupRemove)))
      .addContainerGap(33, Short.MAX_VALUE))
     .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
  );

  TabbedPane.addTab("Cari", null, Panel_Query, "Cari barang berdasarkan parameter tertentu");

  TF_CategoryCount.setEditable(false);
  TF_CategoryCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_CategoryCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CategoryCount.setToolTipText("jumlah kategori");
  TF_CategoryCount.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

  TF_CategoryCheckedCount.setEditable(false);
  TF_CategoryCheckedCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_CategoryCheckedCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CategoryCheckedCount.setToolTipText("jumlah kategori berdasarkan 'DaftarKu'");
  TF_CategoryCheckedCount.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

  Btn_CatRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_CatRefresh.setText("R");
  Btn_CatRefresh.setToolTipText("klik 'R' untuk menyegarkan daftar kategori");
  Btn_CatRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatRefreshActionPerformed(evt);
   }
  });
  Btn_CatRefresh.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatRefreshKeyPressed(evt);
   }
  });

  CmB_CatQueryType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Semua", "DaftarKu", "~DaftarKu" }));
  CmB_CatQueryType.setToolTipText("pilih kategori yg akan ditampilkan");
  CmB_CatQueryType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_CatQueryTypeActionPerformed(evt);
   }
  });
  CmB_CatQueryType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_CatQueryTypeKeyPressed(evt);
   }
  });

  Btn_TempListAddByCategory.setText("+");
  Btn_TempListAddByCategory.setToolTipText("menambahkan brg2 pada kategori2 yg dipilih ke \"DaftarKu\"");
  Btn_TempListAddByCategory.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAddByCategory.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddByCategoryActionPerformed(evt);
   }
  });
  Btn_TempListAddByCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TempListAddByCategoryKeyPressed(evt);
   }
  });

  Btn_TempListRemoveByCategory.setText("-");
  Btn_TempListRemoveByCategory.setToolTipText("mengurangi brg2 pada kategori2 yg dipilih dari \"DaftarKu\"");
  Btn_TempListRemoveByCategory.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemoveByCategory.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveByCategoryActionPerformed(evt);
   }
  });
  Btn_TempListRemoveByCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TempListRemoveByCategoryKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(TF_CategoryCount, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_CategoryCheckedCount, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CatRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_CatQueryType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
    .addComponent(Btn_TempListAddByCategory)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemoveByCategory))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_CategoryCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_CategoryCheckedCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_CatRefresh)
    .addComponent(CmB_CatQueryType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_TempListAddByCategory)
    .addComponent(Btn_TempListRemoveByCategory))
  );

  jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_FCatNext.setText(">");
  Btn_FCatNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatNextActionPerformed(evt);
   }
  });
  Btn_FCatNext.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatNextKeyPressed(evt);
   }
  });

  Btn_FCatBefore.setText("<");
  Btn_FCatBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FCatBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FCatBeforeActionPerformed(evt);
   }
  });
  Btn_FCatBefore.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FCatBeforeKeyPressed(evt);
   }
  });

  TF_FindCategory.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindCategoryFocusGained(evt);
   }
  });
  TF_FindCategory.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindCategoryKeyPressed(evt);
   }
  });

  Btn_CatAdd.setText("B");
  Btn_CatAdd.setToolTipText("Buat Baru Kategori Barang {F6}");
  Btn_CatAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatAddActionPerformed(evt);
   }
  });
  Btn_CatAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatAddKeyPressed(evt);
   }
  });

  Btn_CatEdit.setText("U");
  Btn_CatEdit.setToolTipText("Ubah Kategori Barang yg dipilih pada daftar {F7}");
  Btn_CatEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatEditActionPerformed(evt);
   }
  });
  Btn_CatEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatEditKeyPressed(evt);
   }
  });

  Btn_CatRemove.setText("H");
  Btn_CatRemove.setToolTipText("Hapus Kategori Barang yg dipilih pada daftar {F8}");
  Btn_CatRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CatRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CatRemoveActionPerformed(evt);
   }
  });
  Btn_CatRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CatRemoveKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_CatModifyLayout = new javax.swing.GroupLayout(Pnl_CatModify);
  Pnl_CatModify.setLayout(Pnl_CatModifyLayout);
  Pnl_CatModifyLayout.setHorizontalGroup(
   Pnl_CatModifyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_CatModifyLayout.createSequentialGroup()
    .addComponent(Btn_CatAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CatEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CatRemove))
  );
  Pnl_CatModifyLayout.setVerticalGroup(
   Pnl_CatModifyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_CatModifyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_CatAdd)
    .addComponent(Btn_CatEdit)
    .addComponent(Btn_CatRemove))
  );

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(TF_FindCategory)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatBefore)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FCatNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Pnl_CatModify, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FCatNext)
    .addComponent(Btn_FCatBefore)
    .addComponent(TF_FindCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addComponent(Pnl_CatModify, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
  );

  List_Category.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  List_Category.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_CategoryMouseReleased(evt);
   }
  });
  List_Category.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_CategoryKeyReleased(evt);
   }
  });
  jScrollPane15.setViewportView(List_Category);

  javax.swing.GroupLayout Panel_CategorizedViewLayout = new javax.swing.GroupLayout(Panel_CategorizedView);
  Panel_CategorizedView.setLayout(Panel_CategorizedViewLayout);
  Panel_CategorizedViewLayout.setHorizontalGroup(
   Panel_CategorizedViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane15)
  );
  Panel_CategorizedViewLayout.setVerticalGroup(
   Panel_CategorizedViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_CategorizedViewLayout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 577, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("Kategori", null, Panel_CategorizedView, "Cari barang berdasarkan kategori tertentu");

  Panel_ItemDetail.setToolTipText("Item's Detail");

  jLabel5.setText("Id & Nama");
  jLabel5.setRequestFocusEnabled(false);

  TF_DetStock.setEditable(false);
  TF_DetStock.setBackground(new java.awt.Color(204, 255, 204));

  CB_DetIsActive.setText("Masih Aktif");
  CB_DetIsActive.setEnabled(false);
  CB_DetIsActive.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_DetIsActive.setRequestFocusEnabled(false);

  TA_DetSell.setEditable(false);
  TA_DetSell.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetSell.setColumns(20);
  TA_DetSell.setLineWrap(true);
  TA_DetSell.setRows(1);
  TA_DetSell.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_DetSell);

  TA_DetBuy.setEditable(false);
  TA_DetBuy.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetBuy.setColumns(20);
  TA_DetBuy.setLineWrap(true);
  TA_DetBuy.setRows(1);
  TA_DetBuy.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_DetBuy);

  jLabel3.setText("Keterangan Tambahan");
  jLabel3.setRequestFocusEnabled(false);

  TA_DetComment.setEditable(false);
  TA_DetComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetComment.setColumns(20);
  TA_DetComment.setLineWrap(true);
  TA_DetComment.setRows(1);
  TA_DetComment.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_DetComment);

  TA_DetIdName.setEditable(false);
  TA_DetIdName.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetIdName.setColumns(20);
  TA_DetIdName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_DetIdName.setLineWrap(true);
  TA_DetIdName.setRows(1);
  TA_DetIdName.setWrapStyleWord(true);
  jScrollPane10.setViewportView(TA_DetIdName);

  TF_DetExpire.setEditable(false);
  TF_DetExpire.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetExpire.setToolTipText("Periode Pengecekan Kadaluarsa");

  CmB_DetBuy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Beli", "Harga Beli", "Ket Beli" }));
  CmB_DetBuy.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_DetBuyActionPerformed(evt);
   }
  });

  CmB_DetSell.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jual", "Harga Jual", "Ket Jual" }));
  CmB_DetSell.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_DetSellActionPerformed(evt);
   }
  });

  CB_DetSell.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_DetSell.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_DetSellActionPerformed(evt);
   }
  });

  CB_DetBuy.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_DetBuy.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_DetBuyActionPerformed(evt);
   }
  });

  jLabel2.setText("Stok");

  jLabel4.setText("Exp");

  jLabel10.setText("Order");
  jLabel10.setToolTipText("");

  TF_DetOrderSpec.setEditable(false);
  TF_DetOrderSpec.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetOrderSpec.setToolTipText("spesifikasi order : minimal ? pak, di mana 'qty / pak' @ ? satuan-stok (bulatkan menjadi 1 pak jika sisa-perhitungan-order >= ? % dari 'qty / pak')");

  CB_DetUpdateStock.setText("Di-Perbarui");
  CB_DetUpdateStock.setEnabled(false);
  CB_DetUpdateStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_DetUpdateStock.setRequestFocusEnabled(false);

  CB_DetIsReorder.setText("Di-Reorder");
  CB_DetIsReorder.setEnabled(false);
  CB_DetIsReorder.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CB_DetExp.setText("Kadaluarsa");
  CB_DetExp.setEnabled(false);
  CB_DetExp.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_DetExp.setRequestFocusEnabled(false);

  CB_DetIsOpname.setText("Di-Opname");
  CB_DetIsOpname.setEnabled(false);
  CB_DetIsOpname.setMargin(new java.awt.Insets(0, 0, 0, 0));

  javax.swing.GroupLayout Panel_ItemDetailLayout = new javax.swing.GroupLayout(Panel_ItemDetail);
  Panel_ItemDetail.setLayout(Panel_ItemDetailLayout);
  Panel_ItemDetailLayout.setHorizontalGroup(
   Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane3)
   .addComponent(jScrollPane6)
   .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ItemDetailLayout.createSequentialGroup()
    .addComponent(jLabel5)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_DetIsOpname)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_DetIsActive))
   .addComponent(jSeparator4)
   .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
   .addComponent(jSeparator2)
   .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
     .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_DetStock)
     .addComponent(TF_DetOrderSpec))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(CB_DetUpdateStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_DetIsReorder, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)))
   .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
      .addComponent(CB_DetBuy)
      .addGap(2, 2, 2)
      .addComponent(CmB_DetBuy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
      .addComponent(CB_DetSell)
      .addGap(2, 2, 2)
      .addComponent(CmB_DetSell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
   .addComponent(jScrollPane2)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ItemDetailLayout.createSequentialGroup()
    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_DetExpire)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_DetExp, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
    .addComponent(jLabel3)
    .addGap(0, 0, Short.MAX_VALUE))
  );
  Panel_ItemDetailLayout.setVerticalGroup(
   Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_DetIsActive)
     .addComponent(jLabel5)
     .addComponent(CB_DetIsOpname))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel3)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_DetStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(jLabel2)
       .addComponent(CB_DetUpdateStock)))
     .addGroup(Panel_ItemDetailLayout.createSequentialGroup()
      .addGap(32, 32, 32)
      .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_DetOrderSpec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(jLabel10)
       .addComponent(CB_DetIsReorder))))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetExpire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_DetExp)
     .addComponent(jLabel4))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_DetSell, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_DetSell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_ItemDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(CmB_DetBuy)
     .addComponent(CB_DetBuy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("ket", null, Panel_ItemDetail, "keterangan dari suatu barang");

  Panel_ItemEtc.setToolTipText("");

  Btn_ItemCategoryAdd.setText("Tambah");
  Btn_ItemCategoryAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemCategoryAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemCategoryAddActionPerformed(evt);
   }
  });

  Btn_ItemCategoryRemove.setText("Hapus");
  Btn_ItemCategoryRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemCategoryRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemCategoryRemoveActionPerformed(evt);
   }
  });

  jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel12.setText("- - Kategori");

  jScrollPane4.setViewportView(List_ItemCategory);

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addComponent(jLabel12)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 204, Short.MAX_VALUE)
    .addComponent(Btn_ItemCategoryAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemCategoryRemove))
   .addComponent(jScrollPane4)
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_ItemCategoryRemove)
     .addComponent(jLabel12)
     .addComponent(Btn_ItemCategoryAdd))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE))
  );

  Btn_ItemTagAdd.setText("Tambah");
  Btn_ItemTagAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemTagAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemTagAddActionPerformed(evt);
   }
  });

  Btn_ItemTagRemove.setText("Hapus");
  Btn_ItemTagRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemTagRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemTagRemoveActionPerformed(evt);
   }
  });

  jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel16.setText("- - Tag");

  jScrollPane7.setViewportView(List_ItemTag);

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addComponent(jLabel16)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 231, Short.MAX_VALUE)
    .addComponent(Btn_ItemTagAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemTagRemove))
   .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_ItemTagRemove)
     .addComponent(Btn_ItemTagAdd)
     .addComponent(jLabel16))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 299, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout Panel_ItemEtcLayout = new javax.swing.GroupLayout(Panel_ItemEtc);
  Panel_ItemEtc.setLayout(Panel_ItemEtcLayout);
  Panel_ItemEtcLayout.setHorizontalGroup(
   Panel_ItemEtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_ItemEtcLayout.setVerticalGroup(
   Panel_ItemEtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemEtcLayout.createSequentialGroup()
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("dll", null, Panel_ItemEtc, "daftar kategori & tag dari suatu barang");

  Btn_ItemPictureAdd.setText("Tambah {F6}");
  Btn_ItemPictureAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemPictureAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemPictureAddActionPerformed(evt);
   }
  });

  Btn_ItemPictureRemove.setText("Hapus {F8}");
  Btn_ItemPictureRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemPictureRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemPictureRemoveActionPerformed(evt);
   }
  });

  List_ItemPicture.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_ItemPictureMouseReleased(evt);
   }
  });
  List_ItemPicture.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_ItemPictureKeyReleased(evt);
   }
  });
  jScrollPane12.setViewportView(List_ItemPicture);

  javax.swing.GroupLayout Panel_ItemPictureLayout = new javax.swing.GroupLayout(Panel_ItemPicture);
  Panel_ItemPicture.setLayout(Panel_ItemPictureLayout);
  Panel_ItemPictureLayout.setHorizontalGroup(
   Panel_ItemPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ItemPictureLayout.createSequentialGroup()
    .addComponent(Btn_ItemPictureAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemPictureRemove)
    .addGap(0, 216, Short.MAX_VALUE))
   .addComponent(Panel_Image, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane12, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  Panel_ItemPictureLayout.setVerticalGroup(
   Panel_ItemPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemPictureLayout.createSequentialGroup()
    .addComponent(Panel_Image, javax.swing.GroupLayout.DEFAULT_SIZE, 475, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGroup(Panel_ItemPictureLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_ItemPictureRemove)
     .addComponent(Btn_ItemPictureAdd)))
  );

  TabbedPane.addTab("gbr", null, Panel_ItemPicture, "daftar gambar dari suatu barang");

  Btn_SecAdd.setText("Tambah");
  Btn_SecAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SecAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SecAddActionPerformed(evt);
   }
  });

  Btn_SecEdit.setText("Ubah");
  Btn_SecEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SecEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SecEditActionPerformed(evt);
   }
  });

  Btn_SecRemove.setText("Hapus");
  Btn_SecRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SecRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SecRemoveActionPerformed(evt);
   }
  });

  jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel22.setText("- - Secondary Id");

  jScrollPane11.setViewportView(List_Sec);

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addComponent(jLabel22)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_SecAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SecEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SecRemove))
   .addComponent(jScrollPane11, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SecRemove)
     .addComponent(Btn_SecEdit)
     .addComponent(Btn_SecAdd)
     .addComponent(jLabel22))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE))
  );

  Tbl_Vart.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Vart.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Vart.setRowHeight(17);
  Tbl_Vart.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_VartMouseReleased(evt);
   }
  });
  Tbl_Vart.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_VartKeyReleased(evt);
   }
  });
  jScrollPane23.setViewportView(Tbl_Vart);

  Btn_VartRemove.setText("Hapus");
  Btn_VartRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_VartRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_VartRemoveActionPerformed(evt);
   }
  });

  Btn_VartEdit.setText("Ubah");
  Btn_VartEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_VartEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_VartEditActionPerformed(evt);
   }
  });

  Btn_VartAdd.setText("Tambah");
  Btn_VartAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_VartAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_VartAddActionPerformed(evt);
   }
  });

  Pnl_VartInfoPreview.setToolTipText("klik utk melihat pembesaran gambar");
  Pnl_VartInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_VartInfoPreviewMouseClicked(evt);
   }
  });

  jPanel27.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_VartViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewComment.setText("Ket");
  CB_VartViewComment.setToolTipText("Keterangan");
  CB_VartViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewComment.setIconTextGap(0);
  CB_VartViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewCommentActionPerformed(evt);
   }
  });

  CB_VartViewBuyPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewBuyPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewBuyPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewBuyPrice.setText("H-Beli");
  CB_VartViewBuyPrice.setToolTipText("Harga Beli");
  CB_VartViewBuyPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewBuyPrice.setIconTextGap(0);
  CB_VartViewBuyPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewBuyPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewBuyPriceActionPerformed(evt);
   }
  });

  CB_VartViewBuyComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewBuyComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewBuyComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewBuyComment.setText("Ket H-Beli");
  CB_VartViewBuyComment.setToolTipText("Keterangan Harga Beli");
  CB_VartViewBuyComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewBuyComment.setIconTextGap(0);
  CB_VartViewBuyComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewBuyComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewBuyCommentActionPerformed(evt);
   }
  });

  CB_VartViewBuyUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_VartViewBuyUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_VartViewBuyUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_VartViewBuyUpdate.setText("Tgl");
  CB_VartViewBuyUpdate.setToolTipText("Tanggal Pembaruan");
  CB_VartViewBuyUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_VartViewBuyUpdate.setIconTextGap(0);
  CB_VartViewBuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_VartViewBuyUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_VartViewBuyUpdateActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
  jPanel27.setLayout(jPanel27Layout);
  jPanel27Layout.setHorizontalGroup(
   jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
    .addComponent(CB_VartViewComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_VartViewBuyPrice)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_VartViewBuyComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_VartViewBuyUpdate)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel27Layout.setVerticalGroup(
   jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_VartViewComment)
    .addComponent(CB_VartViewBuyPrice)
    .addComponent(CB_VartViewBuyComment)
    .addComponent(CB_VartViewBuyUpdate))
  );

  TA_VartInfoBuy.setEditable(false);
  TA_VartInfoBuy.setBackground(new java.awt.Color(204, 255, 204));
  TA_VartInfoBuy.setLineWrap(true);
  TA_VartInfoBuy.setWrapStyleWord(true);
  jScrollPane20.setViewportView(TA_VartInfoBuy);

  TA_VartInfoName.setEditable(false);
  TA_VartInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_VartInfoName.setLineWrap(true);
  TA_VartInfoName.setWrapStyleWord(true);
  jScrollPane22.setViewportView(TA_VartInfoName);

  javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
  jPanel28.setLayout(jPanel28Layout);
  jPanel28Layout.setHorizontalGroup(
   jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane20)
   .addComponent(jScrollPane22)
  );
  jPanel28Layout.setVerticalGroup(
   jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
    .addComponent(jScrollPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
  jPanel26.setLayout(jPanel26Layout);
  jPanel26Layout.setHorizontalGroup(
   jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel26Layout.setVerticalGroup(
   jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
    .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
  jPanel25.setLayout(jPanel25Layout);
  jPanel25Layout.setHorizontalGroup(
   jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel25Layout.createSequentialGroup()
    .addComponent(Pnl_VartInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel25Layout.setVerticalGroup(
   jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_VartInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  Btn_VartActiveAdd.setText("+");
  Btn_VartActiveAdd.setToolTipText("menandai atribut aktif pada varian-varian yg dipilih di dlm daftar");
  Btn_VartActiveAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_VartActiveAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_VartActiveAddActionPerformed(evt);
   }
  });

  Btn_VartActiveRemove.setText("-");
  Btn_VartActiveRemove.setToolTipText("menghilangkan tanda atribut aktif pada varian-varian yg dipilih di dlm daftar");
  Btn_VartActiveRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_VartActiveRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_VartActiveRemoveActionPerformed(evt);
   }
  });

  jLabel35.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel35.setText("Atf");

  jLabel34.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel34.setText("- - Varian");

  javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
  jPanel24.setLayout(jPanel24Layout);
  jPanel24Layout.setHorizontalGroup(
   jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel24Layout.createSequentialGroup()
    .addComponent(jLabel34)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel35)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_VartActiveAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_VartActiveRemove)
    .addGap(18, 18, 18)
    .addComponent(Btn_VartAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_VartEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_VartRemove))
   .addComponent(jScrollPane23, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
   .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel24Layout.setVerticalGroup(
   jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
    .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_VartRemove)
     .addComponent(Btn_VartEdit)
     .addComponent(Btn_VartAdd)
     .addComponent(Btn_VartActiveAdd)
     .addComponent(Btn_VartActiveRemove)
     .addComponent(jLabel35)
     .addComponent(jLabel34))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane23, javax.swing.GroupLayout.DEFAULT_SIZE, 303, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Panel_ItemVariantLayout = new javax.swing.GroupLayout(Panel_ItemVariant);
  Panel_ItemVariant.setLayout(Panel_ItemVariantLayout);
  Panel_ItemVariantLayout.setHorizontalGroup(
   Panel_ItemVariantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_ItemVariantLayout.setVerticalGroup(
   Panel_ItemVariantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemVariantLayout.createSequentialGroup()
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("var", null, Panel_ItemVariant, "daftar varian dari suatu barang");

  Panel_ItemSupplier.setToolTipText("Item's Suppliers");

  Btn_SuppRemove.setText("Hps {F8}");
  Btn_SuppRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppRemoveActionPerformed(evt);
   }
  });

  Btn_SuppEdit.setText("Ubh {F7}");
  Btn_SuppEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppEditActionPerformed(evt);
   }
  });

  Btn_SuppAdd.setText("Tbh {F6}");
  Btn_SuppAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppAddActionPerformed(evt);
   }
  });

  Btn_SuppTempListAdd.setText("+");
  Btn_SuppTempListAdd.setToolTipText("tambahkan supplier2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_SuppTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppTempListAddActionPerformed(evt);
   }
  });

  Btn_SuppTempListRemove.setText("-");
  Btn_SuppTempListRemove.setToolTipText("kurangi supplier2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_SuppTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppTempListRemoveActionPerformed(evt);
   }
  });

  jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel8.setText("*");

  jPanel13.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_SuppFindBef.setText("<");
  Btn_SuppFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppFindBefActionPerformed(evt);
   }
  });

  Btn_SuppFindNext.setText(">");
  Btn_SuppFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppFindNextActionPerformed(evt);
   }
  });

  TF_SuppFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SuppFindFocusGained(evt);
   }
  });
  TF_SuppFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SuppFindKeyPressed(evt);
   }
  });

  CmB_SuppFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Suplier", "Ket Beli" }));

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
    .addComponent(CmB_SuppFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_SuppFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_SuppFindNext))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_SuppFindBef)
    .addComponent(Btn_SuppFindNext)
    .addComponent(TF_SuppFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_SuppFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Tbl_Supp.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Supp.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Supp.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Supp.setRowHeight(18);
  Tbl_Supp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_SuppMouseReleased(evt);
   }
  });
  Tbl_Supp.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_SuppKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_Supp);

  Btn_SuppActiveRemove.setText("-");
  Btn_SuppActiveRemove.setToolTipText("menghilangkan tanda atribut aktif pada suplier-suplier yg dipilih di dlm daftar");
  Btn_SuppActiveRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppActiveRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppActiveRemoveActionPerformed(evt);
   }
  });

  Btn_SuppActiveAdd.setText("+");
  Btn_SuppActiveAdd.setToolTipText("menandai atribut aktif pada suplier-suplier yg dipilih di dlm daftar");
  Btn_SuppActiveAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppActiveAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppActiveAddActionPerformed(evt);
   }
  });

  jLabel30.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel30.setText("Atf");

  Btn_SuppInfo.setText("i");
  Btn_SuppInfo.setToolTipText("lihat keterangan subjek yg dipilih pd daftar");
  Btn_SuppInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SuppInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SuppInfoActionPerformed(evt);
   }
  });

  jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_SuppViewBuyUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewBuyUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewBuyUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewBuyUpdate.setText("Tgl");
  CB_SuppViewBuyUpdate.setToolTipText("Tanggal Pembaruan");
  CB_SuppViewBuyUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewBuyUpdate.setIconTextGap(0);
  CB_SuppViewBuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewBuyUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewBuyUpdateActionPerformed(evt);
   }
  });

  CB_SuppViewBuyComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewBuyComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewBuyComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewBuyComment.setText("Ket H-Beli");
  CB_SuppViewBuyComment.setToolTipText("Keterangan Harga Beli");
  CB_SuppViewBuyComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewBuyComment.setIconTextGap(0);
  CB_SuppViewBuyComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewBuyComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewBuyCommentActionPerformed(evt);
   }
  });

  CB_SuppViewBuyPrc.setBackground(new java.awt.Color(204, 204, 204));
  CB_SuppViewBuyPrc.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_SuppViewBuyPrc.setForeground(new java.awt.Color(102, 102, 0));
  CB_SuppViewBuyPrc.setText("H-Beli");
  CB_SuppViewBuyPrc.setToolTipText("Harga Beli");
  CB_SuppViewBuyPrc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_SuppViewBuyPrc.setIconTextGap(0);
  CB_SuppViewBuyPrc.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SuppViewBuyPrc.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SuppViewBuyPrcActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
    .addComponent(CB_SuppViewBuyPrc)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_SuppViewBuyComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_SuppViewBuyUpdate)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_SuppViewBuyUpdate)
    .addComponent(CB_SuppViewBuyComment)
    .addComponent(CB_SuppViewBuyPrc))
  );

  CB_SuppInfoActive.setText(" ");
  CB_SuppInfoActive.setEnabled(false);
  CB_SuppInfoActive.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TF_SuppInfoName.setEditable(false);
  TF_SuppInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_SuppInfoName.setToolTipText("klik utk melihat keterangan suplier");
  TF_SuppInfoName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_SuppInfoName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_SuppInfoNameMouseClicked(evt);
   }
  });

  TA_SuppInfoBuy.setEditable(false);
  TA_SuppInfoBuy.setBackground(new java.awt.Color(204, 255, 204));
  TA_SuppInfoBuy.setColumns(20);
  TA_SuppInfoBuy.setLineWrap(true);
  TA_SuppInfoBuy.setWrapStyleWord(true);
  jScrollPane9.setViewportView(TA_SuppInfoBuy);

  javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
  jPanel23.setLayout(jPanel23Layout);
  jPanel23Layout.setHorizontalGroup(
   jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel23Layout.createSequentialGroup()
    .addComponent(TF_SuppInfoName)
    .addGap(0, 0, 0)
    .addComponent(CB_SuppInfoActive))
   .addComponent(jScrollPane9)
  );
  jPanel23Layout.setVerticalGroup(
   jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel23Layout.createSequentialGroup()
    .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SuppInfoActive)
     .addComponent(TF_SuppInfoName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Panel_ItemSupplierLayout = new javax.swing.GroupLayout(Panel_ItemSupplier);
  Panel_ItemSupplier.setLayout(Panel_ItemSupplierLayout);
  Panel_ItemSupplierLayout.setHorizontalGroup(
   Panel_ItemSupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemSupplierLayout.createSequentialGroup()
    .addComponent(Btn_SuppAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_SuppEdit)
    .addGap(4, 4, 4)
    .addComponent(Btn_SuppRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
    .addComponent(jLabel30)
    .addGap(3, 3, 3)
    .addComponent(Btn_SuppActiveAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_SuppActiveRemove)
    .addGap(8, 8, 8)
    .addComponent(jLabel8)
    .addGap(3, 3, 3)
    .addComponent(Btn_SuppTempListAdd)
    .addGap(4, 4, 4)
    .addComponent(Btn_SuppTempListRemove)
    .addGap(4, 4, 4)
    .addComponent(Btn_SuppInfo))
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_ItemSupplierLayout.setVerticalGroup(
   Panel_ItemSupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemSupplierLayout.createSequentialGroup()
    .addGroup(Panel_ItemSupplierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SuppAdd)
     .addComponent(Btn_SuppEdit)
     .addComponent(Btn_SuppRemove)
     .addComponent(Btn_SuppTempListRemove)
     .addComponent(Btn_SuppTempListAdd)
     .addComponent(jLabel8)
     .addComponent(Btn_SuppActiveRemove)
     .addComponent(Btn_SuppActiveAdd)
     .addComponent(jLabel30)
     .addComponent(Btn_SuppInfo))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("sup", null, Panel_ItemSupplier, "daftar suplier dari suatu barang");

  CmB_TransType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_TransTypeActionPerformed(evt);
   }
  });

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("Jenis Trans");

  jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel23.setText("Transaksi");

  RG_ViewTransIsPreTrans.add(RB_TransIsPreTransN);
  RB_TransIsPreTransN.setText("Transaksi");
  RB_TransIsPreTransN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_TransIsPreTransN.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    RB_TransIsPreTransNActionPerformed(evt);
   }
  });

  RG_ViewTransIsPreTrans.add(RB_TransIsPreTransY);
  RB_TransIsPreTransY.setText("Pra-Transaksi");
  RB_TransIsPreTransY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_TransIsPreTransY.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    RB_TransIsPreTransYActionPerformed(evt);
   }
  });

  CmB_TransSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_TransSubjectActionPerformed(evt);
   }
  });

  jLabel26.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel26.setText("Subjek/Sales");

  Btn_TransSubjectInfo.setText("i");
  Btn_TransSubjectInfo.setToolTipText("lihat keterangan subjek");
  Btn_TransSubjectInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSubjectInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSubjectInfoActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addGroup(jPanel14Layout.createSequentialGroup()
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel1)
     .addComponent(jLabel23)
     .addComponent(jLabel26))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel14Layout.createSequentialGroup()
      .addComponent(RB_TransIsPreTransN)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(RB_TransIsPreTransY)
      .addContainerGap())
     .addComponent(CmB_TransType, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel14Layout.createSequentialGroup()
      .addComponent(CmB_TransSubject, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_TransSubjectInfo))))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createSequentialGroup()
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_TransIsPreTransN)
     .addComponent(RB_TransIsPreTransY)
     .addComponent(jLabel23))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_TransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_TransSubject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel26)
     .addComponent(Btn_TransSubjectInfo)))
  );

  Tbl_TransIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_TransIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_TransIn.setRowHeight(17);
  Tbl_TransIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_TransInMouseReleased(evt);
   }
  });
  Tbl_TransIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_TransInKeyReleased(evt);
   }
  });
  jScrollPane14.setViewportView(Tbl_TransIn);

  jPanel20.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_TransInDate.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInDate.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInDate.setText("Tg");
  CB_TransInDate.setToolTipText("Tanggal Transaksi");
  CB_TransInDate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInDate.setIconTextGap(0);
  CB_TransInDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInDate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInDateActionPerformed(evt);
   }
  });

  CB_TransInType.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInType.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInType.setText("Jn");
  CB_TransInType.setToolTipText("Jenis Transaksi");
  CB_TransInType.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInType.setIconTextGap(0);
  CB_TransInType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInTypeActionPerformed(evt);
   }
  });

  CB_TransInSubject.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInSubject.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInSubject.setText("Sb");
  CB_TransInSubject.setToolTipText("Subjek");
  CB_TransInSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInSubject.setIconTextGap(0);
  CB_TransInSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInSubjectActionPerformed(evt);
   }
  });

  CB_TransInSalesman.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInSalesman.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInSalesman.setText("Sl");
  CB_TransInSalesman.setToolTipText("Sales");
  CB_TransInSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInSalesman.setIconTextGap(0);
  CB_TransInSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInSalesmanActionPerformed(evt);
   }
  });

  CB_TransInId.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInId.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInId.setText("Id");
  CB_TransInId.setToolTipText("Id Transaksi");
  CB_TransInId.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInId.setIconTextGap(0);
  CB_TransInId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInIdActionPerformed(evt);
   }
  });

  CB_TransInIdExternal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInIdExternal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInIdExternal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInIdExternal.setText("{E}");
  CB_TransInIdExternal.setToolTipText("{Id-External}");
  CB_TransInIdExternal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInIdExternal.setIconTextGap(0);
  CB_TransInIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInIdExternal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInIdExternalActionPerformed(evt);
   }
  });

  CB_TransInItemComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInItemComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInItemComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInItemComment.setText("C");
  CB_TransInItemComment.setToolTipText("Komentar");
  CB_TransInItemComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInItemComment.setIconTextGap(0);
  CB_TransInItemComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInItemComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInItemCommentActionPerformed(evt);
   }
  });

  CB_TransInPriceUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInPriceUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInPriceUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInPriceUnit.setText("HS");
  CB_TransInPriceUnit.setToolTipText("Harga Satuan");
  CB_TransInPriceUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInPriceUnit.setIconTextGap(0);
  CB_TransInPriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInPriceUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInPriceUnitActionPerformed(evt);
   }
  });

  CB_TransInPriceTotal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransInPriceTotal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransInPriceTotal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransInPriceTotal.setText("HT");
  CB_TransInPriceTotal.setToolTipText("Harga Total");
  CB_TransInPriceTotal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransInPriceTotal.setIconTextGap(0);
  CB_TransInPriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransInPriceTotal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransInPriceTotalActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
  jPanel20.setLayout(jPanel20Layout);
  jPanel20Layout.setHorizontalGroup(
   jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
    .addComponent(CB_TransInDate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInType)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInSubject)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInSalesman)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInIdExternal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInItemComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInPriceUnit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransInPriceTotal)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel20Layout.setVerticalGroup(
   jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_TransInDate)
    .addComponent(CB_TransInType)
    .addComponent(CB_TransInSubject)
    .addComponent(CB_TransInSalesman)
    .addComponent(CB_TransInId)
    .addComponent(CB_TransInIdExternal)
    .addComponent(CB_TransInItemComment)
    .addComponent(CB_TransInPriceUnit)
    .addComponent(CB_TransInPriceTotal))
  );

  jPanel21.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TransInFindNext.setText(">");
  Btn_TransInFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInFindNextActionPerformed(evt);
   }
  });

  Btn_TransInFindBef.setText("<");
  Btn_TransInFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInFindBefActionPerformed(evt);
   }
  });

  TF_TransInFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_TransInFindFocusGained(evt);
   }
  });
  TF_TransInFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransInFindKeyPressed(evt);
   }
  });

  CmB_TransInFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jenis Trans", "Subjek", "Sales", "Id Trans", "Id Ext", "Komentar" }));

  javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
  jPanel21.setLayout(jPanel21Layout);
  jPanel21Layout.setHorizontalGroup(
   jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
    .addComponent(CmB_TransInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TransInFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInFindNext))
  );
  jPanel21Layout.setVerticalGroup(
   jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransInFindNext)
    .addComponent(Btn_TransInFindBef)
    .addComponent(TF_TransInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_TransInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_TransInSalesmanTempListRemove.setText("-");
  Btn_TransInSalesmanTempListRemove.setToolTipText("kurangi sales2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransInSalesmanTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSalesmanTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSalesmanTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInSalesmanTempListAdd.setText("+");
  Btn_TransInSalesmanTempListAdd.setToolTipText("tambahkan sales2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransInSalesmanTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSalesmanTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSalesmanTempListAddActionPerformed(evt);
   }
  });

  jLabel24.setText("Sls*");

  Btn_TransInSubjectTempListRemove.setText("-");
  Btn_TransInSubjectTempListRemove.setToolTipText("kurangi subjek2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransInSubjectTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSubjectTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSubjectTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInSubjectTempListAdd.setText("+");
  Btn_TransInSubjectTempListAdd.setToolTipText("tambahkan subjek2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransInSubjectTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSubjectTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSubjectTempListAddActionPerformed(evt);
   }
  });

  jLabel25.setText("Sbj*");

  Btn_TransInSalesmanInfo.setText("i");
  Btn_TransInSalesmanInfo.setToolTipText("lihat keterangan sales yg dipilih pd daftar");
  Btn_TransInSalesmanInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSalesmanInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSalesmanInfoActionPerformed(evt);
   }
  });

  Btn_TransInSubjectInfo.setText("i");
  Btn_TransInSubjectInfo.setToolTipText("lihat keterangan subjek yg dipilih pd daftar");
  Btn_TransInSubjectInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInSubjectInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInSubjectInfoActionPerformed(evt);
   }
  });

  Btn_TransInTransInfo.setText("i");
  Btn_TransInTransInfo.setToolTipText("lihat keterangan transaksi yg dipilih pd daftar");
  Btn_TransInTransInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInTransInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInTransInfoActionPerformed(evt);
   }
  });

  Btn_TransInTransTempListRemove.setText("-");
  Btn_TransInTransTempListRemove.setToolTipText("kurangi transaksi2 yg dipilih dari 'DaftarKu' pd form Transaksi");
  Btn_TransInTransTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInTransTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInTransTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransInTransTempListAdd.setText("+");
  Btn_TransInTransTempListAdd.setToolTipText("tambahkan transaksi2 yg dipilih ke 'DaftarKu' pd form Transaksi");
  Btn_TransInTransTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransInTransTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransInTransTempListAddActionPerformed(evt);
   }
  });

  jLabel31.setText("Trans*");

  javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
  jPanel19.setLayout(jPanel19Layout);
  jPanel19Layout.setHorizontalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(jLabel31)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInTransTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInTransTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInTransInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel25)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSubjectTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSubjectTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSubjectInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel24)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSalesmanTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSalesmanTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransInSalesmanInfo))
  );
  jPanel19Layout.setVerticalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransInSalesmanTempListRemove)
    .addComponent(Btn_TransInSalesmanTempListAdd)
    .addComponent(jLabel24)
    .addComponent(Btn_TransInSubjectTempListRemove)
    .addComponent(Btn_TransInSubjectTempListAdd)
    .addComponent(jLabel25)
    .addComponent(Btn_TransInSalesmanInfo)
    .addComponent(Btn_TransInSubjectInfo)
    .addComponent(Btn_TransInTransInfo)
    .addComponent(Btn_TransInTransTempListRemove)
    .addComponent(Btn_TransInTransTempListAdd)
    .addComponent(jLabel31))
  );

  javax.swing.GroupLayout Panel_TransInLayout = new javax.swing.GroupLayout(Panel_TransIn);
  Panel_TransIn.setLayout(Panel_TransInLayout);
  Panel_TransInLayout.setHorizontalGroup(
   Panel_TransInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
   .addComponent(jPanel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_TransInLayout.setVerticalGroup(
   Panel_TransInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_TransInLayout.createSequentialGroup()
    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane_TransList.addTab("Barang Masuk", Panel_TransIn);

  Tbl_TransOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_TransOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_TransOut.setRowHeight(17);
  Tbl_TransOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_TransOutMouseReleased(evt);
   }
  });
  Tbl_TransOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_TransOutKeyReleased(evt);
   }
  });
  jScrollPane19.setViewportView(Tbl_TransOut);

  jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_TransOutDate.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutDate.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutDate.setText("Tg");
  CB_TransOutDate.setToolTipText("Tanggal Transaksi");
  CB_TransOutDate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutDate.setIconTextGap(0);
  CB_TransOutDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutDate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutDateActionPerformed(evt);
   }
  });

  CB_TransOutType.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutType.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutType.setText("Jn");
  CB_TransOutType.setToolTipText("Jenis Transaksi");
  CB_TransOutType.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutType.setIconTextGap(0);
  CB_TransOutType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutTypeActionPerformed(evt);
   }
  });

  CB_TransOutSubject.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutSubject.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutSubject.setText("Sb");
  CB_TransOutSubject.setToolTipText("Subjek");
  CB_TransOutSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutSubject.setIconTextGap(0);
  CB_TransOutSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutSubjectActionPerformed(evt);
   }
  });

  CB_TransOutSalesman.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutSalesman.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutSalesman.setText("Sl");
  CB_TransOutSalesman.setToolTipText("Sales");
  CB_TransOutSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutSalesman.setIconTextGap(0);
  CB_TransOutSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutSalesmanActionPerformed(evt);
   }
  });

  CB_TransOutId.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutId.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutId.setText("Id");
  CB_TransOutId.setToolTipText("Id Transaksi");
  CB_TransOutId.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutId.setIconTextGap(0);
  CB_TransOutId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutIdActionPerformed(evt);
   }
  });

  CB_TransOutIdExternal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutIdExternal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutIdExternal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutIdExternal.setText("{E}");
  CB_TransOutIdExternal.setToolTipText("{Id-External}");
  CB_TransOutIdExternal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutIdExternal.setIconTextGap(0);
  CB_TransOutIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutIdExternal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutIdExternalActionPerformed(evt);
   }
  });

  CB_TransOutItemComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutItemComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutItemComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutItemComment.setText("C");
  CB_TransOutItemComment.setToolTipText("Komentar");
  CB_TransOutItemComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutItemComment.setIconTextGap(0);
  CB_TransOutItemComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutItemComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutItemCommentActionPerformed(evt);
   }
  });

  CB_TransOutPriceUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutPriceUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutPriceUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutPriceUnit.setText("HS");
  CB_TransOutPriceUnit.setToolTipText("Harga Satuan");
  CB_TransOutPriceUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutPriceUnit.setIconTextGap(0);
  CB_TransOutPriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutPriceUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutPriceUnitActionPerformed(evt);
   }
  });

  CB_TransOutPriceTotal.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutPriceTotal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutPriceTotal.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutPriceTotal.setText("HT");
  CB_TransOutPriceTotal.setToolTipText("Harga Total");
  CB_TransOutPriceTotal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutPriceTotal.setIconTextGap(0);
  CB_TransOutPriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutPriceTotal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutPriceTotalActionPerformed(evt);
   }
  });

  CB_TransOutPriceBasic.setBackground(new java.awt.Color(204, 204, 204));
  CB_TransOutPriceBasic.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_TransOutPriceBasic.setForeground(new java.awt.Color(102, 102, 0));
  CB_TransOutPriceBasic.setText("HPP");
  CB_TransOutPriceBasic.setToolTipText("Harga Pokok Penjualan");
  CB_TransOutPriceBasic.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_TransOutPriceBasic.setIconTextGap(0);
  CB_TransOutPriceBasic.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransOutPriceBasic.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_TransOutPriceBasicActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
    .addComponent(CB_TransOutDate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutType)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutSubject)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutSalesman)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutIdExternal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutItemComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutPriceUnit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutPriceTotal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransOutPriceBasic)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_TransOutDate)
    .addComponent(CB_TransOutType)
    .addComponent(CB_TransOutSubject)
    .addComponent(CB_TransOutSalesman)
    .addComponent(CB_TransOutId)
    .addComponent(CB_TransOutIdExternal)
    .addComponent(CB_TransOutItemComment)
    .addComponent(CB_TransOutPriceUnit)
    .addComponent(CB_TransOutPriceTotal)
    .addComponent(CB_TransOutPriceBasic))
  );

  jPanel18.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TransOutFindNext.setText(">");
  Btn_TransOutFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutFindNextActionPerformed(evt);
   }
  });

  Btn_TransOutFindBef.setText("<");
  Btn_TransOutFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutFindBefActionPerformed(evt);
   }
  });

  CmB_TransOutFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jenis Trans", "Subjek", "Sales", "Id Trans", "Id Ext", "Komentar" }));

  TF_TransOutFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_TransOutFindFocusGained(evt);
   }
  });
  TF_TransOutFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransOutFindKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
  jPanel18.setLayout(jPanel18Layout);
  jPanel18Layout.setHorizontalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
    .addComponent(CmB_TransOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TransOutFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutFindNext))
  );
  jPanel18Layout.setVerticalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransOutFindNext)
    .addComponent(Btn_TransOutFindBef)
    .addComponent(CmB_TransOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_TransOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_TransOutSalesmanTempListRemove.setText("-");
  Btn_TransOutSalesmanTempListRemove.setToolTipText("kurangi sales2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransOutSalesmanTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSalesmanTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSalesmanTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutSalesmanTempListAdd.setText("+");
  Btn_TransOutSalesmanTempListAdd.setToolTipText("tambahkan sales2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransOutSalesmanTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSalesmanTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSalesmanTempListAddActionPerformed(evt);
   }
  });

  jLabel27.setText("Sls*");

  Btn_TransOutSubjectTempListRemove.setText("-");
  Btn_TransOutSubjectTempListRemove.setToolTipText("kurangi subjek2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransOutSubjectTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSubjectTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSubjectTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutSubjectTempListAdd.setText("+");
  Btn_TransOutSubjectTempListAdd.setToolTipText("tambahkan subjek2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransOutSubjectTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSubjectTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSubjectTempListAddActionPerformed(evt);
   }
  });

  jLabel28.setText("Sbj*");

  Btn_TransOutSalesmanInfo.setText("i");
  Btn_TransOutSalesmanInfo.setToolTipText("lihat keterangan sales yg dipilih pd daftar");
  Btn_TransOutSalesmanInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSalesmanInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSalesmanInfoActionPerformed(evt);
   }
  });

  Btn_TransOutSubjectInfo.setText("i");
  Btn_TransOutSubjectInfo.setToolTipText("lihat keterangan subjek yg dipilih pd daftar");
  Btn_TransOutSubjectInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutSubjectInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutSubjectInfoActionPerformed(evt);
   }
  });

  Btn_TransOutTransInfo.setText("i");
  Btn_TransOutTransInfo.setToolTipText("lihat keterangan transaksi yg dipilih pd daftar");
  Btn_TransOutTransInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutTransInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutTransInfoActionPerformed(evt);
   }
  });

  Btn_TransOutTransTempListRemove.setText("-");
  Btn_TransOutTransTempListRemove.setToolTipText("kurangi transaksi2 yg dipilih dari 'DaftarKu' pd form Transaksi");
  Btn_TransOutTransTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutTransTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutTransTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransOutTransTempListAdd.setText("+");
  Btn_TransOutTransTempListAdd.setToolTipText("tambahkan transaksi2 yg dipilih ke 'DaftarKu' pd form Transaksi");
  Btn_TransOutTransTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransOutTransTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransOutTransTempListAddActionPerformed(evt);
   }
  });

  jLabel32.setText("Trans*");

  javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
  jPanel22.setLayout(jPanel22Layout);
  jPanel22Layout.setHorizontalGroup(
   jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(jLabel32)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutTransTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutTransTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutTransInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel28)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSubjectTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSubjectTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSubjectInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel27)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSalesmanTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSalesmanTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransOutSalesmanInfo))
  );
  jPanel22Layout.setVerticalGroup(
   jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransOutSalesmanTempListRemove)
    .addComponent(Btn_TransOutSalesmanTempListAdd)
    .addComponent(jLabel27)
    .addComponent(Btn_TransOutSubjectTempListRemove)
    .addComponent(Btn_TransOutSubjectTempListAdd)
    .addComponent(jLabel28)
    .addComponent(Btn_TransOutSalesmanInfo)
    .addComponent(Btn_TransOutSubjectInfo)
    .addComponent(Btn_TransOutTransInfo)
    .addComponent(Btn_TransOutTransTempListRemove)
    .addComponent(Btn_TransOutTransTempListAdd)
    .addComponent(jLabel32))
  );

  javax.swing.GroupLayout Panel_TransOutLayout = new javax.swing.GroupLayout(Panel_TransOut);
  Panel_TransOut.setLayout(Panel_TransOutLayout);
  Panel_TransOutLayout.setHorizontalGroup(
   Panel_TransOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
   .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_TransOutLayout.setVerticalGroup(
   Panel_TransOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_TransOutLayout.createSequentialGroup()
    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane_TransList.addTab("Barang Keluar", Panel_TransOut);

  javax.swing.GroupLayout Panel_TransLayout = new javax.swing.GroupLayout(Panel_Trans);
  Panel_Trans.setLayout(Panel_TransLayout);
  Panel_TransLayout.setHorizontalGroup(
   Panel_TransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(TabbedPane_TransList)
  );
  Panel_TransLayout.setVerticalGroup(
   Panel_TransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_TransLayout.createSequentialGroup()
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(TabbedPane_TransList))
  );

  TabbedPane.addTab("trans", null, Panel_Trans, "riwayat aktivitas barang masuk & keluar dari suatu barang pada transaksi-transaksi");

  TF_QueryCount.setEditable(false);
  TF_QueryCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_QueryCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_QueryCount.setToolTipText("Jumlah data barang di daftar");

  TF_QueryTempListCount.setEditable(false);
  TF_QueryTempListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryTempListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_QueryTempListCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_QueryTempListCount.setToolTipText("Jumlah data 'DaftarKu' di daftar");

  CmB_ResultFilterExpire.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "{exp}", "Exp", "~Exp" }));
  CmB_ResultFilterExpire.setToolTipText("Filter \"Memiliki Expire\"");
  CmB_ResultFilterExpire.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterExpireActionPerformed(evt);
   }
  });

  CmB_ResultFilterUpdateStock.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "{pbr}", "Pbr", "~Pbr" }));
  CmB_ResultFilterUpdateStock.setToolTipText("Filter \"Stok Di-Perbarui\"");
  CmB_ResultFilterUpdateStock.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterUpdateStockActionPerformed(evt);
   }
  });

  CmB_ResultFilterActive.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "{atf}", "Atf", "~Atf" }));
  CmB_ResultFilterActive.setToolTipText("Filter \"Aktif\"");
  CmB_ResultFilterActive.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterActiveActionPerformed(evt);
   }
  });

  CmB_ResultFilterSubset.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "*Smua", "*DftKu", "*~DftKu" }));
  CmB_ResultFilterSubset.setToolTipText("Filter \"DaftarKu\"");
  CmB_ResultFilterSubset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterSubsetActionPerformed(evt);
   }
  });

  Btn_QueryRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_QueryRefresh.setText("R");
  Btn_QueryRefresh.setToolTipText("klik 'R' untuk menyegarkan daftar barang dlm tabel");
  Btn_QueryRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_QueryRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryRefreshActionPerformed(evt);
   }
  });

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi barang2 yg dipilih dari 'DaftarKu'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan barang2 yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu' (klik kiri - lihat DaftarKu ; klik kanan - lihat ~DaftarKu)");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TempListQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TempListQuantityMouseClicked(evt);
   }
  });

  jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel15.setText("*DaftarKu");

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  CmB_ResultFilterIsReorder.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "{rod}", "Rod", "~Rod" }));
  CmB_ResultFilterIsReorder.setToolTipText("Filter \"Di-Reorder\"");
  CmB_ResultFilterIsReorder.setMinimumSize(new java.awt.Dimension(52, 18));
  CmB_ResultFilterIsReorder.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterIsReorderActionPerformed(evt);
   }
  });

  CmB_ResultFilterIsOpname.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "{opn}", "Opn", "~Opn" }));
  CmB_ResultFilterIsOpname.setToolTipText("Filter \"Di-Opname\"");
  CmB_ResultFilterIsOpname.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterIsOpnameActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(4, 4, 4)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(4, 4, 4)
    .addComponent(Btn_QueryRefresh)
    .addGap(6, 6, 6)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(CmB_ResultFilterActive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(CmB_ResultFilterIsOpname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(CmB_ResultFilterIsReorder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(CmB_ResultFilterUpdateStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(CmB_ResultFilterExpire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
    .addComponent(jLabel15)
    .addGap(6, 6, 6)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(Btn_TempListAdd)
    .addGap(6, 6, 6)
    .addComponent(Btn_TempListRemove)
    .addGap(6, 6, 6)
    .addComponent(Btn_TempListSave)
    .addGap(6, 6, 6)
    .addComponent(Btn_TempListLoad)
    .addGap(6, 6, 6)
    .addComponent(Btn_TempListClear))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterExpire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterUpdateStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterActive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_QueryRefresh)
    .addComponent(Btn_TempListLoad)
    .addComponent(Btn_TempListSave)
    .addComponent(Btn_TempListRemove)
    .addComponent(Btn_TempListAdd)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel15)
    .addComponent(Btn_TempListClear)
    .addComponent(CmB_ResultFilterIsReorder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterIsOpname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_Choose.setText("Impor-Ekspor / Pilih {F11}");
  Btn_Choose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Choose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseActionPerformed(evt);
   }
  });

  Lbl_MultipleSelection.setText("{Boleh > 1}");
  Lbl_MultipleSelection.setRequestFocusEnabled(false);

  Btn_New.setText("Buat Baru {F1}");
  Btn_New.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_New.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_NewActionPerformed(evt);
   }
  });

  Btn_Edit.setText("Ubah {F4}");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Remove.setText("Hapus {F3}");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  Btn_Report.setText("Cetak");
  Btn_Report.setToolTipText("");
  Btn_Report.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Report.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReportActionPerformed(evt);
   }
  });

  CmB_ReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laporan", "Check-List", "Katalog Gambar", "Pengadaan Brg", "File CSV" }));

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
    .addComponent(Btn_New)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Edit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Remove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Report)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Lbl_MultipleSelection)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Choose))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Choose)
    .addComponent(Lbl_MultipleSelection)
    .addComponent(Btn_New)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Remove)
    .addComponent(Btn_Report)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_MultipleItemsSupRemove.setText("-");
  Btn_MultipleItemsSupRemove.setToolTipText("menghapus suplier dari brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsSupRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsSupRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsSupRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsSupAdd.setText("+");
  Btn_MultipleItemsSupAdd.setToolTipText("menambah supplier pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsSupAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsSupAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsSupAddActionPerformed(evt);
   }
  });

  jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel11.setText("Sp");

  Btn_MultipleItemsPicRemove.setText("-");
  Btn_MultipleItemsPicRemove.setToolTipText("menghapus gambar dari brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsPicRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsPicRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsPicRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsPicAdd.setText("+");
  Btn_MultipleItemsPicAdd.setToolTipText("menambah gambar pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsPicAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsPicAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsPicAddActionPerformed(evt);
   }
  });

  jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel7.setText("Gb");

  Btn_MultipleItemsTagRemove.setText("-");
  Btn_MultipleItemsTagRemove.setToolTipText("menghapus tag dari brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsTagRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsTagRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsTagRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsTagAdd.setText("+");
  Btn_MultipleItemsTagAdd.setToolTipText("menambah tag pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsTagAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsTagAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsTagAddActionPerformed(evt);
   }
  });

  jLabel20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel20.setText("Tg");

  Btn_MultipleItemsCategoryRemove.setText("-");
  Btn_MultipleItemsCategoryRemove.setToolTipText("menghapus kategori dari brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsCategoryRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsCategoryRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsCategoryRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsCategoryAdd.setText("+");
  Btn_MultipleItemsCategoryAdd.setToolTipText("menambah kategori pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsCategoryAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsCategoryAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsCategoryAddActionPerformed(evt);
   }
  });

  jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel6.setText("Kg");

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_FindBefore.setText("<");
  Btn_FindBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBeforeActionPerformed(evt);
   }
  });

  CmB_Find.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nama Brg", "Kategori", "Ket. Beli", "Ket. Jual" }));

  TF_Find.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FindFocusLost(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  Btn_MultipleItemsActiveRemove.setText("-");
  Btn_MultipleItemsActiveRemove.setToolTipText("nonaktifkan brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsActiveRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsActiveRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsActiveRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsActiveAdd.setText("+");
  Btn_MultipleItemsActiveAdd.setToolTipText("aktifkan brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsActiveAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsActiveAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsActiveAddActionPerformed(evt);
   }
  });

  jLabel29.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel29.setForeground(new java.awt.Color(204, 51, 0));
  jLabel29.setText("At");

  Btn_MultipleItemsIsReorderRemove.setText("-");
  Btn_MultipleItemsIsReorderRemove.setToolTipText("hapus tanda \"Di-Reorder\" pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsIsReorderRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsIsReorderRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsIsReorderRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsIsReorderAdd.setText("+");
  Btn_MultipleItemsIsReorderAdd.setToolTipText("beri tanda \"Di-Reorder\" pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsIsReorderAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsIsReorderAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsIsReorderAddActionPerformed(evt);
   }
  });

  jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel33.setForeground(new java.awt.Color(204, 51, 0));
  jLabel33.setText("RO");

  Btn_MultipleItemsVartRemove.setText("-");
  Btn_MultipleItemsVartRemove.setToolTipText("menghapus varian dari brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsVartRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsVartRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsVartRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsVartAdd.setText("+");
  Btn_MultipleItemsVartAdd.setToolTipText("menambah varian pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsVartAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsVartAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsVartAddActionPerformed(evt);
   }
  });

  jLabel36.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel36.setText("Vr");

  Btn_MultipleItemsIsOpnameRemove.setText("-");
  Btn_MultipleItemsIsOpnameRemove.setToolTipText("hapus tanda \"Di-Opname\" pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsIsOpnameRemove.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsIsOpnameRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsIsOpnameRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleItemsIsOpnameAdd.setText("+");
  Btn_MultipleItemsIsOpnameAdd.setToolTipText("beri tanda \"Di-Opname\" pada brg-brg yg dipilih di dlm daftar");
  Btn_MultipleItemsIsOpnameAdd.setMargin(new java.awt.Insets(1, 2, 1, 2));
  Btn_MultipleItemsIsOpnameAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleItemsIsOpnameAddActionPerformed(evt);
   }
  });

  jLabel37.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel37.setForeground(new java.awt.Color(204, 51, 0));
  jLabel37.setText("OP");

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Find)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindBefore)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel29)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsActiveAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsActiveRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel37)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsIsOpnameAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsIsOpnameRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel33)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsIsReorderAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsIsReorderRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel6)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsCategoryAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsCategoryRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel20)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsTagAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsTagRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel7)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsPicAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsPicRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel36)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsVartAdd)
    .addGap(6, 6, 6)
    .addComponent(Btn_MultipleItemsVartRemove)
    .addGap(10, 10, 10)
    .addComponent(jLabel11)
    .addGap(5, 5, 5)
    .addComponent(Btn_MultipleItemsSupAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleItemsSupRemove))
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_MultipleItemsSupRemove)
    .addComponent(Btn_MultipleItemsSupAdd)
    .addComponent(jLabel11)
    .addComponent(Btn_MultipleItemsPicRemove)
    .addComponent(Btn_MultipleItemsPicAdd)
    .addComponent(jLabel7)
    .addComponent(Btn_MultipleItemsTagRemove)
    .addComponent(Btn_MultipleItemsTagAdd)
    .addComponent(jLabel20)
    .addComponent(Btn_MultipleItemsCategoryRemove)
    .addComponent(Btn_MultipleItemsCategoryAdd)
    .addComponent(jLabel6)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_FindBefore)
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_MultipleItemsActiveRemove)
    .addComponent(Btn_MultipleItemsActiveAdd)
    .addComponent(jLabel29)
    .addComponent(Btn_MultipleItemsIsReorderRemove)
    .addComponent(Btn_MultipleItemsIsReorderAdd)
    .addComponent(jLabel33)
    .addComponent(Btn_MultipleItemsVartRemove)
    .addComponent(Btn_MultipleItemsVartAdd)
    .addComponent(jLabel36)
    .addComponent(Btn_MultipleItemsIsOpnameRemove)
    .addComponent(Btn_MultipleItemsIsOpnameAdd)
    .addComponent(jLabel37))
  );

  Tbl_Item.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Item.setToolTipText("F9 - tambah ke DaftarKu ; F10 - hapus dr DaftarKu ; Spasi - alih fokus ke input atribut opname");
  Tbl_Item.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Item.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Item.setRowHeight(18);
  Tbl_Item.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemMouseReleased(evt);
   }
  });
  Tbl_Item.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_ItemKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemKeyReleased(evt);
   }
  });
  jScrollPane18.setViewportView(Tbl_Item);

  Pnl_CheckerItemPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_CheckerItemPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_CheckerItemPreviewMouseClicked(evt);
   }
  });

  TA_CheckerItemName.setEditable(false);
  TA_CheckerItemName.setBackground(new java.awt.Color(204, 204, 255));
  TA_CheckerItemName.setColumns(5);
  TA_CheckerItemName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TA_CheckerItemName.setForeground(new java.awt.Color(102, 0, 0));
  TA_CheckerItemName.setLineWrap(true);
  TA_CheckerItemName.setRows(1);
  TA_CheckerItemName.setWrapStyleWord(true);
  jScrollPane21.setViewportView(TA_CheckerItemName);

  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CmB_ViewMode.setBackground(new java.awt.Color(255, 220, 209));
  CmB_ViewMode.setToolTipText("Pilih mode tampilan daftar barang di tabel");
  CmB_ViewMode.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ViewModeActionPerformed(evt);
   }
  });

  CB_ViewHasExp.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewHasExp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewHasExp.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewHasExp.setText("Ex");
  CB_ViewHasExp.setToolTipText("Memiliki Expire");
  CB_ViewHasExp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewHasExp.setIconTextGap(0);
  CB_ViewHasExp.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewHasExp.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewHasExpActionPerformed(evt);
   }
  });

  CB_ViewExpThreshold.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewExpThreshold.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewExpThreshold.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewExpThreshold.setText("Bt");
  CB_ViewExpThreshold.setToolTipText("Batas Expire");
  CB_ViewExpThreshold.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewExpThreshold.setIconTextGap(0);
  CB_ViewExpThreshold.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewExpThreshold.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewExpThresholdActionPerformed(evt);
   }
  });

  CB_ViewExpCheckPeriod.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewExpCheckPeriod.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewExpCheckPeriod.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewExpCheckPeriod.setToolTipText("Cek Expire Tiap");
  CB_ViewExpCheckPeriod.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewExpCheckPeriod.setIconTextGap(0);
  CB_ViewExpCheckPeriod.setLabel("C");
  CB_ViewExpCheckPeriod.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewExpCheckPeriod.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewExpCheckPeriodActionPerformed(evt);
   }
  });

  CB_ViewSellUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSellUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSellUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSellUpdate.setToolTipText("Tgl Update Harga Jual");
  CB_ViewSellUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSellUpdate.setIconTextGap(0);
  CB_ViewSellUpdate.setLabel("T");
  CB_ViewSellUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSellUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSellUpdateActionPerformed(evt);
   }
  });

  CB_ViewSellPriceComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSellPriceComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSellPriceComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSellPriceComment.setText("C");
  CB_ViewSellPriceComment.setToolTipText("Keterangan Harga Jual");
  CB_ViewSellPriceComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSellPriceComment.setIconTextGap(0);
  CB_ViewSellPriceComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSellPriceComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSellPriceCommentActionPerformed(evt);
   }
  });

  CB_ViewSellPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSellPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSellPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSellPrice.setToolTipText("Harga Jual");
  CB_ViewSellPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSellPrice.setIconTextGap(0);
  CB_ViewSellPrice.setLabel("Jl");
  CB_ViewSellPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSellPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSellPriceActionPerformed(evt);
   }
  });

  CB_ViewBuyUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewBuyUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewBuyUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewBuyUpdate.setToolTipText("Tgl Update Harga Beli");
  CB_ViewBuyUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewBuyUpdate.setIconTextGap(0);
  CB_ViewBuyUpdate.setLabel("T");
  CB_ViewBuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewBuyUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewBuyUpdateActionPerformed(evt);
   }
  });

  CB_ViewBuyPriceComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewBuyPriceComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewBuyPriceComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewBuyPriceComment.setToolTipText("Keterangan Harga Beli");
  CB_ViewBuyPriceComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewBuyPriceComment.setIconTextGap(0);
  CB_ViewBuyPriceComment.setLabel("C");
  CB_ViewBuyPriceComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewBuyPriceComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewBuyPriceCommentActionPerformed(evt);
   }
  });

  CB_ViewBuyPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewBuyPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewBuyPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewBuyPrice.setText("Bl");
  CB_ViewBuyPrice.setToolTipText("Harga Beli");
  CB_ViewBuyPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewBuyPrice.setIconTextGap(0);
  CB_ViewBuyPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewBuyPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewBuyPriceActionPerformed(evt);
   }
  });

  CB_ViewStockIsUpdate.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewStockIsUpdate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewStockIsUpdate.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewStockIsUpdate.setText("B");
  CB_ViewStockIsUpdate.setToolTipText("Stok Diperbarui");
  CB_ViewStockIsUpdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewStockIsUpdate.setIconTextGap(0);
  CB_ViewStockIsUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewStockIsUpdate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewStockIsUpdateActionPerformed(evt);
   }
  });

  CB_ViewStockUnit.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewStockUnit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewStockUnit.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewStockUnit.setText("U");
  CB_ViewStockUnit.setToolTipText("Satuan Stok");
  CB_ViewStockUnit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewStockUnit.setIconTextGap(0);
  CB_ViewStockUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewStockUnitActionPerformed(evt);
   }
  });

  CB_ViewOrderPackMin.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewOrderPackMin.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewOrderPackMin.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewOrderPackMin.setText(">");
  CB_ViewOrderPackMin.setToolTipText("Order - Min Pak");
  CB_ViewOrderPackMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewOrderPackMin.setIconTextGap(0);
  CB_ViewOrderPackMin.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewOrderPackMin.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewOrderPackMinActionPerformed(evt);
   }
  });

  CB_ViewOrderPackThreshold.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewOrderPackThreshold.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewOrderPackThreshold.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewOrderPackThreshold.setText("%");
  CB_ViewOrderPackThreshold.setToolTipText("Order - Pembulatan / Pak");
  CB_ViewOrderPackThreshold.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewOrderPackThreshold.setIconTextGap(0);
  CB_ViewOrderPackThreshold.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewOrderPackThreshold.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewOrderPackThresholdActionPerformed(evt);
   }
  });

  CB_ViewOrderPackQty.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewOrderPackQty.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewOrderPackQty.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewOrderPackQty.setText("Q");
  CB_ViewOrderPackQty.setToolTipText("Order - Qty / Pak");
  CB_ViewOrderPackQty.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewOrderPackQty.setIconTextGap(0);
  CB_ViewOrderPackQty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewOrderPackQty.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewOrderPackQtyActionPerformed(evt);
   }
  });

  CB_ViewIsReorder.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewIsReorder.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewIsReorder.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewIsReorder.setText("R");
  CB_ViewIsReorder.setToolTipText("Di-Reorder");
  CB_ViewIsReorder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewIsReorder.setIconTextGap(0);
  CB_ViewIsReorder.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewIsReorder.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIsReorderActionPerformed(evt);
   }
  });

  CB_ViewIsOpname.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewIsOpname.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewIsOpname.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewIsOpname.setText("O");
  CB_ViewIsOpname.setToolTipText("Di-Opname");
  CB_ViewIsOpname.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewIsOpname.setIconTextGap(0);
  CB_ViewIsOpname.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewIsOpname.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIsOpnameActionPerformed(evt);
   }
  });

  CB_ViewStockMinMax.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewStockMinMax.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewStockMinMax.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewStockMinMax.setText("M");
  CB_ViewStockMinMax.setToolTipText("Stok Min-Max");
  CB_ViewStockMinMax.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewStockMinMax.setIconTextGap(0);
  CB_ViewStockMinMax.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewStockMinMax.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewStockMinMaxActionPerformed(evt);
   }
  });

  CB_ViewStockEst.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewStockEst.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewStockEst.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewStockEst.setText("Ks");
  CB_ViewStockEst.setToolTipText("Kisaran Stok");
  CB_ViewStockEst.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewStockEst.setIconTextGap(0);
  CB_ViewStockEst.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewStockEst.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewStockEstActionPerformed(evt);
   }
  });

  CB_ViewStockPre.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewStockPre.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewStockPre.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewStockPre.setText("Pr");
  CB_ViewStockPre.setToolTipText("Stok Pra Masuk & Keluar");
  CB_ViewStockPre.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewStockPre.setIconTextGap(0);
  CB_ViewStockPre.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewStockPre.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewStockPreActionPerformed(evt);
   }
  });

  CB_ViewStock.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewStock.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewStock.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewStock.setText("St");
  CB_ViewStock.setToolTipText("Stok");
  CB_ViewStock.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewStock.setIconTextGap(0);
  CB_ViewStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewStock.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewStockActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_ViewNormalModeLayout = new javax.swing.GroupLayout(Pnl_ViewNormalMode);
  Pnl_ViewNormalMode.setLayout(Pnl_ViewNormalModeLayout);
  Pnl_ViewNormalModeLayout.setHorizontalGroup(
   Pnl_ViewNormalModeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_ViewNormalModeLayout.createSequentialGroup()
    .addComponent(CB_ViewStock)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewStockPre)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewStockEst)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewStockMinMax)
    .addGap(16, 16, 16)
    .addComponent(CB_ViewIsOpname)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewIsReorder)
    .addGap(16, 16, 16)
    .addComponent(CB_ViewOrderPackQty)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewOrderPackThreshold)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewOrderPackMin)
    .addGap(16, 16, 16)
    .addComponent(CB_ViewStockUnit)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewStockIsUpdate)
    .addGap(16, 16, 16)
    .addComponent(CB_ViewBuyPrice)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewBuyPriceComment)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewBuyUpdate)
    .addGap(16, 16, 16)
    .addComponent(CB_ViewSellPrice)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewSellPriceComment)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewSellUpdate)
    .addGap(16, 16, 16)
    .addComponent(CB_ViewExpCheckPeriod)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewExpThreshold)
    .addGap(6, 6, 6)
    .addComponent(CB_ViewHasExp))
  );
  Pnl_ViewNormalModeLayout.setVerticalGroup(
   Pnl_ViewNormalModeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_ViewNormalModeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_ViewHasExp)
    .addComponent(CB_ViewExpThreshold)
    .addComponent(CB_ViewExpCheckPeriod)
    .addComponent(CB_ViewSellUpdate)
    .addComponent(CB_ViewSellPriceComment)
    .addComponent(CB_ViewSellPrice)
    .addComponent(CB_ViewBuyUpdate)
    .addComponent(CB_ViewBuyPriceComment)
    .addComponent(CB_ViewBuyPrice)
    .addComponent(CB_ViewStockIsUpdate)
    .addComponent(CB_ViewStockUnit)
    .addComponent(CB_ViewOrderPackMin)
    .addComponent(CB_ViewOrderPackThreshold)
    .addComponent(CB_ViewOrderPackQty)
    .addComponent(CB_ViewIsReorder)
    .addComponent(CB_ViewIsOpname)
    .addComponent(CB_ViewStockMinMax)
    .addComponent(CB_ViewStockEst)
    .addComponent(CB_ViewStockPre)
    .addComponent(CB_ViewStock))
  );

  TF_CheckerInfo.setEditable(false);
  TF_CheckerInfo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CheckerInfo.setForeground(new java.awt.Color(102, 0, 0));
  TF_CheckerInfo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_CheckerInfo.setText(" ");
  TF_CheckerInfo.setBorder(null);
  TF_CheckerInfo.setOpaque(false);

  Btn_CheckerP1.setText("P1");
  Btn_CheckerP1.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CheckerP1.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CheckerP1ActionPerformed(evt);
   }
  });

  Btn_CheckerP2.setText("P2");
  Btn_CheckerP2.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CheckerP2.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CheckerP2ActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_CheckerInfoLayout = new javax.swing.GroupLayout(Pnl_CheckerInfo);
  Pnl_CheckerInfo.setLayout(Pnl_CheckerInfoLayout);
  Pnl_CheckerInfoLayout.setHorizontalGroup(
   Pnl_CheckerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_CheckerInfoLayout.createSequentialGroup()
    .addComponent(Btn_CheckerP1)
    .addGap(4, 4, 4)
    .addComponent(Btn_CheckerP2)
    .addGap(2, 2, 2)
    .addComponent(TF_CheckerInfo, javax.swing.GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE))
  );
  Pnl_CheckerInfoLayout.setVerticalGroup(
   Pnl_CheckerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_CheckerInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_CheckerP1)
    .addComponent(TF_CheckerInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_CheckerP2))
  );

  CB_ViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCategorized.setText("K");
  CB_ViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCategorized.setIconTextGap(0);
  CB_ViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(CmB_ViewMode, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Pnl_CheckerInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Pnl_ViewNormalMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CmB_ViewMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_ViewCategorized))
   .addComponent(Pnl_ViewNormalMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(Pnl_CheckerInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
  );

  javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
  jPanel17.setLayout(jPanel17Layout);
  jPanel17Layout.setHorizontalGroup(
   jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane21)
   .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel17Layout.setVerticalGroup(
   jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel17Layout.createSequentialGroup()
    .addComponent(jScrollPane21)
    .addGap(0, 0, 0)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Pnl_CheckerInput.setBackground(new java.awt.Color(204, 204, 255));
  Pnl_CheckerInput.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_CheckerAttr2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TF_CheckerAttr2.setForeground(new java.awt.Color(102, 0, 0));
  TF_CheckerAttr2.setToolTipText("format input atribut : tahun-bulan-tanggal, contohnya 2018-06-13; {Spasi} alih fokus ke tabel");
  TF_CheckerAttr2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CheckerAttr2FocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_CheckerAttr2FocusLost(evt);
   }
  });
  TF_CheckerAttr2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CheckerAttr2KeyPressed(evt);
   }
  });

  CmB_CheckerAttr2.setBackground(new java.awt.Color(204, 204, 255));
  CmB_CheckerAttr2.setForeground(new java.awt.Color(102, 0, 0));
  CmB_CheckerAttr2.setToolTipText("pilih opsi pembaharuan pada atribut");
  CmB_CheckerAttr2.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_CheckerAttr2ActionPerformed(evt);
   }
  });

  CB_CheckerAttr2.setBackground(new java.awt.Color(204, 204, 255));
  CB_CheckerAttr2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_CheckerAttr2.setToolTipText("centang utk memperbaharui atribut");
  CB_CheckerAttr2.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CheckerAttr2.setOpaque(false);

  TF_CheckerAttr1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TF_CheckerAttr1.setForeground(new java.awt.Color(102, 0, 0));
  TF_CheckerAttr1.setToolTipText("format input atribut : hanya angka (0-9), maks 9 digit; {Spasi} alih fokus ke tabel");
  TF_CheckerAttr1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CheckerAttr1FocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_CheckerAttr1FocusLost(evt);
   }
  });
  TF_CheckerAttr1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CheckerAttr1KeyPressed(evt);
   }
  });

  CmB_CheckerAttr1.setBackground(new java.awt.Color(204, 204, 255));
  CmB_CheckerAttr1.setForeground(new java.awt.Color(102, 0, 0));
  CmB_CheckerAttr1.setToolTipText("pilih opsi pembaharuan pada atribut");
  CmB_CheckerAttr1.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_CheckerAttr1ActionPerformed(evt);
   }
  });

  CB_CheckerAttr1.setBackground(new java.awt.Color(204, 204, 255));
  CB_CheckerAttr1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_CheckerAttr1.setToolTipText("centang utk memperbaharui atribut");
  CB_CheckerAttr1.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CheckerAttr1.setOpaque(false);

  TF_CheckerItemId.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TF_CheckerItemId.setForeground(new java.awt.Color(102, 0, 0));
  TF_CheckerItemId.setToolTipText("Inputan Id : {F12} lihat ket. brg, {Spasi} alih fokus ke tabel");
  TF_CheckerItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CheckerItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_CheckerItemIdFocusLost(evt);
   }
  });
  TF_CheckerItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CheckerItemIdKeyPressed(evt);
   }
  });

  CmB_CheckerIdInput.setBackground(new java.awt.Color(204, 204, 255));
  CmB_CheckerIdInput.setForeground(new java.awt.Color(102, 0, 0));
  CmB_CheckerIdInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Inputan Id", "Pilihan Tabel" }));
  CmB_CheckerIdInput.setToolTipText("pilih metode input dari data barang yg akan diperbaharui nilai atribut-nya");
  CmB_CheckerIdInput.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_CheckerIdInputActionPerformed(evt);
   }
  });

  Btn_CheckerExecute.setForeground(new java.awt.Color(102, 0, 0));
  Btn_CheckerExecute.setText("Perbarui {F5}");
  Btn_CheckerExecute.setToolTipText("klik utk memperbaharui atribut-atribut");
  Btn_CheckerExecute.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_CheckerExecute.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CheckerExecuteActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_CheckerInputLayout = new javax.swing.GroupLayout(Pnl_CheckerInput);
  Pnl_CheckerInput.setLayout(Pnl_CheckerInputLayout);
  Pnl_CheckerInputLayout.setHorizontalGroup(
   Pnl_CheckerInputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_CheckerInputLayout.createSequentialGroup()
    .addComponent(CmB_CheckerIdInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_CheckerItemId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_CheckerAttr1)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_CheckerAttr1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_CheckerAttr1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_CheckerAttr2)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_CheckerAttr2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_CheckerAttr2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_CheckerExecute))
  );
  Pnl_CheckerInputLayout.setVerticalGroup(
   Pnl_CheckerInputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_CheckerInputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_CheckerAttr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_CheckerAttr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_CheckerExecute))
   .addGroup(Pnl_CheckerInputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
    .addComponent(CB_CheckerAttr1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pnl_CheckerInputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CheckerAttr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_CheckerAttr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pnl_CheckerInputLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CheckerItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_CheckerIdInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addComponent(CB_CheckerAttr2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
  jPanel16.setLayout(jPanel16Layout);
  jPanel16Layout.setHorizontalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
    .addGap(0, 0, 0)
    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Pnl_CheckerInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
  );
  jPanel16Layout.setVerticalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
    .addComponent(Pnl_CheckerInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout Pnl_CheckerLayout = new javax.swing.GroupLayout(Pnl_Checker);
  Pnl_Checker.setLayout(Pnl_CheckerLayout);
  Pnl_CheckerLayout.setHorizontalGroup(
   Pnl_CheckerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_CheckerLayout.createSequentialGroup()
    .addComponent(Pnl_CheckerItemPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  Pnl_CheckerLayout.setVerticalGroup(
   Pnl_CheckerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_CheckerItemPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane18)
   .addComponent(Pnl_Checker, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane18)
    .addGap(0, 0, 0)
    .addComponent(Pnl_Checker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addGap(12, 12, 12)
    .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(TabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 656, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  runQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void Btn_FCatNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatNextActionPerformed
  findCategoryInList(1);
 }//GEN-LAST:event_Btn_FCatNextActionPerformed

 private void Btn_FCatBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FCatBeforeActionPerformed
  findCategoryInList(2);
 }//GEN-LAST:event_Btn_FCatBeforeActionPerformed

 private void Btn_FindBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBeforeActionPerformed
  findItemInTable(2);
 }//GEN-LAST:event_Btn_FindBeforeActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findItemInTable(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void Btn_QCatAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCatAddActionPerformed
  int temp, temp_;
  Object[] row;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfItem;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    row=new Object[2];
    row[0]=(int)IFV.FDataIdName.DataId[temp_];
    row[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQCat.append(row);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QCatAddActionPerformed

 private void Btn_QCatRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCatRemoveActionPerformed
  ListMdlQCat.remove(List_QCat.getSelectedIndices());
 }//GEN-LAST:event_Btn_QCatRemoveActionPerformed

 private void Btn_NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_NewActionPerformed
  boolean bool, found;
  Object[] NewRow;
  long Id;
  String Name;
  int insertpos;
  double OrderPriceEst;
  int result;
  String FindName=null;
  int FindColumn=0;
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  Date BuyUpdate=null;
  Date SellUpdate=null;
  
  if(!PGUI.isEnabled(Btn_New)){return;}
  
  IFV.FItemModify.wMode=0;
  
  if(IFV.FItemModify.showForm()==false){return;}
  if(IFV.FItemModify.DialogResult!=1){return;}
   
  Id=IFV.FItemModify.Id;
  Name=IFV.FItemModify.Name;

  bool=false;
  do{
   try{
    result=PMyShop.checkExistIdOnItem(Id, IFV.Stm);
    if(result==-1){break;}
    if(result==1){JOptionPane.showMessageDialog(null, "Tidak dapat menambah : Id / Secondary-Id Barang sudah ada !"); return;}

    SellUpdate=IFV.FItemModify.SellUpdate; if(SellUpdate==null){SellUpdate=PDate.generateDate(new Date(), false);}
    BuyUpdate=IFV.FItemModify.BuyUpdate; if(BuyUpdate==null){BuyUpdate=PDate.generateDate(new Date(), false);}
    
    try{
     IFV.Stm.executeUpdate(
      "insert into Item("+
       "Id, Name, IsActive, Comment, "+
       "StockUnit, Stock, UpdateStockOnTransaction, MinimalStock, MaximalStock, "+
       "IsOpname, IsReorder, OrderEachPackQty, OrderEachPackThreshold, OrderMinPack, "+
       "HasExpireDate, ExpireCheckPeriod, ExpireThreshold, "+
       "SellPrice, SellPriceComment, SellUpdate, BuyPriceEstimation, BuyPriceComment, BuyUpdate, "+
       "OpnameStock, OpnameExpire, OrderQuantity"+
      ") values("+
      Id+", '"+PSql.norm(Name)+"', "+PText.getString(IFV.FItemModify.IsActive, CCore.vTrue, CCore.vFalse)+", "+PText.getStringWithQuote(PSql.norm(IFV.FItemModify.Comment), CCore.vNull, '\'', true)+", "+
      PText.getString(IFV.FItemModify.StockUnitId, -1, String.valueOf(IFV.FItemModify.StockUnitId), CCore.vNull)+", "+PText.doubleToString(IFV.FItemModify.Stock, false)+", "+
       PText.getString(IFV.FItemModify.UpdateStock, CCore.vTrue, CCore.vFalse)+", "+
       PText.doubleToString(IFV.FItemModify.MinStock, false)+", "+PText.doubleToString(IFV.FItemModify.MaxStock, false)+", "+
       PText.getString(IFV.FItemModify.IsOpname, CCore.vTrue, CCore.vFalse)+", "+
       PText.getString(IFV.FItemModify.IsReorder, CCore.vTrue, CCore.vFalse)+", "+
       PText.doubleToString(IFV.FItemModify.OrderEachPackQty, false)+", "+PText.doubleToString(IFV.FItemModify.OrderEachPackThreshold, false)+", "+PText.doubleToString(IFV.FItemModify.OrderMinPack, false)+", "+
      PText.getString(IFV.FItemModify.HasExpireDate, CCore.vTrue, CCore.vFalse)+", "+
       PText.getString(IFV.FItemModify.ExpireCheckPeriod, CCore.vNull, -1, false)+", "+PText.getString(IFV.FItemModify.ExpireThreshold, CCore.vNull, -1, false)+", "+
      PText.doubleToString(IFV.FItemModify.SellPrice, false)+", "+PText.getStringWithQuote(PSql.norm(IFV.FItemModify.SellPriceComment), CCore.vNull, '\'', true)+", "+PDatabase.dateToSQLStringFormat(SellUpdate)+", "+
       PText.doubleToString(IFV.FItemModify.BuyPriceEst, false)+", "+PText.getStringWithQuote(PSql.norm(IFV.FItemModify.BuyPriceComment), CCore.vNull, '\'', true)+", "+PDatabase.dateToSQLStringFormat(BuyUpdate)+", "+
      PText.getStringDouble2(IFV.FItemModify.OpStock, CCore.vNull, false, false)+", "+PDatabase.dateToSQLStringFormat(IFV.FItemModify.OpExpire)+", "+
       PText.getStringDouble(IFV.FItemModify.OrderQty, CCore.vNull, -0.1, false, false)+");");
    }
    catch(Exception E){
     JOptionPane.showMessageDialog(null, "Gagal menambah data barang !"+
      "\nMungkin disebabkan Nama Barang sudah ada !");
     return;
    }
   }
   catch(Exception E){break;}
   bool=true;
  }while(false);
  if(bool==false){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }

  NewRow=new Object[TableItemColsName.length];
  NewRow[0]=Id;
  NewRow[1]=Name;
  NewRow[2]=IFV.FItemModify.IsActive;
  NewRow[3]=IFV.FItemModify.Stock;
  NewRow[4]=IFV.FItemModify.MinStock;
  NewRow[5]=IFV.FItemModify.MaxStock;
  NewRow[6]=IFV.FItemModify.OrderEachPackQty;
  NewRow[7]=IFV.FItemModify.OrderEachPackThreshold;
  NewRow[8]=IFV.FItemModify.OrderMinPack;
  NewRow[9]=IFV.FItemModify.IsOpname;
  NewRow[10]=IFV.FItemModify.IsReorder;
  NewRow[11]=PCore.subtituteLong(IFV.FItemModify.StockUnitId, -1, IFV.FItemModify.StockUnitId, null);
  NewRow[12]=PCore.subtituteLong(IFV.FItemModify.StockUnitId, -1, IFV.FItemModify.StockUnitName, null);
  NewRow[13]=IFV.FItemModify.UpdateStock;
  NewRow[14]=PCore.subtituteLong(IFV.FItemModify.ExpireCheckPeriod, -1, IFV.FItemModify.ExpireCheckPeriod, null);
  NewRow[15]=PCore.subtituteLong(IFV.FItemModify.ExpireThreshold, -1, IFV.FItemModify.ExpireThreshold, null);
  NewRow[16]=PCore.subtituteLong(IFV.FItemModify.ExpireThreshold, -1, PDate.calculateDateByDay(new Date(), IFV.FItemModify.ExpireThreshold, 1), null);
  NewRow[17]=IFV.FItemModify.HasExpireDate;
  NewRow[18]=IFV.FItemModify.SellPrice;
  NewRow[19]=IFV.FItemModify.SellPriceComment;
  NewRow[20]=SellUpdate;
  NewRow[21]=IFV.FItemModify.BuyPriceEst;
  NewRow[22]=IFV.FItemModify.BuyPriceComment;
  NewRow[23]=BuyUpdate;
  NewRow[24]=IFV.FItemModify.OpStock;
  NewRow[25]=IFV.FItemModify.OpExpire;
  NewRow[26]=PCore.subtituteDouble(IFV.FItemModify.OrderQty, -0.1, IFV.FItemModify.OrderQty, null);
  OrderPriceEst=0; if(IFV.FItemModify.OrderQty!=-1){OrderPriceEst=IFV.FItemModify.OrderQty*IFV.FItemModify.BuyPriceEst;}
  NewRow[27]=PCore.subtituteDouble(IFV.FItemModify.OrderQty, -0.1, OrderPriceEst, null);
  NewRow[28]=null;
  NewRow[29]=null;
  NewRow[30]=IFV.FItemModify.Stock;
  NewRow[31]=null;
  NewRow[32]=null;
  
  if(!IsCategorized){FindColumn=1;}else{FindColumn=32;}
  FindName=PCore.objString(NewRow[FindColumn], null);
  insertpos=PGUI.findInsertPos(TableItemMdl, FindColumn, FindName, false, true, true);
  TableItemMdl.insert(insertpos, NewRow);

  updateQueryCount();
  found=TempList.checkElement(Id)>=0;
  TableItemMdl.setChecked(insertpos, found); updateQueryTempListCount();
  
  addOrderTotalPriceTbl(OrderPriceEst, true);
  if(found){addOrderTotalPriceTempList(OrderPriceEst, true);}
  
  refreshCheckerInfo();

  Tbl_Item.changeSelection(insertpos, 0, false, false); onTableSelectedRowChanged(true);
 }//GEN-LAST:event_Btn_NewActionPerformed

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  int[] rows;
  int count;
  
  if(!PGUI.isEnabled(Btn_Edit)){return;}
  
  rows=Tbl_Item.getSelectedRows();
  
  count=rows.length;
  if(count==0){return;}
  if(count==1){editSingle(rows[0]); return;}
  if(count>1){editMultiple(rows); return;}
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  int[] rows, removerows, checkedrows;
  boolean bool;
  int temp, removcount;
  boolean[] IsRemove;
  double progress_inc;
  Object[] SumTbl, SumTempList;
  
  if(!PGUI.isEnabled(Btn_Remove)){return;}
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length!=0){
   if(JOptionPane.showConfirmDialog(null, "Hapus "+PText.intToString(rows.length)+" barang yg dipilih pada daftar barang ?"+
    "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
    "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
    
    IFV.FSplashScreen.appear(this, "Menghapus Data Barang");
    
    IFV.FSplashScreen.inform(0, "Menghapus "+PText.intToString(rows.length)+" data barang, harap menunggu ...", "-");
    
    IsRemove=PCore.newBooleanArray(rows.length, false);
    removcount=0;
    progress_inc=(double)100/(double)rows.length;
    temp=0;
    do{
     // IFV.FSplashScreen.inform(0, null, "Menghapus data ke-"+PText.intToString(temp+1));
     bool=true;
     try{IFV.Stm.executeUpdate("delete from Item where Id="+(Long)TableItemMdl.Mdl.Rows.elementAt(rows[temp])[0]+";");}
     catch(Exception E){bool=false;}
     if(bool==true){
      removcount=removcount+1;
      IsRemove[temp]=true;
     }
     temp=temp+1;
     IFV.FSplashScreen.inform(progress_inc, null, null);
    }while(temp!=rows.length);
    
    IFV.FSplashScreen.disappear();
    
    if(removcount!=0){
     removerows=PGUI.getPickedRows(rows, IsRemove, true);
     checkedrows=TableItemMdl.getChecked(removerows, true);
     SumTbl=PGUI.sumColumns(TableItemMdl, PCore.primArr(27), removerows);
     SumTempList=PGUI.sumColumns(TableItemMdl, PCore.primArr(27), checkedrows);
     addOrderTotalPriceTbl((Double)SumTbl[0], false);
     addOrderTotalPriceTempList((Double)SumTempList[0], false);
     TableItemMdl.remove(removerows);
     onTableSelectedRowChanged(true);
     updateQueryCount();
     updateQueryTempListCount();
     refreshCheckerInfo();
    }
    if(removcount!=rows.length){
     JOptionPane.showMessageDialog(null, "Gagal menghapus "+(rows.length-removcount)+" data !"+
      "\nMungkin data barang tsb masih terdaftar pd suatu transaksi !");
    }
   }
  }
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  if(wMode==1){DialogResult=0;}
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   if(wMode==0){
    setTitle("Barang");
    Btn_Report.setVisible(true);
    CmB_ReportType.setVisible(true);
    Btn_Choose.setText("Impor-Ekspor {F11}");
   }
   else{
    setTitle("Cari dan Pilih Barang");
    Btn_Report.setVisible(false);
    CmB_ReportType.setVisible(false);
    Btn_Choose.setText("Pilih {F11}");
   }
   dialogWithFSubject(wDialogWithFSubject);
   if(wAllowMultipleSelection==false){
    Tbl_Item.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
   }
   else{
    Tbl_Item.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
   }
   Lbl_MultipleSelection.setVisible(wAllowMultipleSelection && wMode!=0);
   
   refreshBackgroundVariables_All();
   refreshBackgroundVariables_TempList();
   refreshCheckerInfo();
   
   initPrivGUIShow();
   
   onTabbedPaneChanged();
   
   TF_QName.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void Lbl_QIdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QIdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 18, 2, 0, 0, 0, false));
 }//GEN-LAST:event_Lbl_QIdHelpMouseClicked

 private void Lbl_QNameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QNameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 150, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QNameHelpMouseClicked

 private void Lbl_QStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QStockHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Parameter2 >= Parameter1.\n"+
   PText.getInputInfo(false, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_QStockHelpMouseClicked

 private void Lbl_QPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter2 >= Parameter1.\n"+PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_QPriceHelpMouseClicked

 private void Btn_ItemPictureAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemPictureAddActionPerformed
  boolean firstinsert, error;
  int row;
  int MaxEachInsert, CurrInsertCount;
  int currpic, piclength;
  long Id;
  String[] FilesName;
  Object[] RowData;
  StringBuilder Values;
  int insertpos;
  Vector<OTableCellUpdater> Updater;
  OTableCellReference[] CheckCells;
  
  row=Tbl_Item.getSelectedRow();
  if(row==-1){return;}
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Tambah (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(row)[0];
  MaxEachInsert=1000;
  FilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  piclength=FilesName.length;
  currpic=0;
  error=false;
  do{
   Values=new StringBuilder();
   
   CurrInsertCount=0;
   firstinsert=true;
   do{
    if(firstinsert){firstinsert=false;}else{Values.append(',');}
    Values.append("("+Id+",'"+PSql.norm(FilesName[currpic])+"')");
    CurrInsertCount=CurrInsertCount+1;
    
    currpic=currpic+1;
   }while(currpic!=piclength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXPicture(Item, FileName) values "+Values.toString());}
   catch(Exception E){error=true;}
  }while(currpic!=piclength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  Updater=new Vector();
  CheckCells=new OTableCellReference[1]; CheckCells[0]=new OTableCellReference(0, 0, 0, 0);
  Updater.addElement(new OTableCellUpdaterSelect(
   new OTableCellUpdaterSelectCheckerNull(true, 31, CheckCells),
   new OTableCellUpdaterByObject(31, FilesName[0]),
   new OTableCellUpdaterByNone(31)));
  PGUI.changeElements(TableItemMdl, PCore.primArr(row), Updater);
  
  currpic=0;
  insertpos=-1;
  do{
   if(PGUI.findString(ListMdlItemPic, 0, FilesName[currpic])==-1){
    RowData=new Object[1];
    RowData[0]=FilesName[currpic];
    insertpos=PGUI.findInsertPos(ListMdlItemPic, 0, FilesName[currpic], false, true, true);
    ListMdlItemPic.insert(insertpos, RowData);
   }
   currpic=currpic+1;
  }while(currpic!=piclength);
  if(insertpos!=-1){
   List_ItemPicture.setSelectedIndex(insertpos); List_ItemPicture.ensureIndexIsVisible(insertpos); onListPicRowSelected(true);
  }
  IIPic=true; IIPicClear=false; IIEmptyAll=false;
 }//GEN-LAST:event_Btn_ItemPictureAddActionPerformed

 private void Btn_ItemPictureRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemPictureRemoveActionPerformed
  int[] rows=List_ItemPicture.getSelectedIndices();
  int rowItem=Tbl_Item.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currpic, currpiclistcount, piclength;
  String PicList;
  
  if(rows.length==0 || rowItem==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" gambar yang dipilih dari daftar gambar barang ?"+
   "\n(operasi ini hanya menghapus data di database dan tidak menghapus file yang sebenarnya)",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rowItem)[0];
  MaxList=1000;
  error=false;
  piclength=rows.length;
  currpic=0;
  do{
   currpiclistcount=MaxList;
   if(currpic+currpiclistcount>piclength){currpiclistcount=piclength-currpic;}
   PicList=PGUI.getElementList(ListMdlItemPic.Mdl.Rows, PCore.subArr(rows, currpic, currpiclistcount), 0, ",", "'", true);
   
   try{IFV.Stm.execute("delete ignore from ItemXPicture where Item="+Id+" and FileName in("+PicList+")");}
   catch(Exception E){error=true;}
   
   currpic=currpic+currpiclistcount;
  }while(currpic!=piclength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlItemPic.remove(rows);
  onListPicRowSelected(true);
 }//GEN-LAST:event_Btn_ItemPictureRemoveActionPerformed

 private void Btn_SuppAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppAddActionPerformed
  addSupp();
 }//GEN-LAST:event_Btn_SuppAddActionPerformed

 private void Btn_SuppEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppEditActionPerformed
  editSupp();
 }//GEN-LAST:event_Btn_SuppEditActionPerformed

 private void Btn_SuppRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppRemoveActionPerformed
  removeSupp();
 }//GEN-LAST:event_Btn_SuppRemoveActionPerformed

 private void Btn_ChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseActionPerformed
  if(!PGUI.isEnabled(Btn_Choose)){return;}
  if(wMode==0){csvImportExport();}
  else{chooseData();}
 }//GEN-LAST:event_Btn_ChooseActionPerformed

 private void TF_QIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QIdKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QId, TF_QId, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QId)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QIdKeyPressed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Item)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Find)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void TF_FindCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindCategoryKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FindCategory, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FCatBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FCatNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindCategoryKeyPressed

 private void Btn_ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReportActionPerformed
  switch(CmB_ReportType.getSelectedIndex()){
   case 0 : printReport(); break; // Report
   case 1 : printCheckList(); break; // Check List
   case 2 : printCatalog(); break; // Catalog
   case 3 : printOrder(); break; // Order
   case 4 : printCSV(); break; // CSV Report
  }
 }//GEN-LAST:event_Btn_ReportActionPerformed

 private void Btn_MultipleItemsCategoryAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsCategoryAddActionPerformed
  int[] rows;
  boolean firstinsert, error;
  int curritem, itemlength, currcat, catlength;
  int MaxEachInsert, CurrInsertCount;
  long Id;
  Object[] RowData;
  StringBuilder records;
  int insertpos;
  Vector<OTableCellUpdater> Updater;
  OTableCellReference[] CheckCells;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfItem;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Kategori Pada Beberapa Barang";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  itemlength=rows.length;
  curritem=0;
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
  currcat=0;
  catlength=IFV.FDataIdName.DataId.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+","+IFV.FDataIdName.DataId[currcat]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currcat=currcat+1;
    if(currcat==catlength){
     curritem=curritem+1;
     if(curritem!=itemlength){
      Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
      currcat=0;
     }
    }
   }while(curritem!=itemlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXCategory(Item, CategoryOfItem) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  Updater=new Vector();
  CheckCells=new OTableCellReference[1]; CheckCells[0]=new OTableCellReference(0, 0, 0, 0);
  Updater.addElement(new OTableCellUpdaterSelect(
   new OTableCellUpdaterSelectCheckerNull(true, 32, CheckCells),
   new OTableCellUpdaterByObject(32, IFV.FDataIdName.DataName[0]),
   new OTableCellUpdaterByNone(32)));
  PGUI.changeElements(TableItemMdl, rows, Updater);
  
  if(IIEtc){
   currcat=0;
   insertpos=-1;
   do{
    if(PGUI.findLong(ListMdlItemCat, 0, IFV.FDataIdName.DataId[currcat])==-1){
     RowData=new Object[2];
     RowData[0]=(int)IFV.FDataIdName.DataId[currcat];
     RowData[1]=IFV.FDataIdName.DataName[currcat];
     insertpos=PGUI.findInsertPos(ListMdlItemCat, 1, IFV.FDataIdName.DataName[currcat], false, true, true);
     ListMdlItemCat.insert(insertpos, RowData);
    }
    currcat=currcat+1;
   }while(currcat!=catlength);
   if(insertpos!=-1){
    List_ItemCategory.setSelectedIndex(insertpos); List_ItemCategory.ensureIndexIsVisible(insertpos);
   }
   IIEtcClear=false;
  }
 }//GEN-LAST:event_Btn_MultipleItemsCategoryAddActionPerformed

 private void Btn_MultipleItemsCategoryRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsCategoryRemoveActionPerformed
  int[] rows;
  boolean error;
  int MaxListCat, MaxListItem;
  int curritem, curritemlistcount, itemlength,
      currcat, currcatlistcount, catlength;
  int findindex;
  String ItemList, CatList;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfItem;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menghapus Kategori Dari Beberapa Barang";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}

  MaxListCat=1000;
  MaxListItem=1000;
  
  itemlength=rows.length;
  curritem=0;
  catlength=IFV.FDataIdName.DataId.length;
  error=false;
  
  do{
   curritemlistcount=MaxListItem;
   if(curritem+curritemlistcount>itemlength){curritemlistcount=itemlength-curritem;}
   ItemList=PGUI.getElementList(TableItemMdl.Mdl.Rows, PCore.subArr(rows, curritem, curritemlistcount), 0, ",", "", false);
   
   currcat=0;
   do{
    currcatlistcount=MaxListCat;
    if(currcat+currcatlistcount>catlength){currcatlistcount=catlength-currcat;}
    CatList=PText.toString(IFV.FDataIdName.DataId, currcat, currcatlistcount, ",");
    
    try{
     IFV.Stm.execute("delete ignore from ItemXCategory where Item in ("+ItemList+") and CategoryOfItem in ("+CatList+")");
    }
    catch(Exception E){error=true;}
    
    currcat=currcat+currcatlistcount;
   }while(currcat!=catlength);
   
   curritem=curritem+curritemlistcount;
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(IIEtc){
   currcat=0;
   do{
    findindex=PGUI.findLong(ListMdlItemCat, 0, IFV.FDataIdName.DataId[currcat]);
    if(findindex>=0){ListMdlItemCat.remove(findindex);}
    currcat=currcat+1;
   }while(currcat!=catlength);
  }
 }//GEN-LAST:event_Btn_MultipleItemsCategoryRemoveActionPerformed

 private void Btn_ItemCategoryRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemCategoryRemoveActionPerformed
  int[] rows=List_ItemCategory.getSelectedIndices();
  int rowItem=Tbl_Item.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currcat, currcatlistcount, catlength;
  String CatList;
  
  if(rows.length==0 || rowItem==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" kategori yg dipilih dari daftar kategori barang ?",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rowItem)[0];
  MaxList=1000;
  error=false;
  catlength=rows.length;
  currcat=0;
  do{
   currcatlistcount=MaxList;
   if(currcat+currcatlistcount>catlength){currcatlistcount=catlength-currcat;}
   CatList=PGUI.getElementList(ListMdlItemCat.Mdl.Rows, PCore.subArr(rows, currcat, currcatlistcount), 0, ",", "", false);
   
   try{IFV.Stm.execute("delete ignore from ItemXCategory where Item="+Id+" and CategoryOfItem in("+CatList+")");}
   catch(Exception E){error=true;}
   
   currcat=currcat+currcatlistcount;
  }while(currcat!=catlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlItemCat.remove(rows);
 }//GEN-LAST:event_Btn_ItemCategoryRemoveActionPerformed

 private void Btn_ItemCategoryAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemCategoryAddActionPerformed
  boolean firstinsert, error;
  int row;
  int MaxEachInsert, CurrInsertCount;
  int currcat, catlength;
  long Id;
  Object[] RowData;
  StringBuilder Values;
  int insertpos;
  Vector<OTableCellUpdater> Updater;
  OTableCellReference[] CheckCells;
  
  row=Tbl_Item.getSelectedRow();
  if(row==-1){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCategoryOfItem;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Kategori Pada Sebuah Barang";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(row)[0];
  MaxEachInsert=1000;
  catlength=IFV.FDataIdName.DataId.length;
  currcat=0;
  error=false;
  do{
   Values=new StringBuilder();
   
   CurrInsertCount=0;
   firstinsert=true;
   do{
    if(firstinsert){firstinsert=false;}else{Values.append(',');}
    Values.append("("+Id+","+IFV.FDataIdName.DataId[currcat]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currcat=currcat+1;
   }while(currcat!=catlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXCategory(Item, CategoryOfItem) values "+Values.toString());}
   catch(Exception E){error=true;}
  }while(currcat!=catlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  Updater=new Vector();
  CheckCells=new OTableCellReference[1]; CheckCells[0]=new OTableCellReference(0, 0, 0, 0);
  Updater.addElement(new OTableCellUpdaterSelect(
   new OTableCellUpdaterSelectCheckerNull(true, 32, CheckCells),
   new OTableCellUpdaterByObject(32, IFV.FDataIdName.DataName[0]),
   new OTableCellUpdaterByNone(32)));
  PGUI.changeElements(TableItemMdl, PCore.primArr(row), Updater);
  
  currcat=0;
  insertpos=-1;
  do{
   if(PGUI.findLong(ListMdlItemCat, 0, IFV.FDataIdName.DataId[currcat])==-1){
    RowData=new Object[2];
    RowData[0]=(int)IFV.FDataIdName.DataId[currcat];
    RowData[1]=IFV.FDataIdName.DataName[currcat];
    insertpos=PGUI.findInsertPos(ListMdlItemCat, 1, IFV.FDataIdName.DataName[currcat], false, true, true);
    ListMdlItemCat.insert(insertpos, RowData);
   }
   currcat=currcat+1;
  }while(currcat!=catlength);
  if(insertpos!=-1){
   List_ItemCategory.setSelectedIndex(insertpos); List_ItemCategory.ensureIndexIsVisible(insertpos);
  }
  IIEtc=true; IIEtcClear=false; IIEmptyAll=false;
 }//GEN-LAST:event_Btn_ItemCategoryAddActionPerformed

 private void Btn_MultipleItemsPicAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsPicAddActionPerformed
  int[] rows;
  long Id;
  String[] ImgFilesName;
  Object[] RowData;
  boolean firstinsert, error;
  int curritem, itemlength, currpic, piclength;
  int MaxEachInsert, CurrInsertCount;
  StringBuilder records;
  int insertpos;
  Vector<OTableCellUpdater> Updater;
  OTableCellReference[] CheckCells;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Tambah (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  itemlength=rows.length;
  curritem=0;
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
  currpic=0;
  ImgFilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  piclength=ImgFilesName.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+",'"+PSql.norm(ImgFilesName[currpic])+"')");
    CurrInsertCount=CurrInsertCount+1;
    
    currpic=currpic+1;
    if(currpic==piclength){
     curritem=curritem+1;
     if(curritem!=itemlength){
      Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
      currpic=0;
     }
    }
   }while(curritem!=itemlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXPicture(Item, FileName) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  Updater=new Vector();
  CheckCells=new OTableCellReference[1]; CheckCells[0]=new OTableCellReference(0, 0, 0, 0);
  Updater.addElement(new OTableCellUpdaterSelect(
   new OTableCellUpdaterSelectCheckerNull(true, 31, CheckCells),
   new OTableCellUpdaterByObject(31, ImgFilesName[0]),
   new OTableCellUpdaterByNone(31)));
  PGUI.changeElements(TableItemMdl, rows, Updater);
  
  // onTableSelectedRowChanged(true);
  
  if(IIPic){
   currpic=0;
   insertpos=-1;
   do{
    if(PGUI.findString(ListMdlItemPic, 0, ImgFilesName[currpic])==-1){
     RowData=new Object[1];
     RowData[0]=ImgFilesName[currpic];
     insertpos=PGUI.findInsertPos(ListMdlItemPic, 0, ImgFilesName[currpic], false, true, true);
     ListMdlItemPic.insert(insertpos, RowData);
    }
    currpic=currpic+1;
   }while(currpic!=piclength);
   if(insertpos!=-1){
    List_ItemPicture.setSelectedIndex(insertpos); List_ItemPicture.ensureIndexIsVisible(insertpos); onListPicRowSelected(true);
   }
   IIPicClear=false;
  }
 }//GEN-LAST:event_Btn_MultipleItemsPicAddActionPerformed

 private void Btn_MultipleItemsPicRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsPicRemoveActionPerformed
  int[] rows;
  boolean error, removeintab;
  int MaxListPic, MaxListItem;
  int curritem, curritemlistcount, itemlength,
      currpic, currpiclistcount, piclength;
  int findindex;
  String ItemList, PicList;
  String[] ImgFilesName;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Hapus (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  MaxListPic=1000;
  MaxListItem=1000;
  
  itemlength=rows.length;
  curritem=0;
  ImgFilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  piclength=ImgFilesName.length;
  error=false;
  
  do{
   curritemlistcount=MaxListItem;
   if(curritem+curritemlistcount>itemlength){curritemlistcount=itemlength-curritem;}
   ItemList=PGUI.getElementList(TableItemMdl.Mdl.Rows, PCore.subArr(rows, curritem, curritemlistcount), 0, ",", "", false);
   
   currpic=0;
   do{
    currpiclistcount=MaxListPic;
    if(currpic+currpiclistcount>piclength){currpiclistcount=piclength-currpic;}
    PicList=PText.toStringWithQuote(ImgFilesName, currpic, currpiclistcount, ",", "'", true);
    
    try{
     IFV.Stm.execute("delete ignore from ItemXPicture where Item in ("+ItemList+") and FileName in ("+PicList+")");
    }
    catch(Exception E){error=true;}
    
    currpic=currpic+currpiclistcount;
   }while(currpic!=piclength);
   
   curritem=curritem+curritemlistcount;
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(IIPic){
   removeintab=false;
   currpic=0;
   do{
    findindex=PGUI.findString(ListMdlItemPic, 0, ImgFilesName[currpic]);
    if(findindex>=0){ListMdlItemPic.remove(findindex); removeintab=true;}
    currpic=currpic+1;
   }while(currpic!=piclength);
   if(removeintab){onListPicRowSelected(true);}
  }
 }//GEN-LAST:event_Btn_MultipleItemsPicRemoveActionPerformed

 private void Btn_MultipleItemsSupAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsSupAddActionPerformed
  int[] rows;
  boolean firstinsert, error;
  int curritem, itemlength, currsup, suplength;
  int MaxEachInsert, CurrInsertCount;
  long Id;
  Object[] RowData;
  StringBuilder records;
  int insertpos;
  F_Subject fm=IFV.FSubject;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  
  fm.wMode=1;
  fm.wDialogWithFItem=false;
  fm.wAllowMultipleSelection=true;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  itemlength=rows.length;
  curritem=0;
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
  currsup=0;
  suplength=fm.ChoosedId.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+","+fm.ChoosedId[currsup]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currsup=currsup+1;
    if(currsup==suplength){
     curritem=curritem+1;
     if(curritem!=itemlength){
      Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
      currsup=0;
     }
    }
   }while(curritem!=itemlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXSupplier(Item, Supplier) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  /* "Id", "Nama", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Aktif", "File Gambar", "Kategori" */
  
  if(IISupp){
   currsup=0;
   insertpos=-1;
   do{
    if(PGUI.findLong(TableMdlSupp, 0, fm.ChoosedId[currsup])==-1){
     RowData=PCore.objArrVariant(fm.ChoosedId[currsup], fm.ChoosedName[currsup], 0D, null, null,
      CApp.Default_ItemSupplier_Active, null, null);
     insertpos=PGUI.findInsertPos(TableMdlSupp, 1, fm.ChoosedName[currsup], false, true, true);
     TableMdlSupp.insert(insertpos, RowData);
    }
    currsup=currsup+1;
   }while(currsup!=suplength);
   if(insertpos!=-1){
    Tbl_Supp.changeSelection(insertpos, 0, false, false); onSelectedRowSuppChanged(true);
   }
   IISuppClear=false;
  }
 }//GEN-LAST:event_Btn_MultipleItemsSupAddActionPerformed

 private void Btn_MultipleItemsSupRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsSupRemoveActionPerformed
  int[] rows;
  boolean error, removeintab;
  int MaxListSup, MaxListItem;
  int curritem, curritemlistcount, itemlength,
      currsup, currsuplistcount, suplength;
  int findindex;
  String ItemList, SupList;
  F_Subject fm=IFV.FSubject;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  
  fm.wMode=1;
  fm.wDialogWithFItem=false;
  fm.wAllowMultipleSelection=true;
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  MaxListSup=1000;
  MaxListItem=1000;
  
  itemlength=rows.length;
  curritem=0;
  suplength=fm.ChoosedId.length;
  error=false;
  
  do{
   curritemlistcount=MaxListItem;
   if(curritem+curritemlistcount>itemlength){curritemlistcount=itemlength-curritem;}
   ItemList=PGUI.getElementList(TableItemMdl.Mdl.Rows, PCore.subArr(rows, curritem, curritemlistcount), 0, ",", "", false);
   
   currsup=0;
   do{
    currsuplistcount=MaxListSup;
    if(currsup+currsuplistcount>suplength){currsuplistcount=suplength-currsup;}
    SupList=PText.toString(fm.ChoosedId, currsup, currsuplistcount, ",");
    
    try{
     IFV.Stm.execute("delete ignore from ItemXSupplier where Item in ("+ItemList+") and Supplier in ("+SupList+")");
    }
    catch(Exception E){error=true;}
    
    currsup=currsup+currsuplistcount;
   }while(currsup!=suplength);
   
   curritem=curritem+curritemlistcount;
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(IISupp){
   currsup=0;
   removeintab=false;
   do{
    findindex=PGUI.findLong(TableMdlSupp, 0, fm.ChoosedId[currsup]);
    if(findindex>=0){TableMdlSupp.remove(findindex); removeintab=true;}
    currsup=currsup+1;
   }while(currsup!=suplength);
   if(removeintab){onSelectedRowSuppChanged(true);}
  }
 }//GEN-LAST:event_Btn_MultipleItemsSupRemoveActionPerformed

 private void TF_QNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QNameKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QName, TF_QName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QName)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QNameKeyPressed

 private void TF_QStock1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QStock1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QStock, TF_QStock1, TF_QStock2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QExpList)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QOrderPack1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QStock)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QStock1KeyPressed

 private void TF_QPrice1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QPrice1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QPrice, TF_QPrice1, TF_QPrice2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QExpRange1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QPriceUpdate1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QPrice)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QPrice1KeyPressed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(TableItemMdl, Tbl_Item.getSelectedRows(), 0), true);
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(TableItemMdl, Tbl_Item.getSelectedRows(), 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  File f;
  String fstr;
  
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION){return;}
   
  f=IFV.FileChooser.getSelectedFile();
  if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
   JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
   return;
  }
  try{
   fstr=f.getCanonicalPath();
   if(PFile.compareIgnoreCaseExtension(fstr, "report")==false){
    f=new File(fstr+".report");
   }
  }
  catch(Exception E){
   JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !");
   return;
  }
  if(PEtc.saveIdToFile(TempList.getElements(), f, false,
   IFV.FSplashScreen, true, this, "Menulis Data DaftarKu")==false){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data report ke file !");
  }
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  File f;
  long[] tlist;
  
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showDialog(this, "Load")!=JFileChooser.APPROVE_OPTION){return;}
  f=IFV.FileChooser.getSelectedFile();
  if(PFile.compareIgnoreCaseExtension(f.getName(), "report")==false){
   JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+
    "Ekstensi file harus '.report'.");
   return;
  }
  tlist=PEtc.loadIdFromFile(f, false,
   IFV.FSplashScreen, true, this, "Membaca Data DaftarKu");
  if(tlist==null){
   JOptionPane.showMessageDialog(null, "Gagal membaca data report dari file !");
   return;
  }
  
  clearTempList();
  fillTempList(tlist, true);
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void Lbl_QCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QCommentHelpMouseClicked

 private void TF_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QCommentKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QComment, TF_QComment, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QExpList)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QComment)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QCommentKeyPressed

 private void TF_QIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QIdFocusGained
  LastFocusedCmpSearch=TF_QId;
  PGUI.text_SelectAll(TF_QId);
 }//GEN-LAST:event_TF_QIdFocusGained

 private void TF_QNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QNameFocusGained
  LastFocusedCmpSearch=TF_QName;
  PGUI.text_SelectAll(TF_QName);
 }//GEN-LAST:event_TF_QNameFocusGained

 private void TF_QCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QCommentFocusGained
  LastFocusedCmpSearch=TF_QComment;
  PGUI.text_SelectAll(TF_QComment);
 }//GEN-LAST:event_TF_QCommentFocusGained

 private void TF_QStock1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QStock1FocusGained
  LastFocusedCmpSearch=TF_QStock1;
  PGUI.text_SelectAll(TF_QStock1);
 }//GEN-LAST:event_TF_QStock1FocusGained

 private void TF_QPrice1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QPrice1FocusGained
  LastFocusedCmpSearch=TF_QPrice1;
  PGUI.text_SelectAll(TF_QPrice1);
 }//GEN-LAST:event_TF_QPrice1FocusGained

 private void Lbl_QExpRangeHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QExpRangeHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Parameter2 >= Parameter1.\n"+
   PText.getInputInfo(false, 9, 2, 3, 0, 0, false));
 }//GEN-LAST:event_Lbl_QExpRangeHelpMouseClicked

 private void TF_QStock2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QStock2FocusGained
  LastFocusedCmpSearch=TF_QStock2;
  PGUI.text_SelectAll(TF_QStock2);
 }//GEN-LAST:event_TF_QStock2FocusGained

 private void TF_QPrice2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QPrice2FocusGained
  LastFocusedCmpSearch=TF_QPrice2;
  PGUI.text_SelectAll(TF_QPrice2);
 }//GEN-LAST:event_TF_QPrice2FocusGained

 private void TF_QExpRange1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QExpRange1FocusGained
  LastFocusedCmpSearch=TF_QExpRange1;
  PGUI.text_SelectAll(TF_QExpRange1);
 }//GEN-LAST:event_TF_QExpRange1FocusGained

 private void TF_QExpRange2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QExpRange2FocusGained
  LastFocusedCmpSearch=TF_QExpRange2;
  PGUI.text_SelectAll(TF_QExpRange2);
 }//GEN-LAST:event_TF_QExpRange2FocusGained

 private void TF_QStock2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QStock2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QStock, TF_QStock1, TF_QStock2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QExpList)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QOrderPack2)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QStock2KeyPressed

 private void TF_QPrice2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QPrice2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QPrice, TF_QPrice1, TF_QPrice2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QExpRange2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QPriceUpdate2)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QPrice2KeyPressed

 private void TF_QExpRange1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QExpRange1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QExpRange, TF_QExpRange1, TF_QExpRange2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QOrderPack1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QPrice1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QExpRange)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QExpRange1KeyPressed

 private void TF_QExpRange2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QExpRange2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QExpRange, TF_QExpRange1, TF_QExpRange2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QOrderPack2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QPrice2)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QExpRange2KeyPressed

 private void Btn_MultipleItemsTagAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsTagAddActionPerformed
  int[] rows;
  boolean firstinsert, error;
  int curritem, itemlength, currtag, taglength;
  int MaxEachInsert, CurrInsertCount;
  long Id;
  Object[] RowData;
  StringBuilder records;
  int insertpos;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfItem;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Tag Pada Beberapa Barang";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  MaxEachInsert=1000;
  
  error=false;
  itemlength=rows.length;
  curritem=0;
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
  currtag=0;
  taglength=IFV.FDataIdName.DataId.length;
  
  do{
   records=new StringBuilder();
   firstinsert=true;
   
   CurrInsertCount=0;
   do{
    if(firstinsert){firstinsert=false;}else{records.append(',');}
    records.append("("+Id+","+IFV.FDataIdName.DataId[currtag]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currtag=currtag+1;
    if(currtag==taglength){
     curritem=curritem+1;
     if(curritem!=itemlength){
      Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rows[curritem])[0];
      currtag=0;
     }
    }
   }while(curritem!=itemlength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXTag(Item, TagOfItem) values "+records.toString());}
   catch(Exception E){error=true;}
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  if(IIEtc){
   currtag=0;
   insertpos=-1;
   do{
    if(PGUI.findLong(ListMdlItemTag, 0, IFV.FDataIdName.DataId[currtag])==-1){
     RowData=new Object[2];
     RowData[0]=(int)IFV.FDataIdName.DataId[currtag];
     RowData[1]=IFV.FDataIdName.DataName[currtag];
     insertpos=PGUI.findInsertPos(ListMdlItemTag, 1, IFV.FDataIdName.DataName[currtag], false, true, true);
     ListMdlItemTag.insert(insertpos, RowData);
    }
    currtag=currtag+1;
   }while(currtag!=taglength);
   if(insertpos!=-1){
    List_ItemTag.setSelectedIndex(insertpos); List_ItemTag.ensureIndexIsVisible(insertpos);
   }
   IIEtcClear=false;
  }
 }//GEN-LAST:event_Btn_MultipleItemsTagAddActionPerformed

 private void Btn_MultipleItemsTagRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsTagRemoveActionPerformed
  int[] rows;
  boolean error;
  int MaxListTag, MaxListItem;
  int curritem, curritemlistcount, itemlength,
      currtag, currtaglistcount, taglength;
  int findindex;
  String ItemList, TagList;
  
  rows=Tbl_Item.getSelectedRows();
  if(rows.length==0){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfItem;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menghapus Tag Dari Beberapa Barang";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}

  MaxListTag=1000;
  MaxListItem=1000;
  
  itemlength=rows.length;
  curritem=0;
  taglength=IFV.FDataIdName.DataId.length;
  error=false;
  
  do{
   curritemlistcount=MaxListItem;
   if(curritem+curritemlistcount>itemlength){curritemlistcount=itemlength-curritem;}
   ItemList=PGUI.getElementList(TableItemMdl.Mdl.Rows, PCore.subArr(rows, curritem, curritemlistcount), 0, ",", "", false);
   
   currtag=0;
   do{
    currtaglistcount=MaxListTag;
    if(currtag+currtaglistcount>taglength){currtaglistcount=taglength-currtag;}
    TagList=PText.toString(IFV.FDataIdName.DataId, currtag, currtaglistcount, ",");
    
    try{
     IFV.Stm.execute("delete ignore from ItemXTag where Item in ("+ItemList+") and TagOfItem in ("+TagList+")");
    }
    catch(Exception E){error=true;}
    
    currtag=currtag+currtaglistcount;
   }while(currtag!=taglength);
   
   curritem=curritem+curritemlistcount;
  }while(curritem!=itemlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi");
   return;
  }
  
  if(IIEtc){
   currtag=0;
   do{
    findindex=PGUI.findLong(ListMdlItemTag, 0, IFV.FDataIdName.DataId[currtag]);
    if(findindex>=0){ListMdlItemTag.remove(findindex);}
    currtag=currtag+1;
   }while(currtag!=taglength);
  }
 }//GEN-LAST:event_Btn_MultipleItemsTagRemoveActionPerformed

 private void Btn_ItemTagAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemTagAddActionPerformed
  boolean firstinsert, error;
  int row;
  int MaxEachInsert, CurrInsertCount;
  int currtag, taglength;
  long Id;
  Object[] RowData;
  StringBuilder Values;
  int insertpos;
  
  row=Tbl_Item.getSelectedRow();
  if(row==-1){return;}
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfItem;
  IFV.FDataIdName.wUseCustomTitle=true;
  IFV.FDataIdName.wCustomTitle="Menambah Tag Pada Sebuah Barang";
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(row)[0];
  MaxEachInsert=1000;
  taglength=IFV.FDataIdName.DataId.length;
  currtag=0;
  error=false;
  do{
   Values=new StringBuilder();
   
   CurrInsertCount=0;
   firstinsert=true;
   do{
    if(firstinsert){firstinsert=false;}else{Values.append(',');}
    Values.append("("+Id+","+IFV.FDataIdName.DataId[currtag]+")");
    CurrInsertCount=CurrInsertCount+1;
    
    currtag=currtag+1;
   }while(currtag!=taglength && CurrInsertCount!=MaxEachInsert);
   
   try{IFV.Stm.execute("insert ignore into ItemXTag(Item, TagOfItem) values "+Values.toString());}
   catch(Exception E){error=true;}
  }while(currtag!=taglength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  currtag=0;
  insertpos=-1;
  do{
   if(PGUI.findLong(ListMdlItemTag, 0, IFV.FDataIdName.DataId[currtag])==-1){
    RowData=new Object[2];
    RowData[0]=(int)IFV.FDataIdName.DataId[currtag];
    RowData[1]=IFV.FDataIdName.DataName[currtag];
    insertpos=PGUI.findInsertPos(ListMdlItemTag, 1, IFV.FDataIdName.DataName[currtag], false, true, true);
    ListMdlItemTag.insert(insertpos, RowData);
   }
   currtag=currtag+1;
  }while(currtag!=taglength);
  if(insertpos!=-1){
   List_ItemTag.setSelectedIndex(insertpos); List_ItemTag.ensureIndexIsVisible(insertpos);
  }
  IIEtc=true; IIEtcClear=false; IIEmptyAll=false;
 }//GEN-LAST:event_Btn_ItemTagAddActionPerformed

 private void Btn_ItemTagRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemTagRemoveActionPerformed
  int[] rows=List_ItemTag.getSelectedIndices();
  int rowItem=Tbl_Item.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currtag, currtaglistcount, taglength;
  String TagList;
  
  if(rows.length==0 || rowItem==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" tag yg dipilih dari daftar tag barang ?",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rowItem)[0];
  MaxList=1000;
  error=false;
  taglength=rows.length;
  currtag=0;
  do{
   currtaglistcount=MaxList;
   if(currtag+currtaglistcount>taglength){currtaglistcount=taglength-currtag;}
   TagList=PGUI.getElementList(ListMdlItemTag.Mdl.Rows, PCore.subArr(rows, currtag, currtaglistcount), 0, ",", "", false);
   
   try{IFV.Stm.execute("delete ignore from ItemXTag where Item="+Id+" and TagOfItem in("+TagList+")");}
   catch(Exception E){error=true;}
   
   currtag=currtag+currtaglistcount;
  }while(currtag!=taglength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlItemTag.remove(rows);
 }//GEN-LAST:event_Btn_ItemTagRemoveActionPerformed

 private void Btn_QTagAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QTagAddActionPerformed
  int temp, temp_;
  Object[] row;
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTagOfItem;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    row=new Object[2];
    row[0]=(int)IFV.FDataIdName.DataId[temp_];
    row[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQTag.append(row);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QTagAddActionPerformed

 private void Btn_QTagRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QTagRemoveActionPerformed
  ListMdlQTag.remove(List_QTag.getSelectedIndices());
 }//GEN-LAST:event_Btn_QTagRemoveActionPerformed

 private void CmB_CatQueryTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_CatQueryTypeActionPerformed
  fillListModelCategory(2);
 }//GEN-LAST:event_CmB_CatQueryTypeActionPerformed

 private void Btn_CatRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatRefreshActionPerformed
  fillListModelCategory(0);
 }//GEN-LAST:event_Btn_CatRefreshActionPerformed

 private void CmB_ResultFilterActiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterActiveActionPerformed
  int temp=CmB_ResultFilterActive.getSelectedIndex();
  if(LastResultFilterIsActive==temp){return;}
  LastResultFilterIsActive=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterActiveActionPerformed

 private void CmB_ResultFilterUpdateStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterUpdateStockActionPerformed
  int temp=CmB_ResultFilterUpdateStock.getSelectedIndex();
  if(LastResultFilterIsUpdateStock==temp){return;}
  LastResultFilterIsUpdateStock=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterUpdateStockActionPerformed

 private void CmB_ResultFilterExpireActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterExpireActionPerformed
  int temp=CmB_ResultFilterExpire.getSelectedIndex();
  if(LastResultFilterHasExpire==temp){return;}
  LastResultFilterHasExpire=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterExpireActionPerformed

 private void TF_TempListQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TempListQuantityMouseClicked
  int DynamicTempList=0;
  
  do{
   if(SwingUtilities.isLeftMouseButton(evt)){DynamicTempList=1; break;}
   if(SwingUtilities.isRightMouseButton(evt)){DynamicTempList=2; break;}
   DynamicTempList=-1;
  }while(false);
  if(DynamicTempList==-1){return;}
  
  setLastQuery(3, 0, "", "", false, "", false, DynamicTempList, false);
  fillTable();
 }//GEN-LAST:event_TF_TempListQuantityMouseClicked

 private void Btn_QPicAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QPicAddActionPerformed
  int temp;
  String[] FilesName;
  
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(true);
  if(IFV.FileChooser.showDialog(null, "Tambah (blh jamak)")!=JFileChooser.APPROVE_OPTION){return;}
  
  FilesName=PFile.getFilesName(IFV.FileChooser.getSelectedFiles());
  temp=0;
  do{
   ListMdlQPic.append(PCore.objArrVariant(FilesName[temp]));
   temp=temp+1;
  }while(temp!=FilesName.length);
 }//GEN-LAST:event_Btn_QPicAddActionPerformed

 private void Btn_QPicRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QPicRemoveActionPerformed
  ListMdlQPic.remove(List_QPic.getSelectedIndices());
 }//GEN-LAST:event_Btn_QPicRemoveActionPerformed

 private void Btn_QSupAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSupAddActionPerformed
  Object[] NewRow;
  int count, temp;
  
  
  IFV.FSubject.wMode=1;
  IFV.FSubject.wDialogWithFItem=false;
  IFV.FSubject.wAllowMultipleSelection=true;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   count=IFV.FSubject.ChoosedId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=IFV.FSubject.ChoosedId[temp];
    NewRow[1]=IFV.FSubject.ChoosedName[temp];
    ListMdlQSup.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QSupAddActionPerformed

 private void Btn_QSupRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSupRemoveActionPerformed
  ListMdlQSup.remove(List_QSup.getSelectedIndices());
 }//GEN-LAST:event_Btn_QSupRemoveActionPerformed

 private void CmB_ResultFilterSubsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterSubsetActionPerformed
  int temp=CmB_ResultFilterSubset.getSelectedIndex();
  if(LastResultFilterSubset==temp){return;}
  LastResultFilterSubset=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterSubsetActionPerformed

 private void Btn_QueryRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryRefreshActionPerformed
  fillTable();
 }//GEN-LAST:event_Btn_QueryRefreshActionPerformed

 private void Btn_CheckerExecuteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CheckerExecuteActionPerformed
  if(!PGUI.isEnabled(Btn_CheckerExecute)){return;}
  checkerExecute();
 }//GEN-LAST:event_Btn_CheckerExecuteActionPerformed

 private void TF_CheckerItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CheckerItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_CheckerItemId, TF_CheckerId_ShortcutKeys);
		TF_CheckerItemId.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_CheckerItemId);
 }//GEN-LAST:event_TF_CheckerItemIdFocusGained

 private void TF_CheckerItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CheckerItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
		TF_CheckerItemId.setBackground(CGUI.Color_TextBox_FocusOff);
  updateCheckerInput(false, -1);
 }//GEN-LAST:event_TF_CheckerItemIdFocusLost

 private void TF_CheckerItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CheckerItemIdKeyPressed
  boolean Pass=false;
  boolean FocusChanged;
  switch(evt.getKeyCode()){
			case KeyEvent.VK_SPACE : evt.consume(); Tbl_Item.requestFocusInWindow(); break;
   // key "enter, right, down" has the same action
   case KeyEvent.VK_RIGHT :
    if(!Pass){
     Pass=true;
     if(TF_CheckerItemId.getCaretPosition()!=TF_CheckerItemId.getDocument().getLength()){break;}
    }
   case KeyEvent.VK_DOWN : if(!Pass){Pass=true;}
   case KeyEvent.VK_ENTER :
    FocusChanged=false;
    if(!((evt.getKeyCode()==KeyEvent.VK_ENTER) && evt.isShiftDown())){
     FocusChanged=changeFocusToCheckerAttributesInput();
    }
    if((evt.getKeyCode()==KeyEvent.VK_ENTER) && !FocusChanged){updateCheckerInput(false, -1);}
    break;
   case KeyEvent.VK_F12 :
    updateCheckerInput(false, -1);
    break;
  }
 }//GEN-LAST:event_TF_CheckerItemIdKeyPressed

 private void TF_CheckerAttr1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CheckerAttr1FocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_CheckerAttr1, TF_Checker1_ShortcutKeys);
		TF_CheckerAttr1.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_CheckerAttr1);
 }//GEN-LAST:event_TF_CheckerAttr1FocusGained

 private void TF_CheckerAttr1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CheckerAttr1FocusLost
  IFV.KeyboardManager.disableComponentShortcut();
		TF_CheckerAttr1.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_CheckerAttr1FocusLost

 private void TF_CheckerAttr1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CheckerAttr1KeyPressed
  boolean Pass=false;
  switch(evt.getKeyCode()){
			case KeyEvent.VK_SPACE : evt.consume(); Tbl_Item.requestFocusInWindow(); break;
   // key "enter, right, down" has the same action
   case KeyEvent.VK_RIGHT :
    if(!Pass){
     Pass=true;
     if(TF_CheckerAttr1.getCaretPosition()!=TF_CheckerAttr1.getDocument().getLength()){break;}
    }
   case KeyEvent.VK_DOWN : if(!Pass){Pass=true;}
   case KeyEvent.VK_ENTER :
    if(!((evt.getKeyCode()==KeyEvent.VK_ENTER) && evt.isShiftDown())){
     do{
      if(TF_CheckerAttr2.isEnabled() && CB_CheckerAttr2.isSelected()){TF_CheckerAttr2.requestFocusInWindow(); break;}
     }while(false);
     break;
    }
    Pass=true;
   case KeyEvent.VK_LEFT :
    if(!Pass){
     Pass=true;
     if(TF_CheckerAttr1.getCaretPosition()!=0){break;}
    }
   case KeyEvent.VK_UP :
    do{
     if(TF_CheckerItemId.isEnabled()){TF_CheckerItemId.requestFocusInWindow(); break;}
    }while(false);
    break;
  }
 }//GEN-LAST:event_TF_CheckerAttr1KeyPressed

 private void TF_CheckerAttr2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CheckerAttr2FocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_CheckerAttr2, TF_Checker2_ShortcutKeys);
		TF_CheckerAttr2.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_CheckerAttr2);
 }//GEN-LAST:event_TF_CheckerAttr2FocusGained

 private void TF_CheckerAttr2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CheckerAttr2FocusLost
  IFV.KeyboardManager.disableComponentShortcut();
		TF_CheckerAttr2.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_CheckerAttr2FocusLost

 private void TF_CheckerAttr2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CheckerAttr2KeyPressed
  boolean Pass=false;
  switch(evt.getKeyCode()){
			case KeyEvent.VK_SPACE : evt.consume(); Tbl_Item.requestFocusInWindow(); break;
   // key "enter, right, down" has the same action
   case KeyEvent.VK_LEFT :
    if(!Pass){
     Pass=true;
     if(TF_CheckerAttr2.getCaretPosition()!=0){break;}
    }
   case KeyEvent.VK_UP : if(!Pass){Pass=true;}
   case KeyEvent.VK_ENTER :
    if(!((evt.getKeyCode()==KeyEvent.VK_ENTER) && !evt.isShiftDown())){
     do{
      if(!TF_CheckerAttr1.isEnabled() && !TF_CheckerItemId.isEnabled()){break;}
      if(TF_CheckerAttr1.isEnabled() && CB_CheckerAttr1.isSelected()){TF_CheckerAttr1.requestFocusInWindow(); break;}
      if(TF_CheckerItemId.isEnabled()){TF_CheckerItemId.requestFocusInWindow(); break;}
     }while(false);
    }
    break;
  }
 }//GEN-LAST:event_TF_CheckerAttr2KeyPressed

 private void CmB_CheckerIdInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_CheckerIdInputActionPerformed
  TF_CheckerItemId.setEnabled(CmB_CheckerIdInput.getSelectedIndex()==0);
 }//GEN-LAST:event_CmB_CheckerIdInputActionPerformed

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 private void TF_FindFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusLost
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FindFocusLost

 private void CmB_CheckerAttr1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_CheckerAttr1ActionPerformed
  onCheckerAttrInputOptChanged(false, CurrCheckerAttr1, CmB_CheckerAttr1, TF_CheckerAttr1);
 }//GEN-LAST:event_CmB_CheckerAttr1ActionPerformed

 private void CmB_CheckerAttr2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_CheckerAttr2ActionPerformed
  onCheckerAttrInputOptChanged(false, CurrCheckerAttr2, CmB_CheckerAttr2, TF_CheckerAttr2);
 }//GEN-LAST:event_CmB_CheckerAttr2ActionPerformed

 private void CmB_ViewModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ViewModeActionPerformed
  onSelectedViewModeChanged(false);
 }//GEN-LAST:event_CmB_ViewModeActionPerformed

 private void CmB_DetBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_DetBuyActionPerformed
  fillDetBuy();
 }//GEN-LAST:event_CmB_DetBuyActionPerformed

 private void CmB_DetSellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_DetSellActionPerformed
  fillDetSell();
 }//GEN-LAST:event_CmB_DetSellActionPerformed

 private void CB_DetSellActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_DetSellActionPerformed
  fillDetSell();
 }//GEN-LAST:event_CB_DetSellActionPerformed

 private void CB_DetBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_DetBuyActionPerformed
  fillDetBuy();
 }//GEN-LAST:event_CB_DetBuyActionPerformed

 private void Btn_TempListAddByCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddByCategoryActionPerformed
  int[] Rows=List_Category.getSelectedIndices();
  
  if(Rows.length==0){return;}
  
  fillTempListByCategory(PGUI.getIdsFromSelectedRows(ListMdlCat, Rows, 0), true);
 }//GEN-LAST:event_Btn_TempListAddByCategoryActionPerformed

 private void Btn_TempListRemoveByCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveByCategoryActionPerformed
  int[] Rows=List_Category.getSelectedIndices();
  
  if(Rows.length==0){return;}
  
  fillTempListByCategory(PGUI.getIdsFromSelectedRows(ListMdlCat, Rows, 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveByCategoryActionPerformed

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  if(JOptionPane.showConfirmDialog(null, "Kosongkan data pada 'Daftarku' ?", "Konfirmasi Pengosongan Data Pada 'Daftarku'",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  clearTempList();
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Lbl_QPriceUpdateHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QPriceUpdateHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Inputan harus diisi.\n"+
   "- Isi inputan dgn rentang tanggal tertentu ( Tanggal A ... Tanggal B ).\n"+
   "- Tanggal B >= Tanggal A.\n"+
   "- Masing-masing inputan Tanggal diisi dgn format Tahun-Bulan-Hari, contohnya 2018-12-31.");
 }//GEN-LAST:event_Lbl_QPriceUpdateHelpMouseClicked

 private void Btn_SuppTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppTempListAddActionPerformed
  int[] rows=Tbl_Supp.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlSupp.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_SuppTempListAddActionPerformed

 private void Btn_SuppTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppTempListRemoveActionPerformed
  int[] rows=Tbl_Supp.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlSupp.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_SuppTempListRemoveActionPerformed

 private void TF_QPriceUpdate1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QPriceUpdate1FocusGained
  LastFocusedCmpSearch=TF_QPriceUpdate1;
  PGUI.text_SelectAll(TF_QPriceUpdate1);
 }//GEN-LAST:event_TF_QPriceUpdate1FocusGained

 private void TF_QPriceUpdate2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QPriceUpdate2FocusGained
  LastFocusedCmpSearch=TF_QPriceUpdate2;
  PGUI.text_SelectAll(TF_QPriceUpdate2);
 }//GEN-LAST:event_TF_QPriceUpdate2FocusGained

 private void TF_QPriceUpdate1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QPriceUpdate1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QPriceUpdate, TF_QPriceUpdate1, TF_QPriceUpdate2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QPrice1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QOrder1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QPriceUpdate)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QPriceUpdate1KeyPressed

 private void TF_QPriceUpdate2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QPriceUpdate2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QPriceUpdate, TF_QPriceUpdate1, TF_QPriceUpdate2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QPrice2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QOrder2)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QPriceUpdate2KeyPressed

 private void Btn_QStockUnitAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QStockUnitAddActionPerformed
  int temp, temp_;
  Object[] row;
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblStockUnit;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   temp=IFV.FDataIdName.DataId.length;
   temp_=0;
   do{
    row=new Object[2];
    row[0]=(int)IFV.FDataIdName.DataId[temp_];
    row[1]=IFV.FDataIdName.DataName[temp_];
    ListMdlQStockUnit.append(row);
    temp_=temp_+1;
   }while(temp_!=temp);
  }
 }//GEN-LAST:event_Btn_QStockUnitAddActionPerformed

 private void Btn_QStockUnitRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QStockUnitRemoveActionPerformed
  ListMdlQStockUnit.remove(List_QStockUnit.getSelectedIndices());
 }//GEN-LAST:event_Btn_QStockUnitRemoveActionPerformed

 private void TF_QOrderPack1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QOrderPack1FocusGained
  LastFocusedCmpSearch=TF_QOrderPack1;
  PGUI.text_SelectAll(TF_QOrderPack1);
 }//GEN-LAST:event_TF_QOrderPack1FocusGained

 private void TF_QOrderPack1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QOrderPack1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QOrderPack, TF_QOrderPack1, TF_QOrderPack2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QStock1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QExpRange1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QOrderPack)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QOrderPack1KeyPressed

 private void TF_QOrderPack2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QOrderPack2FocusGained
  LastFocusedCmpSearch=TF_QOrderPack2;
  PGUI.text_SelectAll(TF_QOrderPack2);
 }//GEN-LAST:event_TF_QOrderPack2FocusGained

 private void TF_QOrderPack2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QOrderPack2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QOrderPack, TF_QOrderPack1, TF_QOrderPack2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QStock2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QExpRange2)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QOrderPack2KeyPressed

 private void TF_QOrder1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QOrder1FocusGained
  LastFocusedCmpSearch=TF_QOrder1;
  PGUI.text_SelectAll(TF_QOrder1);
 }//GEN-LAST:event_TF_QOrder1FocusGained

 private void TF_QOrder1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QOrder1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QOrder, TF_QOrder1, TF_QOrder2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QPriceUpdate1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QStockUnitAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QOrder)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QOrder1KeyPressed

 private void TF_QOrder2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QOrder2FocusGained
  LastFocusedCmpSearch=TF_QOrder2;
  PGUI.text_SelectAll(TF_QOrder2);
 }//GEN-LAST:event_TF_QOrder2FocusGained

 private void TF_QOrder2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QOrder2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QOrder, TF_QOrder1, TF_QOrder2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QPriceUpdate2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QStockUnitAdd)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QOrder2KeyPressed

 private void Lbl_QOrderPackHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QOrderPackHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter2 >= Parameter1.\n"+PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_QOrderPackHelpMouseClicked

 private void Lbl_QOrderHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QOrderHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter2 >= Parameter1.\n"+PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_QOrderHelpMouseClicked

 private void Btn_SecAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SecAddActionPerformed
  boolean error;
  int row=Tbl_Item.getSelectedRow();
  int result;
  long Id;
  long SecondaryId;
  
  if(row==-1){return;}
  
  IFV.FInputName.wTitle="Menambah Secondary-Id Pada Sebuah Barang";
  IFV.FInputName.wText="Input Secondary-Id :";
  IFV.FInputName.wInput="";
  IFV.FInputName.wCheckEmpty=false;
  IFV.FInputName.wCheckLength=18;
  IFV.FInputName.wCheckAll=2;
  IFV.FInputName.wCheckFirst=0;
  IFV.FInputName.wCheckLast=0;
  IFV.FInputName.wCheckOther=0;
  
  if(IFV.FInputName.showForm()==false){return;}
  if(IFV.FInputName.DialogResult!=1){return;}
  
  SecondaryId=Long.parseLong(IFV.FInputName.Input);
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(row)[0];
  
  error=true;
  do{
   try{
    result=PMyShop.checkExistIdOnItem(SecondaryId, IFV.Stm);
    if(result==-1){break;}
    if(result==1){JOptionPane.showMessageDialog(null, "Tidak dapat menambah : Id / Secondary-Id sudah ada !"); return;}
    
    try{IFV.Stm.executeUpdate("insert into ItemXSecondaryId(Item, SecondaryId) values ("+Id+","+SecondaryId+");");}
    catch(Exception E){break;}
   }
   catch(Exception E){break;}
   error=false;
  }while(false);
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlSec.append(PCore.objArrVariant((long)SecondaryId, formatSecondaryId(SecondaryId)));
  IIVrs=true; IIVrsClear=false; IIEmptyAll=false; IISecClear=false;
 }//GEN-LAST:event_Btn_SecAddActionPerformed

 private void Btn_SecEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SecEditActionPerformed
  boolean error;
  int row_item=Tbl_Item.getSelectedRow();
  int[] rows=List_Sec.getSelectedIndices();
  int result;
  long Id;
  long SecondaryId;
  long EditedSecondaryId;
  
  if(row_item==-1 || rows.length==0){return;}
  
  if(rows.length>1){
   JOptionPane.showMessageDialog(null, "Pilihan jamak tidak diperbolehkan utk melakukan operasi ini !");
   return;
  }
  
  SecondaryId=(Long)ListMdlSec.Mdl.Rows.elementAt(rows[0])[0];
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(row_item)[0];
  
  IFV.FEditName.wTitle="Mengubah Secondary-Id Pada Sebuah Barang";
  IFV.FEditName.wCurrValue=String.valueOf(SecondaryId);
  IFV.FEditName.wCheckEmpty=false;
  IFV.FEditName.wCheckLength=18;
  IFV.FEditName.wCheckAll=2;
  IFV.FEditName.wCheckFirst=0;
  IFV.FEditName.wCheckLast=0;
  IFV.FEditName.wCheckOther=0;
  
  if(IFV.FEditName.showForm()==false){return;}
  if(IFV.FEditName.DialogResult!=1){return;}
  
  EditedSecondaryId=Long.parseLong(IFV.FEditName.UpdateValue);
  
  if(EditedSecondaryId==SecondaryId){return;}
  
  error=true;
  do{
   try{
    result=PMyShop.checkExistIdOnItem(EditedSecondaryId, IFV.Stm);
    if(result==-1){break;}
    if(result==1){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : Id / Secondary-Id sudah ada !"); return;}
    
    try{IFV.Stm.executeUpdate("update ItemXSecondaryId set SecondaryId="+EditedSecondaryId+" where Item="+Id+" and SecondaryId="+SecondaryId+";");}
    catch(Exception E){break;}
   }
   catch(Exception E){break;}
   error=false;
  }while(false);
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlSec.changeValue(rows[0], PCore.objArrVariant((long)EditedSecondaryId, formatSecondaryId(EditedSecondaryId)));
 }//GEN-LAST:event_Btn_SecEditActionPerformed

 private void Btn_SecRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SecRemoveActionPerformed
  int[] rows=List_Sec.getSelectedIndices();
  int rowItem=Tbl_Item.getSelectedRow();
  long Id;
  boolean error;
  int MaxList;
  int currsecid, currsecidlistcount, secidlength;
  String SecIdList;
  
  if(rows.length==0 || rowItem==-1){return;}
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" Secondary-Id yg dipilih dari daftar ?",
   "Konfirmasi Penghapusan", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  Id=(Long)TableItemMdl.Mdl.Rows.elementAt(rowItem)[0];
  MaxList=1000;
  error=false;
  secidlength=rows.length;
  currsecid=0;
  do{
   currsecidlistcount=MaxList;
   if(currsecid+currsecidlistcount>secidlength){currsecidlistcount=secidlength-currsecid;}
   SecIdList=PGUI.getElementList(ListMdlSec.Mdl.Rows, PCore.subArr(rows, currsecid, currsecidlistcount), 0, ",", "", false);
   
   try{IFV.Stm.execute("delete ignore from ItemXSecondaryId where Item="+Id+" and SecondaryId in("+SecIdList+")");}
   catch(Exception E){error=true;}
   
   currsecid=currsecid+currsecidlistcount;
  }while(currsecid!=secidlength);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlSec.remove(rows);
 }//GEN-LAST:event_Btn_SecRemoveActionPerformed

 private void Btn_CatAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatAddActionPerformed
  int temp, insertrow;
  Object[] UpdateData;
  String Name;
  
  IFV.FInputName.wTitle="Tambah Kategori Barang";
  IFV.FInputName.wText="Nama Kategori Barang yg baru :";
  IFV.FInputName.wInput="";
  IFV.FInputName.wCheckEmpty=false;
  IFV.FInputName.wCheckLength=150;
  IFV.FInputName.wCheckAll=0;
  IFV.FInputName.wCheckFirst=1;
  IFV.FInputName.wCheckLast=1;
  IFV.FInputName.wCheckOther=0;
  
  if(IFV.FInputName.showForm()==false){return;}
  if(IFV.FInputName.DialogResult!=1){return;}
  
  Name=IFV.FInputName.Input;
  temp=PDatabase.addARecordIdName(IFV.Stm, "CategoryOfItem", Name, true, IFV.Params);
  if(temp!=0){
   if(temp==1){JOptionPane.showMessageDialog(null, "Gagal menambah : Kategori Barang sudah ada !");}
   else if(temp==-1){JOptionPane.showMessageDialog(null, "Gagal menambah : terjadi kesalahan ketika melakukan operasi !");}
   return;
  }

  if(!CatQueryWithCheck && CatQueryWithoutCheckByTempList){return;}
  
  UpdateData=new Object[2];
  UpdateData[0]=IFV.Params.Param[0];
  UpdateData[1]=Name;
  insertrow=PGUI.findInsertPos(ListMdlCat, 1, Name, false, true, true);
  ListMdlCat.insert(insertrow, UpdateData);
  LastSelectedRowCat=-1;
  updateCategoryCount();
  
  // optional operation, just to update another related data with this operation
  
 }//GEN-LAST:event_Btn_CatAddActionPerformed

 private void Btn_CatEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatEditActionPerformed
  categoryEdit();
 }//GEN-LAST:event_Btn_CatEditActionPerformed

 private void Btn_CatRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CatRemoveActionPerformed
  int[] rows=List_Category.getSelectedIndices();
  long[] ids;
  int curr_offset, curr_operationcount, length, maxeach;
  boolean error;
  
  length=rows.length;
  if(length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+length+" data Kategori Barang yg dipilih ?"+
   "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
   "Konfirmasi Penghapusan Data Kategori Barang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  ids=ListMdlCat.getIds(0, rows);
  
  curr_offset=0; maxeach=1000; error=false;
  do{
   curr_operationcount=maxeach; if(curr_offset+curr_operationcount>length){curr_operationcount=length-curr_offset;}
   
   try{IFV.Stm.executeUpdate("delete ignore from CategoryOfItem where Id in ("+PText.toString(ids, curr_offset, curr_operationcount, ",")+")");}
   catch(Exception E){error=true;}
   
   curr_offset=curr_offset+curr_operationcount;
  }while(curr_offset!=length);
  
  if(error){
   JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");
   return;
  }
  
  ListMdlCat.remove(rows); updateCategoryCount(); updateCategoryCheckedCount();
  LastSelectedRowCat=-1;
  
  // optional operation, just to update another related data with this operation
  if(TabbedPane.getSelectedIndex()==3 || IIEtc){
   ListMdlItemCat.remove(PGUI.inspectLong(ids, ListMdlItemCat, 0, true, true));
  }
 }//GEN-LAST:event_Btn_CatRemoveActionPerformed

 private void Btn_CheckerP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CheckerP1ActionPerformed
  int ViewMode=CmB_ViewMode.getSelectedIndex();
  
  if(!PGUI.isEnabled(Btn_CheckerP1)){return;}
  
  switch(ViewMode){
   case 1 : checkerOpnameStart(); break;
   case 2 : checkerOrderStart(); break;
  }
 }//GEN-LAST:event_Btn_CheckerP1ActionPerformed

 private void Btn_CheckerP2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CheckerP2ActionPerformed
  int ViewMode=CmB_ViewMode.getSelectedIndex();
  
  if(!PGUI.isEnabled(Btn_CheckerP2)){return;}
  
  switch(ViewMode){
   case 1 : checkerOpnameDone(); break;
   case 2 : checkerOrderDone(); break;
  }
 }//GEN-LAST:event_Btn_CheckerP2ActionPerformed

 private void TF_SuppFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SuppFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_SuppFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Supp)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SuppFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_SuppFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_SuppFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_SuppFindKeyPressed

 private void Btn_SuppFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppFindNextActionPerformed
  findSupp(1);
 }//GEN-LAST:event_Btn_SuppFindNextActionPerformed

 private void Btn_SuppFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppFindBefActionPerformed
  findSupp(2);
 }//GEN-LAST:event_Btn_SuppFindBefActionPerformed

 private void Tbl_ItemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemKeyReleased
  onTableSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Item, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_LEFT:
    if(Tbl_Item.OnKeyPress_PosCol<=0){
     switch(TabbedPane.getSelectedIndex()){
      case 0 : focusQuery(); break;
      case 1 :
       if(ListMdlCat.getSize()!=0){
        if(List_Category.getSelectedIndex()==-1){List_Category.setSelectedIndex(0); List_Category.ensureIndexIsVisible(0);}
        onListCategoryRowSelected(false);
        List_Category.requestFocusInWindow();
       }
       break;
     }
    }
    break;
  }
 }//GEN-LAST:event_Tbl_ItemKeyReleased

 private void Tbl_ItemMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemMouseReleased
  onTableSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_ItemMouseReleased

 private void Tbl_ItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemKeyPressed
  switch(evt.getKeyCode()){
			case KeyEvent.VK_SPACE : evt.consume(); changeFocusToCheckerAttributesInput(); break;
   case KeyEvent.VK_ENTER:
    if(wMode==1 && !Tbl_Item.isEditing()){
     if(Tbl_Item.getSelectedRows().length!=0){evt.consume(); Btn_ChooseActionPerformed(null);}
    }
    break;
  }
 }//GEN-LAST:event_Tbl_ItemKeyPressed

 private void Lbl_QExpListHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QExpListHelpMouseClicked
  JOptionPane.showMessageDialog(null, "Format input : angka, angka, angka, dst ..."+
   "\nContohnya : 0, 1, 3, 7, 15, 30, 60");
 }//GEN-LAST:event_Lbl_QExpListHelpMouseClicked

 private void TF_QExpListFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QExpListFocusGained
  LastFocusedCmpSearch=TF_QExpList;
  PGUI.text_SelectAll(TF_QExpList);
 }//GEN-LAST:event_TF_QExpListFocusGained

 private void TF_QExpListKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QExpListKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QExpList, TF_QExpList, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QStock1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QExpList)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QExpListKeyPressed

 private void Tbl_SuppKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_SuppKeyReleased
  onSelectedRowSuppChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Supp, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SuppFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_SuppKeyReleased

 private void Tbl_SuppMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_SuppMouseReleased
  onSelectedRowSuppChanged(false);
 }//GEN-LAST:event_Tbl_SuppMouseReleased

 private void RB_TransIsPreTransNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_TransIsPreTransNActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_RB_TransIsPreTransNActionPerformed

 private void RB_TransIsPreTransYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_TransIsPreTransYActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_RB_TransIsPreTransYActionPerformed

 private void CmB_TransTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_TransTypeActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_CmB_TransTypeActionPerformed

 private void Btn_TransOutFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutFindBefActionPerformed
  findTransOut(2);
 }//GEN-LAST:event_Btn_TransOutFindBefActionPerformed

 private void Btn_TransOutFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutFindNextActionPerformed
  findTransOut(1);
 }//GEN-LAST:event_Btn_TransOutFindNextActionPerformed

 private void Btn_TransInFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInFindBefActionPerformed
  findTransIn(2);
 }//GEN-LAST:event_Btn_TransInFindBefActionPerformed

 private void Btn_TransInFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInFindNextActionPerformed
  findTransIn(1);
 }//GEN-LAST:event_Btn_TransInFindNextActionPerformed

 private void CmB_TransSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_TransSubjectActionPerformed
  if(IFV.PreventAutoFire.isPrevent()){IFV.PreventAutoFire.preventConfirmed(); return;}
  onQueryTransComponentsChanged();
 }//GEN-LAST:event_CmB_TransSubjectActionPerformed

 private void Btn_TransInSubjectTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSubjectTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(2, rows), true);
 }//GEN-LAST:event_Btn_TransInSubjectTempListAddActionPerformed

 private void Btn_TransInSubjectTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSubjectTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(2, rows), false);
 }//GEN-LAST:event_Btn_TransInSubjectTempListRemoveActionPerformed

 private void Btn_TransInSalesmanTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSalesmanTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(4, rows), true);
 }//GEN-LAST:event_Btn_TransInSalesmanTempListAddActionPerformed

 private void Btn_TransInSalesmanTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSalesmanTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransIn.getIds(4, rows), false);
 }//GEN-LAST:event_Btn_TransInSalesmanTempListRemoveActionPerformed

 private void Btn_TransOutSubjectTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSubjectTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(2, rows), true);
 }//GEN-LAST:event_Btn_TransOutSubjectTempListAddActionPerformed

 private void Btn_TransOutSubjectTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSubjectTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(2, rows), false);
 }//GEN-LAST:event_Btn_TransOutSubjectTempListRemoveActionPerformed

 private void Btn_TransOutSalesmanTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSalesmanTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(4, rows), true);
 }//GEN-LAST:event_Btn_TransOutSalesmanTempListAddActionPerformed

 private void Btn_TransOutSalesmanTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSalesmanTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTransOut.getIds(4, rows), false);
 }//GEN-LAST:event_Btn_TransOutSalesmanTempListRemoveActionPerformed

 private void Tbl_TransInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransInKeyReleased
  onTableTransInSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_TransIn, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransInFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_TransInKeyReleased

 private void Tbl_TransInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_TransInMouseReleased
  onTableTransInSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_TransInMouseReleased

 private void Tbl_TransOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_TransOutMouseReleased
  onTableTransOutSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_TransOutMouseReleased

 private void Tbl_TransOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransOutKeyReleased
  onTableTransOutSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_TransOut, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransOutFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_TransOutKeyReleased

 private void TF_TransInFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransInFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_TransInFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_TransIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_TransInFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransInFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_TransInFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_TransInFindKeyPressed

 private void TF_TransOutFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransOutFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_TransOutFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_TransOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_TransOutFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransOutFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_TransOutFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_TransOutFindKeyPressed

 private void Btn_MultipleItemsActiveAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsActiveAddActionPerformed
  setItemActive(true);
 }//GEN-LAST:event_Btn_MultipleItemsActiveAddActionPerformed

 private void Btn_MultipleItemsActiveRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsActiveRemoveActionPerformed
  setItemActive(false);
 }//GEN-LAST:event_Btn_MultipleItemsActiveRemoveActionPerformed

 private void Btn_SuppActiveAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppActiveAddActionPerformed
  setItemSuppActive(true);
 }//GEN-LAST:event_Btn_SuppActiveAddActionPerformed

 private void Btn_SuppActiveRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppActiveRemoveActionPerformed
  setItemSuppActive(false);
 }//GEN-LAST:event_Btn_SuppActiveRemoveActionPerformed

 private void Pnl_CheckerItemPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_CheckerItemPreviewMouseClicked
  if(CheckerItemId==-1){return;}
  
  PMyShop.viewFormInfo(CheckerItemId, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_CheckerItemPreviewMouseClicked

 private void Btn_SuppInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SuppInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_Supp, TableMdlSupp, 0, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_SuppInfoActionPerformed

 private void Btn_TransInSubjectInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSubjectInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransIn, TableMdlTransIn, 2, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransInSubjectInfoActionPerformed

 private void Btn_TransInSalesmanInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInSalesmanInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransIn, TableMdlTransIn, 4, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransInSalesmanInfoActionPerformed

 private void Btn_TransOutSubjectInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSubjectInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransOut, TableMdlTransOut, 2, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransOutSubjectInfoActionPerformed

 private void Btn_TransOutSalesmanInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutSalesmanInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_TransOut, TableMdlTransOut, 4, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransOutSalesmanInfoActionPerformed

 private void Btn_TransSubjectInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSubjectInfoActionPerformed
  PMyShop.viewFormInfo_FromComboBox(CmB_TransSubject, ComboMdlTransSubject, 0, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransSubjectInfoActionPerformed

 private void Btn_TransInTransTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInTransTempListAddActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransIn.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, true);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, true);
  }
 }//GEN-LAST:event_Btn_TransInTransTempListAddActionPerformed

 private void Btn_TransInTransTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInTransTempListRemoveActionPerformed
  int[] rows=Tbl_TransIn.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransIn.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, false);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, false);
  }
 }//GEN-LAST:event_Btn_TransInTransTempListRemoveActionPerformed

 private void Btn_TransInTransInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransInTransInfoActionPerformed
  PMyShop.viewFormInfo_SpecificTrans_FromTable(Tbl_TransIn, TableMdlTransIn, 6, IFV.FTransPreview, RB_TransIsPreTransY.isSelected(), false);
 }//GEN-LAST:event_Btn_TransInTransInfoActionPerformed

 private void Btn_TransOutTransTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutTransTempListAddActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransOut.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, true);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, true);
  }
 }//GEN-LAST:event_Btn_TransOutTransTempListAddActionPerformed

 private void Btn_TransOutTransTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutTransTempListRemoveActionPerformed
  int[] rows=Tbl_TransOut.getSelectedRows();
  long[] Ids;
  
  if(rows.length==0){return;}
  
  Ids=TableMdlTransOut.getIds(6, rows);
  
  if(!RB_TransIsPreTransY.isSelected()){
   IFV.FTransView.fillTempList(Ids, false);
  }
  else{
   IFV.FPreTransView.fillTempList(Ids, false);
  }
 }//GEN-LAST:event_Btn_TransOutTransTempListRemoveActionPerformed

 private void Btn_TransOutTransInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransOutTransInfoActionPerformed
  PMyShop.viewFormInfo_SpecificTrans_FromTable(Tbl_TransOut, TableMdlTransOut, 6, IFV.FTransPreview, RB_TransIsPreTransY.isSelected(), false);
 }//GEN-LAST:event_Btn_TransOutTransInfoActionPerformed

 private void CmB_ResultFilterIsReorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterIsReorderActionPerformed
  int temp=CmB_ResultFilterIsReorder.getSelectedIndex();
  if(LastResultFilterIsReorder==temp){return;}
  LastResultFilterIsReorder=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterIsReorderActionPerformed

 private void Btn_MultipleItemsIsReorderAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsIsReorderAddActionPerformed
  setItemIsReorder(true);
 }//GEN-LAST:event_Btn_MultipleItemsIsReorderAddActionPerformed

 private void Btn_MultipleItemsIsReorderRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsIsReorderRemoveActionPerformed
  setItemIsReorder(false);
 }//GEN-LAST:event_Btn_MultipleItemsIsReorderRemoveActionPerformed

 private void TF_SuppInfoNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_SuppInfoNameMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Supp, TableMdlSupp, 0, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_SuppInfoNameMouseClicked

 private void Tbl_VartMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_VartMouseReleased
  onSelectedRowVartChanged(false);
 }//GEN-LAST:event_Tbl_VartMouseReleased

 private void Tbl_VartKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_VartKeyReleased
  onSelectedRowVartChanged(false);
 }//GEN-LAST:event_Tbl_VartKeyReleased

 private void Btn_VartActiveAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_VartActiveAddActionPerformed
  setItemVartActive(true);
 }//GEN-LAST:event_Btn_VartActiveAddActionPerformed

 private void Btn_VartActiveRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_VartActiveRemoveActionPerformed
  setItemVartActive(false);
 }//GEN-LAST:event_Btn_VartActiveRemoveActionPerformed

 private void Btn_VartAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_VartAddActionPerformed
  addVart();
 }//GEN-LAST:event_Btn_VartAddActionPerformed

 private void Btn_VartEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_VartEditActionPerformed
  editVart();
 }//GEN-LAST:event_Btn_VartEditActionPerformed

 private void Btn_VartRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_VartRemoveActionPerformed
  removeVart();
 }//GEN-LAST:event_Btn_VartRemoveActionPerformed

 private void Pnl_VartInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_VartInfoPreviewMouseClicked
  int RowVart;
  Object[] objs;
  String PictureFile;
  F_ImagePreview fm=IFV.FImagePreview;
  
  RowVart=Tbl_Vart.getSelectedRow();
  if(RowVart==-1){return;}
  
  objs=TableMdlVart.Mdl.Rows.elementAt(RowVart);
  PictureFile=PText.getString(PCore.objString(objs[6], null), null, true);
  if(PictureFile==null){return;}
  
  fm.wTitle="Gambar Varian";
  fm.wAutoHideListPic=true;
  fm.wImageDir=IFV.Conf.ImageDirItem;
  fm.wModeFetchList=1;
  fm.wList=PCore.vectObj(PictureFile);
  
  if(!fm.showForm()){return;}
 }//GEN-LAST:event_Pnl_VartInfoPreviewMouseClicked

 private void Btn_MultipleItemsVartAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsVartAddActionPerformed
  int[] ItemRows;
  F_ItemVariantModify fm=IFV.FItemVariantModify;
  Object[] NewVart;
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}
  
  fm.wMode=1;
  
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  /* "Varian", "Aktif", "Hrg Beli", "Ket Hrg Beli", "Tgl Pembaruan", "Komentar", "File Gambar" */
  
  NewVart=PCore.objArrVariant(fm.Info.Variant, fm.Info.IsActive, fm.Info.BuyPrice, PText.getString(fm.Info.BuyComment, null, true), fm.Info.BuyUpdate,
   PText.getString(fm.Info.Comment, null, true), PText.getString(fm.Info.PictureFile, null, true));
  
  if(!addVart(true, ItemRows, ItemRows[0], PCore.toMultiRows2(NewVart), IFV.FSplashScreen)){
   JOptionPane.showMessageDialog(null, "Gagal menambah data varian !"); return;}
 }//GEN-LAST:event_Btn_MultipleItemsVartAddActionPerformed

 private void Btn_MultipleItemsVartRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsVartRemoveActionPerformed
  int[] ItemRows;
  long[] ItemIds;
  F_DataIdName fm=IFV.FDataIdName;
  String[] VariantIds;
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}
  ItemIds=TableItemMdl.getIds(0, ItemRows);
  
  fm.wMode=1;
  fm.wAllowMultipleSelection=true;
  fm.wByTableCode=false;
  fm.wUseCustomTitle=false;
  fm.wMasterDataIsEnable=false;

  fm.wQuery="select Min(0), Variant from ItemXVariant where Item in("+PText.toString(ItemIds, 0, ItemIds.length, ",")+") group by Variant order by Variant asc";
  fm.wTableText="Varian";
  fm.wIdInteger=true;
  
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  VariantIds=fm.DataName;
  
  if(!removeVart(ItemRows, ItemRows[0], 3, null, null, VariantIds, IFV.FSplashScreen)){
   JOptionPane.showMessageDialog(null, "Gagal menghapus data varian !"); return;}
 }//GEN-LAST:event_Btn_MultipleItemsVartRemoveActionPerformed

 private void List_CategoryMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_CategoryMouseReleased
  onListCategoryRowSelected(false);
 }//GEN-LAST:event_List_CategoryMouseReleased

 private void List_CategoryKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_CategoryKeyReleased
  onListCategoryRowSelected(false);
  
  int consumed=PNav.onKey_List(this, List_Category, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_CatRefresh)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_FindCategory)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddByCategoryActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveByCategoryActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_List_CategoryKeyReleased

 private void List_ItemPictureKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_ItemPictureKeyReleased
  onListPicRowSelected(false);
 }//GEN-LAST:event_List_ItemPictureKeyReleased

 private void List_ItemPictureMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_ItemPictureMouseReleased
  onListPicRowSelected(false);
 }//GEN-LAST:event_List_ItemPictureMouseReleased

 private void Btn_QueryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QueryKeyPressed
  PNav.onKey_Btn(this, Btn_Query, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QueryKeyPressed

 private void CB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCheckKeyPressed
  PNav.onKey_CB(this, CB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCheck)));
 }//GEN-LAST:event_CB_QCheckKeyPressed

 private void CmB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCheckKeyPressed
  PNav.onKey_CmB(this, CmB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCheck)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QCheckKeyPressed

 private void CB_QIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QIdKeyPressed
  PNav.onKey_CB(this, CB_QId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QId)));
 }//GEN-LAST:event_CB_QIdKeyPressed

 private void CmB_QIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QIdKeyPressed
  PNav.onKey_CmB(this, CmB_QId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QId)));
 }//GEN-LAST:event_CmB_QIdKeyPressed

 private void CB_QNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QNameKeyPressed
  PNav.onKey_CB(this, CB_QName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QName)));
 }//GEN-LAST:event_CB_QNameKeyPressed

 private void CB_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCommentKeyPressed
  PNav.onKey_CB(this, CB_QComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QExpList)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QComment)));
 }//GEN-LAST:event_CB_QCommentKeyPressed

 private void CmB_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCommentKeyPressed
  PNav.onKey_CmB(this, CmB_QComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QComment)));
 }//GEN-LAST:event_CmB_QCommentKeyPressed

 private void CB_QExpListKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QExpListKeyPressed
  PNav.onKey_CB(this, CB_QExpList, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QExpList)));
 }//GEN-LAST:event_CB_QExpListKeyPressed

 private void CmB_QExpListKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QExpListKeyPressed
  PNav.onKey_CmB(this, CmB_QExpList, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QExpList)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QExpList)));
 }//GEN-LAST:event_CmB_QExpListKeyPressed

 private void CB_QStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QStockKeyPressed
  PNav.onKey_CB(this, CB_QStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QExpList)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QOrderPack)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QStock)));
 }//GEN-LAST:event_CB_QStockKeyPressed

 private void CmB_QStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QStockKeyPressed
  PNav.onKey_CmB(this, CmB_QStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QStock1)));
 }//GEN-LAST:event_CmB_QStockKeyPressed

 private void CB_QOrderPackKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QOrderPackKeyPressed
  PNav.onKey_CB(this, CB_QOrderPack, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QExpRange)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QOrderPack)));
 }//GEN-LAST:event_CB_QOrderPackKeyPressed

 private void CmB_QOrderPackKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QOrderPackKeyPressed
  PNav.onKey_CmB(this, CmB_QOrderPack, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QOrderPack)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QOrderPack1)));
 }//GEN-LAST:event_CmB_QOrderPackKeyPressed

 private void CB_QExpRangeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QExpRangeKeyPressed
  PNav.onKey_CB(this, CB_QExpRange, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QOrderPack)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QExpRange)));
 }//GEN-LAST:event_CB_QExpRangeKeyPressed

 private void CmB_QExpRangeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QExpRangeKeyPressed
  PNav.onKey_CmB(this, CmB_QExpRange, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QExpRange)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QExpRange1)));
 }//GEN-LAST:event_CmB_QExpRangeKeyPressed

 private void CB_QPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPriceKeyPressed
  PNav.onKey_CB(this, CB_QPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QExpRange)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPriceUpdate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QPrice)));
 }//GEN-LAST:event_CB_QPriceKeyPressed

 private void CmB_QPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QPriceKeyPressed
  PNav.onKey_CmB(this, CmB_QPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QPrice)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QPrice1)));
 }//GEN-LAST:event_CmB_QPriceKeyPressed

 private void CB_QPriceUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPriceUpdateKeyPressed
  PNav.onKey_CB(this, CB_QPriceUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPrice)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QOrder)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QPriceUpdate)));
 }//GEN-LAST:event_CB_QPriceUpdateKeyPressed

 private void CmB_QPriceUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QPriceUpdateKeyPressed
  PNav.onKey_CmB(this, CmB_QPriceUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QPriceUpdate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QPriceUpdate1)));
 }//GEN-LAST:event_CmB_QPriceUpdateKeyPressed

 private void CB_QOrderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QOrderKeyPressed
  PNav.onKey_CB(this, CB_QOrder, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPriceUpdate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QStockUnit)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QOrder)));
 }//GEN-LAST:event_CB_QOrderKeyPressed

 private void CmB_QOrderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QOrderKeyPressed
  PNav.onKey_CmB(this, CmB_QOrder, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QOrder)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QOrder1)));
 }//GEN-LAST:event_CmB_QOrderKeyPressed

 private void CB_QStockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QStockUnitKeyPressed
  PNav.onKey_CB(this, CB_QStockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QOrder)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QStockUnitEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QStockUnit)));
 }//GEN-LAST:event_CB_QStockUnitKeyPressed

 private void CB_QStockUnitEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QStockUnitEmptyKeyPressed
  PNav.onKey_CB(this, CB_QStockUnitEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QStockUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCat)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QStockUnit)));
 }//GEN-LAST:event_CB_QStockUnitEmptyKeyPressed

 private void List_QStockUnitKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QStockUnitKeyReleased
  PNav.onKey_List(this, List_QStockUnit, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QOrder1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QStockUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QStockUnitAdd)));
 }//GEN-LAST:event_List_QStockUnitKeyReleased

 private void Btn_QStockUnitAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QStockUnitAddKeyPressed
  PNav.onKey_Btn(this, Btn_QStockUnitAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QOrder1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QStockUnitRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QStockUnit)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QStockUnitAddKeyPressed

 private void Btn_QStockUnitRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QStockUnitRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QStockUnitRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QStockUnitAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QStockUnit)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QStockUnitRemoveKeyPressed

 private void CB_QCatKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCatKeyPressed
  PNav.onKey_CB(this, CB_QCat, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QStockUnitEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCatNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCat)));
 }//GEN-LAST:event_CB_QCatKeyPressed

 private void CB_QCatNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCatNonKeyPressed
  PNav.onKey_CB(this, CB_QCatNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCat)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QTag)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCat)));
 }//GEN-LAST:event_CB_QCatNonKeyPressed

 private void List_QCatKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QCatKeyReleased
  PNav.onKey_List(this, List_QCat, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QStockUnitAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCat)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QCatAdd)));
 }//GEN-LAST:event_List_QCatKeyReleased

 private void Btn_QCatAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCatAddKeyPressed
  PNav.onKey_Btn(this, Btn_QCatAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QStockUnitRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCatRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCat)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCatAddKeyPressed

 private void Btn_QCatRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCatRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QCatRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCat)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCatRemoveKeyPressed

 private void CB_QTagKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QTagKeyPressed
  PNav.onKey_CB(this, CB_QTag, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCatNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QTagNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QTag)));
 }//GEN-LAST:event_CB_QTagKeyPressed

 private void CB_QTagNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QTagNonKeyPressed
  PNav.onKey_CB(this, CB_QTagNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QTag)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPic)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QTag)));
 }//GEN-LAST:event_CB_QTagNonKeyPressed

 private void List_QTagKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QTagKeyReleased
  PNav.onKey_List(this, List_QTag, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCatAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QTag)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QTagAdd)));
 }//GEN-LAST:event_List_QTagKeyReleased

 private void Btn_QTagAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QTagAddKeyPressed
  PNav.onKey_Btn(this, Btn_QTagAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCatRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTagRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QTag)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QTagAddKeyPressed

 private void Btn_QTagRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QTagRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QTagRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QTag)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QTagRemoveKeyPressed

 private void CB_QPicKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPicKeyPressed
  PNav.onKey_CB(this, CB_QPic, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QTagNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPicNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QPic)));
 }//GEN-LAST:event_CB_QPicKeyPressed

 private void CB_QPicNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPicNonKeyPressed
  PNav.onKey_CB(this, CB_QPicNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPic)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSup)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QPic)));
 }//GEN-LAST:event_CB_QPicNonKeyPressed

 private void List_QPicKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QPicKeyReleased
  PNav.onKey_List(this, List_QPic, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTagAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSupAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QPic)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QPicAdd)));
 }//GEN-LAST:event_List_QPicKeyReleased

 private void Btn_QPicAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QPicAddKeyPressed
  PNav.onKey_Btn(this, Btn_QPicAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTagRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QPicRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QPic)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QPicAddKeyPressed

 private void Btn_QPicRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QPicRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QPicRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSupAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QPic)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QPicRemoveKeyPressed

 private void CB_QSupKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSupKeyPressed
  PNav.onKey_CB(this, CB_QSup, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPicNon)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSupNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QSup)));
 }//GEN-LAST:event_CB_QSupKeyPressed

 private void CB_QSupNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSupNonKeyPressed
  PNav.onKey_CB(this, CB_QSupNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QSup)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QSup)));
 }//GEN-LAST:event_CB_QSupNonKeyPressed

 private void List_QSupKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QSupKeyReleased
  PNav.onKey_List(this, List_QSup, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QPicAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QSup)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QSupAdd)));
 }//GEN-LAST:event_List_QSupKeyReleased

 private void Btn_QSupAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSupAddKeyPressed
  PNav.onKey_Btn(this, Btn_QSupAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QPicRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSupRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QSup)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSupAddKeyPressed

 private void Btn_QSupRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSupRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QSupRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSupAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QSup)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSupRemoveKeyPressed

 private void Btn_CatRefreshKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatRefreshKeyPressed
  PNav.onKey_Btn(this, Btn_CatRefresh, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Category)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_CatQueryType)));
 }//GEN-LAST:event_Btn_CatRefreshKeyPressed

 private void CmB_CatQueryTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_CatQueryTypeKeyPressed
  PNav.onKey_CmB(this, CmB_CatQueryType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CatRefresh)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TempListAddByCategory)));
 }//GEN-LAST:event_CmB_CatQueryTypeKeyPressed

 private void Btn_TempListAddByCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TempListAddByCategoryKeyPressed
  PNav.onKey_Btn(this, Btn_TempListAddByCategory, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Category)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_CatQueryType)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TempListRemoveByCategory)));
 }//GEN-LAST:event_Btn_TempListAddByCategoryKeyPressed

 private void Btn_TempListRemoveByCategoryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveByCategoryKeyPressed
  PNav.onKey_Btn(this, Btn_TempListRemoveByCategory, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Category)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_TempListAddByCategory)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_TempListRemoveByCategoryKeyPressed

 private void Btn_FCatBeforeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatBeforeKeyPressed
  PNav.onKey_Btn(this, Btn_FCatBefore, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_FindCategory)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FCatNext)));
 }//GEN-LAST:event_Btn_FCatBeforeKeyPressed

 private void Btn_FCatNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FCatNextKeyPressed
  PNav.onKey_Btn(this, Btn_FCatNext, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FCatBefore)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CatAdd)));
 }//GEN-LAST:event_Btn_FCatNextKeyPressed

 private void Btn_CatAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatAddKeyPressed
  PNav.onKey_Btn(this, Btn_CatAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FCatNext)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CatEdit)));
 }//GEN-LAST:event_Btn_CatAddKeyPressed

 private void Btn_CatEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatEditKeyPressed
  PNav.onKey_Btn(this, Btn_CatEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CatAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CatRemove)));
 }//GEN-LAST:event_Btn_CatEditKeyPressed

 private void Btn_CatRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CatRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_CatRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Category)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CatEdit)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_CatRemoveKeyPressed

 private void CB_ViewStockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewStockActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewStockActionPerformed

 private void CB_ViewStockPreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewStockPreActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewStockPreActionPerformed

 private void CB_ViewStockEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewStockEstActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewStockEstActionPerformed

 private void CB_ViewStockMinMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewStockMinMaxActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewStockMinMaxActionPerformed

 private void CB_ViewIsOpnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIsOpnameActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewIsOpnameActionPerformed

 private void CB_ViewIsReorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIsReorderActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewIsReorderActionPerformed

 private void CB_ViewOrderPackQtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewOrderPackQtyActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewOrderPackQtyActionPerformed

 private void CB_ViewOrderPackThresholdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewOrderPackThresholdActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewOrderPackThresholdActionPerformed

 private void CB_ViewOrderPackMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewOrderPackMinActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewOrderPackMinActionPerformed

 private void CB_ViewStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewStockUnitActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewStockUnitActionPerformed

 private void CB_ViewStockIsUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewStockIsUpdateActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewStockIsUpdateActionPerformed

 private void CB_ViewBuyPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewBuyPriceActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewBuyPriceActionPerformed

 private void CB_ViewBuyPriceCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewBuyPriceCommentActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewBuyPriceCommentActionPerformed

 private void CB_ViewBuyUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewBuyUpdateActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewBuyUpdateActionPerformed

 private void CB_ViewSellPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSellPriceActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewSellPriceActionPerformed

 private void CB_ViewSellPriceCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSellPriceCommentActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewSellPriceCommentActionPerformed

 private void CB_ViewSellUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSellUpdateActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewSellUpdateActionPerformed

 private void CB_ViewExpCheckPeriodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewExpCheckPeriodActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewExpCheckPeriodActionPerformed

 private void CB_ViewExpThresholdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewExpThresholdActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewExpThresholdActionPerformed

 private void CB_ViewHasExpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewHasExpActionPerformed
  changeTableItemViewByNormalMode();
 }//GEN-LAST:event_CB_ViewHasExpActionPerformed

 private void CmB_ResultFilterIsOpnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterIsOpnameActionPerformed
  int temp=CmB_ResultFilterIsOpname.getSelectedIndex();
  if(LastResultFilterIsOpname==temp){return;}
  LastResultFilterIsOpname=temp;
  fillTable();
 }//GEN-LAST:event_CmB_ResultFilterIsOpnameActionPerformed

 private void Btn_MultipleItemsIsOpnameAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsIsOpnameAddActionPerformed
  setItemIsOpname(true);
 }//GEN-LAST:event_Btn_MultipleItemsIsOpnameAddActionPerformed

 private void Btn_MultipleItemsIsOpnameRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleItemsIsOpnameRemoveActionPerformed
  setItemIsOpname(false);
 }//GEN-LAST:event_Btn_MultipleItemsIsOpnameRemoveActionPerformed

 private void CB_ViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCategorizedActionPerformed
  changeTableItemViewByCategorized();
 }//GEN-LAST:event_CB_ViewCategorizedActionPerformed

 private void CB_VartViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewCommentActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewCommentActionPerformed

 private void CB_VartViewBuyPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewBuyPriceActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewBuyPriceActionPerformed

 private void CB_VartViewBuyCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewBuyCommentActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewBuyCommentActionPerformed

 private void CB_VartViewBuyUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_VartViewBuyUpdateActionPerformed
  changeVartViewByNormal();
 }//GEN-LAST:event_CB_VartViewBuyUpdateActionPerformed

 private void CB_SuppViewBuyUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewBuyUpdateActionPerformed
  changeSuppViewByNormal();
 }//GEN-LAST:event_CB_SuppViewBuyUpdateActionPerformed

 private void CB_SuppViewBuyCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewBuyCommentActionPerformed
  changeSuppViewByNormal();
 }//GEN-LAST:event_CB_SuppViewBuyCommentActionPerformed

 private void CB_SuppViewBuyPrcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SuppViewBuyPrcActionPerformed
  changeSuppViewByNormal();
 }//GEN-LAST:event_CB_SuppViewBuyPrcActionPerformed

 private void CB_TransInDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInDateActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInDateActionPerformed

 private void CB_TransInTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInTypeActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInTypeActionPerformed

 private void CB_TransInSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInSubjectActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInSubjectActionPerformed

 private void CB_TransInSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInSalesmanActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInSalesmanActionPerformed

 private void CB_TransInIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInIdActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInIdActionPerformed

 private void CB_TransInIdExternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInIdExternalActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInIdExternalActionPerformed

 private void CB_TransInItemCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInItemCommentActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInItemCommentActionPerformed

 private void CB_TransInPriceUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInPriceUnitActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInPriceUnitActionPerformed

 private void CB_TransInPriceTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransInPriceTotalActionPerformed
  changeTableTransInViewByNormalMode();
 }//GEN-LAST:event_CB_TransInPriceTotalActionPerformed

 private void CB_TransOutDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutDateActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutDateActionPerformed

 private void CB_TransOutTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutTypeActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutTypeActionPerformed

 private void CB_TransOutSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutSubjectActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutSubjectActionPerformed

 private void CB_TransOutSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutSalesmanActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutSalesmanActionPerformed

 private void CB_TransOutIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutIdActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutIdActionPerformed

 private void CB_TransOutIdExternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutIdExternalActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutIdExternalActionPerformed

 private void CB_TransOutItemCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutItemCommentActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutItemCommentActionPerformed

 private void CB_TransOutPriceUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutPriceUnitActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutPriceUnitActionPerformed

 private void CB_TransOutPriceTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutPriceTotalActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutPriceTotalActionPerformed

 private void CB_TransOutPriceBasicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_TransOutPriceBasicActionPerformed
  changeTableTransOutViewByNormalMode();
 }//GEN-LAST:event_CB_TransOutPriceBasicActionPerformed

 private void TF_FindCategoryFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindCategoryFocusGained
  PGUI.text_SelectAll(TF_FindCategory);
 }//GEN-LAST:event_TF_FindCategoryFocusGained

 private void TF_SuppFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SuppFindFocusGained
  PGUI.text_SelectAll(TF_SuppFind);
 }//GEN-LAST:event_TF_SuppFindFocusGained

 private void TF_TransInFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransInFindFocusGained
  PGUI.text_SelectAll(TF_TransInFind);
 }//GEN-LAST:event_TF_TransInFindFocusGained

 private void TF_TransOutFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransOutFindFocusGained
  PGUI.text_SelectAll(TF_TransOutFind);
 }//GEN-LAST:event_TF_TransOutFindFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_CatAdd;
 private javax.swing.JButton Btn_CatEdit;
 private javax.swing.JButton Btn_CatRefresh;
 private javax.swing.JButton Btn_CatRemove;
 private javax.swing.JButton Btn_CheckerExecute;
 private javax.swing.JButton Btn_CheckerP1;
 private javax.swing.JButton Btn_CheckerP2;
 private javax.swing.JButton Btn_Choose;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FCatBefore;
 private javax.swing.JButton Btn_FCatNext;
 private javax.swing.JButton Btn_FindBefore;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_ItemCategoryAdd;
 private javax.swing.JButton Btn_ItemCategoryRemove;
 private javax.swing.JButton Btn_ItemPictureAdd;
 private javax.swing.JButton Btn_ItemPictureRemove;
 private javax.swing.JButton Btn_ItemTagAdd;
 private javax.swing.JButton Btn_ItemTagRemove;
 private javax.swing.JButton Btn_MultipleItemsActiveAdd;
 private javax.swing.JButton Btn_MultipleItemsActiveRemove;
 private javax.swing.JButton Btn_MultipleItemsCategoryAdd;
 private javax.swing.JButton Btn_MultipleItemsCategoryRemove;
 private javax.swing.JButton Btn_MultipleItemsIsOpnameAdd;
 private javax.swing.JButton Btn_MultipleItemsIsOpnameRemove;
 private javax.swing.JButton Btn_MultipleItemsIsReorderAdd;
 private javax.swing.JButton Btn_MultipleItemsIsReorderRemove;
 private javax.swing.JButton Btn_MultipleItemsPicAdd;
 private javax.swing.JButton Btn_MultipleItemsPicRemove;
 private javax.swing.JButton Btn_MultipleItemsSupAdd;
 private javax.swing.JButton Btn_MultipleItemsSupRemove;
 private javax.swing.JButton Btn_MultipleItemsTagAdd;
 private javax.swing.JButton Btn_MultipleItemsTagRemove;
 private javax.swing.JButton Btn_MultipleItemsVartAdd;
 private javax.swing.JButton Btn_MultipleItemsVartRemove;
 private javax.swing.JButton Btn_New;
 private javax.swing.JButton Btn_QCatAdd;
 private javax.swing.JButton Btn_QCatRemove;
 private javax.swing.JButton Btn_QPicAdd;
 private javax.swing.JButton Btn_QPicRemove;
 private javax.swing.JButton Btn_QStockUnitAdd;
 private javax.swing.JButton Btn_QStockUnitRemove;
 private javax.swing.JButton Btn_QSupAdd;
 private javax.swing.JButton Btn_QSupRemove;
 private javax.swing.JButton Btn_QTagAdd;
 private javax.swing.JButton Btn_QTagRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_QueryRefresh;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Report;
 private javax.swing.JButton Btn_SecAdd;
 private javax.swing.JButton Btn_SecEdit;
 private javax.swing.JButton Btn_SecRemove;
 private javax.swing.JButton Btn_SuppActiveAdd;
 private javax.swing.JButton Btn_SuppActiveRemove;
 private javax.swing.JButton Btn_SuppAdd;
 private javax.swing.JButton Btn_SuppEdit;
 private javax.swing.JButton Btn_SuppFindBef;
 private javax.swing.JButton Btn_SuppFindNext;
 private javax.swing.JButton Btn_SuppInfo;
 private javax.swing.JButton Btn_SuppRemove;
 private javax.swing.JButton Btn_SuppTempListAdd;
 private javax.swing.JButton Btn_SuppTempListRemove;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListAddByCategory;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListRemoveByCategory;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JButton Btn_TransInFindBef;
 private javax.swing.JButton Btn_TransInFindNext;
 private javax.swing.JButton Btn_TransInSalesmanInfo;
 private javax.swing.JButton Btn_TransInSalesmanTempListAdd;
 private javax.swing.JButton Btn_TransInSalesmanTempListRemove;
 private javax.swing.JButton Btn_TransInSubjectInfo;
 private javax.swing.JButton Btn_TransInSubjectTempListAdd;
 private javax.swing.JButton Btn_TransInSubjectTempListRemove;
 private javax.swing.JButton Btn_TransInTransInfo;
 private javax.swing.JButton Btn_TransInTransTempListAdd;
 private javax.swing.JButton Btn_TransInTransTempListRemove;
 private javax.swing.JButton Btn_TransOutFindBef;
 private javax.swing.JButton Btn_TransOutFindNext;
 private javax.swing.JButton Btn_TransOutSalesmanInfo;
 private javax.swing.JButton Btn_TransOutSalesmanTempListAdd;
 private javax.swing.JButton Btn_TransOutSalesmanTempListRemove;
 private javax.swing.JButton Btn_TransOutSubjectInfo;
 private javax.swing.JButton Btn_TransOutSubjectTempListAdd;
 private javax.swing.JButton Btn_TransOutSubjectTempListRemove;
 private javax.swing.JButton Btn_TransOutTransInfo;
 private javax.swing.JButton Btn_TransOutTransTempListAdd;
 private javax.swing.JButton Btn_TransOutTransTempListRemove;
 private javax.swing.JButton Btn_TransSubjectInfo;
 private javax.swing.JButton Btn_VartActiveAdd;
 private javax.swing.JButton Btn_VartActiveRemove;
 private javax.swing.JButton Btn_VartAdd;
 private javax.swing.JButton Btn_VartEdit;
 private javax.swing.JButton Btn_VartRemove;
 private javax.swing.JCheckBox CB_CheckerAttr1;
 private javax.swing.JCheckBox CB_CheckerAttr2;
 private javax.swing.JCheckBox CB_DetBuy;
 private javax.swing.JCheckBox CB_DetExp;
 private javax.swing.JCheckBox CB_DetIsActive;
 private javax.swing.JCheckBox CB_DetIsOpname;
 private javax.swing.JCheckBox CB_DetIsReorder;
 private javax.swing.JCheckBox CB_DetSell;
 private javax.swing.JCheckBox CB_DetUpdateStock;
 private javax.swing.JCheckBox CB_QCat;
 private javax.swing.JCheckBox CB_QCatNon;
 private javax.swing.JCheckBox CB_QCheck;
 private javax.swing.JCheckBox CB_QComment;
 private javax.swing.JCheckBox CB_QExpList;
 private javax.swing.JCheckBox CB_QExpRange;
 private javax.swing.JCheckBox CB_QId;
 private javax.swing.JCheckBox CB_QName;
 private javax.swing.JCheckBox CB_QOrder;
 private javax.swing.JCheckBox CB_QOrderPack;
 private javax.swing.JCheckBox CB_QPic;
 private javax.swing.JCheckBox CB_QPicNon;
 private javax.swing.JCheckBox CB_QPrice;
 private javax.swing.JCheckBox CB_QPriceUpdate;
 private javax.swing.JCheckBox CB_QStock;
 private javax.swing.JCheckBox CB_QStockUnit;
 private javax.swing.JCheckBox CB_QStockUnitEmpty;
 private javax.swing.JCheckBox CB_QSup;
 private javax.swing.JCheckBox CB_QSupNon;
 private javax.swing.JCheckBox CB_QTag;
 private javax.swing.JCheckBox CB_QTagNon;
 private javax.swing.JCheckBox CB_SuppInfoActive;
 private javax.swing.JToggleButton CB_SuppViewBuyComment;
 private javax.swing.JToggleButton CB_SuppViewBuyPrc;
 private javax.swing.JToggleButton CB_SuppViewBuyUpdate;
 private javax.swing.JToggleButton CB_TransInDate;
 private javax.swing.JToggleButton CB_TransInId;
 private javax.swing.JToggleButton CB_TransInIdExternal;
 private javax.swing.JToggleButton CB_TransInItemComment;
 private javax.swing.JToggleButton CB_TransInPriceTotal;
 private javax.swing.JToggleButton CB_TransInPriceUnit;
 private javax.swing.JToggleButton CB_TransInSalesman;
 private javax.swing.JToggleButton CB_TransInSubject;
 private javax.swing.JToggleButton CB_TransInType;
 private javax.swing.JToggleButton CB_TransOutDate;
 private javax.swing.JToggleButton CB_TransOutId;
 private javax.swing.JToggleButton CB_TransOutIdExternal;
 private javax.swing.JToggleButton CB_TransOutItemComment;
 private javax.swing.JToggleButton CB_TransOutPriceBasic;
 private javax.swing.JToggleButton CB_TransOutPriceTotal;
 private javax.swing.JToggleButton CB_TransOutPriceUnit;
 private javax.swing.JToggleButton CB_TransOutSalesman;
 private javax.swing.JToggleButton CB_TransOutSubject;
 private javax.swing.JToggleButton CB_TransOutType;
 private javax.swing.JToggleButton CB_VartViewBuyComment;
 private javax.swing.JToggleButton CB_VartViewBuyPrice;
 private javax.swing.JToggleButton CB_VartViewBuyUpdate;
 private javax.swing.JToggleButton CB_VartViewComment;
 private javax.swing.JToggleButton CB_ViewBuyPrice;
 private javax.swing.JToggleButton CB_ViewBuyPriceComment;
 private javax.swing.JToggleButton CB_ViewBuyUpdate;
 private javax.swing.JToggleButton CB_ViewCategorized;
 private javax.swing.JToggleButton CB_ViewExpCheckPeriod;
 private javax.swing.JToggleButton CB_ViewExpThreshold;
 private javax.swing.JToggleButton CB_ViewHasExp;
 private javax.swing.JToggleButton CB_ViewIsOpname;
 private javax.swing.JToggleButton CB_ViewIsReorder;
 private javax.swing.JToggleButton CB_ViewOrderPackMin;
 private javax.swing.JToggleButton CB_ViewOrderPackQty;
 private javax.swing.JToggleButton CB_ViewOrderPackThreshold;
 private javax.swing.JToggleButton CB_ViewSellPrice;
 private javax.swing.JToggleButton CB_ViewSellPriceComment;
 private javax.swing.JToggleButton CB_ViewSellUpdate;
 private javax.swing.JToggleButton CB_ViewStock;
 private javax.swing.JToggleButton CB_ViewStockEst;
 private javax.swing.JToggleButton CB_ViewStockIsUpdate;
 private javax.swing.JToggleButton CB_ViewStockMinMax;
 private javax.swing.JToggleButton CB_ViewStockPre;
 private javax.swing.JToggleButton CB_ViewStockUnit;
 private javax.swing.JComboBox<String> CmB_CatQueryType;
 private javax.swing.JComboBox<String> CmB_CheckerAttr1;
 private javax.swing.JComboBox<String> CmB_CheckerAttr2;
 private javax.swing.JComboBox<String> CmB_CheckerIdInput;
 private javax.swing.JComboBox<String> CmB_DetBuy;
 private javax.swing.JComboBox<String> CmB_DetSell;
 private javax.swing.JComboBox<String> CmB_Find;
 private javax.swing.JComboBox<String> CmB_QCheck;
 private javax.swing.JComboBox<String> CmB_QComment;
 private javax.swing.JComboBox<String> CmB_QExpList;
 private javax.swing.JComboBox<String> CmB_QExpRange;
 private javax.swing.JComboBox<String> CmB_QId;
 private javax.swing.JComboBox<String> CmB_QOrder;
 private javax.swing.JComboBox<String> CmB_QOrderPack;
 private javax.swing.JComboBox<String> CmB_QPrice;
 private javax.swing.JComboBox<String> CmB_QPriceUpdate;
 private javax.swing.JComboBox<String> CmB_QStock;
 private javax.swing.JComboBox<String> CmB_ReportType;
 private javax.swing.JComboBox<String> CmB_ResultFilterActive;
 private javax.swing.JComboBox<String> CmB_ResultFilterExpire;
 private javax.swing.JComboBox<String> CmB_ResultFilterIsOpname;
 private javax.swing.JComboBox<String> CmB_ResultFilterIsReorder;
 private javax.swing.JComboBox<String> CmB_ResultFilterSubset;
 private javax.swing.JComboBox<String> CmB_ResultFilterUpdateStock;
 private javax.swing.JComboBox<String> CmB_SuppFind;
 private javax.swing.JComboBox<String> CmB_TransInFind;
 private javax.swing.JComboBox<String> CmB_TransOutFind;
 private javax.swing.JComboBox<String> CmB_TransSubject;
 private javax.swing.JComboBox<String> CmB_TransType;
 private javax.swing.JComboBox<String> CmB_ViewMode;
 private javax.swing.JLabel Lbl_MultipleSelection;
 private javax.swing.JLabel Lbl_QCommentHelp;
 private javax.swing.JLabel Lbl_QExpListHelp;
 private javax.swing.JLabel Lbl_QExpRangeHelp;
 private javax.swing.JLabel Lbl_QIdHelp;
 private javax.swing.JLabel Lbl_QNameHelp;
 private javax.swing.JLabel Lbl_QOrderHelp;
 private javax.swing.JLabel Lbl_QOrderPackHelp;
 private javax.swing.JLabel Lbl_QPriceHelp;
 private javax.swing.JLabel Lbl_QPriceUpdateHelp;
 private javax.swing.JLabel Lbl_QStockHelp;
 private XList List_Category;
 private XList List_ItemCategory;
 private XList List_ItemPicture;
 private XList List_ItemTag;
 private XList List_QCat;
 private XList List_QPic;
 private XList List_QStockUnit;
 private XList List_QSup;
 private XList List_QTag;
 private XList List_Sec;
 private javax.swing.JPanel Panel_CategorizedView;
 private XImgBoxURL Panel_Image;
 private javax.swing.JPanel Panel_ItemDetail;
 private javax.swing.JPanel Panel_ItemEtc;
 private javax.swing.JPanel Panel_ItemPicture;
 private javax.swing.JPanel Panel_ItemSupplier;
 private javax.swing.JPanel Panel_ItemVariant;
 private javax.swing.JPanel Panel_Query;
 private javax.swing.JPanel Panel_Trans;
 private javax.swing.JPanel Panel_TransIn;
 private javax.swing.JPanel Panel_TransOut;
 private javax.swing.JPanel Pnl_CatModify;
 private javax.swing.JPanel Pnl_Checker;
 private javax.swing.JPanel Pnl_CheckerInfo;
 private javax.swing.JPanel Pnl_CheckerInput;
 private XImgBoxURL Pnl_CheckerItemPreview;
 private XImgBoxURL Pnl_VartInfoPreview;
 private javax.swing.JPanel Pnl_ViewNormalMode;
 private javax.swing.JRadioButton RB_TransIsPreTransN;
 private javax.swing.JRadioButton RB_TransIsPreTransY;
 private javax.swing.ButtonGroup RG_Find;
 private javax.swing.ButtonGroup RG_HasExpire;
 private javax.swing.ButtonGroup RG_IsActive;
 private javax.swing.ButtonGroup RG_QMismatch;
 private javax.swing.ButtonGroup RG_Query;
 private javax.swing.ButtonGroup RG_Stock;
 private javax.swing.ButtonGroup RG_UpdateStock;
 private javax.swing.ButtonGroup RG_ViewTransIsPreTrans;
 private javax.swing.JTextArea TA_CheckerItemName;
 private javax.swing.JTextArea TA_DetBuy;
 private javax.swing.JTextArea TA_DetComment;
 private javax.swing.JTextArea TA_DetIdName;
 private javax.swing.JTextArea TA_DetSell;
 private javax.swing.JTextArea TA_SuppInfoBuy;
 private javax.swing.JTextArea TA_VartInfoBuy;
 private javax.swing.JTextArea TA_VartInfoName;
 private javax.swing.JTextField TF_CategoryCheckedCount;
 private javax.swing.JTextField TF_CategoryCount;
 private javax.swing.JTextField TF_CheckerAttr1;
 private javax.swing.JTextField TF_CheckerAttr2;
 private javax.swing.JTextField TF_CheckerInfo;
 private javax.swing.JTextField TF_CheckerItemId;
 private javax.swing.JTextField TF_DetExpire;
 private javax.swing.JTextField TF_DetOrderSpec;
 private javax.swing.JTextField TF_DetStock;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_FindCategory;
 private javax.swing.JTextField TF_QComment;
 private javax.swing.JTextField TF_QExpList;
 private javax.swing.JTextField TF_QExpRange1;
 private javax.swing.JTextField TF_QExpRange2;
 private javax.swing.JTextField TF_QId;
 private javax.swing.JTextField TF_QName;
 private javax.swing.JTextField TF_QOrder1;
 private javax.swing.JTextField TF_QOrder2;
 private javax.swing.JTextField TF_QOrderPack1;
 private javax.swing.JTextField TF_QOrderPack2;
 private javax.swing.JTextField TF_QPrice1;
 private javax.swing.JTextField TF_QPrice2;
 private javax.swing.JTextField TF_QPriceUpdate1;
 private javax.swing.JTextField TF_QPriceUpdate2;
 private javax.swing.JTextField TF_QStock1;
 private javax.swing.JTextField TF_QStock2;
 private javax.swing.JTextField TF_QueryCount;
 private javax.swing.JTextField TF_QueryTempListCount;
 private javax.swing.JTextField TF_SuppFind;
 private javax.swing.JTextField TF_SuppInfoName;
 private javax.swing.JTextField TF_TempListQuantity;
 private javax.swing.JTextField TF_TransInFind;
 private javax.swing.JTextField TF_TransOutFind;
 private javax.swing.JTabbedPane TabbedPane;
 private javax.swing.JTabbedPane TabbedPane_TransList;
 private XTable Tbl_Item;
 private XTable Tbl_Supp;
 private XTable Tbl_TransIn;
 private XTable Tbl_TransOut;
 private XTable Tbl_Vart;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel12;
 private javax.swing.JLabel jLabel13;
 private javax.swing.JLabel jLabel14;
 private javax.swing.JLabel jLabel15;
 private javax.swing.JLabel jLabel16;
 private javax.swing.JLabel jLabel17;
 private javax.swing.JLabel jLabel18;
 private javax.swing.JLabel jLabel19;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel20;
 private javax.swing.JLabel jLabel21;
 private javax.swing.JLabel jLabel22;
 private javax.swing.JLabel jLabel23;
 private javax.swing.JLabel jLabel24;
 private javax.swing.JLabel jLabel25;
 private javax.swing.JLabel jLabel26;
 private javax.swing.JLabel jLabel27;
 private javax.swing.JLabel jLabel28;
 private javax.swing.JLabel jLabel29;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel30;
 private javax.swing.JLabel jLabel31;
 private javax.swing.JLabel jLabel32;
 private javax.swing.JLabel jLabel33;
 private javax.swing.JLabel jLabel34;
 private javax.swing.JLabel jLabel35;
 private javax.swing.JLabel jLabel36;
 private javax.swing.JLabel jLabel37;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel16;
 private javax.swing.JPanel jPanel17;
 private javax.swing.JPanel jPanel18;
 private javax.swing.JPanel jPanel19;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel20;
 private javax.swing.JPanel jPanel21;
 private javax.swing.JPanel jPanel22;
 private javax.swing.JPanel jPanel23;
 private javax.swing.JPanel jPanel24;
 private javax.swing.JPanel jPanel25;
 private javax.swing.JPanel jPanel26;
 private javax.swing.JPanel jPanel27;
 private javax.swing.JPanel jPanel28;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane12;
 private javax.swing.JScrollPane jScrollPane13;
 private javax.swing.JScrollPane jScrollPane14;
 private javax.swing.JScrollPane jScrollPane15;
 private javax.swing.JScrollPane jScrollPane18;
 private javax.swing.JScrollPane jScrollPane19;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane20;
 private javax.swing.JScrollPane jScrollPane21;
 private javax.swing.JScrollPane jScrollPane22;
 private javax.swing.JScrollPane jScrollPane23;
 private javax.swing.JScrollPane jScrollPane24;
 private javax.swing.JScrollPane jScrollPane25;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 // End of variables declaration//GEN-END:variables
}