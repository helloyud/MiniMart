import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.print.Book;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableColumnModel;

public class F_TransNew extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 boolean wIsPreTrans;
 
 // 
 String DbTable;
 String DbAppLock;
 String DbPendLock;
 String TransName;
 
 // Last Trans
 long LastTransId;
 String LastTransIdExternal;
 
 // Current Trans
 long TransId;
 long TransPendingId;
	Date TransDate;
	int TransCreditDays;
 long TransSubjectId; String TransSubjectName;
 long TransSalesmanId; String TransSalesmanName;
	Date TransRepayPeriodStart, TransRepayPeriodEnd;
 OCustomComboBoxModel ComboMdlTransType;
 OCustomComboBoxModel ComboMdlCashOut;
 OCustomComboBoxModel ComboMdlCashIn;
 OCustomComboBoxModel ComboMdlReceiptPaper;
 OCustomComboBoxModel ComboMdlReceiptPrinter;
 
 // Trans's Item In
 OCustomTableModel TableMdlIn;
 VDouble InPrice;
 int LastSelectedRowIn;
 OQuickListOfLong QuickIdIn;
 
 // Trans's Item Out
 OCustomTableModel TableMdlOut;
 VDouble OutPrice;
 int LastSelectedRowOut;
 OQuickListOfLong QuickIdOut;
 
 // Add Item
  // Item
 boolean RecheckId;
 long CheckedId, I_CheckedId;
 OInfoItem ItemInfo, I_ItemInfo;
 boolean InputInfoClearedItem;
 
 String I_TransItemComment, TransItemComment;
 
  // Qty
 double Qty, I_Qty;
 
  // Price
 double PriceUnit, I_PriceUnit;
 double PriceTotal, I_PriceTotal;
 boolean InputInfoClearedPrice;
 
  // Others
 VBoolean EnableDocumentListener;
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 
 public F_TransNew(MInterFormVariables IFV_) {
  String[] ColName;
  int[] ColType;
  int[] ColVisible;
  int[] Editable;
  TableColumnModel ColMdl;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  Lbl_TransComment.setText("Komentar (Opsional, maksimal "+PText.intToString(CApp.DbVarcharMaxSize)+" karakter)");
  TA_TransComment.setToolTipText("maksimal "+PText.intToString(CApp.DbVarcharMaxSize)+" karakter");
  
  // Last Trans
  clearLastTrans();
  
  // Current Trans
  RB_TransIdExternal.setSelected(true);
  CB_Receipt.setSelected(false);
  ColType=new int[2]; // PrintService, PrintServiceName
  ColType[0]=0;
  ColType[1]=1;
  ComboMdlReceiptPrinter=new OCustomComboBoxModel();
  ComboMdlReceiptPrinter.setColumnsInfo(ColType, 1);
  ComboBox_ReceiptPrinter.setModel(ComboMdlReceiptPrinter);
  ComboMdlReceiptPaper=new OCustomComboBoxModel();
  ComboMdlReceiptPaper.setColumnsInfo(PCore.primArr(CCore.TypeUnknown, CCore.TypeInteger, CCore.TypeString), 2); // OPaper, PaperId, PaperName
  ComboBox_ReceiptPaper.setModel(ComboMdlReceiptPaper);
  PPrint.fillPapers(ComboMdlReceiptPaper, PMyShop.getPaperReceipt(IFV.Conf.StandardPaperMargin, IFV.Conf.ThermalPaperMargin));
  ComboBox_ReceiptPaper.setSelectedIndex(PGUI.findLong(ComboMdlReceiptPaper, 1, IFV.CurrentReceiptPaper.Id));
  ColType=new int[2]; // TransType_Id, TransType_Name
  ColType[0]=2;
  ColType[1]=1;
  ComboMdlTransType=new OCustomComboBoxModel();
  ComboMdlTransType.setColumnsInfo(ColType, 1);
  ComboBox_TransType.setModel(ComboMdlTransType);
  ColType=new int[2]; // Cash_Id, Cash_Name
  ColType[0]=2;
  ColType[1]=1;
  ComboMdlCashOut=new OCustomComboBoxModel();
  ComboMdlCashOut.setColumnsInfo(ColType, 1);
  ComboBox_CashOut.setModel(ComboMdlCashOut);
  ColType=new int[2]; // Cash_Id, Cash_Name
  ColType[0]=2;
  ColType[1]=1;
  ComboMdlCashIn=new OCustomComboBoxModel();
  ComboMdlCashIn.setColumnsInfo(ColType, 1);
  ComboBox_CashIn.setModel(ComboMdlCashIn);
  TransSubjectId=-1;
  TransSalesmanId=-1;
		CB_RepayPeriodActionPerformed(null);
  
  // Table Item Out
  ColName=new String[10];
  ColName[0]="Id Barang";
  ColName[1]="Nm Brg";
  ColName[2]="Nama Barang";
  ColName[3]="Qty";
  ColName[4]="Satuan";
  ColName[5]="Harga Total";
  ColName[6]="Harga Satuan";
  ColName[7]="Komentar";
  ColName[8]="Diperbarui";
  ColName[9]="File Gambar";
  ColType=new int[10];
  ColType[0]=3;
  ColType[1]=1;
  ColType[2]=CCore.TypeString;
  ColType[3]=CCore.TypeDouble;
  ColType[4]=CCore.TypeString;
  ColType[5]=4;
  ColType[6]=4;
  ColType[7]=CCore.TypeString;
  ColType[8]=5;
  ColType[9]=CCore.TypeString;
  ColVisible=new int[7];
  ColVisible[0]=2;
  ColVisible[1]=3;
  ColVisible[2]=4;
  ColVisible[3]=6;
  ColVisible[4]=5;
  ColVisible[5]=0;
  ColVisible[6]=8;
  Editable=PCore.primArr(3, 5, 6);
  TableMdlOut=new OCustomTableModel(true, CApp.Default_TransItem_Checked, true);
  TableMdlOut.setColumnsInfo(ColName, ColType,
   PCore.changeValue(PCore.newIntegerArray(ColName.length, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   ColVisible,
   PCore.changeValue(PCore.newBooleanArray(ColName.length, false),
    Editable, PCore.newBooleanArray(Editable.length, true)));
  Tbl_Out.setModel(TableMdlOut);
  refreshTotalCount(TF_OutCount, TableMdlOut);
  OutPrice=new VDouble(0); refreshTotalPrice(TF_OutPrice, OutPrice);
  LastSelectedRowOut=-1;
  QuickIdOut=new OQuickListOfLong(1024, 1024, false, false);
  RB_FindItemOutName.setSelected(true);
  ColMdl=Tbl_Out.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(25);
  ColMdl.getColumn(1).setPreferredWidth(380);
  ColMdl.getColumn(2).setPreferredWidth(45);
  ColMdl.getColumn(3).setPreferredWidth(55);
  ColMdl.getColumn(4).setPreferredWidth(90);
  ColMdl.getColumn(5).setPreferredWidth(100);
  ColMdl.getColumn(6).setPreferredWidth(105);
  ColMdl.getColumn(7).setPreferredWidth(25);
  
  Tbl_Out.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem(false);}
   };
  
  Pnl_ItemOutPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Table Item In
  ColName=new String[10];
  ColName[0]="Id Barang";
  ColName[1]="Nama Brg";
  ColName[2]="Nama Barang";
  ColName[3]="Qty";
  ColName[4]="Satuan";
  ColName[5]="Harga Total";
  ColName[6]="Harga Satuan";
  ColName[7]="Komentar";
  ColName[8]="Diperbarui";
  ColName[9]="File Gambar";
  ColType=new int[10];
  ColType[0]=3;
  ColType[1]=1;
  ColType[2]=CCore.TypeString;
  ColType[3]=CCore.TypeDouble;
  ColType[4]=CCore.TypeString;
  ColType[5]=4;
  ColType[6]=4;
  ColType[7]=CCore.TypeString;
  ColType[8]=5;
  ColType[9]=CCore.TypeString;
  ColVisible=new int[7];
  ColVisible[0]=2;
  ColVisible[1]=3;
  ColVisible[2]=4;
  ColVisible[3]=6;
  ColVisible[4]=5;
  ColVisible[5]=0;
  ColVisible[6]=8;
  Editable=PCore.primArr(3, 5, 6);
  TableMdlIn=new OCustomTableModel(true, CApp.Default_TransItem_Checked, true);
  TableMdlIn.setColumnsInfo(ColName, ColType,
   PCore.changeValue(PCore.newIntegerArray(ColName.length, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   ColVisible,
   PCore.changeValue(PCore.newBooleanArray(ColName.length, false),
    Editable, PCore.newBooleanArray(Editable.length, true)));
  Tbl_In.setModel(TableMdlIn);
  refreshTotalCount(TF_InCount, TableMdlIn);
  InPrice=new VDouble(0); refreshTotalPrice(TF_InPrice, InPrice);
  LastSelectedRowIn=-1;
  QuickIdIn=new OQuickListOfLong(1024, 1024, false, false);
  RB_FindItemInName.setSelected(true);
  ColMdl=Tbl_In.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(25);
  ColMdl.getColumn(1).setPreferredWidth(380);
  ColMdl.getColumn(2).setPreferredWidth(45);
  ColMdl.getColumn(3).setPreferredWidth(55);
  ColMdl.getColumn(4).setPreferredWidth(90);
  ColMdl.getColumn(5).setPreferredWidth(100);
  ColMdl.getColumn(6).setPreferredWidth(105);
  ColMdl.getColumn(7).setPreferredWidth(25);
  
  Tbl_In.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem(true);}
   };
  
  Pnl_ItemInPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Add Item
  TF_TransItemComment.setToolTipText("isi komentar barang di sini .... (max "+PText.intToString(CApp.DbVarcharMaxSize)+" karakter)");
  
  I_ItemInfo=new OInfoItem();
  
  EnableDocumentListener=new VBoolean(true);
  
  TF_ItemId.setToolTipText("{F6} ket brg, {Spasi} cari brg, {Enter} tbh brg, {Down} ubah qty & hrg");
  TF_ItemId.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
   });
  TF_Quantity.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
   });
  TF_PriceUnit.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener.Value){
      inputPriceUnit();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener.Value){
      inputPriceUnit();
     }
    }
   });
  TF_PriceTotal.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==3 && EnableDocumentListener.Value){
      inputPriceTotal();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==3 && EnableDocumentListener.Value){
      inputPriceTotal();
     }
    }
   });
  
  RB_PriceUnit.addItemListener(new ItemListener(){
   public void itemStateChanged(ItemEvent evt){
    if(RB_PriceUnit.isSelected() && EnableDocumentListener.Value){switchInputPrice();}
   }
  });
  RB_PriceTotal.addItemListener(new ItemListener(){
   public void itemStateChanged(ItemEvent evt){
    if(RB_PriceTotal.isSelected() && EnableDocumentListener.Value){switchInputPrice();}
   }
  });
  
  EnableDocumentListener.Value=true;
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  I_CheckedId=-1; RecheckId=false;
  I_Qty=-1;
  I_PriceUnit=-1;
  I_PriceTotal=-1;
  
  InputInfoClearedItem=true;
  InputInfoClearedPrice=true;
  
  RB_AddItemOut.setSelected(true);
  RB_PriceUnit.setSelected(true);
  enableEditPrice(false);
  
  CB_ItemIdEnterAutoAdd.setSelected(true);
  CmB_Price.setSelectedIndex(2);
 }
 
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_Receipt, ComboBox_ReceiptPaper, ComboBox_ReceiptPrinter,
    
    RB_TransId, Btn_TransPendingLoad, CB_TransImportant,
    RB_TransIdExternal, CB_TransIdExternalKeep, TF_TransIdExternal,
    
    TF_TransDateYear, ComboBox_TransDateMonth, ComboBox_TransDateDay,
    CB_TransCreditDaysKeep, TF_TransCreditDays,
    CB_RepayPeriodKeep, CB_RepayPeriod, TF_RepayPeriodStart, TF_RepayPeriodEnd,
    
    ComboBox_TransType,
    ComboBox_CashIn, CB_CashInCommentKeep, TF_CashInComment,
    ComboBox_CashOut, CB_CashOutCommentKeep, TF_CashOutComment,
    CB_TransSubjectKeep, Btn_ChooseSubject, Btn_ClearChoosedSubject,
    CB_TransSalesmanKeep, Btn_ChooseSalesman, Btn_ClearChoosedSalesman,
    
    RB_AddItemIn, RB_AddItemOut, Btn_AddItem,
    CB_ItemIdEnterAutoAdd, Btn_ChooseItem, TF_ItemId,
    TF_TransItemComment,
    TF_Quantity,
    CB_Price, CmB_Price, RB_PriceUnit, TF_PriceUnit, RB_PriceTotal, TF_PriceTotal,
    
    RB_FindItemOutId, RB_FindItemOutName, TF_FindItemOut, Btn_FindItemOutBef, Btn_FindItemOutNext,
    CB_ItemOutKeep, Btn_OutMove, Btn_OutRemove, Btn_OutEdit, Btn_OutCheckAdd, Btn_OutCheckRemove,
    Tbl_Out,
    
    RB_FindItemInId, RB_FindItemInName, TF_FindItemIn, Btn_FindItemInBef, Btn_FindItemInNext,
    CB_ItemInKeep, Btn_InMove, Btn_InRemove, Btn_InEdit, Btn_InCheckAdd, Btn_InCheckRemove,
    Tbl_In,
    
    TA_TransComment, CB_TransCommentKeep,
    
    Btn_ReprintLastTrans, Btn_TransPending, Btn_TransCancel, Btn_TransFinish),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, InputEvent.SHIFT_DOWN_MASK, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // F2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddItemActionPerformed(null);
    }
   });
  
  // F3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, InputEvent.ALT_DOWN_MASK, false), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     RB_AddItemIn.setSelected(true);
    }
   });
  
  // F4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_DOWN_MASK, false), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     RB_AddItemOut.setSelected(true);
    }
   });
  
  // F6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     TabbedPane.setSelectedIndex(0);
    }
   });
  
  // F7
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0, true), "f7");
  act.put("f7", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     TabbedPane.setSelectedIndex(1);
    }
   });
  
  // F11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_TransFinishActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
 }
 
 void setPaper(OPaper PaperType){
  ComboBox_ReceiptPaper.setSelectedIndex(PGUI.findLong(ComboMdlReceiptPaper, 1, PaperType.Id));
 }
 OPaper getPaper(){
  return (OPaper)ComboMdlReceiptPaper.Mdl.Rows.elementAt(ComboBox_ReceiptPaper.getSelectedIndex())[0];
 }
 
 void clearComponents(){
  Tbl_Out.editingCanceled(null);
  Tbl_In.editingCanceled(null);
  
  CB_Receipt.setSelected(false);
  ComboMdlReceiptPrinter.removeAll();
  removeCurrentTransId(TransPendingId==-1);
  clearTransIdAndDateInput();
  clearTransInputs(true);
  clearAllKeepInput();
  ComboMdlTransType.removeAll();
  ComboMdlCashOut.removeAll();
  ComboMdlCashIn.removeAll();
  RB_FindItemOutName.setSelected(true);
  PGUI.clearText(TF_FindItemOut);
  RB_FindItemInName.setSelected(true);
  PGUI.clearText(TF_FindItemIn);
  clearLastTrans();
  
  
 }
 void clearAllKeepInput(){
  PGUI.setSelected(false,
   CB_TransIdExternalKeep, CB_TransCommentKeep,
   CB_TransCreditDaysKeep, CB_RepayPeriodKeep,
   CB_CashOutCommentKeep, CB_CashInCommentKeep,
   CB_TransSubjectKeep, CB_TransSalesmanKeep,
   CB_ItemInKeep, CB_ItemOutKeep);
 }
 
 void onSelectedRowInChanged(boolean UpdateAnyway){
  int row=Tbl_In.getSelectedRow();
  if(LastSelectedRowIn!=row || UpdateAnyway){
   LastSelectedRowIn=row;
   if(row==-1){clearItemInInfo();}
   else{fillItemInInfo(row);}
  }
 }
 void onSelectedRowOutChanged(boolean UpdateAnyway){
  int row=Tbl_Out.getSelectedRow();
  if(LastSelectedRowOut!=row || UpdateAnyway){
   LastSelectedRowOut=row;
   if(row==-1){clearItemOutInfo();}
   else{fillItemOutInfo(row);}
  }
 }
 void onEditingTableItem(boolean IsItemIn){
  int Row, Col;
  int result=0;
  boolean IsSame;
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemIn, TableMdlIn, TableMdlOut);
  
  Row=Tbl.Editing_Row;
  Col=TableMdl.convertColumnIndexFromViewToModel(Tbl.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdl.Mdl.ColumnsType[Col], null, Tbl.Editing_ValueOld, true, null, Tbl.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableItem_Check(IsItemIn, Row); break;}
   result=onEditingTableItem_Item(IsItemIn, Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableItem_Check(boolean IsItemIn, int Row){
  int ret=0;
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  
  addCheck(IsItemIn, PCore.primArr(Row), PCore.objBoolean(Tbl.Editing_ValueNew, false));
  
  return ret;
 }
 int onEditingTableItem_Item(boolean IsItemIn, int Row, int Col){
  int ret=0;
  boolean valid;
  OEditTransItem Edit;
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  
  do{
   Edit=new OEditTransItem();
   valid=true;
   switch(Col){
    // double not null, positive only, >0
    case 3 : Edit.EditQuantity=true; Edit.EditedQuantity=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedQuantity<=0){valid=false;} break;

    // double not null, positive only, >=0
    case 5 : Edit.EditPriceTotal=true; Edit.EditedPriceTotal=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedPriceTotal<0){valid=false;} break;
    case 6 : Edit.EditPriceUnit=true; Edit.EditedPriceUnit=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedPriceUnit<0){valid=false;} break;
   }
   if(!valid){ret=-2; break;}

   editItems(IsItemIn, PCore.primArr(Row), Edit);
  }while(false);
  
  return ret;
 }
 
 //
 int addItem(long CheckedId, String ItemName, double CheckedQuantity, String ItemStockUnit, double CheckedPriceTotal, String TransItemComment, Object Check,
  Object ItemUpdateStock, Object ItemPictureFile,
  OCustomTableModel TableMdl, OQuickListOfLong QuickId, VDouble TotalPrice){
  int ret;
  int temp;
  Object[] NewRow;
  double Qty; double Price;
  
  // search for existed item in table
  ret=QuickId.checkElement(CheckedId);

  // add item
  
  if(ret<0){
   // define new row's insert position
   ret=0;
   temp=TableMdl.Mdl.Rows.size();
   if(temp!=0){
    do{
     if(PText.grading(ItemName, (String)TableMdl.Mdl.Rows.elementAt(ret)[1], false)==1){break;}
     ret=ret+1;
    }while(ret!=temp);
   }
   // insert a new row
   QuickId.addAt(ret, CheckedId);
   NewRow=new Object[10];
   NewRow[0]=CheckedId;
   NewRow[1]=ItemName;
   NewRow[2]=PMyShop.genTransItemName(ItemName, TransItemComment);
   NewRow[3]=CheckedQuantity;
   NewRow[4]=PText.getString(ItemStockUnit, null,
    PText.getString(PText.findElementCharacter(CCore.Chars_WhiteSpace, PText.getCharAt(ItemStockUnit, 0))==-1, " ", "")+ItemStockUnit, true);
   NewRow[5]=CheckedPriceTotal;
   NewRow[6]=(double)(CheckedPriceTotal/CheckedQuantity);
   NewRow[7]=TransItemComment;
   NewRow[8]=ItemUpdateStock;
   NewRow[9]=ItemPictureFile;
   TableMdl.insert(ret, NewRow);
   TableMdl.setChecked(ret, (Boolean)Check);
  }
  else{
   NewRow=TableMdl.Mdl.Rows.elementAt(ret);
   Qty=(Double)NewRow[3]+CheckedQuantity; NewRow[3]=Qty;
   Price=(Double)NewRow[5]+CheckedPriceTotal; NewRow[5]=Price;
   NewRow[6]=(double)(Price/Qty);
   TableMdl.changeValue(ret, NewRow);
  }
  TotalPrice.Value=TotalPrice.Value+CheckedPriceTotal;
  
  return ret;
 }
 void addItemIn(long CheckedId, String ItemName, double CheckedQuantity, String ItemStockUnit, double CheckedPriceTotal, String TransItemComment, Object Check,
  Object ItemUpdateStock, Object ItemPictureFile){
  int insertpos;
  
  insertpos=addItem(CheckedId, ItemName, CheckedQuantity, ItemStockUnit, CheckedPriceTotal, TransItemComment, Check, ItemUpdateStock, ItemPictureFile,
   TableMdlIn, QuickIdIn, InPrice);
  refreshTotalCount(TF_InCount, TableMdlIn);
  refreshTotalPrice(TF_InPrice, InPrice);
  
  if(TabbedPane.getSelectedIndex()!=1){TabbedPane.setSelectedIndex(1);}
  Tbl_In.changeSelection(insertpos, 0, false, false);
  onSelectedRowInChanged(true);
 }
 void addItemOut(long CheckedId, String ItemName, double CheckedQuantity, String ItemStockUnit, double CheckedPriceTotal, String TransItemComment, Object Check,
  Object ItemUpdateStock, Object ItemPictureFile){
  int insertpos;
  
  insertpos=addItem(CheckedId, ItemName, CheckedQuantity, ItemStockUnit, CheckedPriceTotal, TransItemComment, Check, ItemUpdateStock, ItemPictureFile,
   TableMdlOut, QuickIdOut, OutPrice);
  refreshTotalCount(TF_OutCount, TableMdlOut);
  refreshTotalPrice(TF_OutPrice, OutPrice);
  
  if(TabbedPane.getSelectedIndex()!=0){TabbedPane.setSelectedIndex(0);}
  Tbl_Out.changeSelection(insertpos, 0, false, false);
  onSelectedRowOutChanged(true);
 }
 void removeItem(int[] rows, OCustomTableModel TableMdl, OQuickListOfLong QuickId, VDouble TotalPrice){
  double PriceTot;
  int temp;
  Object[] Objs;
  
  if(rows.length==0){return;}
  
  if(rows.length!=TableMdl.Mdl.Rows.size()){
   PriceTot=0;
   temp=0;
   do{
    Objs=TableMdl.Mdl.Rows.elementAt(rows[temp]);
    PriceTot=PriceTot+(Double)Objs[5];
    temp=temp+1;
   }while(temp!=rows.length);
   TotalPrice.Value=TotalPrice.Value-PriceTot;
   TableMdl.remove(rows);
   QuickId.removeElementAtIndex(rows);
  }
  else{
   QuickId.removeAll();
   TableMdl.removeAll();
   TotalPrice.Value=0;
  }
 }
 void removeItemIn(int[] rows){
  removeItem(rows, TableMdlIn, QuickIdIn, InPrice);
  refreshTotalCount(TF_InCount, TableMdlIn);
  refreshTotalPrice(TF_InPrice, InPrice);
  onSelectedRowInChanged(true);
 }
 void removeItemOut(int[] rows){
  removeItem(rows, TableMdlOut, QuickIdOut, OutPrice);
  refreshTotalCount(TF_OutCount, TableMdlOut);
  refreshTotalPrice(TF_OutPrice, OutPrice);
  onSelectedRowOutChanged(true);
 }
 void editItems(boolean IsItemIn){
  int[] rows;
  JTable Tbl=(JTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemIn, TableMdlIn, TableMdlOut);
  OEditTransItem Edit=new OEditTransItem();
  F_TransItemModify fm1=IFV.FTransItemModify;
  F_TransItemModifyMulti fm2=IFV.FTransItemModifyMulti;
  Object[] Objs;
  
  rows=Tbl.getSelectedRows();
  if(rows.length==0){return;}
  
  if(rows.length==1){
   Objs=TableMdl.Mdl.Rows.elementAt(rows[0]);
   fm1.wMode=1;
   fm1.wItemId=(Long)Objs[0];
   fm1.wQuantity=(Double)Objs[3];
   fm1.wPriceTotal=(Double)Objs[5];
   fm1.wTransItemComment=PCore.objString(Objs[7], null);
   
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}
   
   Edit.init(
    true, fm1.Qty,
    false, -1,
    true, fm1.PriceTotal,
    true, false, null, fm1.TransItemComment);
  }
  else{
   fm2.wDataCount=rows.length;
   
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    fm2.ChangeQuantity, fm2.Quantity,
    fm2.ChangePriceUnit, fm2.PriceUnit,
    fm2.ChangePriceTotal, fm2.PriceTotal,
    fm2.ChangeTransItemComment, fm2.ChangeTransItemCommentSubString, fm2.TransItemCommentFind, fm2.TransItemComment);
  }
  
  editItems(IsItemIn, rows, Edit);
 }
 void editItems(boolean IsItemIn, int[] Rows, OEditTransItem Edit){
  if(IsItemIn){editItemsIn(Rows, Edit);}
  else{editItemsOut(Rows, Edit);}
 }
 void editItemsIn(int[] Rows, OEditTransItem Edit){
  editItems(Rows, TableMdlIn, InPrice, Edit);
  onSelectedRowInChanged(true);
  refreshTotalPrice(TF_InPrice, InPrice);
 }
 void editItemsOut(int[] Rows, OEditTransItem Edit){
  editItems(Rows, TableMdlOut, OutPrice, Edit);
  onSelectedRowOutChanged(true);
  refreshTotalPrice(TF_OutPrice, OutPrice);
 }
 void editItems(int[] rows, OCustomTableModel TableMdl, VDouble TotalPrice, OEditTransItem Edit){
  double CurrPriceTotal, ChangedPriceTotal;
  Vector<OTableCellUpdater> ChangeValues;
  OTableCellUpdaterByCalculation UpdaterPrice=null;
  
  CurrPriceTotal=(Double)PGUI.sumColumns(TableMdl, PCore.primArr(5), rows)[0];
  
  ChangeValues=new Vector();
  if(Edit.EditQuantity){
   ChangeValues.addElement(new OTableCellUpdaterByObject(3, Edit.EditedQuantity));
  }
  if(Edit.EditPriceTotal){
   ChangeValues.addElement(new OTableCellUpdaterByObject(5, Edit.EditedPriceTotal));
  }
  if(Edit.EditPriceUnit){
   ChangeValues.addElement(new OTableCellUpdaterByObject(6, Edit.EditedPriceUnit));
  }
  if(Edit.EditComment){
   if(!Edit.ReplaceSubComment){
    ChangeValues.addElement(new OTableCellUpdaterByObject(7, PText.getString(Edit.EditedComment, null, true)));
   }
   else{
    ChangeValues.addElement(new OTableCellUpdaterBySubString(7, true, Edit.SubComment, Edit.EditedComment));
   }
  }
  PGUI.changeElements(TableMdl, rows, ChangeValues);

  ChangeValues=new Vector();
  if(Edit.EditComment){
   ChangeValues.addElement(new OTableCellUpdaterByAppTransItemName(2, 1, 7));
  }
  if(Edit.EditQuantity || Edit.EditPriceTotal || Edit.EditPriceUnit){
   if(Edit.EditPriceTotal){
    UpdaterPrice=new OTableCellUpdaterByCalculation(6,
     new OCalculationOperandTableCell(TableMdl, 5, 0, 0, 0, 0, 0, 0),
     new OCalculation(new OCalculationOperandTableCell(TableMdl, 3, 0, 0, 0, 0, 0, 0), CMath.Divide, false, 0));
   }
   else{
    UpdaterPrice=new OTableCellUpdaterByCalculation(5,
     new OCalculationOperandTableCell(TableMdl, 3, 0, 0, 0, 0, 0, 0),
     new OCalculation(new OCalculationOperandTableCell(TableMdl, 6, 0, 0, 0, 0, 0, 0), CMath.Times, false, 0));
   }
   ChangeValues.addElement(UpdaterPrice);
  }
  PGUI.changeElements(TableMdl, rows, ChangeValues);

  ChangedPriceTotal=(Double)PGUI.sumColumns(TableMdl, PCore.primArr(5), rows)[0];
  TotalPrice.Value=TotalPrice.Value-CurrPriceTotal+ChangedPriceTotal;
 }
 
 void refreshTotalCount(JTextField TF_TotalCount, OCustomTableModel TableItemMdl){
  TF_TotalCount.setText(PText.intToString(TableItemMdl.getRowCount())+"  ( "+PText.intToString(TableItemMdl.getCheckedCount())+" )");
 }
 void refreshTotalPrice(JTextField TF_TotalPrice, VDouble TotalPrice){
  TF_TotalPrice.setText(PText.priceToString(TotalPrice.Value));
 }
 
 //
 void clearTransInputs(boolean ForceClear){
  // Trans
  emptyInputDetDynamic(ForceClear);
  emptyInputDetStatic(ForceClear);
  
  // Trans's Item In
  clearItemIn(ForceClear);
  
  // Trans's Item Out
  clearItemOut(ForceClear);
  
  // Add Item
  clearInputItem();
 }
 void emptyInputDetDynamic(boolean ForceClear){
  if(!CB_TransIdExternalKeep.isSelected() || ForceClear){TF_TransIdExternal.setText("");}
  if(!CB_CashInCommentKeep.isSelected() || ForceClear){TF_CashInComment.setText("");}
  if(!CB_CashOutCommentKeep.isSelected() || ForceClear){TF_CashOutComment.setText("");}
  if(!CB_TransSubjectKeep.isSelected() || ForceClear){TransSubjectId=-1; TF_TransSubject.setText("");}
  if(!CB_TransSalesmanKeep.isSelected() || ForceClear){TransSalesmanId=-1; TF_TransSalesman.setText("");}
  if(!CB_TransCreditDaysKeep.isSelected() || ForceClear){TF_TransCreditDays.setText(""); updateValueTransCreditDays(true);}
		if(!CB_RepayPeriodKeep.isSelected() || ForceClear){CB_RepayPeriod.setSelected(false); CB_RepayPeriodActionPerformed(null);}
  if(!CB_TransCommentKeep.isSelected() || ForceClear){TA_TransComment.setText("");}
 }
 void emptyInputDetStatic(boolean ForceClear){
  if(!ForceClear){return;}
  CB_TransImportant.setSelected(false);
  ComboBox_TransType.setSelectedIndex(0); ComboBox_TransType.repaint();
  ComboBox_CashIn.setSelectedIndex(0); ComboBox_CashIn.repaint();
  ComboBox_CashOut.setSelectedIndex(0); ComboBox_CashOut.repaint();
 }
 void fillItemInInfo(int row){
  Object[] objs=TableMdlIn.Mdl.Rows.elementAt(row);
  TF_InInfo.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemInPreview, IFV.Conf.ImageDirItem, objs[9]);
 }
 void clearItemIn(boolean ForceClear){
  if(CB_ItemInKeep.isSelected() && !ForceClear){return;}
  
  QuickIdIn.removeAll();
  TableMdlIn.removeAll(); onSelectedRowInChanged(false);
  refreshTotalCount(TF_InCount, TableMdlIn);
  InPrice.Value=0; refreshTotalPrice(TF_InPrice, InPrice);
 }
 void clearItemInInfo(){
  TF_InInfo.setText("");
  PGUI.fillPanelPictureURL(Pnl_ItemInPreview, IFV.Conf.ImageDirItem, null);
 }
 void fillItemOutInfo(int row){
  Object[] objs=TableMdlOut.Mdl.Rows.elementAt(row);
  TF_OutInfo.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemOutPreview, IFV.Conf.ImageDirItem, objs[9]);
 }
 void clearItemOut(boolean ForceClear){
  if(CB_ItemOutKeep.isSelected() && !ForceClear){return;}
  
  QuickIdOut.removeAll();
  TableMdlOut.removeAll(); onSelectedRowOutChanged(false);
  refreshTotalCount(TF_OutCount, TableMdlOut);
  OutPrice.Value=0; refreshTotalPrice(TF_OutPrice, OutPrice);
 }
 void clearItemOutInfo(){
  TF_OutInfo.setText("");
  PGUI.fillPanelPictureURL(Pnl_ItemOutPreview, IFV.Conf.ImageDirItem, null);
 }
 void fillTransIdAndDateInput(long Id, Date Dt){
  TransId=Id; TF_TransId.setText(PText.separate(String.valueOf(Id), "-", PCore.primArr(4, 2, 2)));
  PGUI.setDateComponent(Dt, TF_TransDateYear, ComboBox_TransDateMonth, ComboBox_TransDateDay);
  updateValueTransDate(true);
 }
 void clearTransIdAndDateInput(){
  TransId=-1; TF_TransId.setText("");
  TF_TransDateYear.setText(""); ComboBox_TransDateMonth.setSelectedIndex(0); ComboBox_TransDateDay.setSelectedIndex(0);
		updateValueTransDate(true);
 }
 void newTransId(){
  Date dt=new Date();
  TransId=PDatabase.addTransactionId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, wIsPreTrans, dt, null, false);
  if(TransId<0){
   if(TransId==-2){
    JOptionPane.showMessageDialog(null, "Gagal memulai "+TransName+" baru :"+
     "\nServer merespon terlalu lama ketika klien menunggu sebuah Id "+TransName+" baru !"+
     "\nSilahkan tekan tombol 'Batal' untuk memulai "+TransName+" baru lagi !");
   }
   else{
    JOptionPane.showMessageDialog(null, "Gagal memulai "+TransName+" baru :"+
     "\nTerjadi kesalahan ketika klien menunggu sebuah Id "+TransName+" baru dari server !"+
     "\nSilahkan tekan tombol 'Batal' untuk memulai "+TransName+" baru lagi !");
   }
   clearTransIdAndDateInput();
   Btn_TransCancel.requestFocusInWindow();
  }
  else{
   TransPendingId=-1;
   fillTransIdAndDateInput(TransId, dt);
   TF_ItemId.requestFocusInWindow();
  }
 }
 void removeCurrentTransId(boolean RemoveInDatabase){
  if(TransId!=-1){
   if(RemoveInDatabase){
    if(PDatabase.removeTransactionId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, wIsPreTrans, TransId, true)!=0){
     JOptionPane.showMessageDialog(null, "Gagal menghapus Id "+TransName+" saat ini !"+
      "\nSilahkan menghapus Id "+TransName+" tersebut secara manual !");
    }
   }
   TransId=-1;
  }
 }
 OValidation checkTransInput(boolean ListItemCheckEmpty){
  OValidation ret=new OValidation(true);
		
  updateValueTransDate(false);
		updateValueTransCreditDays(false);
		TransRepayPeriodStart=null; 	TransRepayPeriodEnd=null;
		if(CB_RepayPeriod.isSelected()){
		 TransRepayPeriodStart=PDate.parseDate(TF_RepayPeriodStart.getText());
			TransRepayPeriodEnd=PDate.parseDate(TF_RepayPeriodEnd.getText());
			if(TransRepayPeriodStart==null || TransRepayPeriodEnd==null){
			 TransRepayPeriodStart=null; 	TransRepayPeriodEnd=null;
			}
		}
		
		if(TransDate==null){ret.addError("\n- Inputan 'Tanggal Transaksi' belum benar.");}
		if(TransCreditDays==-2){ret.addError("\n- Inputan 'Lama Kredit' belum benar.");}
		if(CB_RepayPeriod.isSelected()){
			if(TransRepayPeriodStart==null || TransRepayPeriodEnd==null){
				ret.addError("\n- Inputan Tanggal pada 'Periode Cicil' belum benar.");
			}
			else{
				if(PDate.grading(TransRepayPeriodStart, TransRepayPeriodEnd, Long.MIN_VALUE)==1){ret.addError("\n- Tanggal Awal 'Periode Cicil' harus <= Tanggal Akhir 'Periode Cicil'.");}
			}
		}
		if(PText.checkInput(TA_TransComment.getText(), true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)==false){ret.addError("\n- Inputan 'Komentar' belum benar.");}
  if(PText.checkInput(TF_TransIdExternal.getText(), true, 100, 0, 0, 0, 0)==false){ret.addError("\n- Inputan 'Id-External' belum benar.");}
  if(PText.checkInput(TF_CashInComment.getText(), true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)==false){ret.addError("\n- Inputan 'Keterangan Kas Masuk Tunai' belum benar.");}
  if(PText.checkInput(TF_CashOutComment.getText(), true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)==false){ret.addError("\n- Inputan 'Keterangan Kas Keluar Tunai' belum benar.");}
		if(ListItemCheckEmpty){if(TableMdlIn.getRowCount()==0 && TableMdlOut.getRowCount()==0){ret.addError("\n- Belum ada data 'Barang Masuk' maupun 'Barang Keluar'.");}}
		
		if(!ret.getValid()){return ret;}
		
		if(CB_RepayPeriod.isSelected()){
			if(TransCreditDays==-1){ret.addError("\n- Jika 'Periode Cicil' diisi, maka 'Lama Kredit' tidak boleh kosong.");}
			else{
				if(PDate.grading(TransRepayPeriodEnd, PDate.calculateDateByDay(TransDate, TransCreditDays, 1), Long.MIN_VALUE)!=2){
				 ret.addError("\n- Tanggal Akhir 'Periode Cicil' harus < 'Tanggal Tagih'.");
				}
			}
		}
  
		return ret;
 }
 boolean finishingTrans(){
  boolean ret=false;
  boolean started=false;
  
  int temp, tblcount;
  StringBuilder Str;
  int Until, MaxEach, len;
  boolean first;
  Object[] Objs;
  String TransIdExternal=TF_TransIdExternal.getText();
  String Tb_ItemIn_Temp, Tb_ItemOut_Temp, Tb_PayOut_Temp, Tb_PayIn_Temp;
  
  MaxEach=100;
  
  do{
   try{
    IFV.Stm.execute("start transaction;");
    started=true;
    
    // update trans detail
    IFV.Stm.executeUpdate("call "+DbTable+"EditNotImportant("+TransId+", "+PDatabase.dateToSQLStringFormat(TransDate)+", "+
     PText.getString(PCore.objInteger(ComboMdlTransType.Mdl.Rows.elementAt(ComboBox_TransType.getSelectedIndex())[0], -1), CCore.vNull, -1, false)+", "+
     PText.getString(PCore.objInteger(ComboMdlCashOut.Mdl.Rows.elementAt(ComboBox_CashOut.getSelectedIndex())[0], -1), CCore.vNull, -1, false)+", "+
     PText.getString(PCore.objInteger(ComboMdlCashIn.Mdl.Rows.elementAt(ComboBox_CashIn.getSelectedIndex())[0], -1), CCore.vNull, -1, false)+", "+
     PText.getString(TransSubjectId, CCore.vNull, -1, false)+", "+PText.getString(TransSalesmanId, CCore.vNull, -1, false)+", "+
     PText.getString(TF_TransCreditDays.getText(), CCore.vNull, true)+", "+
					PDatabase.dateToSQLStringFormat(TransRepayPeriodStart)+", "+PDatabase.dateToSQLStringFormat(TransRepayPeriodEnd)+", "+
     PText.getString(CB_TransImportant.isSelected(), CCore.vTrue, CCore.vFalse)+", "+
     PText.getStringWithQuote(PSql.norm(TA_TransComment.getText()), CCore.vNull, '\'', true)+", "+
     PText.getStringWithQuote(PSql.norm(TransIdExternal), CCore.vNull, '\'', true)+", "+
     PText.getStringWithQuote(PSql.norm(TF_CashOutComment.getText()), CCore.vNull, '\'', true)+", "+
     PText.getStringWithQuote(PSql.norm(TF_CashInComment.getText()), CCore.vNull, '\'', true)+");");
    
    //
    Tb_ItemIn_Temp=CSQL.getTableTemp(DbTable+"XItemIn");
    Tb_ItemOut_Temp=CSQL.getTableTemp(DbTable+"XItemOut");
    Tb_PayOut_Temp=CSQL.getTableTemp(DbTable+"XPayment");
    Tb_PayIn_Temp=CSQL.getTableTemp(DbTable+"XPaymentIn");
    
    // empty possible existed data in temporary table
    IFV.Stm.executeUpdate("call "+DbTable+"RemoveTemporary("+TransId+")");
    
    // insert trans's item in
    tblcount=TableMdlIn.getRowCount();
    if(tblcount!=0){
     temp=0;
     do{
      Until=temp+MaxEach;
      if(tblcount<Until){Until=tblcount;}
      len=Until-temp;
      first=true;
      Str=new StringBuilder("insert into "+Tb_ItemIn_Temp+"("+DbTable+", Item, Stock, Price, Comment, Checked) values ");
      do{
       if(first){first=false;}else{Str.append(',');}
       Objs=TableMdlIn.Mdl.Rows.elementAt(temp);
       Str.append("("+TransId+","+(Long)Objs[0]+","+PText.doubleToString((Double)Objs[3], false)+","+PText.doubleToString((Double)Objs[5], false)+","+
        PDatabase.getSQLString(PText.getString(PCore.objString(Objs[7], null), null, true), CCore.TypeString, CCore.vNull, false)+","+
        PText.getString(TableMdlIn.getChecked(temp), CCore.vTrue, CCore.vFalse)+")");
       temp=temp+1;
      }while(temp!=Until);
      Str.append(';');
      IFV.Stm.executeUpdate(Str.toString());
     }while(temp!=tblcount);
     if(temp==-1){break;}
    }
    
    // insert trans's item out
    tblcount=TableMdlOut.getRowCount();
    if(tblcount!=0){
     temp=0;
     do{
      Until=temp+MaxEach;
      if(tblcount<Until){Until=tblcount;}
      len=Until-temp;
      first=true;
      Str=new StringBuilder("insert into "+Tb_ItemOut_Temp+"("+DbTable+", Item, Stock, Price, Comment, Checked) values ");
      do{
       if(first){first=false;}else{Str.append(',');}
       Objs=TableMdlOut.Mdl.Rows.elementAt(temp);
       Str.append("("+TransId+","+(Long)Objs[0]+","+PText.doubleToString((Double)Objs[3], false)+","+PText.doubleToString((Double)Objs[5], false)+","+
        PDatabase.getSQLString(PText.getString(PCore.objString(Objs[7], null), null, true), CCore.TypeString, CCore.vNull, false)+","+
        PText.getString(TableMdlOut.getChecked(temp), CCore.vTrue, CCore.vFalse)+")");
       temp=temp+1;
      }while(temp!=Until);
      Str.append(';');
      IFV.Stm.executeUpdate(Str.toString());
     }while(temp!=tblcount);
     if(temp==-1){break;}
    }
    
    // inserting data into trans's table list & finalizing trans
    IFV.Stm.executeUpdate("call "+DbTable+"Insert("+TransId+")");
    
    // empty inserted data in temporary table
    IFV.Stm.executeUpdate("call "+DbTable+"RemoveTemporary("+TransId+")");
    
    if(TransPendingId!=-1){
     if(PDatabase.removeTransPendingId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbPendLock, 10, wIsPreTrans, TransPendingId,
      false, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, true)[0]!=0){break;}
    }
    
    IFV.Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{IFV.Stm.execute("rollback;");}catch(Exception E_){}
  }
  
  if(ret){addLastTrans(TransId, TransIdExternal);}
  
  return ret;
 }
 boolean pendingTrans(){
  boolean ret=false;
  boolean started=false;
  
  int temp, tblcount;
  StringBuilder Strb;
  int Until, MaxEach, len;
  boolean first;
  
  long NewPendingId;
  OInfoTransPending Data;
  Object[] Objs;
  
  MaxEach=100;
  
  do{
   try{
    IFV.Stm.execute("start transaction;");
    started=true;
    
    // insert pending id
    Data=new OInfoTransPending();
    Data.TransId=TransId;
    Data.Important=CB_TransImportant.isSelected();
    Data.InfoIdExternal=PText.getString(TF_TransIdExternal.getText(), null, true);
    Data.Dt=TransDate;
    temp=ComboBox_TransType.getSelectedIndex();
    if(temp==0){Data.TypeId=-1;}else{Data.TypeId=(Integer)ComboMdlTransType.Mdl.Rows.elementAt(temp)[0];}
    temp=ComboBox_CashIn.getSelectedIndex();
    if(temp==0){Data.CashInId=-1;}else{Data.CashInId=(Integer)ComboMdlCashIn.Mdl.Rows.elementAt(temp)[0];}
    temp=ComboBox_CashOut.getSelectedIndex();
    if(temp==0){Data.CashOutId=-1;}else{Data.CashOutId=(Integer)ComboMdlCashOut.Mdl.Rows.elementAt(temp)[0];}
    Data.SubjectId=TransSubjectId;
    Data.SalesmanId=TransSalesmanId;
    Data.CreditDays=TransCreditDays;
				Data.RepaymentPeriodStart=TransRepayPeriodStart;
				Data.RepaymentPeriodEnd=TransRepayPeriodEnd;
    Data.Comment=PText.getString(TA_TransComment.getText(), null, true);
    Data.CashOutComment=PText.getString(TF_CashOutComment.getText(), null, true);
    Data.CashInComment=PText.getString(TF_CashInComment.getText(), null, true);
    
    if(TransPendingId!=-1){
     if(PDatabase.removeTransPendingId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbPendLock, 10, wIsPreTrans, TransPendingId,
      false, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, true)[0]!=0){break;}
    }
    NewPendingId=PDatabase.addTransPendingId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbPendLock, 10, wIsPreTrans, Data);
    if(NewPendingId<0){break;}
    
    // insert pending's item in
    tblcount=TableMdlIn.getRowCount();
    if(tblcount!=0){
     temp=0;
     do{
      Until=temp+MaxEach;
      if(tblcount<Until){Until=tblcount;}
      len=Until-temp;
      first=true;
      Strb=new StringBuilder("insert into "+DbTable+"PendXItemIn("+DbTable+"Pend, Item, Stock, Price, Comment, Checked) values ");
      do{
       if(first){first=false;}else{Strb.append(',');}
       Objs=TableMdlIn.Mdl.Rows.elementAt(temp);
       Strb.append("("+NewPendingId+","+(Long)Objs[0]+","+PText.doubleToString((Double)Objs[3], false)+","+PText.doubleToString((Double)Objs[5], false)+","+
        PDatabase.getSQLString(PText.getString(PCore.objString(Objs[7], null), null, true), CCore.TypeString, CCore.vNull, false)+","+
        PText.getString(TableMdlIn.getChecked(temp), CCore.vTrue, CCore.vFalse)+")");
       temp=temp+1;
      }while(temp!=Until);
      Strb.append(';');
      IFV.Stm.executeUpdate(Strb.toString());
     }while(temp!=tblcount);
     if(temp==-1){break;}
    }
    
    // insert pending's item out
    tblcount=TableMdlOut.getRowCount();
    if(tblcount!=0){
     temp=0;
     do{
      Until=temp+MaxEach;
      if(tblcount<Until){Until=tblcount;}
      len=Until-temp;
      first=true;
      Strb=new StringBuilder("insert into "+DbTable+"PendXItemOut("+DbTable+"Pend, Item, Stock, Price, Comment, Checked) values ");
      do{
       if(first){first=false;}else{Strb.append(',');}
       Objs=TableMdlOut.Mdl.Rows.elementAt(temp);
       Strb.append("("+NewPendingId+","+(Long)Objs[0]+","+PText.doubleToString((Double)Objs[3], false)+","+PText.doubleToString((Double)Objs[5], false)+","+
        PDatabase.getSQLString(PText.getString(PCore.objString(Objs[7], null), null, true), CCore.TypeString, CCore.vNull, false)+","+
        PText.getString(TableMdlOut.getChecked(temp), CCore.vTrue, CCore.vFalse)+")");
       temp=temp+1;
      }while(temp!=Until);
      Strb.append(';');
      IFV.Stm.executeUpdate(Strb.toString());
     }while(temp!=tblcount);
     if(temp==-1){break;}
    }
    
    IFV.Stm.execute("commit;");
    
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{IFV.Stm.execute("rollback;");}catch(Exception E_){}
  }
  return ret;
 }
 void findItemIn(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str=TF_FindItemIn.getText();
  if(str.length()!=0){
   if(TableMdlIn.Mdl.Rows.size()!=0){
    Column=0;
    ColumnType=3;
    if(RB_FindItemInName.isSelected()==true){
     Column=2;
     ColumnType=1;
    }
    Selected=Tbl_In.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlIn, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_In.changeSelection(FindIndex, 0, false, false);
      onSelectedRowInChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang masuk !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang masuk dalam keadaan kosong !");
   }
  }
 }
 void findItemOut(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str=TF_FindItemOut.getText();
  if(str.length()!=0){
   if(TableMdlOut.Mdl.Rows.size()!=0){
    Column=0;
    ColumnType=3;
    if(RB_FindItemOutName.isSelected()==true){
     Column=2;
     ColumnType=1;
    }
    Selected=Tbl_Out.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlOut, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_Out.changeSelection(FindIndex, 0, false, false);
      onSelectedRowOutChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang keluar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang keluar dalam keadaan kosong !");
   }
  }
 }
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 public boolean signItemsWithMissmatch(int Resolution, Vector<Object[]> TransItems, int IndexOfItemId, int[] ChangeIndex){
  boolean ret=false;
  boolean UseExternalStm;
  Connection AdminCon;
  Statement AdminStm;
  
  AdminCon=null;
  AdminStm=IFV.Stm; UseExternalStm=false;
  do{
   try{
    if(Resolution==1){
     AdminCon=IFV.FLogin.loginTemporary("Login Sementara Sbg User Lain Utk Menandai 'Mismatch Stok'");
     if(AdminCon==null){break;}
     AdminStm=AdminCon.createStatement(); UseExternalStm=true;
     if(!IFV.useDb(AdminStm, IFV.CurrentDatabase)){break;}
    }
    if(!PMyShop.assignItemsWithMismatchStock(AdminStm, TransItems, IndexOfItemId, ChangeIndex)){
     JOptionPane.showMessageDialog(null, "Tidak dapat menyelesaikan transaksi : gagal menandai\n"+
      "'Mismatch Stok' Pd Brg Yg Bersangkutan !");
     break;
    }
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);

  if(AdminStm!=null && UseExternalStm){try{AdminStm.close();}catch(Exception E){}}
  if(AdminCon!=null){try{AdminCon.close();}catch(Exception E){}}
  
  return ret;
 }
	
	void updateValueTransDate(boolean AlsoUpdateCreditDaysInfo){
		TransDate=PGUI.valueOfDateComponent(TF_TransDateYear, ComboBox_TransDateMonth, ComboBox_TransDateDay);
		if(AlsoUpdateCreditDaysInfo){refreshCreditDaysInfo();}
	}
	void updateValueTransCreditDays(boolean AlsoUpdateCreditDaysInfo){
		String str=TF_TransCreditDays.getText();
		do{
			if(!PText.checkInput(str, true, CCore.CharsCount_Int(), 2, 7, 0, 0)){TransCreditDays=-2; break;}
			if(str.length()==0){TransCreditDays=-1; break;}
			TransCreditDays=Integer.parseInt(str);
		}while(false);
		if(AlsoUpdateCreditDaysInfo){refreshCreditDaysInfo();}
	}
	void refreshCreditDaysInfo(){
		if(TransDate==null || TransCreditDays<=0){clearCreditDaysInfo(); return;}
		TF_CreditDaysInfo.setText(PText.dateToString(PDate.calculateDateByDay(TransDate, TransCreditDays, 1), 2));
	}
	void clearCreditDaysInfo(){TF_CreditDaysInfo.setText("");}
	void enableInputRepayPeriod(boolean Enable){PGUI.enableInput(Enable, TF_RepayPeriodStart, TF_RepayPeriodEnd, true);}
 
 void clearLastTrans(){
  LastTransId=-1;
  LastTransIdExternal=null;
 }
 void addLastTrans(long AddTransId, String AddTransIdExternal){
  LastTransId=AddTransId;
  LastTransIdExternal=AddTransIdExternal;
 }
 void printReceipt(long PrintTransId, boolean ShowPrintDialog){
  boolean bool;
  Book bk;
  int temp;
  PrintService Printer;
  OPaper Paper;
  boolean UseIdExternal=RB_TransIdExternal.isSelected();
  F_PrintTransReceipt fm=IFV.FPrintTransReceipt;
  
  temp=ComboBox_ReceiptPrinter.getSelectedIndex();
  if(temp==-1){JOptionPane.showMessageDialog(null, "Tidak dapat mencetak : tidak ada printer yang terpilih !"); return;}
  Printer=(PrintService)ComboMdlReceiptPrinter.Mdl.Rows.elementAt(temp)[0];
  Paper=getPaper();
  
  if(ShowPrintDialog){
   fm.wUseIdExternal=PCore.subtBool_Int(UseIdExternal, 2, 1);
   
   if(fm.showForm()==false){return;}
   if(fm.DialogResult!=1){return;}
   UseIdExternal=fm.UseIdExternal;
   
   IFV.FPrintDialog.wPaperType=Paper;
   IFV.FPrintDialog.wPrinter=Printer;
   IFV.FPrintDialog.wPrintSettingMode=3;
   IFV.FPrintDialog.wEnableOption=false;
   
   if(IFV.FPrintDialog.showForm()==false){return;}
   if(IFV.FPrintDialog.DialogResult!=1){return;}
   Paper=IFV.FPrintDialog.PaperType;
   Printer=IFV.FPrintDialog.Printer;
  }
  
  IFV.PrintGenReceipt.setPrintVariables(Paper, IFV.FontPrintReceipt, IFV.FontPrintReceiptThermal, IFV.Stm,
   PrintTransId, wIsPreTrans, true, true, UseIdExternal);
  bk=IFV.PrintGenReceipt.generateBook(null);
  if(bk==null){JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !"); return;}
  
  if(ShowPrintDialog){
   if(IFV.FPrintDialog.ChoosePage){
    IFV.FPrintPage.wBook=bk;
    
    if(IFV.FPrintPage.showForm()==false){return;}
    if(IFV.FPrintPage.DialogResult!=1){return;}
    if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
   }
  }
  
  bool=true;
  do{
   if(PPrint.print(bk, Printer, "Nota"+TransName+"_"+PrintTransId+"_"+PText.dateToString(new Date(), 101), false)){break;}
   if(JOptionPane.showConfirmDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !\nIngin mencoba ulang?",
    "Konfirmasi Pencetakan Ulang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){break;}
  }while(bool);
 }
 
 String getQueryOfLoadItems(String CoreTransItemsTable){
  // CoreTransItemsTable must contains fields 'TransItem', 'TransItemQty', 'TransItemPriceTotal', 'TransItemPriceUnit', 'TransItemComment', 'TransItemChecked'
  return
   "select tb3.TransItem, ItemName, ItemNm, "+
   "TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, "+
   "UpdateStockOnTransaction, Min(ItemXPicture.FileName), TransItemChecked from "+
    "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
     "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", Item.StockUnit as 'ItemStockUnit', Item.UpdateStockOnTransaction from "+
      "("+CoreTransItemsTable+") as tb1 "+
     "left join Item on tb1.TransItem=Item.Id) as tb2 "+
    "left join StockUnit on tb2.ItemStockUnit=StockUnit.Id) as tb3 "+
   "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem "+
   "order by tb3.ItemName asc";
 }
 String getQueryOfLoadItemsFromTransPending(long PendId, boolean IsItemIn){
  return
   getQueryOfLoadItems("select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' from "+
    DbTable+"PendXItem"+PText.getString(IsItemIn, "In", "Out")+" where "+DbTable+"Pend="+PendId);
 }
 
 void addCheck(boolean IsItemIn, boolean IsAdd){
  JTable Tbl=(JTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  addCheck(IsItemIn, Tbl.getSelectedRows(), IsAdd);
 }
 void addCheck(boolean IsItemIn, int[] Rows, boolean IsAdd){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemIn, TableMdlIn, TableMdlOut);
  JTextField TF_TotalCheckedCount=(JTextField)PCore.subtituteBool(IsItemIn, TF_InCount, TF_OutCount);
  
  if(Rows.length==0){return;}
  
  TableMdl.setChecked(Rows, IsAdd);
  refreshTotalCount(TF_TotalCheckedCount, TableMdl);
 }
 
 // Input Item Methods
  // Item
 void inputItem(){
  if(!changeItemMetadata()){return;}
  afterChangeItemMetadata();
 }
 boolean changeItemMetadata(){
  boolean ret=false;
  OInfoItem InfoItem;
  
  do{
   // Parse TF_ItemId
   try{I_CheckedId=Long.parseLong(TF_ItemId.getText());}catch(Exception E){break;}
   
   // Check if Item is exist in database
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId, false); if(InfoItem==null){break;}
   
   // init input-item's non-gui variables
   I_ItemInfo=InfoItem;
   changeItemQuantityPrice();
   
   ret=true;
  }while(false);
  
  if(!ret){I_CheckedId=-1; clearItem();}
  
  RecheckId=false;
  
  return ret;
 }
 void afterChangeItemMetadata(){
  // init input-item's gui variables
  setIQty(I_Qty, false);
  setIPriceUnit(I_PriceUnit, false);
  setIPriceTotal(I_PriceTotal, false);
  
  fillInputInfoItem();
  fillInputInfoPrice();
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
  I_PriceUnit=getPriceUnit(false, 0);
  I_PriceTotal=I_Qty*I_PriceUnit;
 }
 void fillInputInfoItem(){
  if(I_CheckedId==-1){clearInputInfoItem(); return;}
  
  TA_ItemName.setText(I_ItemInfo.Name);
  TF_ItemStock.setText(PText.priceToString(I_ItemInfo.Stock)+PText.getString(I_ItemInfo.StockUnit, -1, " "+I_ItemInfo.StockUnitName, ""));
  CB_ItemUpStock.setSelected(I_ItemInfo.UpdateStock);
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  PGUI.clearText(TA_ItemName, TF_ItemStock);
  CB_ItemUpStock.setSelected(false);
  
  InputInfoClearedItem=true;
 }
 void clearItem(){
  clearInputInfoItem();
  
  clearInputInfoPrice();
 }
 void focusItem(){
  PGUI.requestFocusInWindow(TF_ItemId);
 }
 void fillTransItemComment(String TransItemComment){TF_TransItemComment.setText(PText.getString(TransItemComment, "", false));}
 void clearTransItemComment(){TF_TransItemComment.setText("");}
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, "");}}
 }
 void inputQuantity(){
  I_Qty=PText.parseDouble(TF_Quantity.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}
  
  if(I_Qty<=0){return;}
  
  if(I_PriceUnit>=0){setIPriceTotal(I_PriceUnit*I_Qty, false);}
 }
 void focusQty(){
  PGUI.requestFocusInWindow(TF_Quantity);
 }
  // Price
 void setIPriceUnit(double Value, boolean ClearInvalidValue){
  I_PriceUnit=Value;
  
  if(I_PriceUnit>=0){PGUI.changeDocument(EnableDocumentListener, TF_PriceUnit, PText.doubleToString(I_PriceUnit, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_PriceUnit, "");}}
 }
 void setIPriceTotal(double Value, boolean ClearInvalidValue){
  I_PriceTotal=Value;
  
  if(I_PriceTotal>=0){PGUI.changeDocument(EnableDocumentListener, TF_PriceTotal, PText.doubleToString(I_PriceTotal, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_PriceTotal, "");}}
 }
 void fillInputInfoPrice(){
  String str=null;
  double PriceUnit;
  
  if(I_CheckedId==-1){clearInputInfoPrice(); return;}
  
  PriceUnit=getPriceUnit(false, 0);
  
  switch(CmB_Price.getSelectedIndex()){
   case 1 :
    if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){
     str=PText.priceToString(PriceUnit)+
      PText.getString(!PText.isEmptyString(I_ItemInfo.BuyPriceComment, true, true), "\n{ "+I_ItemInfo.BuyPriceComment+" }", "");
    }
    break;
   case 2 :
    str=PText.priceToString(PriceUnit)+
      PText.getString(!PText.isEmptyString(I_ItemInfo.SellPriceComment, true, true), "\n{ "+I_ItemInfo.SellPriceComment+" }", "");
    break;
  }
  
  TA_ItemPriceComment.setText(PText.getString(str, "", false));
  
  InputInfoClearedPrice=false;
 }
 void clearInputInfoPrice(){
  if(InputInfoClearedPrice){return;}
  
  PGUI.clearText(TA_ItemPriceComment);
  
  InputInfoClearedPrice=true;
 }
 double getPriceUnit(boolean KeepPresentUSPriceUnit, double PresentUSPriceUnit){
  // KeepPresentUSPriceUnit = keep present unit standard's price unit
  double ret=0;
  
  if(I_CheckedId==-1){return ret;}

  switch(CmB_Price.getSelectedIndex()){
   case 1 : 
    if(KeepPresentUSPriceUnit && PresentUSPriceUnit>0){ret=PresentUSPriceUnit;}
    else{if(IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice){ret=I_ItemInfo.BuyPriceEstimation;}}
    break;
   case 2 : ret=I_ItemInfo.SellPrice; break;
  }
  
  return ret;
 }
 void inputPriceUnit(){
  I_PriceUnit=PText.parseDouble(TF_PriceUnit.getText(), -1D, -1D); if(I_PriceUnit<0){I_PriceUnit=-1;}

  if(I_PriceUnit<0){return;}
  
  if(I_Qty>0){setIPriceTotal(I_Qty*I_PriceUnit, false);}
 }
 void inputPriceTotal(){
  I_PriceTotal=PText.parseDouble(TF_PriceTotal.getText(), -1D, -1D); if(I_PriceTotal<0){I_PriceTotal=-1;}

  if(I_PriceTotal<0){return;}
  
  if(I_Qty>0){setIPriceUnit(I_PriceTotal/I_Qty, false);}
 }
 void focusPrice(){
  if(CB_Price.isSelected()){
   PGUI.requestFocusInWindow((Component)PCore.subtituteBool(RB_PriceUnit.isSelected(), TF_PriceUnit, TF_PriceTotal));
  }
 }
  // Others
 void fillInputVariablesIntoRealVariables(){
  CheckedId=I_CheckedId;
  ItemInfo=I_ItemInfo;
  
  Qty=I_Qty;
  PriceTotal=I_PriceTotal;
  PriceUnit=PriceTotal/Qty;
  
  TransItemComment=PText.getString(I_TransItemComment, null, true);
 }
 void clearInputItem(){
  EnableDocumentListener.Value=false;
  
  TF_ItemId.setText(""); I_CheckedId=-1; RecheckId=false; clearItem();
  setIQty(-1, true);
  setIPriceUnit(-1, true);
  setIPriceTotal(-1, true);
  clearTransItemComment();
  
  EnableDocumentListener.Value=true;
 }
 void changeDocument(JTextField TF, String Str){
  EnableDocumentListener.Value=false;
  TF.setText(Str);
  EnableDocumentListener.Value=true;
 }
 void focus(JTextField TF){
  TF.requestFocusInWindow();
 }
 void enablePriceUnit(boolean Enable){
  TF_PriceUnit.setEditable(Enable);
  if(Enable==true){
   if(TF_PriceUnit.isFocusOwner()){TF_PriceUnit.setBackground(CGUI.Color_TextBox_FocusOn);}
   else{TF_PriceUnit.setBackground(CGUI.Color_TextBox_FocusOff);}
  }
  else{TF_PriceUnit.setBackground(CGUI.Color_TextBox_Uneditable);}
 }
 void enablePriceTotal(boolean Enable){
  TF_PriceTotal.setEditable(Enable);
  if(Enable==true){
   if(TF_PriceTotal.isFocusOwner()){TF_PriceTotal.setBackground(CGUI.Color_TextBox_FocusOn);}
   else{TF_PriceTotal.setBackground(CGUI.Color_TextBox_FocusOff);}
  }
  else{TF_PriceTotal.setBackground(CGUI.Color_TextBox_Uneditable);}
 }
 void enableEditPrice(boolean Enable){
  RB_PriceUnit.setEnabled(Enable);
  RB_PriceTotal.setEnabled(Enable);
  if(Enable){
   if(RB_PriceUnit.isSelected()){enablePriceUnit(true);}
   else{enablePriceTotal(true);}
  }
  else{
   enablePriceUnit(false);
   enablePriceTotal(false);
  }
 }
 void switchInputPrice(){
  boolean PriceEditable=CB_Price.isSelected();
  boolean IsInputPriceUnit=RB_PriceUnit.isSelected();
  
  if(!PriceEditable){return;}
  enablePriceUnit(IsInputPriceUnit);
  enablePriceTotal(!IsInputPriceUnit);
 }
 
 //
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIAddTrans, IFV.PrivGUIAddPreTrans));
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Price = new javax.swing.ButtonGroup();
  RG_AddItem = new javax.swing.ButtonGroup();
  RG_FindItemOut = new javax.swing.ButtonGroup();
  RG_FindItemIn = new javax.swing.ButtonGroup();
  RG_MainId = new javax.swing.ButtonGroup();
  jLabel7 = new javax.swing.JLabel();
  jPanel5 = new javax.swing.JPanel();
  jPanel10 = new javax.swing.JPanel();
  TF_TransId = new javax.swing.JTextField();
  CB_TransImportant = new javax.swing.JCheckBox();
  Btn_TransPendingLoad = new javax.swing.JButton();
  RB_TransId = new javax.swing.JRadioButton();
  TF_TransIdExternal = new javax.swing.JTextField();
  Lbl_TransIdExternalHelp = new javax.swing.JLabel();
  RB_TransIdExternal = new javax.swing.JRadioButton();
  ComboBox_TransDateDay = new javax.swing.JComboBox();
  ComboBox_TransDateMonth = new javax.swing.JComboBox();
  TF_TransDateYear = new javax.swing.JTextField();
  Lbl_TransDate = new javax.swing.JLabel();
  TF_CreditDaysInfo = new javax.swing.JTextField();
  Lbl_TransCreditDaysHelp = new javax.swing.JLabel();
  TF_TransCreditDays = new javax.swing.JTextField();
  Lbl_TransCreditDays = new javax.swing.JLabel();
  TF_RepayPeriodEnd = new javax.swing.JTextField();
  Lbl_RepayPeriodHelp = new javax.swing.JLabel();
  jLabel1 = new javax.swing.JLabel();
  TF_RepayPeriodStart = new javax.swing.JTextField();
  ComboBox_TransType = new javax.swing.JComboBox();
  Lbl_TransType = new javax.swing.JLabel();
  jSeparator4 = new javax.swing.JSeparator();
  jSeparator5 = new javax.swing.JSeparator();
  jSeparator6 = new javax.swing.JSeparator();
  jSeparator7 = new javax.swing.JSeparator();
  ComboBox_CashIn = new javax.swing.JComboBox<>();
  Lbl_CashIn = new javax.swing.JLabel();
  TF_CashInComment = new javax.swing.JTextField();
  Lbl_CashInCommentHelp = new javax.swing.JLabel();
  ComboBox_CashOut = new javax.swing.JComboBox<>();
  Lbl_CashOut = new javax.swing.JLabel();
  TF_CashOutComment = new javax.swing.JTextField();
  Lbl_CashOutCommentHelp = new javax.swing.JLabel();
  TF_TransSubject = new javax.swing.JTextField();
  Btn_ClearChoosedSubject = new javax.swing.JButton();
  Btn_ChooseSubject = new javax.swing.JButton();
  Btn_ClearChoosedSalesman = new javax.swing.JButton();
  Btn_ChooseSalesman = new javax.swing.JButton();
  jSeparator8 = new javax.swing.JSeparator();
  jSeparator9 = new javax.swing.JSeparator();
  CB_TransSubjectKeep = new javax.swing.JCheckBox();
  TF_TransSalesman = new javax.swing.JTextField();
  CB_TransSalesmanKeep = new javax.swing.JCheckBox();
  Lbl_TransSubject = new javax.swing.JLabel();
  Lbl_TransSalesman = new javax.swing.JLabel();
  CB_CashOutCommentKeep = new javax.swing.JCheckBox();
  Lbl_RepayPeriod = new javax.swing.JLabel();
  CB_RepayPeriod = new javax.swing.JCheckBox();
  CB_CashInCommentKeep = new javax.swing.JCheckBox();
  CB_TransIdExternalKeep = new javax.swing.JCheckBox();
  CB_TransCreditDaysKeep = new javax.swing.JCheckBox();
  CB_RepayPeriodKeep = new javax.swing.JCheckBox();
  jPanel6 = new javax.swing.JPanel();
  Panel_AddItem = new javax.swing.JPanel();
  Btn_AddItem = new javax.swing.JButton();
  RB_AddItemIn = new javax.swing.JRadioButton();
  RB_AddItemOut = new javax.swing.JRadioButton();
  jLabel8 = new javax.swing.JLabel();
  Panel_AddItemDet = new javax.swing.JPanel();
  TF_ItemId = new javax.swing.JTextField();
  Btn_ChooseItem = new javax.swing.JButton();
  Lbl_ItemId = new javax.swing.JLabel();
  CB_ItemIdEnterAutoAdd = new javax.swing.JCheckBox();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_ItemPriceComment = new javax.swing.JTextArea();
  TF_Quantity = new javax.swing.JTextField();
  Lbl_Quantity = new javax.swing.JLabel();
  TF_PriceUnit = new javax.swing.JTextField();
  RB_PriceUnit = new javax.swing.JRadioButton();
  TF_PriceTotal = new javax.swing.JTextField();
  RB_PriceTotal = new javax.swing.JRadioButton();
  CB_Price = new javax.swing.JCheckBox();
  CmB_Price = new javax.swing.JComboBox<>();
  CB_ItemUpStock = new javax.swing.JCheckBox();
  TF_ItemStock = new javax.swing.JTextField();
  TF_TransItemComment = new javax.swing.JTextField();
  jPanel2 = new javax.swing.JPanel();
  CB_Receipt = new javax.swing.JCheckBox();
  ComboBox_ReceiptPaper = new javax.swing.JComboBox<>();
  ComboBox_ReceiptPrinter = new javax.swing.JComboBox<>();
  jPanel7 = new javax.swing.JPanel();
  jPanel13 = new javax.swing.JPanel();
  jPanel12 = new javax.swing.JPanel();
  TF_InPrice = new javax.swing.JTextField();
  TF_InCount = new javax.swing.JTextField();
  jLabel2 = new javax.swing.JLabel();
  TF_OutPrice = new javax.swing.JTextField();
  TF_OutCount = new javax.swing.JTextField();
  jLabel5 = new javax.swing.JLabel();
  jPanel1 = new javax.swing.JPanel();
  Btn_TransPending = new javax.swing.JButton();
  Btn_TransCancel = new javax.swing.JButton();
  Btn_TransFinish = new javax.swing.JButton();
  Btn_ReprintLastTrans = new javax.swing.JButton();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_ItemOut = new javax.swing.JPanel();
  Btn_OutEdit = new javax.swing.JButton();
  Btn_OutRemove = new javax.swing.JButton();
  RB_FindItemOutId = new javax.swing.JRadioButton();
  RB_FindItemOutName = new javax.swing.JRadioButton();
  Btn_FindItemOutNext = new javax.swing.JButton();
  Btn_FindItemOutBef = new javax.swing.JButton();
  TF_FindItemOut = new javax.swing.JTextField();
  jScrollPane6 = new javax.swing.JScrollPane();
  TF_OutInfo = new javax.swing.JTextArea();
  Pnl_ItemOutPreview = new XImgBoxURL();
  Btn_OutMove = new javax.swing.JButton();
  Btn_OutCheckAdd = new javax.swing.JButton();
  Btn_OutCheckRemove = new javax.swing.JButton();
  jLabel3 = new javax.swing.JLabel();
  jScrollPane8 = new javax.swing.JScrollPane();
  Tbl_Out = new XTable();
  CB_ItemOutKeep = new javax.swing.JCheckBox();
  Panel_ItemIn = new javax.swing.JPanel();
  Btn_InEdit = new javax.swing.JButton();
  Btn_InRemove = new javax.swing.JButton();
  TF_FindItemIn = new javax.swing.JTextField();
  Btn_FindItemInBef = new javax.swing.JButton();
  Btn_FindItemInNext = new javax.swing.JButton();
  RB_FindItemInId = new javax.swing.JRadioButton();
  RB_FindItemInName = new javax.swing.JRadioButton();
  jScrollPane7 = new javax.swing.JScrollPane();
  TF_InInfo = new javax.swing.JTextArea();
  Pnl_ItemInPreview = new XImgBoxURL();
  Btn_InMove = new javax.swing.JButton();
  Btn_InCheckRemove = new javax.swing.JButton();
  Btn_InCheckAdd = new javax.swing.JButton();
  jLabel4 = new javax.swing.JLabel();
  jScrollPane3 = new javax.swing.JScrollPane();
  Tbl_In = new XTable();
  CB_ItemInKeep = new javax.swing.JCheckBox();
  Pnl_TransAdditional = new javax.swing.JPanel();
  Lbl_TransComment = new javax.swing.JLabel();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_TransComment = new javax.swing.JTextArea();
  CB_TransCommentKeep = new javax.swing.JCheckBox();
  jSeparator2 = new javax.swing.JSeparator();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel5.setBackground(new java.awt.Color(230, 229, 216));
  jPanel5.setOpaque(false);

  jPanel10.setBackground(new java.awt.Color(221, 219, 192));

  TF_TransId.setEditable(false);
  TF_TransId.setBackground(new java.awt.Color(204, 255, 204));
  TF_TransId.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_TransId.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TransId.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransId.setRequestFocusEnabled(false);

  CB_TransImportant.setText("Pent.");
  CB_TransImportant.setToolTipText("Centang utk menandakan transaksi ini penting");
  CB_TransImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransImportant.setOpaque(false);
  CB_TransImportant.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransImportantKeyPressed(evt);
   }
  });

  Btn_TransPendingLoad.setText("...");
  Btn_TransPendingLoad.setToolTipText("Buka transaksi / pra-transaksi yg ter-pending");
  Btn_TransPendingLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransPendingLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransPendingLoadActionPerformed(evt);
   }
  });
  Btn_TransPendingLoad.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TransPendingLoadKeyPressed(evt);
   }
  });

  RG_MainId.add(RB_TransId);
  RB_TransId.setText("Id");
  RB_TransId.setToolTipText("Pilih Id-Internal sebagai Id yg dicetak dlm nota");
  RB_TransId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_TransId.setOpaque(false);
  RB_TransId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_TransIdKeyPressed(evt);
   }
  });

  TF_TransIdExternal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TransIdExternal.setToolTipText("Id-External");
  TF_TransIdExternal.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransIdExternal.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_TransIdExternalFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_TransIdExternalFocusLost(evt);
   }
  });
  TF_TransIdExternal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransIdExternalKeyPressed(evt);
   }
  });

  Lbl_TransIdExternalHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_TransIdExternalHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_TransIdExternalHelp.setText("(?)");
  Lbl_TransIdExternalHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_TransIdExternalHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_TransIdExternalHelpMouseClicked(evt);
   }
  });

  RG_MainId.add(RB_TransIdExternal);
  RB_TransIdExternal.setText("{Ext}");
  RB_TransIdExternal.setToolTipText("Id-External (pilih sebagai Id yg dicetak dlm nota)");
  RB_TransIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_TransIdExternal.setOpaque(false);
  RB_TransIdExternal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_TransIdExternalKeyPressed(evt);
   }
  });

  ComboBox_TransDateDay.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_TransDateDay.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  ComboBox_TransDateDay.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_TransDateDay.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    ComboBox_TransDateDayActionPerformed(evt);
   }
  });
  ComboBox_TransDateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_TransDateDayKeyPressed(evt);
   }
  });

  ComboBox_TransDateMonth.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_TransDateMonth.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  ComboBox_TransDateMonth.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  ComboBox_TransDateMonth.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    ComboBox_TransDateMonthActionPerformed(evt);
   }
  });
  ComboBox_TransDateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_TransDateMonthKeyPressed(evt);
   }
  });

  TF_TransDateYear.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TransDateYear.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransDateYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_TransDateYearFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_TransDateYearFocusLost(evt);
   }
  });
  TF_TransDateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransDateYearKeyPressed(evt);
   }
  });

  Lbl_TransDate.setText("Tanggal");
  Lbl_TransDate.setRequestFocusEnabled(false);

  TF_CreditDaysInfo.setEditable(false);
  TF_CreditDaysInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_CreditDaysInfo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CreditDaysInfo.setToolTipText("Tanggal Tagih");
  TF_CreditDaysInfo.setMargin(new java.awt.Insets(0, 2, 0, 2));

  Lbl_TransCreditDaysHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_TransCreditDaysHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_TransCreditDaysHelp.setText("(?)");
  Lbl_TransCreditDaysHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_TransCreditDaysHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_TransCreditDaysHelpMouseClicked(evt);
   }
  });

  TF_TransCreditDays.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TransCreditDays.setToolTipText("Lama Kredit (dalam hari, kosongkan input utk mengabaikan)");
  TF_TransCreditDays.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransCreditDays.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_TransCreditDaysFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_TransCreditDaysFocusLost(evt);
   }
  });
  TF_TransCreditDays.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransCreditDaysKeyPressed(evt);
   }
  });

  Lbl_TransCreditDays.setText("Kredit");
  Lbl_TransCreditDays.setToolTipText("Lama Kredit (dalam hari)");

  TF_RepayPeriodEnd.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_RepayPeriodEnd.setToolTipText("Tanggal Akhir Periode Cicil; Format input : tahun-bulan-tanggal (contohnya 2018-07-19)");
  TF_RepayPeriodEnd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_RepayPeriodEnd.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_RepayPeriodEndFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_RepayPeriodEndFocusLost(evt);
   }
  });
  TF_RepayPeriodEnd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_RepayPeriodEndKeyPressed(evt);
   }
  });

  Lbl_RepayPeriodHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_RepayPeriodHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_RepayPeriodHelp.setText("(?)");
  Lbl_RepayPeriodHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_RepayPeriodHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_RepayPeriodHelpMouseClicked(evt);
   }
  });

  jLabel1.setText("-");

  TF_RepayPeriodStart.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_RepayPeriodStart.setToolTipText("Tanggal Awal Periode Cicil; Format input : tahun-bulan-tanggal (contohnya 2018-07-19)");
  TF_RepayPeriodStart.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_RepayPeriodStart.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_RepayPeriodStartFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_RepayPeriodStartFocusLost(evt);
   }
  });
  TF_RepayPeriodStart.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_RepayPeriodStartKeyPressed(evt);
   }
  });

  ComboBox_TransType.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_TransType.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  ComboBox_TransType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_TransTypeKeyPressed(evt);
   }
  });

  Lbl_TransType.setText("Jenis");
  Lbl_TransType.setRequestFocusEnabled(false);

  ComboBox_CashIn.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_CashIn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  ComboBox_CashIn.setToolTipText("Kas Masuk Tunai");
  ComboBox_CashIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_CashInKeyPressed(evt);
   }
  });

  Lbl_CashIn.setText("Kas Msk Tun");
  Lbl_CashIn.setToolTipText("Kas Masuk Tunai");

  TF_CashInComment.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CashInComment.setToolTipText("Keterangan kas masuk tunai");
  TF_CashInComment.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_CashInComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CashInCommentFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_CashInCommentFocusLost(evt);
   }
  });
  TF_CashInComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CashInCommentKeyPressed(evt);
   }
  });

  Lbl_CashInCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CashInCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CashInCommentHelp.setText("(?)");
  Lbl_CashInCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CashInCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CashInCommentHelpMouseClicked(evt);
   }
  });

  ComboBox_CashOut.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_CashOut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  ComboBox_CashOut.setToolTipText("Kas Keluar Tunai");
  ComboBox_CashOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_CashOutKeyPressed(evt);
   }
  });

  Lbl_CashOut.setText("Kas Klr Tun");
  Lbl_CashOut.setToolTipText("Kas Keluar Tunai");

  TF_CashOutComment.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_CashOutComment.setToolTipText("Keterangan kas keluar tunai");
  TF_CashOutComment.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_CashOutComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CashOutCommentFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_CashOutCommentFocusLost(evt);
   }
  });
  TF_CashOutComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CashOutCommentKeyPressed(evt);
   }
  });

  Lbl_CashOutCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CashOutCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CashOutCommentHelp.setText("(?)");
  Lbl_CashOutCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CashOutCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CashOutCommentHelpMouseClicked(evt);
   }
  });

  TF_TransSubject.setEditable(false);
  TF_TransSubject.setBackground(new java.awt.Color(204, 255, 204));
  TF_TransSubject.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TransSubject.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TransSubject.setToolTipText("klik utk melihat keterangan subjek");
  TF_TransSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TransSubject.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransSubject.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TransSubjectMouseClicked(evt);
   }
  });

  Btn_ClearChoosedSubject.setText("-");
  Btn_ClearChoosedSubject.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearChoosedSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearChoosedSubjectActionPerformed(evt);
   }
  });
  Btn_ClearChoosedSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearChoosedSubjectKeyPressed(evt);
   }
  });

  Btn_ChooseSubject.setText("...");
  Btn_ChooseSubject.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseSubjectActionPerformed(evt);
   }
  });
  Btn_ChooseSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseSubjectKeyPressed(evt);
   }
  });

  Btn_ClearChoosedSalesman.setText("-");
  Btn_ClearChoosedSalesman.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearChoosedSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearChoosedSalesmanActionPerformed(evt);
   }
  });
  Btn_ClearChoosedSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearChoosedSalesmanKeyPressed(evt);
   }
  });

  Btn_ChooseSalesman.setText("...");
  Btn_ChooseSalesman.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseSalesmanActionPerformed(evt);
   }
  });
  Btn_ChooseSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseSalesmanKeyPressed(evt);
   }
  });

  CB_TransSubjectKeep.setText("!");
  CB_TransSubjectKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_TransSubjectKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_TransSubjectKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_TransSubjectKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransSubjectKeep.setOpaque(false);
  CB_TransSubjectKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransSubjectKeepKeyPressed(evt);
   }
  });

  TF_TransSalesman.setEditable(false);
  TF_TransSalesman.setBackground(new java.awt.Color(204, 255, 204));
  TF_TransSalesman.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TransSalesman.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TransSalesman.setToolTipText("klik utk melihat keterangan sales");
  TF_TransSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TransSalesman.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransSalesman.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TransSalesmanMouseClicked(evt);
   }
  });

  CB_TransSalesmanKeep.setText("!");
  CB_TransSalesmanKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_TransSalesmanKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_TransSalesmanKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_TransSalesmanKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransSalesmanKeep.setOpaque(false);
  CB_TransSalesmanKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransSalesmanKeepKeyPressed(evt);
   }
  });

  Lbl_TransSubject.setText("Subjek");

  Lbl_TransSalesman.setText("Sales");

  CB_CashOutCommentKeep.setText("!");
  CB_CashOutCommentKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_CashOutCommentKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_CashOutCommentKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_CashOutCommentKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CashOutCommentKeep.setOpaque(false);
  CB_CashOutCommentKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CashOutCommentKeepKeyPressed(evt);
   }
  });

  Lbl_RepayPeriod.setText("Cicil");
  Lbl_RepayPeriod.setToolTipText("Periode Cicil");

  CB_RepayPeriod.setText(" ");
  CB_RepayPeriod.setToolTipText("kosongkan inputan 'Periode Cicil' dgn menghilangkan centang");
  CB_RepayPeriod.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  CB_RepayPeriod.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
  CB_RepayPeriod.setIconTextGap(0);
  CB_RepayPeriod.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_RepayPeriod.setOpaque(false);
  CB_RepayPeriod.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_RepayPeriodActionPerformed(evt);
   }
  });
  CB_RepayPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_RepayPeriodKeyPressed(evt);
   }
  });

  CB_CashInCommentKeep.setText("!");
  CB_CashInCommentKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_CashInCommentKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_CashInCommentKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_CashInCommentKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CashInCommentKeep.setOpaque(false);
  CB_CashInCommentKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CashInCommentKeepKeyPressed(evt);
   }
  });

  CB_TransIdExternalKeep.setText("!");
  CB_TransIdExternalKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_TransIdExternalKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_TransIdExternalKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_TransIdExternalKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransIdExternalKeep.setOpaque(false);
  CB_TransIdExternalKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransIdExternalKeepKeyPressed(evt);
   }
  });

  CB_TransCreditDaysKeep.setText("!");
  CB_TransCreditDaysKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_TransCreditDaysKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_TransCreditDaysKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_TransCreditDaysKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransCreditDaysKeep.setOpaque(false);
  CB_TransCreditDaysKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransCreditDaysKeepKeyPressed(evt);
   }
  });

  CB_RepayPeriodKeep.setText("!");
  CB_RepayPeriodKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_RepayPeriodKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_RepayPeriodKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_RepayPeriodKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_RepayPeriodKeep.setOpaque(false);
  CB_RepayPeriodKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_RepayPeriodKeepKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator6)
     .addComponent(jSeparator4)
     .addComponent(RB_TransId, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_TransDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(Lbl_TransCreditDays)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(CB_TransCreditDaysKeep))
     .addComponent(Lbl_TransType, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jSeparator9, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
      .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_TransSubject)
       .addComponent(Lbl_TransSalesman))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(CB_TransSalesmanKeep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(CB_TransSubjectKeep, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addComponent(CB_CashOutCommentKeep, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(RB_TransIdExternal)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
      .addComponent(CB_TransIdExternalKeep))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(Lbl_RepayPeriod)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addComponent(CB_RepayPeriodKeep))
     .addComponent(CB_CashInCommentKeep, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(Lbl_CashIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_CashOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_TransSalesman)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseSalesman)
      .addGap(3, 3, 3)
      .addComponent(Btn_ClearChoosedSalesman))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_TransSubject)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseSubject)
      .addGap(3, 3, 3)
      .addComponent(Btn_ClearChoosedSubject))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_CashOutComment)
      .addGap(2, 2, 2)
      .addComponent(Lbl_CashOutCommentHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
      .addComponent(TF_CashInComment)
      .addGap(2, 2, 2)
      .addComponent(Lbl_CashInCommentHelp))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(CB_RepayPeriod)
      .addGap(2, 2, 2)
      .addComponent(TF_RepayPeriodStart, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel1)
      .addGap(2, 2, 2)
      .addComponent(TF_RepayPeriodEnd)
      .addGap(2, 2, 2)
      .addComponent(Lbl_RepayPeriodHelp))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_TransCreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(4, 4, 4)
      .addComponent(TF_CreditDaysInfo)
      .addGap(2, 2, 2)
      .addComponent(Lbl_TransCreditDaysHelp))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_TransDateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_TransDateMonth, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_TransDateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_TransId)
      .addGap(0, 0, 0)
      .addComponent(Btn_TransPendingLoad)
      .addGap(3, 3, 3)
      .addComponent(CB_TransImportant))
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(TF_TransIdExternal)
      .addGap(2, 2, 2)
      .addComponent(Lbl_TransIdExternalHelp))
     .addComponent(jSeparator5)
     .addComponent(jSeparator7)
     .addComponent(jSeparator8)
     .addComponent(ComboBox_TransType, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_CashIn, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_CashOut, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_TransId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_TransImportant)
     .addComponent(Btn_TransPendingLoad)
     .addComponent(RB_TransId))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_TransIdExternal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransIdExternalHelp)
     .addComponent(RB_TransIdExternal)
     .addComponent(CB_TransIdExternalKeep))
    .addGap(2, 2, 2)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator4)
     .addComponent(jSeparator5))
    .addGap(2, 2, 2)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(ComboBox_TransDateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_TransDateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_TransDateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransDate))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CreditDaysInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransCreditDaysHelp)
     .addComponent(TF_TransCreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransCreditDays)
     .addComponent(CB_TransCreditDaysKeep))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_RepayPeriodEnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_RepayPeriodHelp)
     .addComponent(jLabel1)
     .addComponent(TF_RepayPeriodStart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_RepayPeriod)
     .addComponent(Lbl_RepayPeriod)
     .addComponent(CB_RepayPeriodKeep))
    .addGap(2, 2, 2)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator6)
     .addComponent(jSeparator7))
    .addGap(2, 2, 2)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(ComboBox_TransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransType))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(ComboBox_CashIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashIn))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CashInComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashInCommentHelp)
     .addComponent(CB_CashInCommentKeep))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(ComboBox_CashOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashOut))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CashOutComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashOutCommentHelp)
     .addComponent(CB_CashOutCommentKeep))
    .addGap(2, 2, 2)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator9)
     .addComponent(jSeparator8))
    .addGap(2, 2, 2)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_TransSubject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ClearChoosedSubject)
     .addComponent(Btn_ChooseSubject)
     .addComponent(CB_TransSubjectKeep)
     .addComponent(Lbl_TransSubject))
    .addGap(3, 3, 3)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_ClearChoosedSalesman)
     .addComponent(Btn_ChooseSalesman)
     .addComponent(TF_TransSalesman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_TransSalesmanKeep)
     .addComponent(Lbl_TransSalesman)))
  );

  jPanel6.setBackground(new java.awt.Color(221, 219, 192));

  Panel_AddItem.setOpaque(false);

  Btn_AddItem.setText("Tmbah {F2}");
  Btn_AddItem.setToolTipText("Menambah barang ke daftar barang keluar / daftar barang masuk");
  Btn_AddItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddItemActionPerformed(evt);
   }
  });
  Btn_AddItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddItemKeyPressed(evt);
   }
  });

  RG_AddItem.add(RB_AddItemIn);
  RB_AddItemIn.setText("Msuk {Alt+F3}");
  RB_AddItemIn.setToolTipText("Tambah inputan barang ke Daftar Barang Masuk");
  RB_AddItemIn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_AddItemIn.setOpaque(false);
  RB_AddItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_AddItemInKeyPressed(evt);
   }
  });

  RG_AddItem.add(RB_AddItemOut);
  RB_AddItemOut.setText("Kluar {Alt+F4}");
  RB_AddItemOut.setToolTipText("Tambah inputan barang ke Daftar Barang Keluar");
  RB_AddItemOut.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_AddItemOut.setOpaque(false);
  RB_AddItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_AddItemOutKeyPressed(evt);
   }
  });

  jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel8.setText("BRG : ");

  javax.swing.GroupLayout Panel_AddItemLayout = new javax.swing.GroupLayout(Panel_AddItem);
  Panel_AddItem.setLayout(Panel_AddItemLayout);
  Panel_AddItemLayout.setHorizontalGroup(
   Panel_AddItemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_AddItemLayout.createSequentialGroup()
    .addComponent(jLabel8)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(RB_AddItemIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(RB_AddItemOut)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_AddItem))
  );
  Panel_AddItemLayout.setVerticalGroup(
   Panel_AddItemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_AddItemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_AddItem)
    .addComponent(RB_AddItemIn)
    .addComponent(RB_AddItemOut)
    .addComponent(jLabel8))
  );

  Panel_AddItemDet.setOpaque(false);

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_ItemId.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_ItemId.setToolTipText("Tekan F6 utk lihat detail barang");
  TF_ItemId.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setToolTipText("Pilih sebuah barang");
  Btn_ChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });
  Btn_ChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseItemKeyPressed(evt);
   }
  });

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Brg");
  Lbl_ItemId.setRequestFocusEnabled(false);

  CB_ItemIdEnterAutoAdd.setToolTipText("centang opsi ini utk mengaktifkan penambahan barang secara otomatis ketika karakter 'Enter' ditekan pada 'text box Id Barang'");
  CB_ItemIdEnterAutoAdd.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_ItemIdEnterAutoAdd.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_ItemIdEnterAutoAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemIdEnterAutoAdd.setOpaque(false);
  CB_ItemIdEnterAutoAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ItemIdEnterAutoAddKeyPressed(evt);
   }
  });

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(5);
  TA_ItemName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setToolTipText("klik utk melihat keterangan barang");
  TA_ItemName.setWrapStyleWord(true);
  TA_ItemName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_ItemName.setRequestFocusEnabled(false);
  TA_ItemName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_ItemNameMouseClicked(evt);
   }
  });
  jScrollPane1.setViewportView(TA_ItemName);

  TA_ItemPriceComment.setEditable(false);
  TA_ItemPriceComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemPriceComment.setColumns(5);
  TA_ItemPriceComment.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_ItemPriceComment.setLineWrap(true);
  TA_ItemPriceComment.setToolTipText("Keterangan Harga Beli - Jual");
  TA_ItemPriceComment.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_ItemPriceComment);

  TF_Quantity.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_Quantity.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_Quantity.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_Quantity.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusLost(evt);
   }
  });
  TF_Quantity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QuantityKeyPressed(evt);
   }
  });

  Lbl_Quantity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Quantity.setText("Kuantitas");
  Lbl_Quantity.setRequestFocusEnabled(false);

  TF_PriceUnit.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_PriceUnit.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_PriceUnit.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_PriceUnit.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PriceUnitFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_PriceUnitFocusLost(evt);
   }
  });
  TF_PriceUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PriceUnitKeyPressed(evt);
   }
  });

  RG_Price.add(RB_PriceUnit);
  RB_PriceUnit.setText("/ Unit");
  RB_PriceUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_PriceUnit.setOpaque(false);
  RB_PriceUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_PriceUnitKeyPressed(evt);
   }
  });

  TF_PriceTotal.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_PriceTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_PriceTotal.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_PriceTotal.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PriceTotalFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_PriceTotalFocusLost(evt);
   }
  });
  TF_PriceTotal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PriceTotalKeyPressed(evt);
   }
  });

  RG_Price.add(RB_PriceTotal);
  RB_PriceTotal.setText("Total");
  RB_PriceTotal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_PriceTotal.setOpaque(false);
  RB_PriceTotal.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_PriceTotalKeyPressed(evt);
   }
  });

  CB_Price.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_Price.setToolTipText("centang utk mengubah harga secara manual");
  CB_Price.setIconTextGap(0);
  CB_Price.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Price.setOpaque(false);
  CB_Price.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_PriceActionPerformed(evt);
   }
  });
  CB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PriceKeyPressed(evt);
   }
  });

  CmB_Price.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CmB_Price.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hrg", "Beli", "Jual" }));
  CmB_Price.setToolTipText("pilih jenis harga yg akan digunakan sebagai nilai awal");
  CmB_Price.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_PriceActionPerformed(evt);
   }
  });
  CmB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PriceKeyPressed(evt);
   }
  });

  CB_ItemUpStock.setText(" ");
  CB_ItemUpStock.setToolTipText("Pembaruan Stok Saat Transaksi");
  CB_ItemUpStock.setEnabled(false);
  CB_ItemUpStock.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_ItemUpStock.setIconTextGap(0);
  CB_ItemUpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemUpStock.setOpaque(false);
  CB_ItemUpStock.setRequestFocusEnabled(false);

  TF_ItemStock.setEditable(false);
  TF_ItemStock.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemStock.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_ItemStock.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_ItemStock.setToolTipText("Jumlah Stok");
  TF_ItemStock.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_ItemStock.setRequestFocusEnabled(false);

  TF_TransItemComment.setBackground(new java.awt.Color(255, 204, 204));
  TF_TransItemComment.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TransItemComment.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TransItemComment.setMargin(new java.awt.Insets(0, 2, 0, 2));
  TF_TransItemComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_TransItemCommentKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout Panel_AddItemDetLayout = new javax.swing.GroupLayout(Panel_AddItemDet);
  Panel_AddItemDet.setLayout(Panel_AddItemDetLayout);
  Panel_AddItemDetLayout.setHorizontalGroup(
   Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
      .addComponent(CB_Price)
      .addGap(0, 0, 0)
      .addComponent(CmB_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
      .addComponent(Lbl_ItemId)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_ItemIdEnterAutoAdd))
     .addComponent(Lbl_Quantity))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_Quantity)
     .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
      .addComponent(Btn_ChooseItem)
      .addGap(0, 0, 0)
      .addComponent(TF_ItemId))
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
     .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
      .addComponent(TF_ItemStock)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_ItemUpStock))
     .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
      .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(RB_PriceUnit)
       .addComponent(RB_PriceTotal))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_PriceUnit)
       .addComponent(TF_PriceTotal)))
     .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_TransItemComment)))
  );
  Panel_AddItemDetLayout.setVerticalGroup(
   Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_AddItemDetLayout.createSequentialGroup()
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_ItemId)
      .addComponent(Btn_ChooseItem))
     .addComponent(CB_ItemIdEnterAutoAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(3, 3, 3)
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_ItemUpStock)
     .addComponent(TF_ItemStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addComponent(TF_TransItemComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(3, 3, 3)
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Quantity))
    .addGap(3, 3, 3)
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_Price, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_PriceUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(RB_PriceUnit)
      .addComponent(CmB_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addGap(3, 3, 3)
    .addGroup(Panel_AddItemDetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PriceTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_PriceTotal))
    .addGap(3, 3, 3)
    .addComponent(jScrollPane5))
  );

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Panel_AddItem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Panel_AddItemDet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(Panel_AddItem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Panel_AddItemDet, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  jPanel2.setBackground(new java.awt.Color(221, 219, 192));

  CB_Receipt.setText("Ctak");
  CB_Receipt.setToolTipText("Centang opsi ini utk mencetak nota ketika transaksi selesai dilakukan");
  CB_Receipt.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Receipt.setOpaque(false);
  CB_Receipt.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ReceiptKeyPressed(evt);
   }
  });

  ComboBox_ReceiptPaper.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_ReceiptPaper.setToolTipText("Ukuran kertas utk mencetak nota");
  ComboBox_ReceiptPaper.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_ReceiptPaperKeyPressed(evt);
   }
  });

  ComboBox_ReceiptPrinter.setBackground(new java.awt.Color(230, 230, 255));
  ComboBox_ReceiptPrinter.setToolTipText("Printer utk mencetak nota");
  ComboBox_ReceiptPrinter.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_ReceiptPrinterKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(CB_Receipt)
    .addGap(18, 18, Short.MAX_VALUE)
    .addComponent(ComboBox_ReceiptPaper, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(ComboBox_ReceiptPrinter, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_Receipt)
    .addComponent(ComboBox_ReceiptPaper, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(ComboBox_ReceiptPrinter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(6, 6, 6)
    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TF_InPrice.setEditable(false);
  TF_InPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_InPrice.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_InPrice.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_InPrice.setRequestFocusEnabled(false);

  TF_InCount.setEditable(false);
  TF_InCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_InCount.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_InCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_InCount.setRequestFocusEnabled(false);

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  jLabel2.setText("Brg Msk");

  TF_OutPrice.setEditable(false);
  TF_OutPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutPrice.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_OutPrice.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_OutPrice.setRequestFocusEnabled(false);

  TF_OutCount.setEditable(false);
  TF_OutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutCount.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_OutCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_OutCount.setRequestFocusEnabled(false);

  jLabel5.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  jLabel5.setText("Brg Klr");

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addComponent(jLabel5)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_OutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_OutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel2)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_InCount, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_InPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_InPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_InCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel2)
    .addComponent(TF_OutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_OutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel5))
  );

  Btn_TransPending.setText("Pend");
  Btn_TransPending.setToolTipText("Pending (tunda) transaksi saat ini dan buat transaksi baru");
  Btn_TransPending.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransPending.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransPendingActionPerformed(evt);
   }
  });
  Btn_TransPending.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TransPendingKeyPressed(evt);
   }
  });

  Btn_TransCancel.setText("Btal");
  Btn_TransCancel.setToolTipText("Batalkan transaksi saat ini dan buat transaksi baru");
  Btn_TransCancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransCancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransCancelActionPerformed(evt);
   }
  });
  Btn_TransCancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TransCancelKeyPressed(evt);
   }
  });

  Btn_TransFinish.setText("Slesai {F11}");
  Btn_TransFinish.setToolTipText("");
  Btn_TransFinish.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransFinish.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransFinishActionPerformed(evt);
   }
  });
  Btn_TransFinish.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TransFinishKeyPressed(evt);
   }
  });

  Btn_ReprintLastTrans.setText("Ctk Ulang");
  Btn_ReprintLastTrans.setToolTipText("Mencetak ulang nota dari transaksi terakhir");
  Btn_ReprintLastTrans.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ReprintLastTrans.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReprintLastTransActionPerformed(evt);
   }
  });
  Btn_ReprintLastTrans.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ReprintLastTransKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addGap(0, 0, 0)
    .addComponent(Btn_ReprintLastTrans)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransPending)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransCancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransFinish))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransPending)
    .addComponent(Btn_TransCancel)
    .addComponent(Btn_TransFinish)
    .addComponent(Btn_ReprintLastTrans))
  );

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
  );

  TabbedPane.setToolTipText("");

  Btn_OutEdit.setText("Ubah");
  Btn_OutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutEditActionPerformed(evt);
   }
  });
  Btn_OutEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OutEditKeyPressed(evt);
   }
  });

  Btn_OutRemove.setText("Hapus");
  Btn_OutRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutRemoveActionPerformed(evt);
   }
  });
  Btn_OutRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OutRemoveKeyPressed(evt);
   }
  });

  RG_FindItemOut.add(RB_FindItemOutId);
  RB_FindItemOutId.setText("Id");
  RB_FindItemOutId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_FindItemOutId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_FindItemOutIdKeyPressed(evt);
   }
  });

  RG_FindItemOut.add(RB_FindItemOutName);
  RB_FindItemOutName.setText("Nama");
  RB_FindItemOutName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_FindItemOutName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_FindItemOutNameKeyPressed(evt);
   }
  });

  Btn_FindItemOutNext.setText(">");
  Btn_FindItemOutNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemOutNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemOutNextActionPerformed(evt);
   }
  });
  Btn_FindItemOutNext.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FindItemOutNextKeyPressed(evt);
   }
  });

  Btn_FindItemOutBef.setText("<");
  Btn_FindItemOutBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemOutBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemOutBefActionPerformed(evt);
   }
  });
  Btn_FindItemOutBef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FindItemOutBefKeyPressed(evt);
   }
  });

  TF_FindItemOut.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_FindItemOut.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindItemOutFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FindItemOutFocusLost(evt);
   }
  });
  TF_FindItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindItemOutKeyPressed(evt);
   }
  });

  TF_OutInfo.setEditable(false);
  TF_OutInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutInfo.setColumns(5);
  TF_OutInfo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_OutInfo.setLineWrap(true);
  TF_OutInfo.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TF_OutInfo);

  Pnl_ItemOutPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutPreviewMouseClicked(evt);
   }
  });

  Btn_OutMove.setText(">>>");
  Btn_OutMove.setToolTipText("Pindahkan barang2 yg dipilih ke daftar barang masuk");
  Btn_OutMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutMoveActionPerformed(evt);
   }
  });
  Btn_OutMove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OutMoveKeyPressed(evt);
   }
  });

  Btn_OutCheckAdd.setText("+");
  Btn_OutCheckAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutCheckAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutCheckAddActionPerformed(evt);
   }
  });
  Btn_OutCheckAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OutCheckAddKeyPressed(evt);
   }
  });

  Btn_OutCheckRemove.setText("-");
  Btn_OutCheckRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutCheckRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutCheckRemoveActionPerformed(evt);
   }
  });
  Btn_OutCheckRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OutCheckRemoveKeyPressed(evt);
   }
  });

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setText("Cek");

  Tbl_Out.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Out.setToolTipText("F9 - Cek ; F10 - Hapus Cek");
  Tbl_Out.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Out.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  Tbl_Out.setRowHeight(23);
  Tbl_Out.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_OutMouseReleased(evt);
   }
  });
  Tbl_Out.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_OutKeyReleased(evt);
   }
  });
  jScrollPane8.setViewportView(Tbl_Out);

  CB_ItemOutKeep.setText("!");
  CB_ItemOutKeep.setToolTipText("centang utk mempertahankan nilai daftar barang keluar");
  CB_ItemOutKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_ItemOutKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_ItemOutKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutKeep.setOpaque(false);
  CB_ItemOutKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ItemOutKeepKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout Panel_ItemOutLayout = new javax.swing.GroupLayout(Panel_ItemOut);
  Panel_ItemOut.setLayout(Panel_ItemOutLayout);
  Panel_ItemOutLayout.setHorizontalGroup(
   Panel_ItemOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemOutLayout.createSequentialGroup()
    .addComponent(RB_FindItemOutId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(RB_FindItemOutName)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemOutBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemOutNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 203, Short.MAX_VALUE)
    .addComponent(CB_ItemOutKeep)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel3)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutCheckAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutCheckRemove))
   .addGroup(Panel_ItemOutLayout.createSequentialGroup()
    .addComponent(Pnl_ItemOutPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6))
   .addComponent(jScrollPane8)
  );
  Panel_ItemOutLayout.setVerticalGroup(
   Panel_ItemOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemOutLayout.createSequentialGroup()
    .addGroup(Panel_ItemOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_OutEdit)
     .addComponent(Btn_OutRemove)
     .addComponent(RB_FindItemOutId)
     .addComponent(RB_FindItemOutName)
     .addComponent(Btn_FindItemOutNext)
     .addComponent(Btn_FindItemOutBef)
     .addComponent(TF_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_OutMove)
     .addComponent(Btn_OutCheckAdd)
     .addComponent(Btn_OutCheckRemove)
     .addComponent(jLabel3)
     .addComponent(CB_ItemOutKeep))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_ItemOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Pnl_ItemOutPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)))
  );

  TabbedPane.addTab("Barang Keluar {F6}", Panel_ItemOut);

  Btn_InEdit.setText("Ubah");
  Btn_InEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InEditActionPerformed(evt);
   }
  });
  Btn_InEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InEditKeyPressed(evt);
   }
  });

  Btn_InRemove.setText("Hapus");
  Btn_InRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InRemoveActionPerformed(evt);
   }
  });
  Btn_InRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InRemoveKeyPressed(evt);
   }
  });

  TF_FindItemIn.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  TF_FindItemIn.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindItemInFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FindItemInFocusLost(evt);
   }
  });
  TF_FindItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindItemInKeyPressed(evt);
   }
  });

  Btn_FindItemInBef.setText("<");
  Btn_FindItemInBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemInBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemInBefActionPerformed(evt);
   }
  });
  Btn_FindItemInBef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FindItemInBefKeyPressed(evt);
   }
  });

  Btn_FindItemInNext.setText(">");
  Btn_FindItemInNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemInNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemInNextActionPerformed(evt);
   }
  });
  Btn_FindItemInNext.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FindItemInNextKeyPressed(evt);
   }
  });

  RG_FindItemIn.add(RB_FindItemInId);
  RB_FindItemInId.setText("Id");
  RB_FindItemInId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_FindItemInId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_FindItemInIdKeyPressed(evt);
   }
  });

  RG_FindItemIn.add(RB_FindItemInName);
  RB_FindItemInName.setText("Nama");
  RB_FindItemInName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_FindItemInName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_FindItemInNameKeyPressed(evt);
   }
  });

  TF_InInfo.setEditable(false);
  TF_InInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_InInfo.setColumns(5);
  TF_InInfo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  TF_InInfo.setLineWrap(true);
  TF_InInfo.setWrapStyleWord(true);
  jScrollPane7.setViewportView(TF_InInfo);

  Pnl_ItemInPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInPreviewMouseClicked(evt);
   }
  });

  Btn_InMove.setText("<<<");
  Btn_InMove.setToolTipText("Pindahkan barang2 yg dipilih ke daftar barang keluar");
  Btn_InMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InMoveActionPerformed(evt);
   }
  });
  Btn_InMove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InMoveKeyPressed(evt);
   }
  });

  Btn_InCheckRemove.setText("-");
  Btn_InCheckRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InCheckRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InCheckRemoveActionPerformed(evt);
   }
  });
  Btn_InCheckRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InCheckRemoveKeyPressed(evt);
   }
  });

  Btn_InCheckAdd.setText("+");
  Btn_InCheckAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InCheckAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InCheckAddActionPerformed(evt);
   }
  });
  Btn_InCheckAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_InCheckAddKeyPressed(evt);
   }
  });

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("Cek");

  Tbl_In.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_In.setToolTipText("F9 - Cek ; F10 - Hapus Cek");
  Tbl_In.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_In.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
  Tbl_In.setRowHeight(23);
  Tbl_In.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_InMouseReleased(evt);
   }
  });
  Tbl_In.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_InKeyReleased(evt);
   }
  });
  jScrollPane3.setViewportView(Tbl_In);

  CB_ItemInKeep.setText("!");
  CB_ItemInKeep.setToolTipText("centang utk mempertahankan nilai daftar barang masuk");
  CB_ItemInKeep.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  CB_ItemInKeep.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_ItemInKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInKeep.setOpaque(false);
  CB_ItemInKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ItemInKeepKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout Panel_ItemInLayout = new javax.swing.GroupLayout(Panel_ItemIn);
  Panel_ItemIn.setLayout(Panel_ItemInLayout);
  Panel_ItemInLayout.setHorizontalGroup(
   Panel_ItemInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemInLayout.createSequentialGroup()
    .addComponent(RB_FindItemInId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(RB_FindItemInName)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemInBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemInNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 203, Short.MAX_VALUE)
    .addComponent(CB_ItemInKeep)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel4)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InCheckAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InCheckRemove))
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ItemInLayout.createSequentialGroup()
    .addComponent(Pnl_ItemInPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7))
   .addComponent(jScrollPane3)
  );
  Panel_ItemInLayout.setVerticalGroup(
   Panel_ItemInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_ItemInLayout.createSequentialGroup()
    .addGroup(Panel_ItemInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_InEdit)
     .addComponent(Btn_InRemove)
     .addComponent(TF_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_FindItemInBef)
     .addComponent(Btn_FindItemInNext)
     .addComponent(RB_FindItemInId)
     .addComponent(RB_FindItemInName)
     .addComponent(Btn_InMove)
     .addComponent(Btn_InCheckRemove)
     .addComponent(Btn_InCheckAdd)
     .addComponent(jLabel4)
     .addComponent(CB_ItemInKeep))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_ItemInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Pnl_ItemInPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)))
  );

  TabbedPane.addTab("Barang Masuk {F7}", Panel_ItemIn);

  Lbl_TransComment.setText("Komentar (Opsional, maksimal 255 karakter)");
  Lbl_TransComment.setRequestFocusEnabled(false);

  TA_TransComment.setColumns(5);
  TA_TransComment.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_TransComment.setLineWrap(true);
  TA_TransComment.setToolTipText("maksimal 255 karakter");
  TA_TransComment.setWrapStyleWord(true);
  TA_TransComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TA_TransCommentFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TA_TransCommentFocusLost(evt);
   }
  });
  TA_TransComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_TransCommentKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_TransComment);

  CB_TransCommentKeep.setText("!");
  CB_TransCommentKeep.setToolTipText("centang utk mempertahankan nilai");
  CB_TransCommentKeep.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  CB_TransCommentKeep.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
  CB_TransCommentKeep.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_TransCommentKeep.setOpaque(false);
  CB_TransCommentKeep.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_TransCommentKeepKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_TransAdditionalLayout = new javax.swing.GroupLayout(Pnl_TransAdditional);
  Pnl_TransAdditional.setLayout(Pnl_TransAdditionalLayout);
  Pnl_TransAdditionalLayout.setHorizontalGroup(
   Pnl_TransAdditionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_TransAdditionalLayout.createSequentialGroup()
    .addComponent(Lbl_TransComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_TransCommentKeep)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 933, Short.MAX_VALUE)
  );
  Pnl_TransAdditionalLayout.setVerticalGroup(
   Pnl_TransAdditionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_TransAdditionalLayout.createSequentialGroup()
    .addGroup(Pnl_TransAdditionalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_TransComment)
     .addComponent(CB_TransCommentKeep))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE))
  );

  TabbedPane.addTab("Lainnya", Pnl_TransAdditional);

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(TabbedPane, javax.swing.GroupLayout.Alignment.TRAILING)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(TabbedPane))
  );

  TabbedPane.getAccessibleContext().setAccessibleName("");

  jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addGroup(layout.createSequentialGroup()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addGap(1191, 1191, 1191)
      .addComponent(jLabel7)
      .addGap(0, 0, Short.MAX_VALUE))
     .addGroup(layout.createSequentialGroup()
      .addContainerGap()
      .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jSeparator2)
     .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel7))
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutEditActionPerformed
  editItems(false);
 }//GEN-LAST:event_Btn_OutEditActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  int temp;
  if(Activ==false){
   Activ=true;
   
   if(!wIsPreTrans){
    setTitle("Tambah Transaksi Baru ( {Shift+Esc} Utk Keluar )");
    RB_TransId.setText("Id Trans");
    DbTable="Trans";
    DbAppLock=IFV.TransLock;
    DbPendLock=IFV.TransPendLock;
    TransName="Transaksi";
   }
   else{
    setTitle("Tambah Pra-Transaksi Baru ( {Shift+Esc} Utk Keluar )");
    RB_TransId.setText("Id PraTrans");
    DbTable="PreTrans";
    DbAppLock=IFV.PreTransLock;
    DbPendLock=IFV.PreTransPendLock;
    TransName="Pra-Transaksi";
   }
   
   // fill Trans Type
   PDatabase.queryToComboBox(IFV.Stm,
    "select Id, Name from TransType order by Name asc;", ComboMdlTransType, true, PCore.refArr("Tidak Didefenisikan"));
   ComboBox_TransType.setSelectedIndex(0);
   // fill Cash Out
   PDatabase.queryToComboBox(IFV.Stm,
    "select Id, Name from Cash order by Name asc;", ComboMdlCashOut, true, PCore.refArr("Tidak Didefenisikan"));
   ComboBox_CashOut.setSelectedIndex(0);
   // fill Cash In
   ComboMdlCashIn.append(ComboMdlCashOut.getRows());
   ComboBox_CashIn.setSelectedIndex(0);
   // fill Print Setting
   setPaper(IFV.CurrentReceiptPaper);
   PPrint.fillPrinters(ComboMdlReceiptPrinter);
   temp=PGUI.findString(ComboMdlReceiptPrinter, 1, IFV.CurrentReceiptPrinter.getName());
   if(temp!=-1){ComboBox_ReceiptPrinter.setSelectedIndex(temp);}
   
   // start transaction
   newTransId();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void CB_PriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_PriceActionPerformed
  enableEditPrice(CB_Price.isSelected());
 }//GEN-LAST:event_CB_PriceActionPerformed

 private void Btn_AddItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddItemActionPerformed
  long ItemId;
  OValidation Valid;
  
  if(TransId==-1){
   JOptionPane.showMessageDialog(null, TransName+" ini tidak memiliki Id "+TransName+","+
    "\nsilahkan tekan tombol 'Batal' utk mengulangi !"); return;
  }
  
  if(RecheckId){changeItemMetadata();}

  Valid=new OValidation(true);
  
  if(I_CheckedId==-1 || I_Qty<=0 || I_PriceUnit<0 || I_PriceTotal<0){
   Valid.addError("\n- Salah satu inputan di antara \"Id Brg, Qty, Hrg Sat, Hrg Total\" belum benar.");
  }
  
  I_TransItemComment=TF_TransItemComment.getText();
  if(!PText.checkInput(I_TransItemComment, true, CApp.DbVarcharMaxSize, 0, 0, 0, 0)){
   Valid.addError("\n- Inputan \"Komentar Brg\" belum benar.");
  }

  if(!Valid.getValid()){
   JOptionPane.showMessageDialog(null, "Masukan barang belum benar !\n"+Valid.getError()); return;
  }

  fillInputVariablesIntoRealVariables();
  ItemId=ItemInfo.PrimaryId;
  if(RB_AddItemIn.isSelected()){addItemIn(ItemId, ItemInfo.Name, Qty, ItemInfo.StockUnitName, PriceTotal, TransItemComment, false, ItemInfo.UpdateStock, ItemInfo.PictureFile);}
  else{addItemOut(ItemId, ItemInfo.Name, Qty, ItemInfo.StockUnitName, PriceTotal, TransItemComment, false, ItemInfo.UpdateStock, ItemInfo.PictureFile);}

  clearInputItem();
  TF_ItemId.requestFocusInWindow();
 }//GEN-LAST:event_Btn_AddItemActionPerformed

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult==1){
   // change ItemDet's variables directly from FItem
   I_CheckedId=IFV.FItem.ChoosedId[0];
   changeDocument(TF_ItemId, String.valueOf(I_CheckedId));
   inputItem();
   
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void Btn_ChooseSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseSubjectActionPerformed
  
  IFV.FSubject.wMode=1;
  IFV.FSubject.wAllowMultipleSelection=false;
  IFV.FSubject.wDialogWithFItem=false;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   TransSubjectId=IFV.FSubject.ChoosedId[0];
   TransSubjectName=IFV.FSubject.ChoosedName[0];
   TF_TransSubject.setText(TransSubjectName);
  }
 }//GEN-LAST:event_Btn_ChooseSubjectActionPerformed

 private void Btn_ClearChoosedSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSubjectActionPerformed
  TF_TransSubject.setText("");
  TransSubjectId=-1;
 }//GEN-LAST:event_Btn_ClearChoosedSubjectActionPerformed

 private void Btn_TransCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransCancelActionPerformed
  if(TransId!=-1){
   if(JOptionPane.showConfirmDialog(null, "Batalkan "+TransName+" saat ini ?", "Konfirmasi pembatalan "+TransName,
    JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  }
  removeCurrentTransId(TransPendingId==-1);
  clearTransInputs(false);
  newTransId();
 }//GEN-LAST:event_Btn_TransCancelActionPerformed

 private void Btn_TransFinishActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransFinishActionPerformed
  boolean bool;
  int[] OverInputOfItemStock=null;
		OValidation valid;
  StringBuilder Error;
  boolean WithResolution;
  F_TransFinishSummary fm=IFV.FTransFinishSummary;
  
  bool=false;
  do{
   // check trans id
   if(TransId==-1){
    JOptionPane.showMessageDialog(null, TransName+" ini tidak memiliki Id "+TransName+","+
     "\nsilahkan tekan tombol 'Batal' untuk mengulangi !");
    break;
   }

   // check trans inputs
   valid=checkTransInput(true);
   if(!valid.getValid()){
    JOptionPane.showMessageDialog(null, "Terdapat masukan yg belum benar !\n"+valid.getError());
    break;
   }

   // finish confirmation
   if(wIsPreTrans){
    if(JOptionPane.showConfirmDialog(null, "Selesaikan "+TransName+" saat ini ?",
     "Konfirmasi Penyelesaian "+TransName, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
     break;
    }
   }
   else{
    if(fm.appear(
     PCore.objInteger(ComboMdlCashIn.Mdl.Rows.elementAt(ComboBox_CashIn.getSelectedIndex())[0], -1),
     PCore.objString(ComboMdlCashIn.Mdl.Rows.elementAt(ComboBox_CashIn.getSelectedIndex())[1], "Tdk didefenisikan"),
     TF_CashInComment.getText(), TableMdlOut.getRowCount(), TableMdlOut.getCheckedCount(), OutPrice.Value,
     
     PCore.objInteger(ComboMdlCashOut.Mdl.Rows.elementAt(ComboBox_CashOut.getSelectedIndex())[0], -1),
     PCore.objString(ComboMdlCashOut.Mdl.Rows.elementAt(ComboBox_CashOut.getSelectedIndex())[1], "Tdk didefenisikan"),
     TF_CashOutComment.getText(), TableMdlIn.getRowCount(), TableMdlIn.getCheckedCount(), InPrice.Value)!=true){break;}
    if(fm.DialogResult!=1){break;}
   }
   
   bool=true;
  }while(false);
  if(bool==false){return;}
  
  // if inputs are valid, then process and start new trans
  bool=true;
  do{
   // finishing transaction
   if(finishingTrans()){break;}
   
   // if can't finish transaction, then show error message and resolution
   Error=new StringBuilder("Gagal menyelesaikan "+TransName+", mungkin dikarenakan :");
   
   WithResolution=false;
   if(!wIsPreTrans){
    OverInputOfItemStock=PMyShop.checkOverInputOfItemStock(IFV.Stm, TableMdlOut.Mdl.Rows, 0, 2,
     true, TableMdlIn.Mdl.Rows, 0, 2);
    if(OverInputOfItemStock!=null){
     if(OverInputOfItemStock.length!=0){
      WithResolution=true;
      
      Error.append(
       "\n\n- Pada daftar barang keluar, terdapat data barang yg 'kuantitas'-nya melebihi 'jumlah stok saat ini' "+
       "(di mana pembaruan stok pd barang tersebut aktif sehingga hasil pengurangan antara "+
       "'jumlah stok saat ini' dengan 'kuantitas' menghasilkan 'stok akhir' yg bernilai minus) :");

      Error.append("\n"+PText.toStringWithQuote(TableMdlOut.Mdl.Rows, OverInputOfItemStock, "\n",
       PCore.primArr(1, 0), PCore.primArr(false, false), "> ", ".", ", ", "", "", false));
     }
    }
   }
   
   if(!WithResolution){
    Error.append(
     "\n\n- Terdapat data barang yang tidak ditemukan di database."+
     "\n\n- Koneksi ke database server terputus.");
    IFV.FMessage.showMessage(Error.toString());
    return;
   }
   
   IFV.FMessage.showMessage(Error.toString(), PCore.vectObj(
    "Lanjut selesaikan transaksi (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan transaksi (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){return;}
   
   if(!signItemsWithMissmatch(IFV.FMessage.Resolution, TableMdlOut.Mdl.Rows, 0, OverInputOfItemStock)){return;}
  }while(bool);
  
  if(CB_Receipt.isSelected()){printReceipt(TransId, false);}
   
  clearTransInputs(false);
  newTransId();
 }//GEN-LAST:event_Btn_TransFinishActionPerformed

 private void Btn_OutRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutRemoveActionPerformed
  int[] rows=Tbl_Out.getSelectedRows();
  
  if(rows.length!=0){
   if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" barang yg dipilih dari tabel ?", "Konfirmasi Penghapusan",
    JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
    
    removeItemOut(rows);
   
   }
  }
 }//GEN-LAST:event_Btn_OutRemoveActionPerformed

 private void Btn_InRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InRemoveActionPerformed
  int[] rows=Tbl_In.getSelectedRows();
  if(rows.length!=0){
   if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" barang yg dipilih dari tabel ?", "Konfirmasi Penghapusan",
    JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
    
    removeItemIn(rows);
   
   }
  }
 }//GEN-LAST:event_Btn_InRemoveActionPerformed

 private void Btn_InEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InEditActionPerformed
  editItems(true);
 }//GEN-LAST:event_Btn_InEditActionPerformed

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOff);
  if(RecheckId){inputItem();}
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void Btn_TransCancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TransCancelKeyPressed
  PNav.onKey_Btn(this, Btn_TransCancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TabbedPane)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_TransPending)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransFinish)));
 }//GEN-LAST:event_Btn_TransCancelKeyPressed

 private void Btn_TransFinishKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TransFinishKeyPressed
  PNav.onKey_Btn(this, Btn_TransFinish, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TabbedPane)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_TransCancel)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_TransFinishKeyPressed

 private void CB_TransImportantKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransImportantKeyPressed
  PNav.onKey_CB(this, CB_TransImportant, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Receipt)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransIdExternal)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_TransPendingLoad)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_TransImportantKeyPressed

 private void TF_TransDateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransDateYearKeyPressed
  PNav.onKey_TF(this, TF_TransDateYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransIdExternal)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransCreditDays)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_TransDateMonth)));
 }//GEN-LAST:event_TF_TransDateYearKeyPressed

 private void ComboBox_TransDateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_TransDateMonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_TransDateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_TransDateYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_TransDateDay)));
 }//GEN-LAST:event_ComboBox_TransDateMonthKeyPressed

 private void ComboBox_TransDateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_TransDateDayKeyPressed
  PNav.onKey_CmB(this, ComboBox_TransDateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_TransDateMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_TransCreditDays)));
 }//GEN-LAST:event_ComboBox_TransDateDayKeyPressed

 private void ComboBox_TransTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_TransTypeKeyPressed
  PNav.onKey_CmB(this, ComboBox_TransType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_RepayPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_CashIn)));
 }//GEN-LAST:event_ComboBox_TransTypeKeyPressed

 private void Btn_ChooseSubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseSubjectKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseSubject, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CashOutComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_TransSubjectKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearChoosedSubject)));
 }//GEN-LAST:event_Btn_ChooseSubjectKeyPressed

 private void Btn_ClearChoosedSubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSubjectKeyPressed
  PNav.onKey_Btn(this, Btn_ClearChoosedSubject, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CashOutComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ClearChoosedSalesman)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseSubject)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ClearChoosedSubjectKeyPressed

 private void Btn_AddItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddItemKeyPressed
  PNav.onKey_Btn(this, Btn_AddItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_AddItemOut)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_AddItemKeyPressed

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ItemId, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : if(CB_ItemIdEnterAutoAdd.isSelected()){Btn_AddItemActionPerformed(null);}else{focus(TF_Quantity);} break;
   case KeyEvent.VK_F6 : if(RecheckId){inputItem();} break;
   case KeyEvent.VK_SPACE : evt.consume(); Btn_ChooseItemActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void Btn_ChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseItemKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ItemIdEnterAutoAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ItemId)));
 }//GEN-LAST:event_Btn_ChooseItemKeyPressed

 private void TF_QuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QuantityKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Quantity, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : if(evt.isShiftDown()){focus(TF_ItemId);}else{focusPrice();} break;
   case KeyEvent.VK_DOWN : focusPrice(); break;
   case KeyEvent.VK_UP : focus(TF_ItemId); break;
  }
 }//GEN-LAST:event_TF_QuantityKeyPressed

 private void TF_PriceUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PriceUnitKeyPressed
  if(!PGUI.isEnabled(TF_PriceUnit)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_PriceUnit, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_PriceUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focus(TF_Quantity); break;
   case KeyEvent.VK_ENTER : if(evt.isShiftDown()){focus(TF_Quantity);} break;
  }
 }//GEN-LAST:event_TF_PriceUnitKeyPressed

 private void TF_PriceTotalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PriceTotalKeyPressed
  if(!PGUI.isEnabled(TF_PriceTotal)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_PriceTotal, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_PriceTotal)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focus(TF_Quantity); break;
   case KeyEvent.VK_ENTER : if(evt.isShiftDown()){focus(TF_Quantity);} break;
  }
 }//GEN-LAST:event_TF_PriceTotalKeyPressed

 private void TF_QuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusGained
  DocumentListenerFocus=1;
  TF_Quantity.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_Quantity);
 }//GEN-LAST:event_TF_QuantityFocusGained

 private void TF_QuantityFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusLost
  DocumentListenerFocus=-1;
  TF_Quantity.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_QuantityFocusLost

 private void TF_PriceUnitFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceUnitFocusGained
  DocumentListenerFocus=2;
  if(TF_PriceUnit.isEditable()){
   TF_PriceUnit.setBackground(CGUI.Color_TextBox_FocusOn);
   PGUI.text_SelectAll(TF_PriceUnit);
  }
 }//GEN-LAST:event_TF_PriceUnitFocusGained

 private void TF_PriceUnitFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceUnitFocusLost
  DocumentListenerFocus=-1;
  if(TF_PriceUnit.isEditable()){
   TF_PriceUnit.setBackground(CGUI.Color_TextBox_FocusOff);
  }
 }//GEN-LAST:event_TF_PriceUnitFocusLost

 private void TF_PriceTotalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceTotalFocusGained
  DocumentListenerFocus=3;
  if(TF_PriceTotal.isEditable()){
   TF_PriceTotal.setBackground(CGUI.Color_TextBox_FocusOn);
   PGUI.text_SelectAll(TF_PriceTotal);
  }
 }//GEN-LAST:event_TF_PriceTotalFocusGained

 private void TF_PriceTotalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceTotalFocusLost
  DocumentListenerFocus=-1;
  if(TF_PriceTotal.isEditable()){
   TF_PriceTotal.setBackground(CGUI.Color_TextBox_FocusOff);
  }
 }//GEN-LAST:event_TF_PriceTotalFocusLost

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_ItemId);
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void TF_TransDateYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransDateYearFocusGained
  TF_TransDateYear.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_TransDateYear);
 }//GEN-LAST:event_TF_TransDateYearFocusGained

 private void TF_TransDateYearFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransDateYearFocusLost
  TF_TransDateYear.setBackground(CGUI.Color_TextBox_FocusOff);
		updateValueTransDate(true);
 }//GEN-LAST:event_TF_TransDateYearFocusLost

 private void TA_TransCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_TransCommentFocusGained
  TA_TransComment.setBackground(CGUI.Color_TextBox_FocusOn);
 }//GEN-LAST:event_TA_TransCommentFocusGained

 private void TA_TransCommentFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_TransCommentFocusLost
  TA_TransComment.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TA_TransCommentFocusLost

 private void TF_FindItemOutFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemOutFocusGained
  TF_FindItemOut.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_FindItemOut);
 }//GEN-LAST:event_TF_FindItemOutFocusGained

 private void TF_FindItemOutFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemOutFocusLost
  TF_FindItemOut.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FindItemOutFocusLost

 private void TF_FindItemOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindItemOutKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FindItemOut, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_FindItemOutName)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemOutBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: Btn_FindItemOutNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindItemOutKeyPressed

 private void Btn_FindItemOutBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemOutBefActionPerformed
  findItemOut(2);
 }//GEN-LAST:event_Btn_FindItemOutBefActionPerformed

 private void Btn_FindItemOutNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemOutNextActionPerformed
  findItemOut(1);
 }//GEN-LAST:event_Btn_FindItemOutNextActionPerformed

 private void TF_FindItemInFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemInFocusGained
  TF_FindItemIn.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_FindItemIn);
 }//GEN-LAST:event_TF_FindItemInFocusGained

 private void TF_FindItemInFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemInFocusLost
  TF_FindItemIn.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FindItemInFocusLost

 private void TF_FindItemInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindItemInKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FindItemIn, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_FindItemInName)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemInBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindItemInNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindItemInKeyPressed

 private void Btn_FindItemInBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemInBefActionPerformed
  findItemIn(2);
 }//GEN-LAST:event_Btn_FindItemInBefActionPerformed

 private void Btn_FindItemInNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemInNextActionPerformed
  findItemIn(1);
 }//GEN-LAST:event_Btn_FindItemInNextActionPerformed

 private void Lbl_TransCreditDaysHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_TransCreditDaysHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- 'Lama Kredit' diinput dalam satuan hari.\n"+PText.getInputInfo(true, 9, 2, 7, 0, 0, false));
 }//GEN-LAST:event_Lbl_TransCreditDaysHelpMouseClicked

 private void Btn_ChooseSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseSalesmanActionPerformed
  IFV.FSubject.wMode=1;
  IFV.FSubject.wAllowMultipleSelection=false;
  IFV.FSubject.wDialogWithFItem=false;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   TransSalesmanId=IFV.FSubject.ChoosedId[0];
   TransSalesmanName=IFV.FSubject.ChoosedName[0];
   TF_TransSalesman.setText(TransSalesmanName);
  }
 }//GEN-LAST:event_Btn_ChooseSalesmanActionPerformed

 private void Btn_ClearChoosedSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSalesmanActionPerformed
  TF_TransSalesman.setText("");
  TransSalesmanId=-1;
 }//GEN-LAST:event_Btn_ClearChoosedSalesmanActionPerformed

 private void Btn_ChooseSalesmanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseSalesmanKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseSalesman, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseSubject)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_TransSalesmanKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearChoosedSalesman)));
 }//GEN-LAST:event_Btn_ChooseSalesmanKeyPressed

 private void Btn_ClearChoosedSalesmanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedSalesmanKeyPressed
  PNav.onKey_Btn(this, Btn_ClearChoosedSalesman, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ClearChoosedSubject)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ClearChoosedSalesmanKeyPressed

 private void TF_TransCreditDaysKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransCreditDaysKeyPressed
  int consumed=PNav.onKey_TF(this, TF_TransCreditDays, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransDateYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_RepayPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_TransCreditDaysKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
			case KeyEvent.VK_ENTER : updateValueTransCreditDays(true); break;
  }
 }//GEN-LAST:event_TF_TransCreditDaysKeyPressed

 private void TF_TransCreditDaysFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransCreditDaysFocusGained
  TF_TransCreditDays.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_TransCreditDays);
 }//GEN-LAST:event_TF_TransCreditDaysFocusGained

 private void TF_TransCreditDaysFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransCreditDaysFocusLost
  TF_TransCreditDays.setBackground(CGUI.Color_TextBox_FocusOff);
		updateValueTransCreditDays(true);
 }//GEN-LAST:event_TF_TransCreditDaysFocusLost

 private void ComboBox_CashOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_CashOutKeyPressed
  PNav.onKey_CmB(this, ComboBox_CashOut, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CashInComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CashOutComment)));
 }//GEN-LAST:event_ComboBox_CashOutKeyPressed

 private void ComboBox_CashInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_CashInKeyPressed
  PNav.onKey_CmB(this, ComboBox_CashIn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_TransType)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CashInComment)));
 }//GEN-LAST:event_ComboBox_CashInKeyPressed

 private void Btn_TransPendingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransPendingActionPerformed
  OValidation valid;
		
		if(TransId==-1){
   JOptionPane.showMessageDialog(null, TransName+" ini tidak memiliki Id "+TransName+","+
    "\nsilahkan tekan tombol 'Batal' untuk mengulangi !");
   return;
  }
  
  if(JOptionPane.showConfirmDialog(null, "Pending "+TransName+" saat ini ?",
   "Konfirmasi Pending "+TransName, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
   return;
  }
  
  // check input
		valid=checkTransInput(false);
  if(!valid.getValid()){
   JOptionPane.showMessageDialog(null, "Tidak dapat menyelesaikan operasi pending :\n"+valid.getError());
   return;
  }
  
  if(!pendingTrans()){
   JOptionPane.showMessageDialog(null, "Gagal menyelesaikan operasi pending, mungkin dikarenakan :"+
    "\n- Koneksi ke database terputus."+
    "\n- Id dari transaksi ter-pending tdk ditemukan di database.");
   return;
  }
  
  // if pending success, then start a new trans
  clearTransInputs(false);
  newTransId();
 }//GEN-LAST:event_Btn_TransPendingActionPerformed

 private void Btn_TransPendingLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransPendingLoadActionPerformed
  long PendingId;
  OInfoTransPending Pend=null;
  Vector<Object[]> PendItemIn=null;
  Vector<Object[]> PendItemOut=null;
  int PendItemInCount=0;
  int PendItemOutCount=0;
  boolean bool;
  int temp;
  Object[] Row;
  int[] ColumnsType;
  
  IFV.FTransPending.wIsPreTrans=wIsPreTrans;
  
  IFV.FTransPending.wIsViewMode=false;
  IFV.FTransPending.wAllowMultipleChoose=false;
  
  if(IFV.FTransPending.showForm()==false){return;}
  if(IFV.FTransPending.DialogResult!=1){return;}
  
  if(TransId!=-1){
   if(JOptionPane.showConfirmDialog(null, "Tutup "+TransName+" saat ini dan gantikan dgn "+TransName+" Pending ?",
    "Konfirmasi Penutupan "+TransName+" Saat Ini", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
    return;
   }
  }
  
  // prepare pending-transaction's data
  PendingId=IFV.FTransPending.ChoosedId[0];
  bool=false;
  do{
   try{
    Pend=PMyShop.getTransPendingInfo(IFV.Stm, wIsPreTrans, PendingId);
    if(Pend==null){break;}
    
    PendItemIn=new Vector(); ColumnsType=TableMdlIn.Mdl.ColumnsType;
    PendItemInCount=PDatabase.queryToRows(IFV.Stm, getQueryOfLoadItemsFromTransPending(PendingId, true),
     PendItemIn, PCore.concatArr(ColumnsType, PCore.newIntegerArrayInOrderedSequence(ColumnsType.length, 0, 1), CCore.TypeBoolean),
     null, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1);
    if(PendItemInCount==-1){break;}
    
    PendItemOut=new Vector(); ColumnsType=TableMdlOut.Mdl.ColumnsType;
    PendItemOutCount=PDatabase.queryToRows(IFV.Stm, getQueryOfLoadItemsFromTransPending(PendingId, false),
     PendItemOut, PCore.concatArr(ColumnsType, PCore.newIntegerArrayInOrderedSequence(ColumnsType.length, 0, 1), CCore.TypeBoolean),
     null, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1);
    if(PendItemOutCount==-1){break;}
   }
   catch(Exception E){break;}
   bool=true;
  }while(false);
  if(!bool){
   JOptionPane.showMessageDialog(null, "Gagal membuka data "+TransName+" Pending :\n"+
    "terjadi error ketika mengakses database !");
   return;
  }
  
  // if pending-transaction's data prepared successfully, then open pending-transaction
  if(TransId!=-1){removeCurrentTransId(TransPendingId==-1);}
  clearTransInputs(true);
  
  fillTransIdAndDateInput(Pend.TransId, Pend.Dt);
  TransPendingId=PendingId;
  CB_TransImportant.setSelected(Pend.Important);
  TF_TransIdExternal.setText(PText.getString(Pend.InfoIdExternal, "", false));
  TransSubjectId=Pend.SubjectId;
  if(TransSubjectId!=-1){TransSubjectName=Pend.SubjectName; TF_TransSubject.setText(TransSubjectName);}
  TransSalesmanId=Pend.SalesmanId;
  if(TransSalesmanId!=-1){TransSalesmanName=Pend.SalesmanName; TF_TransSalesman.setText(TransSalesmanName);}
  if(Pend.TypeId!=-1){
   temp=PGUI.findLong(ComboMdlTransType, 0, Pend.TypeId);
   if(temp!=-1){ComboBox_TransType.setSelectedIndex(temp);}
  }
  if(Pend.CashInId!=-1){
   temp=PGUI.findLong(ComboMdlCashIn, 0, Pend.CashInId);
   if(temp!=-1){ComboBox_CashIn.setSelectedIndex(temp);}
  }
  TF_CashInComment.setText(PText.getString(Pend.CashInComment, "", false));
  if(Pend.CashOutId!=-1){
   temp=PGUI.findLong(ComboMdlCashOut, 0, Pend.CashOutId);
   if(temp!=-1){ComboBox_CashOut.setSelectedIndex(temp);}
  }
  TF_CashOutComment.setText(PText.getString(Pend.CashOutComment, "", false));
  if(Pend.CreditDays!=-1){TF_TransCreditDays.setText(String.valueOf(Pend.CreditDays)); updateValueTransCreditDays(true);}
		if(Pend.CreditDays==-1 || Pend.RepaymentPeriodStart==null || Pend.RepaymentPeriodEnd==null){
			CB_RepayPeriod.setSelected(false); CB_RepayPeriodActionPerformed(null);
		}
		else{
		 CB_RepayPeriod.setSelected(true); CB_RepayPeriodActionPerformed(null);
			TF_RepayPeriodStart.setText(PText.dateToString(Pend.RepaymentPeriodStart, 1));
			TF_RepayPeriodEnd.setText(PText.dateToString(Pend.RepaymentPeriodEnd, 1));
	 }
  if(Pend.Comment!=null){TA_TransComment.setText(Pend.Comment);}
  if(PendItemInCount!=0){
   temp=0;
   do{
    Row=PendItemIn.elementAt(temp);
    addItem((Long)Row[0], (String)Row[1], (Double)Row[3], PCore.objString(Row[4], null), (Double)Row[5], PCore.objString(Row[7], null), Row[10], Row[8], Row[9],
     TableMdlIn, QuickIdIn, InPrice);
    temp=temp+1;
   }while(temp!=PendItemInCount);
   refreshTotalCount(TF_InCount, TableMdlIn); refreshTotalPrice(TF_InPrice, InPrice);
  }
  if(PendItemOutCount!=0){
   temp=0;
   do{
    Row=PendItemOut.elementAt(temp);
    addItem((Long)Row[0], (String)Row[1], (Double)Row[3], PCore.objString(Row[4], null), (Double)Row[5], PCore.objString(Row[7], null), Row[10], Row[8], Row[9],
     TableMdlOut, QuickIdOut, OutPrice);
    temp=temp+1;
   }while(temp!=PendItemOutCount);
   refreshTotalCount(TF_OutCount, TableMdlOut); refreshTotalPrice(TF_OutPrice, OutPrice);
  }
  
  TF_ItemId.requestFocusInWindow();
 }//GEN-LAST:event_Btn_TransPendingLoadActionPerformed

 private void CB_RepayPeriodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_RepayPeriodActionPerformed
  enableInputRepayPeriod(CB_RepayPeriod.isSelected());
 }//GEN-LAST:event_CB_RepayPeriodActionPerformed

 private void ComboBox_TransDateMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_TransDateMonthActionPerformed
  updateValueTransDate(true);
 }//GEN-LAST:event_ComboBox_TransDateMonthActionPerformed

 private void ComboBox_TransDateDayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBox_TransDateDayActionPerformed
  updateValueTransDate(true);
 }//GEN-LAST:event_ComboBox_TransDateDayActionPerformed

 private void TF_RepayPeriodStartFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_RepayPeriodStartFocusGained
  TF_RepayPeriodStart.setBackground(CGUI.Color_TextBox_FocusOn);
		PGUI.text_SelectAll(TF_RepayPeriodStart);
 }//GEN-LAST:event_TF_RepayPeriodStartFocusGained

 private void TF_RepayPeriodStartFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_RepayPeriodStartFocusLost
  TF_RepayPeriodStart.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_RepayPeriodStartFocusLost

 private void TF_RepayPeriodEndFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_RepayPeriodEndFocusGained
  TF_RepayPeriodEnd.setBackground(CGUI.Color_TextBox_FocusOn);
		PGUI.text_SelectAll(TF_RepayPeriodEnd);
 }//GEN-LAST:event_TF_RepayPeriodEndFocusGained

 private void TF_RepayPeriodEndFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_RepayPeriodEndFocusLost
  TF_RepayPeriodEnd.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_RepayPeriodEndFocusLost

 private void TF_RepayPeriodStartKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_RepayPeriodStartKeyPressed
  PNav.onKey_TF(this, TF_RepayPeriodStart, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransCreditDays)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(ComboBox_TransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_RepayPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_RepayPeriodEnd)));
 }//GEN-LAST:event_TF_RepayPeriodStartKeyPressed

 private void TF_RepayPeriodEndKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_RepayPeriodEndKeyPressed
  PNav.onKey_TF(this, TF_RepayPeriodEnd, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransCreditDays)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(ComboBox_TransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_RepayPeriodStart, CB_RepayPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_RepayPeriodEndKeyPressed

 private void Lbl_RepayPeriodHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_RepayPeriodHelpMouseClicked
  JOptionPane.showMessageDialog(null,
			"- Isi inputan 'Periode Cicil' dgn tgl awal & tgl akhir dari masa periode cicil.\n"+
			"- Inputan 'Periode Cicil' bersifat opsional (boleh dikosongkan).\n"+
			"- Jika 'Periode Cicil' diisi, maka 'Lama Kredit' juga wajib diisi.\n"+
			"- Tanggal awal 'Periode Cicil' <= tanggal akhir 'Periode Cicil'.\n"+
			"- Tanggal akhir 'Periode Cicil' < 'Tanggal Tagih'."
		);
 }//GEN-LAST:event_Lbl_RepayPeriodHelpMouseClicked

 private void Btn_OutMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutMoveActionPerformed
  int[] rows=Tbl_Out.getSelectedRows();
  int temp, length;
  int insertpos;
  Object[] CurrData;
  
  length=rows.length;
  if(length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Pindahkan "+PText.intToString(length)+" barang yg dipilih ke daftar barang masuk ?",
   "Konfirmasi Pemindahan Barang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  temp=0;
  do{
   CurrData=TableMdlOut.Mdl.Rows.elementAt(rows[temp]);
   insertpos=addItem((Long)CurrData[0], (String)CurrData[1], (Double)CurrData[3], PCore.objString(CurrData[4], null),
    (Double)CurrData[5], PCore.objString(CurrData[7], null), TableMdlOut.getChecked(rows[temp]), CurrData[8], CurrData[9],
    TableMdlIn, QuickIdIn, InPrice);
   temp=temp+1;
  }while(temp!=length);
  refreshTotalCount(TF_InCount, TableMdlIn); refreshTotalPrice(TF_InPrice, InPrice);
  Tbl_In.changeSelection(insertpos, 0, false, false); onSelectedRowInChanged(true);
  
  removeItemOut(rows);
 }//GEN-LAST:event_Btn_OutMoveActionPerformed

 private void Btn_InMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InMoveActionPerformed
  int[] rows=Tbl_In.getSelectedRows();
  int temp, length;
  int insertpos;
  Object[] CurrData;
  
  length=rows.length;
  if(length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Pindahkan "+PText.intToString(length)+" barang yg dipilih ke daftar barang keluar ?",
   "Konfirmasi Pemindahan Barang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  temp=0;
  do{
   CurrData=TableMdlIn.Mdl.Rows.elementAt(rows[temp]);
   insertpos=addItem((Long)CurrData[0], (String)CurrData[1], (Double)CurrData[3], PCore.objString(CurrData[4], null),
    (Double)CurrData[5], PCore.objString(CurrData[7], null), TableMdlIn.getChecked(rows[temp]), CurrData[8], CurrData[9],
    TableMdlOut, QuickIdOut, OutPrice);
   temp=temp+1;
  }while(temp!=length);
  refreshTotalCount(TF_OutCount, TableMdlOut); refreshTotalPrice(TF_OutPrice, OutPrice);
  Tbl_Out.changeSelection(insertpos, 0, false, false); onSelectedRowOutChanged(true);
  
  removeItemIn(rows);
 }//GEN-LAST:event_Btn_InMoveActionPerformed

 private void Btn_ReprintLastTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReprintLastTransActionPerformed
  int IdExternalFit=20;
  
  if(LastTransId==-1){
   JOptionPane.showMessageDialog(null, "Tidak dapat mencetak ulang nota !"+
    "\nBelum ada data "+TransName+" terakhir yg diinput !");
   return;
  }
  
  if(JOptionPane.showConfirmDialog(null, "Cetak ulang nota dari "+TransName+" dengan Id {Ext} : "+LastTransId+
   PText.getString(PText.isEmptyString(LastTransIdExternal, true, true), "",
   " {"+PText.fitString(LastTransIdExternal, IdExternalFit, false, IdExternalFit-1, 1, '~')+"}")+" ?",
   "Konfirmasi Pencetakan Ulang Nota Dari "+TransName, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
   return;
  }
  
  printReceipt(LastTransId, true);
 }//GEN-LAST:event_Btn_ReprintLastTransActionPerformed

 private void Lbl_TransIdExternalHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_TransIdExternalHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Id External = keterangan bukti fisik nota."+"\n"+
   PText.getInputInfo(true, 100, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_TransIdExternalHelpMouseClicked

 private void TF_TransIdExternalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransIdExternalFocusGained
  TF_TransIdExternal.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_TransIdExternal);
 }//GEN-LAST:event_TF_TransIdExternalFocusGained

 private void TF_TransIdExternalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_TransIdExternalFocusLost
  TF_TransIdExternal.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_TransIdExternalFocusLost

 private void TF_TransIdExternalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransIdExternalKeyPressed
  PNav.onKey_TF(this, TF_TransIdExternal, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_TransImportant)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransDateYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_TransIdExternalKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_TransIdExternalKeyPressed

 private void Btn_OutCheckAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutCheckAddActionPerformed
  addCheck(false, true);
 }//GEN-LAST:event_Btn_OutCheckAddActionPerformed

 private void Btn_OutCheckRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutCheckRemoveActionPerformed
  addCheck(false, false);
 }//GEN-LAST:event_Btn_OutCheckRemoveActionPerformed

 private void Btn_InCheckAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InCheckAddActionPerformed
  addCheck(true, true);
 }//GEN-LAST:event_Btn_InCheckAddActionPerformed

 private void Btn_InCheckRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InCheckRemoveActionPerformed
  addCheck(true, false);
 }//GEN-LAST:event_Btn_InCheckRemoveActionPerformed

 private void TF_CashInCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CashInCommentFocusGained
  TF_CashInComment.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_CashInComment);
 }//GEN-LAST:event_TF_CashInCommentFocusGained

 private void TF_CashOutCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CashOutCommentFocusGained
  TF_CashOutComment.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_CashOutComment);
 }//GEN-LAST:event_TF_CashOutCommentFocusGained

 private void TF_CashOutCommentFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CashOutCommentFocusLost
  TF_CashOutComment.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_CashOutCommentFocusLost

 private void TF_CashInCommentFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CashInCommentFocusLost
  TF_CashInComment.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_CashInCommentFocusLost

 private void TF_CashInCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CashInCommentKeyPressed
  PNav.onKey_TF(this, TF_CashInComment, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(ComboBox_CashIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(ComboBox_CashOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_CashInCommentKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_CashInCommentKeyPressed

 private void TF_CashOutCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CashOutCommentKeyPressed
  PNav.onKey_TF(this, TF_CashOutComment, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(ComboBox_CashOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseSubject)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_CashOutCommentKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_CashOutCommentKeyPressed

 private void Lbl_CashOutCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CashOutCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_CashOutCommentHelpMouseClicked

 private void Lbl_CashInCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CashInCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_CashInCommentHelpMouseClicked

 private void Tbl_InKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_InKeyReleased
  onSelectedRowInChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_In, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FindItemIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_InCheckAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_InCheckRemoveActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_Tbl_InKeyReleased

 private void Tbl_InMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_InMouseReleased
  onSelectedRowInChanged(false);
 }//GEN-LAST:event_Tbl_InMouseReleased

 private void Tbl_OutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_OutKeyReleased
  onSelectedRowOutChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Out, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FindItemOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_OutCheckAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_OutCheckRemoveActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_Tbl_OutKeyReleased

 private void Tbl_OutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_OutMouseReleased
  onSelectedRowOutChanged(false);
 }//GEN-LAST:event_Tbl_OutMouseReleased

 private void Pnl_ItemInPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_In, TableMdlIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInPreviewMouseClicked

 private void Pnl_ItemOutPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Out, TableMdlOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutPreviewMouseClicked

 private void TF_TransSubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TransSubjectMouseClicked
  if(TransSubjectId==-1){return;}
  PMyShop.viewFormInfo(TransSubjectId, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_TransSubjectMouseClicked

 private void TF_TransSalesmanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TransSalesmanMouseClicked
  if(TransSalesmanId==-1){return;}
  PMyShop.viewFormInfo(TransSalesmanId, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_TransSalesmanMouseClicked

 private void CmB_PriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_PriceActionPerformed
  fillInputInfoPrice();
 }//GEN-LAST:event_CmB_PriceActionPerformed

 private void TA_ItemNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_ItemNameMouseClicked
  if(I_CheckedId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_ItemNameMouseClicked

 private void CB_ReceiptKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ReceiptKeyPressed
  PNav.onKey_CB(this, CB_Receipt, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_TransId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_ReceiptPaper)));
 }//GEN-LAST:event_CB_ReceiptKeyPressed

 private void ComboBox_ReceiptPaperKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_ReceiptPaperKeyPressed
  PNav.onKey_CmB(this, ComboBox_ReceiptPaper, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Receipt)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_ReceiptPrinter)));
 }//GEN-LAST:event_ComboBox_ReceiptPaperKeyPressed

 private void ComboBox_ReceiptPrinterKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_ReceiptPrinterKeyPressed
  PNav.onKey_CmB(this, ComboBox_ReceiptPrinter, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_ReceiptPaper)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_TransId)));
 }//GEN-LAST:event_ComboBox_ReceiptPrinterKeyPressed

 private void RB_TransIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_TransIdKeyPressed
  PNav.onKey_RB(this, RB_TransId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Receipt)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_TransIdExternal)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransPendingLoad)));
 }//GEN-LAST:event_RB_TransIdKeyPressed

 private void Btn_TransPendingLoadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TransPendingLoadKeyPressed
  PNav.onKey_Btn(this, Btn_TransPendingLoad, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Receipt)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransIdExternal)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_TransId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_TransImportant)));
 }//GEN-LAST:event_Btn_TransPendingLoadKeyPressed

 private void RB_TransIdExternalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_TransIdExternalKeyPressed
  PNav.onKey_RB(this, RB_TransIdExternal, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_TransId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransDateYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_TransIdExternalKeep)));
 }//GEN-LAST:event_RB_TransIdExternalKeyPressed

 private void CB_TransIdExternalKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransIdExternalKeepKeyPressed
  PNav.onKey_CB(this, CB_TransIdExternalKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_TransId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_TransDateYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_TransIdExternal)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_TransIdExternal)));
 }//GEN-LAST:event_CB_TransIdExternalKeepKeyPressed

 private void CB_TransCreditDaysKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransCreditDaysKeepKeyPressed
  PNav.onKey_CB(this, CB_TransCreditDaysKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransDateYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_RepayPeriodKeep)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_TransCreditDays)));
 }//GEN-LAST:event_CB_TransCreditDaysKeepKeyPressed

 private void CB_RepayPeriodKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_RepayPeriodKeepKeyPressed
  PNav.onKey_CB(this, CB_RepayPeriodKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_TransCreditDaysKeep)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(ComboBox_TransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_RepayPeriod)));
 }//GEN-LAST:event_CB_RepayPeriodKeepKeyPressed

 private void CB_RepayPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_RepayPeriodKeyPressed
  PNav.onKey_CB(this, CB_RepayPeriod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_TransCreditDays)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(ComboBox_TransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_RepayPeriodKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_RepayPeriodStart)));
 }//GEN-LAST:event_CB_RepayPeriodKeyPressed

 private void CB_CashInCommentKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CashInCommentKeepKeyPressed
  PNav.onKey_CB(this, CB_CashInCommentKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(ComboBox_CashIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(ComboBox_CashOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CashInComment)));
 }//GEN-LAST:event_CB_CashInCommentKeepKeyPressed

 private void CB_CashOutCommentKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CashOutCommentKeepKeyPressed
  PNav.onKey_CB(this, CB_CashOutCommentKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(ComboBox_CashOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_TransSubjectKeep)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CashOutComment)));
 }//GEN-LAST:event_CB_CashOutCommentKeepKeyPressed

 private void CB_TransSubjectKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransSubjectKeepKeyPressed
  PNav.onKey_CB(this, CB_TransSubjectKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_CashOutCommentKeep)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_TransSalesmanKeep)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseSubject)));
 }//GEN-LAST:event_CB_TransSubjectKeepKeyPressed

 private void CB_TransSalesmanKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransSalesmanKeepKeyPressed
  PNav.onKey_CB(this, CB_TransSalesmanKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_TransSubjectKeep)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseSalesman)));
 }//GEN-LAST:event_CB_TransSalesmanKeepKeyPressed

 private void RB_AddItemInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_AddItemInKeyPressed
  PNav.onKey_RB(this, RB_AddItemIn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_AddItemOut)));
 }//GEN-LAST:event_RB_AddItemInKeyPressed

 private void RB_AddItemOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_AddItemOutKeyPressed
  PNav.onKey_RB(this, RB_AddItemOut, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseSalesman)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_AddItem)));
 }//GEN-LAST:event_RB_AddItemOutKeyPressed

 private void CB_ItemIdEnterAutoAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ItemIdEnterAutoAddKeyPressed
  PNav.onKey_CB(this, CB_ItemIdEnterAutoAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_AddItemIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseItem)));
 }//GEN-LAST:event_CB_ItemIdEnterAutoAddKeyPressed

 private void CmB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PriceKeyPressed
  PNav.onKey_CmB(this, CmB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_PriceUnit)));
 }//GEN-LAST:event_CmB_PriceKeyPressed

 private void RB_PriceUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_PriceUnitKeyPressed
  PNav.onKey_RB(this, RB_PriceUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_PriceTotal)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PriceUnit)));
 }//GEN-LAST:event_RB_PriceUnitKeyPressed

 private void RB_PriceTotalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_PriceTotalKeyPressed
  PNav.onKey_RB(this, RB_PriceTotal, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_PriceUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PriceTotal)));
 }//GEN-LAST:event_RB_PriceTotalKeyPressed

 private void RB_FindItemOutIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_FindItemOutIdKeyPressed
  PNav.onKey_RB(this, RB_FindItemOutId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_FindItemOutName)));
 }//GEN-LAST:event_RB_FindItemOutIdKeyPressed

 private void RB_FindItemOutNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_FindItemOutNameKeyPressed
  PNav.onKey_RB(this, RB_FindItemOutName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_FindItemOutId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_FindItemOut)));
 }//GEN-LAST:event_RB_FindItemOutNameKeyPressed

 private void Btn_FindItemOutBefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FindItemOutBefKeyPressed
  PNav.onKey_Btn(this, Btn_FindItemOutBef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_FindItemOut)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemOutNext)));
 }//GEN-LAST:event_Btn_FindItemOutBefKeyPressed

 private void Btn_FindItemOutNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FindItemOutNextKeyPressed
  PNav.onKey_Btn(this, Btn_FindItemOutNext, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FindItemOutBef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_ItemOutKeep)));
 }//GEN-LAST:event_Btn_FindItemOutNextKeyPressed

 private void CB_ItemOutKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ItemOutKeepKeyPressed
  PNav.onKey_CB(this, CB_ItemOutKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FindItemOutNext)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_OutMove)));
 }//GEN-LAST:event_CB_ItemOutKeepKeyPressed

 private void Btn_OutMoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OutMoveKeyPressed
  PNav.onKey_Btn(this, Btn_OutMove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ItemOutKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_OutRemove)));
 }//GEN-LAST:event_Btn_OutMoveKeyPressed

 private void Btn_OutRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OutRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_OutRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_OutMove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_OutEdit)));
 }//GEN-LAST:event_Btn_OutRemoveKeyPressed

 private void Btn_OutEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OutEditKeyPressed
  PNav.onKey_Btn(this, Btn_OutEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_OutRemove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_OutCheckAdd)));
 }//GEN-LAST:event_Btn_OutEditKeyPressed

 private void Btn_OutCheckAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OutCheckAddKeyPressed
  PNav.onKey_Btn(this, Btn_OutCheckAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_OutEdit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_OutCheckRemove)));
 }//GEN-LAST:event_Btn_OutCheckAddKeyPressed

 private void Btn_OutCheckRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OutCheckRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_OutCheckRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_OutCheckAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_OutCheckRemoveKeyPressed

 private void RB_FindItemInIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_FindItemInIdKeyPressed
  PNav.onKey_RB(this, RB_FindItemInId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_FindItemInName)));
 }//GEN-LAST:event_RB_FindItemInIdKeyPressed

 private void RB_FindItemInNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_FindItemInNameKeyPressed
  PNav.onKey_RB(this, RB_FindItemInName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_FindItemInId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_FindItemIn)));
 }//GEN-LAST:event_RB_FindItemInNameKeyPressed

 private void Btn_FindItemInBefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FindItemInBefKeyPressed
  PNav.onKey_Btn(this, Btn_FindItemInBef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_FindItemIn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemInNext)));
 }//GEN-LAST:event_Btn_FindItemInBefKeyPressed

 private void Btn_FindItemInNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FindItemInNextKeyPressed
  PNav.onKey_Btn(this, Btn_FindItemInNext, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FindItemInBef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_ItemInKeep)));
 }//GEN-LAST:event_Btn_FindItemInNextKeyPressed

 private void CB_ItemInKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ItemInKeepKeyPressed
  PNav.onKey_CB(this, CB_ItemInKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FindItemInNext)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InMove)));
 }//GEN-LAST:event_CB_ItemInKeepKeyPressed

 private void Btn_InMoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InMoveKeyPressed
  PNav.onKey_Btn(this, Btn_InMove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ItemInKeep)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InRemove)));
 }//GEN-LAST:event_Btn_InMoveKeyPressed

 private void Btn_InRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_InRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InMove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InEdit)));
 }//GEN-LAST:event_Btn_InRemoveKeyPressed

 private void Btn_InEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InEditKeyPressed
  PNav.onKey_Btn(this, Btn_InEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InRemove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InCheckAdd)));
 }//GEN-LAST:event_Btn_InEditKeyPressed

 private void Btn_InCheckAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InCheckAddKeyPressed
  PNav.onKey_Btn(this, Btn_InCheckAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InEdit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_InCheckRemove)));
 }//GEN-LAST:event_Btn_InCheckAddKeyPressed

 private void Btn_InCheckRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_InCheckRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_InCheckRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_InCheckAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_InCheckRemoveKeyPressed

 private void TA_TransCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_TransCommentKeyPressed
  PNav.onKey_TA(this, TA_TransComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_TransCommentKeep)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_TransCommentKeyPressed

 private void CB_TransCommentKeepKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_TransCommentKeepKeyPressed
  PNav.onKey_CB(this, CB_TransCommentKeep, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_TransFinish)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_TransComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_TransCommentKeepKeyPressed

 private void Btn_ReprintLastTransKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ReprintLastTransKeyPressed
  PNav.onKey_Btn(this, Btn_ReprintLastTrans, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TabbedPane)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransPending)));
 }//GEN-LAST:event_Btn_ReprintLastTransKeyPressed

 private void Btn_TransPendingKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TransPendingKeyPressed
  PNav.onKey_Btn(this, Btn_TransPending, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TabbedPane)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ReprintLastTrans)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_TransCancel)));
 }//GEN-LAST:event_Btn_TransPendingKeyPressed

 private void CB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PriceKeyPressed
  PNav.onKey_CB(this, CB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_Price)));
 }//GEN-LAST:event_CB_PriceKeyPressed

 private void TF_TransItemCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_TransItemCommentKeyPressed
  PNav.onKey_TF(this, TF_TransItemComment, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_TransItemCommentKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_AddItem;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_ChooseSalesman;
 private javax.swing.JButton Btn_ChooseSubject;
 private javax.swing.JButton Btn_ClearChoosedSalesman;
 private javax.swing.JButton Btn_ClearChoosedSubject;
 private javax.swing.JButton Btn_FindItemInBef;
 private javax.swing.JButton Btn_FindItemInNext;
 private javax.swing.JButton Btn_FindItemOutBef;
 private javax.swing.JButton Btn_FindItemOutNext;
 private javax.swing.JButton Btn_InCheckAdd;
 private javax.swing.JButton Btn_InCheckRemove;
 private javax.swing.JButton Btn_InEdit;
 private javax.swing.JButton Btn_InMove;
 private javax.swing.JButton Btn_InRemove;
 private javax.swing.JButton Btn_OutCheckAdd;
 private javax.swing.JButton Btn_OutCheckRemove;
 private javax.swing.JButton Btn_OutEdit;
 private javax.swing.JButton Btn_OutMove;
 private javax.swing.JButton Btn_OutRemove;
 private javax.swing.JButton Btn_ReprintLastTrans;
 private javax.swing.JButton Btn_TransCancel;
 private javax.swing.JButton Btn_TransFinish;
 private javax.swing.JButton Btn_TransPending;
 private javax.swing.JButton Btn_TransPendingLoad;
 private javax.swing.JCheckBox CB_CashInCommentKeep;
 private javax.swing.JCheckBox CB_CashOutCommentKeep;
 private javax.swing.JCheckBox CB_ItemIdEnterAutoAdd;
 private javax.swing.JCheckBox CB_ItemInKeep;
 private javax.swing.JCheckBox CB_ItemOutKeep;
 private javax.swing.JCheckBox CB_ItemUpStock;
 private javax.swing.JCheckBox CB_Price;
 private javax.swing.JCheckBox CB_Receipt;
 private javax.swing.JCheckBox CB_RepayPeriod;
 private javax.swing.JCheckBox CB_RepayPeriodKeep;
 private javax.swing.JCheckBox CB_TransCommentKeep;
 private javax.swing.JCheckBox CB_TransCreditDaysKeep;
 private javax.swing.JCheckBox CB_TransIdExternalKeep;
 private javax.swing.JCheckBox CB_TransImportant;
 private javax.swing.JCheckBox CB_TransSalesmanKeep;
 private javax.swing.JCheckBox CB_TransSubjectKeep;
 private javax.swing.JComboBox<String> CmB_Price;
 private javax.swing.JComboBox<String> ComboBox_CashIn;
 private javax.swing.JComboBox<String> ComboBox_CashOut;
 private javax.swing.JComboBox<String> ComboBox_ReceiptPaper;
 private javax.swing.JComboBox<String> ComboBox_ReceiptPrinter;
 private javax.swing.JComboBox ComboBox_TransDateDay;
 private javax.swing.JComboBox ComboBox_TransDateMonth;
 private javax.swing.JComboBox ComboBox_TransType;
 private javax.swing.JLabel Lbl_CashIn;
 private javax.swing.JLabel Lbl_CashInCommentHelp;
 private javax.swing.JLabel Lbl_CashOut;
 private javax.swing.JLabel Lbl_CashOutCommentHelp;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_Quantity;
 private javax.swing.JLabel Lbl_RepayPeriod;
 private javax.swing.JLabel Lbl_RepayPeriodHelp;
 private javax.swing.JLabel Lbl_TransComment;
 private javax.swing.JLabel Lbl_TransCreditDays;
 private javax.swing.JLabel Lbl_TransCreditDaysHelp;
 private javax.swing.JLabel Lbl_TransDate;
 private javax.swing.JLabel Lbl_TransIdExternalHelp;
 private javax.swing.JLabel Lbl_TransSalesman;
 private javax.swing.JLabel Lbl_TransSubject;
 private javax.swing.JLabel Lbl_TransType;
 private javax.swing.JPanel Panel_AddItem;
 private javax.swing.JPanel Panel_AddItemDet;
 private javax.swing.JPanel Panel_ItemIn;
 private javax.swing.JPanel Panel_ItemOut;
 private XImgBoxURL Pnl_ItemInPreview;
 private XImgBoxURL Pnl_ItemOutPreview;
 private javax.swing.JPanel Pnl_TransAdditional;
 private javax.swing.JRadioButton RB_AddItemIn;
 private javax.swing.JRadioButton RB_AddItemOut;
 private javax.swing.JRadioButton RB_FindItemInId;
 private javax.swing.JRadioButton RB_FindItemInName;
 private javax.swing.JRadioButton RB_FindItemOutId;
 private javax.swing.JRadioButton RB_FindItemOutName;
 private javax.swing.JRadioButton RB_PriceTotal;
 private javax.swing.JRadioButton RB_PriceUnit;
 private javax.swing.JRadioButton RB_TransId;
 private javax.swing.JRadioButton RB_TransIdExternal;
 private javax.swing.ButtonGroup RG_AddItem;
 private javax.swing.ButtonGroup RG_FindItemIn;
 private javax.swing.ButtonGroup RG_FindItemOut;
 private javax.swing.ButtonGroup RG_MainId;
 private javax.swing.ButtonGroup RG_Price;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextArea TA_ItemPriceComment;
 private javax.swing.JTextArea TA_TransComment;
 private javax.swing.JTextField TF_CashInComment;
 private javax.swing.JTextField TF_CashOutComment;
 private javax.swing.JTextField TF_CreditDaysInfo;
 private javax.swing.JTextField TF_FindItemIn;
 private javax.swing.JTextField TF_FindItemOut;
 private javax.swing.JTextField TF_InCount;
 private javax.swing.JTextArea TF_InInfo;
 private javax.swing.JTextField TF_InPrice;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_ItemStock;
 private javax.swing.JTextField TF_OutCount;
 private javax.swing.JTextArea TF_OutInfo;
 private javax.swing.JTextField TF_OutPrice;
 private javax.swing.JTextField TF_PriceTotal;
 private javax.swing.JTextField TF_PriceUnit;
 private javax.swing.JTextField TF_Quantity;
 private javax.swing.JTextField TF_RepayPeriodEnd;
 private javax.swing.JTextField TF_RepayPeriodStart;
 private javax.swing.JTextField TF_TransCreditDays;
 private javax.swing.JTextField TF_TransDateYear;
 private javax.swing.JTextField TF_TransId;
 private javax.swing.JTextField TF_TransIdExternal;
 private javax.swing.JTextField TF_TransItemComment;
 private javax.swing.JTextField TF_TransSalesman;
 private javax.swing.JTextField TF_TransSubject;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_In;
 private XTable Tbl_Out;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 private javax.swing.JSeparator jSeparator6;
 private javax.swing.JSeparator jSeparator7;
 private javax.swing.JSeparator jSeparator8;
 private javax.swing.JSeparator jSeparator9;
 // End of variables declaration//GEN-END:variables

 
}
