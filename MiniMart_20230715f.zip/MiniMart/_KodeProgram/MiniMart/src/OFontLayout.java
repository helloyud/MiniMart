public class OFontLayout {

 float PointSize;
 boolean IsItalic;
 boolean IsBold;

 public OFontLayout(float PointSize, boolean IsBold, boolean IsItalic) {
  this.PointSize = PointSize;
  this.IsBold = IsBold;
  this.IsItalic = IsItalic;
 }

}