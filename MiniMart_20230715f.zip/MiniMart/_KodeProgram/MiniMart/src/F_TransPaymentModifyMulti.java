import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class F_TransPaymentModifyMulti extends XFormDialog {
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeDate;
 Date PayDate;
 boolean ChangeCash;
 int CashId;
 String CashName;
 boolean ChangePrice;
 double Price;
 boolean ChangeComment;
 boolean ChangeCommentSub;
 String CommentSub;
 String Comment;
 
 public F_TransPaymentModifyMulti(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  CB_CommentSubActionPerformed(null);
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_Date, TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay,
    CB_Cash, Btn_ChooseCash, Btn_ClearChoosedCash,
    CB_Price, TF_Price,
    CB_Comment, TF_CommentSub, CB_CommentSub, TA_Comment,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 
 void clearComponents(){
  CB_Date.setSelected(false); CB_Date.setForeground(CGUI.Color_Label_InputRight);
  PGUI.clearDateComponent(TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay);
  CB_Cash.setSelected(false);
  TF_Cash.setText("");
  CB_Price.setSelected(false); CB_Price.setForeground(CGUI.Color_Label_InputRight);
  TF_Price.setText("");
  CB_Comment.setSelected(false); CB_Comment.setForeground(CGUI.Color_Label_InputRight);
  TF_CommentSub.setText(""); TA_Comment.setText("");
  clearSetVariables();
 }
 void clearSetVariables(){
  
 }
 
 void enableInputInTextField(boolean Enable, JTextField TF){
  TF.setEnabled(Enable);
  if(!TF.isEnabled()){TF.setText("");}
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_DateYear = new javax.swing.JTextField();
  TF_Price = new javax.swing.JTextField();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_PriceHelp = new javax.swing.JLabel();
  ComboBox_DateDay = new javax.swing.JComboBox<>();
  ComboBox_DateMonth = new javax.swing.JComboBox<>();
  Lbl_CommentHelp = new javax.swing.JLabel();
  TF_Cash = new javax.swing.JTextField();
  Btn_ClearChoosedCash = new javax.swing.JButton();
  Btn_ChooseCash = new javax.swing.JButton();
  CB_Date = new javax.swing.JCheckBox();
  CB_Cash = new javax.swing.JCheckBox();
  CB_Price = new javax.swing.JCheckBox();
  CB_Comment = new javax.swing.JCheckBox();
  Lbl_DataCount = new javax.swing.JLabel();
  TF_CommentSub = new javax.swing.JTextField();
  CB_CommentSub = new javax.swing.JCheckBox();

  setTitle("Ubah Beberapa Data Pembayaran Pada Suatu ransaksi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_DateYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_DateYearFocusGained(evt);
   }
  });
  TF_DateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_DateYearKeyPressed(evt);
   }
  });

  TF_Price.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PriceFocusGained(evt);
   }
  });
  TF_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PriceKeyPressed(evt);
   }
  });

  TA_Comment.setColumns(20);
  TA_Comment.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_Comment.setLineWrap(true);
  TA_Comment.setWrapStyleWord(true);
  TA_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_Comment);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_PriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_PriceHelp.setText("(?)");
  Lbl_PriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_PriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PriceHelpMouseClicked(evt);
   }
  });

  ComboBox_DateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_DateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_DateDayKeyPressed(evt);
   }
  });

  ComboBox_DateMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  ComboBox_DateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_DateMonthKeyPressed(evt);
   }
  });

  Lbl_CommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentHelp.setText("(?)");
  Lbl_CommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentHelpMouseClicked(evt);
   }
  });

  TF_Cash.setEditable(false);
  TF_Cash.setBackground(new java.awt.Color(204, 255, 204));

  Btn_ClearChoosedCash.setText("-");
  Btn_ClearChoosedCash.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearChoosedCash.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearChoosedCashActionPerformed(evt);
   }
  });
  Btn_ClearChoosedCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearChoosedCashKeyPressed(evt);
   }
  });

  Btn_ChooseCash.setText("...");
  Btn_ChooseCash.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseCash.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseCashActionPerformed(evt);
   }
  });
  Btn_ChooseCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseCashKeyPressed(evt);
   }
  });

  CB_Date.setText("Tanggal");
  CB_Date.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Date.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_DateKeyPressed(evt);
   }
  });

  CB_Cash.setText("Kas Kredit");
  CB_Cash.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Cash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CashKeyPressed(evt);
   }
  });

  CB_Price.setText("Jumlah");
  CB_Price.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Price.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PriceKeyPressed(evt);
   }
  });

  CB_Comment.setText("Ket.");
  CB_Comment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentKeyPressed(evt);
   }
  });

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data");

  TF_CommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CommentSubKeyPressed(evt);
   }
  });

  CB_CommentSub.setText("Ganti Sub-Kata");
  CB_CommentSub.setToolTipText("centang opsi ini utk mengganti sub-kata");
  CB_CommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_CommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_CommentSubActionPerformed(evt);
   }
  });
  CB_CommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentSubKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Lbl_DataCount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_Date)
       .addComponent(CB_Cash)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_Price)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_PriceHelp))
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_Comment)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_CommentHelp)))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_Cash)
        .addGap(0, 0, 0)
        .addComponent(Btn_ChooseCash)
        .addGap(3, 3, 3)
        .addComponent(Btn_ClearChoosedCash))
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_DateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(ComboBox_DateMonth, 0, 238, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(ComboBox_DateDay, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_CommentSub)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_CommentSub))
       .addComponent(TF_Price))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_DateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_DateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Date))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Cash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ClearChoosedCash)
     .addComponent(Btn_ChooseCash)
     .addComponent(CB_Cash))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PriceHelp)
     .addComponent(CB_Price))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_CommentHelp)
     .addComponent(CB_Comment)
     .addComponent(TF_CommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_CommentSub))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)
     .addComponent(Lbl_DataCount))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrCheck=false;
  
  ChangeDate=CB_Date.isSelected();
  ChangeCash=CB_Cash.isSelected();
  ChangePrice=CB_Price.isSelected();
  ChangeComment=CB_Comment.isSelected();
  if(!ChangeDate && !ChangeCash && !ChangePrice && !ChangeComment){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  // check
  IsValid=true;
  
  if(ChangeDate){
   PayDate=PGUI.valueOfDateComponent(TF_DateYear, ComboBox_DateMonth, ComboBox_DateDay);
   if(PayDate==null){IsValid=false; CB_Date.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Date.setForeground(CGUI.Color_Label_InputRight);}
  }
   
  if(ChangePrice){
   try{Price=Double.parseDouble(TF_Price.getText());}catch(Exception E){Price=-1;}
   if(Price<=0){IsValid=false; CB_Price.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Price.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeComment){
   Comment=TA_Comment.getText();
   ChangeCommentSub=CB_CommentSub.isSelected();
   if(!ChangeCommentSub){CurrCheck=PText.checkInput(Comment, true, CApp.DbVarcharMaxSize, 0, 1, 1, 0);}
   else{
    CommentSub=TF_CommentSub.getText();
    CurrCheck=CommentSub.length()!=0;
   }
   if(!CurrCheck){IsValid=false; CB_Comment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Comment.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+
    "Silahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Lbl_CommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true)+"\n"+
   "- Dalam mode 'Ganti Sub-Kata', inputan 'Ganti Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Keterangan' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_CommentHelpMouseClicked

 private void Lbl_PriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_PriceHelpMouseClicked

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(!Activ){
   Activ=true;
   
   Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data");
   CashId=-1;
   
   TF_Price.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_ChooseCashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseCashActionPerformed
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=false;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCash;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   CashId=(int)IFV.FDataIdName.DataId[0];
   CashName=IFV.FDataIdName.DataName[0];
   TF_Cash.setText(CashName);
  }
 }//GEN-LAST:event_Btn_ChooseCashActionPerformed

 private void Btn_ClearChoosedCashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedCashActionPerformed
  CashId=-1;
  TF_Cash.setText("");
 }//GEN-LAST:event_Btn_ClearChoosedCashActionPerformed

 private void CB_CommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_CommentSubActionPerformed
  enableInputInTextField(CB_CommentSub.isSelected(), TF_CommentSub);
 }//GEN-LAST:event_CB_CommentSubActionPerformed

 private void CB_DateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_DateKeyPressed
  PNav.onKey_CB(this, CB_Date, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Cash)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_DateYear)));
 }//GEN-LAST:event_CB_DateKeyPressed

 private void TF_DateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_DateYearKeyPressed
  PNav.onKey_TF(this, TF_DateYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseCash)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Date)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_DateMonth)));
 }//GEN-LAST:event_TF_DateYearKeyPressed

 private void ComboBox_DateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_DateMonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_DateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_DateYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_DateDay)));
 }//GEN-LAST:event_ComboBox_DateMonthKeyPressed

 private void ComboBox_DateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_DateDayKeyPressed
  PNav.onKey_CmB(this, ComboBox_DateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_DateMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseCash)));
 }//GEN-LAST:event_ComboBox_DateDayKeyPressed

 private void CB_CashKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CashKeyPressed
  PNav.onKey_CB(this, CB_Cash, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Date)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Price)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseCash)));
 }//GEN-LAST:event_CB_CashKeyPressed

 private void Btn_ChooseCashKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseCashKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseCash, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DateYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Price)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Cash)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearChoosedCash)));
 }//GEN-LAST:event_Btn_ChooseCashKeyPressed

 private void Btn_ClearChoosedCashKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedCashKeyPressed
  PNav.onKey_Btn(this, Btn_ClearChoosedCash, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DateYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Price)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseCash)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ClearChoosedCashKeyPressed

 private void CB_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PriceKeyPressed
  PNav.onKey_CB(this, CB_Price, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Cash)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Price)));
 }//GEN-LAST:event_CB_PriceKeyPressed

 private void TF_PriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PriceKeyPressed
  PNav.onKey_TF(this, TF_Price, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseCash)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Price)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_PriceKeyPressed

 private void CB_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentKeyPressed
  PNav.onKey_CB(this, CB_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Price)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)));
 }//GEN-LAST:event_CB_CommentKeyPressed

 private void TF_CommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CommentSubKeyPressed
  PNav.onKey_TF(this, TF_CommentSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Price)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_CommentSub)));
 }//GEN-LAST:event_TF_CommentSubKeyPressed

 private void CB_CommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentSubKeyPressed
  PNav.onKey_CB(this, CB_CommentSub, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Price)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CommentSub, CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_CommentSubKeyPressed

 private void TA_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentKeyPressed
  PNav.onKey_TA(this, TA_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CommentSub, CB_CommentSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_CommentKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_DateYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_DateYearFocusGained
  PGUI.text_SelectAll(TF_DateYear);
 }//GEN-LAST:event_TF_DateYearFocusGained

 private void TF_PriceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PriceFocusGained
  PGUI.text_SelectAll(TF_Price);
 }//GEN-LAST:event_TF_PriceFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseCash;
 private javax.swing.JButton Btn_ClearChoosedCash;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_Cash;
 private javax.swing.JCheckBox CB_Comment;
 private javax.swing.JCheckBox CB_CommentSub;
 private javax.swing.JCheckBox CB_Date;
 private javax.swing.JCheckBox CB_Price;
 private javax.swing.JComboBox<String> ComboBox_DateDay;
 private javax.swing.JComboBox<String> ComboBox_DateMonth;
 private javax.swing.JLabel Lbl_CommentHelp;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.JLabel Lbl_PriceHelp;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextField TF_Cash;
 private javax.swing.JTextField TF_CommentSub;
 private javax.swing.JTextField TF_DateYear;
 private javax.swing.JTextField TF_Price;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
