public class OCalculationResult {
 double Result;
}