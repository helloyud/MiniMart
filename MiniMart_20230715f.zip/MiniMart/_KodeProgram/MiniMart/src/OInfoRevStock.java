import java.util.Date;

public class OInfoRevStock {
 
 long Id;
 Date RevDate;
 int ReasonOfRevisiId; String ReasonOfRevisiName;
 
 long ItemId; String ItemName;
 
 double StockOld;
 double StockNew;
 double StockDiff;
 
 int StockUnitId; String StockUnitName;
 boolean UpdateStock;
 int CategoryId; String CategoryName;
 
}