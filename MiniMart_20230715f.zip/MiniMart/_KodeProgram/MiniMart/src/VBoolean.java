public class VBoolean {

 boolean Value;
 
 public VBoolean(){}
 public VBoolean(boolean Value) {this.Value = Value;}
 
}