
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableColumnModel;

public class F_TransPending extends XFormDialog {

 // set
 boolean wIsViewMode; // true = view mode, false = choose mode
 boolean wIsPreTrans;
 boolean wAllowMultipleChoose;

 // get
 Long[] ChoosedId;

 //
 String DbTable;
 String DbTransPendLock;
 String DbTransLock;
 String TransName;

 // table trans
 OCustomTableModel TableMdlTrans;
 String[] TableMdlTransColsName;
 int[] TableMdlTransColsType, TableMdlTransColsShowOption, TableMdlTransColsVisible, TableTransColsWidth;
 String QueryTransOrderBy, QueryTransTbHaving;
 int LastSelectedRowTrans;

 // index
 boolean TIRequeryAll;

 // tab detail
 boolean TIDet;
 boolean TIDetClear;

 // tab item in & out
 OCustomTableModel TableMdlIn;
 String[] TableMdlItemInColsName;
 int[] TableMdlItemInColsType, TableMdlItemInColsShowOption, TableMdlItemInColsVisible, TableItemInColsWidth;
 String QueryItemInOrderBy, QueryItemInTbHaving;
 boolean TIIn; // table re-query sign
 boolean TIInClear; // table-content cleared sign
 int LastSelectedRowIn;
 boolean InfoInClear; // panel-info cleared sign

 OCustomTableModel TableMdlOut;
 String[] TableMdlItemOutColsName;
 int[] TableMdlItemOutColsType, TableMdlItemOutColsShowOption, TableMdlItemOutColsVisible, TableItemOutColsWidth;
 String QueryItemOutOrderBy, QueryItemOutTbHaving;
 boolean TIOut; // table re-query sign
 boolean TIOutClear; // table-content cleared sign
 int LastSelectedRowOut;
 boolean InfoOutClear; // panel-info cleared sign

 /**
  * Creates new form F_TransView
  */
 public F_TransPending(MInterFormVariables IFV_) {
  String[] ColName;
  int[] ColType;
  int[] ColVisible;
  TableColumnModel ColMdl;

  preInitComponents();
  initComponents();
  postInitComponents();

  IFV = IFV_;
  Activ = false;

  onKeyPress();

  // table trans
  TableMdlTrans = new OCustomTableModel();
  Tbl_Trans.setModel(TableMdlTrans);
  TableMdlTransColsName = PCore.refArr(
   "Id Pending", "Id Transaksi", "{Id-Ext}", "Penting", "Jenis",
   "Tanggal", "Tgl Tagih", "Cicil Awal", "Cicil Akhir",
   "Id Subjek", "Subjek", "Id Sales", "Sales",
   "Kas Keluar", "Ket. Kas Keluar", "Kas Masuk", "Ket. Kas Masuk",
   "Brg Masuk", "Brg Keluar");
  TableMdlTransColsType = PCore.primArr(
   CCore.TypeLong, CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString,
   CCore.TypeDate, CCore.TypeDate, CCore.TypeDate, CCore.TypeDate,
   CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString,
   CCore.TypeString, CCore.TypeString, CCore.TypeString, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeDouble);
  TableMdlTransColsShowOption = PCore.changeValue(PCore.newIntegerArray(TableMdlTransColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  QueryTransTbHaving = "tb4";
  LastSelectedRowTrans = -1;
  buildTableTransViewStructure(true, true);
  updateTableTransView(false);

  TIRequeryAll = true;
  TIDet = false;
  TIDetClear = true;
  TIIn = false;
  TIInClear = true;
  TIOut = false;
  TIOutClear = true;

  // tab item in & out
  TableMdlIn = new OCustomTableModel(true, CApp.Default_TransItem_Checked, false);
  Tbl_In.setModel(TableMdlIn);
  TableMdlItemInColsName = PCore.refArr("Id Brg", "Nm Brg", "Nama Brg", "Qty", "Satuan", "Hrg Total", "Hrg Sat.", "Komentar",
   "File Gambar", "Kategori");
  TableMdlItemInColsType = PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeString, CCore.TypeString);
  TableMdlItemInColsShowOption = PCore.changeValue(PCore.newIntegerArray(TableMdlItemInColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  QueryItemInTbHaving = "tb4";
  LastSelectedRowIn = -1;
  InfoInClear = true;
  CB_ItemInCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableItemInViewStructure(true, true);
  updateTableItemInView(false);

  refreshItemCount(TF_InCount, TableMdlIn);
  CmB_FindItemIn.setSelectedIndex(1);

  Pnl_ItemInPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

  TableMdlOut = new OCustomTableModel(true, CApp.Default_TransItem_Checked, false);
  Tbl_Out.setModel(TableMdlOut);
  TableMdlItemOutColsName = PCore.refArr("Id Brg", "Nm Brg", "Nama Brg", "Qty", "Satuan", "Hrg Total", "Hrg Sat.", "Komentar",
   "File Gambar", "Kategori");
  TableMdlItemOutColsType = PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeString, CCore.TypeString);
  TableMdlItemOutColsShowOption = PCore.changeValue(PCore.newIntegerArray(TableMdlItemOutColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  QueryItemOutTbHaving = "tb4";
  LastSelectedRowOut = -1;
  InfoOutClear = true;
  CB_ItemOutCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableItemOutViewStructure(true, true);
  updateTableItemOutView(false);

  refreshItemCount(TF_OutCount, TableMdlOut);
  CmB_FindItemOut.setSelectedIndex(1);

  Pnl_ItemOutPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

  // TabbedPane
  TabbedPane.addChangeListener(new ChangeListener() {
   public void stateChanged(ChangeEvent e) {
    onTabbedPaneChanged();
   }
  });
  TabbedPane.setSelectedIndex(0);

  PGUI.setSelected(true, CB_ViewDate, CB_ViewDateBill, CB_ViewSubject, CB_ViewSalesman, CB_ViewId, CB_ViewIsImportant, CB_ViewItemIn, CB_ViewItemOut);
  changeTableTransView();
 }

 private void onKeyPress() {
  InputMap inp = getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act = getRootPane().getActionMap();

  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(TF_Find, Tbl_Trans,
    TF_FindItemIn, Tbl_In,
    TF_FindItemOut, Tbl_Out),
   PCore.objArrVariant());

  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction() {
   public void actionPerformed(ActionEvent e) {
    formWindowClosing(null);
    setVisible(false);
   }
  });

  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction() {
   public void actionPerformed(ActionEvent e) {
    if (Btn_TransChoose.isVisible()) {
     Btn_TransChooseActionPerformed(null);
    }
   }
  });
 }

 void clearComponents() {
  // table trans
  clearTableTrans(); PGUI.clearText(TF_Find);

  // tab detail, item in, item out
  clearDet();
  clearIn(); PGUI.clearText(TF_FindItemIn);
  clearOut(); PGUI.clearText(TF_FindItemOut);
 }

 void updateTableTransView(boolean Requery) {
  TableMdlTrans.updateColumnsInfo(TableMdlTransColsName, TableMdlTransColsType, TableMdlTransColsShowOption, TableMdlTransColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_Trans, TableTransColsWidth);
  if (!Requery) {
   onSelectedRowTransChanged(false);
  } else {
   fillTableTrans();
  }
 }

 void buildTableTransViewColumns() {
  Vector<Integer> ColsVisible = new Vector();
  Vector<Integer> ColsWidth = new Vector();

  // TransType
  ColsVisible.addElement(4);
  ColsWidth.addElement(CGUI.ColTextSml - 25);

  // TransDate
  if (CB_ViewDate.isSelected()) {
   ColsVisible.addElement(5);
   ColsWidth.addElement(CGUI.ColDate);
  }
  if (CB_ViewDateBill.isSelected()) {
   ColsVisible.addElement(6);
   ColsWidth.addElement(CGUI.ColDate);
  }
  if (CB_ViewDateRepayment.isSelected()) {
   ColsVisible.addElement(7);
   ColsWidth.addElement(CGUI.ColDate);
   ColsVisible.addElement(8);
   ColsWidth.addElement(CGUI.ColDate);
  }

  // Subject
  if (CB_ViewSubject.isSelected()) {
   ColsVisible.addElement(10);
   ColsWidth.addElement(CGUI.ColTextSml - 25);
  }
  if (CB_ViewSalesman.isSelected()) {
   ColsVisible.addElement(12);
   ColsWidth.addElement(CGUI.ColTextSml - 25);
  }

  // Cash
  if (CB_ViewCashOut.isSelected()) {
   ColsVisible.addElement(13);
   ColsWidth.addElement(CGUI.ColTextSml - 25);
  }
  if (CB_ViewCashOutComment.isSelected()) {
   ColsVisible.addElement(14);
   ColsWidth.addElement(CGUI.ColTextSml - 25);
  }
  if (CB_ViewCashIn.isSelected()) {
   ColsVisible.addElement(15);
   ColsWidth.addElement(CGUI.ColTextSml - 25);
  }
  if (CB_ViewCashInComment.isSelected()) {
   ColsVisible.addElement(16);
   ColsWidth.addElement(CGUI.ColTextSml - 25);
  }

  // Id
  if (CB_ViewId.isSelected()) {
   ColsVisible.addElement(1);
   ColsWidth.addElement(CGUI.ColNum16 + 35);
  }
  if (CB_ViewIdExternal.isSelected()) {
   ColsVisible.addElement(2);
   ColsWidth.addElement(CGUI.ColNum16 + 35);
  }
  if (CB_ViewIsImportant.isSelected()) {
   ColsVisible.addElement(3);
   ColsWidth.addElement(CGUI.ColCheck);
  }

  // Item In & Item Out
  if (CB_ViewItemIn.isSelected()) {
   ColsVisible.addElement(17);
   ColsWidth.addElement(CGUI.ColCur09_02 - 10);
  }
  if (CB_ViewItemOut.isSelected()) {
   ColsVisible.addElement(18);
   ColsWidth.addElement(CGUI.ColCur09_02 - 10);
  }

  TableMdlTransColsVisible = PCore.primArr_VectInt(ColsVisible);
  TableTransColsWidth = PCore.primArr_VectInt(ColsWidth);
 }

 void buildTableTransColumns() {
  buildTableTransViewColumns();
 }

 void buildTableTransOrderBy() {
  QueryTransOrderBy = " order by TransTypeName asc, TransDate desc, SubjectName asc, BillDate asc, " + QueryTransTbHaving + "." + DbTable + "Id desc";
 }

 void buildTableTransViewStructure(boolean RebuildColumns, boolean RebuildOrderBy) {
  if (RebuildColumns) {
   buildTableTransColumns();
  }
  if (RebuildOrderBy) {
   buildTableTransOrderBy();
  }
 }

 void changeTableTransView() {
  buildTableTransViewStructure(true, false);
  updateTableTransView(false);
 }

 void updateTableItemInView(boolean Requery) {
  int RowTrans = Tbl_Trans.getSelectedRow();
  long Id;

  TableMdlIn.updateColumnsInfo(TableMdlItemInColsName, TableMdlItemInColsType, TableMdlItemInColsShowOption,
   TableMdlItemInColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_In, TableItemInColsWidth);
  if (!Requery) {
   onSelectedRowInChanged(false);
  } else {
   RowTrans = Tbl_Trans.getSelectedRow();
   Id = -1;
   if (RowTrans != -1) {
    Id = (Long) TableMdlTrans.Mdl.Rows.elementAt(RowTrans)[0];
   }
   fillIn(Id);
  }
 }

 void buildTableItemInColumns() {
  boolean IsCategorized = CB_ItemInCategorized.isSelected();
  TableMdlItemInColsVisible = PCore.primArr(2, 3, 6, 5);
  TableItemInColsWidth = PCore.primArr(25, 260, 40, 75, 85);
  if (!IsCategorized) {
   TableMdlItemInColsVisible = PCore.insert(TableMdlItemInColsVisible, TableMdlItemInColsVisible.length, 0);
   TableItemInColsWidth = PCore.insert(TableItemInColsWidth, TableItemInColsWidth.length, 95);
  } else {
   TableMdlItemInColsVisible = PCore.insert(TableMdlItemInColsVisible, 0, 9);
   TableItemInColsWidth = PCore.insert(TableItemInColsWidth, 1, 130);
  }
 }

 void buildTableItemInOrderBy() {
  boolean IsCategorized = CB_ItemInCategorized.isSelected();
  QueryItemInOrderBy = PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }

 void buildTableItemInViewStructure(boolean RebuildColumns, boolean RebuildOrderBy) {
  if (RebuildColumns) {
   buildTableItemInColumns();
  }
  if (RebuildOrderBy) {
   buildTableItemInOrderBy();
  }
 }

 void changeItemInViewByCategorized() {
  buildTableItemInViewStructure(true, true);
  updateTableItemInView(true);
 }

 void updateTableItemOutView(boolean Requery) {
  int RowTrans = Tbl_Trans.getSelectedRow();
  long Id;

  TableMdlOut.updateColumnsInfo(TableMdlItemOutColsName, TableMdlItemOutColsType, TableMdlItemOutColsShowOption,
   TableMdlItemOutColsVisible, Requery);
  PGUI.resizeTableColumn(Tbl_Out, TableItemOutColsWidth);
  if (!Requery) {
   onSelectedRowOutChanged(false);
  } else {
   RowTrans = Tbl_Trans.getSelectedRow();
   Id = -1;
   if (RowTrans != -1) {
    Id = (Long) TableMdlTrans.Mdl.Rows.elementAt(RowTrans)[0];
   }
   fillOut(Id);
  }
 }

 void buildTableItemOutColumns() {
  boolean IsCategorized = CB_ItemOutCategorized.isSelected();
  TableMdlItemOutColsVisible = PCore.primArr(2, 3, 6, 5);
  TableItemOutColsWidth = PCore.primArr(25, 260, 40, 75, 85);
  if (!IsCategorized) {
   TableMdlItemOutColsVisible = PCore.insert(TableMdlItemOutColsVisible, TableMdlItemOutColsVisible.length, 0);
   TableItemOutColsWidth = PCore.insert(TableItemOutColsWidth, TableItemOutColsWidth.length, 95);
  } else {
   TableMdlItemOutColsVisible = PCore.insert(TableMdlItemOutColsVisible, 0, 9);
   TableItemOutColsWidth = PCore.insert(TableItemOutColsWidth, 1, 130);
  }
 }

 void buildTableItemOutOrderBy() {
  boolean IsCategorized = CB_ItemOutCategorized.isSelected();
  QueryItemOutOrderBy = PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }

 void buildTableItemOutViewStructure(boolean RebuildColumns, boolean RebuildOrderBy) {
  if (RebuildColumns) {
   buildTableItemOutColumns();
  }
  if (RebuildOrderBy) {
   buildTableItemOutOrderBy();
  }
 }

 void changeItemOutViewByCategorized() {
  buildTableItemOutViewStructure(true, true);
  updateTableItemOutView(true);
 }

 // on event
 void onTabbedPaneChanged() {
  int CurrTab = TabbedPane.getSelectedIndex();
  int row;
  row = Tbl_Trans.getSelectedRow();
  if (row != -1) {
   fillAnActiveTab(CurrTab, (Long) TableMdlTrans.Mdl.Rows.elementAt(row)[0]);
  } else {
   clearAnActiveTab(CurrTab);
  }
 }

 void onSelectedRowTransChanged(boolean UpdateAnyway) {
  int row = Tbl_Trans.getSelectedRow();
  int tab;
  if (row != LastSelectedRowTrans || UpdateAnyway) {
   LastSelectedRowTrans = row;
   clearRequeryIndex();
   tab = TabbedPane.getSelectedIndex();
   if (row != -1) {
    fillAnActiveTab(tab, (Long) TableMdlTrans.Mdl.Rows.elementAt(row)[0]);
   } else {
    clearAnActiveTab(tab);
   }
  }
 }

 void onSelectedRowInChanged(boolean UpdateAnyway) {
  int row = Tbl_In.getSelectedRow();
  if (LastSelectedRowIn != row || UpdateAnyway) {
   LastSelectedRowIn = row;
   if (row != -1) {
    fillInfoIn(row);
   } else {
    clearInfoIn();
   }
  }
 }

 void onSelectedRowOutChanged(boolean UpdateAnyway) {
  int row = Tbl_Out.getSelectedRow();
  if (LastSelectedRowOut != row || UpdateAnyway) {
   LastSelectedRowOut = row;
   if (row != -1) {
    fillInfoOut(row);
   } else {
    clearInfoOut();
   }
  }
 }

 // fill-clear
 void clearRequeryIndex() {
  if (!TIRequeryAll) {
   TIDet = false;
   TIIn = false;
   TIOut = false;
   TIRequeryAll = true;
  }
 }

 void fillTableTrans() {
  int temp;
  String Query;

  clearTableTrans();

  /*
   the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
   because there can be ambiguous column name, if other additional tables have the same column name as static tables

   for example :
   "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
   ~ should be changed into
   "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
   ~ to prevent ambiguous interpretation of column name between static table & additional table
  */
  Query
   = "select tb4.*, Sum(" + DbTable + "PendXItemOut.Price) as 'PriceItemOut' from "
   + "(select tb3.*, Sum(" + DbTable + "PendXItemIn.Price) as 'PriceItemIn' from "
   + "(select tb2.Id, tb2." + DbTable + "Id, tb2.InfoIdExternal, tb2.IsImportant, tb2.TransTypeName, "
   + "tb2.TransDate, tb2.BillDate, tb2.RepaymentPeriodStart, tb2.RepaymentPeriodEnd, "
   + "tb2.Subject, tb2.SubjectName, tb2.Salesman, Subject.Name as 'SalesmanName', "
   + "tb2.CashOutName, tb2.CashOutComment, Cash.Name as 'CashInName', tb2.CashInComment "
   + "from "
   + "(select tb1.*, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName', Cash.Name as 'CashOutName' from "
   + "(select " + DbTable + "Pend.*, if(CreditDays is " + CCore.vNull + ", " + CCore.vNull + ", Date_Add(TransDate, Interval ifnull(CreditDays, 0) Day)) as 'BillDate' from " + DbTable + "Pend) as tb1 "
   + "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id left join Cash on tb1.CashOut=Cash.Id) as tb2 "
   + "left join Subject on tb2.Salesman=Subject.Id left join Cash on tb2.CashIn=Cash.Id) as tb3 "
   + "left join " + DbTable + "PendXItemIn on tb3.Id=" + DbTable + "PendXItemIn." + DbTable + "Pend group by tb3.Id) as tb4 "
   + "left join " + DbTable + "PendXItemOut on tb4.Id=" + DbTable + "PendXItemOut." + DbTable + "Pend group by tb4.Id"
   + QueryTransOrderBy;

  temp = PDatabase.queryToTable(IFV.Stm, Query, TableMdlTrans, false, false, null, -1, false, -1);
  if (temp == -1) {
   clearTableTrans();
   JOptionPane.showMessageDialog(null, "Gagal mengambil data dari database !");
  } else {
   if (temp != 0) {
    Tbl_Trans.changeSelection(0, 0, false, false);
    onSelectedRowTransChanged(false);
   }
  }
 }

 void clearTableTrans() {
  TableMdlTrans.removeAll();
  onSelectedRowTransChanged(true);
 }

 String getStringOfCash(int CashId, String CashName, String CashComment) {
  StringBuilder ret;
  boolean first;

  ret = new StringBuilder();
  first = true;
  if (CashId != -1) {
   if (first) {
    first = false;
   } else {
    ret.append("\n");
   }
   ret.append(CashName);
  }
  if (!PText.isEmptyString(CashComment, false, true)) {
   if (first) {
    first = false;
   } else {
    ret.append("\n");
   }
   ret.append("{ " + CashComment + " }");
  }

  return ret.toString();
 }

 void fillDet(long PendingId) {
  OInfoTransPending InfoTrans = PMyShop.getTransPendingInfo(IFV.Stm, wIsPreTrans, PendingId);
  if (InfoTrans != null) {
   TF_DetId.setText(PText.separate(String.valueOf(InfoTrans.TransId), " - ", PCore.primArr(4, 2, 2, 4, 4)));
   CB_DetImportant.setSelected(InfoTrans.Important);
   TF_DetIdExternal.setText(PText.getString(InfoTrans.InfoIdExternal, "", true));
   TF_DetDate.setText(PText.dateToString(InfoTrans.Dt, 2));
   if (InfoTrans.TypeId == -1) {
    TF_DetTransType.setText("");
   } else {
    TF_DetTransType.setText(InfoTrans.TypeName);
   }
   TF_DetCashIn.setText(getStringOfCash(InfoTrans.CashInId, InfoTrans.CashInName, InfoTrans.CashInComment));
   TF_DetCashOut.setText(getStringOfCash(InfoTrans.CashOutId, InfoTrans.CashOutName, InfoTrans.CashOutComment));
   if (InfoTrans.SubjectId == -1) {
    TF_DetSubject.setText("");
   } else {
    TF_DetSubject.setText(InfoTrans.SubjectName);
   }
   if (InfoTrans.SalesmanId == -1) {
    TF_DetSalesman.setText("");
   } else {
    TF_DetSalesman.setText(InfoTrans.SalesmanName);
   }
   if (InfoTrans.CreditDays == -1) {
    TF_DetCreditDays.setText("");
   } else {
    TF_DetCreditDays.setText(InfoTrans.CreditDays + " hari ("
     + PText.dateToString(PDate.calculateDateByDay(InfoTrans.Dt, InfoTrans.CreditDays, 1), 2) + ")");
   }
   TF_DetRepaymentPeriod.setText(PText.getString(InfoTrans.RepaymentPeriodStart == null || InfoTrans.RepaymentPeriodEnd == null, "",
    PText.dateToString(InfoTrans.RepaymentPeriodStart, 2) + " - " + PText.dateToString(InfoTrans.RepaymentPeriodEnd, 2)));
   if (InfoTrans.Comment == null) {
    TA_DetComment.setText("");
   } else {
    TA_DetComment.setText(InfoTrans.Comment);
   }
   TIDet = true;
   TIDetClear = false;
   if (TIRequeryAll) {
    TIRequeryAll = false;
   }
  } else {
   clearDet();
   JOptionPane.showMessageDialog(null, "Gagal mengambil keterangan " + TransName + " dari database !");
  }
 }

 void clearDet() {
  if (TIDetClear == false) {
   TF_DetId.setText("");
   CB_DetImportant.setSelected(false);
   TF_DetIdExternal.setText("");
   TF_DetDate.setText("");
   TF_DetTransType.setText("");
   TF_DetCashIn.setText("");
   TF_DetCashOut.setText("");
   TF_DetSubject.setText("");
   TF_DetSalesman.setText("");
   TF_DetCreditDays.setText("");
   TF_DetRepaymentPeriod.setText("");
   TA_DetComment.setText("");
   TIDetClear = true;
  }
 }

 void refreshItemCount(JTextField TF_ItemCount, OCustomTableModel TableMdlItem) {
  TF_ItemCount.setText(PText.intToString(TableMdlItem.getRowCount()) + "  ( " + PText.intToString(TableMdlItem.getCheckedCount()) + " )");
 }

 void fillIn(long TransId) {
  int datacount;

  clearIn();
  if (TransId == -1) {
   return;
  }

  // fetch list data
  datacount = PDatabase.queryToTable(IFV.Stm,
   "select TransItem, ItemName, ItemNm, TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, PictureFile, Min(CategoryOfItem.Name) as 'CategoryName', TransItemChecked from "
   + "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "
   + "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "
   + "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit from "
   + "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "
   + "from " + DbTable + "PendXItemIn where " + DbTable + "Pend=" + TransId + ") as tb1 "
   + "left join Item on tb1.TransItem=Item.Id) as tb2 "
   + "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "
   + "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem) as tb4 "
   + "left join ItemXCategory on tb4.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.TransItem"
   + QueryItemInOrderBy,
   TableMdlIn, false, false, null, -1, true, 10);
  TIInClear = false;
  if (datacount != -1) {
   TIIn = true;
   if (TIRequeryAll == true) {
    TIRequeryAll = false;
   }
   refreshItemCount(TF_InCount, TableMdlIn);
   if (datacount > 0) {
    Tbl_In.changeSelection(0, 0, false, false);
    onSelectedRowInChanged(false);
   } else {
    clearInfoIn();
   }
  } else {
   clearIn();
   JOptionPane.showMessageDialog(null, "Gagal mengambil 'daftar barang masuk' dari database !");
  }
 }

 void clearIn() {
  if (TIInClear == false) {
   TableMdlIn.removeAll();
   refreshItemCount(TF_InCount, TableMdlIn);
   LastSelectedRowIn = -1;
   clearInfoIn();
   TIInClear = true;
  }
 }

 void fillInfoIn(int row) {
  Object[] objs = TableMdlIn.Mdl.Rows.elementAt(row);
  TF_InInfoCategory.setText(PCore.objString(objs[9], ""));
  TF_InInfoName.setText("(" + PText.separate(objs[0].toString(), " - ", 5) + ") " + (String) objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemInPreview, IFV.Conf.ImageDirItem, objs[8]);
  InfoInClear = false;
 }

 void clearInfoIn() {
  if (InfoInClear == false) {
   TF_InInfoCategory.setText("");
   TF_InInfoName.setText("");
   PGUI.fillPanelPictureURL(Pnl_ItemInPreview, IFV.Conf.ImageDirItem, null);
   InfoInClear = true;
  }
 }

 void fillOut(long TransId) {
  int datacount;

  clearOut();
  if (TransId == -1) {
   return;
  }

  // fetch list data
  datacount = PDatabase.queryToTable(IFV.Stm,
   "select TransItem, ItemName, ItemNm, TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, PictureFile, Min(CategoryOfItem.Name) as 'CategoryName', TransItemChecked from "
   + "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "
   + "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "
   + "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit from "
   + "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "
   + "from " + DbTable + "PendXItemOut where " + DbTable + "Pend=" + TransId + ") as tb1 "
   + "left join Item on tb1.TransItem=Item.Id) as tb2 "
   + "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "
   + "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem) as tb4 "
   + "left join ItemXCategory on tb4.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.TransItem"
   + QueryItemOutOrderBy,
   TableMdlOut, false, false, null, -1, true, 10);
  TIOutClear = false;
  if (datacount != -1) {
   TIOut = true;
   if (TIRequeryAll == true) {
    TIRequeryAll = false;
   }
   refreshItemCount(TF_OutCount, TableMdlOut);
   if (datacount > 0) {
    Tbl_Out.changeSelection(0, 0, false, false);
    onSelectedRowOutChanged(false);
   } else {
    clearInfoOut();
   }
  } else {
   clearOut();
   JOptionPane.showMessageDialog(null, "Gagal mengambil 'daftar barang keluar' dari database !");
  }
 }

 void clearOut() {
  if (TIOutClear == false) {
   TableMdlOut.removeAll();
   refreshItemCount(TF_OutCount, TableMdlOut);
   LastSelectedRowOut = -1;
   clearInfoOut();
   TIOutClear = true;
  }
 }

 void fillInfoOut(int row) {
  Object[] objs = TableMdlOut.Mdl.Rows.elementAt(row);
  TF_OutInfoCategory.setText(PCore.objString(objs[9], ""));
  TF_OutInfoName.setText("(" + PText.separate(objs[0].toString(), " - ", 5) + ") " + (String) objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemOutPreview, IFV.Conf.ImageDirItem, objs[8]);
  InfoOutClear = false;
 }

 void clearInfoOut() {
  if (InfoOutClear == false) {
   TF_OutInfoCategory.setText("");
   TF_OutInfoName.setText("");
   PGUI.fillPanelPictureURL(Pnl_ItemOutPreview, IFV.Conf.ImageDirItem, null);
   InfoOutClear = true;
  }
 }

 void fillAnActiveTab(int tab, long TransId) {
  switch (tab) {
   case 0: // tab det
    if (TIDet == false) {
     fillDet(TransId);
    }
    break;
   case 1: // tab item in
    if (TIIn == false) {
     fillIn(TransId);
    }
    break;
   case 2: // tab item out
    if (TIOut == false) {
     fillOut(TransId);
    }
    break;
  }
 }

 void clearAnActiveTab(int tab) {
  switch (tab) {
   case 0:
    clearDet();
    break; // tab det
   case 1:
    clearIn();
    break; // tab item in
   case 2:
    clearOut();
    break; // tab item out
  }
 }

 void findTransInTable(int Mode) {
  int Selected, FindIndex;
  int Column, ColumnType;
  String str = TF_Find.getText();
  if (str.length() != 0) {
   if (TableMdlTrans.Mdl.Rows.size() != 0) {
    switch (CmB_Find.getSelectedIndex()) {
     case 1:
      Column = 2;
      break;
     case 2:
      Column = 4;
      break;
     case 3:
      Column = 10;
      break;
     case 4:
      Column = 12;
      break;
     case 5:
      Column = 13;
      break;
     case 6:
      Column = 14;
      break;
     case 7:
      Column = 15;
      break;
     case 8:
      Column = 16;
      break;
     default:
      Column = 1;
      break;
    }
    ColumnType = TableMdlTrans.getColumnsType()[Column];
    Selected = Tbl_Trans.getSelectedRow();
    FindIndex = PGUI.searchInTable(TableMdlTrans, Column, ColumnType, str, Selected, Mode);
    if (FindIndex != -1) {
     if (Selected != FindIndex) {
      Tbl_Trans.changeSelection(FindIndex, 0, false, false);
      onSelectedRowTransChanged(false);
     }
    } else {
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !");
    }
   } else {
    JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !");
   }
  }
 }

 void findItemIn(int Mode) {
  int Selected, FindIndex;
  int Column, ColumnType;
  String str = TF_FindItemIn.getText();
  if (str.length() != 0) {
   if (TableMdlIn.Mdl.Rows.size() != 0) {
    switch (CmB_FindItemIn.getSelectedIndex()) {
     case 1:
      Column = 2;
      break;
     case 2:
      Column = 9;
      break;
     default:
      Column = 0;
      break;
    }
    ColumnType = TableMdlIn.Mdl.ColumnsType[Column];
    Selected = Tbl_In.getSelectedRow();
    FindIndex = PGUI.searchInTable(TableMdlIn, Column, ColumnType, str, Selected, Mode);
    if (FindIndex != -1) {
     if (Selected != FindIndex) {
      Tbl_In.changeSelection(FindIndex, 0, false, false);
      onSelectedRowInChanged(false);
     }
    } else {
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang masuk !");
    }
   } else {
    JOptionPane.showMessageDialog(null, "Tabel barang masuk dalam keadaan kosong !");
   }
  }
 }

 void findItemOut(int Mode) {
  int Selected, FindIndex;
  int Column, ColumnType;
  String str = TF_FindItemOut.getText();
  if (str.length() != 0) {
   if (TableMdlOut.Mdl.Rows.size() != 0) {
    switch (CmB_FindItemOut.getSelectedIndex()) {
     case 1:
      Column = 2;
      break;
     case 2:
      Column = 9;
      break;
     default:
      Column = 0;
      break;
    }
    ColumnType = TableMdlOut.Mdl.ColumnsType[Column];
    Selected = Tbl_Out.getSelectedRow();
    FindIndex = PGUI.searchInTable(TableMdlOut, Column, ColumnType, str, Selected, Mode);
    if (FindIndex != -1) {
     if (Selected != FindIndex) {
      Tbl_Out.changeSelection(FindIndex, 0, false, false);
      onSelectedRowOutChanged(false);
     }
    } else {
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang keluar !");
    }
   } else {
    JOptionPane.showMessageDialog(null, "Tabel barang keluar dalam keadaan kosong !");
   }
  }
 }

 void transRemove() {
  int[] rows;
  int temp, count, currrow;
  boolean[] removed;
  int removedcount;
  int increase_n_times;
  long increase_every_n_records;
  double increase_size;
  int[] result;

  rows = Tbl_Trans.getSelectedRows();
  count = rows.length;
  if (count == 0) {
   return;
  }

  if (JOptionPane.showConfirmDialog(null, "Hapus " + PText.intToString(count) + " " + TransName + " Pending yg dipilih ?"
   + "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
   "Konfirmasi Penghapusan " + TransName + " Pending", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
   return;
  }

  IFV.FSplashScreen.appear(this, "Hapus " + TransName + " Pend");

  IFV.FSplashScreen.inform(0, "Menghapus " + PText.intToString(count) + " " + TransName + " Pend ...", null);

  increase_n_times = 10;
  increase_every_n_records = count / increase_n_times;
  if (increase_every_n_records == 0) {
   increase_every_n_records = 1;
   increase_n_times = count;
  }
  increase_size = (100 - IFV.FSplashScreen.getProgress()) / increase_n_times;

  removed = PCore.newBooleanArray(count, false);
  removedcount = 0;
  temp = 0;
  do {
   currrow = rows[temp];

   result = PDatabase.removeTransPendingId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false) + DbTransPendLock, 10, wIsPreTrans, (Long) TableMdlTrans.Mdl.Rows.elementAt(currrow)[0],
    true, PText.getString(IFV.CurrentDatabase, "", false) + DbTransLock, 10, true);
   if (result[0] == 0 && result[1] == 0) {
    removed[temp] = true;
    removedcount = removedcount + 1;
   }

   temp = temp + 1;
   if (temp % increase_every_n_records == 0) {
    IFV.FSplashScreen.inform(increase_size, null, null);
   }
  } while (temp != count);

  IFV.FSplashScreen.disappear();

  if (removedcount != 0) {
   TableMdlTrans.remove(rows, removed);
   onSelectedRowTransChanged(true);
  }

  if (removedcount != count) {
   JOptionPane.showMessageDialog(null, "Gagal menghapus " + (count - removedcount) + " " + TransName + " Pending !");
  }
 }

 void transChoose() {
  int[] rows = Tbl_Trans.getSelectedRows();
  int temp, temp2;

  temp = rows.length;
  if (temp == 0) {
   JOptionPane.showMessageDialog(null, "Belum ada data " + TransName + " Pending yang dipilih !");
   return;
  }
  if (!wAllowMultipleChoose && temp > 1) {
   JOptionPane.showMessageDialog(null, "Hanya diperbolehkan memilih 1 data !");
   return;
  }

  ChoosedId = new Long[temp];
  temp2 = 0;
  do {
   ChoosedId[temp2] = (Long) TableMdlTrans.Mdl.Rows.elementAt(rows[temp2])[0];
   temp2 = temp2 + 1;
  } while (temp2 != temp);

  DialogResult = 1;
  clearComponents();
  Activ = false;
  setVisible(false);
 }

 public boolean canShowForm(boolean ShowMessage) {
  return IFV.canAccessGUI(1, ShowMessage, (Boolean) PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIAddTrans, IFV.PrivGUIAddPreTrans));
 }

 //
 void focusQueryResult() {
  if (!TableMdlTrans.Mdl.Rows.isEmpty()) {
   if (Tbl_Trans.getSelectedRow() == -1) {
    Tbl_Trans.changeSelection(0, 0, false, false);
    onSelectedRowTransChanged(false);
   }
   Tbl_Trans.requestFocusInWindow();
  }
 }

 void initFocus() {
  int datacount = TableMdlTrans.Mdl.Rows.size();

  if (datacount != 0) {
   Tbl_Trans.changeSelection(0, 0, false, false);
   onSelectedRowTransChanged(false);
  }

  if (datacount <= CApp.InitFocusInTableIfCountLimit) {
   PGUI.requestFocusInWindow(Tbl_Trans);
  } else {
   PGUI.requestFocusInWindow(TF_Find);
  }
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Query = new javax.swing.ButtonGroup();
  RG_QImportant = new javax.swing.ButtonGroup();
  RG_QItem = new javax.swing.ButtonGroup();
  BG_FindItemOut = new javax.swing.ButtonGroup();
  BG_FindItemIn = new javax.swing.ButtonGroup();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_Detail = new javax.swing.JPanel();
  Lbl_DetId = new javax.swing.JLabel();
  TF_DetId = new javax.swing.JTextField();
  TF_DetDate = new javax.swing.JTextField();
  TF_DetTransType = new javax.swing.JTextField();
  TF_DetSubject = new javax.swing.JTextField();
  CB_DetImportant = new javax.swing.JCheckBox();
  Lbl_DetComment = new javax.swing.JLabel();
  Lbl_DetDate = new javax.swing.JLabel();
  Lbl_DetTransType = new javax.swing.JLabel();
  Lbl_DetSubject = new javax.swing.JLabel();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_DetComment = new javax.swing.JTextArea();
  TF_DetSalesman = new javax.swing.JTextField();
  TF_DetCreditDays = new javax.swing.JTextField();
  Lbl_DetSalesman = new javax.swing.JLabel();
  Lbl_DetCreditDays = new javax.swing.JLabel();
  Lbl_DetCashOut = new javax.swing.JLabel();
  Lbl_DetCashIn = new javax.swing.JLabel();
  TF_DetRepaymentPeriod = new javax.swing.JTextField();
  Lbl_DetRepaymentPeriod = new javax.swing.JLabel();
  TF_DetIdExternal = new javax.swing.JTextField();
  Lbl_DetIdExternal = new javax.swing.JLabel();
  jScrollPane9 = new javax.swing.JScrollPane();
  TF_DetCashIn = new javax.swing.JTextArea();
  jScrollPane10 = new javax.swing.JScrollPane();
  TF_DetCashOut = new javax.swing.JTextArea();
  jSeparator1 = new javax.swing.JSeparator();
  jSeparator2 = new javax.swing.JSeparator();
  jSeparator3 = new javax.swing.JSeparator();
  jSeparator4 = new javax.swing.JSeparator();
  Panel_In = new javax.swing.JPanel();
  TF_FindItemIn = new javax.swing.JTextField();
  Btn_FindItemInNext = new javax.swing.JButton();
  Btn_FindItemInBef = new javax.swing.JButton();
  jScrollPane5 = new javax.swing.JScrollPane();
  TF_InInfoName = new javax.swing.JTextArea();
  Pnl_ItemInPreview = new XImgBoxURL();
  TF_InCount = new javax.swing.JTextField();
  CmB_FindItemIn = new javax.swing.JComboBox<>();
  jScrollPane8 = new javax.swing.JScrollPane();
  TF_InInfoCategory = new javax.swing.JTextArea();
  jScrollPane11 = new javax.swing.JScrollPane();
  Tbl_In = new XTable();
  CB_ItemInCategorized = new javax.swing.JToggleButton();
  Panel_Out = new javax.swing.JPanel();
  TF_FindItemOut = new javax.swing.JTextField();
  Btn_FindItemOutNext = new javax.swing.JButton();
  Btn_FindItemOutBef = new javax.swing.JButton();
  jScrollPane6 = new javax.swing.JScrollPane();
  TF_OutInfoName = new javax.swing.JTextArea();
  Pnl_ItemOutPreview = new XImgBoxURL();
  CmB_FindItemOut = new javax.swing.JComboBox<>();
  TF_OutCount = new javax.swing.JTextField();
  jScrollPane7 = new javax.swing.JScrollPane();
  TF_OutInfoCategory = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  Tbl_Out = new XTable();
  CB_ItemOutCategorized = new javax.swing.JToggleButton();
  jPanel2 = new javax.swing.JPanel();
  Btn_TransRemove = new javax.swing.JButton();
  Btn_TransChoose = new javax.swing.JButton();
  Lbl_AllowMultipleChoose = new javax.swing.JLabel();
  Lbl_Title = new javax.swing.JLabel();
  jPanel1 = new javax.swing.JPanel();
  Btn_FindNext = new javax.swing.JButton();
  Btn_Before = new javax.swing.JButton();
  TF_Find = new javax.swing.JTextField();
  CmB_Find = new javax.swing.JComboBox<>();
  jPanel3 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  CB_ViewDate = new javax.swing.JToggleButton();
  CB_ViewDateBill = new javax.swing.JToggleButton();
  CB_ViewDateRepayment = new javax.swing.JToggleButton();
  CB_ViewSubject = new javax.swing.JToggleButton();
  CB_ViewSalesman = new javax.swing.JToggleButton();
  CB_ViewCashOut = new javax.swing.JToggleButton();
  CB_ViewCashOutComment = new javax.swing.JToggleButton();
  CB_ViewCashIn = new javax.swing.JToggleButton();
  CB_ViewCashInComment = new javax.swing.JToggleButton();
  CB_ViewId = new javax.swing.JToggleButton();
  CB_ViewIdExternal = new javax.swing.JToggleButton();
  CB_ViewIsImportant = new javax.swing.JToggleButton();
  CB_ViewItemIn = new javax.swing.JToggleButton();
  CB_ViewItemOut = new javax.swing.JToggleButton();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_Trans = new XTable();

  setTitle("Lihat Transaksi ( {Esc} Utk Keluar )");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Lbl_DetId.setText("Id");

  TF_DetId.setEditable(false);
  TF_DetId.setBackground(new java.awt.Color(204, 255, 204));

  TF_DetDate.setEditable(false);
  TF_DetDate.setBackground(new java.awt.Color(204, 255, 204));

  TF_DetTransType.setEditable(false);
  TF_DetTransType.setBackground(new java.awt.Color(204, 255, 204));

  TF_DetSubject.setEditable(false);
  TF_DetSubject.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetSubject.setToolTipText("klik utk melihat keterangan subjek");
  TF_DetSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_DetSubject.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_DetSubjectMouseClicked(evt);
   }
  });

  CB_DetImportant.setText("Penting");
  CB_DetImportant.setEnabled(false);
  CB_DetImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));

  Lbl_DetComment.setText("Keterangan");

  Lbl_DetDate.setText("Tanggal");

  Lbl_DetTransType.setText("Jenis");

  Lbl_DetSubject.setText("Subjek");

  TA_DetComment.setEditable(false);
  TA_DetComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetComment.setColumns(20);
  TA_DetComment.setLineWrap(true);
  TA_DetComment.setWrapStyleWord(true);
  jScrollPane4.setViewportView(TA_DetComment);

  TF_DetSalesman.setEditable(false);
  TF_DetSalesman.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetSalesman.setToolTipText("klik utk melihat keterangan sales");
  TF_DetSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_DetSalesman.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_DetSalesmanMouseClicked(evt);
   }
  });

  TF_DetCreditDays.setEditable(false);
  TF_DetCreditDays.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_DetSalesman.setText("Salesman");

  Lbl_DetCreditDays.setText("Lama Kredit");

  Lbl_DetCashOut.setText("Kas Keluar Tunai");

  Lbl_DetCashIn.setText("Kas Masuk Tunai");

  TF_DetRepaymentPeriod.setEditable(false);
  TF_DetRepaymentPeriod.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_DetRepaymentPeriod.setText("Periode Cicil");

  TF_DetIdExternal.setEditable(false);
  TF_DetIdExternal.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_DetIdExternal.setText("{ Id External }");

  TF_DetCashIn.setEditable(false);
  TF_DetCashIn.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetCashIn.setColumns(20);
  TF_DetCashIn.setLineWrap(true);
  TF_DetCashIn.setWrapStyleWord(true);
  jScrollPane9.setViewportView(TF_DetCashIn);

  TF_DetCashOut.setEditable(false);
  TF_DetCashOut.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetCashOut.setColumns(20);
  TF_DetCashOut.setLineWrap(true);
  TF_DetCashOut.setWrapStyleWord(true);
  jScrollPane10.setViewportView(TF_DetCashOut);

  javax.swing.GroupLayout Panel_DetailLayout = new javax.swing.GroupLayout(Panel_Detail);
  Panel_Detail.setLayout(Panel_DetailLayout);
  Panel_DetailLayout.setHorizontalGroup(
   Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DetailLayout.createSequentialGroup()
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_DetSubject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetSalesman, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetCreditDays, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetRepaymentPeriod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetIdExternal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetTransType, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetCashIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetCashOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetComment, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_DetDate, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_DetCreditDays)
     .addComponent(TF_DetRepaymentPeriod, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_DetailLayout.createSequentialGroup()
      .addComponent(TF_DetId)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_DetImportant))
     .addComponent(TF_DetIdExternal)
     .addComponent(TF_DetTransType, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
     .addComponent(jScrollPane10, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_DetSubject)
     .addComponent(TF_DetSalesman)))
   .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
   .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
   .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
   .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  Panel_DetailLayout.setVerticalGroup(
   Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DetailLayout.createSequentialGroup()
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_DetImportant)
     .addComponent(Lbl_DetId))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetIdExternal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetIdExternal))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetTransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetTransType))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetCreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetCreditDays))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetRepaymentPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetRepaymentPeriod))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetSubject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetSubject))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetSalesman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetSalesman))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_DetCashIn)
     .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_DetCashOut)
     .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_DetailLayout.createSequentialGroup()
      .addComponent(Lbl_DetComment)
      .addContainerGap(220, Short.MAX_VALUE))
     .addComponent(jScrollPane4)))
  );

  TabbedPane.addTab("Ket", Panel_Detail);

  TF_FindItemIn.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindItemInFocusGained(evt);
   }
  });
  TF_FindItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindItemInKeyPressed(evt);
   }
  });

  Btn_FindItemInNext.setText(">");
  Btn_FindItemInNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemInNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemInNextActionPerformed(evt);
   }
  });

  Btn_FindItemInBef.setText("<");
  Btn_FindItemInBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemInBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemInBefActionPerformed(evt);
   }
  });

  TF_InInfoName.setEditable(false);
  TF_InInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_InInfoName.setColumns(20);
  TF_InInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_InInfoName.setLineWrap(true);
  TF_InInfoName.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TF_InInfoName);

  Pnl_ItemInPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInPreviewMouseClicked(evt);
   }
  });

  TF_InCount.setEditable(false);
  TF_InCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_InCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CmB_FindItemIn.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nm Brg", "Kategori" }));

  TF_InInfoCategory.setEditable(false);
  TF_InInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TF_InInfoCategory.setColumns(20);
  TF_InInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_InInfoCategory.setLineWrap(true);
  TF_InInfoCategory.setWrapStyleWord(true);
  jScrollPane8.setViewportView(TF_InInfoCategory);

  Tbl_In.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_In.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_In.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_In.setRowHeight(18);
  Tbl_In.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_InMouseReleased(evt);
   }
  });
  Tbl_In.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_InKeyReleased(evt);
   }
  });
  jScrollPane11.setViewportView(Tbl_In);

  CB_ItemInCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemInCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemInCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemInCategorized.setText("K");
  CB_ItemInCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemInCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemInCategorized.setIconTextGap(0);
  CB_ItemInCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemInCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Panel_InLayout = new javax.swing.GroupLayout(Panel_In);
  Panel_In.setLayout(Panel_InLayout);
  Panel_InLayout.setHorizontalGroup(
   Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_InLayout.createSequentialGroup()
    .addComponent(TF_InCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemInCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CmB_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FindItemIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemInBef)
    .addGap(3, 3, 3)
    .addComponent(Btn_FindItemInNext))
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_InLayout.createSequentialGroup()
    .addComponent(Pnl_ItemInPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
     .addComponent(jScrollPane5)))
   .addComponent(jScrollPane11)
  );
  Panel_InLayout.setVerticalGroup(
   Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_InLayout.createSequentialGroup()
    .addGroup(Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_FindItemInNext)
     .addComponent(Btn_FindItemInBef)
     .addComponent(TF_InCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ItemInCategorized))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel_InLayout.createSequentialGroup()
      .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane5))
     .addComponent(Pnl_ItemInPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  TabbedPane.addTab("Brg Masuk", Panel_In);

  TF_FindItemOut.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindItemOutFocusGained(evt);
   }
  });
  TF_FindItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindItemOutKeyPressed(evt);
   }
  });

  Btn_FindItemOutNext.setText(">");
  Btn_FindItemOutNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemOutNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemOutNextActionPerformed(evt);
   }
  });

  Btn_FindItemOutBef.setText("<");
  Btn_FindItemOutBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemOutBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemOutBefActionPerformed(evt);
   }
  });

  TF_OutInfoName.setEditable(false);
  TF_OutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutInfoName.setColumns(20);
  TF_OutInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_OutInfoName.setLineWrap(true);
  TF_OutInfoName.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TF_OutInfoName);

  Pnl_ItemOutPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutPreviewMouseClicked(evt);
   }
  });

  CmB_FindItemOut.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nm Brg", "Kategori" }));

  TF_OutCount.setEditable(false);
  TF_OutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_OutInfoCategory.setEditable(false);
  TF_OutInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutInfoCategory.setColumns(20);
  TF_OutInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_OutInfoCategory.setLineWrap(true);
  TF_OutInfoCategory.setWrapStyleWord(true);
  jScrollPane7.setViewportView(TF_OutInfoCategory);

  Tbl_Out.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Out.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Out.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Out.setRowHeight(18);
  Tbl_Out.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_OutMouseReleased(evt);
   }
  });
  Tbl_Out.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_OutKeyReleased(evt);
   }
  });
  jScrollPane3.setViewportView(Tbl_Out);

  CB_ItemOutCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutCategorized.setText("K");
  CB_ItemOutCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemOutCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutCategorized.setIconTextGap(0);
  CB_ItemOutCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Panel_OutLayout = new javax.swing.GroupLayout(Panel_Out);
  Panel_Out.setLayout(Panel_OutLayout);
  Panel_OutLayout.setHorizontalGroup(
   Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_OutLayout.createSequentialGroup()
    .addComponent(TF_OutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CmB_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FindItemOut)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemOutBef)
    .addGap(3, 3, 3)
    .addComponent(Btn_FindItemOutNext))
   .addGroup(Panel_OutLayout.createSequentialGroup()
    .addComponent(Pnl_ItemOutPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 385, Short.MAX_VALUE)
     .addComponent(jScrollPane6)))
   .addComponent(jScrollPane3)
  );
  Panel_OutLayout.setVerticalGroup(
   Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_OutLayout.createSequentialGroup()
    .addGroup(Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_FindItemOutNext)
     .addComponent(Btn_FindItemOutBef)
     .addComponent(CmB_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ItemOutCategorized))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel_OutLayout.createSequentialGroup()
      .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane6))
     .addComponent(Pnl_ItemOutPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  TabbedPane.addTab("Brg Keluar", Panel_Out);

  Btn_TransRemove.setText("Hapus");
  Btn_TransRemove.setToolTipText("Operasi penghapusan akan menghapus transaksi yang dipilih, tetapi tidak mengubah stok barang yang berkaitan");
  Btn_TransRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransRemoveActionPerformed(evt);
   }
  });

  Btn_TransChoose.setText("Pilih {F11}");
  Btn_TransChoose.setToolTipText("Operasi penghapusan akan menghapus transaksi tanpa mengubah stok barang yang berkaitan");
  Btn_TransChoose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransChoose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransChooseActionPerformed(evt);
   }
  });

  Lbl_AllowMultipleChoose.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_AllowMultipleChoose.setText("{Boleh > 1}");

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(Btn_TransRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Lbl_AllowMultipleChoose)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Btn_TransChoose))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_TransRemove)
     .addComponent(Btn_TransChoose)
     .addComponent(Lbl_AllowMultipleChoose)))
  );

  Lbl_Title.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  Lbl_Title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_Title.setText("Daftar Transaksi Pending");

  jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_Before.setText("<");
  Btn_Before.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Before.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_BeforeActionPerformed(evt);
   }
  });

  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  CmB_Find.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Trans", "Id External", "Jenis Trans", "Subjek", "Salesman", "Kas Klr", "Ket. Kas Klr", "Kas Msk", "Ket. Kas Msk" }));

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Find)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Before)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_Before)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CB_ViewDate.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewDate.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewDate.setText("Tg");
  CB_ViewDate.setToolTipText("Tanggal Transaksi");
  CB_ViewDate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewDate.setIconTextGap(0);
  CB_ViewDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewDate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewDateActionPerformed(evt);
   }
  });

  CB_ViewDateBill.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewDateBill.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewDateBill.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewDateBill.setText("Th");
  CB_ViewDateBill.setToolTipText("Tanggal Tagih");
  CB_ViewDateBill.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewDateBill.setIconTextGap(0);
  CB_ViewDateBill.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewDateBill.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewDateBillActionPerformed(evt);
   }
  });

  CB_ViewDateRepayment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewDateRepayment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewDateRepayment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewDateRepayment.setText("Cl");
  CB_ViewDateRepayment.setToolTipText("Periode Cicil");
  CB_ViewDateRepayment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewDateRepayment.setIconTextGap(0);
  CB_ViewDateRepayment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewDateRepayment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewDateRepaymentActionPerformed(evt);
   }
  });

  CB_ViewSubject.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSubject.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSubject.setText("Sb");
  CB_ViewSubject.setToolTipText("Subjek");
  CB_ViewSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSubject.setIconTextGap(0);
  CB_ViewSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSubjectActionPerformed(evt);
   }
  });

  CB_ViewSalesman.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSalesman.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSalesman.setText("Sl");
  CB_ViewSalesman.setToolTipText("Salesman");
  CB_ViewSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSalesman.setIconTextGap(0);
  CB_ViewSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSalesmanActionPerformed(evt);
   }
  });

  CB_ViewCashOut.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashOut.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashOut.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashOut.setText("Ks K");
  CB_ViewCashOut.setToolTipText("Kas Keluar");
  CB_ViewCashOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashOut.setIconTextGap(0);
  CB_ViewCashOut.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashOut.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashOutActionPerformed(evt);
   }
  });

  CB_ViewCashOutComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashOutComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashOutComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashOutComment.setText("{C}");
  CB_ViewCashOutComment.setToolTipText("Keterangan Kas Keluar");
  CB_ViewCashOutComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashOutComment.setIconTextGap(0);
  CB_ViewCashOutComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashOutComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashOutCommentActionPerformed(evt);
   }
  });

  CB_ViewCashIn.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashIn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashIn.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashIn.setText("M");
  CB_ViewCashIn.setToolTipText("Kas Masuk");
  CB_ViewCashIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashIn.setIconTextGap(0);
  CB_ViewCashIn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashIn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashInActionPerformed(evt);
   }
  });

  CB_ViewCashInComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashInComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashInComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashInComment.setText("{C}");
  CB_ViewCashInComment.setToolTipText("Keterangan Kas Masuk");
  CB_ViewCashInComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashInComment.setIconTextGap(0);
  CB_ViewCashInComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashInComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashInCommentActionPerformed(evt);
   }
  });

  CB_ViewId.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewId.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewId.setText("Id");
  CB_ViewId.setToolTipText("Id Transaksi");
  CB_ViewId.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewId.setIconTextGap(0);
  CB_ViewId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIdActionPerformed(evt);
   }
  });

  CB_ViewIdExternal.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewIdExternal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewIdExternal.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewIdExternal.setText("{E}");
  CB_ViewIdExternal.setToolTipText("{ Id External }");
  CB_ViewIdExternal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewIdExternal.setIconTextGap(0);
  CB_ViewIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewIdExternal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIdExternalActionPerformed(evt);
   }
  });

  CB_ViewIsImportant.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewIsImportant.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewIsImportant.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewIsImportant.setText("P");
  CB_ViewIsImportant.setToolTipText("Penting");
  CB_ViewIsImportant.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewIsImportant.setIconTextGap(0);
  CB_ViewIsImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewIsImportant.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIsImportantActionPerformed(evt);
   }
  });

  CB_ViewItemIn.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewItemIn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewItemIn.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewItemIn.setText("Br M");
  CB_ViewItemIn.setToolTipText("Total Harga Barang Masuk & Bayar Keluar");
  CB_ViewItemIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewItemIn.setIconTextGap(0);
  CB_ViewItemIn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewItemIn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewItemInActionPerformed(evt);
   }
  });

  CB_ViewItemOut.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewItemOut.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewItemOut.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewItemOut.setText("K");
  CB_ViewItemOut.setToolTipText("Total Harga Barang Keluar & Bayar Masuk");
  CB_ViewItemOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewItemOut.setIconTextGap(0);
  CB_ViewItemOut.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewItemOut.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewItemOutActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(CB_ViewDate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewDateBill)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewDateRepayment)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewSubject)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewSalesman)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewCashOut)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCashOutComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCashIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCashInComment)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewIdExternal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewIsImportant)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewItemIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewItemOut))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_ViewDate)
    .addComponent(CB_ViewDateBill)
    .addComponent(CB_ViewDateRepayment)
    .addComponent(CB_ViewSubject)
    .addComponent(CB_ViewSalesman)
    .addComponent(CB_ViewCashOut)
    .addComponent(CB_ViewCashOutComment)
    .addComponent(CB_ViewCashIn)
    .addComponent(CB_ViewCashInComment)
    .addComponent(CB_ViewId)
    .addComponent(CB_ViewIdExternal)
    .addComponent(CB_ViewIsImportant)
    .addComponent(CB_ViewItemIn)
    .addComponent(CB_ViewItemOut))
  );

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
  );

  Tbl_Trans.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Trans.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  Tbl_Trans.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Trans.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Trans.setRowHeight(18);
  Tbl_Trans.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_TransMouseReleased(evt);
   }
  });
  Tbl_Trans.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_TransKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_TransKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_Trans);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_Title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 824, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_Title)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane1)
      .addGap(0, 0, 0)
      .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(TabbedPane))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_TransRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransRemoveActionPerformed
  transRemove();
 }//GEN-LAST:event_Btn_TransRemoveActionPerformed

 private void Btn_TransChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransChooseActionPerformed
  transChoose();
 }//GEN-LAST:event_Btn_TransChooseActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  int temp;

  if (Activ) {
   return;
  }

  Activ = true;

  Btn_TransChoose.setVisible(!wIsViewMode);
  Lbl_AllowMultipleChoose.setVisible(!wIsViewMode && wAllowMultipleChoose);

  if (!wIsPreTrans) {
   DbTable = "Trans";
   DbTransPendLock = IFV.TransPendLock;
   DbTransLock = IFV.TransLock;
   TransName = "Transaksi Pending";
  } else {
   DbTable = "PreTrans";
   DbTransPendLock = IFV.PreTransPendLock;
   DbTransLock = IFV.PreTransLock;
   TransName = "Pra-Transaksi Pending";
  }
  buildTableTransOrderBy();

  if (wIsViewMode) {
   setTitle("Lihat " + TransName + " ( {Esc} Utk Keluar )");
  } else {
   setTitle("Pilih " + TransName + " ( {Esc} Utk Keluar )");
  }

  Lbl_Title.setText("Daftar " + TransName);

  fillTableTrans();

  initFocus();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  if (!wIsViewMode) {
   DialogResult = 0;
  }
  clearComponents();
  Activ = false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_FindItemOutBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemOutBefActionPerformed
  findItemOut(2);
 }//GEN-LAST:event_Btn_FindItemOutBefActionPerformed

 private void Btn_FindItemOutNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemOutNextActionPerformed
  findItemOut(1);
 }//GEN-LAST:event_Btn_FindItemOutNextActionPerformed

 private void Btn_FindItemInBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemInBefActionPerformed
  findItemIn(2);
 }//GEN-LAST:event_Btn_FindItemInBefActionPerformed

 private void Btn_FindItemInNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemInNextActionPerformed
  findItemIn(1);
 }//GEN-LAST:event_Btn_FindItemInNextActionPerformed

 private void TF_FindItemInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindItemInKeyPressed
  int consumed = PNav.onKey_TF(this, TF_FindItemIn, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */ CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */ CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */ CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_FindItemIn)),
   /* Right */ CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemInBef)));
  if (consumed == CNav.Ret_Consumed) {
   return;
  }

  switch (evt.getKeyCode()) {
   case KeyEvent.VK_ENTER:
    Btn_FindItemInNextActionPerformed(null);
    break;
  }
 }//GEN-LAST:event_TF_FindItemInKeyPressed

 private void TF_FindItemOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindItemOutKeyPressed
  int consumed = PNav.onKey_TF(this, TF_FindItemOut, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */ CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */ CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */ CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_FindItemOut)),
   /* Right */ CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemOutBef)));
  if (consumed == CNav.Ret_Consumed) {
   return;
  }

  switch (evt.getKeyCode()) {
   case KeyEvent.VK_ENTER:
    Btn_FindItemOutNextActionPerformed(null);
    break;
  }
 }//GEN-LAST:event_TF_FindItemOutKeyPressed

 private void Btn_BeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_BeforeActionPerformed
  findTransInTable(2);
 }//GEN-LAST:event_Btn_BeforeActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findTransInTable(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed = PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */ CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */ CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Trans)),
   /* Left  */ CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Find)),
   /* Right */ CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Before)));
  if (consumed == CNav.Ret_Consumed) {
   return;
  }

  switch (evt.getKeyCode()) {
   case KeyEvent.VK_ENTER:
    Btn_FindNextActionPerformed(null);
    break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void Pnl_ItemOutPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Out, TableMdlOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutPreviewMouseClicked

 private void Pnl_ItemInPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_In, TableMdlIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInPreviewMouseClicked

 private void TF_DetSubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_DetSubjectMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Trans, TableMdlTrans, 9, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_DetSubjectMouseClicked

 private void TF_DetSalesmanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_DetSalesmanMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Trans, TableMdlTrans, 11, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_DetSalesmanMouseClicked

 private void Tbl_InKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_InKeyReleased
  onSelectedRowInChanged(false);

  int consumed = PNav.onKey_Tbl(this, Tbl_In, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */ CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FindItemIn)),
   /* Down  */ CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */ CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */ CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if (consumed == CNav.Ret_Consumed) {
   return;
  }
 }//GEN-LAST:event_Tbl_InKeyReleased

 private void Tbl_InMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_InMouseReleased
  onSelectedRowInChanged(false);
 }//GEN-LAST:event_Tbl_InMouseReleased

 private void Tbl_OutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_OutKeyReleased
  onSelectedRowOutChanged(false);

  int consumed = PNav.onKey_Tbl(this, Tbl_Out, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */ CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FindItemOut)),
   /* Down  */ CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */ CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */ CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if (consumed == CNav.Ret_Consumed) {
   return;
  }
 }//GEN-LAST:event_Tbl_OutKeyReleased

 private void Tbl_OutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_OutMouseReleased
  onSelectedRowOutChanged(false);
 }//GEN-LAST:event_Tbl_OutMouseReleased

 private void Tbl_TransKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransKeyPressed
  switch (evt.getKeyCode()) {
   case KeyEvent.VK_ENTER:
    if (!wIsViewMode && !Tbl_Trans.isEditing()) {
     if (Tbl_Trans.getSelectedRows().length != 0) {
      evt.consume();
      Btn_TransChooseActionPerformed(null);
     }
    }
    break;
  }
 }//GEN-LAST:event_Tbl_TransKeyPressed

 private void Tbl_TransKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransKeyReleased
  onSelectedRowTransChanged(false);

  PNav.onKey_Tbl(this, Tbl_Trans, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */ CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */ CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */ CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */ CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Tbl_TransKeyReleased

 private void Tbl_TransMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_TransMouseReleased
  onSelectedRowTransChanged(false);
 }//GEN-LAST:event_Tbl_TransMouseReleased

 private void CB_ItemOutCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutCategorizedActionPerformed
  changeItemOutViewByCategorized();
 }//GEN-LAST:event_CB_ItemOutCategorizedActionPerformed

 private void CB_ItemInCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemInCategorizedActionPerformed
  changeItemInViewByCategorized();
 }//GEN-LAST:event_CB_ItemInCategorizedActionPerformed

 private void CB_ViewDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewDateActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewDateActionPerformed

 private void CB_ViewDateBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewDateBillActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewDateBillActionPerformed

 private void CB_ViewDateRepaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewDateRepaymentActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewDateRepaymentActionPerformed

 private void CB_ViewSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSubjectActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewSubjectActionPerformed

 private void CB_ViewSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSalesmanActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewSalesmanActionPerformed

 private void CB_ViewCashOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashOutActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewCashOutActionPerformed

 private void CB_ViewCashOutCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashOutCommentActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewCashOutCommentActionPerformed

 private void CB_ViewCashInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashInActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewCashInActionPerformed

 private void CB_ViewCashInCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashInCommentActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewCashInCommentActionPerformed

 private void CB_ViewIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIdActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewIdActionPerformed

 private void CB_ViewIdExternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIdExternalActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewIdExternalActionPerformed

 private void CB_ViewIsImportantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIsImportantActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewIsImportantActionPerformed

 private void CB_ViewItemInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewItemInActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewItemInActionPerformed

 private void CB_ViewItemOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewItemOutActionPerformed
  changeTableTransView();
 }//GEN-LAST:event_CB_ViewItemOutActionPerformed

 private void TF_FindItemInFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemInFocusGained
  PGUI.text_SelectAll(TF_FindItemIn);
 }//GEN-LAST:event_TF_FindItemInFocusGained

 private void TF_FindItemOutFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemOutFocusGained
  PGUI.text_SelectAll(TF_FindItemOut);
 }//GEN-LAST:event_TF_FindItemOutFocusGained

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.ButtonGroup BG_FindItemIn;
 private javax.swing.ButtonGroup BG_FindItemOut;
 private javax.swing.JButton Btn_Before;
 private javax.swing.JButton Btn_FindItemInBef;
 private javax.swing.JButton Btn_FindItemInNext;
 private javax.swing.JButton Btn_FindItemOutBef;
 private javax.swing.JButton Btn_FindItemOutNext;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_TransChoose;
 private javax.swing.JButton Btn_TransRemove;
 private javax.swing.JCheckBox CB_DetImportant;
 private javax.swing.JToggleButton CB_ItemInCategorized;
 private javax.swing.JToggleButton CB_ItemOutCategorized;
 private javax.swing.JToggleButton CB_ViewCashIn;
 private javax.swing.JToggleButton CB_ViewCashInComment;
 private javax.swing.JToggleButton CB_ViewCashOut;
 private javax.swing.JToggleButton CB_ViewCashOutComment;
 private javax.swing.JToggleButton CB_ViewDate;
 private javax.swing.JToggleButton CB_ViewDateBill;
 private javax.swing.JToggleButton CB_ViewDateRepayment;
 private javax.swing.JToggleButton CB_ViewId;
 private javax.swing.JToggleButton CB_ViewIdExternal;
 private javax.swing.JToggleButton CB_ViewIsImportant;
 private javax.swing.JToggleButton CB_ViewItemIn;
 private javax.swing.JToggleButton CB_ViewItemOut;
 private javax.swing.JToggleButton CB_ViewSalesman;
 private javax.swing.JToggleButton CB_ViewSubject;
 private javax.swing.JComboBox<String> CmB_Find;
 private javax.swing.JComboBox<String> CmB_FindItemIn;
 private javax.swing.JComboBox<String> CmB_FindItemOut;
 private javax.swing.JLabel Lbl_AllowMultipleChoose;
 private javax.swing.JLabel Lbl_DetCashIn;
 private javax.swing.JLabel Lbl_DetCashOut;
 private javax.swing.JLabel Lbl_DetComment;
 private javax.swing.JLabel Lbl_DetCreditDays;
 private javax.swing.JLabel Lbl_DetDate;
 private javax.swing.JLabel Lbl_DetId;
 private javax.swing.JLabel Lbl_DetIdExternal;
 private javax.swing.JLabel Lbl_DetRepaymentPeriod;
 private javax.swing.JLabel Lbl_DetSalesman;
 private javax.swing.JLabel Lbl_DetSubject;
 private javax.swing.JLabel Lbl_DetTransType;
 private javax.swing.JLabel Lbl_Title;
 private javax.swing.JPanel Panel_Detail;
 private javax.swing.JPanel Panel_In;
 private javax.swing.JPanel Panel_Out;
 private XImgBoxURL Pnl_ItemInPreview;
 private XImgBoxURL Pnl_ItemOutPreview;
 private javax.swing.ButtonGroup RG_QImportant;
 private javax.swing.ButtonGroup RG_QItem;
 private javax.swing.ButtonGroup RG_Query;
 private javax.swing.JTextArea TA_DetComment;
 private javax.swing.JTextArea TF_DetCashIn;
 private javax.swing.JTextArea TF_DetCashOut;
 private javax.swing.JTextField TF_DetCreditDays;
 private javax.swing.JTextField TF_DetDate;
 private javax.swing.JTextField TF_DetId;
 private javax.swing.JTextField TF_DetIdExternal;
 private javax.swing.JTextField TF_DetRepaymentPeriod;
 private javax.swing.JTextField TF_DetSalesman;
 private javax.swing.JTextField TF_DetSubject;
 private javax.swing.JTextField TF_DetTransType;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_FindItemIn;
 private javax.swing.JTextField TF_FindItemOut;
 private javax.swing.JTextField TF_InCount;
 private javax.swing.JTextArea TF_InInfoCategory;
 private javax.swing.JTextArea TF_InInfoName;
 private javax.swing.JTextField TF_OutCount;
 private javax.swing.JTextArea TF_OutInfoCategory;
 private javax.swing.JTextArea TF_OutInfoName;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_In;
 private XTable Tbl_Out;
 private XTable Tbl_Trans;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 // End of variables declaration//GEN-END:variables
}
