import java.util.Date;

public class OEditItemSupplier {
 
 boolean EditComp; Long EditedCompId; String EditedCompName;
 boolean EditBuyPrc; int EditBuyPrcMode; Double EditedBuyPrc;
 boolean EditBuyComment; int EditBuyCommentMode; boolean EditBuyCommentSub; String EditedBuyCommentSub; String EditedBuyComment;
 boolean EditBuyUpdate; int EditBuyUpdateMode; Date EditedBuyUpdate;
 boolean EditIsActive; int EditIsActiveMode; Boolean EditedIsActive;
 
 public OEditItemSupplier(){clearAll();}
 
 OEditItemSupplier clearAll(){
  init(
   false, -1, null,
   false, 0, 0,
   false, 0, false, null, null,
   false, 0, null,
   false, 0, false);
  
  return this;
 }
 OEditItemSupplier init(
  boolean EditComp, long EditedCompId, String EditedCompName,
  boolean EditBuyPrc, int EditBuyPrcMode, double EditedBuyPrc,
  boolean EditBuyComment, int EditBuyCommentMode, boolean EditBuyCommentSub, String EditedBuyCommentSub, String EditedBuyComment,
  boolean EditBuyUpdate, int EditBuyUpdateMode, Date EditedBuyUpdate,
  boolean EditIsActive, int EditIsActiveMode, boolean EditedIsActive){
  
  this.EditComp = EditComp; this.EditedCompId = EditedCompId; this.EditedCompName = EditedCompName;
  this.EditBuyPrc = EditBuyPrc; this.EditBuyPrcMode=EditBuyPrcMode; this.EditedBuyPrc = EditedBuyPrc;
  this.EditBuyComment = EditBuyComment; this.EditBuyCommentMode=EditBuyCommentMode; this.EditBuyCommentSub = EditBuyCommentSub; this.EditedBuyCommentSub = EditedBuyCommentSub; this.EditedBuyComment = EditedBuyComment;
  this.EditBuyUpdate = EditBuyUpdate; this.EditBuyUpdateMode=EditBuyUpdateMode; this.EditedBuyUpdate = EditedBuyUpdate;
  this.EditIsActive = EditIsActive; this.EditIsActiveMode=EditIsActiveMode; this.EditedIsActive = EditedIsActive;
  
  return this;
 }
 
}