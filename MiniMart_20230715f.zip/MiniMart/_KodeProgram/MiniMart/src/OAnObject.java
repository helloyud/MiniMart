import java.util.Date;

public class OAnObject {
 
 boolean Defined;
 
 Object Obj;
 int Type;
 
 boolean UseSeparator;
 
 public OAnObject(){Defined=false;}
 public OAnObject(String Var){initString(Var);}
 public OAnObject(Integer Var, boolean UseSeparator){initInteger(Var, UseSeparator);}
 public OAnObject(Long Var, boolean UseSeparator){initLong(Var, UseSeparator);}
 public OAnObject(Double Var, boolean UseSeparator){initDouble(Var, UseSeparator);}
 public OAnObject(Boolean Var){initBoolean(Var);}
 public OAnObject(Date Var){initDate(Var);}
 
 void initString(String Var){setObject(Var, CCore.TypeString, false);}
 void initInteger(Integer Var, boolean UseSeparator){setObject(Var, CCore.TypeInteger, UseSeparator);}
 void initLong(Long Var, boolean UseSeparator){setObject(Var, CCore.TypeLong, UseSeparator);}
 void initDouble(Double Var, boolean UseSeparator){setObject(Var, CCore.TypeDouble, UseSeparator);}
 void initBoolean(Boolean Var){setObject(Var, CCore.TypeBoolean, false);}
 void initDate(Date Var){setObject(Var, CCore.TypeDate, false);}
 
 public void setObject(Object Obj, int Type,
  boolean UseSeparator){
  Defined=true;
  this.Obj=Obj;
  this.Type=Type;
  this.UseSeparator=UseSeparator;
 }
 
 String getValueString(){
  String ret=null;
  do{
   if(!Defined){break;}
   if(Obj==null){break;}
   if(Obj instanceof String){ret=(String)Obj; break;}
  }while(false);
  return ret;
 }
 Integer getValueInteger(){
  Integer ret=null;
  do{
   if(!Defined){break;}
   if(Obj==null){break;}
   if(Obj instanceof Integer){ret=(Integer)Obj; break;}
   if(Obj instanceof Double){ret=((Double)Obj).intValue(); break;}
  }while(false);
  return ret;
 }
 Long getValueLong(){
  Long ret=null;
  do{
   if(!Defined){break;}
   if(Obj==null){break;}
   if(Obj instanceof Long){ret=(Long)Obj; break;}
  }while(false);
  return ret;
 }
 Double getValueDouble(){
  Double ret=null;
  do{
   if(!Defined){break;}
   if(Obj==null){break;}
   if(Obj instanceof Double){ret=(Double)Obj; break;}
   if(Obj instanceof Integer){ret=((Integer)Obj).doubleValue(); break;}
  }while(false);
  return ret;
 }
 Boolean getValueBoolean(){
  Boolean ret=null;
  do{
   if(!Defined){break;}
   if(Obj==null){break;}
   if(Obj instanceof Boolean){ret=(Boolean)Obj; break;}
  }while(false);
  return ret;
 }
 Date getValueDate(){
  Date ret=null;
  do{
   if(!Defined){break;}
   if(Obj==null){break;}
   if(Obj instanceof Date){ret=(Date)Obj; break;}
  }while(false);
  return ret;
 }
 
 public String toString(){
  if(!Defined || Obj==null){return "";}
  
  switch(Type){
   case CCore.TypeString: return (String)Obj;
   case CCore.TypeInteger: if(!UseSeparator){return ((Integer)Obj).toString();}else{return PText.intToString((Integer)Obj);}
   case CCore.TypeLong: if(!UseSeparator){return ((Long)Obj).toString();}else{return PText.intToString((Long)Obj);}
   case CCore.TypeDouble: if(!UseSeparator){return PText.doubleToString((Double)Obj, true);}else{return PText.priceToString((Double)Obj);}
   case CCore.TypeBoolean: return ((Boolean)Obj).toString();
   case CCore.TypeDate: return PText.dateToString((Date)Obj, 2);
  }
  
  return "";
 }

}