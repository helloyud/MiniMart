public class OBarcodePatternsCode128 extends OBarcodePatterns {
 
 /*
  Code 128 Specification (http://www.adams1.com/128code.html)
  - Minimal X-Dimension = 7.5 mil
  - Minimal Quiet Zone = 10 X-Dimension (recommended 0.25 inch for optimum hand-scanning)
  - Minimal Height = 15% of width
 
  In this appication, the Code 128 use the following specification:
  - X-Dimension 8.3 mil
  - width = ??
            start quiet zone (10 module) +
            start (11 module) +
            ? data (@ 11 module / data) +
            checksum (11 module) +
            stop (13 module) +
            end quiet zone (10 module)
  - height = 13 mm
 */
 
 public static final double Code128IdealModuleWidth=OUnit.inch_to_pixel(0.0083);
 public static final double Code128IdealModuleHeight=OUnit.mm_to_pixel(18.5);
 
 public static OBarcodePatternsSpecification getStandardSpecification(){
  return new OBarcodePatternsSpecification(Code128IdealModuleWidth, Code128IdealModuleHeight, 1, 10, 10);
 }
 public static String[] getStandardPatterns(){
  String[] ret=new String[107]; // 0 - 106
  
  
  ret[  0] = "11011001100";    ret[ 10] = "11001000100";    ret[ 20] = "11001001110";    ret[ 30] = "11011011000";    ret[ 40] = "11000101000";
  ret[  1] = "11001101100";    ret[ 11] = "11000100100";    ret[ 21] = "11011100100";    ret[ 31] = "11011000110";    ret[ 41] = "11000100010";
  ret[  2] = "11001100110";    ret[ 12] = "10110011100";    ret[ 22] = "11001110100";    ret[ 32] = "11000110110";    ret[ 42] = "10110111000";
  ret[  3] = "10010011000";    ret[ 13] = "10011011100";    ret[ 23] = "11101101110";    ret[ 33] = "10100011000";    ret[ 43] = "10110001110";
  ret[  4] = "10010001100";    ret[ 14] = "10011001110";    ret[ 24] = "11101001100";    ret[ 34] = "10001011000";    ret[ 44] = "10001101110";
  ret[  5] = "10001001100";    ret[ 15] = "10111001100";    ret[ 25] = "11100101100";    ret[ 35] = "10001000110";    ret[ 45] = "10111011000";
  ret[  6] = "10011001000";    ret[ 16] = "10011101100";    ret[ 26] = "11100100110";    ret[ 36] = "10110001000";    ret[ 46] = "10111000110";
  ret[  7] = "10011000100";    ret[ 17] = "10011100110";    ret[ 27] = "11101100100";    ret[ 37] = "10001101000";    ret[ 47] = "10001110110";
  ret[  8] = "10001100100";    ret[ 18] = "11001110010";    ret[ 28] = "11100110100";    ret[ 38] = "10001100010";    ret[ 48] = "11101110110";
  ret[  9] = "11001001000";    ret[ 19] = "11001011100";    ret[ 29] = "11100110010";    ret[ 39] = "11010001000";    ret[ 49] = "11010001110";
  
  
  ret[ 50] = "11000101110";    ret[ 60] = "11101111010";    ret[ 70] = "10110000100";    ret[ 80] = "10100111100";    ret[ 90] = "11011110110";
  ret[ 51] = "11011101000";    ret[ 61] = "11001000010";    ret[ 71] = "10011010000";    ret[ 81] = "10010111100";    ret[ 91] = "11110110110";
  ret[ 52] = "11011100010";    ret[ 62] = "11110001010";    ret[ 72] = "10011000010";    ret[ 82] = "10010011110";    ret[ 92] = "10101111000";
  ret[ 53] = "11011101110";    ret[ 63] = "10100110000";    ret[ 73] = "10000110100";    ret[ 83] = "10111100100";    ret[ 93] = "10100011110";
  ret[ 54] = "11101011000";    ret[ 64] = "10100001100";    ret[ 74] = "10000110010";    ret[ 84] = "10011110100";    ret[ 94] = "10001011110";
  ret[ 55] = "11101000110";    ret[ 65] = "10010110000";    ret[ 75] = "11000010010";    ret[ 85] = "10011110010";    ret[ 95] = "10111101000";
  ret[ 56] = "11100010110";    ret[ 66] = "10010000110";    ret[ 76] = "11001010000";    ret[ 86] = "11110100100";    ret[ 96] = "10111100010";
  ret[ 57] = "11101101000";    ret[ 67] = "10000101100";    ret[ 77] = "11110111010";    ret[ 87] = "11110010100";    ret[ 97] = "11110101000";
  ret[ 58] = "11101100010";    ret[ 68] = "10000100110";    ret[ 78] = "11000010100";    ret[ 88] = "11110010010";    ret[ 98] = "11110100010";
  ret[ 59] = "11100011010";    ret[ 69] = "10110010000";    ret[ 79] = "10001111010";    ret[ 89] = "11011011110";    ret[ 99] = "10111011110";
  
  
  ret[100] = "10111101110";
  ret[101] = "11101011110";
  ret[102] = "11110101110";
  ret[103] = "11010000100";
  ret[104] = "11010010000";
  ret[105] = "11010011100";
  ret[106] = "1100011101011";
  
  
  return ret;
 }
 
}