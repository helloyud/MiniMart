import java.awt.Component;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.ActionMap;
import javax.swing.InputMap;

/* keyboard's navigation inside the GUI form */

public class OActionNav extends OAction {
 
 
 
 Window Form;
 InputMap inp;
 ActionMap act;
 Component[] ExcludeComponents;
 
 KeyEvent evt;
 
 
 
 public OActionNav(
  
  Window Form, InputMap inp, ActionMap act,
  Component[] ExcludeComponents,
  
  KeyEvent evt) {
  
  this.Form = Form;
  this.inp = inp;
  this.act = act;
  this.ExcludeComponents = ExcludeComponents;
  
  this.evt = evt;
  
 }
 
 
 
 public void actionPerformed(ActionEvent e) {
  PNav.actionNavDefault(Form.getFocusOwner(), CNav.StateKey_Universal, evt, Form, ExcludeComponents);
 }
 
 
 
}