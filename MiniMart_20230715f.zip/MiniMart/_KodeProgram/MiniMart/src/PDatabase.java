import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Calendar;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.util.Vector;

public class PDatabase{
 
 static OGregorianCalendar cal=new OGregorianCalendar();

 public static int queryToRows(Statement Stm, String Query, Vector<Object[]> Rows, int[] ColumnsType,
  OCustomModel Mdl,
  boolean OptSum, boolean[] SumColumn, double[] SumResult,
  boolean OptUpdateColumnsInfoFromResultSet,
  boolean OptFillCheckedFromCheckIdList, OQuickListOfLong CheckIdList, int CheckIdCol,
  boolean OptFillCheckedFromQueryCol, int FillCheckedFromQueryCol,
  boolean OptFilterAddByCheckIdList, boolean FilterAddCheckAndInsertToCheckIdList, boolean FilterAddOnlyIfInCheckIdList, OQuickListOfLong FilterAddCheckIdList, int FilterAddCheckIdCol){
  int ret=-1; // -1 error, >=0 data count
  int rettemp;
  
  int temp, temp_, result;
  boolean error, process_add;
  
  boolean vbool;
  
  long Id;
  
  int[] ColType=ColumnsType;
  ResultSet Rs;
  Object[] Row;
  
  boolean chk=false;
  boolean chk_default=false;
  Vector<Boolean> CheckList=null;
  boolean CheckIdColIsInteger=true;
  
  rettemp=0; error=false;
  do{
   try{
    do{
     
     if(OptSum){
      temp_=0; temp=SumColumn.length;
      do{
       SumResult[temp_]=0;
       temp_=temp_+1;
      }while(temp_!=temp);
     }

     Rs=Stm.executeQuery(Query);

     if(!Rs.next()){break;}

     // if table is for dynamic query, then update columns info
     if(OptUpdateColumnsInfoFromResultSet){
      Mdl.updateColumnsInfo(Rs.getMetaData());
      ColType=Mdl.getColumnsType();
     }
     
     if(Mdl!=null){
      chk=Mdl.isCheckable();
      if(chk){
       CheckList=Mdl.getCheckList();
       chk_default=Mdl.getCheckDefaultNewValue();
      }
     }

     if(OptFillCheckedFromCheckIdList){
      CheckIdColIsInteger=ColType[CheckIdCol]==CCore.TypeInteger;
     }

     do{
      Row=new Object[ColType.length];

      fillResultSetToRow(Rs, Row, ColType, OptSum, SumColumn, SumResult);

      process_add=true;
      if(OptFilterAddByCheckIdList){
       Id=PCore.getValueIntLong(Row[FilterAddCheckIdCol], ColType[FilterAddCheckIdCol]==CCore.TypeInteger, -1L);
       if(FilterAddCheckAndInsertToCheckIdList){result=FilterAddCheckIdList.addElement(Id);}
       else{result=FilterAddCheckIdList.checkElement(Id);}
       process_add=(result>=0 && FilterAddOnlyIfInCheckIdList) || (result<0 && !FilterAddOnlyIfInCheckIdList);
      }
      if(process_add){
       Rows.addElement(Row);
       
       if(chk){
        vbool=chk_default;

        if(OptFillCheckedFromCheckIdList){
         Id=PCore.getValueIntLong(Row[CheckIdCol], CheckIdColIsInteger, -1L);
         vbool=CheckIdList.checkElement(Id)>=0;
        }
        else if(OptFillCheckedFromQueryCol){
         try{vbool=Rs.getBoolean(FillCheckedFromQueryCol+1);}catch(Exception E){vbool=chk_default; error=true;}
        }

        CheckList.addElement(vbool);
        if(vbool){Mdl.addCheckedCount(1, true);}
       }

       rettemp=rettemp+1;
      }
     }while(Rs.next() && !error);
     
    }while(false);
    if(error){break;}
   }
   catch(Exception E){System.out.println(E.toString()); break;}
   ret=rettemp;
  }while(false);
   
  return ret;
 }
 public static void fillResultSetToRow(ResultSet Rs, Object[] Row, int[] Row_ColumnType,
  boolean OptSum, boolean[] SumColumn, double[] SumResult) throws Exception{
  int temp, length;
  
  boolean vbool;
  int vInt;
  long vLong;
  double vDouble;
  byte[] vBinary;
  String vString;
  Date vDate;
  
  temp=0; length=Row.length;
  do{
   switch(Row_ColumnType[temp]){

    case CCore.TypeString:
     vString=Rs.getString(temp+1);
     if(!Rs.wasNull()){Row[temp]=vString;}
     break;

    case CCore.TypeInteger:
     vInt=Rs.getInt(temp+1);
     if(!Rs.wasNull()){
      Row[temp]=vInt;
      if(OptSum){if(SumColumn[temp]){SumResult[temp]=SumResult[temp]+vInt;}}
     }
     break;

    case CCore.TypeLong:
     vLong=Rs.getLong(temp+1);
     if(!Rs.wasNull()){
      Row[temp]=new Long(vLong);
      if(OptSum){if(SumColumn[temp]){SumResult[temp]=SumResult[temp]+vLong;}}
     }
     break;

    case CCore.TypeDouble:
     vDouble=Rs.getDouble(temp+1);
     if(!Rs.wasNull()){
      Row[temp]=new Double(vDouble);
      if(OptSum){if(SumColumn[temp]){SumResult[temp]=SumResult[temp]+vDouble;}}
     }
     break;

    case CCore.TypeBoolean:
     vbool=Rs.getBoolean(temp+1);
     if(!Rs.wasNull()){Row[temp]=new Boolean(vbool);}
     break;

    case CCore.TypeDate:
     vDate=Rs.getDate(temp+1);
     if(!Rs.wasNull()){Row[temp]=vDate;}
     break;

    case CCore.TypeBinary:
     vBinary=Rs.getBytes(temp+1);
     if(!Rs.wasNull()){Row[temp]=vBinary;}
     break;

   }

   temp=temp+1;
  }while(temp!=length);
 }
 public static int queryToRows(Statement Stm, String Query, Vector<Object[]> Rows, int[] ColumnsType){
  return queryToRows(Stm, Query, Rows, ColumnsType, null, false, null, null, false, false, null, -1, false, -1, false, false, false, null, -1);
 }
 public static int queryToTable(Statement Stm, String Query, OCustomTableModel TableMdl,
  boolean UpdateColumnsInfoFromResultSet,
  boolean OptFillCheckedFromCheckIdList, OQuickListOfLong CheckIdList, int CheckIdCol,
  boolean OptFillCheckedFromQueryCol, int FillCheckedFromQueryCol){
  int ret=0; // -1 error, >=0 data count
  int temp, data_size;
  
  data_size=TableMdl.Mdl.Rows.size();
  
  temp=queryToRows(Stm, Query, TableMdl.Mdl.Rows, TableMdl.Mdl.ColumnsType,
   TableMdl, false, null, null, UpdateColumnsInfoFromResultSet,
   OptFillCheckedFromCheckIdList, CheckIdList, CheckIdCol, OptFillCheckedFromQueryCol, FillCheckedFromQueryCol,
   false, false, false, null, -1);
  if(temp==-1){return -1;}
  ret=ret+temp;
  
  if(ret>0){TableMdl.refreshInsert(data_size, data_size+(ret-1));}
  
  return ret;
 }
 public static int queryToTableWithSum(Statement Stm, String Query, OCustomTableModel TableMdl,
  boolean[] SumColumn, double[] SumResult,
  boolean UpdateColumnsInfoFromResultSet,
  boolean OptFillCheckedFromCheckIdList, OQuickListOfLong CheckIdList, int CheckIdCol,
  boolean OptFillCheckedFromQueryCol, int FillCheckedFromQueryCol){
  int ret=0; // -1 error, >=0 data count
  int temp, data_size;
  
  data_size=TableMdl.Mdl.Rows.size();
  
  temp=queryToRows(Stm, Query, TableMdl.Mdl.Rows, TableMdl.Mdl.ColumnsType, TableMdl,
   true, SumColumn, SumResult, UpdateColumnsInfoFromResultSet,
   OptFillCheckedFromCheckIdList, CheckIdList, CheckIdCol, OptFillCheckedFromQueryCol, FillCheckedFromQueryCol,
   false, false, false, null, -1);
  if(temp==-1){return -1;}
  ret=ret+temp;
  
  if(ret>0){TableMdl.refreshInsert(data_size, data_size+(ret-1));}
  
  return ret;
 }
 public static int queryToList(Statement Stm, String Query, OCustomListModel ListMdl,
  boolean OptFillCheckedFromCheckIdList, OQuickListOfLong CheckIdList, int CheckIdCol,
  boolean OptFillCheckedFromQueryCol, int FillCheckedFromQueryCol){
  int ret=0; // -1 error, >=0 data count
  int temp, data_size;
  
  data_size=ListMdl.Mdl.Rows.size();
  
  temp=queryToRows(Stm, Query, ListMdl.Mdl.Rows, ListMdl.Mdl.ColumnsType,
   ListMdl, false, null, null, false,
   OptFillCheckedFromCheckIdList, CheckIdList, CheckIdCol, OptFillCheckedFromQueryCol, FillCheckedFromQueryCol,
   false, false, false, null, -1);
  if(temp==-1){return -1;}
  ret=ret+temp;
  
  if(ret>0){ListMdl.refreshInsert(data_size, data_size+(ret-1));}
  
  return ret;
 }
 public static int queryToComboBox(Statement Stm, String Query, OCustomComboBoxModel CBMdl,
  boolean AddAdditionalData, String[] AdditionalData){
  int ret=0; // -1 error, >=0 data count
  int data_size, maincol, temp, additionalcount, colcount;
  Object[] Row;
  int[] ColumnsType;
  
  data_size=CBMdl.Mdl.Rows.size();
  
  if(AddAdditionalData){
   // initialize all additional-rows with default value
   additionalcount=AdditionalData.length;
   maincol=CBMdl.MainColumn;
   ColumnsType=CBMdl.getColumnsType();
   colcount=ColumnsType.length;
   temp=0;
   do{
    Row=new Object[colcount];
				Row[maincol]=AdditionalData[temp];
    CBMdl.Mdl.Rows.addElement(Row);
    temp=temp+1;
   }while(temp!=additionalcount);
   
   ret=ret+additionalcount;
  }
  
  temp=queryToRows(Stm, Query, CBMdl.Mdl.Rows, CBMdl.Mdl.ColumnsType, CBMdl, false, null, null, false, false, null, -1, false, -1,
   false, false, false, null, -1);
  if(temp==-1){return -1;}
  ret=ret+temp;
  
  if(ret>0){CBMdl.refreshInsert(data_size, data_size+(ret-1));}
  
  return ret;
 }
 
 public static void genNewId_Normal_Preparing(VInteger phase, VLong enumeration, VLong DbId, ResultSet Rs) throws Exception{
  // increase enumeration by 1 and define next phase
  enumeration.Value=0;
  do{
   if(!Rs.next()){phase.Value=3; break;}
   DbId.Value=Rs.getLong(1);
   if(enumeration.Value<DbId.Value){phase.Value=2; break;}
   phase.Value=1; break;
  }while(false);
 }
 public static Vector<Long> genNewId_Normal_Generating(VInteger phase, VLong enumeration, VLong DbId, ResultSet Rs, int GenerateCount) throws Exception{
  Vector<Long> ret=new Vector();
  boolean exit=false;
  
  /*
   phase :
   + lower than result set :
     1 enumeration = Db-Id
     2 enumeration < Db-Id
   3 higher than result set 
   4 end
  */
  do{
   do{

    if(phase.Value==1){
     do{
      // increase enumeration by 1 and define next phase
      enumeration.Value=enumeration.Value+1;
      if(!Rs.next()){phase.Value=3; break;}
      DbId.Value=Rs.getLong(1);
      if(enumeration.Value<DbId.Value){phase.Value=2; break;}
      if(enumeration.Value==Long.MAX_VALUE){phase.Value=4; break;}
     }while(phase.Value==1);
     break;
    }

    if(phase.Value==2){
     do{
      ret.addElement(enumeration.Value);

      // increase enumeration by 1 and define next phase
      if(enumeration.Value==Long.MAX_VALUE){phase.Value=4; break;}
      enumeration.Value=enumeration.Value+1;
      if(enumeration.Value==DbId.Value){phase.Value=1;}

      if(ret.size()==GenerateCount){exit=true; break;}
     }while(phase.Value==2);
     break;
    }

    if(phase.Value==3){
     do{
      ret.addElement(enumeration.Value);

      // increase enumeration by 1 and define next phase
      if(enumeration.Value==Long.MAX_VALUE){phase.Value=4; break;}
      enumeration.Value=enumeration.Value+1;

      if(ret.size()==GenerateCount){exit=true; break;}
     }while(phase.Value==3);
     break;
    }

    if(phase.Value==4){exit=true; break;}

   }while(false);
  }while(!exit);
  
  return ret;
 }
 public static Vector<Long> generateNewId(
  OBarcodeGenerator BarcodeGen, long SmallestEnumerationOfId_WithoutBarcodeGenerator, long SmallestEnumerationOfId_WithBarcodeGenerator,
  Statement Stm, String Query, int GenerateCount){
  Vector<Long> ret=null; // null = error, not null = smallest unused Id
  Vector<Long> rettemp=new Vector();
  long enumeration;
  ResultSet Rs;
  OQuickListOfLong Ids;
  long ErrorSign;
  long DbId;
  long GeneratedId;
  boolean loop=true;
  
  do{
   try{
    Rs=Stm.executeQuery(Query);

    if(BarcodeGen==null){
     /*
      ResultSet:
      - only has 1 column contains the list of existed Id
      - must have been sorted in ascending order
      - smallest number is 0
     */
     
     enumeration=SmallestEnumerationOfId_WithoutBarcodeGenerator;
     
     // lower than result set
     DbId=-1;
     if(Rs.next()){
      do{
       DbId=Rs.getLong(1);

       if(enumeration<DbId){
        do{
         rettemp.addElement(enumeration);
         if(rettemp.size()==GenerateCount){break;}

         if(enumeration==Long.MAX_VALUE){break;}
         enumeration=enumeration+1;
        }while(enumeration!=DbId);
        if(rettemp.size()==GenerateCount){break;}
       }

       if(enumeration==Long.MAX_VALUE){break;}
       enumeration=enumeration+1;
      }while(Rs.next());
     }
     
     // higher than result set
     if(rettemp.size()!=GenerateCount && DbId!=Long.MAX_VALUE){
      do{
       rettemp.addElement(enumeration);
       if(rettemp.size()==GenerateCount){break;}

       if(enumeration==Long.MAX_VALUE){break;}
       enumeration=enumeration+1;
      }while(loop);
     }
    }
    
    else{
     /*
      ResultSet:
      - only has 1 column contains the list of existed Id
      - smallest number is 0
     */
     
     enumeration=SmallestEnumerationOfId_WithBarcodeGenerator;
     
     Ids=new OQuickListOfLong(1024, 1024, true, true);
     if(Rs.next()){
      do{
       Ids.addElement(Rs.getLong(1));
      }while(Rs.next());
     }

     ErrorSign=BarcodeGen.generateCompatibleBarcodeFromNumberGetErrorSign();
     do{
      GeneratedId=BarcodeGen.generateCompatibleBarcodeFromNumber(enumeration);
      
      if(GeneratedId!=ErrorSign){
       if(Ids.addElement(GeneratedId)==-1){
        rettemp.addElement(GeneratedId);
        if(rettemp.size()==GenerateCount){break;}
       }
      }
      
      if(enumeration==Long.MAX_VALUE){break;}
      enumeration=enumeration+1;
     }while(loop);
    }
   }
   catch(Exception E){break;}
   ret=rettemp;
  }while(false);
  
  return ret;
 }
 public static Vector<Long> generateNewId(OBarcodeGenerator BarcodeGen,
  Statement Stm, String Query, int GenerateCount){
  return generateNewId(BarcodeGen, CCore.SmallestEnumerationOfId_WithoutBarcodeGenerator, CCore.SmallestEnumerationOfId_WithBarcodeGenerator,
   Stm, Query, GenerateCount);
 }
 public static Long generateNewId(OBarcodeGenerator BarcodeGen, Statement Stm, String Query){
  Long ret=null; // null = error, not null = smallest unused Id
  Vector<Long> rettemp;
  
  rettemp=generateNewId(BarcodeGen, Stm, Query, 1);
  if(rettemp!=null){
   if(rettemp.size()!=0){ret=rettemp.elementAt(0);}
  }
  
  return ret;
 }
 public static int isQueryEmpty(Statement Stm, String Query, boolean CheckNull){
  int ret=0; // 0 empty, 1 not empty, -1 error
  ResultSet Rs;
  Object obj;
  try{
   Rs=Stm.executeQuery(Query);
   if(Rs.next()==true){
    if(CheckNull){
     if(Rs.getObject(1)!=null){ret=1;}
    }
    else{ret=1;}
   }
  }
  catch(Exception E){
   ret=-1;
  }
  return ret;
 }
 public static Object[] getFirstRecords(Statement Stm, String Query, int[] Columns, int[] ColumnType) throws Exception{
  Object[] ret=null; // null = empty query
  Object obj;
  ResultSet rs;
  int temp, length;
  
  if(Columns==null){return ret;}
  
  length=Columns.length;
  if(length==0){return ret;}
  
  rs=Stm.executeQuery(Query);
  if(!rs.next()){return ret;}
  
  ret=new Object[length];
  temp=0;
  do{
   obj=getColumnFromResultSet(rs, Columns[temp], ColumnType[temp]);
   if(!rs.wasNull()){ret[temp]=obj;}
   
   temp=temp+1;
  }while(temp!=length);
   
  return ret;
 }
 public static Object getFirstRecord(Statement Stm, String Query, int Column, int ColumnType) throws Exception{
  Object ret=null;
  Object[] result=getFirstRecords(Stm, Query, PCore.primArr(Column), PCore.primArr(ColumnType));
  if(result!=null){
   if(result.length!=0){ret=result[0];}
  }
  return ret;
 }
 public static Object getColumnFromResultSet(ResultSet Rs, int Column, int ColumnType) throws Exception{
  Object ret=null;
  Object temp=null;
  switch(ColumnType){
   case CCore.TypeBoolean : temp=Rs.getBoolean(Column+1); break;
   case CCore.TypeInteger : temp=Rs.getInt(Column+1); break;
   case CCore.TypeLong : temp=Rs.getLong(Column+1); break;
   case CCore.TypeDouble : temp=Rs.getDouble(Column+1); break;
   case CCore.TypeString : temp=Rs.getString(Column+1); break;
   case CCore.TypeDate : temp=Rs.getDate(Column+1); break;
   default : temp=Rs.getObject(Column+1); break;
  }
  if(!Rs.wasNull()){ret=temp;}
  return ret;
 }
 public static Vector<Object> getListFromQuery(Statement Stm, String Query, int DataType,
  boolean AcceptNull, Object NullSubtitution){
  Vector<Object> ret=null;
  Vector<Object> rettemp=null;
  ResultSet Rs;
  Object Obj=null;
  boolean wasnull;
  
  do{
   try{
    Rs=Stm.executeQuery(Query);
    rettemp=new Vector();
    if(Rs.next()){
     do{
      Obj=getColumnFromResultSet(Rs, 0, DataType);
      wasnull=Rs.wasNull();
      if(AcceptNull || !wasnull){
       if(wasnull){Obj=NullSubtitution;}
       rettemp.addElement(Obj);
      }
     }while(Rs.next());
    }
   }
   catch(Exception E){break;}
   ret=rettemp;
  }while(false);
  
  return ret;
 }
 
 public static String getSQLStringWithOperator(Object Value, int Type,
  boolean NegativeNumberAsNull){
  String ret=null;
  
  if(isValueNull(Value, Type, NegativeNumberAsNull)){
   ret=" is "+CCore.vNull;
  }
  else{
   ret="="+getSQLString_(Value, Type);
  }
  
  return ret;
 }
 public static String getSQLString(Object Value, int Type, String ReplaceNull,
  boolean NegativeNumberAsNull){
  if(isValueNull(Value, Type, NegativeNumberAsNull)){return ReplaceNull;}
  return getSQLString_(Value, Type);
 }
 public static boolean isValueNull(Object Value, int Type,
  boolean NegativeNumberAsNull){
  boolean ret=true;
  long lg;
  double dbl;
  String str;
  
  do{
   if(Value==null){break;}
   
   if(NegativeNumberAsNull){
    if(Type==CCore.TypeInteger){lg=(Integer)Value; if(lg<0){break;}}
    if(Type==CCore.TypeLong){lg=(Long)Value; if(lg<0){break;}}
    if(Type==CCore.TypeDouble){dbl=(Double)Value; if(dbl<0){break;}}
   }
   
   if(Type==CCore.TypeString){str=(String)Value; if(PText.isEmptyString(str, false, true)){break;}}
   
   ret=false;
  }while(false);
  
  return ret;
 }
 public static String getSQLString_(Object Value, int Type){
  switch(Type){
   case CCore.TypeString   : return "'"+PSql.norm((String)Value)+"'";
   case CCore.TypeInteger  : return String.valueOf((Integer)Value);
   case CCore.TypeLong     : return String.valueOf((Long)Value);
   case CCore.TypeDouble   : return PText.doubleToString((Double)Value, false);
   case CCore.TypeBoolean  : return PText.getString((Boolean)Value, CCore.vTrue, CCore.vFalse);
   case CCore.TypeDate     : return dateToSQLStringFormat((Date)Value);
  }
  return null;
 }
 public static String dateToSQLStringFormatWithoutQuote(OGregorianCalendar Cal_){
  if(Cal_==null){return CCore.vNull;}
  return PText.paddingNumber(Cal_.get(Calendar.YEAR), 4)+"-"+PText.paddingNumber((Cal_.get(Calendar.MONTH)+1), 2)+"-"+
   PText.paddingNumber(Cal_.get(Calendar.DAY_OF_MONTH), 2);
 }
 public static String dateToSQLStringFormat(long TimeMillis){
  cal.setNewTimeInMillis(TimeMillis);
  return "'"+dateToSQLStringFormatWithoutQuote(cal)+"'";
 }
 public static String dateToSQLStringFormat(OGregorianCalendar Cal_){
  if(Cal_==null){return CCore.vNull;}
  return "'"+dateToSQLStringFormatWithoutQuote(Cal_)+"'";
 }
 public static String dateToSQLStringFormat(Date Dt){
  if(Dt==null){return CCore.vNull;}
  cal.setNewTime(Dt);
  return "'"+dateToSQLStringFormatWithoutQuote(cal)+"'";
 }
 public static String dateToSQLStringFormat(Date Dt, boolean EndDay){
  String ret=null;
  if(Dt==null){return CCore.vNull;}
  cal.setNewTime(Dt);
  if(!EndDay){ret="'"+dateToSQLStringFormatWithoutQuote(cal)+" 00:00:00'";}
  else{ret="'"+dateToSQLStringFormatWithoutQuote(cal)+" 23:59:59'";}
  return ret;
 }
 public static String dateToSQLStringFormat(OGregorianCalendar Cal_, boolean EndDay){
  String ret=null;
  if(Cal_==null){return CCore.vNull;}
  if(!EndDay){ret="'"+dateToSQLStringFormatWithoutQuote(Cal_)+" 00:00:00'";}
  else{ret="'"+dateToSQLStringFormatWithoutQuote(Cal_)+" 23:59:59'";}
  return ret;
 }
 
 public static String getSQLInsert(Vector<Object[]> Vect, int[] ColumnType, int StartIndex, int Count,
  int[] ColumnIndex, String[] ReplaceObjNull, boolean[] NegativeNumberAsNull){
  return getSQLInsert(Vect, ColumnType, PCore.newIntegerArrayInOrderedSequence(Count, StartIndex, 1),
  ColumnIndex, ReplaceObjNull, NegativeNumberAsNull);
 }
 public static String getSQLInsert(Vector<Object[]> Vect, int[] ColumnType, int[] SelectedRows,
  int[] ColumnIndex, String[] ReplaceObjNull, boolean[] NegativeNumberAsNull){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  
  boolean colfirst;
  int coltemp, colcount, col, rowcurr, rowcount;
  Object[] Objs;
  
  if(Vect==null){return ret.toString();}
  rowcount=Vect.size();
  if(rowcount==0){return ret.toString();}
  
  colcount=ColumnIndex.length;
  
  first=true;
  until=SelectedRows.length;
  temp=0;
  do{
   rowcurr=SelectedRows[temp];
   if(rowcurr<rowcount){
    if(first){first=false;}else{ret.append(",");}
    Objs=Vect.elementAt(rowcurr);
    ret.append("(");

    colfirst=true;
    coltemp=0;
    do{
     if(colfirst){colfirst=false;}else{ret.append(",");}
     col=ColumnIndex[coltemp];
     ret.append(getSQLString(Objs[col], ColumnType[col], ReplaceObjNull[coltemp], NegativeNumberAsNull[coltemp]));
     coltemp=coltemp+1;
    }while(coltemp!=colcount);

    ret.append(")");
   }
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }
 public static boolean executeBatchQueries(Statement Stm, String[] Queries){
  boolean ret=false;
  boolean started=false;
  int temp, length;
  
  if(Queries==null){return true;}
  length=Queries.length;
  if(length==0){return true;}
  
  do{
   try{
    Stm.execute("start transaction");
    started=true;
    
    temp=0;
    do{
     if(!PText.isEmptyString(Queries[temp], false, true)){
      Stm.execute(Queries[temp]);
     }
     
     temp=temp+1;
    }while(temp!=length);
    
    Stm.execute("commit");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  
  if(started && ret==false){
   try{Stm.execute("rollback");}catch(Exception E){}
  }
  
  return ret;
 }
 public static String buildJoinSingleSourceKey(String Columns, String SourceTable, String SourceTableKey, Vector<String[]> JoinData){
  /*
   - format of JoinData = join's table, join's table's key, join's conditions, join's other operation
   - this method builds "join query" as following format :
     level 0 = select <columns> from <src> left join <comp0> on <src>.<src_key>=<comp0>.<comp0_key> where <join0_conditions> <join0_other_operation>
     level 1 = select level0.* from (level 0) as level0 left join <comp1> on level0.<src_key>=<comp1>.<comp1.key> where <join1_conditions> <join1_other_operation>
     level 2 = select level1.* from (level 1) as level1 left join <comp2> on level1.<src_key>=<comp2>.<comp2.key> where <join2_conditions> <join2_other_operation>
     ...
  */
  StringBuilder ret=null;
  int temp, count;
  String join_bef;
  String curr_sourcetable;
  String[] curr_joindata;
  
  count=JoinData.size();
  temp=0;
  curr_sourcetable=SourceTable;
  join_bef=null;
  do{
   if(temp!=0){
    join_bef=ret.toString();
    curr_sourcetable="level"+(temp-1);
   }
   
   ret=new StringBuilder();
   
   curr_joindata=JoinData.elementAt(temp);
   
   ret.append("select ");

   // columns
   ret.append(PText.getString(temp, 0, curr_sourcetable+".*", Columns));

   // from "source table"
   ret.append(" from "+PText.getString(temp, 0, "("+join_bef+") as "+curr_sourcetable, SourceTable));

   // left join "complement table" on "source table's key" = "complement table's key"
   ret.append(" left join "+curr_joindata[0]+" on "+curr_sourcetable+"."+SourceTableKey+"="+curr_joindata[0]+"."+curr_joindata[1]);
   
   // where "join's conditions"
   if(curr_joindata[2]!=null){ret.append(" where "+curr_joindata[2]);}
   
   // other operation
   if(curr_joindata[3]!=null){ret.append(" "+curr_joindata[3]);}

   temp=temp+1;
  }while(temp!=count);
  
  return ret.toString();
 }
 
 public static String getCurrentDatabase(Statement Stm) throws Exception{
  String ret=null;
  Object obj;
  
  obj=PDatabase.getFirstRecord(Stm, "select database();", 0, CCore.TypeString);
  if(obj!=null){ret=obj.toString();}
  
  return ret;
 }
 
 public static int addARecordIdName(Statement Stm, String Table, String ValueName, boolean IdIsInteger, OParam ReturnParam){
  int ret=0; // -1 error, 0 success, 1 fail : Name Existed
  Long temp;
  do{
   try{
    temp=(long)isQueryEmpty(Stm, "select name from "+Table+" where name='"+PSql.norm(ValueName)+"';", false);
    if(temp==-1){ret=-1; break;}
    if(temp==1){ret=1; break;}
    temp=generateNewId(null, Stm, "select id from "+Table+" order by id asc;");
    if(temp==null){ret=-1; break;}
    Stm.executeUpdate("insert into "+Table+" (id, name) values ("+String.valueOf(temp)+",'"+PSql.norm(ValueName)+"');");
    if(IdIsInteger==true){
     ReturnParam.Param[0]=temp.intValue();
    }
    else{
     ReturnParam.Param[0]=temp;
    }
   }
   catch(Exception E){ret=-1;}
  }while(false);
  return ret;
 }
 public static boolean editRecordsIdName(Statement Stm, String Table, long[] Ids, OEditIdName Edit, OFormInformProgress Progress){
  boolean ret=false;
  VBoolean Started;
  
  int temp, count, MaxOp, currcount;
  long [] Ids_;
  double progress_inc=0;
  int progress_inc_times;
  
  StringBuilder col;
  String columns;
  boolean first, op_query;
  
  Started=new VBoolean(false);
  do{
   try{
    PDatabase.transactionStart(Stm, Started);
    
    count=Ids.length;
    op_query=false;
    col=new StringBuilder(); first=true;
    
    if(Edit.EditName){
     if(first){first=false;}else{col.append(',');}
     if(!Edit.ReplaceSubName){
      col.append("Name="+PText.getStringWithQuote(PSql.norm(Edit.EditedName), CCore.vNull, '\'', true));
     }
     else{
      col.append("Name=replace(Name, '"+PSql.norm(Edit.SubName)+"', '"+PSql.norm(Edit.EditedName)+"')");
     }
     op_query=true;
    }
    
    temp=0; MaxOp=1000; columns=col.toString();
    
    if(Progress!=null){
     progress_inc_times=PMath.round((double)count/(double)MaxOp, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    do{
     currcount=MaxOp; if(temp+currcount>count){currcount=count-temp;}
     Ids_=PCore.subArr(Ids, temp, currcount);
     
     if(op_query){
      Stm.execute("update "+Table+" set "+columns+" where Id in("+PText.toString(Ids_, 0, Ids_.length, ",")+")");
     }
     
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
     
     temp=temp+currcount;
    }while(temp!=count);
    
    PDatabase.transactionCommit(Stm, Started);
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(!ret){PDatabase.transactionRollback(Stm, Started);}
  
  return ret;
 }
 public static boolean removeARecord(Statement Stm, String Table, long Id){
  boolean ret=true;
  try{
   Stm.executeUpdate("delete from "+Table+" where id="+String.valueOf(Id)+";");
  }
  catch(Exception E){ret=false;}
  return ret;
 }
 public static String getNameFromId(Statement Stm, String Table, long Id){
  String ret=null;
  ResultSet Rs;
  try{
   Rs=Stm.executeQuery("select Name from "+Table+" where Id="+Id+";");
   if(Rs.next()==true){
    ret=Rs.getString(1);
   }
  }
  catch(Exception E){}
  return ret;
 }
 
 public static long[] insert_MultiRecords_AutoIncrement_ByList(
  Statement Stm, String Table, String LockId, int TimeoutSeconds,
  String[] ColsPK_NonIncrement_Name, int[] ColsPK_NonIncrement_Type, Object[] ColsPK_NonIncrement_Value,
  String ColPK_Increment_Name,
  String[] ColsNonPK_Name, int[] ColsNonPK_Type,
  Vector<Object[]> ColsNonPK_FromList, int[] ColsNonPK_FromList_SelectedRows, int[] ColsNonPK_FromList_ColsIndex){
  // ColPK_Increment_Type should be integer unsigned or long unsigned that begins from index 0.
  Vector<Long> ret=null;
  Vector<Long> rettemp=new Vector();
  boolean started, locked, error, first;
  Statement Stm3;
  ResultSet Rs, Rs3;
  int temp, CurrOpInsertCount, MaxEach, ColsPK_NonIncrement_Length, ColsNonPK_Length, SelectedRowsLength, CurrSelectedRow;
  long GeneratedId;
  Vector<Long> Enums;
  StringBuilder Cols, ColsValues, strb;
  VInteger phase=new VInteger();
  VLong enumeration=new VLong();
  VLong DbId=new VLong();
  Object[] Objs;
  
  SelectedRowsLength=ColsNonPK_FromList_SelectedRows.length;
  if(SelectedRowsLength==0){ret=rettemp; return PCore.primArr_VectLong(ret);}
  
  started=false; locked=false; error=false; Stm3=null;
  do{
   try{
    Stm3=Stm.getConnection().createStatement();
    
    Stm.execute("start transaction;");
    started=true;
    
    // get lock
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSeconds+");");
    if(!Rs.next()){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    // preparing insert records
    ColsPK_NonIncrement_Length=0; if(ColsPK_NonIncrement_Name!=null){ColsPK_NonIncrement_Length=ColsPK_NonIncrement_Name.length;}
    ColsNonPK_Length=0; if(ColsNonPK_Name!=null){ColsNonPK_Length=ColsNonPK_Name.length;}

     // preparing insert columns's name
    Cols=new StringBuilder(); first=true;

    if(ColsPK_NonIncrement_Length!=0){
     temp=0;
     do{
      if(first){first=false;}else{Cols.append(",");}
      Cols.append(ColsPK_NonIncrement_Name[temp]);
      temp=temp+1;
     }while(temp!=ColsPK_NonIncrement_Length);
    }

    if(first){first=false;}else{Cols.append(",");}
    Cols.append(ColPK_Increment_Name);

    if(ColsNonPK_Length!=0){
     temp=0;
     do{
      if(first){first=false;}else{Cols.append(",");}
      Cols.append(ColsNonPK_Name[temp]);
      temp=temp+1;
     }while(temp!=ColsNonPK_Length);
    }

     // preparing auto-generated-increment-id
    strb=new StringBuilder();
    if(ColsPK_NonIncrement_Length!=0){
     strb.append(" where");
     temp=0;
     do{
      if(temp!=0){strb.append(" and");}
      strb.append(" "+ColsPK_NonIncrement_Name[temp]+"="+getSQLString(ColsPK_NonIncrement_Value[temp], ColsPK_NonIncrement_Type[temp], CCore.vNull, false));
      temp=temp+1;
     }while(temp!=ColsPK_NonIncrement_Length);
    }

    Rs3=Stm3.executeQuery("select "+ColPK_Increment_Name+" from "+Table+strb.toString()+" order by "+ColPK_Increment_Name+" asc;");

    genNewId_Normal_Preparing(phase, enumeration, DbId, Rs3);
    
    // process insert records
    CurrSelectedRow=0; MaxEach=1000;
    do{
     // fetch records
     ColsValues=new StringBuilder();
     CurrOpInsertCount=0;
     do{
      // for each fetched cols_non-pk, also generate 1 id-autoincrement for cols_pk-increment
      if(CurrOpInsertCount!=0){ColsValues.append(",");}
      ColsValues.append("(");

      first=true;

      if(ColsPK_NonIncrement_Length!=0){
       temp=0;
       do{
        if(first){first=false;}else{ColsValues.append(",");}
        ColsValues.append(getSQLString(ColsPK_NonIncrement_Value[temp], ColsPK_NonIncrement_Type[temp], CCore.vNull, false));
        temp=temp+1;
       }while(temp!=ColsPK_NonIncrement_Length);
      }

      Enums=genNewId_Normal_Generating(phase, enumeration, DbId, Rs3, 1);
      if(Enums.size()!=1){error=true; break;}
      GeneratedId=Enums.elementAt(0);
      if(first){first=false;}else{ColsValues.append(",");}
      ColsValues.append(getSQLString(GeneratedId, CCore.TypeLong, CCore.vNull, false));
      rettemp.addElement(GeneratedId);
      
      if(ColsNonPK_Length!=0){
       Objs=ColsNonPK_FromList.elementAt(ColsNonPK_FromList_SelectedRows[CurrSelectedRow]);
       temp=0;
       do{
        if(first){first=false;}else{ColsValues.append(",");}
        ColsValues.append(getSQLString(Objs[ColsNonPK_FromList_ColsIndex[temp]], ColsNonPK_Type[temp], CCore.vNull, false));
        temp=temp+1;
       }while(temp!=ColsNonPK_Length);
      }

      ColsValues.append(")");

      CurrOpInsertCount=CurrOpInsertCount+1;
      CurrSelectedRow=CurrSelectedRow+1;
     }while(CurrSelectedRow!=SelectedRowsLength && CurrOpInsertCount!=MaxEach);
     if(error){break;}
     
     // build sql query & execute insert records operation !
     try{Stm.executeUpdate("insert into "+Table+"("+Cols.toString()+") values "+ColsValues.toString());}
     catch(Exception E){error=true; break;}
    }while(CurrSelectedRow!=SelectedRowsLength);
    if(error){break;}
    
    Stm.execute("commit");
   }
   catch(Exception E){System.out.println(E.toString()); break;}
   ret=rettemp;
  }while(false);
  if(Stm3!=null){try{Stm3.close();}catch(Exception E){} Stm3=null;}
  if(locked){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret==null){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return PCore.primArr_VectLong(ret);
 }
 public static boolean insert_MultiRecords_AutoIncrement_ByQuery(
  Statement Stm, String Table, String LockId, int TimeoutSeconds,
  String[] ColsPK_NonIncrement_Name, int[] ColsPK_NonIncrement_Type, Object[] ColsPK_NonIncrement_Value,
  String ColPK_Increment_Name,
  String[] ColsNonPK_Name, int[] ColsNonPK_Type, String ColsNonPK_Query){
  // ColPK_Increment_Type should be integer unsigned or long unsigned that begins from index 0.
  boolean ret=false;
  boolean started, locked, error, next, first;
  Statement Stm2, Stm3;
  ResultSet Rs, Rs2, Rs3;
  int temp, CurrOpInsertCount, MaxEach, ColsPK_NonIncrement_Length, ColsNonPK_Length;
  Vector<Long> Enums;
  StringBuilder Cols, ColsValues, strb;
  VInteger phase=new VInteger();
  VLong enumeration=new VLong();
  VLong DbId=new VLong();
  
  started=false; locked=false; error=false; Stm2=null; Stm3=null;
  do{
   try{
    Stm2=Stm.getConnection().createStatement();
    Stm3=Stm.getConnection().createStatement();
    
    Stm.execute("start transaction;");
    started=true;
    
    // get lock
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSeconds+");");
    if(!Rs.next()){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    // preparing insert records
    
     // fetch insert records
    Rs2=Stm2.executeQuery(ColsNonPK_Query);
    next=Rs2.next();
    
    if(next){
     
     ColsPK_NonIncrement_Length=0; if(ColsPK_NonIncrement_Name!=null){ColsPK_NonIncrement_Length=ColsPK_NonIncrement_Name.length;}
     ColsNonPK_Length=0; if(ColsNonPK_Name!=null){ColsNonPK_Length=ColsNonPK_Name.length;}
     
      // preparing insert columns's name
     Cols=new StringBuilder(); first=true;

     if(ColsPK_NonIncrement_Length!=0){
      temp=0;
      do{
       if(first){first=false;}else{Cols.append(",");}
       Cols.append(ColsPK_NonIncrement_Name[temp]);
       temp=temp+1;
      }while(temp!=ColsPK_NonIncrement_Length);
     }

     if(first){first=false;}else{Cols.append(",");}
     Cols.append(ColPK_Increment_Name);

     if(ColsNonPK_Length!=0){
      temp=0;
      do{
       if(first){first=false;}else{Cols.append(",");}
       Cols.append(ColsNonPK_Name[temp]);
       temp=temp+1;
      }while(temp!=ColsNonPK_Length);
     }

      // preparing auto-generated-increment-id
     strb=new StringBuilder();
     if(ColsPK_NonIncrement_Length!=0){
      strb.append(" where");
      temp=0;
      do{
       if(temp!=0){strb.append(" and");}
       strb.append(" "+ColsPK_NonIncrement_Name[temp]+"="+getSQLString(ColsPK_NonIncrement_Value[temp], ColsPK_NonIncrement_Type[temp], CCore.vNull, false));
       temp=temp+1;
      }while(temp!=ColsPK_NonIncrement_Length);
     }

     Rs3=Stm3.executeQuery("select "+ColPK_Increment_Name+" from "+Table+strb.toString()+" order by "+ColPK_Increment_Name+" asc;");

     genNewId_Normal_Preparing(phase, enumeration, DbId, Rs3);

     // process insert records
     MaxEach=1000;
     do{
      // fetch records
      ColsValues=new StringBuilder();
      CurrOpInsertCount=0;
      do{
       // for each fetched cols_non-pk, also generate 1 id-autoincrement for cols_pk-increment
       if(CurrOpInsertCount!=0){ColsValues.append(",");}
       ColsValues.append("(");

       first=true;

       if(ColsPK_NonIncrement_Length!=0){
        temp=0;
        do{
         if(first){first=false;}else{ColsValues.append(",");}
         ColsValues.append(getSQLString(ColsPK_NonIncrement_Value[temp], ColsPK_NonIncrement_Type[temp], CCore.vNull, false));
         temp=temp+1;
        }while(temp!=ColsPK_NonIncrement_Length);
       }

       Enums=genNewId_Normal_Generating(phase, enumeration, DbId, Rs3, 1);
       if(Enums.size()!=1){error=true; break;}
       if(first){first=false;}else{ColsValues.append(",");}
       ColsValues.append(getSQLString(Enums.elementAt(0), CCore.TypeLong, CCore.vNull, false));

       if(ColsNonPK_Length!=0){
        temp=0;
        do{
         if(first){first=false;}else{ColsValues.append(",");}
         ColsValues.append(getSQLString(getColumnFromResultSet(Rs2, temp, ColsNonPK_Type[temp]), ColsNonPK_Type[temp], CCore.vNull, false));
         temp=temp+1;
        }while(temp!=ColsNonPK_Length);
       }

       ColsValues.append(")");

       CurrOpInsertCount=CurrOpInsertCount+1;
       next=Rs2.next();
      }while(next && CurrOpInsertCount!=MaxEach);
      if(error){break;}

      // build sql query & execute insert records operation !
      try{Stm.executeUpdate("insert into "+Table+"("+Cols.toString()+") values "+ColsValues.toString());}
      catch(Exception E){error=true; break;}
     }while(next);
     if(error){break;}
    
    }
    
    Stm.execute("commit");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(Stm2!=null){try{Stm2.close();}catch(Exception E){} Stm2=null;}
  if(Stm3!=null){try{Stm3.close();}catch(Exception E){} Stm3=null;}
  if(locked){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean update_MultiRecords_EachRecordDifferentValues_ValuesFromList(Statement Stm,
  String Table, String[] UpdateCols, String[] PKCols,
  Vector<Object[]> List, int[] ListColumnsType, int[] ListSelectedRows,
  int[] ListCols_UpdateColsValue, int[] ListCols_PKColsValue){
  /*
   update 'Table'
   set 'UpdateCols[0]' = 'List's element[ ListCols_UpdateColsValue[0] ]' , 'UpdateCols[1]' = 'List's element[ ListCols_UpdateColsValue[1] ]' , ...
   where 'PKCols[0]' = 'List's element[ ListCols_PKColsValue[0] ]' and 'PKCols[1]' = 'List's element[ ListCols_PKColsValue[1] ]' and ...
  */
  
  boolean ret=false;
  boolean started=false;
  int updatecols_count=UpdateCols.length;
  int pkcols_count=PKCols.length;
  int ListSelectedRowLength=ListSelectedRows.length;
  int rowtemp, temp;
  
  StringBuilder strb;
  Object[] Objs;
  
  if(ListSelectedRowLength==0){return true;}
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    rowtemp=0;
    do{
     Objs=List.elementAt(ListSelectedRows[rowtemp]);
     
     strb=new StringBuilder();

     strb.append("update ignore "+Table);

     strb.append(" set");
     temp=0;
     do{
      if(temp!=0){strb.append(",");}
      strb.append(" "+UpdateCols[temp]+"="+
       getSQLString(Objs[ListCols_UpdateColsValue[temp]], ListColumnsType[ListCols_UpdateColsValue[temp]], CCore.vNull, false));

      temp=temp+1;
     }while(temp!=updatecols_count);

     strb.append(" where");
     temp=0;
     do{
      if(temp!=0){strb.append(" and");}
      strb.append(" "+PKCols[temp]+"="+
       getSQLString(Objs[ListCols_PKColsValue[temp]], ListColumnsType[ListCols_PKColsValue[temp]], CCore.vNull, false));

      temp=temp+1;
     }while(temp!=pkcols_count);
     
     Stm.executeUpdate(strb.toString());
     
     rowtemp=rowtemp+1;
    }while(rowtemp!=ListSelectedRowLength);
    if(rowtemp!=ListSelectedRowLength){break;}
     
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(started && ret==false){
   try{Stm.executeQuery("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static boolean removeIdsWithLock(OFormInformProgress Progress, Statement Stm, String LockId, int TimeoutSecond, String Tbl, long[] Id){
  boolean ret=false;
  boolean locked=false;
  boolean started=false;
  int temp;
  int count=Id.length;
  ResultSet Rs;
  StringBuilder Str;
  int Until, MaxEach, len;
  boolean first;
  double progress_inc=0;
  int progress_inc_times;
  
  MaxEach=1000;
  
  if(Progress!=null){
   progress_inc_times=PMath.round((double)count/(double)MaxEach, 1); if(progress_inc_times==0){progress_inc_times=1;}
   progress_inc=(double)(100-Progress.getProgress())/(double)progress_inc_times;
  }
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    // remove trans id
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSecond+");");
    if(Rs.next()==false){break;}
    temp=Rs.getInt(1);
    if(Rs.wasNull()){break;}
    if(temp!=1){break;}
    locked=true;
    
    temp=0;
    do{
     Str=new StringBuilder();
     Until=temp+MaxEach;
     if(count<Until){Until=count;}
     len=Until-temp;
     first=true;
     do{
      if(first){first=false;}
      else{Str.append(',');}
      Str.append(Id[temp]);
      temp=temp+1;
     }while(temp!=Until);
     Stm.executeUpdate("delete from "+Tbl+" where Id in ("+Str.toString()+");");
     if(Progress!=null){Progress.inform(progress_inc, null, null);}
    }while(temp!=count);
    if(temp==-1){break;}
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  if(locked){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret==false){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 
 public static void transactionStart(Statement Stm, VBoolean TransactionStarted) throws Exception{
  TransactionStarted.Value=false;
  Stm.executeUpdate("start transaction;");
  TransactionStarted.Value=true;
 }
 public static void transactionCommit(Statement Stm, VBoolean TransactionStarted) throws Exception{
  Stm.executeUpdate("commit;");
  TransactionStarted.Value=false;
 }
 public static void transactionRollback(Statement Stm, VBoolean TransactionStarted){
  if(!TransactionStarted.Value){return;}
  
  try{Stm.executeUpdate("rollback;");}catch(Exception E){}
  TransactionStarted.Value=false;
 }
 
 public static int lockingTable_Start(Statement Stm, String LockId, int TimeoutSeconds, VInteger LockStatus) throws Exception{
  // returning "lock status" : -1 error, -2 timeout, 1 success
  ResultSet Rs;
  int result;
  
  LockStatus.Value=-1;
  do{
   // get lock
   Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSeconds+");");
   if(!Rs.next()){break;}
   
   // get lock status
   result=Rs.getInt(1);
   if(Rs.wasNull()){break;}
   if(result==0){LockStatus.Value=-2; break;}
   
   LockStatus.Value=1;
  }while(false);
  
  return LockStatus.Value;
 }
 public static void lockingTable_End(Statement Stm, String LockId, VInteger LockStatus){
  if(LockStatus.Value!=1){return;}
  
  try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  LockStatus.Value=-1;
 }
 
 public static long addTransactionId(Statement Stm, String LockId, int TimeoutSeconds, boolean IsPreTrans,
  Date Dt, OInfoTrans Data, boolean Finalize){
  long ret=(long)PText.dateInNumber(Dt)*100000000; // -1 error, -2 timeout, >="YYYYMMDD+00000001" id
  String SQLDateFormat=PDatabase.dateToSQLStringFormat(Dt);
  ResultSet Rs;
  int temp=0; // 0 haven't get lock, 1 get lock
  long rettemp;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  
  String str=null;
  
  try{
   do{
    // get lock
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSeconds+");");
    if(Rs.next()==false){
     ret=-1;
     break;
    }
    
    // get lock status
    temp=Rs.getInt(1);
    if(Rs.wasNull()==false){
     if(temp==0){
      ret=-2;
      break;
     }
     else{temp=1;}
    }
    else{
     ret=-1;
     break;
    }
    
    // generate Id
    Rs=Stm.executeQuery("select max(Id) from "+Tbl+" where Id>"+ret+" and Id<="+(ret+99999999)+";");
    if(Rs.next()==true){
     rettemp=Rs.getLong(1);
     if(Rs.wasNull()==false){ret=rettemp;}
    }
    ret=ret+1;
    
    // insert Id
    if(Data==null){
     str="insert into "+Tbl+" (Id, TransDate, TransType, Subject, IsImportant, Comment, IsFinalized) values("+
      ret+","+SQLDateFormat+","+CCore.vNull+","+CCore.vNull+","+CCore.vFalse+","+CCore.vNull+","+PText.getString(Finalize, CCore.vTrue, CCore.vFalse)+");";
    }
    else{
     str="insert into "+Tbl+" (Id, TransDate, TransType, Subject, IsImportant, Comment, Salesman, CreditDays, Cash, CashIn, "+
      "RepaymentPeriodStart, RepaymentPeriodEnd, InfoIdExternal, CashOutComment, CashInComment, IsFinalized) values("+
      ret+","+PDatabase.dateToSQLStringFormat(Data.Dt)+","+PText.getString(Data.TypeId, CCore.vNull, -1, false)+","+
      PText.getString(Data.SubjectId, CCore.vNull, -1, false)+","+PText.getString(Data.Important, CCore.vTrue, CCore.vFalse)+","+
      PText.getStringWithQuote(PSql.norm(Data.Comment), CCore.vNull, '\'', true)+","+PText.getString(Data.SalesmanId, CCore.vNull, -1, false)+","+
      PText.getString(Data.CreditDays, CCore.vNull, -1, false)+","+PText.getString(Data.CashOutId, CCore.vNull, -1, false)+","+
      PText.getString(Data.CashInId, CCore.vNull, -1, false)+","+PDatabase.dateToSQLStringFormat(Data.RepaymentPeriodStart)+","+
						PDatabase.dateToSQLStringFormat(Data.RepaymentPeriodEnd)+","+PText.getStringWithQuote(PSql.norm(Data.InfoIdExternal), CCore.vNull, '\'', true)+","+
      PText.getStringWithQuote(PSql.norm(Data.CashOutComment), CCore.vNull, '\'', true)+","+PText.getStringWithQuote(PSql.norm(Data.CashInComment), CCore.vNull, '\'', true)+","+
      PText.getString(Finalize, CCore.vTrue, CCore.vFalse)+");";
    }
    Stm.executeUpdate(str);
   }while(false);
  }
  catch(Exception E){ret=-1;}
  // release lock
  if(temp==1){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  return ret;
 }
 public static int removeTransactionId(Statement Stm, String LockId, int TimeoutSecond, boolean IsPreTrans, long TransId, boolean RemoveEmptyOnly){
  int ret=-1; // -1 error, -2 timeout, 0 success
  ResultSet Rs;
  int lock=0; // 0 haven't get lock, 1 get lock
  String str;
  boolean started=false;
  
  String Tbl=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    // get lock
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSecond+");");
    if(Rs.next()==false){break;}
    
    // get lock status
    lock=Rs.getInt(1);
    if(Rs.wasNull()==true){break;}
    if(lock==0){ret=-2; break;}
    lock=1;
    
    // remove Id
    str=PText.getString(RemoveEmptyOnly, "call "+Tbl+"RemoveEmpty("+TransId+")", "delete from "+Tbl+" where Id="+TransId);
    Stm.executeUpdate(str);
    
    Stm.execute("commit;");
   }
   catch(Exception E){break;}
   ret=0;
  }while(false);
  if(lock==1){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  if(started && ret!=0){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 public static long addTransPendingId(Statement Stm, String LockId, int TimeoutSeconds, boolean IsPreTrans,
  OInfoTransPending Data){
  long ret=-1; // -1 error, -2 timeout, >=0 id
  ResultSet Rs;
  int temp=0; // 0 haven't get lock, 1 get lock
  long rettemp;
  
  String Tbl="Trans";
  if(IsPreTrans){Tbl="PreTrans";}
  
  String str=null;
  
  try{
   do{
    // get lock
    Rs=Stm.executeQuery("select get_lock('"+LockId+"',"+TimeoutSeconds+");");
    if(Rs.next()==false){
     ret=-1;
     break;
    }
    
    // get lock status
    temp=Rs.getInt(1);
    if(Rs.wasNull()==false){
     if(temp==0){
      ret=-2;
      break;
     }
     else{temp=1;}
    }
    else{
     ret=-1;
     break;
    }
    
    // generate Id
    Rs=Stm.executeQuery("select max(Id) from "+Tbl+"Pend;");
    if(Rs.next()==true){
     rettemp=Rs.getLong(1);
     if(Rs.wasNull()==false){ret=rettemp;}
    }
    ret=ret+1;
    
    // insert Id
    str="insert into "+Tbl+"Pend (Id, "+Tbl+"Id, TransDate, TransType, Subject, IsImportant, Comment, Salesman, CreditDays, CashOut, CashIn, "+
     "RepaymentPeriodStart, RepaymentPeriodEnd, InfoIdExternal, CashOutComment, CashInComment) values("+
     ret+","+Data.TransId+","+PDatabase.dateToSQLStringFormat(Data.Dt)+","+PText.getString(Data.TypeId, CCore.vNull, -1, false)+","+
     PText.getString(Data.SubjectId, CCore.vNull, -1, false)+","+PText.getString(Data.Important, CCore.vTrue, CCore.vFalse)+","+
     PText.getStringWithQuote(PSql.norm(Data.Comment), CCore.vNull, '\'', true)+","+PText.getString(Data.SalesmanId, CCore.vNull, -1, false)+","+
     PText.getString(Data.CreditDays, CCore.vNull, -1, false)+","+PText.getString(Data.CashOutId, CCore.vNull, -1, false)+","+
     PText.getString(Data.CashInId, CCore.vNull, -1, false)+","+PDatabase.dateToSQLStringFormat(Data.RepaymentPeriodStart)+","+
					PDatabase.dateToSQLStringFormat(Data.RepaymentPeriodEnd)+","+PText.getStringWithQuote(PSql.norm(Data.InfoIdExternal), CCore.vNull, '\'', true)+","+
      PText.getStringWithQuote(PSql.norm(Data.CashOutComment), CCore.vNull, '\'', true)+","+PText.getStringWithQuote(PSql.norm(Data.CashInComment), CCore.vNull, '\'', true)+");";
    Stm.executeUpdate(str);
   }while(false);
  }
  catch(Exception E){ret=-1;}
  // release lock
  if(temp==1){
   try{Stm.execute("select release_lock('"+LockId+"');");}catch(Exception E){}
  }
  return ret;
 }
 public static int[] removeTransPendingId(Statement Stm, String TransPendLockId, int TransPendTimeoutSecond, boolean IsPreTrans, long TransPendingId,
  boolean AlsoRemoveTrans, String TransLockId, int TransTimeoutSecond, boolean RemoveTransEmptyOnly){
  int[] ret=PCore.primArr(-1, -1); // index : 0 trans-pend, 1 trans ; result : -1 error, -2 timeout, 0 success
  ResultSet Rs;
  int lock; // 0 haven't get lock, 1 get lock
  boolean started=false;
  String str;
  long TransId=-1;
  
  String Tbl=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  
  do{
   try{
    Stm.execute("start transaction;");
    started=true;
    
    if(AlsoRemoveTrans){
     TransId=PCore.objLong(getFirstRecord(Stm, "select "+Tbl+"Id from "+Tbl+"Pend where Id="+TransPendingId, 0, CCore.TypeLong), -1L);
     if(TransId==-1){break;}
    }
   }
   catch(Exception E){break;}
   
   lock=0;
   do{
    try{
     // get lock
     Rs=Stm.executeQuery("select get_lock('"+TransPendLockId+"',"+TransPendTimeoutSecond+");");
     if(Rs.next()==false){break;}

     // get lock status
     lock=Rs.getInt(1);
     if(Rs.wasNull()==true){break;}
     if(lock==0){ret[0]=-2; break;}
     lock=1;

     // remove TransPendingId
     Stm.executeUpdate("delete from "+Tbl+"Pend where Id="+TransPendingId+";");
    }
    catch(Exception E){break;}
    ret[0]=0;
   }while(false);
   if(lock==1){
    try{Stm.execute("select release_lock('"+TransPendLockId+"');");}catch(Exception E){}
   }
   if(ret[0]!=0){break;}
   
   if(AlsoRemoveTrans){
    lock=0;
    do{
     try{
      // get lock
      Rs=Stm.executeQuery("select get_lock('"+TransLockId+"',"+TransTimeoutSecond+");");
      if(Rs.next()==false){break;}

      // get lock status
      lock=Rs.getInt(1);
      if(Rs.wasNull()==true){break;}
      if(lock==0){ret[1]=-2; break;}
      lock=1;

      // remove TransId
      str=PText.getString(RemoveTransEmptyOnly, "call "+Tbl+"RemoveEmpty("+TransId+")", "delete from "+Tbl+" where Id="+TransId);
      Stm.executeUpdate(str);
     }
     catch(Exception E){break;}
     ret[1]=0;
    }while(false);
    if(lock==1){
     try{Stm.execute("select release_lock('"+TransLockId+"');");}catch(Exception E){}
    }
    if(ret[1]!=0){break;}
   }
   
   try{Stm.execute("commit;");}catch(Exception E){ret[0]=-1; ret[1]=-1; break;}
  }while(false);
  if(started && (ret[0]!=0 || (AlsoRemoveTrans && ret[1]!=0))){
   try{Stm.execute("rollback;");}catch(Exception E){}
  }
  return ret;
 }
 
 public static boolean parameterValueInsert(Statement Stm, String DatabaseName, String TableName,
  OParameterValueGroup InsertData, boolean GetValueDefault, int GetValueIfNotIsAlreadyReturn){
  boolean ret=false;
  int temp, count;
  OParameterValue CurrData;
  boolean started;
  PreparedStatement PStm;
  
  started=false;
  do{
   try{
    Stm.executeUpdate("start transaction;");
    started=true;
    
    PStm=Stm.getConnection().prepareStatement("insert ignore into "+DatabaseName+"."+TableName+"(parameter, valuetype, value) values (?, ?, ?)");
    
    count=InsertData.size();
    temp=0;
    do{
     CurrData=InsertData.elementAt(temp);
     PStm.setString(1, CurrData.Parameter);
     PStm.setInt(2, CurrData.ValueType);
     PStm.setBytes(3, PSerialize.ser(CurrData.ValueType, CurrData.getValue(GetValueDefault, GetValueIfNotIsAlreadyReturn)));
     PStm.execute();

     temp=temp+1;
    }while(temp!=count);
    
    Stm.executeUpdate("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  
  if(!ret && started){
   try{Stm.executeUpdate("rollback;");}catch(Exception E){}
  }
  
  return ret;
 }
 public static boolean parameterValueUpdate(Statement Stm, String Database, String TableName,
  OParameterValueGroup UpdateData, boolean GetValueDefault, int GetValueIfNotIsAlreadyReturn){
  boolean ret=false;
  int temp, count;
  OParameterValue CurrData;
  boolean started;
  PreparedStatement PStm;
  
  started=false;
  do{
   try{
    Stm.executeUpdate("start transaction;");
    started=true;
    
    PStm=Stm.getConnection().prepareStatement("update "+PText.getString(Database, "", Database+".", true)+TableName+" set value=? where parameter=?;");
    
    count=UpdateData.size();
    temp=0;
    do{
     CurrData=UpdateData.elementAt(temp);
     PStm.setBytes(1, PSerialize.ser(CurrData.ValueType, CurrData.getValue(GetValueDefault, GetValueIfNotIsAlreadyReturn)));
     PStm.setString(2, CurrData.Parameter);
     PStm.execute();

     temp=temp+1;
    }while(temp!=count);
    
    Stm.executeUpdate("commit;");
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);
  
  if(!ret && started){
   try{Stm.executeUpdate("rollback;");}catch(Exception E){}
  }
  
  return ret;
 }
 public static OParameterValueGroup parameterValueGet(Statement Stm, String DatabaseName, String TableName,
  OParameterValueGroup Data){
  OParameterValueGroup ret;
  int temp, count, found_idx;
  Vector<Object[]> results;
  Object[] aresult;
  OParameterValue adata;
  
  count=Data.size();
  
  // generate Return OParameterValueGroup from the clone of Source OParameterValueGroup
  ret=new OParameterValueGroup();
  temp=0;
  do{
   ret.addElement(new OParameterValue(Data.elementAt(temp)).resetValue());
   temp=temp+1;
  }while(temp!=count);
  
  // store 'records from database' into 'temporary vector'
  results=new Vector();
  temp=queryToRows(Stm, "select parameter, value from "+PText.getString(DatabaseName, "", DatabaseName+".", false)+TableName+
   " where parameter in ("+PText.toStringWithQuote(Data.toStringParameters(), 0, count, ",", "\'", true)+");",
   results, PCore.primArr(CCore.TypeString, CCore.TypeBinary));
  if(temp==-1){return ret;}
  
  // define return values
  if(results.size()!=0){
   temp=0;
   do{
    adata=ret.elementAt(temp);
    found_idx=PTable.findString(results, 0, adata.Parameter);
    if(found_idx!=-1){
     aresult=results.elementAt(found_idx);
     adata.setValue(PSerialize.deser(adata.ValueType, aresult[1]), false);
    }
    temp=temp+1;
   }while(temp!=count);
  }
  return ret;
 }

 public static int convertJavaSQLDataTypeToMyType(ResultSetMetaData RsM, int ColumnIndex)
  throws Exception{
  /*
   My Type :
   1 String
   2 Integer
   3 Long
   4 Double
   5 Boolean
   6 Date
  */
  switch(RsM.getColumnType(ColumnIndex)){
   // 5 Boolean
   case Types.TINYINT: return CCore.TypeBoolean;
   case Types.BOOLEAN: return CCore.TypeBoolean;
   case Types.BIT: return CCore.TypeBoolean;
   
   // 2 Integer
   case Types.SMALLINT: return CCore.TypeInteger;
   case Types.INTEGER: return CCore.TypeInteger;
   
   // 3 Long
   case Types.BIGINT: return CCore.TypeLong;
   
   // 4 Double
   case Types.FLOAT: return CCore.TypeDouble;
   case Types.DOUBLE: return CCore.TypeDouble;
   case Types.DECIMAL: return CCore.TypeDouble;
   
   // 1 String
   case Types.CHAR: return CCore.TypeString;
   case Types.VARCHAR: return CCore.TypeString;
   
   // 6 Date
   case Types.DATE: return CCore.TypeDate;
   case Types.TIME: return CCore.TypeDate;
   case Types.TIMESTAMP: return CCore.TypeDate;
  }
  return CCore.TypeString;
 }

}