import java.util.Vector;

public class OEnum {
 
 /*
  this class act as an enumeration data type, which stores some pairs of key (integer) and value (Object).
 
  for example :
  
  - DataCount = 3, ValueType = String
    (1, "Small")
    (2, "Medium")
    (3, "Large")
 
  - DataCount = 5, ValueType = Character
    (1, 'A')
    (2, 'B')
    (3, 'C')
    (4, 'D')
    (5, 'E')
 */
 
 Vector<Object[]> Data;
 int ValueType;
 
 int DataCount;

 public OEnum(Vector<Object[]> Data, int ValueType) {
  this.Data = Data;
  this.ValueType = ValueType;
  DataCount = Data.size();
 }
 
 public Object getValue(Object Key, Object ReturnIfKeyNotFound){
  Object ret=ReturnIfKeyNotFound;
  int temp;
  Object[] Objs;
  long Key1, Key2;
  
  if(DataCount==0){return ret;}
  
  temp=0;
  do{
   Objs=Data.elementAt(temp);
   
   if(Objs[0]==null && Key==null){break;}
   if(Objs[0]!=null && Key!=null){
    Key1=(Integer)Objs[0]; Key2=(Integer)Key;
    if(Key1==Key2){break;}
   }
   
   temp=temp+1;
  }while(temp!=DataCount);
  if(temp!=DataCount){ret=Objs[1];}
  
  return ret;
 }
 
 public String getSQLQueryInsert(){
  return PDatabase.getSQLInsert(Data, PCore.primArr(CCore.TypeInteger, ValueType), 0, DataCount, PCore.newIntegerArrayInOrderedSequence(2, 0, 1),
   PCore.newStringArray(DataCount, CCore.vNull), PCore.newBooleanArray(DataCount, false));
 }
 
}