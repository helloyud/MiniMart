import java.awt.Font;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.AffineTransform;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;

public abstract class OPrintGenerator {

 // standard printing properties
 FontRenderContext Frc;
 OPaper PaperType;
 Statement Stm;
 OFont FontStandard; // used to calculate the point size of FontCustom when printing
 OFont FontCustom;
 OFont FontCustomThermal;
 Font FontType;
 Book GenBook;
 Vector<ODrawComponent> DrawComponents;
	double BaseX, BaseY;
 double CurrX, CurrY;
 int CurrPage;
	int CurrColumnar;
 ResultSet Rs;
 char[] Txt, TxtPage, Txt2, Txt3, Txt4;
 boolean IsANewPage;
	boolean IsANewColumnar;
 Date dt;
 String str;
 int it;
 long lg;
 double dbl;
 boolean bool;
 
 int LastUsedPaperType;
 int LastUsedPaperOrientation;
	int LastUsedColumnarCount;
 
 // standard printing layout variables
  // PageFormat
 PageFormat PgFormat;
  // paper
 double PaprWidth, PaprHeight,
        PaprImageableX, PaprImageableY,
        PaprImageableWidth, PaprImageableHeight;
  // oriented paper
 double OrientedPaprWidth, OrientedPaprHeight,
        OrientedPaprImageableX, OrientedPaprImageableY,
        OrientedPaprImageableWidth, OrientedPaprImageableHeight;
 int PaperOrientation; // portrait or landscape paper orientation
 OPaperMargin ChangeMarginPaperStatic, ChangeMarginPaperDynamic;
	 // Columnar
	int ColumnarCount;
	double ColumnarSpacing;
	double ColumnarWidth, ColumnarHeight;
  // paragraph
	int PageColumnCount;
 int MinimalColumnarColumnCount, ColumnarColumnCount;
 double LineSpacing, BaselineHeight, NormalHeight;
  // header
 double HeaderHeight, HeaderAddLineSpacing;
  // footer
 double FooterAddLineSpacing, FooterHeight;
  // margin bottom is only for thermal roll paper
 double OrientedPaprMarginBottomAddLineSpacing, OrientedPaprMarginBottom;
  // font
 double FontHeight, FontMaxAscent, FontMaxDescent;
 double FontWidth;
  // draw line
 double DrawLineSpacing, DrawLineHeight, DrawLineWidth;
 
 OPrintGenerator(OFont FontStandard){
  Frc=new FontRenderContext(new AffineTransform(), true, true);
  PgFormat=new PageFormat();
  PgFormat.setOrientation(PageFormat.PORTRAIT);
  PaperOrientation=PageFormat.PORTRAIT;
  this.FontStandard=FontStandard;
		if(!isMultiColumnar()){ColumnarCount=1;}
  nullifyLayout();
 }
 
 /*
  printing operation's common properties:
  - 72 dpi measurement tools
    - FontMetrics
  - printer and paper properties
    - on what paper that data will be printed.
    - printer's dpi.
  - printing data
  - printing layout/presentation
 */
 public Book generateBook(OFormInformProgress Prog){
  Book ret=null;
  boolean LayoutCalculated=false;
		boolean NextColumnarInCurrentPage;
  
  do{
   try{
    if(Prog!=null){Prog.inform(0, "Mempersiapkan proses pembuatan data print ...", "-");}
    calculateLayoutVariable();
    LayoutCalculated=true;
    prepareFirstPageData();
    
    // initialize print process variables
    initializePrintingVariables();
    if(Prog!=null){Prog.inform(5, null, null);}
    
    // construct a page by a page
    if(Prog!=null){
     Prog.inform(0, "Membuat halaman-halaman ...", "-");
     Prog.limitProgress(95);
    }
    do{
     startANewPage();
     if(Prog!=null){Prog.inform(0.3, null, "halaman "+PText.intToString(CurrPage));}
     // header
     addHeader();
     // body
					do{
						startANewColumnar();
						NextColumnarInCurrentPage=addColumnar();
					}while(CurrColumnar!=ColumnarCount && NextColumnarInCurrentPage);
     // footer
     addFooter();
     //
     defineRollPaperSize();
     GenBook.append(new OAPage(PaperOrientation, DrawComponents), PgFormat);
    }while(prepareNextPage());
    if(Prog!=null){
     Prog.unlimitProgress();
     Prog.inform(90, null, null);
    }
   }
   catch(Exception E){System.out.println(E.toString()); break;}
   ret=GenBook;
  }while(false);
  if(!LayoutCalculated){nullifyLayout();}
  clearVariable();
  return ret;
 }
 
 // standard private methods
 private void clearVariable(){
  DrawComponents=null;
  GenBook=null;
  Rs=null;
  Stm=null;
  Txt=null;
		TxtPage=null;
  dt=null;
  str=null;
  clearVar();
 }
	protected boolean isMultiColumnar(){return false;}
	protected boolean drawColumnarSeparator(){return true;}
 protected boolean isFooterWithLine(){return true;}
 protected boolean isHeaderWithLine(){return true;}
 protected boolean calculateLayoutPaper(){return true;}
 protected boolean calculateLayoutForCommonDrawing(){return true;}
 protected boolean changeMarginForStaticPaperSize(){return false;}
 protected boolean changeMarginForDynamicPaperSize(){return false;}
 protected OFont getCurrentFontCustom(){return FontCustom;}
	protected double getColumnarSpacing(){return 0.05*(OrientedPaprImageableWidth/ColumnarCount);}
 private void genOrientedPaper(){
  switch(PaperOrientation){
   case PageFormat.PORTRAIT :
    OrientedPaprWidth=PaprWidth;
    OrientedPaprHeight=PaprHeight;
    OrientedPaprImageableX=PaprImageableX;
    OrientedPaprImageableY=PaprImageableY;
    OrientedPaprImageableWidth=PaprImageableWidth;
    OrientedPaprImageableHeight=PaprImageableHeight;
    break;
   case PageFormat.LANDSCAPE :
    OrientedPaprWidth=PaprHeight;
    OrientedPaprHeight=PaprWidth;
    OrientedPaprImageableX=PaprHeight-(PaprImageableY+PaprImageableHeight);
    OrientedPaprImageableY=PaprImageableX;
    OrientedPaprImageableWidth=PaprImageableHeight;
    OrientedPaprImageableHeight=PaprImageableWidth;
    break;
   case PageFormat.REVERSE_LANDSCAPE :
    OrientedPaprWidth=PaprHeight;
    OrientedPaprHeight=PaprWidth;
    OrientedPaprImageableX=PaprImageableY;
    OrientedPaprImageableY=PaprWidth-(PaprImageableX+PaprImageableWidth);
    OrientedPaprImageableWidth=PaprImageableHeight;
    OrientedPaprImageableHeight=PaprImageableWidth;
    break;
  }
  OrientedPaprMarginBottom=OrientedPaprHeight-(OrientedPaprImageableY+OrientedPaprImageableHeight);
 }
 private void calculateLayoutVariable() throws Exception{
  double temp1;
  OFontLayout FontLayout;
  OFont CurrFont;
  
  // checkLastUsedLayout() method can be executed after all 'check variables' in checkLastUsedLayout() method has been set
  if(checkLastUsedLayout()){return;}
  
  if(calculateLayoutPaper()){
   if(!PaperType.IsRollPaper){
    if(changeMarginForStaticPaperSize() && ChangeMarginPaperStatic!=null){
     PaperType=(OPaper)PaperType.clone();
     PaperType.changeMargin(ChangeMarginPaperStatic);
    }
   }
   else{
    if(changeMarginForDynamicPaperSize() && ChangeMarginPaperDynamic!=null){
     PaperType=(OPaper)PaperType.clone();
     PaperType.changeMargin(ChangeMarginPaperDynamic);
    }
   }
   PaprWidth=PaperType.RealWidth;
   PaprHeight=PaperType.RealHeight;
   PaprImageableX=PaperType.RealImageableX;
   PaprImageableY=PaperType.RealImageableY;
   PaprImageableWidth=PaperType.RealImageableWidth;
   PaprImageableHeight=PaperType.RealImageableHeight;
  }
  
  PgFormat.setPaper(getPaper(PaprWidth, PaprHeight, PaprImageableX, PaprImageableY, PaprImageableWidth, PaprImageableHeight));
  
  genOrientedPaper();
		
		ColumnarSpacing=getColumnarSpacing();
		ColumnarWidth=(OrientedPaprImageableWidth-(ColumnarCount-1)*ColumnarSpacing)/ColumnarCount;

  if(calculateLayoutForCommonDrawing()){
   CurrFont=getCurrentFontCustom();
   FontLayout=getFontStandardLayout();
   FontType=PFont.getFont(CurrFont.FontFamily, CurrFont.getPointSize(FontStandard, FontLayout.PointSize),
    FontLayout.IsBold, FontLayout.IsItalic);
   FontWidth=FontType.getStringBounds("W", Frc).getWidth();
   LineMetrics lmetric=FontType.getLineMetrics("Wg", Frc);
   FontMaxAscent=lmetric.getAscent();
   FontMaxDescent=lmetric.getDescent();
   FontHeight=FontMaxAscent+FontMaxDescent;

   DrawLineWidth=1;

   LineSpacing=1;
   DrawLineSpacing=1;
   HeaderAddLineSpacing=4;
   FooterAddLineSpacing=4;
   OrientedPaprMarginBottomAddLineSpacing=4;

   BaselineHeight=LineSpacing+FontMaxAscent;
   NormalHeight=LineSpacing+FontHeight;
   DrawLineHeight=DrawLineSpacing+DrawLineWidth;
   temp1=DrawLineHeight;
   if(!isHeaderWithLine()){temp1=0;}
   HeaderHeight=HeaderAddLineSpacing+NormalHeight+temp1;
   temp1=DrawLineHeight;
   if(!isFooterWithLine()){temp1=0;}
   FooterHeight=FooterAddLineSpacing+NormalHeight+temp1;

   PageColumnCount=(int)(OrientedPaprImageableWidth/FontWidth);
			
			ColumnarColumnCount=(int)(ColumnarWidth/FontWidth);
   MinimalColumnarColumnCount=getMinimalColumnarColumnCount();
   if(ColumnarColumnCount<MinimalColumnarColumnCount){throw new Exception();}
  }
		
		ColumnarHeight=OrientedPaprImageableHeight;
		if(hasHeader()){ColumnarHeight=ColumnarHeight-HeaderHeight;}
		if(hasFooter()){ColumnarHeight=ColumnarHeight-FooterHeight;}
  
  calculateLayoutVariablesOptional();
  
  calculateLayoutVar();

  updateLastUsedLayout();
 }
 protected void calculateLayoutVariablesOptional() throws Exception{}
 protected void nullifyLayout(){
  LastUsedPaperType=-1;
  LastUsedPaperOrientation=-1;
		LastUsedColumnarCount=-1;
 }
 protected boolean checkLastUsedLayout(){
  boolean ret=false;
  do{
   if(PaperType.Id!=LastUsedPaperType){break;}
   if(PaperOrientation!=LastUsedPaperOrientation){break;}
			if(ColumnarCount!=LastUsedColumnarCount){break;}
   ret=true;
  }while(false);
  return ret;
 }
 protected void updateLastUsedLayout(){
  LastUsedPaperType=PaperType.Id;
  LastUsedPaperOrientation=PaperOrientation;
		LastUsedColumnarCount=ColumnarCount;
 }
 private void initializePrintingVariables(){
  GenBook=new Book();
  CurrPage=0;
  Txt=PText.createChars(ColumnarColumnCount, ' ');
		TxtPage=PText.createChars(PageColumnCount, ' ');
  initializePrintingVariablesOptional();
 }
 protected void initializePrintingVariablesOptional(){}
 private void startANewPage(){
  CurrPage=CurrPage+1;
  DrawComponents=new Vector();
		CurrY=0;
		CurrColumnar=0;
  IsANewPage=true;
 }
	private void startANewColumnar(){
		double separator_x, separator_y;
		CurrColumnar=CurrColumnar+1;
		if(CurrColumnar==1){BaseX=0; BaseY=CurrY;}
		else{
			BaseX=BaseX+ColumnarWidth+ColumnarSpacing;
			
			if(drawColumnarSeparator()){
				separator_x=BaseX-(ColumnarSpacing/2);
				separator_y=OrientedPaprImageableHeight; if(hasFooter()){separator_y=separator_y-FooterHeight;}
				DrawComponents.addElement(new ODrawComponentLine(separator_x, BaseY, separator_x+DrawLineWidth, separator_y));
			}
		}
  CurrX=0; CurrY=0;
		IsANewColumnar=true;
	}
 private void defineRollPaperSize(){
  if(!isCurrentPaperIsRollPaper()){return;}
  
  PgFormat=new PageFormat();
  PgFormat.setOrientation(PageFormat.PORTRAIT);
  PgFormat.setPaper(getPaper(PaprWidth, getCurrentRollPaperHeight(),
   PaprImageableX, PaprImageableY, PaprImageableWidth, getCurrentRollPaperImageableHeight()));
 }
 private OPaper getPaper(double Width, double Height,
  double ImageableX, double ImageableY, double ImageableWidth, double ImageableHeight){
  OPaper ret=new OPaper(PaperType);
  
  ret.changeSize(Width, Height);
  ret.changeImageableArea(ImageableX, ImageableY, ImageableWidth, ImageableHeight);
  
  return ret;
 }
 
 protected boolean checkOverColumnarHeight(double ComponentHeight){ // check if over page height or not
  if(CurrY+ComponentHeight>ColumnarHeight){return true;}
  return false;
 }
 protected boolean checkOverColumnarWidth(double ComponentWidth){ // check if over page width or not
  if(CurrX+ComponentWidth>ColumnarWidth){return true;}
  return false;
 }
 
 // abstract
 protected abstract boolean hasHeader();
 protected abstract boolean hasFooter();
 protected abstract void calculateLayoutVar() throws Exception;
 protected abstract void prepareFirstPageData() throws Exception;
 protected abstract void addHeader() throws Exception;
 protected abstract boolean addColumnar() throws Exception;
 protected abstract void addFooter() throws Exception;
 protected abstract boolean isCurrentPaperIsRollPaper();
 protected abstract double getCurrentRollPaperHeight();
 protected abstract double getCurrentRollPaperImageableHeight();
 protected abstract boolean prepareNextPage() throws Exception;
 protected abstract int getMinimalColumnarColumnCount();
 protected abstract OFontLayout getFontStandardLayout();
 protected abstract void clearVar();
 
}