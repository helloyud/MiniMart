import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class OGregorianCalendar extends GregorianCalendar {
 
 OGregorianCalendar(){
  setLenient(false);
 }
	
 void setNewTime(Date Dt){
		setTime(Dt);
	}
 void setNewTimeInMillis(long TimeMillis){
		setTimeInMillis(TimeMillis);
	}
	boolean setNewTime(int Year, int Month, int Day, boolean IsEndDay){
  boolean ret=true;
		
  try{
   set(Calendar.YEAR, Year);
   set(Calendar.MONTH, Month);
   set(Calendar.DATE, Day);
   
   /* disable set hour, minute, second, and milisecond because can cause error (maybe caused by bug in GregorianCalendar class) */
   set(Calendar.HOUR_OF_DAY, PCore.subtBool_Int(IsEndDay, 23, 0));
   set(Calendar.MINUTE, PCore.subtBool_Int(IsEndDay, 59, 0));
   set(Calendar.SECOND, PCore.subtBool_Int(IsEndDay, 59, 0));
   set(Calendar.MILLISECOND, PCore.subtBool_Int(IsEndDay, 999, 0)); 
   
   
   computeTime();
   //recalculateTimeInMillis(IsEndDay);
  }
  catch(Exception E){ret=false;}
		
  return ret;
 }
	boolean setNewTime(int Year, int Month, int Day){
  return setNewTime(Year, Month, Day, false);
 }
 
 private void recalculateTimeInMillis(boolean IsEndDay){
  /* cannot use this method because cannot provide accurate date output */
  long newmillis=getTimeInMillis();
  long mod;
  
  mod=(newmillis-CTime.BeginDayInMillis)%CTime.OneDayMillis;
  if(!(mod==0 || mod==CTime.OneDayMillis)){
   if(mod<0){mod=-1*mod;}
   if(newmillis>CTime.BeginDayInMillis){newmillis=newmillis-mod;}
   else{newmillis=newmillis+mod-CTime.OneDayMillis;}
  }
  
  if(IsEndDay){newmillis=newmillis+(CTime.OneDayMillis-1);}
  setNewTimeInMillis(newmillis);
 }
 
}