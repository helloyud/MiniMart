public class ODatabaseTableColumn {
 
 String Name;
 int SinceVersion;
 OVector<ODatabaseTableColumnType> ColumnTypes;

 public ODatabaseTableColumn(String Name, int SinceVersion, OVector<ODatabaseTableColumnType> ColumnTypes) {
  this.Name = Name;
  this.SinceVersion = SinceVersion;
  this.ColumnTypes = ColumnTypes;
 }
 
}