public class OGeneratedSQLValue {
 
 private String GeneratedSQLValue;
 private boolean IsGenerated;

 public OGeneratedSQLValue() {
  ungenerateSQLValue();
 }
 public OGeneratedSQLValue(String GeneratedSQLValue){
  setGeneratedSQLValue(GeneratedSQLValue);
 }
 
 public boolean isGenerated(){return IsGenerated;}
 public String getGeneratedSQLValue(){return GeneratedSQLValue;}
 
 public OGeneratedSQLValue setGeneratedSQLValue(String GeneratedSQLValue){
  this.GeneratedSQLValue=GeneratedSQLValue;
  IsGenerated=true;
  return this;
 }
 public OGeneratedSQLValue ungenerateSQLValue(){
  GeneratedSQLValue=null;
  IsGenerated=false;
  return this;
 }
 
}