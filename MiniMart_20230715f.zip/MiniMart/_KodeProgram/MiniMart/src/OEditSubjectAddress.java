public class OEditSubjectAddress {
 
 boolean EditCity; int EditCityMode; Integer EditedCityId; String EditedCityName;
 boolean EditAddr; int EditAddrMode; boolean EditAddrSub; String EditedAddrSub; String EditedAddr;
 boolean EditComment; int EditCommentMode; boolean EditCommentSub; String EditedCommentSub; String EditedComment;
 
 public OEditSubjectAddress(){clearAll();}
 
 OEditSubjectAddress clearAll(){
  init(
   false, 0, -1, null,
   false, 0, false, null, null,
   false, 0, false, null, null);
  
  return this;
 }
 OEditSubjectAddress init(
  boolean EditCity, int EditCityMode, int EditedCityId, String EditedCityName,
  boolean EditAddr, int EditAddrMode, boolean EditAddrSub, String EditedAddrSub, String EditedAddr,
  boolean EditComment, int EditCommentMode, boolean EditCommentSub, String EditedCommentSub, String EditedComment){
  
  this.EditCity = EditCity; this.EditCityMode = EditCityMode; this.EditedCityId = EditedCityId; this.EditedCityName = EditedCityName;
  this.EditAddr = EditAddr; this.EditAddrMode = EditAddrMode; this.EditAddrSub = EditAddrSub; this.EditedAddrSub = EditedAddrSub; this.EditedAddr = EditedAddr;
  this.EditComment = EditComment; this.EditCommentMode=EditCommentMode; this.EditCommentSub = EditCommentSub; this.EditedCommentSub = EditedCommentSub; this.EditedComment = EditedComment;
  
  return this;
 }
 
}