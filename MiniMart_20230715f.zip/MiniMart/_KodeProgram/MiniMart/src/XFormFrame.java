import javax.swing.JFrame;

public abstract class XFormFrame extends JFrame
 implements XForm{
 
 MInterFormVariables IFV;
 boolean Activ;
 int DialogResult; // 0 Cancel, 1 Ok
 
 public void preInitComponents(){
  
 }
 public void postInitComponents(){
  // getContentPane().setBackground(CGUI.Color_Form_Background);
 }
 
}