import java.util.Vector;

public class PSql {
 
 final static char SqlEscapeChar='\\';
 final static char[] SqlCharsRequireEscapeChar={'\\', '\'', '\"'};
 
 public static String norm(String Word){
  // normalizing Word by preceding the SqlCharsRequireEscapeChar inside Word with SqlEscapeChar
  return PText.precedeWithEscapeChar(Word, SqlCharsRequireEscapeChar, SqlEscapeChar);
 }
 public static String genCheckWord(String CheckVariable, String CheckValue, boolean DoBrokeWords, boolean UsingLogicAnd){
  return genCheckWord(CheckVariable, CheckValue, false, DoBrokeWords, CCore.Chars_Separator, false, UsingLogicAnd);
 }
 public static String genCheckWord(String CheckVariable, String CheckValue, boolean CaseSensitive,
  boolean DoBrokeWords, char[] BySeparators, boolean CollectSeparators, boolean UsingLogicAnd){
  StringBuilder ret=new StringBuilder();
  String[] SubWords;
  int temp, length;
  
  if(!DoBrokeWords){SubWords=PCore.refArr(CheckValue);}
  else{SubWords=PText.breakWords(CheckValue, BySeparators, CaseSensitive, CollectSeparators, true);}
  
  length=SubWords.length;
  ret.append("(");
  temp=0;
  do{
   if(temp!=0){ret.append(" "+PText.getString(UsingLogicAnd, "and", "or"));}
   
   if(temp!=0){ret.append(" ");}
   ret.append(CheckVariable+" like '%"+norm(SubWords[temp])+"%'");
   
   temp=temp+1;
  }while(temp!=length);
  ret.append(")");
  
  return ret.toString();
 }
 public static String genCheckList(String CheckVariable, String[] CheckValue){
  StringBuilder ret=new StringBuilder();
  String[] FilteredCheckValue;
  Vector<String> FilteredCheckValueTemp;
  boolean CheckValue_Null;
  boolean first;
  int temp;
  String Value;
  
  do{
   if(PCore.isArrayEmpty(CheckValue, true)){break;}
   
   //
   FilteredCheckValueTemp=new Vector(); CheckValue_Null=false;

   temp=0;
   do{
    Value=CheckValue[temp];

    if(Value!=null){FilteredCheckValueTemp.addElement(Value);}
    else{CheckValue_Null=true;}

    temp=temp+1;
   }while(temp!=CheckValue.length);

   FilteredCheckValue=PCore.primArr_VectString(FilteredCheckValueTemp);
   
   //
   first=true;
   ret.append("(");
   
   if(FilteredCheckValue.length!=0){
    if(first){first=false;}else{ret.append(" or");}
    ret.append(" "+CheckVariable+" in("+PText.toStringWithQuote(FilteredCheckValue, 0, FilteredCheckValue.length, ",", "'", true)+")");
   }
   
   if(CheckValue_Null){
    if(first){first=false;}else{ret.append(" or");}
    ret.append(" "+CheckVariable+" is "+CCore.vNull);
   }
   
   ret.append(")");
  }while(false);
  
  return ret.toString();
 }
 public static String genCheckList(String CheckVariable, long[] CheckValue, boolean CheckValue_NegativeAsNull){
  StringBuilder ret=new StringBuilder();
  long[] FilteredCheckValue;
  Vector<Long> FilteredCheckValueTemp;
  boolean CheckValue_Null;
  boolean first;
  int temp;
  long Value;
  
  do{
   if(PCore.isArrayEmpty(CheckValue, true)){break;}
   
   FilteredCheckValue=CheckValue; CheckValue_Null=false;
   
   if(CheckValue_NegativeAsNull){
    FilteredCheckValueTemp=new Vector();
    
    temp=0;
    do{
     Value=CheckValue[temp];
     
     if(Value>=0){FilteredCheckValueTemp.addElement(Value);}
     else{CheckValue_Null=true;}
     
     temp=temp+1;
    }while(temp!=CheckValue.length);
    
    FilteredCheckValue=PCore.primArr_VectLong(FilteredCheckValueTemp);
   }
   
   first=true;
   ret.append("(");
   
   if(FilteredCheckValue.length!=0){
    if(first){first=false;}else{ret.append(" or");}
    ret.append(" "+CheckVariable+" in("+PText.toString(FilteredCheckValue, 0, FilteredCheckValue.length, ",")+")");
   }
   
   if(CheckValue_Null){
    if(first){first=false;}else{ret.append(" or");}
    ret.append(" "+CheckVariable+" is "+CCore.vNull);
   }
   
   ret.append(")");
  }while(false);
  
  return ret.toString();
 }
 public static String genCheckList(String CheckVariable, int[] CheckValue, boolean CheckValue_NegativeAsNull){
  return genCheckList(CheckVariable, PCore.convertPrimArrIntToLong(CheckValue), CheckValue_NegativeAsNull);
 }
 public static String genCheckKey(
  String[] Keys, boolean Keys_OperatorAnd,
  Vector<Object[]> Values, int[] Values_DataType, int[] Values_KeysColumn, boolean Values_OperatorAnd, boolean NegativeNumberAsNull){
  StringBuilder ret=new StringBuilder();
  int rowcurr, rowcount, colcurr, colcount, keycol;
  String KeyStr, ValueWithOperatorStr;
  Object[] Value;
  
  rowcount=0; if(Values!=null){rowcount=Values.size();} if(rowcount==0){return ret.toString();}
  colcount=Keys.length;
  
  ret.append("(");
  
  rowcurr=0;
  do{
   if(rowcurr!=0){ret.append(PText.getString(Values_OperatorAnd, " and", " or"));}
   Value=Values.elementAt(rowcurr);
   
   ret.append(" (");
   
   colcurr=0;
   do{
    if(colcurr!=0){ret.append(PText.getString(Keys_OperatorAnd, " and", " or"));}
    KeyStr=Keys[colcurr];
    keycol=Values_KeysColumn[colcurr];
    ValueWithOperatorStr=PDatabase.getSQLStringWithOperator(Value[keycol], Values_DataType[keycol], NegativeNumberAsNull);
    
    ret.append(" "+KeyStr+ValueWithOperatorStr);
    
    colcurr=colcurr+1;
   }while(colcurr!=colcount);
   
   ret.append(")");
   
   rowcurr=rowcurr+1;
  }while(rowcurr!=rowcount);
  
  ret.append(")");
  
  return ret.toString();
 }
 public static String genCheckKey(
  String[] Keys, Vector<Object[]> Values, int[] Values_DataType, int[] Values_KeysColumn){
  return genCheckKey(Keys, true, Values, Values_DataType, Values_KeysColumn, false, true);
 }
 public static String genCheckKey(
  String[] Keys, Vector<Object[]> Values, int[] Values_DataType){
  return genCheckKey(Keys, true, Values, Values_DataType, PCore.newIntegerArrayInOrderedSequence(Keys.length, 0, 1), false, true);
 }
 public static String genVarAndValue(String Variable, Object Value, int ValueType, boolean NegativeNumberAsNull){
  return Variable+PDatabase.getSQLStringWithOperator(Value, ValueType, NegativeNumberAsNull);
 }

}