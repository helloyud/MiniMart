public abstract class OPrevent {
 public abstract void doPrevent(boolean Prevent);
 public abstract boolean isPrevent();
 public abstract void preventConfirmed();
}