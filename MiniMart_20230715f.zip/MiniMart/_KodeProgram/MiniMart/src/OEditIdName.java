public class OEditIdName {
 
 boolean EditName; boolean ReplaceSubName; String SubName; String EditedName;
 
 public OEditIdName(){clearAll();}
 
 OEditIdName clearAll(){
  init(false, false, null, null);
  
  return this;
 }

 OEditIdName init(
  boolean EditName, boolean ReplaceSubName, String SubName, String EditedName) {
  
  this.EditName = EditName; this.ReplaceSubName = ReplaceSubName; this.SubName = SubName; this.EditedName = EditedName;
  
  return this;
 }
 
}