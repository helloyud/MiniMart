import java.util.Calendar;
import java.util.Date;

public class PDate {
 
	static OGregorianCalendar Cal=new OGregorianCalendar();
 
 public static String spellDaysCount(int DaysCount, int Mode){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int left;
  
  if(DaysCount<0){return ret.toString();}
  
  switch(Mode){
   case 1: // YearSpell or MonthSpell or DaySpell
    if(DaysCount>=365){ret.append(PText.priceToString(DaysCount/365d)+" "+CTime.YearSpell); break;}
    if(DaysCount>=30){ret.append(PText.priceToString(DaysCount/30d)+" "+CTime.MonthSpell); break;}
    ret.append(DaysCount+" "+CTime.DaySpell); break;
   case 2: // YearSpellShort or MonthSpellShort or DaySpellShort
    if(DaysCount>=365){ret.append(PText.priceToString(DaysCount/365d)+" "+CTime.YearSpellShort); break;}
    if(DaysCount>=30){ret.append(PText.priceToString(DaysCount/30d)+" "+CTime.MonthSpellShort); break;}
    ret.append(DaysCount+" "+CTime.DaySpellShort); break;
   case 3: // YearSpell + MonthSpell + DaySpell
    first=true;
    left=DaysCount;
    if(left>=365){
     if(first){first=false;}else{ret.append(" ");}
     ret.append((left/365)+" "+CTime.YearSpell);
     left=left%365;
     if(left==0){break;}
    }
    if(left>=30){
     if(first){first=false;}else{ret.append(" ");}
     ret.append((left/30)+" "+CTime.MonthSpell);
     left=left%30;
     if(left==0){break;}
    }
    if(first){first=false;}else{ret.append(" ");}
    ret.append(left+" "+CTime.DaySpell);
    break;
   case 4: // YearSpellShort + MonthSpellShort + DaySpellShort
    first=true;
    left=DaysCount;
    if(left>=365){
     if(first){first=false;}else{ret.append(" ");}
     ret.append((left/365)+" "+CTime.YearSpellShort);
     left=left%365;
     if(left==0){break;}
    }
    if(left>=30){
     if(first){first=false;}else{ret.append(" ");}
     ret.append((left/30)+" "+CTime.MonthSpellShort);
     left=left%30;
     if(left==0){break;}
    }
    if(first){first=false;}else{ret.append(" ");}
    ret.append(left+" "+CTime.DaySpellShort);
    break;
   case 5: // DaySpell
    ret.append(PText.intToString(DaysCount)+" "+CTime.DaySpell); break;
   case 6: // DaySpellShort
    ret.append(PText.intToString(DaysCount)+" "+CTime.DaySpellShort); break;
  }
  
  return ret.toString();
 }
 public static int createDaysCount(int Years, int Months, int Days){return Years*365+Months*30+Days;}
	public static long getMillisFromDays(int Day, boolean ReplaceNegativeDay, long ReturnNegativeDay){
		if(Day<0 && ReplaceNegativeDay){return ReturnNegativeDay;}else{return Day*CTime.OneDayMillis;}
	}
 public static int grading(Date A, Date B, long NullValue){
  int ret=0; // 0 : (A = B), 1 : (A > B), 2 : (B > A)
  long millis_A, millis_B;
		
  millis_A=NullValue; if(A!=null){millis_A=generateDateInMillis(A, false);}
  millis_B=NullValue; if(B!=null){millis_B=generateDateInMillis(B, false);}
  
  if(millis_A!=millis_B){
   if(millis_A>millis_B){ret=1;}else{ret=2;}
  }
  
  return ret;
 }
	public static long calculateintervalTime(Date Dt1, Date Dt2, boolean ActDateAsDay){
		Date d1=Dt1;
		Date d2=Dt2;
		if(ActDateAsDay){
		 d1=generateDate(d1, false);
			d2=generateDate(calculateDateByDay(d2, 1, 1), false);
		}
		return d2.getTime()-d1.getTime();
	}
	public static int calculateIntervalDay(Date Dt1, Date Dt2){
		return PMath.round((double)calculateintervalTime(Dt1, Dt2, true)/(double)CTime.OneDayMillis, 0);
	}
	public static Date calculateDate(Date Dt, long TimeMillis, int CalculationMode){
		Date ret=null;
		long ResultMillis;
		
		if(Dt==null){return null;}
		
		ResultMillis=Dt.getTime();
		switch(CalculationMode){
			case 1 : ResultMillis=ResultMillis+TimeMillis; break; // add
			case 2 : ResultMillis=ResultMillis-TimeMillis; break; // minus
		}
		ret=new Date(ResultMillis);
		
		return ret;
	}
	public static Date calculateDateByDay(Date Dt, int Days, int CalculationMode){
		Date ret=null;
  int sign=PCore.subtBool_Int(CalculationMode==1, 1, -1);
		
		if(Dt==null){return ret;}
		
  Cal.setTime(Dt);
  Cal.add(Calendar.DAY_OF_MONTH, sign*Days);
		
		return Cal.getTime();
	}
	public static long getMillis(Date Dt, long NullValue){
		if(Dt==null){return NullValue;}else{return Dt.getTime();}
	}
	public static Date generateDate(int Year, int Month, int Day, boolean IsEndDay){
  if(!Cal.setNewTime(Year, Month, Day, IsEndDay)){return null;}
		return Cal.getTime();
	}
	public static Date generateDate(long TimeMillis, boolean IsEndDay){
		return new Date(generateDateInMillis(TimeMillis, IsEndDay));
	}
	public static Date generateDate(Date Dt, boolean IsEndDay){
		return new Date(generateDateInMillis(Dt.getTime(), IsEndDay));
	}
	public static long generateDateInMillis(long TimeMillis, boolean IsEndDay){
		Cal.setNewTimeInMillis(TimeMillis);
		return generateDate(Cal.get(Calendar.YEAR), Cal.get(Calendar.MONTH), Cal.get(Calendar.DAY_OF_MONTH), IsEndDay).getTime();
	}
	public static long generateDateInMillis(Date Dt, boolean IsEndDay){
		return generateDateInMillis(Dt.getTime(), IsEndDay);
	}
 public static Date parseDate(String Str){
  Date ret=null;
  long[] parse;
  
  parse=PText.parseNumbersToLong(Str);
  do{
   if(parse==null){break;}
   if(parse.length!=3){break;}
   if(!(parse[0]>=1000 && parse[0]<=9999)){break;}
   if(!(parse[1]>=1 && parse[1]<=12)){break;}
   if(!(parse[2]>=1 && parse[2]<=31)){break;}
   if(!Cal.setNewTime((int)parse[0], (int)parse[1]-1, (int)parse[2])){break;}
   ret=Cal.getTime();
  }while(false);
  
  return ret;
 }
 public static Date getMinMax(boolean IsMinimal, Date... Values){
  Date ret=null;
		int temp, length;
		Date dt;
		int grade_mode;
		
  if(Values==null){return ret;}
  
		length=Values.length;
		if(length==0){return ret;}
		
		ret=Values[0];
		if(length==1){return ret;}
		
		grade_mode=PCore.subtBool_Int(IsMinimal, 1, 2);
		temp=1;
		do{
			dt=Values[temp];
			if(PDate.grading(ret, dt, Long.MIN_VALUE)==grade_mode){ret=dt;}
			temp=temp+1;
		}while(temp!=length);
		
		return ret;
 }
 public static Date getDate(OGregorianCalendar Cal){
  Date ret=null;
  if(Cal!=null){ret=Cal.getTime();}
  return ret;
 }
 
 public static Date getMinMaxDate(Date Value1, Date Value2, boolean ChooseSmallestValue){
  Date ret=null;
  int grading;
  
  do{
   if(Value1==null && Value2==null){break;}

   if(Value2==null){ret=Value1; break;}
   if(Value1==null){ret=Value2; break;}
   
   ret=Value1;
   grading=grading(Value1, Value2, 0);
   if(grading==0){break;}
   if((ChooseSmallestValue && grading==1) || (!ChooseSmallestValue && grading==2)){ret=Value2;}
  }while(false);
  
  return ret;
 }
 
}