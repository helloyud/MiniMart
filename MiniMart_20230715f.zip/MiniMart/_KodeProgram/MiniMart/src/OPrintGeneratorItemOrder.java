import java.sql.Statement;
import java.util.LinkedList;

public class OPrintGeneratorItemOrder extends OPrintGenerator {
 
 // additional printing properties
 boolean ShowBuyPrice;
 boolean OptVariants; boolean OptVariants_ActiveYes, OptVariants_ActiveNo;
 LinkedList<Long> ItemsId;
 LinkedList<OIdName> ItemsCategory;
 String ItemsIdQ;
 OQuickListOfLong PrintedId;
 
 ODrawTableColumnMetadata[] Columns;
 
 int CategoryCount;
 OIdName CurrCategory;
 String CurrItemName;
 long CurrItemId;
	String CurrItemText;
	ODrawTableRow TableNewRow;
 ODrawTable Table;
 boolean CurrCategoryHeaderPrint;
 
 String QueryCondition_Variants;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 double CategoryAddLineSpacing, TableAddLineSpacing;
	final double CellAreaMinHeight=OUnit.mm_to_pixel(6);
 
 OPrintGeneratorItemOrder(OFont FontStandard) {super(FontStandard);}
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> ItemsId, boolean ShowBuyPrice,
  boolean OptVariants, boolean OptVariants_ActiveYes, boolean OptVariants_ActiveNo){
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.ItemsId=ItemsId;
  this.ShowBuyPrice=ShowBuyPrice;
  this.OptVariants=OptVariants; this.OptVariants_ActiveYes=OptVariants_ActiveYes; this.OptVariants_ActiveNo=OptVariants_ActiveNo;
 }
 
 // standard private methods
	protected boolean hasHeader(){return true;}
 protected boolean hasFooter(){return true;}
 protected boolean checkLastUsedLayout(){return false;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.5f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(7.5f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  OInset ContentInset;
  
  CategoryAddLineSpacing=7;
  TableAddLineSpacing=3;
  
  ContentInset=new OInset(OUnit.mm_to_pixel(0.7),
   OUnit.mm_to_pixel(0.7), OUnit.mm_to_pixel(1.1), OUnit.mm_to_pixel(1.1));
  
  Columns=new ODrawTableColumnMetadata[4];
  Columns[0]=new ODrawTableColumnMetadata("Barang", 0.425*OrientedPaprImageableWidth);
  Columns[1]=new ODrawTableColumnMetadata("Nama Suplier", 0.23*OrientedPaprImageableWidth);
  Columns[2]=new ODrawTableColumnMetadata("Qty", 0.115*OrientedPaprImageableWidth);
  Columns[3]=new ODrawTableColumnMetadata("Kisaran Harga", 0.23*OrientedPaprImageableWidth);
		
  // create an empty table for simulating purpose
		Table=new ODrawTable(Columns, ContentInset, ODrawTableBorder.DefaultFillAll);
 }
 protected void prepareFirstPageData() throws Exception{
		StringBuilder strb;
  boolean first;
  
  PrintedId=new OQuickListOfLong(1024, 1024, true, true);
  saveItemsId();
  saveItemsCategory();
  
  strb=new StringBuilder(); first=true;
  if(OptVariants){
   if(OptVariants_ActiveYes){
    if(first){first=false;}else{strb.append(" or");}
    strb.append(" ItemXVariant.IsActive="+CCore.vTrue);
   }
   if(OptVariants_ActiveNo){
    if(first){first=false;}else{strb.append(" or");}
    strb.append(" ItemXVariant.IsActive="+CCore.vFalse);
   }
   if(!first){
    strb=new StringBuilder(" and("+strb.toString()+")");
   }
  }
  QueryCondition_Variants=strb.toString();
  
  if(!getNextCategory()){throw new Exception();}
  if(!getItemsFromCurrCategory()){throw new Exception();}
 }
 protected void addHeader() throws Exception{
  int temp;
  double curr_x;
  
  temp=0;
  curr_x=0;
  do{
   DrawComponents.add(new ODrawComponentText(curr_x+PGraphics.getInsetX(Columns[temp].Width, FontType, Columns[temp].Name, OAlignment.HorizontalCenter),
    CurrY+BaselineHeight, FontType, Columns[temp].Name));
   
   curr_x=curr_x+Columns[temp].Width;
   temp=temp+1;
  }while(temp!=Columns.length);
  
  CurrY=CurrY+NormalHeight;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  CurrY=CurrY+HeaderAddLineSpacing;
 }
 protected boolean addColumnar() throws Exception{
  boolean KeepPrinting=true;
  boolean IsOverPage, ThereIs;
  double temp;
  ODrawTable tbl;
  
  do{
   // print curr item
   if(CurrCategoryHeaderPrint){
    if(IsANewColumnar){IsANewColumnar=false;}
    else{CurrY=CurrY+CategoryAddLineSpacing;}
    PText.refillChars(Txt, ' ');
    PText.fillStringToChars(Txt, PText.fitString("+ "+CurrCategory.Name, ColumnarColumnCount, true, ColumnarColumnCount-1, 1, '~'), 0, 1);
    DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
    CurrY=CurrY+NormalHeight;
    
    CurrCategoryHeaderPrint=false;
   }
   
   // print a table
   if(IsANewColumnar){IsANewColumnar=false;}
   else{CurrY=CurrY+TableAddLineSpacing;}
   tbl=Table.createNewTable();
   IsOverPage=false;
   do{
    tbl.insertARow(tbl.Rows.size(), TableNewRow);
    
    if(!getNextItemFromResultSet()){break;}
    if(checkOverColumnarHeight(tbl.Height+TableNewRow.Height)){IsOverPage=true; break;}
   }while(KeepPrinting);
   DrawComponents.add(new ODrawComponentTable(BaseX, BaseY+CurrY, tbl));
   if(IsOverPage){break;}
   CurrY=CurrY+tbl.Height;
   
   // searching if there is any category that has an item that haven't been printed
   ThereIs=true;
   do{
    if(!getNextCategory()){ThereIs=false; break;}
    if(getItemsFromCurrCategory()){break;}
   }while(ThereIs);
   if(!ThereIs){CurrItemName=null; break;}
   
   temp=CategoryAddLineSpacing+NormalHeight+TableAddLineSpacing+TableNewRow.Height;
   if(checkOverColumnarHeight(temp)){break;}
   
  }while(KeepPrinting);
		return false;
 }
 protected void addFooter() throws Exception{
  String FooterStr=null;
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  FooterStr="Hal. "+CurrPage;
  PText.fillStringToChars(TxtPage, FooterStr, PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  boolean ret=true;
  do{
   // prepare print data for next page
   if(CurrItemName==null){ret=false; break;}
  }while(false);
  return ret;
 }
 protected void clearVar(){
  ItemsId=null;
  ItemsCategory=null;
  CurrCategory=null;
  CurrItemName=null;
  ItemsIdQ=null;
  PrintedId=null;
  CurrItemText=null;
  TableNewRow=null;
 }
 
 // additional private methods
 void saveItemsId(){
  StringBuilder strb=new StringBuilder();
  strb=strb.append(ItemsId.pop().toString());
  if(!ItemsId.isEmpty()){
   do{
    strb.append(","+ItemsId.pop().toString());
   }while(!ItemsId.isEmpty());
  }
  ItemsIdQ=strb.toString();
 }
 void saveItemsCategory() throws Exception{
  OIdName data;
  int temp;
  boolean IsNull;
  ItemsCategory=new LinkedList();
  Rs=Stm.executeQuery(
   "select Id, Name from "+
    "(select CategoryOfItem from "+
     "(select Id from Item where Id in ("+ItemsIdQ+")) as i "+
    "left join ItemXCategory on i.Id=ItemXCategory.Item group by CategoryOfItem) as tb1 "+
   "left join CategoryOfItem on tb1.CategoryOfItem=CategoryOfItem.Id order by Name asc;");
  if(Rs.next()){
   IsNull=false;
   do{
    temp=Rs.getInt(1);
    if(Rs.wasNull()){IsNull=true;}
    else{
     data=new OIdName();
     data.Id=temp;
     data.Name=Rs.getString(2);
     ItemsCategory.addLast(data);
    }
   }while(Rs.next());
   if(IsNull){
    data=new OIdName();
    data.Id=-1;
    data.Name="~ Belum Terkategori ~";
    ItemsCategory.addLast(data);
   }
  }
  CategoryCount=ItemsCategory.size();
 }
 private boolean getNextCategory(){
  if(ItemsCategory.isEmpty()){return false;}
  CurrCategory=ItemsCategory.pop();
  return true;
 }
 private boolean getItemsFromCurrCategory() throws Exception{
  String con=null;
  String AdditionalTable="";
  
  if(CurrCategory.Id!=-1){
   AdditionalTable=", ItemXCategory";
   con="Item.Id=ItemXCategory.Item and Item.Id in ("+ItemsIdQ+") and ItemXCategory.CategoryOfItem="+CurrCategory.Id;
  }
  else{
   if(CategoryCount==1){con="Item.Id in ("+ItemsIdQ+")";}
   else{
    AdditionalTable=" left join ItemXCategory on Item.Id=ItemXCategory.Item";
    con="Item.Id in ("+ItemsIdQ+") and ItemXCategory.Item is null";
   }
  }
  
  Rs=Stm.executeQuery(
   "select tb4.*, Sum(PreTransXItemOut.Stock) as 'PreStockOut' from "+
    "(select tb3.*, Sum(PreTransXItemIn.Stock) as 'PreStockIn' from "+
     "(select tb2.*, Group_Concat(Variant Order By Variant asc Separator ', ') as 'Variants' from "+
      "(select tb1.*, StockUnit.Name as 'StockUnitName' from "+
       "(select Name, Id, StockUnit, Stock, MinimalStock, MaximalStock, OrderMinPack, OrderEachPackQty, BuyPriceEstimation, OrderQuantity from Item"+AdditionalTable+" where "+con+") as tb1 "+
      "left join  StockUnit on tb1.StockUnit=StockUnit.Id) as tb2 "+
     "left join ItemXVariant on tb2.Id=ItemXVariant.Item"+QueryCondition_Variants+" group by Id) as tb3 "+
    "left join PreTransXItemIn on tb3.Id=PreTransXItemIn.Item group by Id) as tb4 "+
   "left join PreTransXItemOut on tb4.Id=PreTransXItemOut.Item group by Id "+
   "order by Name asc;"
		);
  
  if(!getNextItemFromResultSet()){return false;}
  CurrCategoryHeaderPrint=true;
  return true;
 }
 private boolean getNextItemFromResultSet() throws Exception{
  String ItemVariants;
  double ItemStock, ItemStockMin, ItemStockMax,
   ItemPreStockIn, ItemPreStockOut, ItemStockEst;
  double ItemOrderMinPack, ItemOrderEachPackQty;
  double ItemBuyPriceEst;
		String ItemStockUnit;
  double ItemOrderQty;
  double ItemOrderPriceEst;
		boolean ThereIs;
		
		ThereIs=true;
		do{
			if(!Rs.next()){return false;}
			CurrItemName=Rs.getString(1); CurrItemId=Rs.getLong(2);
			if(PrintedId.addElement(CurrItemId)==-1){break;}
		}while(ThereIs);
		if(!ThereIs){return false;}
  
  ItemVariants=Rs.getString(12);
		ItemStock=Rs.getDouble(4);
		ItemStockMin=Rs.getDouble(5);
		ItemStockMax=Rs.getDouble(6);
  ItemOrderMinPack=Rs.getDouble(7);
  ItemOrderEachPackQty=Rs.getDouble(8);
  ItemBuyPriceEst=Rs.getDouble(9);
  ItemOrderQty=Rs.getDouble(10); if(Rs.wasNull()){ItemOrderQty=-1;}
		ItemStockUnit=Rs.getString(11);
		ItemPreStockIn=Rs.getDouble(13); if(Rs.wasNull()){ItemPreStockIn=0;}
		ItemPreStockOut=Rs.getDouble(14); if(Rs.wasNull()){ItemPreStockOut=0;}
		ItemStockEst=ItemStock+ItemPreStockIn-ItemPreStockOut;
  ItemOrderPriceEst=ItemOrderQty*ItemBuyPriceEst;

		str=
   CurrItemName+" ("+CurrItemId+")"+
   
   ", "+
			
   PText.priceToString(ItemStock)+" ("+PText.priceToString(ItemStockEst)+") "+
   PText.priceToString(ItemStockMin)+"-"+PText.priceToString(ItemStockMax)+" "+
			
   "["+
   "P-"+PText.priceToString(ItemOrderMinPack)+" "+
   "@"+PText.priceToString(ItemOrderEachPackQty)+
   "]"+
   
   PText.getString(ItemStockUnit, "", " "+ItemStockUnit, true)+
   
   ", "+
			
   PText.getStringDouble(ItemOrderQty, -0.1, PText.priceToString(ItemOrderQty), "-")+" X "+
   PText.getString(ShowBuyPrice, PText.priceToString(ItemBuyPriceEst), "-")+
   PText.getStringDouble(ItemOrderQty, -0.1, " ("+PText.getString(ShowBuyPrice, PText.priceToString(ItemOrderPriceEst), "-")+")", "");
		
  CurrItemText=str;
		
		createTableNewRow();
		
  return true;
 }
 private void createTableNewRow(){
  ODimension dim;
  
  // Create new row
  TableNewRow=new ODrawTableRow(0, Table.ColumnsCount);
  
   // set new row's cells
  TableNewRow.setCell(0, new ODrawTableCellText(CurrItemText, FontType, LineSpacing, ODrawComponentText.DefaultAlignment));
		
   // set new row's height
  if(TableNewRow.preGenerateCellsDrawContents(Table, 0)==false){TableNewRow.clearAllCells(); return;}
  dim=TableNewRow.calculatePreGeneratedCellsDrawContentsDimension(Table, 0);
  dbl=PCore.getMinMax_Double(false, PCore.refArr(CellAreaMinHeight, dim.getHeight()));
  TableNewRow.setHeight(dbl+(Table.Inset.InsetTop+Table.Inset.InsetBottom));
  
  TableNewRow.generateCellsDrawContents(Table, 0);
 }
 
}