import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.text.JTextComponent;

public class F_ItemImportUpdate extends XFormDialog {
 
 OCustomTableModel TableMdlFilePreview;
 int PreviewMaxRows;
 
 OFileCsv ChoosedFile;
 
 int ChoosedStockUnitId;
 String ChoosedStockUnitName;
 
 //
 
 OFileCsv FileCsv;
 
 VInteger BasedFileField;
 
 VBoolean UpdateId; VInteger IdFileField;
 VBoolean UpdateName; VInteger NameFileField;
 VBoolean UpdateIsActive; VBoolean IsActiveByFile; VInteger IsActiveFileField; VBoolean IsActive;
 VBoolean UpdateComment; VBoolean CommentByFile; VInteger CommentFileField; VString Comment;
 
 VBoolean UpdateStockUnit; VBoolean StockUnitByFile; VInteger StockUnitFileField; VInteger StockUnitId;
 VBoolean UpdateStock; VBoolean StockByFile; VInteger StockFileField; VDouble Stock;
 VBoolean UpdateUpStock; VBoolean UpStockByFile; VInteger UpStockFileField; VBoolean UpStock;
 VBoolean UpdateStockMin; VBoolean StockMinByFile; VInteger StockMinFileField; VDouble StockMin;
 VBoolean UpdateStockMax; VBoolean StockMaxByFile; VInteger StockMaxFileField; VDouble StockMax;
 
 VBoolean UpdateIsOpname; VBoolean IsOpnameByFile; VInteger IsOpnameFileField; VBoolean IsOpname;
 VBoolean UpdateIsReorder; VBoolean IsReorderByFile; VInteger IsReorderFileField; VBoolean IsReorder;
 VBoolean UpdateOrderMinPack; VBoolean OrderMinPackByFile; VInteger OrderMinPackFileField; VDouble OrderMinPack;
 VBoolean UpdateOrderEachPackQty; VBoolean OrderEachPackQtyByFile; VInteger OrderEachPackQtyFileField; VDouble OrderEachPackQty;
 VBoolean UpdateOrderEachPackThreshold; VBoolean OrderEachPackThresholdByFile; VInteger OrderEachPackThresholdFileField; VDouble OrderEachPackThreshold;
 
 VBoolean UpdateHasExp; VBoolean HasExpByFile; VInteger HasExpFileField; VBoolean HasExp;
 VBoolean UpdateExpCheckPeriod; VBoolean ExpCheckPeriodByFile; VInteger ExpCheckPeriodFileField; VInteger ExpCheckPeriod;
 VBoolean UpdateExpThreshold; VBoolean ExpThresholdByFile; VInteger ExpThresholdFileField; VInteger ExpThreshold;
 
 VBoolean UpdateSellPrice; VBoolean SellPriceByFile; VInteger SellPriceFileField; VDouble SellPrice;
 VBoolean UpdateSellComment; VBoolean SellCommentByFile; VInteger SellCommentFileField; VString SellComment;
 VBoolean UpdateSellUpdate; VBoolean SellUpdateByFile; VInteger SellUpdateFileField; VDate SellUpdate;
 VBoolean UpdateBuyPriceEst; VBoolean BuyPriceEstByFile; VInteger BuyPriceEstFileField; VDouble BuyPriceEst;
 VBoolean UpdateBuyComment; VBoolean BuyCommentByFile; VInteger BuyCommentFileField; VString BuyComment;
 VBoolean UpdateBuyUpdate; VBoolean BuyUpdateByFile; VInteger BuyUpdateFileField; VDate BuyUpdate;
 
 VBoolean UpdateOpStock; VBoolean OpStockByFile; VInteger OpStockFileField; VDouble OpStock;
 VBoolean UpdateOpExp; VBoolean OpExpByFile; VInteger OpExpFileField; VDate OpExp;
 VBoolean UpdateOrderQty; VBoolean OrderQtyByFile; VInteger OrderQtyFileField; VDouble OrderQty;
 
 public F_ItemImportUpdate(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  TableMdlFilePreview=new OCustomTableModel();
  Tbl_FilePreview.setModel(TableMdlFilePreview);
  PreviewMaxRows=10;
  
  BasedFileField=new VInteger();
  
  UpdateId=new VBoolean(); IdFileField=new VInteger();
  UpdateName=new VBoolean(); NameFileField=new VInteger();
  UpdateIsActive=new VBoolean(); IsActiveByFile=new VBoolean(); IsActiveFileField=new VInteger(); IsActive=new VBoolean();
  UpdateComment=new VBoolean(); CommentByFile=new VBoolean(); CommentFileField=new VInteger(); Comment=new VString();
  
  UpdateStockUnit=new VBoolean(); StockUnitByFile=new VBoolean(); StockUnitFileField=new VInteger(); StockUnitId=new VInteger();
  UpdateStock=new VBoolean(); StockByFile=new VBoolean(); StockFileField=new VInteger(); Stock=new VDouble();
  UpdateUpStock=new VBoolean(); UpStockByFile=new VBoolean(); UpStockFileField=new VInteger(); UpStock=new VBoolean();
  UpdateStockMin=new VBoolean(); StockMinByFile=new VBoolean(); StockMinFileField=new VInteger(); StockMin=new VDouble();
  UpdateStockMax=new VBoolean(); StockMaxByFile=new VBoolean(); StockMaxFileField=new VInteger(); StockMax=new VDouble();
  
  UpdateIsOpname=new VBoolean(); IsOpnameByFile=new VBoolean(); IsOpnameFileField=new VInteger(); IsOpname=new VBoolean();
  UpdateIsReorder=new VBoolean(); IsReorderByFile=new VBoolean(); IsReorderFileField=new VInteger(); IsReorder=new VBoolean();
  UpdateOrderMinPack=new VBoolean(); OrderMinPackByFile=new VBoolean(); OrderMinPackFileField=new VInteger(); OrderMinPack=new VDouble();
  UpdateOrderEachPackQty=new VBoolean(); OrderEachPackQtyByFile=new VBoolean(); OrderEachPackQtyFileField=new VInteger(); OrderEachPackQty=new VDouble();
  UpdateOrderEachPackThreshold=new VBoolean(); OrderEachPackThresholdByFile=new VBoolean(); OrderEachPackThresholdFileField=new VInteger(); OrderEachPackThreshold=new VDouble();
  
  UpdateHasExp=new VBoolean(); HasExpByFile=new VBoolean(); HasExpFileField=new VInteger(); HasExp=new VBoolean();
  UpdateExpCheckPeriod=new VBoolean(); ExpCheckPeriodByFile=new VBoolean(); ExpCheckPeriodFileField=new VInteger(); ExpCheckPeriod=new VInteger();
  UpdateExpThreshold=new VBoolean(); ExpThresholdByFile=new VBoolean(); ExpThresholdFileField=new VInteger(); ExpThreshold=new VInteger();
  
  UpdateSellPrice=new VBoolean(); SellPriceByFile=new VBoolean(); SellPriceFileField=new VInteger(); SellPrice=new VDouble();
  UpdateSellComment=new VBoolean(); SellCommentByFile=new VBoolean(); SellCommentFileField=new VInteger(); SellComment=new VString();
  UpdateSellUpdate=new VBoolean(); SellUpdateByFile=new VBoolean(); SellUpdateFileField=new VInteger(); SellUpdate=new VDate();
  UpdateBuyPriceEst=new VBoolean(); BuyPriceEstByFile=new VBoolean(); BuyPriceEstFileField=new VInteger(); BuyPriceEst=new VDouble();
  UpdateBuyComment=new VBoolean(); BuyCommentByFile=new VBoolean(); BuyCommentFileField=new VInteger(); BuyComment=new VString();
  UpdateBuyUpdate=new VBoolean(); BuyUpdateByFile=new VBoolean(); BuyUpdateFileField=new VInteger(); BuyUpdate=new VDate();
  
  UpdateOpStock=new VBoolean(); OpStockByFile=new VBoolean(); OpStockFileField=new VInteger(); OpStock=new VDouble();
  UpdateOpExp=new VBoolean(); OpExpByFile=new VBoolean(); OpExpFileField=new VInteger(); OpExp=new VDate();
  UpdateOrderQty=new VBoolean(); OrderQtyByFile=new VBoolean(); OrderQtyFileField=new VInteger(); OrderQty=new VDouble();
  
  Tbl_FilePreview.setToolTipText("preview isi file (maksimal "+PreviewMaxRows+" baris data)");
  
  clearComponents();
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_ChooseFile,
    Tbl_FilePreview,
    
    TF_BasedFileField,
    
    CB_Id, TF_IdFile,
    CB_Name, TF_NameFile,
    CB_IsActive, RB_IsActiveByFile, TF_IsActiveFile, RB_IsActiveByDef, CmB_IsActiveDef,
    CB_Comment, RB_CommentByFile, TF_CommentFile, RB_CommentByDef, TA_CommentDef,
    CB_StockUnit, RB_StockUnitByFile, TF_StockUnitFile, RB_StockUnitByDef, Btn_StockUnitDefChoose, Btn_StockUnitDefClear,
    CB_UpStock, RB_UpStockByFile, TF_UpStockFile, RB_UpStockByDef, CmB_UpStockDef,
    CB_Stock, RB_StockByFile, TF_StockFile, RB_StockByDef, TF_StockDef,
    CB_StockMin, RB_StockMinByFile, TF_StockMinFile, RB_StockMinByDef, TF_StockMinDef,
    CB_StockMax, RB_StockMaxByFile, TF_StockMaxFile, RB_StockMaxByDef, TF_StockMaxDef,
    CB_IsOpname, RB_IsOpnameByFile, TF_IsOpnameFile, RB_IsOpnameByDef, CmB_IsOpnameDef,
    CB_IsReorder, RB_IsReorderByFile, TF_IsReorderFile, RB_IsReorderByDef, CmB_IsReorderDef,
    CB_OrderEachPackQty, RB_OrderEachPackQtyByFile, TF_OrderEachPackQtyFile, RB_OrderEachPackQtyByDef, TF_OrderEachPackQtyDef,
    CB_OrderEachPackThreshold, RB_OrderEachPackThresholdByFile, TF_OrderEachPackThresholdFile, RB_OrderEachPackThresholdByDef, TF_OrderEachPackThresholdDef,
    CB_OrderMinPack, RB_OrderMinPackByFile, TF_OrderMinPackFile, RB_OrderMinPackByDef, TF_OrderMinPackDef,
    CB_HasExp, RB_HasExpByFile, TF_HasExpFile, RB_HasExpByDef, CmB_HasExpDef,
    CB_ExpCheckPeriod, RB_ExpCheckPeriodByFile, TF_ExpCheckPeriodFile, RB_ExpCheckPeriodByDef, TF_ExpCheckPeriodDef,
    CB_ExpThreshold, RB_ExpThresholdByFile, TF_ExpThresholdFile, RB_ExpThresholdByDef, TF_ExpThresholdDef,
    CB_SellPrice, RB_SellPriceByFile, TF_SellPriceFile, RB_SellPriceByDef, TF_SellPriceDef,
    CB_SellUpdate, RB_SellUpdateByFile, TF_SellUpdateFile, RB_SellUpdateByDef, CB_SellUpdateDefIsSet, TF_SellUpdateDefY, CmB_SellUpdateDefM, CmB_SellUpdateDefD,
    CB_SellComment, RB_SellCommentByFile, TF_SellCommentFile, RB_SellCommentByDef, TA_SellCommentDef,
    CB_BuyPriceEst, RB_BuyPriceEstByFile, TF_BuyPriceEstFile, RB_BuyPriceEstByDef, TF_BuyPriceEstDef,
    CB_BuyUpdate, RB_BuyUpdateByFile, TF_BuyUpdateFile, RB_BuyUpdateByDef, CB_BuyUpdateDefIsSet, TF_BuyUpdateDefY, CmB_BuyUpdateDefM, CmB_BuyUpdateDefD,
    CB_BuyComment, RB_BuyCommentByFile, TF_BuyCommentFile, RB_BuyCommentByDef, TA_BuyCommentDef,
    CB_OpStock, RB_OpStockByFile, TF_OpStockFile, RB_OpStockByDef, TF_OpStockDef,
    CB_OpExp, RB_OpExpByFile, TF_OpExpFile, RB_OpExpByDef, CB_OpExpDefIsSet, TF_OpExpDefY, CmB_OpExpDefM, CmB_OpExpDefD,
    CB_OrderQty, RB_OrderQtyByFile, TF_OrderQtyFile, RB_OrderQtyByDef, TF_OrderQtyDef,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  setFileCsv(null, CCore.CsvDefaultFieldDelimiter, CCore.CsvFieldsSeparators, CCore.CsvRecordsSeparators, true);
  
  Lbl_BasedFileField.setForeground(CGUI.Color_Label_InputRight); TF_BasedFileField.setText("");
  
  clearAttribute(CB_Id, TF_IdFile, null, null, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_Name, TF_NameFile, null, null, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_IsActive, TF_IsActiveFile, RB_IsActiveByFile, RB_IsActiveByDef, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_Comment, TF_CommentFile, RB_CommentByFile, RB_CommentByDef, CGUI.Color_Label_InputSecondary); setText(TA_CommentDef, "");
  
  clearAttribute(CB_StockUnit, TF_StockUnitFile, RB_StockUnitByFile, RB_StockUnitByDef, CGUI.Color_Label_InputPrimary); setStockUnit(-1, null);
  clearAttribute(CB_Stock, TF_StockFile, RB_StockByFile, RB_StockByDef, CGUI.Color_Label_InputPrimary); setText(TF_StockDef, "");
  clearAttribute(CB_UpStock, TF_UpStockFile, RB_UpStockByFile, RB_UpStockByDef, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_StockMin, TF_StockMinFile, RB_StockMinByFile, RB_StockMinByDef, CGUI.Color_Label_InputPrimary); setText(TF_StockMinDef, "");
  clearAttribute(CB_StockMax, TF_StockMaxFile, RB_StockMaxByFile, RB_StockMaxByDef, CGUI.Color_Label_InputPrimary); setText(TF_StockMaxDef, "");
  
  clearAttribute(CB_IsOpname, TF_IsOpnameFile, RB_IsOpnameByFile, RB_IsOpnameByDef, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_IsReorder, TF_IsReorderFile, RB_IsReorderByFile, RB_IsReorderByDef, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_OrderMinPack, TF_OrderMinPackFile, RB_OrderMinPackByFile, RB_OrderMinPackByDef, CGUI.Color_Label_InputSecondary); setText(TF_OrderMinPackDef, "");
  clearAttribute(CB_OrderEachPackQty, TF_OrderEachPackQtyFile, RB_OrderEachPackQtyByFile, RB_OrderEachPackQtyByDef, CGUI.Color_Label_InputPrimary); setText(TF_OrderEachPackQtyDef, "");
  clearAttribute(CB_OrderEachPackThreshold, TF_OrderEachPackThresholdFile, RB_OrderEachPackThresholdByFile, RB_OrderEachPackThresholdByDef, CGUI.Color_Label_InputSecondary); setText(TF_OrderEachPackThresholdDef, "");
  
  clearAttribute(CB_HasExp, TF_HasExpFile, RB_HasExpByFile, RB_HasExpByDef, CGUI.Color_Label_InputPrimary);
  clearAttribute(CB_ExpCheckPeriod, TF_ExpCheckPeriodFile, RB_ExpCheckPeriodByFile, RB_ExpCheckPeriodByDef, CGUI.Color_Label_InputPrimary); setText(TF_ExpCheckPeriodDef, "");
  clearAttribute(CB_ExpThreshold, TF_ExpThresholdFile, RB_ExpThresholdByFile, RB_ExpThresholdByDef, CGUI.Color_Label_InputPrimary); setText(TF_ExpThresholdDef, "");
  
  clearAttribute(CB_SellPrice, TF_SellPriceFile, RB_SellPriceByFile, RB_SellPriceByDef, CGUI.Color_Label_InputPrimary); setText(TF_SellPriceDef, "");
  clearAttribute(CB_SellComment, TF_SellCommentFile, RB_SellCommentByFile, RB_SellCommentByDef, CGUI.Color_Label_InputSecondary); setText(TA_SellCommentDef, "");
  clearAttribute(CB_SellUpdate, TF_SellUpdateFile, RB_SellUpdateByFile, RB_SellUpdateByDef, CGUI.Color_Label_InputSecondary); CB_SellUpdateDefIsSet.setSelected(false); CB_SellUpdateDefIsSetActionPerformed(null);
  clearAttribute(CB_BuyPriceEst, TF_BuyPriceEstFile, RB_BuyPriceEstByFile, RB_BuyPriceEstByDef, CGUI.Color_Label_InputPrimary); setText(TF_BuyPriceEstDef, "");
  clearAttribute(CB_BuyComment, TF_BuyCommentFile, RB_BuyCommentByFile, RB_BuyCommentByDef, CGUI.Color_Label_InputSecondary); setText(TA_BuyCommentDef, "");
  clearAttribute(CB_BuyUpdate, TF_BuyUpdateFile, RB_BuyUpdateByFile, RB_BuyUpdateByDef, CGUI.Color_Label_InputSecondary); CB_BuyUpdateDefIsSet.setSelected(false); CB_BuyUpdateDefIsSetActionPerformed(null);
  
  clearAttribute(CB_OpStock, TF_OpStockFile, RB_OpStockByFile, RB_OpStockByDef, CGUI.Color_Label_InputSecondary); setText(TF_OpStockDef, "");
  clearAttribute(CB_OpExp, TF_OpExpFile, RB_OpExpByFile, RB_OpExpByDef, CGUI.Color_Label_InputSecondary); CB_OpExpDefIsSet.setSelected(false); CB_OpExpDefIsSetActionPerformed(null);
  clearAttribute(CB_OrderQty, TF_OrderQtyFile, RB_OrderQtyByFile, RB_OrderQtyByDef, CGUI.Color_Label_InputSecondary); setText(TF_OrderQtyDef, "");
 }
 
 boolean setFileCsv(File f, char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators, boolean ShowMessage){
  OFileCsv f_csv;
  
  if(f==null){
   ChoosedFile=null; clearFileCsv();
   return true;
  }
  
  IFV.FSplashScreen.appear(this, "Membaca File CSV");
  f_csv=new OFileCsv(f, FieldDelimiter, FieldsSeparators, RecordsSeparators, false, PreviewMaxRows, IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  
  if(f_csv.IsValid.IsValid){ChoosedFile=f_csv; fillFileCsv();}
  
  if(!f_csv.IsValid.IsValid && ShowMessage){
   IFV.FMessage.showMessage("Terjadi kegagalan dalam membaca file ("+PMyShop.getCSVErrorMessage()+") :\n"+f_csv.IsValid.getError());
  }
  
  return f_csv.IsValid.IsValid;
 }
 void fillFileCsv(){
  TF_File.setText(ChoosedFile.FileName);
  fillFileInfo();
 }
 void clearFileCsv(){
  TF_File.setText("");
  clearFileInfo();
 }
 void fillFileInfo(){
  int temp, length;
  String[] ColsName;
  String ColName;
  Vector<String> Record;
  
  // clear
  clearFileInfo();
  
  // fill File Info
  TF_FileInfo.setText(PText.intToString(ChoosedFile.RecordsCount)+" record ( "+PText.intToString(ChoosedFile.FieldsCount)+" field )");
  
  // fill File Preview
  if(ChoosedFile.FieldsCount==0){return;}
  
  ColsName=new String[ChoosedFile.FieldsCount];
  temp=0;
  do{
   ColName=ChoosedFile.Header.elementAt(temp);
   ColsName[temp]="("+(temp+1)+")"+PText.getString(ColName, "", " "+ColName, true);
   temp=temp+1;
  }while(temp!=ChoosedFile.FieldsCount);
  
  TableMdlFilePreview.updateColumnsInfo(
   ColsName, PCore.newIntegerArray(ChoosedFile.FieldsCount, CCore.TypeString),
   PCore.newIntegerArrayInOrderedSequence(ChoosedFile.FieldsCount, 0, 1), true);
  
  PGUI.resizeTableColumn(Tbl_FilePreview, PCore.newIntegerArray(ChoosedFile.FieldsCount, CGUI.ColTextSml));
  
  length=ChoosedFile.SampleRecords.size();
  if(length==0){return;}
  temp=0;
  do{
   Record=ChoosedFile.SampleRecords.elementAt(temp);
   TableMdlFilePreview.append(PCore.objArr_Vect(Record));
   temp=temp+1;
  }while(temp!=length);
 }
 void clearFileInfo(){
  TF_FileInfo.setText("");
  TableMdlFilePreview.emptyColumnsInfo();
 }
 
 void clearAttribute(JCheckBox CB_Attr, JTextField TF_File, JRadioButton RB_ByFile, JRadioButton RB_ByDef, Color CBColorValid){
  CB_Attr.setSelected(false); CB_Attr.setForeground(CBColorValid);
  TF_File.setText("");
  if(RB_ByFile!=null && RB_ByDef!=null){PGUI.selectRadioButton(true, RB_ByFile, RB_ByDef);}
 }
 void setStockUnit(int Id, String Name){
  ChoosedStockUnitId=Id;
  ChoosedStockUnitName=Name;
  TF_StockUnitDef.setText(PText.getString(ChoosedStockUnitId, -1, ChoosedStockUnitName, ""));
 }
 void setText(JTextComponent TextComponent, String str){
  TextComponent.setText(str);
 }
 int fileFieldIsValid(JTextField TF_File){
  int ret=-1;
  int temp;
  String str;
  do{
   str=TF_File.getText();
   if(!PText.checkInput(str, false, CCore.CharsCount_Int(), 2, 7, 0, 0)){break;}
   temp=Integer.parseInt(str)-1;
   if(temp<0 || temp>ChoosedFile.FieldsCount-1){break;}
   ret=temp;
  }while(false);
  return ret;
 }
 void checkInteger(
  VBoolean UpdateAttr, VBoolean AttrByFile, VInteger AttrByFileField, VInteger AttrByDef,
  JRadioButton RB_ByFile, JTextField TF_ByFileField, JTextField TF_ByDef,
  JCheckBox CB_Attr, OValidation IsValid, VBoolean First, Color CBColorValid,
  boolean AcceptEmpty, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, int Range1, int Range2){
  boolean CurrValid;
  
  UpdateAttr.Value=CB_Attr.isSelected();
  if(!UpdateAttr.Value){return;}
  
  CurrValid=false;
  do{
   AttrByFile.Value=RB_ByFile.isSelected();
   if(AttrByFile.Value){
    AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){break;}
   }
   else{
    if(!PGUI.checkInputInteger(TF_ByDef, AttrByDef, AcceptEmpty, AcceptZero, PositiveOnly, WithinRange, Range1, Range2)){break;}
   }
   CurrValid=true;
  }while(false);
  setValid(CurrValid, CB_Attr, IsValid, CBColorValid); First.Value=true;
 }
 void checkDouble(
  VBoolean UpdateAttr, VBoolean AttrByFile, VInteger AttrByFileField, VDouble AttrByDef,
  JRadioButton RB_ByFile, JTextField TF_ByFileField, JTextField TF_ByDef,
  JCheckBox CB_Attr, OValidation IsValid, VBoolean First, Color CBColorValid,
  boolean AcceptEmpty, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, double Range1, double Range2){
  boolean CurrValid;
  
  UpdateAttr.Value=CB_Attr.isSelected();
  if(!UpdateAttr.Value){return;}
  
  CurrValid=false;
  do{
   AttrByFile.Value=RB_ByFile.isSelected();
   if(AttrByFile.Value){
    AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){break;}
   }
   else{
    if(!PGUI.checkInputDouble(TF_ByDef, AttrByDef, AcceptEmpty, AcceptZero, PositiveOnly, WithinRange, Range1, Range2)){break;}
   }
   CurrValid=true;
  }while(false);
  setValid(CurrValid, CB_Attr, IsValid, CBColorValid); First.Value=true;
 }
 void checkBoolean(
  VBoolean UpdateAttr, VBoolean AttrByFile, VInteger AttrByFileField, VBoolean AttrByDef,
  JRadioButton RB_ByFile, JTextField TF_ByFileField, JComboBox CmB_ByDef,
  JCheckBox CB_Attr, OValidation IsValid, VBoolean First, Color CBColorValid){
  boolean CurrValid;
  
  UpdateAttr.Value=CB_Attr.isSelected();
  if(!UpdateAttr.Value){return;}
  
  CurrValid=false;
  do{
   AttrByFile.Value=RB_ByFile.isSelected();
   if(AttrByFile.Value){
    AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){break;}
   }
   else{
    AttrByDef.Value=CmB_ByDef.getSelectedIndex()==0;
   }
   CurrValid=true;
  }while(false);
  setValid(CurrValid, CB_Attr, IsValid, CBColorValid); First.Value=true;
 }
 void checkString(
  VBoolean UpdateAttr, VBoolean AttrByFile, VInteger AttrByFileField, VString AttrByDef,
  JRadioButton RB_ByFile, JTextField TF_ByFileField, JTextComponent TF_ByDef,
  JCheckBox CB_Attr, OValidation IsValid, VBoolean First, Color CBColorValid,
  boolean AcceptEmpty, int MaxInputLength){
  boolean CurrValid;
  
  UpdateAttr.Value=CB_Attr.isSelected();
  if(!UpdateAttr.Value){return;}
  
  CurrValid=false;
  do{
   AttrByFile.Value=RB_ByFile.isSelected();
   if(AttrByFile.Value){
    AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){break;}
   }
   else{
    if(!PGUI.checkInputString(TF_ByDef, AttrByDef, AcceptEmpty, MaxInputLength, false, true)){break;}
   }
   CurrValid=true;
  }while(false);
  setValid(CurrValid, CB_Attr, IsValid, CBColorValid); First.Value=true;
 }
 void checkDate(
  VBoolean UpdateAttr, VBoolean AttrByFile, VInteger AttrByFileField, VDate AttrByDef,
  JRadioButton RB_ByFile, JTextField TF_ByFileField, JCheckBox CB_ByDefEnable, JTextField TF_ByDefYear, JComboBox CmB_ByDefMonth, JComboBox CmB_ByDefDay,
  JCheckBox CB_Attr, OValidation IsValid, VBoolean First, Color CBColorValid){
  boolean CurrValid;
  
  UpdateAttr.Value=CB_Attr.isSelected();
  if(!UpdateAttr.Value){return;}
  
  CurrValid=false;
  do{
   AttrByFile.Value=RB_ByFile.isSelected();
   if(AttrByFile.Value){
    AttrByFileField.Value=fileFieldIsValid(TF_ByFileField); if(AttrByFileField.Value==-1){break;}
   }
   else{
    if(!PGUI.checkInputDate(CB_ByDefEnable, TF_ByDefYear, CmB_ByDefMonth, CmB_ByDefDay, AttrByDef)){break;}
   }
   CurrValid=true;
  }while(false);
  setValid(CurrValid, CB_Attr, IsValid, CBColorValid); First.Value=true;
 }
 void setValid(boolean Valid, JComponent CB_Attr, OValidation IsValid, Color CBColorValid){
  if(Valid){CB_Attr.setForeground(CBColorValid);}else{CB_Attr.setForeground(CGUI.Color_Label_InputWrong); IsValid.setValid(false);}
 }
 
 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_StockUnit = new javax.swing.ButtonGroup();
  RG_Stock = new javax.swing.ButtonGroup();
  RG_UpStock = new javax.swing.ButtonGroup();
  RG_MisStock = new javax.swing.ButtonGroup();
  RG_StockMin = new javax.swing.ButtonGroup();
  RG_StockMax = new javax.swing.ButtonGroup();
  RG_OpStock = new javax.swing.ButtonGroup();
  RG_OpExp = new javax.swing.ButtonGroup();
  RG_Comment = new javax.swing.ButtonGroup();
  RG_IsActive = new javax.swing.ButtonGroup();
  RG_HasExp = new javax.swing.ButtonGroup();
  RG_ExpCheckPeriod = new javax.swing.ButtonGroup();
  RG_ExpThreshold = new javax.swing.ButtonGroup();
  RG_SellPrice = new javax.swing.ButtonGroup();
  RG_SellComment = new javax.swing.ButtonGroup();
  RG_BuyComment = new javax.swing.ButtonGroup();
  RG_BuyPriceEst = new javax.swing.ButtonGroup();
  RG_OrderQty = new javax.swing.ButtonGroup();
  RG_SellUpdate = new javax.swing.ButtonGroup();
  RG_BuyUpdate = new javax.swing.ButtonGroup();
  RG_OrderMinPack = new javax.swing.ButtonGroup();
  RG_OrderEachPackQty = new javax.swing.ButtonGroup();
  RG_OrderEachPackThreshold = new javax.swing.ButtonGroup();
  RG_IsReorder = new javax.swing.ButtonGroup();
  RG_IsOpname = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  TF_File = new javax.swing.JTextField();
  Btn_ChooseFile = new javax.swing.JButton();
  Lbl_File = new javax.swing.JLabel();
  TF_FileInfo = new javax.swing.JTextField();
  Lbl_FileHelp = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_FilePreview = new XTable();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  jLabel21 = new javax.swing.JLabel();
  Lbl_FileField2 = new javax.swing.JLabel();
  jLabel23 = new javax.swing.JLabel();
  TF_SellPriceFile = new javax.swing.JTextField();
  TF_SellPriceDef = new javax.swing.JTextField();
  Lbl_SellPriceDefHelp = new javax.swing.JLabel();
  TF_SellCommentFile = new javax.swing.JTextField();
  Lbl_SellCommentDefHelp = new javax.swing.JLabel();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_SellCommentDef = new javax.swing.JTextArea();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_BuyCommentDef = new javax.swing.JTextArea();
  Lbl_BuyCommentDefHelp = new javax.swing.JLabel();
  TF_BuyCommentFile = new javax.swing.JTextField();
  CB_SellPrice = new javax.swing.JCheckBox();
  CB_SellComment = new javax.swing.JCheckBox();
  CB_BuyComment = new javax.swing.JCheckBox();
  RB_SellPriceByFile = new javax.swing.JRadioButton();
  RB_SellCommentByFile = new javax.swing.JRadioButton();
  RB_BuyCommentByFile = new javax.swing.JRadioButton();
  RB_SellPriceByDef = new javax.swing.JRadioButton();
  RB_SellCommentByDef = new javax.swing.JRadioButton();
  RB_BuyCommentByDef = new javax.swing.JRadioButton();
  TF_OpStockDef = new javax.swing.JTextField();
  Lbl_OpStockDefHelp = new javax.swing.JLabel();
  RB_OpStockByDef = new javax.swing.JRadioButton();
  TF_OpStockFile = new javax.swing.JTextField();
  RB_OpStockByFile = new javax.swing.JRadioButton();
  CB_OpStock = new javax.swing.JCheckBox();
  CmB_OpExpDefD = new javax.swing.JComboBox<>();
  CmB_OpExpDefM = new javax.swing.JComboBox<>();
  TF_OpExpDefY = new javax.swing.JTextField();
  CB_OpExpDefIsSet = new javax.swing.JCheckBox();
  RB_OpExpByDef = new javax.swing.JRadioButton();
  RB_OpExpByFile = new javax.swing.JRadioButton();
  TF_OpExpFile = new javax.swing.JTextField();
  CB_OpExp = new javax.swing.JCheckBox();
  TF_BuyPriceEstDef = new javax.swing.JTextField();
  Lbl_BuyPriceEstDefHelp = new javax.swing.JLabel();
  RB_BuyPriceEstByDef = new javax.swing.JRadioButton();
  TF_BuyPriceEstFile = new javax.swing.JTextField();
  RB_BuyPriceEstByFile = new javax.swing.JRadioButton();
  CB_BuyPriceEst = new javax.swing.JCheckBox();
  CB_OrderQty = new javax.swing.JCheckBox();
  RB_OrderQtyByFile = new javax.swing.JRadioButton();
  TF_OrderQtyFile = new javax.swing.JTextField();
  RB_OrderQtyByDef = new javax.swing.JRadioButton();
  TF_OrderQtyDef = new javax.swing.JTextField();
  Lbl_OrderQtyDefHelp = new javax.swing.JLabel();
  CB_SellUpdate = new javax.swing.JCheckBox();
  RB_SellUpdateByFile = new javax.swing.JRadioButton();
  TF_SellUpdateFile = new javax.swing.JTextField();
  RB_SellUpdateByDef = new javax.swing.JRadioButton();
  CB_SellUpdateDefIsSet = new javax.swing.JCheckBox();
  TF_SellUpdateDefY = new javax.swing.JTextField();
  CmB_SellUpdateDefM = new javax.swing.JComboBox<>();
  CmB_SellUpdateDefD = new javax.swing.JComboBox<>();
  RB_BuyUpdateByDef = new javax.swing.JRadioButton();
  CB_BuyUpdateDefIsSet = new javax.swing.JCheckBox();
  TF_BuyUpdateDefY = new javax.swing.JTextField();
  CmB_BuyUpdateDefM = new javax.swing.JComboBox<>();
  CmB_BuyUpdateDefD = new javax.swing.JComboBox<>();
  RB_BuyUpdateByFile = new javax.swing.JRadioButton();
  TF_BuyUpdateFile = new javax.swing.JTextField();
  CB_BuyUpdate = new javax.swing.JCheckBox();
  CB_HasExp = new javax.swing.JCheckBox();
  RB_HasExpByFile = new javax.swing.JRadioButton();
  TF_HasExpFile = new javax.swing.JTextField();
  RB_HasExpByDef = new javax.swing.JRadioButton();
  CmB_HasExpDef = new javax.swing.JComboBox<>();
  CB_ExpCheckPeriod = new javax.swing.JCheckBox();
  RB_ExpCheckPeriodByFile = new javax.swing.JRadioButton();
  TF_ExpCheckPeriodFile = new javax.swing.JTextField();
  RB_ExpCheckPeriodByDef = new javax.swing.JRadioButton();
  TF_ExpCheckPeriodDef = new javax.swing.JTextField();
  Lbl_ExpCheckPeriodDef = new javax.swing.JLabel();
  CB_ExpThreshold = new javax.swing.JCheckBox();
  RB_ExpThresholdByFile = new javax.swing.JRadioButton();
  TF_ExpThresholdFile = new javax.swing.JTextField();
  RB_ExpThresholdByDef = new javax.swing.JRadioButton();
  Lbl_ExpThresholdDefHelp = new javax.swing.JLabel();
  TF_ExpThresholdDef = new javax.swing.JTextField();
  jPanel5 = new javax.swing.JPanel();
  jLabel1 = new javax.swing.JLabel();
  Lbl_FileField1 = new javax.swing.JLabel();
  jLabel6 = new javax.swing.JLabel();
  TF_NameFile = new javax.swing.JTextField();
  TF_StockUnitFile = new javax.swing.JTextField();
  TF_StockUnitDef = new javax.swing.JTextField();
  Btn_StockUnitDefChoose = new javax.swing.JButton();
  Btn_StockUnitDefClear = new javax.swing.JButton();
  TF_StockFile = new javax.swing.JTextField();
  TF_StockDef = new javax.swing.JTextField();
  Lbl_StockDefHelp = new javax.swing.JLabel();
  TF_UpStockFile = new javax.swing.JTextField();
  CmB_UpStockDef = new javax.swing.JComboBox<>();
  TF_StockMinFile = new javax.swing.JTextField();
  TF_StockMinDef = new javax.swing.JTextField();
  Lbl_StockMinDefHelp = new javax.swing.JLabel();
  TF_StockMaxFile = new javax.swing.JTextField();
  TF_StockMaxDef = new javax.swing.JTextField();
  Lbl_StockMaxHelp = new javax.swing.JLabel();
  TF_CommentFile = new javax.swing.JTextField();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_CommentDef = new javax.swing.JTextArea();
  Lbl_CommentDefHelp = new javax.swing.JLabel();
  TF_IdFile = new javax.swing.JTextField();
  RB_UpStockByFile = new javax.swing.JRadioButton();
  RB_StockUnitByFile = new javax.swing.JRadioButton();
  RB_StockByFile = new javax.swing.JRadioButton();
  RB_StockMinByFile = new javax.swing.JRadioButton();
  RB_StockMaxByFile = new javax.swing.JRadioButton();
  RB_CommentByFile = new javax.swing.JRadioButton();
  RB_StockUnitByDef = new javax.swing.JRadioButton();
  RB_StockByDef = new javax.swing.JRadioButton();
  RB_UpStockByDef = new javax.swing.JRadioButton();
  RB_StockMinByDef = new javax.swing.JRadioButton();
  RB_StockMaxByDef = new javax.swing.JRadioButton();
  RB_CommentByDef = new javax.swing.JRadioButton();
  CB_Id = new javax.swing.JCheckBox();
  CB_Name = new javax.swing.JCheckBox();
  CB_StockUnit = new javax.swing.JCheckBox();
  CB_Stock = new javax.swing.JCheckBox();
  CB_UpStock = new javax.swing.JCheckBox();
  CB_StockMin = new javax.swing.JCheckBox();
  CB_StockMax = new javax.swing.JCheckBox();
  CB_Comment = new javax.swing.JCheckBox();
  CmB_IsActiveDef = new javax.swing.JComboBox<>();
  TF_IsActiveFile = new javax.swing.JTextField();
  RB_IsActiveByFile = new javax.swing.JRadioButton();
  RB_IsActiveByDef = new javax.swing.JRadioButton();
  CB_IsActive = new javax.swing.JCheckBox();
  CB_OrderMinPack = new javax.swing.JCheckBox();
  RB_OrderMinPackByFile = new javax.swing.JRadioButton();
  TF_OrderMinPackFile = new javax.swing.JTextField();
  RB_OrderMinPackByDef = new javax.swing.JRadioButton();
  TF_OrderMinPackDef = new javax.swing.JTextField();
  Lbl_OrderMinPackHelp = new javax.swing.JLabel();
  CB_OrderEachPackThreshold = new javax.swing.JCheckBox();
  RB_OrderEachPackThresholdByFile = new javax.swing.JRadioButton();
  TF_OrderEachPackThresholdFile = new javax.swing.JTextField();
  RB_OrderEachPackThresholdByDef = new javax.swing.JRadioButton();
  TF_OrderEachPackThresholdDef = new javax.swing.JTextField();
  Lbl_OrderEachPackThresholdHelp = new javax.swing.JLabel();
  CB_OrderEachPackQty = new javax.swing.JCheckBox();
  RB_OrderEachPackQtyByFile = new javax.swing.JRadioButton();
  TF_OrderEachPackQtyFile = new javax.swing.JTextField();
  RB_OrderEachPackQtyByDef = new javax.swing.JRadioButton();
  TF_OrderEachPackQtyDef = new javax.swing.JTextField();
  Lbl_OrderEachPackQtyDef = new javax.swing.JLabel();
  CB_IsReorder = new javax.swing.JCheckBox();
  RB_IsReorderByFile = new javax.swing.JRadioButton();
  TF_IsReorderFile = new javax.swing.JTextField();
  RB_IsReorderByDef = new javax.swing.JRadioButton();
  CmB_IsReorderDef = new javax.swing.JComboBox<>();
  RB_IsOpnameByDef = new javax.swing.JRadioButton();
  CmB_IsOpnameDef = new javax.swing.JComboBox<>();
  RB_IsOpnameByFile = new javax.swing.JRadioButton();
  TF_IsOpnameFile = new javax.swing.JTextField();
  CB_IsOpname = new javax.swing.JCheckBox();
  jSeparator1 = new javax.swing.JSeparator();
  jPanel4 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_ImportInfo = new javax.swing.JLabel();
  jLabel3 = new javax.swing.JLabel();
  jLabel2 = new javax.swing.JLabel();
  jPanel7 = new javax.swing.JPanel();
  Lbl_BasedFileField = new javax.swing.JLabel();
  TF_BasedFileField = new javax.swing.JTextField();
  Lbl_BasedAttributeFileFieldHelp = new javax.swing.JLabel();

  setTitle("Impor-Perbaharui Data Barang");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_File.setEditable(false);
  TF_File.setBackground(new java.awt.Color(204, 255, 204));

  Btn_ChooseFile.setText("...");
  Btn_ChooseFile.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseFile.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseFileActionPerformed(evt);
   }
  });
  Btn_ChooseFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseFileKeyPressed(evt);
   }
  });

  Lbl_File.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_File.setText("File CSV");

  TF_FileInfo.setEditable(false);
  TF_FileInfo.setBackground(new java.awt.Color(204, 255, 204));
  TF_FileInfo.setToolTipText("jumlah record & jumlah field pada file");

  Lbl_FileHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileHelp.setText("(?)");
  Lbl_FileHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileHelpMouseClicked(evt);
   }
  });

  Tbl_FilePreview.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_FilePreview.setToolTipText("preview isi file (maksimal n baris data)");
  Tbl_FilePreview.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
  Tbl_FilePreview.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_FilePreview.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_FilePreviewKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_FilePreview);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(Lbl_File)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_File, javax.swing.GroupLayout.DEFAULT_SIZE, 872, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FileInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ChooseFile)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_FileHelp))
   .addComponent(jScrollPane1)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_File, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ChooseFile)
     .addComponent(Lbl_File)
     .addComponent(Lbl_FileHelp)
     .addComponent(TF_FileInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE))
  );

  jLabel21.setBackground(new java.awt.Color(204, 204, 255));
  jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel21.setText("Atribut");
  jLabel21.setOpaque(true);

  Lbl_FileField2.setBackground(new java.awt.Color(204, 204, 255));
  Lbl_FileField2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileField2.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileField2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_FileField2.setText("Field Pd File");
  Lbl_FileField2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileField2.setOpaque(true);
  Lbl_FileField2.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileField2MouseClicked(evt);
   }
  });

  jLabel23.setBackground(new java.awt.Color(204, 204, 255));
  jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel23.setText("Defenisi Sendiri");
  jLabel23.setOpaque(true);

  TF_SellPriceFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellPriceFileFocusGained(evt);
   }
  });
  TF_SellPriceFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellPriceFileKeyPressed(evt);
   }
  });

  TF_SellPriceDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellPriceDefFocusGained(evt);
   }
  });
  TF_SellPriceDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellPriceDefKeyPressed(evt);
   }
  });

  Lbl_SellPriceDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellPriceDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellPriceDefHelp.setText("(?)");
  Lbl_SellPriceDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellPriceDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellPriceDefHelpMouseClicked(evt);
   }
  });

  TF_SellCommentFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellCommentFileFocusGained(evt);
   }
  });
  TF_SellCommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellCommentFileKeyPressed(evt);
   }
  });

  Lbl_SellCommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellCommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellCommentDefHelp.setText("(?)");
  Lbl_SellCommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellCommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellCommentDefHelpMouseClicked(evt);
   }
  });

  TA_SellCommentDef.setColumns(5);
  TA_SellCommentDef.setLineWrap(true);
  TA_SellCommentDef.setWrapStyleWord(true);
  TA_SellCommentDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TA_SellCommentDefFocusGained(evt);
   }
  });
  TA_SellCommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_SellCommentDefKeyPressed(evt);
   }
  });
  jScrollPane3.setViewportView(TA_SellCommentDef);

  TA_BuyCommentDef.setColumns(5);
  TA_BuyCommentDef.setLineWrap(true);
  TA_BuyCommentDef.setWrapStyleWord(true);
  TA_BuyCommentDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TA_BuyCommentDefFocusGained(evt);
   }
  });
  TA_BuyCommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyCommentDefKeyPressed(evt);
   }
  });
  jScrollPane4.setViewportView(TA_BuyCommentDef);

  Lbl_BuyCommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyCommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyCommentDefHelp.setText("(?)");
  Lbl_BuyCommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyCommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyCommentDefHelpMouseClicked(evt);
   }
  });

  TF_BuyCommentFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyCommentFileFocusGained(evt);
   }
  });
  TF_BuyCommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyCommentFileKeyPressed(evt);
   }
  });

  CB_SellPrice.setText("Harga Jual");
  CB_SellPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellPriceKeyPressed(evt);
   }
  });

  CB_SellComment.setText("~ Ket. Harga Jual");
  CB_SellComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellCommentKeyPressed(evt);
   }
  });

  CB_BuyComment.setText("~ Ket. Harga Beli");
  CB_BuyComment.setToolTipText("");
  CB_BuyComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyCommentKeyPressed(evt);
   }
  });

  RG_SellPrice.add(RB_SellPriceByFile);
  RB_SellPriceByFile.setText(" ");
  RB_SellPriceByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_SellPriceByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_SellPriceByFileKeyPressed(evt);
   }
  });

  RG_SellComment.add(RB_SellCommentByFile);
  RB_SellCommentByFile.setText(" ");
  RB_SellCommentByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_SellCommentByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_SellCommentByFileKeyPressed(evt);
   }
  });

  RG_BuyComment.add(RB_BuyCommentByFile);
  RB_BuyCommentByFile.setText(" ");
  RB_BuyCommentByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_BuyCommentByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_BuyCommentByFileKeyPressed(evt);
   }
  });

  RG_SellPrice.add(RB_SellPriceByDef);
  RB_SellPriceByDef.setText(" ");
  RB_SellPriceByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_SellPriceByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_SellPriceByDefKeyPressed(evt);
   }
  });

  RG_SellComment.add(RB_SellCommentByDef);
  RB_SellCommentByDef.setText(" ");
  RB_SellCommentByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_SellCommentByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_SellCommentByDefKeyPressed(evt);
   }
  });

  RG_BuyComment.add(RB_BuyCommentByDef);
  RB_BuyCommentByDef.setText(" ");
  RB_BuyCommentByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_BuyCommentByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_BuyCommentByDefKeyPressed(evt);
   }
  });

  TF_OpStockDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OpStockDefFocusGained(evt);
   }
  });
  TF_OpStockDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpStockDefKeyPressed(evt);
   }
  });

  Lbl_OpStockDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OpStockDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OpStockDefHelp.setText("(?)");
  Lbl_OpStockDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OpStockDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OpStockDefHelpMouseClicked(evt);
   }
  });

  RG_OpStock.add(RB_OpStockByDef);
  RB_OpStockByDef.setText(" ");
  RB_OpStockByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OpStockByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OpStockByDefKeyPressed(evt);
   }
  });

  TF_OpStockFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OpStockFileFocusGained(evt);
   }
  });
  TF_OpStockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpStockFileKeyPressed(evt);
   }
  });

  RG_OpStock.add(RB_OpStockByFile);
  RB_OpStockByFile.setText(" ");
  RB_OpStockByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OpStockByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OpStockByFileKeyPressed(evt);
   }
  });

  CB_OpStock.setText("Op. Stok (Selisih)");
  CB_OpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpStockKeyPressed(evt);
   }
  });

  CmB_OpExpDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_OpExpDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpDefDKeyPressed(evt);
   }
  });

  CmB_OpExpDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_OpExpDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpDefMKeyPressed(evt);
   }
  });

  TF_OpExpDefY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OpExpDefYFocusGained(evt);
   }
  });
  TF_OpExpDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpExpDefYKeyPressed(evt);
   }
  });

  CB_OpExpDefIsSet.setText(" ");
  CB_OpExpDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExpDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OpExpDefIsSetActionPerformed(evt);
   }
  });
  CB_OpExpDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpDefIsSetKeyPressed(evt);
   }
  });

  RG_OpExp.add(RB_OpExpByDef);
  RB_OpExpByDef.setText(" ");
  RB_OpExpByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OpExpByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OpExpByDefKeyPressed(evt);
   }
  });

  RG_OpExp.add(RB_OpExpByFile);
  RB_OpExpByFile.setText(" ");
  RB_OpExpByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OpExpByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OpExpByFileKeyPressed(evt);
   }
  });

  TF_OpExpFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OpExpFileFocusGained(evt);
   }
  });
  TF_OpExpFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpExpFileKeyPressed(evt);
   }
  });

  CB_OpExp.setText("Opname Expire");
  CB_OpExp.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExp.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpKeyPressed(evt);
   }
  });

  TF_BuyPriceEstDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyPriceEstDefFocusGained(evt);
   }
  });
  TF_BuyPriceEstDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceEstDefKeyPressed(evt);
   }
  });

  Lbl_BuyPriceEstDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceEstDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceEstDefHelp.setText("(?)");
  Lbl_BuyPriceEstDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceEstDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceEstDefHelpMouseClicked(evt);
   }
  });

  RG_BuyPriceEst.add(RB_BuyPriceEstByDef);
  RB_BuyPriceEstByDef.setText(" ");
  RB_BuyPriceEstByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_BuyPriceEstByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_BuyPriceEstByDefKeyPressed(evt);
   }
  });

  TF_BuyPriceEstFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyPriceEstFileFocusGained(evt);
   }
  });
  TF_BuyPriceEstFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceEstFileKeyPressed(evt);
   }
  });

  RG_BuyPriceEst.add(RB_BuyPriceEstByFile);
  RB_BuyPriceEstByFile.setText(" ");
  RB_BuyPriceEstByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_BuyPriceEstByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_BuyPriceEstByFileKeyPressed(evt);
   }
  });

  CB_BuyPriceEst.setText("Kis. Harga Beli");
  CB_BuyPriceEst.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyPriceEst.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyPriceEstKeyPressed(evt);
   }
  });

  CB_OrderQty.setText("Order Qty");
  CB_OrderQty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderQtyKeyPressed(evt);
   }
  });

  RG_OrderQty.add(RB_OrderQtyByFile);
  RB_OrderQtyByFile.setText(" ");
  RB_OrderQtyByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderQtyByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderQtyByFileKeyPressed(evt);
   }
  });

  TF_OrderQtyFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderQtyFileFocusGained(evt);
   }
  });
  TF_OrderQtyFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderQtyFileKeyPressed(evt);
   }
  });

  RG_OrderQty.add(RB_OrderQtyByDef);
  RB_OrderQtyByDef.setText(" ");
  RB_OrderQtyByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderQtyByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderQtyByDefKeyPressed(evt);
   }
  });

  TF_OrderQtyDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderQtyDefFocusGained(evt);
   }
  });
  TF_OrderQtyDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderQtyDefKeyPressed(evt);
   }
  });

  Lbl_OrderQtyDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderQtyDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderQtyDefHelp.setText("(?)");
  Lbl_OrderQtyDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderQtyDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderQtyDefHelpMouseClicked(evt);
   }
  });

  CB_SellUpdate.setText("~ Tgl Pbrn Jual");
  CB_SellUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateKeyPressed(evt);
   }
  });

  RG_SellUpdate.add(RB_SellUpdateByFile);
  RB_SellUpdateByFile.setText(" ");
  RB_SellUpdateByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_SellUpdateByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_SellUpdateByFileKeyPressed(evt);
   }
  });

  TF_SellUpdateFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellUpdateFileFocusGained(evt);
   }
  });
  TF_SellUpdateFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellUpdateFileKeyPressed(evt);
   }
  });

  RG_SellUpdate.add(RB_SellUpdateByDef);
  RB_SellUpdateByDef.setText(" ");
  RB_SellUpdateByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_SellUpdateByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_SellUpdateByDefKeyPressed(evt);
   }
  });

  CB_SellUpdateDefIsSet.setText(" ");
  CB_SellUpdateDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdateDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellUpdateDefIsSetActionPerformed(evt);
   }
  });
  CB_SellUpdateDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateDefIsSetKeyPressed(evt);
   }
  });

  TF_SellUpdateDefY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellUpdateDefYFocusGained(evt);
   }
  });
  TF_SellUpdateDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellUpdateDefYKeyPressed(evt);
   }
  });

  CmB_SellUpdateDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_SellUpdateDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateDefMKeyPressed(evt);
   }
  });

  CmB_SellUpdateDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_SellUpdateDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateDefDKeyPressed(evt);
   }
  });

  RG_BuyUpdate.add(RB_BuyUpdateByDef);
  RB_BuyUpdateByDef.setText(" ");
  RB_BuyUpdateByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_BuyUpdateByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_BuyUpdateByDefKeyPressed(evt);
   }
  });

  CB_BuyUpdateDefIsSet.setText(" ");
  CB_BuyUpdateDefIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdateDefIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyUpdateDefIsSetActionPerformed(evt);
   }
  });
  CB_BuyUpdateDefIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateDefIsSetKeyPressed(evt);
   }
  });

  TF_BuyUpdateDefY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyUpdateDefYFocusGained(evt);
   }
  });
  TF_BuyUpdateDefY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateDefYKeyPressed(evt);
   }
  });

  CmB_BuyUpdateDefM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_BuyUpdateDefM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDefMKeyPressed(evt);
   }
  });

  CmB_BuyUpdateDefD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_BuyUpdateDefD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDefDKeyPressed(evt);
   }
  });

  RG_BuyUpdate.add(RB_BuyUpdateByFile);
  RB_BuyUpdateByFile.setText(" ");
  RB_BuyUpdateByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_BuyUpdateByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_BuyUpdateByFileKeyPressed(evt);
   }
  });

  TF_BuyUpdateFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyUpdateFileFocusGained(evt);
   }
  });
  TF_BuyUpdateFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateFileKeyPressed(evt);
   }
  });

  CB_BuyUpdate.setText("~ Tgl Pbrn Beli");
  CB_BuyUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateKeyPressed(evt);
   }
  });

  CB_HasExp.setText("Berkadaluarsa");
  CB_HasExp.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_HasExp.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_HasExpKeyPressed(evt);
   }
  });

  RG_HasExp.add(RB_HasExpByFile);
  RB_HasExpByFile.setText(" ");
  RB_HasExpByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_HasExpByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_HasExpByFileKeyPressed(evt);
   }
  });

  TF_HasExpFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_HasExpFileFocusGained(evt);
   }
  });
  TF_HasExpFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_HasExpFileKeyPressed(evt);
   }
  });

  RG_HasExp.add(RB_HasExpByDef);
  RB_HasExpByDef.setText(" ");
  RB_HasExpByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_HasExpByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_HasExpByDefKeyPressed(evt);
   }
  });

  CmB_HasExpDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_HasExpDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_HasExpDefKeyPressed(evt);
   }
  });

  CB_ExpCheckPeriod.setText("~ Cek Exp. Tiap");
  CB_ExpCheckPeriod.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ExpCheckPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpCheckPeriodKeyPressed(evt);
   }
  });

  RG_ExpCheckPeriod.add(RB_ExpCheckPeriodByFile);
  RB_ExpCheckPeriodByFile.setText(" ");
  RB_ExpCheckPeriodByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ExpCheckPeriodByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ExpCheckPeriodByFileKeyPressed(evt);
   }
  });

  TF_ExpCheckPeriodFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ExpCheckPeriodFileFocusGained(evt);
   }
  });
  TF_ExpCheckPeriodFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpCheckPeriodFileKeyPressed(evt);
   }
  });

  RG_ExpCheckPeriod.add(RB_ExpCheckPeriodByDef);
  RB_ExpCheckPeriodByDef.setText(" ");
  RB_ExpCheckPeriodByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ExpCheckPeriodByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ExpCheckPeriodByDefKeyPressed(evt);
   }
  });

  TF_ExpCheckPeriodDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ExpCheckPeriodDefFocusGained(evt);
   }
  });
  TF_ExpCheckPeriodDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpCheckPeriodDefKeyPressed(evt);
   }
  });

  Lbl_ExpCheckPeriodDef.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpCheckPeriodDef.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpCheckPeriodDef.setText("(?)");
  Lbl_ExpCheckPeriodDef.setToolTipText("");
  Lbl_ExpCheckPeriodDef.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpCheckPeriodDef.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpCheckPeriodDefMouseClicked(evt);
   }
  });

  CB_ExpThreshold.setText("~ Batas Expire");
  CB_ExpThreshold.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ExpThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpThresholdKeyPressed(evt);
   }
  });

  RG_ExpThreshold.add(RB_ExpThresholdByFile);
  RB_ExpThresholdByFile.setText(" ");
  RB_ExpThresholdByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ExpThresholdByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ExpThresholdByFileKeyPressed(evt);
   }
  });

  TF_ExpThresholdFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ExpThresholdFileFocusGained(evt);
   }
  });
  TF_ExpThresholdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpThresholdFileKeyPressed(evt);
   }
  });

  RG_ExpThreshold.add(RB_ExpThresholdByDef);
  RB_ExpThresholdByDef.setText(" ");
  RB_ExpThresholdByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ExpThresholdByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ExpThresholdByDefKeyPressed(evt);
   }
  });

  Lbl_ExpThresholdDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpThresholdDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpThresholdDefHelp.setText("(?)");
  Lbl_ExpThresholdDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpThresholdDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpThresholdDefHelpMouseClicked(evt);
   }
  });

  TF_ExpThresholdDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ExpThresholdDefFocusGained(evt);
   }
  });
  TF_ExpThresholdDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpThresholdDefKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(CB_HasExp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_SellUpdate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_SellPrice, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_SellComment, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
     .addComponent(CB_BuyComment, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_OpStock, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_OpExp, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_BuyPriceEst, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_OrderQty, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_BuyUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_ExpThreshold, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_ExpCheckPeriod, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addComponent(RB_ExpThresholdByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_ExpThresholdFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_HasExpByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_HasExpFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_OrderQtyByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderQtyFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_SellCommentByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellCommentFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_SellPriceByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellPriceFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(RB_OpStockByFile)
       .addComponent(RB_OpExpByFile))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_OpStockFile)
       .addComponent(TF_OpExpFile)))
     .addComponent(Lbl_FileField2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_SellUpdateByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellUpdateFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_BuyPriceEstByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyPriceEstFile))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(RB_ExpCheckPeriodByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_ExpCheckPeriodFile))
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
        .addComponent(RB_BuyCommentByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_BuyCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(RB_BuyUpdateByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_BuyUpdateFile)))
      .addGap(0, 0, Short.MAX_VALUE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(RB_OrderQtyByDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_OrderQtyDef))
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(RB_OpStockByDef)
         .addComponent(RB_OpExpByDef))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
         .addGroup(jPanel3Layout.createSequentialGroup()
          .addComponent(CB_OpExpDefIsSet)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(TF_OpExpDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(CmB_OpExpDefM, 0, 67, Short.MAX_VALUE)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(CmB_OpExpDefD, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
         .addComponent(TF_OpStockDef))))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Lbl_OpStockDefHelp)
       .addComponent(Lbl_OrderQtyDefHelp)))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
        .addComponent(RB_HasExpByDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_HasExpDef, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(RB_SellPriceByDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_SellPriceDef)))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_SellPriceDefHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(RB_SellUpdateByDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_SellUpdateDefIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_SellUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_SellUpdateDefM, 0, 73, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_SellUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(RB_SellCommentByDef)
         .addComponent(RB_BuyCommentByDef))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(jScrollPane4)
         .addComponent(jScrollPane3)))
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
        .addComponent(RB_BuyUpdateByDef, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(CB_BuyUpdateDefIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_BuyUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BuyUpdateDefM, 0, 71, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BuyUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_SellCommentDefHelp, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Lbl_BuyCommentDefHelp, javax.swing.GroupLayout.Alignment.TRAILING)))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(RB_BuyPriceEstByDef, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyPriceEstDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPriceEstDefHelp))
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(RB_ExpThresholdByDef)
       .addComponent(RB_ExpCheckPeriodByDef))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(TF_ExpCheckPeriodDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_ExpCheckPeriodDef))
       .addGroup(jPanel3Layout.createSequentialGroup()
        .addComponent(TF_ExpThresholdDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_ExpThresholdDefHelp))))))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel21)
     .addComponent(Lbl_FileField2)
     .addComponent(jLabel23))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_HasExp)
     .addComponent(RB_HasExpByFile)
     .addComponent(TF_HasExpFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_HasExpByDef)
     .addComponent(CmB_HasExpDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpCheckPeriodDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ExpCheckPeriodDef)
     .addComponent(RB_ExpCheckPeriodByDef)
     .addComponent(TF_ExpCheckPeriodFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_ExpCheckPeriodByFile)
     .addComponent(CB_ExpCheckPeriod))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpThresholdFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_ExpThresholdByFile)
     .addComponent(CB_ExpThreshold)
     .addComponent(Lbl_ExpThresholdDefHelp)
     .addComponent(TF_ExpThresholdDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_ExpThresholdByDef))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SellPriceFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SellPriceDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SellPriceDefHelp)
     .addComponent(CB_SellPrice)
     .addComponent(RB_SellPriceByFile)
     .addComponent(RB_SellPriceByDef))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SellUpdate)
     .addComponent(RB_SellUpdateByFile)
     .addComponent(TF_SellUpdateFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_SellUpdateByDef)
     .addComponent(CB_SellUpdateDefIsSet)
     .addComponent(TF_SellUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_SellCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_SellCommentDefHelp)
      .addComponent(CB_SellComment)
      .addComponent(RB_SellCommentByFile)
      .addComponent(RB_SellCommentByDef))
     .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BuyPriceEst)
     .addComponent(RB_BuyPriceEstByFile)
     .addComponent(TF_BuyPriceEstFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_BuyPriceEstByDef)
     .addComponent(Lbl_BuyPriceEstDefHelp)
     .addComponent(TF_BuyPriceEstDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BuyUpdateDefIsSet)
     .addComponent(TF_BuyUpdateDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_BuyUpdateByFile)
     .addComponent(TF_BuyUpdateFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyUpdate)
     .addComponent(RB_BuyUpdateByDef))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
     .addComponent(Lbl_BuyCommentDefHelp)
     .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_BuyCommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CB_BuyComment)
      .addComponent(RB_BuyCommentByFile)
      .addComponent(RB_BuyCommentByDef)))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OpStockDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OpStockDefHelp)
     .addComponent(RB_OpStockByDef)
     .addComponent(TF_OpStockFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_OpStockByFile)
     .addComponent(CB_OpStock))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_OpExpDefD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_OpExpDefM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OpExpDefY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpExpDefIsSet)
     .addComponent(RB_OpExpByDef)
     .addComponent(RB_OpExpByFile)
     .addComponent(TF_OpExpFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpExp))
    .addGap(4, 4, 4)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_OrderQty)
     .addComponent(RB_OrderQtyByFile)
     .addComponent(TF_OrderQtyFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_OrderQtyByDef)
     .addComponent(TF_OrderQtyDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderQtyDefHelp)))
  );

  jLabel1.setBackground(new java.awt.Color(204, 204, 255));
  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("Atribut");
  jLabel1.setOpaque(true);

  Lbl_FileField1.setBackground(new java.awt.Color(204, 204, 255));
  Lbl_FileField1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_FileField1.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_FileField1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_FileField1.setText("Field Pd File");
  Lbl_FileField1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_FileField1.setOpaque(true);
  Lbl_FileField1.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_FileField1MouseClicked(evt);
   }
  });

  jLabel6.setBackground(new java.awt.Color(204, 204, 255));
  jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel6.setText("Defenisi Sendiri");
  jLabel6.setOpaque(true);

  TF_NameFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_NameFileFocusGained(evt);
   }
  });
  TF_NameFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameFileKeyPressed(evt);
   }
  });

  TF_StockUnitFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockUnitFileFocusGained(evt);
   }
  });
  TF_StockUnitFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockUnitFileKeyPressed(evt);
   }
  });

  TF_StockUnitDef.setEditable(false);
  TF_StockUnitDef.setBackground(new java.awt.Color(204, 255, 204));

  Btn_StockUnitDefChoose.setText("...");
  Btn_StockUnitDefChoose.setToolTipText("pilih stok unit");
  Btn_StockUnitDefChoose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_StockUnitDefChoose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_StockUnitDefChooseActionPerformed(evt);
   }
  });
  Btn_StockUnitDefChoose.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_StockUnitDefChooseKeyPressed(evt);
   }
  });

  Btn_StockUnitDefClear.setText("-");
  Btn_StockUnitDefClear.setToolTipText("hapus nilai stok unit yg telah dipilih");
  Btn_StockUnitDefClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_StockUnitDefClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_StockUnitDefClearActionPerformed(evt);
   }
  });
  Btn_StockUnitDefClear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_StockUnitDefClearKeyPressed(evt);
   }
  });

  TF_StockFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockFileFocusGained(evt);
   }
  });
  TF_StockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockFileKeyPressed(evt);
   }
  });

  TF_StockDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockDefFocusGained(evt);
   }
  });
  TF_StockDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockDefKeyPressed(evt);
   }
  });

  Lbl_StockDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockDefHelp.setText("(?)");
  Lbl_StockDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockDefHelpMouseClicked(evt);
   }
  });

  TF_UpStockFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_UpStockFileFocusGained(evt);
   }
  });
  TF_UpStockFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_UpStockFileKeyPressed(evt);
   }
  });

  CmB_UpStockDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_UpStockDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_UpStockDefKeyPressed(evt);
   }
  });

  TF_StockMinFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockMinFileFocusGained(evt);
   }
  });
  TF_StockMinFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMinFileKeyPressed(evt);
   }
  });

  TF_StockMinDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockMinDefFocusGained(evt);
   }
  });
  TF_StockMinDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMinDefKeyPressed(evt);
   }
  });

  Lbl_StockMinDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockMinDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockMinDefHelp.setText("(?)");
  Lbl_StockMinDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockMinDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockMinDefHelpMouseClicked(evt);
   }
  });

  TF_StockMaxFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockMaxFileFocusGained(evt);
   }
  });
  TF_StockMaxFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMaxFileKeyPressed(evt);
   }
  });

  TF_StockMaxDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockMaxDefFocusGained(evt);
   }
  });
  TF_StockMaxDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockMaxDefKeyPressed(evt);
   }
  });

  Lbl_StockMaxHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockMaxHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockMaxHelp.setText("(?)");
  Lbl_StockMaxHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockMaxHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockMaxHelpMouseClicked(evt);
   }
  });

  TF_CommentFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_CommentFileFocusGained(evt);
   }
  });
  TF_CommentFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_CommentFileKeyPressed(evt);
   }
  });

  TA_CommentDef.setColumns(5);
  TA_CommentDef.setLineWrap(true);
  TA_CommentDef.setWrapStyleWord(true);
  TA_CommentDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentDefKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_CommentDef);

  Lbl_CommentDefHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentDefHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentDefHelp.setText("(?)");
  Lbl_CommentDefHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentDefHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentDefHelpMouseClicked(evt);
   }
  });

  TF_IdFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_IdFileFocusGained(evt);
   }
  });
  TF_IdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IdFileKeyPressed(evt);
   }
  });

  RG_UpStock.add(RB_UpStockByFile);
  RB_UpStockByFile.setText(" ");
  RB_UpStockByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_UpStockByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_UpStockByFileKeyPressed(evt);
   }
  });

  RG_StockUnit.add(RB_StockUnitByFile);
  RB_StockUnitByFile.setText(" ");
  RB_StockUnitByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockUnitByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockUnitByFileKeyPressed(evt);
   }
  });

  RG_Stock.add(RB_StockByFile);
  RB_StockByFile.setText(" ");
  RB_StockByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockByFileKeyPressed(evt);
   }
  });

  RG_StockMin.add(RB_StockMinByFile);
  RB_StockMinByFile.setText(" ");
  RB_StockMinByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockMinByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockMinByFileKeyPressed(evt);
   }
  });

  RG_StockMax.add(RB_StockMaxByFile);
  RB_StockMaxByFile.setText(" ");
  RB_StockMaxByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockMaxByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockMaxByFileKeyPressed(evt);
   }
  });

  RG_Comment.add(RB_CommentByFile);
  RB_CommentByFile.setText(" ");
  RB_CommentByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_CommentByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_CommentByFileKeyPressed(evt);
   }
  });

  RG_StockUnit.add(RB_StockUnitByDef);
  RB_StockUnitByDef.setText(" ");
  RB_StockUnitByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockUnitByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockUnitByDefKeyPressed(evt);
   }
  });

  RG_Stock.add(RB_StockByDef);
  RB_StockByDef.setText(" ");
  RB_StockByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockByDefKeyPressed(evt);
   }
  });

  RG_UpStock.add(RB_UpStockByDef);
  RB_UpStockByDef.setText(" ");
  RB_UpStockByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_UpStockByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_UpStockByDefKeyPressed(evt);
   }
  });

  RG_StockMin.add(RB_StockMinByDef);
  RB_StockMinByDef.setText(" ");
  RB_StockMinByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockMinByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockMinByDefKeyPressed(evt);
   }
  });

  RG_StockMax.add(RB_StockMaxByDef);
  RB_StockMaxByDef.setText(" ");
  RB_StockMaxByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_StockMaxByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_StockMaxByDefKeyPressed(evt);
   }
  });

  RG_Comment.add(RB_CommentByDef);
  RB_CommentByDef.setText(" ");
  RB_CommentByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_CommentByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_CommentByDefKeyPressed(evt);
   }
  });

  CB_Id.setText("Id Barang");
  CB_Id.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Id.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IdKeyPressed(evt);
   }
  });

  CB_Name.setText("Nama Barang");
  CB_Name.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_NameKeyPressed(evt);
   }
  });

  CB_StockUnit.setText("Satuan Stok");
  CB_StockUnit.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockUnitKeyPressed(evt);
   }
  });

  CB_Stock.setText("~ Stok");
  CB_Stock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Stock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockKeyPressed(evt);
   }
  });

  CB_UpStock.setText("Perbarui Stok");
  CB_UpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_UpStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpStockKeyPressed(evt);
   }
  });

  CB_StockMin.setText("~ Stok Minimal");
  CB_StockMin.setToolTipText("");
  CB_StockMin.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockMin.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockMinKeyPressed(evt);
   }
  });

  CB_StockMax.setText("~ Stok Maksimal");
  CB_StockMax.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_StockMax.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_StockMaxKeyPressed(evt);
   }
  });

  CB_Comment.setText("Keterangan");
  CB_Comment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_CommentKeyPressed(evt);
   }
  });

  CmB_IsActiveDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_IsActiveDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IsActiveDefKeyPressed(evt);
   }
  });

  TF_IsActiveFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_IsActiveFileFocusGained(evt);
   }
  });
  TF_IsActiveFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IsActiveFileKeyPressed(evt);
   }
  });

  RG_IsActive.add(RB_IsActiveByFile);
  RB_IsActiveByFile.setText(" ");
  RB_IsActiveByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsActiveByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsActiveByFileKeyPressed(evt);
   }
  });

  RG_IsActive.add(RB_IsActiveByDef);
  RB_IsActiveByDef.setText(" ");
  RB_IsActiveByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsActiveByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsActiveByDefKeyPressed(evt);
   }
  });

  CB_IsActive.setText("Masih Aktif");
  CB_IsActive.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsActive.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsActiveKeyPressed(evt);
   }
  });

  CB_OrderMinPack.setText("~ Order Min Pak");
  CB_OrderMinPack.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderMinPack.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderMinPackKeyPressed(evt);
   }
  });

  RG_OrderMinPack.add(RB_OrderMinPackByFile);
  RB_OrderMinPackByFile.setText(" ");
  RB_OrderMinPackByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderMinPackByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderMinPackByFileKeyPressed(evt);
   }
  });

  TF_OrderMinPackFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderMinPackFileFocusGained(evt);
   }
  });
  TF_OrderMinPackFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderMinPackFileKeyPressed(evt);
   }
  });

  RG_OrderMinPack.add(RB_OrderMinPackByDef);
  RB_OrderMinPackByDef.setText(" ");
  RB_OrderMinPackByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderMinPackByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderMinPackByDefKeyPressed(evt);
   }
  });

  TF_OrderMinPackDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderMinPackDefFocusGained(evt);
   }
  });
  TF_OrderMinPackDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderMinPackDefKeyPressed(evt);
   }
  });

  Lbl_OrderMinPackHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderMinPackHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderMinPackHelp.setText("(?)");
  Lbl_OrderMinPackHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderMinPackHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderMinPackHelpMouseClicked(evt);
   }
  });

  CB_OrderEachPackThreshold.setText("~ Pmbulatn / Pak");
  CB_OrderEachPackThreshold.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderEachPackThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderEachPackThresholdKeyPressed(evt);
   }
  });

  RG_OrderEachPackThreshold.add(RB_OrderEachPackThresholdByFile);
  RB_OrderEachPackThresholdByFile.setText(" ");
  RB_OrderEachPackThresholdByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderEachPackThresholdByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderEachPackThresholdByFileKeyPressed(evt);
   }
  });

  TF_OrderEachPackThresholdFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderEachPackThresholdFileFocusGained(evt);
   }
  });
  TF_OrderEachPackThresholdFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackThresholdFileKeyPressed(evt);
   }
  });

  RG_OrderEachPackThreshold.add(RB_OrderEachPackThresholdByDef);
  RB_OrderEachPackThresholdByDef.setText(" ");
  RB_OrderEachPackThresholdByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderEachPackThresholdByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderEachPackThresholdByDefKeyPressed(evt);
   }
  });

  TF_OrderEachPackThresholdDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderEachPackThresholdDefFocusGained(evt);
   }
  });
  TF_OrderEachPackThresholdDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackThresholdDefKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackThresholdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackThresholdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackThresholdHelp.setText("(?)");
  Lbl_OrderEachPackThresholdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackThresholdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackThresholdHelpMouseClicked(evt);
   }
  });

  CB_OrderEachPackQty.setText("~ Order Qty / Pak");
  CB_OrderEachPackQty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrderEachPackQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OrderEachPackQtyKeyPressed(evt);
   }
  });

  RG_OrderEachPackQty.add(RB_OrderEachPackQtyByFile);
  RB_OrderEachPackQtyByFile.setText(" ");
  RB_OrderEachPackQtyByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderEachPackQtyByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderEachPackQtyByFileKeyPressed(evt);
   }
  });

  TF_OrderEachPackQtyFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderEachPackQtyFileFocusGained(evt);
   }
  });
  TF_OrderEachPackQtyFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackQtyFileKeyPressed(evt);
   }
  });

  RG_OrderEachPackQty.add(RB_OrderEachPackQtyByDef);
  RB_OrderEachPackQtyByDef.setText(" ");
  RB_OrderEachPackQtyByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_OrderEachPackQtyByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_OrderEachPackQtyByDefKeyPressed(evt);
   }
  });

  TF_OrderEachPackQtyDef.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderEachPackQtyDefFocusGained(evt);
   }
  });
  TF_OrderEachPackQtyDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackQtyDefKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackQtyDef.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackQtyDef.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackQtyDef.setText("(?)");
  Lbl_OrderEachPackQtyDef.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackQtyDef.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackQtyDefMouseClicked(evt);
   }
  });

  CB_IsReorder.setText("Di-Reorder");
  CB_IsReorder.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsReorder.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsReorderKeyPressed(evt);
   }
  });

  RG_IsReorder.add(RB_IsReorderByFile);
  RB_IsReorderByFile.setText(" ");
  RB_IsReorderByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsReorderByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsReorderByFileKeyPressed(evt);
   }
  });

  TF_IsReorderFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_IsReorderFileFocusGained(evt);
   }
  });
  TF_IsReorderFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IsReorderFileKeyPressed(evt);
   }
  });

  RG_IsReorder.add(RB_IsReorderByDef);
  RB_IsReorderByDef.setText(" ");
  RB_IsReorderByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsReorderByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsReorderByDefKeyPressed(evt);
   }
  });

  CmB_IsReorderDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_IsReorderDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IsReorderDefKeyPressed(evt);
   }
  });

  RG_IsOpname.add(RB_IsOpnameByDef);
  RB_IsOpnameByDef.setText(" ");
  RB_IsOpnameByDef.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsOpnameByDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsOpnameByDefKeyPressed(evt);
   }
  });

  CmB_IsOpnameDef.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ya", "Tidak" }));
  CmB_IsOpnameDef.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_IsOpnameDefKeyPressed(evt);
   }
  });

  RG_IsOpname.add(RB_IsOpnameByFile);
  RB_IsOpnameByFile.setText(" ");
  RB_IsOpnameByFile.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_IsOpnameByFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_IsOpnameByFileKeyPressed(evt);
   }
  });

  TF_IsOpnameFile.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_IsOpnameFileFocusGained(evt);
   }
  });
  TF_IsOpnameFile.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IsOpnameFileKeyPressed(evt);
   }
  });

  CB_IsOpname.setText("Di-Opname");
  CB_IsOpname.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsOpname.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsOpnameKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(CB_OrderEachPackQty, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
     .addComponent(CB_OrderEachPackThreshold, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_OrderMinPack, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_Id, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_Name, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_StockUnit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_Stock, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_UpStock, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_StockMin, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_StockMax, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_IsActive, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_Comment, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_IsReorder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(CB_IsOpname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(RB_OrderMinPackByFile)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderMinPackFile))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(RB_UpStockByFile)
       .addComponent(RB_StockUnitByFile)
       .addComponent(RB_StockByFile)
       .addComponent(RB_StockMinByFile)
       .addComponent(RB_StockMaxByFile)
       .addComponent(RB_CommentByFile)
       .addComponent(RB_IsActiveByFile))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_StockUnitFile)
       .addComponent(TF_StockFile)
       .addComponent(TF_NameFile)
       .addComponent(TF_IdFile)
       .addComponent(TF_StockMinFile)
       .addComponent(TF_StockMaxFile)
       .addComponent(TF_IsActiveFile, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_CommentFile, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_UpStockFile)))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addComponent(RB_IsOpnameByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_IsOpnameFile))
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addComponent(RB_IsReorderByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_IsReorderFile))
       .addComponent(Lbl_FileField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addComponent(RB_OrderEachPackThresholdByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_OrderEachPackThresholdFile))
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addComponent(RB_OrderEachPackQtyByFile)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_OrderEachPackQtyFile)))
      .addGap(0, 0, Short.MAX_VALUE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(RB_StockMinByDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_StockMinDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_StockMinDefHelp))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(RB_StockMaxByDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_StockMaxDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_StockMaxHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(RB_StockUnitByDef)
         .addComponent(RB_CommentByDef))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(jPanel5Layout.createSequentialGroup()
          .addComponent(TF_StockUnitDef)
          .addGap(0, 0, 0)
          .addComponent(Btn_StockUnitDefChoose)
          .addGap(3, 3, 3)
          .addComponent(Btn_StockUnitDefClear))
         .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
         .addComponent(CmB_IsActiveDef, 0, 258, Short.MAX_VALUE)))
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(RB_StockByDef)
         .addComponent(RB_UpStockByDef))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(TF_StockDef)
         .addComponent(CmB_UpStockDef, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_StockDefHelp)
       .addComponent(Lbl_CommentDefHelp, javax.swing.GroupLayout.Alignment.TRAILING)))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(RB_OrderEachPackThresholdByDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OrderEachPackThresholdDef)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderEachPackThresholdHelp))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(RB_IsOpnameByDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_IsOpnameDef, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(RB_IsReorderByDef)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_IsReorderDef, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
       .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(RB_OrderMinPackByDef)
         .addComponent(RB_OrderEachPackQtyByDef))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(TF_OrderEachPackQtyDef)
         .addComponent(TF_OrderMinPackDef))))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_OrderMinPackHelp, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Lbl_OrderEachPackQtyDef, javax.swing.GroupLayout.Alignment.TRAILING)))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(RB_IsActiveByDef)
      .addGap(0, 0, Short.MAX_VALUE))))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel1)
     .addComponent(Lbl_FileField1)
     .addComponent(jLabel6))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_IdFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Id))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_NameFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Name))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_IsActiveFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_IsActiveByFile)
     .addComponent(RB_IsActiveByDef)
     .addComponent(CmB_IsActiveDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_IsActive))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_CommentDefHelp)
        .addGap(0, 43, Short.MAX_VALUE))
       .addComponent(jScrollPane2))
      .addGap(4, 4, 4)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_StockUnitFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_StockUnitDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Btn_StockUnitDefChoose)
       .addComponent(Btn_StockUnitDefClear)
       .addComponent(RB_StockUnitByFile)
       .addComponent(RB_StockUnitByDef)
       .addComponent(CB_StockUnit))
      .addGap(4, 4, 4)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(CmB_UpStockDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(RB_UpStockByDef)
       .addComponent(RB_UpStockByFile)
       .addComponent(TF_UpStockFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(CB_UpStock))
      .addGap(4, 4, 4)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_StockFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_StockDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Lbl_StockDefHelp)
       .addComponent(RB_StockByFile)
       .addComponent(RB_StockByDef)
       .addComponent(CB_Stock))
      .addGap(4, 4, 4)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_StockMinFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_StockMinDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Lbl_StockMinDefHelp)
       .addComponent(RB_StockMinByFile)
       .addComponent(RB_StockMinByDef)
       .addComponent(CB_StockMin))
      .addGap(4, 4, 4)
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(TF_StockMaxFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_StockMaxDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Lbl_StockMaxHelp)
       .addComponent(RB_StockMaxByFile)
       .addComponent(RB_StockMaxByDef)
       .addComponent(CB_StockMax)))
     .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(RB_CommentByDef)
      .addComponent(TF_CommentFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(RB_CommentByFile)
      .addComponent(CB_Comment)))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_IsOpnameByDef)
     .addComponent(CmB_IsOpnameDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_IsOpnameByFile)
     .addComponent(TF_IsOpnameFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_IsOpname))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_IsReorder)
     .addComponent(RB_IsReorderByFile)
     .addComponent(TF_IsReorderFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_IsReorderByDef)
     .addComponent(CmB_IsReorderDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OrderEachPackQtyDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OrderEachPackQty)
     .addComponent(RB_OrderEachPackQtyByFile)
     .addComponent(TF_OrderEachPackQtyFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_OrderEachPackQtyByDef)
     .addComponent(Lbl_OrderEachPackQtyDef))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_OrderEachPackThreshold)
     .addComponent(RB_OrderEachPackThresholdByFile)
     .addComponent(TF_OrderEachPackThresholdFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_OrderEachPackThresholdByDef)
     .addComponent(TF_OrderEachPackThresholdDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderEachPackThresholdHelp))
    .addGap(4, 4, 4)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_OrderMinPack)
     .addComponent(RB_OrderMinPackByFile)
     .addComponent(TF_OrderMinPackFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(RB_OrderMinPackByDef)
     .addComponent(TF_OrderMinPackDef, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderMinPackHelp))
    .addGap(0, 0, 0))
  );

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(18, 18, 18)
    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jSeparator1)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_ImportInfo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ImportInfo.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ImportInfo.setText("{ Klik utk melihat informasi impor-perbaharui }");
  Lbl_ImportInfo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ImportInfo.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ImportInfoMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(Lbl_ImportInfo)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok)
    .addComponent(Lbl_ImportInfo))
  );

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("- - - Pilih Atribut Yg Akan Di-update Dan Defenisikan Nilainya - - -");
  jLabel3.setToolTipText("");

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel2.setText("- - - Atur Pencocokan Antara Database Dengan File - - -");

  Lbl_BasedFileField.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BasedFileField.setText("Lakukan pembaharuan data dengan mencocokkan antara Id Barang pada 'database' dengan Id Barang pada 'Field File' ke-");

  TF_BasedFileField.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BasedFileFieldFocusGained(evt);
   }
  });
  TF_BasedFileField.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BasedFileFieldKeyPressed(evt);
   }
  });

  Lbl_BasedAttributeFileFieldHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BasedAttributeFileFieldHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BasedAttributeFileFieldHelp.setText("(?)");
  Lbl_BasedAttributeFileFieldHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BasedAttributeFileFieldHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BasedAttributeFileFieldHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(Lbl_BasedFileField)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_BasedFileField, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_BasedAttributeFileFieldHelp)
    .addContainerGap(305, Short.MAX_VALUE))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Lbl_BasedFileField)
    .addComponent(TF_BasedFileField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Lbl_BasedAttributeFileFieldHelp))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel2)
    .addGap(4, 4, 4)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel3)
    .addGap(4, 4, 4)
    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation IsValid;
  boolean CurrValid;
  VBoolean First;
  
  // validate file csv
  if(ChoosedFile==null){
   JOptionPane.showMessageDialog(null, "Belum ada file CSV yg dipilih !");
   return;
  }
  FileCsv=ChoosedFile;
  
  // validate import data input
  IsValid=new OValidation(true);
  First=new VBoolean(false);
  
  BasedFileField.Value=fileFieldIsValid(TF_BasedFileField);
  setValid(BasedFileField.Value!=-1, Lbl_BasedFileField, IsValid, CGUI.Color_Label_InputRight);
  
  UpdateId.Value=CB_Id.isSelected();
  if(UpdateId.Value){
   CurrValid=false;
   do{
    IdFileField.Value=fileFieldIsValid(TF_IdFile); if(IdFileField.Value==-1){break;}
    CurrValid=true;
   }while(false);
   setValid(CurrValid, CB_Id, IsValid, CGUI.Color_Label_InputPrimary); First.Value=true;
  }
   
  UpdateName.Value=CB_Name.isSelected();
  if(UpdateName.Value){
   CurrValid=false;
   do{
    NameFileField.Value=fileFieldIsValid(TF_NameFile); if(NameFileField.Value==-1){break;}
    CurrValid=true;
   }while(false);
   setValid(CurrValid, CB_Name, IsValid, CGUI.Color_Label_InputPrimary); First.Value=true;
  }
  
  UpdateStockUnit.Value=CB_StockUnit.isSelected();
  if(UpdateStockUnit.Value){
   CurrValid=false;
   do{
    StockUnitByFile.Value=RB_StockUnitByFile.isSelected();
    if(StockUnitByFile.Value){
     StockUnitFileField.Value=fileFieldIsValid(TF_StockUnitFile); if(StockUnitFileField.Value==-1){break;}
    }
    else{
     StockUnitId.Value=ChoosedStockUnitId;
    }
    CurrValid=true;
   }while(false);
   setValid(CurrValid, CB_StockUnit, IsValid, CGUI.Color_Label_InputPrimary); First.Value=true;
  }
  
  // check double cannot be null
  checkDouble(UpdateStock, StockByFile, StockFileField, Stock, RB_StockByFile, TF_StockFile, TF_StockDef, CB_Stock, IsValid, First, CGUI.Color_Label_InputPrimary, false, true, false, false, 0, 0);
  checkDouble(UpdateStockMin, StockMinByFile, StockMinFileField, StockMin, RB_StockMinByFile, TF_StockMinFile, TF_StockMinDef, CB_StockMin, IsValid, First, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  checkDouble(UpdateStockMax, StockMaxByFile, StockMaxFileField, StockMax, RB_StockMaxByFile, TF_StockMaxFile, TF_StockMaxDef, CB_StockMax, IsValid, First, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  
  checkDouble(UpdateOrderMinPack, OrderMinPackByFile, OrderMinPackFileField, OrderMinPack, RB_OrderMinPackByFile, TF_OrderMinPackFile, TF_OrderMinPackDef, CB_OrderMinPack, IsValid, First, CGUI.Color_Label_InputSecondary, false, false, true, false, 0, 0);
  checkDouble(UpdateOrderEachPackQty, OrderEachPackQtyByFile, OrderEachPackQtyFileField, OrderEachPackQty, RB_OrderEachPackQtyByFile, TF_OrderEachPackQtyFile, TF_OrderEachPackQtyDef, CB_OrderEachPackQty, IsValid, First, CGUI.Color_Label_InputPrimary, false, false, true, false, 0, 0);
  checkDouble(UpdateOrderEachPackThreshold, OrderEachPackThresholdByFile, OrderEachPackThresholdFileField, OrderEachPackThreshold, RB_OrderEachPackThresholdByFile, TF_OrderEachPackThresholdFile, TF_OrderEachPackThresholdDef, CB_OrderEachPackThreshold, IsValid, First, CGUI.Color_Label_InputSecondary, false, true, true, true, 0.01, 100);
  
  checkDouble(UpdateSellPrice, SellPriceByFile, SellPriceFileField, SellPrice, RB_SellPriceByFile, TF_SellPriceFile, TF_SellPriceDef, CB_SellPrice, IsValid, First, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  checkDouble(UpdateBuyPriceEst, BuyPriceEstByFile, BuyPriceEstFileField, BuyPriceEst, RB_BuyPriceEstByFile, TF_BuyPriceEstFile, TF_BuyPriceEstDef, CB_BuyPriceEst, IsValid, First, CGUI.Color_Label_InputPrimary, false, true, true, false, 0, 0);
  
  // check double can be null
  checkDouble(UpdateOpStock, OpStockByFile, OpStockFileField, OpStock, RB_OpStockByFile, TF_OpStockFile, TF_OpStockDef, CB_OpStock, IsValid, First, CGUI.Color_Label_InputSecondary, true, true, false, false, 0, 0);
  checkDouble(UpdateOrderQty, OrderQtyByFile, OrderQtyFileField, OrderQty, RB_OrderQtyByFile, TF_OrderQtyFile, TF_OrderQtyDef, CB_OrderQty, IsValid, First, CGUI.Color_Label_InputSecondary, true, true, true, false, 0, 0);
  
  // check integer can be null
  checkInteger(UpdateExpCheckPeriod, ExpCheckPeriodByFile, ExpCheckPeriodFileField, ExpCheckPeriod, RB_ExpCheckPeriodByFile, TF_ExpCheckPeriodFile, TF_ExpCheckPeriodDef, CB_ExpCheckPeriod, IsValid, First, CGUI.Color_Label_InputPrimary, true, false, true, false, 0, 0);
  checkInteger(UpdateExpThreshold, ExpThresholdByFile, ExpThresholdFileField, ExpThreshold, RB_ExpThresholdByFile, TF_ExpThresholdFile, TF_ExpThresholdDef, CB_ExpThreshold, IsValid, First, CGUI.Color_Label_InputPrimary, true, true, true, false, 0, 0);
  
  // check boolean
  checkBoolean(UpdateUpStock, UpStockByFile, UpStockFileField, UpStock, RB_UpStockByFile, TF_UpStockFile, CmB_UpStockDef, CB_UpStock, IsValid, First, CGUI.Color_Label_InputPrimary);
  checkBoolean(UpdateIsActive, IsActiveByFile, IsActiveFileField, IsActive, RB_IsActiveByFile, TF_IsActiveFile, CmB_IsActiveDef, CB_IsActive, IsValid, First, CGUI.Color_Label_InputPrimary);
  checkBoolean(UpdateIsOpname, IsOpnameByFile, IsOpnameFileField, IsOpname, RB_IsOpnameByFile, TF_IsOpnameFile, CmB_IsOpnameDef, CB_IsOpname, IsValid, First, CGUI.Color_Label_InputPrimary);
  checkBoolean(UpdateIsReorder, IsReorderByFile, IsReorderFileField, IsReorder, RB_IsReorderByFile, TF_IsReorderFile, CmB_IsReorderDef, CB_IsReorder, IsValid, First, CGUI.Color_Label_InputPrimary);
  checkBoolean(UpdateHasExp, HasExpByFile, HasExpFileField, HasExp, RB_HasExpByFile, TF_HasExpFile, CmB_HasExpDef, CB_HasExp, IsValid, First, CGUI.Color_Label_InputPrimary);
  
  // check date
  checkDate(UpdateOpExp, OpExpByFile, OpExpFileField, OpExp, RB_OpExpByFile, TF_OpExpFile, CB_OpExpDefIsSet, TF_OpExpDefY, CmB_OpExpDefM, CmB_OpExpDefD, CB_OpExp, IsValid, First, CGUI.Color_Label_InputSecondary);
  checkDate(UpdateSellUpdate, SellUpdateByFile, SellUpdateFileField, SellUpdate, RB_SellUpdateByFile, TF_SellUpdateFile, CB_SellUpdateDefIsSet, TF_SellUpdateDefY, CmB_SellUpdateDefM, CmB_SellUpdateDefD, CB_SellUpdate, IsValid, First, CGUI.Color_Label_InputSecondary);
  checkDate(UpdateBuyUpdate, BuyUpdateByFile, BuyUpdateFileField, BuyUpdate, RB_BuyUpdateByFile, TF_BuyUpdateFile, CB_BuyUpdateDefIsSet, TF_BuyUpdateDefY, CmB_BuyUpdateDefM, CmB_BuyUpdateDefD, CB_BuyUpdate, IsValid, First, CGUI.Color_Label_InputSecondary);
  
  // check string
  checkString(UpdateComment, CommentByFile, CommentFileField, Comment, RB_CommentByFile, TF_CommentFile, TA_CommentDef, CB_Comment, IsValid, First, CGUI.Color_Label_InputSecondary, true, CApp.DbVarcharMaxSize);
  checkString(UpdateSellComment, SellCommentByFile, SellCommentFileField, SellComment, RB_SellCommentByFile, TF_SellCommentFile, TA_SellCommentDef, CB_SellComment, IsValid, First, CGUI.Color_Label_InputSecondary, true, CApp.DbVarcharMaxSize);
  checkString(UpdateBuyComment, BuyCommentByFile, BuyCommentFileField, BuyComment, RB_BuyCommentByFile, TF_BuyCommentFile, TA_BuyCommentDef, CB_BuyComment, IsValid, First, CGUI.Color_Label_InputSecondary, true, CApp.DbVarcharMaxSize);
  
  if(!First.Value){
   JOptionPane.showMessageDialog(null, "Belum ada atribut update yang dipilih !");
   return;
  }
  
  if(!IsValid.getValid()){
   JOptionPane.showMessageDialog(null, "Inputan data masih salah !"+
    "\nSilahkan koreksi inputan data pada label berwarna merah !");
   return;
  }
  
  clearComponents();
  DialogResult=1;
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_ChooseFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseFileActionPerformed
  File f;
  F_CsvReadOption fm=IFV.FCsvReadOption;
  
  f=PGUI.showLoadDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  setFileCsv(f, fm.FieldDelimiter, fm.FieldsSeparators, CCore.CsvRecordsSeparators, true);
 }//GEN-LAST:event_Btn_ChooseFileActionPerformed

 private void Lbl_FileHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileHelpMouseClicked
  JOptionPane.showMessageDialog(null, PMyShop.getReadWriteCsvInfo(true));
 }//GEN-LAST:event_Lbl_FileHelpMouseClicked

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  DialogResult=0;
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  Activ=true;
 }//GEN-LAST:event_formWindowActivated

 private void Btn_StockUnitDefChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefChooseActionPerformed
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=false;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblStockUnit;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  setStockUnit((int)IFV.FDataIdName.DataId[0], IFV.FDataIdName.DataName[0]);
 }//GEN-LAST:event_Btn_StockUnitDefChooseActionPerformed

 private void Btn_StockUnitDefClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefClearActionPerformed
  setStockUnit(-1, null);
 }//GEN-LAST:event_Btn_StockUnitDefClearActionPerformed

 private void Lbl_StockDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_StockDefHelpMouseClicked

 private void Lbl_StockMinDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockMinDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_StockMinDefHelpMouseClicked

 private void Lbl_StockMaxHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockMaxHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_StockMaxHelpMouseClicked

 private void Lbl_OpStockDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OpStockDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_OpStockDefHelpMouseClicked

 private void Lbl_CommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_CommentDefHelpMouseClicked

 private void Lbl_ExpCheckPeriodDefMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpCheckPeriodDefMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 9, 2, 7, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpCheckPeriodDefMouseClicked

 private void Lbl_ExpThresholdDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpThresholdDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 9, 2, 3, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpThresholdDefHelpMouseClicked

 private void Lbl_SellPriceDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellPriceDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_SellPriceDefHelpMouseClicked

 private void Lbl_SellCommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellCommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_SellCommentDefHelpMouseClicked

 private void Lbl_BuyCommentDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyCommentDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_BuyCommentDefHelpMouseClicked

 private void CB_OpExpDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OpExpDefIsSetActionPerformed
  PGUI.enableInput(CB_OpExpDefIsSet.isSelected(), TF_OpExpDefY, CmB_OpExpDefM, CmB_OpExpDefD, false);
 }//GEN-LAST:event_CB_OpExpDefIsSetActionPerformed

 private void Lbl_FileField1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileField1MouseClicked
  JOptionPane.showMessageDialog(null,
   "Isi inputan dgn posisi field pd file."+
   "\n(jangkauan nilai mulai dari nilai 1 hingga 'jumlah field pada file').");
 }//GEN-LAST:event_Lbl_FileField1MouseClicked

 private void Lbl_FileField2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_FileField2MouseClicked
  Lbl_FileField1MouseClicked(null);
 }//GEN-LAST:event_Lbl_FileField2MouseClicked

 private void Lbl_ImportInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ImportInfoMouseClicked
  JOptionPane.showMessageDialog(null,
   "Proses update dilakukan dgn cara :"+"\n"+
   "- Mencari data barang pd database dgn mencocokkan antara 'Id Brg' pd 'Field File' dgn 'Id Brg' pd database."+"\n"+
   "- Jika data barang pd database ditemukan, maka update data barang tsb sesuai dgn"+"\n"+
   "    atribut-atribut yg dipilih dan nilai pembaharuan atribut yg didefenisikan."
  );
 }//GEN-LAST:event_Lbl_ImportInfoMouseClicked

 private void Lbl_BasedAttributeFileFieldHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BasedAttributeFileFieldHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "Isi inputan dgn posisi field pd file."+
   "\n(jangkauan nilai mulai dari nilai 1 hingga 'jumlah field pada file').");
 }//GEN-LAST:event_Lbl_BasedAttributeFileFieldHelpMouseClicked

 private void Lbl_BuyPriceEstDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceEstDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPriceEstDefHelpMouseClicked

 private void Lbl_OrderQtyDefHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderQtyDefHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_OrderQtyDefHelpMouseClicked

 private void CB_SellUpdateDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellUpdateDefIsSetActionPerformed
  PGUI.enableInput(CB_SellUpdateDefIsSet.isSelected(), TF_SellUpdateDefY, CmB_SellUpdateDefM, CmB_SellUpdateDefD, false);
 }//GEN-LAST:event_CB_SellUpdateDefIsSetActionPerformed

 private void CB_BuyUpdateDefIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyUpdateDefIsSetActionPerformed
  PGUI.enableInput(CB_BuyUpdateDefIsSet.isSelected(), TF_BuyUpdateDefY, CmB_BuyUpdateDefM, CmB_BuyUpdateDefD, false);
 }//GEN-LAST:event_CB_BuyUpdateDefIsSetActionPerformed

 private void Lbl_OrderMinPackHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderMinPackHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderMinPackHelpMouseClicked

 private void Lbl_OrderEachPackQtyDefMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackQtyDefMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackQtyDefMouseClicked

 private void Lbl_OrderEachPackThresholdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackThresholdHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Bulatkan menjadi 1 pak jika 'sisa perhitungan' >= 'n' % x 'Order Qty / Pak'."+"\n"+
   "- Jangkauan nilai 'n' adalah 0 < 'n' <= 100."+"\n"+
   PText.getInputInfo(false, 6, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackThresholdHelpMouseClicked

 private void Btn_ChooseFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseFileKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseFileKeyPressed

 private void CB_IdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IdKeyPressed
  PNav.onKey_CB(this, CB_Id, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BasedFileField)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Name)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IdFile)));
 }//GEN-LAST:event_CB_IdKeyPressed

 private void TF_IdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IdFileKeyPressed
  PNav.onKey_TF(this, TF_IdFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BasedFileField)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_NameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_IdFileKeyPressed

 private void CB_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_NameKeyPressed
  PNav.onKey_CB(this, CB_Name, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Id)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsActive)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_NameFile)));
 }//GEN-LAST:event_CB_NameKeyPressed

 private void TF_NameFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameFileKeyPressed
  PNav.onKey_TF(this, TF_NameFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IsActiveFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Name)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameFileKeyPressed

 private void CB_IsActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsActiveKeyPressed
  PNav.onKey_CB(this, CB_IsActive, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsActiveByFile)));
 }//GEN-LAST:event_CB_IsActiveKeyPressed

 private void RB_IsActiveByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsActiveByFileKeyPressed
  PNav.onKey_RB(this, RB_IsActiveByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_CommentByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsActive)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IsActiveFile)));
 }//GEN-LAST:event_RB_IsActiveByFileKeyPressed

 private void TF_IsActiveFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IsActiveFileKeyPressed
  PNav.onKey_TF(this, TF_IsActiveFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_NameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_CommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsActiveByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsActiveByDef)));
 }//GEN-LAST:event_TF_IsActiveFileKeyPressed

 private void RB_IsActiveByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsActiveByDefKeyPressed
  PNav.onKey_RB(this, RB_IsActiveByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_CommentByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_IsActiveFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsActiveDef)));
 }//GEN-LAST:event_RB_IsActiveByDefKeyPressed

 private void CmB_IsActiveDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IsActiveDefKeyPressed
  PNav.onKey_CmB(this, CmB_IsActiveDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsActiveByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_CommentDef)));
 }//GEN-LAST:event_CmB_IsActiveDefKeyPressed

 private void CB_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_CommentKeyPressed
  PNav.onKey_CB(this, CB_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActive)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockUnit)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_CommentByFile)));
 }//GEN-LAST:event_CB_CommentKeyPressed

 private void RB_CommentByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_CommentByFileKeyPressed
  PNav.onKey_RB(this, RB_CommentByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsActiveByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockUnitByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Comment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_CommentFile)));
 }//GEN-LAST:event_RB_CommentByFileKeyPressed

 private void TF_CommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_CommentFileKeyPressed
  PNav.onKey_TF(this, TF_CommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IsActiveFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockUnitFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_CommentByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_CommentByDef)));
 }//GEN-LAST:event_TF_CommentFileKeyPressed

 private void RB_CommentByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_CommentByDefKeyPressed
  PNav.onKey_RB(this, RB_CommentByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsActiveByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockUnitByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_CommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_CommentDef)));
 }//GEN-LAST:event_RB_CommentByDefKeyPressed

 private void TA_CommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentDefKeyPressed
  PNav.onKey_TA(this, TA_CommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_IsActiveDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_StockUnitDefChoose)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_CommentByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_CommentDefKeyPressed

 private void CB_StockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockUnitKeyPressed
  PNav.onKey_CB(this, CB_StockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_UpStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockUnitByFile)));
 }//GEN-LAST:event_CB_StockUnitKeyPressed

 private void RB_StockUnitByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockUnitByFileKeyPressed
  PNav.onKey_RB(this, RB_StockUnitByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_CommentByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_UpStockByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockUnitFile)));
 }//GEN-LAST:event_RB_StockUnitByFileKeyPressed

 private void TF_StockUnitFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockUnitFileKeyPressed
  PNav.onKey_TF(this, TF_StockUnitFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_CommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_UpStockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockUnitByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockUnitByDef)));
 }//GEN-LAST:event_TF_StockUnitFileKeyPressed

 private void RB_StockUnitByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockUnitByDefKeyPressed
  PNav.onKey_RB(this, RB_StockUnitByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_CommentByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_UpStockByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockUnitFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_StockUnitDefChoose)));
 }//GEN-LAST:event_RB_StockUnitByDefKeyPressed

 private void Btn_StockUnitDefChooseKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefChooseKeyPressed
  PNav.onKey_Btn(this, Btn_StockUnitDefChoose, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_CommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_UpStockDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockUnitByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_StockUnitDefClear)));
 }//GEN-LAST:event_Btn_StockUnitDefChooseKeyPressed

 private void Btn_StockUnitDefClearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_StockUnitDefClearKeyPressed
  PNav.onKey_Btn(this, Btn_StockUnitDefClear, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_CommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_UpStockDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_StockUnitDefChoose)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_StockUnitDefClearKeyPressed

 private void CB_UpStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpStockKeyPressed
  PNav.onKey_CB(this, CB_UpStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Stock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_UpStockByFile)));
 }//GEN-LAST:event_CB_UpStockKeyPressed

 private void RB_UpStockByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_UpStockByFileKeyPressed
  PNav.onKey_RB(this, RB_UpStockByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockUnitByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_UpStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_UpStockFile)));
 }//GEN-LAST:event_RB_UpStockByFileKeyPressed

 private void TF_UpStockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_UpStockFileKeyPressed
  PNav.onKey_TF(this, TF_UpStockFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockUnitFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_UpStockByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_UpStockByDef)));
 }//GEN-LAST:event_TF_UpStockFileKeyPressed

 private void RB_UpStockByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_UpStockByDefKeyPressed
  PNav.onKey_RB(this, RB_UpStockByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockUnitByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_UpStockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_UpStockDef)));
 }//GEN-LAST:event_RB_UpStockByDefKeyPressed

 private void CmB_UpStockDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_UpStockDefKeyPressed
  PNav.onKey_CmB(this, CmB_UpStockDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_UpStockByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockDef)));
 }//GEN-LAST:event_CmB_UpStockDefKeyPressed

 private void CB_StockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockKeyPressed
  PNav.onKey_CB(this, CB_Stock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_UpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockMin)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockByFile)));
 }//GEN-LAST:event_CB_StockKeyPressed

 private void RB_StockByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockByFileKeyPressed
  PNav.onKey_RB(this, RB_StockByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_UpStockByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockMinByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Stock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockFile)));
 }//GEN-LAST:event_RB_StockByFileKeyPressed

 private void TF_StockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockFileKeyPressed
  PNav.onKey_TF(this, TF_StockFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_UpStockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMinFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockByDef)));
 }//GEN-LAST:event_TF_StockFileKeyPressed

 private void RB_StockByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockByDefKeyPressed
  PNav.onKey_RB(this, RB_StockByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_UpStockByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockMinByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockDef)));
 }//GEN-LAST:event_RB_StockByDefKeyPressed

 private void TF_StockDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockDefKeyPressed
  PNav.onKey_TF(this, TF_StockDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_UpStockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMinDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_StockDefKeyPressed

 private void CB_StockMinKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockMinKeyPressed
  PNav.onKey_CB(this, CB_StockMin, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Stock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_StockMax)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockMinByFile)));
 }//GEN-LAST:event_CB_StockMinKeyPressed

 private void RB_StockMinByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockMinByFileKeyPressed
  PNav.onKey_RB(this, RB_StockMinByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockMaxByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockMin)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMinFile)));
 }//GEN-LAST:event_RB_StockMinByFileKeyPressed

 private void TF_StockMinFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMinFileKeyPressed
  PNav.onKey_TF(this, TF_StockMinFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMaxFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockMinByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockMinByDef)));
 }//GEN-LAST:event_TF_StockMinFileKeyPressed

 private void RB_StockMinByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockMinByDefKeyPressed
  PNav.onKey_RB(this, RB_StockMinByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_StockMaxByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockMinFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMinDef)));
 }//GEN-LAST:event_RB_StockMinByDefKeyPressed

 private void TF_StockMinDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMinDefKeyPressed
  PNav.onKey_TF(this, TF_StockMinDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_StockMaxDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockMinByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_StockMinDefKeyPressed

 private void CB_StockMaxKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_StockMaxKeyPressed
  PNav.onKey_CB(this, CB_StockMax, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockMin)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsOpname)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockMaxByFile)));
 }//GEN-LAST:event_CB_StockMaxKeyPressed

 private void RB_StockMaxByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockMaxByFileKeyPressed
  PNav.onKey_RB(this, RB_StockMaxByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockMinByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsOpnameByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_StockMax)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMaxFile)));
 }//GEN-LAST:event_RB_StockMaxByFileKeyPressed

 private void TF_StockMaxFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMaxFileKeyPressed
  PNav.onKey_TF(this, TF_StockMaxFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockMinFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IsOpnameFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockMaxByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_StockMaxByDef)));
 }//GEN-LAST:event_TF_StockMaxFileKeyPressed

 private void RB_StockMaxByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_StockMaxByDefKeyPressed
  PNav.onKey_RB(this, RB_StockMaxByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockMinByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsOpnameByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_StockMaxFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_StockMaxDef)));
 }//GEN-LAST:event_RB_StockMaxByDefKeyPressed

 private void TF_StockMaxDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockMaxDefKeyPressed
  PNav.onKey_TF(this, TF_StockMaxDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockMinDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_IsOpnameDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_StockMaxByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_StockMaxDefKeyPressed

 private void CB_IsReorderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsReorderKeyPressed
  PNav.onKey_CB(this, CB_IsReorder, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsOpname)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderEachPackQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsReorderByFile)));
 }//GEN-LAST:event_CB_IsReorderKeyPressed

 private void RB_IsReorderByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsReorderByFileKeyPressed
  PNav.onKey_RB(this, RB_IsReorderByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsOpnameByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderEachPackQtyByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsReorder)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IsReorderFile)));
 }//GEN-LAST:event_RB_IsReorderByFileKeyPressed

 private void TF_IsReorderFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IsReorderFileKeyPressed
  PNav.onKey_TF(this, TF_IsReorderFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IsOpnameFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackQtyFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsReorderByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsReorderByDef)));
 }//GEN-LAST:event_TF_IsReorderFileKeyPressed

 private void RB_IsReorderByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsReorderByDefKeyPressed
  PNav.onKey_RB(this, RB_IsReorderByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsOpnameByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderEachPackQtyByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_IsReorderFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsReorderDef)));
 }//GEN-LAST:event_RB_IsReorderByDefKeyPressed

 private void CmB_IsReorderDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IsReorderDefKeyPressed
  PNav.onKey_CmB(this, CmB_IsReorderDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsReorderByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQtyDef)));
 }//GEN-LAST:event_CmB_IsReorderDefKeyPressed

 private void CB_OrderEachPackQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderEachPackQtyKeyPressed
  PNav.onKey_CB(this, CB_OrderEachPackQty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsReorder)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderEachPackThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderEachPackQtyByFile)));
 }//GEN-LAST:event_CB_OrderEachPackQtyKeyPressed

 private void RB_OrderEachPackQtyByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderEachPackQtyByFileKeyPressed
  PNav.onKey_RB(this, RB_OrderEachPackQtyByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsReorderByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderEachPackThresholdByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderEachPackQty)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQtyFile)));
 }//GEN-LAST:event_RB_OrderEachPackQtyByFileKeyPressed

 private void TF_OrderEachPackQtyFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyFileKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackQtyFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_IsReorderFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderEachPackQtyByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderEachPackQtyByDef)));
 }//GEN-LAST:event_TF_OrderEachPackQtyFileKeyPressed

 private void RB_OrderEachPackQtyByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderEachPackQtyByDefKeyPressed
  PNav.onKey_RB(this, RB_OrderEachPackQtyByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_IsReorderByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderEachPackThresholdByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderEachPackQtyFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackQtyDef)));
 }//GEN-LAST:event_RB_OrderEachPackQtyByDefKeyPressed

 private void TF_OrderEachPackQtyDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyDefKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackQtyDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_IsReorderDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackThresholdDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderEachPackQtyByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderEachPackQtyDefKeyPressed

 private void CB_OrderEachPackThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderEachPackThresholdKeyPressed
  PNav.onKey_CB(this, CB_OrderEachPackThreshold, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderEachPackQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderMinPack)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderEachPackThresholdByFile)));
 }//GEN-LAST:event_CB_OrderEachPackThresholdKeyPressed

 private void RB_OrderEachPackThresholdByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderEachPackThresholdByFileKeyPressed
  PNav.onKey_RB(this, RB_OrderEachPackThresholdByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OrderEachPackQtyByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderMinPackByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderEachPackThreshold)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile)));
 }//GEN-LAST:event_RB_OrderEachPackThresholdByFileKeyPressed

 private void TF_OrderEachPackThresholdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdFileKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackThresholdFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackQtyFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderMinPackFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderEachPackThresholdByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderEachPackThresholdByDef)));
 }//GEN-LAST:event_TF_OrderEachPackThresholdFileKeyPressed

 private void RB_OrderEachPackThresholdByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderEachPackThresholdByDefKeyPressed
  PNav.onKey_RB(this, RB_OrderEachPackThresholdByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OrderEachPackQtyByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderMinPackByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderEachPackThresholdDef)));
 }//GEN-LAST:event_RB_OrderEachPackThresholdByDefKeyPressed

 private void TF_OrderEachPackThresholdDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdDefKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackThresholdDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackQtyDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderMinPackDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderEachPackThresholdByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderEachPackThresholdDefKeyPressed

 private void CB_OrderMinPackKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderMinPackKeyPressed
  PNav.onKey_CB(this, CB_OrderMinPack, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderEachPackThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_HasExp)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderMinPackByFile)));
 }//GEN-LAST:event_CB_OrderMinPackKeyPressed

 private void RB_OrderMinPackByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderMinPackByFileKeyPressed
  PNav.onKey_RB(this, RB_OrderMinPackByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OrderEachPackThresholdByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_HasExpByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderMinPack)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderMinPackFile)));
 }//GEN-LAST:event_RB_OrderMinPackByFileKeyPressed

 private void TF_OrderMinPackFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderMinPackFileKeyPressed
  PNav.onKey_TF(this, TF_OrderMinPackFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackThresholdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_HasExpFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderMinPackByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderMinPackByDef)));
 }//GEN-LAST:event_TF_OrderMinPackFileKeyPressed

 private void RB_OrderMinPackByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderMinPackByDefKeyPressed
  PNav.onKey_RB(this, RB_OrderMinPackByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OrderEachPackThresholdByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_HasExpByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderMinPackFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderMinPackDef)));
 }//GEN-LAST:event_RB_OrderMinPackByDefKeyPressed

 private void TF_OrderMinPackDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderMinPackDefKeyPressed
  PNav.onKey_TF(this, TF_OrderMinPackDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackThresholdDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_HasExpDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderMinPackByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderMinPackDefKeyPressed

 private void TF_BasedFileFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BasedFileFieldKeyPressed
  PNav.onKey_TF(this, TF_BasedFileField, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_FilePreview)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Id)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BasedFileFieldKeyPressed

 private void CB_HasExpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_HasExpKeyPressed
  PNav.onKey_CB(this, CB_HasExp, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderMinPack)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ExpCheckPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_HasExpByFile)));
 }//GEN-LAST:event_CB_HasExpKeyPressed

 private void RB_HasExpByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_HasExpByFileKeyPressed
  PNav.onKey_RB(this, RB_HasExpByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OrderMinPackByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ExpCheckPeriodByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_HasExp)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_HasExpFile)));
 }//GEN-LAST:event_RB_HasExpByFileKeyPressed

 private void TF_HasExpFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_HasExpFileKeyPressed
  PNav.onKey_TF(this, TF_HasExpFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderMinPackFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpCheckPeriodFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_HasExpByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_HasExpByDef)));
 }//GEN-LAST:event_TF_HasExpFileKeyPressed

 private void RB_HasExpByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_HasExpByDefKeyPressed
  PNav.onKey_RB(this, RB_HasExpByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OrderMinPackByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ExpCheckPeriodByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_HasExpFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_HasExpDef)));
 }//GEN-LAST:event_RB_HasExpByDefKeyPressed

 private void CmB_HasExpDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_HasExpDefKeyPressed
  PNav.onKey_CmB(this, CmB_HasExpDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_HasExpByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpCheckPeriodDef)));
 }//GEN-LAST:event_CmB_HasExpDefKeyPressed

 private void CB_ExpCheckPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpCheckPeriodKeyPressed
  PNav.onKey_CB(this, CB_ExpCheckPeriod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_HasExp)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ExpThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ExpCheckPeriodByFile)));
 }//GEN-LAST:event_CB_ExpCheckPeriodKeyPressed

 private void RB_ExpCheckPeriodByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ExpCheckPeriodByFileKeyPressed
  PNav.onKey_RB(this, RB_ExpCheckPeriodByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_HasExpByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ExpThresholdByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ExpCheckPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpCheckPeriodFile)));
 }//GEN-LAST:event_RB_ExpCheckPeriodByFileKeyPressed

 private void TF_ExpCheckPeriodFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpCheckPeriodFileKeyPressed
  PNav.onKey_TF(this, TF_ExpCheckPeriodFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_HasExpFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpThresholdFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ExpCheckPeriodByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ExpCheckPeriodByDef)));
 }//GEN-LAST:event_TF_ExpCheckPeriodFileKeyPressed

 private void RB_ExpCheckPeriodByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ExpCheckPeriodByDefKeyPressed
  PNav.onKey_RB(this, RB_ExpCheckPeriodByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_HasExpByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ExpThresholdByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ExpCheckPeriodFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpCheckPeriodDef)));
 }//GEN-LAST:event_RB_ExpCheckPeriodByDefKeyPressed

 private void TF_ExpCheckPeriodDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpCheckPeriodDefKeyPressed
  PNav.onKey_TF(this, TF_ExpCheckPeriodDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_HasExpDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpThresholdDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ExpCheckPeriodByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpCheckPeriodDefKeyPressed

 private void CB_ExpThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpThresholdKeyPressed
  PNav.onKey_CB(this, CB_ExpThreshold, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ExpCheckPeriod)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ExpThresholdByFile)));
 }//GEN-LAST:event_CB_ExpThresholdKeyPressed

 private void RB_ExpThresholdByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ExpThresholdByFileKeyPressed
  PNav.onKey_RB(this, RB_ExpThresholdByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ExpCheckPeriodByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_SellPriceByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ExpThreshold)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpThresholdFile)));
 }//GEN-LAST:event_RB_ExpThresholdByFileKeyPressed

 private void TF_ExpThresholdFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpThresholdFileKeyPressed
  PNav.onKey_TF(this, TF_ExpThresholdFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpCheckPeriodFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellPriceFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ExpThresholdByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ExpThresholdByDef)));
 }//GEN-LAST:event_TF_ExpThresholdFileKeyPressed

 private void RB_ExpThresholdByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ExpThresholdByDefKeyPressed
  PNav.onKey_RB(this, RB_ExpThresholdByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ExpCheckPeriodByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_SellPriceByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ExpThresholdFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ExpThresholdDef)));
 }//GEN-LAST:event_RB_ExpThresholdByDefKeyPressed

 private void TF_ExpThresholdDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpThresholdDefKeyPressed
  PNav.onKey_TF(this, TF_ExpThresholdDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpCheckPeriodDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellPriceDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ExpThresholdByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpThresholdDefKeyPressed

 private void CB_SellPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellPriceKeyPressed
  PNav.onKey_CB(this, CB_SellPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ExpThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_SellPriceByFile)));
 }//GEN-LAST:event_CB_SellPriceKeyPressed

 private void RB_SellPriceByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_SellPriceByFileKeyPressed
  PNav.onKey_RB(this, RB_SellPriceByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ExpThresholdByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_SellUpdateByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellPrice)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellPriceFile)));
 }//GEN-LAST:event_RB_SellPriceByFileKeyPressed

 private void TF_SellPriceFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellPriceFileKeyPressed
  PNav.onKey_TF(this, TF_SellPriceFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpThresholdFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellUpdateFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_SellPriceByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_SellPriceByDef)));
 }//GEN-LAST:event_TF_SellPriceFileKeyPressed

 private void RB_SellPriceByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_SellPriceByDefKeyPressed
  PNav.onKey_RB(this, RB_SellPriceByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ExpThresholdByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_SellUpdateByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellPriceFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellPriceDef)));
 }//GEN-LAST:event_RB_SellPriceByDefKeyPressed

 private void TF_SellPriceDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellPriceDefKeyPressed
  PNav.onKey_TF(this, TF_SellPriceDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpThresholdDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_SellPriceByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_SellPriceDefKeyPressed

 private void CB_SellUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateKeyPressed
  PNav.onKey_CB(this, CB_SellUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellPrice)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_SellUpdateByFile)));
 }//GEN-LAST:event_CB_SellUpdateKeyPressed

 private void RB_SellUpdateByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_SellUpdateByFileKeyPressed
  PNav.onKey_RB(this, RB_SellUpdateByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_SellPriceByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_SellCommentByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellUpdateFile)));
 }//GEN-LAST:event_RB_SellUpdateByFileKeyPressed

 private void TF_SellUpdateFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellUpdateFileKeyPressed
  PNav.onKey_TF(this, TF_SellUpdateFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellPriceFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_SellCommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_SellUpdateByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_SellUpdateByDef)));
 }//GEN-LAST:event_TF_SellUpdateFileKeyPressed

 private void RB_SellUpdateByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_SellUpdateByDefKeyPressed
  PNav.onKey_RB(this, RB_SellUpdateByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_SellPriceByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_SellCommentByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellUpdateFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)));
 }//GEN-LAST:event_RB_SellUpdateByDefKeyPressed

 private void CB_SellUpdateDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_SellUpdateDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellPriceDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_SellUpdateByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellUpdateDefY)));
 }//GEN-LAST:event_CB_SellUpdateDefIsSetKeyPressed

 private void TF_SellUpdateDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellUpdateDefYKeyPressed
  PNav.onKey_TF(this, TF_SellUpdateDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellPriceDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateDefM)));
 }//GEN-LAST:event_TF_SellUpdateDefYKeyPressed

 private void CmB_SellUpdateDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateDefMKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellUpdateDefY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateDefD)));
 }//GEN-LAST:event_CmB_SellUpdateDefMKeyPressed

 private void CmB_SellUpdateDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateDefDKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SellUpdateDefM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_SellCommentDef)));
 }//GEN-LAST:event_CmB_SellUpdateDefDKeyPressed

 private void CB_SellCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellCommentKeyPressed
  PNav.onKey_CB(this, CB_SellComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyPriceEst)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_SellCommentByFile)));
 }//GEN-LAST:event_CB_SellCommentKeyPressed

 private void RB_SellCommentByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_SellCommentByFileKeyPressed
  PNav.onKey_RB(this, RB_SellCommentByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_SellUpdateByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_BuyPriceEstByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellCommentFile)));
 }//GEN-LAST:event_RB_SellCommentByFileKeyPressed

 private void TF_SellCommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellCommentFileKeyPressed
  PNav.onKey_TF(this, TF_SellCommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellUpdateFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceEstFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_SellCommentByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_SellCommentByDef)));
 }//GEN-LAST:event_TF_SellCommentFileKeyPressed

 private void RB_SellCommentByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_SellCommentByDefKeyPressed
  PNav.onKey_RB(this, RB_SellCommentByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_SellUpdateByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_BuyPriceEstByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellCommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_SellCommentDef)));
 }//GEN-LAST:event_RB_SellCommentByDefKeyPressed

 private void TA_SellCommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_SellCommentDefKeyPressed
  PNav.onKey_TA(this, TA_SellCommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdateDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceEstDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_SellCommentByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_SellCommentDefKeyPressed

 private void CB_BuyPriceEstKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyPriceEstKeyPressed
  PNav.onKey_CB(this, CB_BuyPriceEst, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_BuyPriceEstByFile)));
 }//GEN-LAST:event_CB_BuyPriceEstKeyPressed

 private void RB_BuyPriceEstByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_BuyPriceEstByFileKeyPressed
  PNav.onKey_RB(this, RB_BuyPriceEstByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_SellCommentByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_BuyUpdateByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyPriceEst)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPriceEstFile)));
 }//GEN-LAST:event_RB_BuyPriceEstByFileKeyPressed

 private void TF_BuyPriceEstFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstFileKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceEstFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_SellCommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyUpdateFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_BuyPriceEstByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_BuyPriceEstByDef)));
 }//GEN-LAST:event_TF_BuyPriceEstFileKeyPressed

 private void RB_BuyPriceEstByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_BuyPriceEstByDefKeyPressed
  PNav.onKey_RB(this, RB_BuyPriceEstByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_SellCommentByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_BuyUpdateByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyPriceEstFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPriceEstDef)));
 }//GEN-LAST:event_RB_BuyPriceEstByDefKeyPressed

 private void TF_BuyPriceEstDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstDefKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceEstDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_SellCommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_BuyPriceEstByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPriceEstDefKeyPressed

 private void CB_BuyUpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_BuyUpdateByFile)));
 }//GEN-LAST:event_CB_BuyUpdateKeyPressed

 private void RB_BuyUpdateByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_BuyUpdateByFileKeyPressed
  PNav.onKey_RB(this, RB_BuyUpdateByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_BuyPriceEstByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_BuyCommentByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateFile)));
 }//GEN-LAST:event_RB_BuyUpdateByFileKeyPressed

 private void TF_BuyUpdateFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateFileKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEstFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyCommentFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_BuyUpdateByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_BuyUpdateByDef)));
 }//GEN-LAST:event_TF_BuyUpdateFileKeyPressed

 private void RB_BuyUpdateByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_BuyUpdateByDefKeyPressed
  PNav.onKey_RB(this, RB_BuyUpdateByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_BuyPriceEstByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_BuyCommentByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)));
 }//GEN-LAST:event_RB_BuyUpdateByDefKeyPressed

 private void CB_BuyUpdateDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdateDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEstDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_BuyUpdateByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateDefY)));
 }//GEN-LAST:event_CB_BuyUpdateDefIsSetKeyPressed

 private void TF_BuyUpdateDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateDefYKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEstDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyCommentDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateDefM)));
 }//GEN-LAST:event_TF_BuyUpdateDefYKeyPressed

 private void CmB_BuyUpdateDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDefMKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateDefY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateDefD)));
 }//GEN-LAST:event_CmB_BuyUpdateDefMKeyPressed

 private void CmB_BuyUpdateDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDefDKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateDefM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_BuyCommentDef)));
 }//GEN-LAST:event_CmB_BuyUpdateDefDKeyPressed

 private void CB_BuyCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyCommentKeyPressed
  PNav.onKey_CB(this, CB_BuyComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_BuyCommentByFile)));
 }//GEN-LAST:event_CB_BuyCommentKeyPressed

 private void RB_BuyCommentByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_BuyCommentByFileKeyPressed
  PNav.onKey_RB(this, RB_BuyCommentByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_BuyUpdateByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OpStockByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyCommentFile)));
 }//GEN-LAST:event_RB_BuyCommentByFileKeyPressed

 private void TF_BuyCommentFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyCommentFileKeyPressed
  PNav.onKey_TF(this, TF_BuyCommentFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyUpdateFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpStockFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_BuyCommentByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_BuyCommentByDef)));
 }//GEN-LAST:event_TF_BuyCommentFileKeyPressed

 private void RB_BuyCommentByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_BuyCommentByDefKeyPressed
  PNav.onKey_RB(this, RB_BuyCommentByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_BuyUpdateByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OpStockByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyCommentFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TA_BuyCommentDef)));
 }//GEN-LAST:event_RB_BuyCommentByDefKeyPressed

 private void TA_BuyCommentDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyCommentDefKeyPressed
  PNav.onKey_TA(this, TA_BuyCommentDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpStockDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_BuyCommentByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyCommentDefKeyPressed

 private void CB_OpStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpStockKeyPressed
  PNav.onKey_CB(this, CB_OpStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExp)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OpStockByFile)));
 }//GEN-LAST:event_CB_OpStockKeyPressed

 private void RB_OpStockByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OpStockByFileKeyPressed
  PNav.onKey_RB(this, RB_OpStockByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_BuyCommentByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OpExpByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpStock)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpStockFile)));
 }//GEN-LAST:event_RB_OpStockByFileKeyPressed

 private void TF_OpStockFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpStockFileKeyPressed
  PNav.onKey_TF(this, TF_OpStockFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyCommentFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpExpFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OpStockByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OpStockByDef)));
 }//GEN-LAST:event_TF_OpStockFileKeyPressed

 private void RB_OpStockByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OpStockByDefKeyPressed
  PNav.onKey_RB(this, RB_OpStockByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_BuyCommentByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OpExpByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpStockFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpStockDef)));
 }//GEN-LAST:event_RB_OpStockByDefKeyPressed

 private void TF_OpStockDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpStockDefKeyPressed
  PNav.onKey_TF(this, TF_OpStockDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyCommentDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExpDefIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OpStockByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OpStockDefKeyPressed

 private void CB_OpExpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpKeyPressed
  PNav.onKey_CB(this, CB_OpExp, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OrderQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OpExpByFile)));
 }//GEN-LAST:event_CB_OpExpKeyPressed

 private void RB_OpExpByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OpExpByFileKeyPressed
  PNav.onKey_RB(this, RB_OpExpByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OpStockByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderQtyByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExp)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpExpFile)));
 }//GEN-LAST:event_RB_OpExpByFileKeyPressed

 private void TF_OpExpFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpExpFileKeyPressed
  PNav.onKey_TF(this, TF_OpExpFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStockFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQtyFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OpExpByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OpExpByDef)));
 }//GEN-LAST:event_TF_OpExpFileKeyPressed

 private void RB_OpExpByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OpExpByDefKeyPressed
  PNav.onKey_RB(this, RB_OpExpByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OpStockByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_OrderQtyByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpExpFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_OpExpDefIsSet)));
 }//GEN-LAST:event_RB_OpExpByDefKeyPressed

 private void CB_OpExpDefIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpDefIsSetKeyPressed
  PNav.onKey_CB(this, CB_OpExpDefIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQtyDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OpExpByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpExpDefY)));
 }//GEN-LAST:event_CB_OpExpDefIsSetKeyPressed

 private void TF_OpExpDefYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpExpDefYKeyPressed
  PNav.onKey_TF(this, TF_OpExpDefY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStockDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQtyDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExpDefIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpDefM)));
 }//GEN-LAST:event_TF_OpExpDefYKeyPressed

 private void CmB_OpExpDefMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpDefMKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpDefM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpExpDefY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpDefD)));
 }//GEN-LAST:event_CmB_OpExpDefMKeyPressed

 private void CmB_OpExpDefDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpDefDKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpDefD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_OpExpDefM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQtyDef)));
 }//GEN-LAST:event_CmB_OpExpDefDKeyPressed

 private void CB_OrderQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OrderQtyKeyPressed
  PNav.onKey_CB(this, CB_OrderQty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExp)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderQtyByFile)));
 }//GEN-LAST:event_CB_OrderQtyKeyPressed

 private void RB_OrderQtyByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderQtyByFileKeyPressed
  PNav.onKey_RB(this, RB_OrderQtyByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OpExpByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OrderQty)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQtyFile)));
 }//GEN-LAST:event_RB_OrderQtyByFileKeyPressed

 private void TF_OrderQtyFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderQtyFileKeyPressed
  PNav.onKey_TF(this, TF_OrderQtyFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpExpFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderQtyByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_OrderQtyByDef)));
 }//GEN-LAST:event_TF_OrderQtyFileKeyPressed

 private void RB_OrderQtyByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_OrderQtyByDefKeyPressed
  PNav.onKey_RB(this, RB_OrderQtyByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_OpExpByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OrderQtyFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQtyDef)));
 }//GEN-LAST:event_RB_OrderQtyByDefKeyPressed

 private void TF_OrderQtyDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderQtyDefKeyPressed
  PNav.onKey_TF(this, TF_OrderQtyDef, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExpDefIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_OrderQtyByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderQtyDefKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OrderQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void Tbl_FilePreviewKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_FilePreviewKeyReleased
  PNav.onKey_Tbl(this, Tbl_FilePreview, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BasedFileField)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Tbl_FilePreviewKeyReleased

 private void CB_IsOpnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsOpnameKeyPressed
  PNav.onKey_CB(this, CB_IsOpname, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_StockMax)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsReorder)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsOpnameByFile)));
 }//GEN-LAST:event_CB_IsOpnameKeyPressed

 private void RB_IsOpnameByFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsOpnameByFileKeyPressed
  PNav.onKey_RB(this, RB_IsOpnameByFile, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockMaxByFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsReorderByFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_IsOpname)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_IsOpnameFile)));
 }//GEN-LAST:event_RB_IsOpnameByFileKeyPressed

 private void TF_IsOpnameFileKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IsOpnameFileKeyPressed
  PNav.onKey_TF(this, TF_IsOpnameFile, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_StockMaxFile)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_IsReorderFile)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsOpnameByFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_IsOpnameByDef)));
 }//GEN-LAST:event_TF_IsOpnameFileKeyPressed

 private void RB_IsOpnameByDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_IsOpnameByDefKeyPressed
  PNav.onKey_RB(this, RB_IsOpnameByDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_StockMaxByDef)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_IsReorderByDef)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_IsOpnameFile)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsOpnameDef)));
 }//GEN-LAST:event_RB_IsOpnameByDefKeyPressed

 private void CmB_IsOpnameDefKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_IsOpnameDefKeyPressed
  PNav.onKey_CmB(this, CmB_IsOpnameDef, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_IsOpnameByDef)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_IsReorderDef)));
 }//GEN-LAST:event_CmB_IsOpnameDefKeyPressed

 private void TF_BasedFileFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BasedFileFieldFocusGained
  PGUI.text_SelectAll(TF_BasedFileField);
 }//GEN-LAST:event_TF_BasedFileFieldFocusGained

 private void TF_IdFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_IdFileFocusGained
  PGUI.text_SelectAll(TF_IdFile);
 }//GEN-LAST:event_TF_IdFileFocusGained

 private void TF_NameFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_NameFileFocusGained
  PGUI.text_SelectAll(TF_NameFile);
 }//GEN-LAST:event_TF_NameFileFocusGained

 private void TF_IsActiveFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_IsActiveFileFocusGained
  PGUI.text_SelectAll(TF_IsActiveFile);
 }//GEN-LAST:event_TF_IsActiveFileFocusGained

 private void TF_CommentFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_CommentFileFocusGained
  PGUI.text_SelectAll(TF_CommentFile);
 }//GEN-LAST:event_TF_CommentFileFocusGained

 private void TF_StockUnitFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockUnitFileFocusGained
  PGUI.text_SelectAll(TF_StockUnitFile);
 }//GEN-LAST:event_TF_StockUnitFileFocusGained

 private void TF_UpStockFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_UpStockFileFocusGained
  PGUI.text_SelectAll(TF_UpStockFile);
 }//GEN-LAST:event_TF_UpStockFileFocusGained

 private void TF_StockFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockFileFocusGained
  PGUI.text_SelectAll(TF_StockFile);
 }//GEN-LAST:event_TF_StockFileFocusGained

 private void TF_StockMinFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockMinFileFocusGained
  PGUI.text_SelectAll(TF_StockMinFile);
 }//GEN-LAST:event_TF_StockMinFileFocusGained

 private void TF_StockMaxFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockMaxFileFocusGained
  PGUI.text_SelectAll(TF_StockMaxFile);
 }//GEN-LAST:event_TF_StockMaxFileFocusGained

 private void TF_IsOpnameFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_IsOpnameFileFocusGained
  PGUI.text_SelectAll(TF_IsOpnameFile);
 }//GEN-LAST:event_TF_IsOpnameFileFocusGained

 private void TF_IsReorderFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_IsReorderFileFocusGained
  PGUI.text_SelectAll(TF_IsReorderFile);
 }//GEN-LAST:event_TF_IsReorderFileFocusGained

 private void TF_OrderEachPackQtyFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyFileFocusGained
  PGUI.text_SelectAll(TF_OrderEachPackQtyFile);
 }//GEN-LAST:event_TF_OrderEachPackQtyFileFocusGained

 private void TF_OrderEachPackThresholdFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdFileFocusGained
  PGUI.text_SelectAll(TF_OrderEachPackThresholdFile);
 }//GEN-LAST:event_TF_OrderEachPackThresholdFileFocusGained

 private void TF_OrderMinPackFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderMinPackFileFocusGained
  PGUI.text_SelectAll(TF_OrderMinPackFile);
 }//GEN-LAST:event_TF_OrderMinPackFileFocusGained

 private void TF_HasExpFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_HasExpFileFocusGained
  PGUI.text_SelectAll(TF_HasExpFile);
 }//GEN-LAST:event_TF_HasExpFileFocusGained

 private void TF_ExpCheckPeriodFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ExpCheckPeriodFileFocusGained
  PGUI.text_SelectAll(TF_ExpCheckPeriodFile);
 }//GEN-LAST:event_TF_ExpCheckPeriodFileFocusGained

 private void TF_ExpThresholdFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ExpThresholdFileFocusGained
  PGUI.text_SelectAll(TF_ExpThresholdFile);
 }//GEN-LAST:event_TF_ExpThresholdFileFocusGained

 private void TF_SellPriceFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellPriceFileFocusGained
  PGUI.text_SelectAll(TF_SellPriceFile);
 }//GEN-LAST:event_TF_SellPriceFileFocusGained

 private void TF_SellUpdateFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellUpdateFileFocusGained
  PGUI.text_SelectAll(TF_SellUpdateFile);
 }//GEN-LAST:event_TF_SellUpdateFileFocusGained

 private void TF_SellCommentFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellCommentFileFocusGained
  PGUI.text_SelectAll(TF_SellCommentFile);
 }//GEN-LAST:event_TF_SellCommentFileFocusGained

 private void TF_BuyPriceEstFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstFileFocusGained
  PGUI.text_SelectAll(TF_BuyPriceEstFile);
 }//GEN-LAST:event_TF_BuyPriceEstFileFocusGained

 private void TF_BuyUpdateFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyUpdateFileFocusGained
  PGUI.text_SelectAll(TF_BuyUpdateFile);
 }//GEN-LAST:event_TF_BuyUpdateFileFocusGained

 private void TF_BuyCommentFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyCommentFileFocusGained
  PGUI.text_SelectAll(TF_BuyCommentFile);
 }//GEN-LAST:event_TF_BuyCommentFileFocusGained

 private void TF_OpStockFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OpStockFileFocusGained
  PGUI.text_SelectAll(TF_OpStockFile);
 }//GEN-LAST:event_TF_OpStockFileFocusGained

 private void TF_OpExpFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OpExpFileFocusGained
  PGUI.text_SelectAll(TF_OpExpFile);
 }//GEN-LAST:event_TF_OpExpFileFocusGained

 private void TF_OrderQtyFileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderQtyFileFocusGained
  PGUI.text_SelectAll(TF_OrderQtyFile);
 }//GEN-LAST:event_TF_OrderQtyFileFocusGained

 private void TF_StockDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockDefFocusGained
  PGUI.text_SelectAll(TF_StockDef);
 }//GEN-LAST:event_TF_StockDefFocusGained

 private void TF_StockMinDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockMinDefFocusGained
  PGUI.text_SelectAll(TF_StockMinDef);
 }//GEN-LAST:event_TF_StockMinDefFocusGained

 private void TF_StockMaxDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockMaxDefFocusGained
  PGUI.text_SelectAll(TF_StockMaxDef);
 }//GEN-LAST:event_TF_StockMaxDefFocusGained

 private void TF_OrderEachPackQtyDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyDefFocusGained
  PGUI.text_SelectAll(TF_OrderEachPackQtyDef);
 }//GEN-LAST:event_TF_OrderEachPackQtyDefFocusGained

 private void TF_OrderEachPackThresholdDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdDefFocusGained
  PGUI.text_SelectAll(TF_OrderEachPackThresholdDef);
 }//GEN-LAST:event_TF_OrderEachPackThresholdDefFocusGained

 private void TF_OrderMinPackDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderMinPackDefFocusGained
  PGUI.text_SelectAll(TF_OrderMinPackDef);
 }//GEN-LAST:event_TF_OrderMinPackDefFocusGained

 private void TF_ExpCheckPeriodDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ExpCheckPeriodDefFocusGained
  PGUI.text_SelectAll(TF_ExpCheckPeriodDef);
 }//GEN-LAST:event_TF_ExpCheckPeriodDefFocusGained

 private void TF_ExpThresholdDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ExpThresholdDefFocusGained
  PGUI.text_SelectAll(TF_ExpThresholdDef);
 }//GEN-LAST:event_TF_ExpThresholdDefFocusGained

 private void TF_SellPriceDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellPriceDefFocusGained
  PGUI.text_SelectAll(TF_SellPriceDef);
 }//GEN-LAST:event_TF_SellPriceDefFocusGained

 private void TF_SellUpdateDefYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellUpdateDefYFocusGained
  PGUI.text_SelectAll(TF_SellUpdateDefY);
 }//GEN-LAST:event_TF_SellUpdateDefYFocusGained

 private void TA_SellCommentDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_SellCommentDefFocusGained
  PGUI.text_SelectAll(TA_SellCommentDef);
 }//GEN-LAST:event_TA_SellCommentDefFocusGained

 private void TF_BuyPriceEstDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstDefFocusGained
  PGUI.text_SelectAll(TF_BuyPriceEstDef);
 }//GEN-LAST:event_TF_BuyPriceEstDefFocusGained

 private void TF_BuyUpdateDefYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyUpdateDefYFocusGained
  PGUI.text_SelectAll(TF_BuyUpdateDefY);
 }//GEN-LAST:event_TF_BuyUpdateDefYFocusGained

 private void TA_BuyCommentDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_BuyCommentDefFocusGained
  PGUI.text_SelectAll(TA_BuyCommentDef);
 }//GEN-LAST:event_TA_BuyCommentDefFocusGained

 private void TF_OpStockDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OpStockDefFocusGained
  PGUI.text_SelectAll(TF_OpStockDef);
 }//GEN-LAST:event_TF_OpStockDefFocusGained

 private void TF_OpExpDefYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OpExpDefYFocusGained
  PGUI.text_SelectAll(TF_OpExpDefY);
 }//GEN-LAST:event_TF_OpExpDefYFocusGained

 private void TF_OrderQtyDefFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderQtyDefFocusGained
  PGUI.text_SelectAll(TF_OrderQtyDef);
 }//GEN-LAST:event_TF_OrderQtyDefFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseFile;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_StockUnitDefChoose;
 private javax.swing.JButton Btn_StockUnitDefClear;
 private javax.swing.JCheckBox CB_BuyComment;
 private javax.swing.JCheckBox CB_BuyPriceEst;
 private javax.swing.JCheckBox CB_BuyUpdate;
 private javax.swing.JCheckBox CB_BuyUpdateDefIsSet;
 private javax.swing.JCheckBox CB_Comment;
 private javax.swing.JCheckBox CB_ExpCheckPeriod;
 private javax.swing.JCheckBox CB_ExpThreshold;
 private javax.swing.JCheckBox CB_HasExp;
 private javax.swing.JCheckBox CB_Id;
 private javax.swing.JCheckBox CB_IsActive;
 private javax.swing.JCheckBox CB_IsOpname;
 private javax.swing.JCheckBox CB_IsReorder;
 private javax.swing.JCheckBox CB_Name;
 private javax.swing.JCheckBox CB_OpExp;
 private javax.swing.JCheckBox CB_OpExpDefIsSet;
 private javax.swing.JCheckBox CB_OpStock;
 private javax.swing.JCheckBox CB_OrderEachPackQty;
 private javax.swing.JCheckBox CB_OrderEachPackThreshold;
 private javax.swing.JCheckBox CB_OrderMinPack;
 private javax.swing.JCheckBox CB_OrderQty;
 private javax.swing.JCheckBox CB_SellComment;
 private javax.swing.JCheckBox CB_SellPrice;
 private javax.swing.JCheckBox CB_SellUpdate;
 private javax.swing.JCheckBox CB_SellUpdateDefIsSet;
 private javax.swing.JCheckBox CB_Stock;
 private javax.swing.JCheckBox CB_StockMax;
 private javax.swing.JCheckBox CB_StockMin;
 private javax.swing.JCheckBox CB_StockUnit;
 private javax.swing.JCheckBox CB_UpStock;
 private javax.swing.JComboBox<String> CmB_BuyUpdateDefD;
 private javax.swing.JComboBox<String> CmB_BuyUpdateDefM;
 private javax.swing.JComboBox<String> CmB_HasExpDef;
 private javax.swing.JComboBox<String> CmB_IsActiveDef;
 private javax.swing.JComboBox<String> CmB_IsOpnameDef;
 private javax.swing.JComboBox<String> CmB_IsReorderDef;
 private javax.swing.JComboBox<String> CmB_OpExpDefD;
 private javax.swing.JComboBox<String> CmB_OpExpDefM;
 private javax.swing.JComboBox<String> CmB_SellUpdateDefD;
 private javax.swing.JComboBox<String> CmB_SellUpdateDefM;
 private javax.swing.JComboBox<String> CmB_UpStockDef;
 private javax.swing.JLabel Lbl_BasedAttributeFileFieldHelp;
 private javax.swing.JLabel Lbl_BasedFileField;
 private javax.swing.JLabel Lbl_BuyCommentDefHelp;
 private javax.swing.JLabel Lbl_BuyPriceEstDefHelp;
 private javax.swing.JLabel Lbl_CommentDefHelp;
 private javax.swing.JLabel Lbl_ExpCheckPeriodDef;
 private javax.swing.JLabel Lbl_ExpThresholdDefHelp;
 private javax.swing.JLabel Lbl_File;
 private javax.swing.JLabel Lbl_FileField1;
 private javax.swing.JLabel Lbl_FileField2;
 private javax.swing.JLabel Lbl_FileHelp;
 private javax.swing.JLabel Lbl_ImportInfo;
 private javax.swing.JLabel Lbl_OpStockDefHelp;
 private javax.swing.JLabel Lbl_OrderEachPackQtyDef;
 private javax.swing.JLabel Lbl_OrderEachPackThresholdHelp;
 private javax.swing.JLabel Lbl_OrderMinPackHelp;
 private javax.swing.JLabel Lbl_OrderQtyDefHelp;
 private javax.swing.JLabel Lbl_SellCommentDefHelp;
 private javax.swing.JLabel Lbl_SellPriceDefHelp;
 private javax.swing.JLabel Lbl_StockDefHelp;
 private javax.swing.JLabel Lbl_StockMaxHelp;
 private javax.swing.JLabel Lbl_StockMinDefHelp;
 private javax.swing.JRadioButton RB_BuyCommentByDef;
 private javax.swing.JRadioButton RB_BuyCommentByFile;
 private javax.swing.JRadioButton RB_BuyPriceEstByDef;
 private javax.swing.JRadioButton RB_BuyPriceEstByFile;
 private javax.swing.JRadioButton RB_BuyUpdateByDef;
 private javax.swing.JRadioButton RB_BuyUpdateByFile;
 private javax.swing.JRadioButton RB_CommentByDef;
 private javax.swing.JRadioButton RB_CommentByFile;
 private javax.swing.JRadioButton RB_ExpCheckPeriodByDef;
 private javax.swing.JRadioButton RB_ExpCheckPeriodByFile;
 private javax.swing.JRadioButton RB_ExpThresholdByDef;
 private javax.swing.JRadioButton RB_ExpThresholdByFile;
 private javax.swing.JRadioButton RB_HasExpByDef;
 private javax.swing.JRadioButton RB_HasExpByFile;
 private javax.swing.JRadioButton RB_IsActiveByDef;
 private javax.swing.JRadioButton RB_IsActiveByFile;
 private javax.swing.JRadioButton RB_IsOpnameByDef;
 private javax.swing.JRadioButton RB_IsOpnameByFile;
 private javax.swing.JRadioButton RB_IsReorderByDef;
 private javax.swing.JRadioButton RB_IsReorderByFile;
 private javax.swing.JRadioButton RB_OpExpByDef;
 private javax.swing.JRadioButton RB_OpExpByFile;
 private javax.swing.JRadioButton RB_OpStockByDef;
 private javax.swing.JRadioButton RB_OpStockByFile;
 private javax.swing.JRadioButton RB_OrderEachPackQtyByDef;
 private javax.swing.JRadioButton RB_OrderEachPackQtyByFile;
 private javax.swing.JRadioButton RB_OrderEachPackThresholdByDef;
 private javax.swing.JRadioButton RB_OrderEachPackThresholdByFile;
 private javax.swing.JRadioButton RB_OrderMinPackByDef;
 private javax.swing.JRadioButton RB_OrderMinPackByFile;
 private javax.swing.JRadioButton RB_OrderQtyByDef;
 private javax.swing.JRadioButton RB_OrderQtyByFile;
 private javax.swing.JRadioButton RB_SellCommentByDef;
 private javax.swing.JRadioButton RB_SellCommentByFile;
 private javax.swing.JRadioButton RB_SellPriceByDef;
 private javax.swing.JRadioButton RB_SellPriceByFile;
 private javax.swing.JRadioButton RB_SellUpdateByDef;
 private javax.swing.JRadioButton RB_SellUpdateByFile;
 private javax.swing.JRadioButton RB_StockByDef;
 private javax.swing.JRadioButton RB_StockByFile;
 private javax.swing.JRadioButton RB_StockMaxByDef;
 private javax.swing.JRadioButton RB_StockMaxByFile;
 private javax.swing.JRadioButton RB_StockMinByDef;
 private javax.swing.JRadioButton RB_StockMinByFile;
 private javax.swing.JRadioButton RB_StockUnitByDef;
 private javax.swing.JRadioButton RB_StockUnitByFile;
 private javax.swing.JRadioButton RB_UpStockByDef;
 private javax.swing.JRadioButton RB_UpStockByFile;
 private javax.swing.ButtonGroup RG_BuyComment;
 private javax.swing.ButtonGroup RG_BuyPriceEst;
 private javax.swing.ButtonGroup RG_BuyUpdate;
 private javax.swing.ButtonGroup RG_Comment;
 private javax.swing.ButtonGroup RG_ExpCheckPeriod;
 private javax.swing.ButtonGroup RG_ExpThreshold;
 private javax.swing.ButtonGroup RG_HasExp;
 private javax.swing.ButtonGroup RG_IsActive;
 private javax.swing.ButtonGroup RG_IsOpname;
 private javax.swing.ButtonGroup RG_IsReorder;
 private javax.swing.ButtonGroup RG_MisStock;
 private javax.swing.ButtonGroup RG_OpExp;
 private javax.swing.ButtonGroup RG_OpStock;
 private javax.swing.ButtonGroup RG_OrderEachPackQty;
 private javax.swing.ButtonGroup RG_OrderEachPackThreshold;
 private javax.swing.ButtonGroup RG_OrderMinPack;
 private javax.swing.ButtonGroup RG_OrderQty;
 private javax.swing.ButtonGroup RG_SellComment;
 private javax.swing.ButtonGroup RG_SellPrice;
 private javax.swing.ButtonGroup RG_SellUpdate;
 private javax.swing.ButtonGroup RG_Stock;
 private javax.swing.ButtonGroup RG_StockMax;
 private javax.swing.ButtonGroup RG_StockMin;
 private javax.swing.ButtonGroup RG_StockUnit;
 private javax.swing.ButtonGroup RG_UpStock;
 private javax.swing.JTextArea TA_BuyCommentDef;
 private javax.swing.JTextArea TA_CommentDef;
 private javax.swing.JTextArea TA_SellCommentDef;
 private javax.swing.JTextField TF_BasedFileField;
 private javax.swing.JTextField TF_BuyCommentFile;
 private javax.swing.JTextField TF_BuyPriceEstDef;
 private javax.swing.JTextField TF_BuyPriceEstFile;
 private javax.swing.JTextField TF_BuyUpdateDefY;
 private javax.swing.JTextField TF_BuyUpdateFile;
 private javax.swing.JTextField TF_CommentFile;
 private javax.swing.JTextField TF_ExpCheckPeriodDef;
 private javax.swing.JTextField TF_ExpCheckPeriodFile;
 private javax.swing.JTextField TF_ExpThresholdDef;
 private javax.swing.JTextField TF_ExpThresholdFile;
 private javax.swing.JTextField TF_File;
 private javax.swing.JTextField TF_FileInfo;
 private javax.swing.JTextField TF_HasExpFile;
 private javax.swing.JTextField TF_IdFile;
 private javax.swing.JTextField TF_IsActiveFile;
 private javax.swing.JTextField TF_IsOpnameFile;
 private javax.swing.JTextField TF_IsReorderFile;
 private javax.swing.JTextField TF_NameFile;
 private javax.swing.JTextField TF_OpExpDefY;
 private javax.swing.JTextField TF_OpExpFile;
 private javax.swing.JTextField TF_OpStockDef;
 private javax.swing.JTextField TF_OpStockFile;
 private javax.swing.JTextField TF_OrderEachPackQtyDef;
 private javax.swing.JTextField TF_OrderEachPackQtyFile;
 private javax.swing.JTextField TF_OrderEachPackThresholdDef;
 private javax.swing.JTextField TF_OrderEachPackThresholdFile;
 private javax.swing.JTextField TF_OrderMinPackDef;
 private javax.swing.JTextField TF_OrderMinPackFile;
 private javax.swing.JTextField TF_OrderQtyDef;
 private javax.swing.JTextField TF_OrderQtyFile;
 private javax.swing.JTextField TF_SellCommentFile;
 private javax.swing.JTextField TF_SellPriceDef;
 private javax.swing.JTextField TF_SellPriceFile;
 private javax.swing.JTextField TF_SellUpdateDefY;
 private javax.swing.JTextField TF_SellUpdateFile;
 private javax.swing.JTextField TF_StockDef;
 private javax.swing.JTextField TF_StockFile;
 private javax.swing.JTextField TF_StockMaxDef;
 private javax.swing.JTextField TF_StockMaxFile;
 private javax.swing.JTextField TF_StockMinDef;
 private javax.swing.JTextField TF_StockMinFile;
 private javax.swing.JTextField TF_StockUnitDef;
 private javax.swing.JTextField TF_StockUnitFile;
 private javax.swing.JTextField TF_UpStockFile;
 private XTable Tbl_FilePreview;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel21;
 private javax.swing.JLabel jLabel23;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JSeparator jSeparator1;
 // End of variables declaration//GEN-END:variables
}
