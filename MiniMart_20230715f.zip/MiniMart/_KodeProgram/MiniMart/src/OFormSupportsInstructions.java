import java.sql.Statement;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public interface OFormSupportsInstructions {
 public Statement getStatement();
 public OParam getParameters();
 
 public JCheckBox getTableResultSign();
 public JTable getTable();
 public JTextField getTableCount();
 public JComboBox getTableIdColumn();
 
 public JCheckBox getTextResultSign();
 public JTextArea getText();
}