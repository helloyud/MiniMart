import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_ItemUnitModify extends XFormDialog {
 
 // set
 int wMode; // 1 Add, 2 Edit
 OInfoItemStockUnit wInfoUnit;
 
 // get
 OInfoItemStockUnit InfoUnit;
 
 //
 OCustomComboBoxModel ComboMdlUnit;
 int LastSelectedRowUnit;
 boolean UnitCleared;
 
 // Qty
 double Qty;
 
 // Sell
 double SellPriceEach;
 double SellPrice;
 
 //
 VBoolean EnableDocumentListener;
 int DocumentListenerFocus;

 public F_ItemUnitModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Update
  CB_UpdateActionPerformed(null);
  
  // Unit
  ComboMdlUnit=new OCustomComboBoxModel();
  ComboMdlUnit.setColumnsInfo(PCore.primArr(CCore.TypeString, CCore.TypeUnknown), 0);
  CmB_Unit.setModel(ComboMdlUnit);
  LastSelectedRowUnit=-1;
  UnitCleared=true;
  
  // Qty & Sell Price
  EnableDocumentListener=new VBoolean(true);
  DocumentListenerFocus=-1;
  
  TF_Qty.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){inputQty();}
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){inputQty();}
    }
   });
  TF_SellEach.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener.Value){inputSellPriceEach();}
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==2 && EnableDocumentListener.Value){inputSellPriceEach();}
    }
   });
  TF_Sell.getDocument().addDocumentListener(new DocumentListener(){
    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==3 && EnableDocumentListener.Value){inputSellPrice();}
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==3 && EnableDocumentListener.Value){inputSellPrice();}
    }
   });
  
  //
  clearComponents();
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearItem();
  Lbl_Update.setForeground(CGUI.Color_Label_InputRight); clearUpdate();
  Lbl_UnitAndQty.setForeground(CGUI.Color_Label_InputRight); clearUnit(); clearQty();
  clearInfo();
  Lbl_Sell.setForeground(CGUI.Color_Label_InputRight); clearSell();
  Lbl_SellComment.setForeground(CGUI.Color_Label_InputRight); clearSellComment();
  
  clearSetVariables();
 }
 
 // Update
 void fillUpdate(Date dt){PGUI.setDateComponent(dt, CB_Update, TF_UpdateY, CmB_UpdateM, CmB_UpdateD, false);}
 void clearUpdate(){PGUI.clearDateComponent(TF_UpdateY, CmB_UpdateM, CmB_UpdateD);}
 void focusUpdate(){PGUI.requestFocusInWindow((Component)PCore.subtituteBool(CB_Update.isSelected(), TF_UpdateY, CB_Update));}
 
 // Item
 void fillItem(){
  String str=null;
  
  str=PText.getString(InfoUnit.Item.PrimaryId, -1,
   "( "+PText.separate(String.valueOf(InfoUnit.Item.PrimaryId), " - ", 5)+" )  "+InfoUnit.Item.Name, "~");
  
  TA_Item.setText(str);
 }
 void clearItem(){PGUI.clearText(TA_Item);}
 
 // Unit
 void onSelectedRowChangedUnit(boolean UpdateAnyway){
  int row=CmB_Unit.getSelectedIndex();
  
  if(!(LastSelectedRowUnit!=row || UpdateAnyway)){return;}
  
  LastSelectedRowUnit=row;
  
  updateUnit();
 }
 void updateUnit(){
  int row=CmB_Unit.getSelectedIndex();
  OInfoIdName Unit=(OInfoIdName)ComboMdlUnit.Mdl.Rows.elementAt(row)[1];
  
  InfoUnit.setUnit(Unit);
 }
 void fillUnit(){
  int row;
  
  clearUnit();
  
  UnitCleared=false;
  ComboMdlUnit.append(PMyShop.getListForComboBox_InfoIdName(IFV.Stm,
   "select Id, Name from StockUnit order by Name asc", true, new OGetStringByFix("1 ", ""), true, true));
  row=0; CmB_Unit.setSelectedIndex(row); LastSelectedRowUnit=row;
 }
 void clearUnit(){
  if(UnitCleared){return;}
  
  ComboMdlUnit.removeAll(); LastSelectedRowUnit=-1;
  
  UnitCleared=true;
 }
 void focusUnit(){if(!CmB_Unit.isEnabled()){return;} PGUI.requestFocusInWindow(CmB_Unit);}
 
 // Qty
 void inputQty(){
  Qty=PText.parseDouble(TF_Qty.getText(), -1D, -1D); if(Qty==-1 || Qty<=0){Qty=-1; clearInfoDynamic(); return;}
  
  fillInfoDynamic();
  if(SellPriceEach!=-1){setSellPrice(Qty*SellPriceEach, false);}
 }
 void setQty(double Value, boolean ClearInvalidValue){
  Qty=Value;
  if(Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_Qty, PText.doubleToString(Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_Qty, "");}}
 }
 void clearQty(){setQty(-1, true);}
 void focusQty(){PGUI.requestFocusInWindow(TF_Qty);}
 
 // Additional Info
 void fillInfoStatic(){
  TF_InfoUnitStd.setText(InfoUnit.UnitStd.getName());
  TF_InfoBuyEach.setText(PText.priceToString(InfoUnit.Item.BuyPriceEstimation));
  TF_InfoSellEach.setText(PText.priceToString(InfoUnit.Item.SellPrice));
 }
 void clearInfoStatic(){PGUI.clearText(TF_InfoUnitStd, TF_InfoBuyEach, TF_InfoSellEach);}
 void fillInfoDynamic(){
  TF_InfoBuy.setText(PText.priceToString(Qty*InfoUnit.Item.BuyPriceEstimation));
  TF_InfoSell.setText(PText.priceToString(Qty*InfoUnit.Item.SellPrice));
 }
 void clearInfoDynamic(){PGUI.clearText(TF_InfoBuy, TF_InfoSell);}
 void fillInfo(){fillInfoStatic(); fillInfoDynamic();}
 void clearInfo(){clearInfoStatic(); clearInfoDynamic();}
 
 // Sell Price
 void inputSellPriceEach(){
  SellPriceEach=PText.parseDouble(TF_SellEach.getText(), -1D, -1D); if(SellPriceEach==-1 || SellPriceEach<0){SellPriceEach=-1; return;}
  
  if(Qty!=-1){setSellPrice(Qty*SellPriceEach, false);}
 }
 void setSellPriceEach(double Value, boolean ClearInvalidValue){
  SellPriceEach=Value;
  if(SellPriceEach>=0){PGUI.changeDocument(EnableDocumentListener, TF_SellEach, PText.doubleToString(SellPriceEach, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_SellEach, "");}}
 }
 void inputSellPrice(){
  SellPrice=PText.parseDouble(TF_Sell.getText(), -1D, -1D); if(SellPrice==-1 || SellPrice<0){SellPrice=-1; return;}
  
  if(Qty!=-1){setSellPriceEach(SellPrice/Qty, false);}
 }
 void setSellPrice(double Value, boolean ClearInvalidValue){
  SellPrice=Value;
  if(SellPrice>=0){PGUI.changeDocument(EnableDocumentListener, TF_Sell, PText.doubleToString(SellPrice, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_Sell, "");}}
 }
 void fillSell(double SellPriceEach, double SellPrice){setSellPriceEach(SellPriceEach, true); setSellPrice(SellPrice, true);}
 void clearSell(){setSellPriceEach(-1, true); setSellPrice(-1, true);}
 void focusSell(){PGUI.requestFocusInWindow(TF_Sell);}
 
 // Sell Comment
 void clearSellComment(){PGUI.clearText(TA_SellComment);}
 void focusSellComment(){PGUI.requestFocusInWindow(TA_SellComment);}
 
 // Others
 void initGUI(){
  fillItem();
  fillUpdate(new Date());
  fillUnit();
  setQty(1, false);
  fillSell(InfoUnit.Item.SellPrice, InfoUnit.Item.SellPrice*Qty);
  fillInfo();
 }
 void fillGUIWithSetVariables(){
  fillUpdate(wInfoUnit.SellUpdate);
  PGUI.findAndSelect_OInfoAThing_ComboBox(ComboMdlUnit, CmB_Unit, 1, wInfoUnit.Unit, true, 0);
  setQty(wInfoUnit.Qty, false);
  fillSell(wInfoUnit.SellPriceEach, wInfoUnit.SellPrice);
  TA_SellComment.setText(PText.getString(InfoUnit.SellComment, "", false));
 }
 void clearSetVariables(){wInfoUnit=null;}
 void setFormMode(){
  boolean IsModeAdd=wMode==1;
  
  CmB_Unit.setEnabled(IsModeAdd);
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  CmB_Unit = new javax.swing.JComboBox<>();
  TF_Qty = new javax.swing.JTextField();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_Item = new javax.swing.JTextArea();
  Lbl_Item = new javax.swing.JLabel();
  CmB_UpdateD = new javax.swing.JComboBox<>();
  CmB_UpdateM = new javax.swing.JComboBox<>();
  TF_UpdateY = new javax.swing.JTextField();
  CB_Update = new javax.swing.JCheckBox();
  Lbl_Update = new javax.swing.JLabel();
  jLabel3 = new javax.swing.JLabel();
  jLabel4 = new javax.swing.JLabel();
  TF_InfoUnitStd = new javax.swing.JTextField();
  jLabel5 = new javax.swing.JLabel();
  Lbl_UnitAndQty = new javax.swing.JLabel();
  TF_InfoBuy = new javax.swing.JTextField();
  TF_InfoBuyEach = new javax.swing.JTextField();
  TF_InfoSell = new javax.swing.JTextField();
  TF_InfoSellEach = new javax.swing.JTextField();
  Lbl_InfoBuy = new javax.swing.JLabel();
  Lbl_InfoSell = new javax.swing.JLabel();
  jLabel9 = new javax.swing.JLabel();
  jLabel10 = new javax.swing.JLabel();
  TF_Sell = new javax.swing.JTextField();
  jLabel11 = new javax.swing.JLabel();
  TF_SellEach = new javax.swing.JTextField();
  Lbl_Sell = new javax.swing.JLabel();
  Btn_UpdateSetToday = new javax.swing.JButton();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_SellComment = new javax.swing.JTextArea();
  Lbl_SellComment = new javax.swing.JLabel();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  CmB_Unit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  CmB_Unit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_UnitKeyPressed(evt);
   }
  });

  TF_Qty.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TF_Qty.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QtyFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_QtyFocusLost(evt);
   }
  });
  TF_Qty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QtyKeyPressed(evt);
   }
  });

  Btn_Cancel.setText("Cancel");
  Btn_Cancel.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok");
  Btn_Ok.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  TA_Item.setEditable(false);
  TA_Item.setBackground(new java.awt.Color(204, 255, 204));
  TA_Item.setColumns(20);
  TA_Item.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_Item.setRows(1);
  jScrollPane1.setViewportView(TA_Item);

  Lbl_Item.setText("Barang");

  CmB_UpdateD.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  CmB_UpdateD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_UpdateD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_UpdateDKeyPressed(evt);
   }
  });

  CmB_UpdateM.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  CmB_UpdateM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - November", "12 - Desember" }));
  CmB_UpdateM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_UpdateMKeyPressed(evt);
   }
  });

  TF_UpdateY.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_UpdateY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_UpdateYFocusGained(evt);
   }
  });
  TF_UpdateY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_UpdateYKeyPressed(evt);
   }
  });

  CB_Update.setText(" ");
  CB_Update.setIconTextGap(0);
  CB_Update.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Update.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_UpdateActionPerformed(evt);
   }
  });
  CB_Update.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpdateKeyPressed(evt);
   }
  });

  Lbl_Update.setText("Tanggal Update");

  jLabel3.setBackground(new java.awt.Color(204, 204, 255));
  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("Satuan Lain");
  jLabel3.setOpaque(true);

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel4.setText("=");

  TF_InfoUnitStd.setEditable(false);
  TF_InfoUnitStd.setBackground(new java.awt.Color(204, 255, 204));
  TF_InfoUnitStd.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  jLabel5.setBackground(new java.awt.Color(204, 204, 255));
  jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel5.setText("Satuan Standar");
  jLabel5.setOpaque(true);

  Lbl_UnitAndQty.setText("Satuan Lain & Qty-nya");

  TF_InfoBuy.setEditable(false);
  TF_InfoBuy.setBackground(new java.awt.Color(204, 255, 204));
  TF_InfoBuy.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_InfoBuyEach.setEditable(false);
  TF_InfoBuyEach.setBackground(new java.awt.Color(204, 255, 204));
  TF_InfoBuyEach.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_InfoSell.setEditable(false);
  TF_InfoSell.setBackground(new java.awt.Color(204, 255, 204));
  TF_InfoSell.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_InfoSellEach.setEditable(false);
  TF_InfoSellEach.setBackground(new java.awt.Color(204, 255, 204));
  TF_InfoSellEach.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Lbl_InfoBuy.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_InfoBuy.setText("- - info hrg beli");

  Lbl_InfoSell.setFont(new java.awt.Font("Tahoma", 2, 11)); // NOI18N
  Lbl_InfoSell.setText("- - info hrg jual normal");

  jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  jLabel9.setText("@");

  jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  jLabel10.setText("@");

  TF_Sell.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TF_Sell.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_SellFocusLost(evt);
   }
  });
  TF_Sell.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellKeyPressed(evt);
   }
  });

  jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  jLabel11.setText("@");

  TF_SellEach.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TF_SellEach.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellEachFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_SellEachFocusLost(evt);
   }
  });
  TF_SellEach.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellEachKeyPressed(evt);
   }
  });

  Lbl_Sell.setText("Harga Jual");

  Btn_UpdateSetToday.setText("Hari Ini");
  Btn_UpdateSetToday.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_UpdateSetToday.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_UpdateSetTodayActionPerformed(evt);
   }
  });
  Btn_UpdateSetToday.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_UpdateSetTodayKeyPressed(evt);
   }
  });

  TA_SellComment.setColumns(20);
  TA_SellComment.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TA_SellComment.setRows(5);
  TA_SellComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TA_SellCommentFocusGained(evt);
   }
  });
  jScrollPane2.setViewportView(TA_SellComment);

  Lbl_SellComment.setText("Ket Harga Jual");

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Lbl_UnitAndQty, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
       .addComponent(Lbl_Update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Lbl_Item, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Lbl_InfoBuy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Lbl_InfoSell, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Lbl_SellComment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Lbl_Sell, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(jScrollPane1)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_Update)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_UpdateY, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_UpdateM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_UpdateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_UpdateSetToday))
       .addGroup(layout.createSequentialGroup()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(TF_InfoSell, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
         .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
         .addComponent(TF_InfoBuy, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
         .addComponent(CmB_Unit, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
         .addComponent(TF_Sell, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(jLabel4)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE)
         .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
          .addComponent(jLabel9)
          .addGap(4, 4, 4)
          .addComponent(TF_InfoBuyEach))
         .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
          .addComponent(jLabel10)
          .addGap(4, 4, 4)
          .addComponent(TF_InfoSellEach))
         .addGroup(layout.createSequentialGroup()
          .addComponent(jLabel11)
          .addGap(4, 4, 4)
          .addComponent(TF_SellEach))
         .addGroup(layout.createSequentialGroup()
          .addComponent(TF_Qty, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
          .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
          .addComponent(TF_InfoUnitStd)))))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_Item)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Update)
     .addComponent(CmB_UpdateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_UpdateM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_UpdateY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Update)
     .addComponent(Btn_UpdateSetToday))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel3)
     .addComponent(jLabel5))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_Unit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel4)
     .addComponent(TF_InfoUnitStd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_UnitAndQty)
     .addComponent(TF_Qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_InfoBuy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_InfoBuyEach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_InfoBuy)
     .addComponent(jLabel9))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_InfoSell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_InfoSellEach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_InfoSell)
     .addComponent(jLabel10))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Sell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel11)
     .addComponent(TF_SellEach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Sell))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_SellComment)
     .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation Valid;
  boolean ModeAdd=wMode==1;
  int selection;
  OInfoIdName Unit;
  boolean CurrValid;
  String str;
  
  Valid=new OValidation(true);
  
  if(ModeAdd){
   // Unit
   selection=CmB_Unit.getSelectedIndex();
   CurrValid=selection!=0;
   if(!CurrValid){
    // Lbl_UnitAndQty.setForeground(CGUI.Color_Label_InputWrong);
    Valid.addError("\n- Satuan Lain harus didefenisikan.");
   }
   else{
    // Lbl_UnitAndQty.setForeground(CGUI.Color_Label_InputRight);
    
    Unit=(OInfoIdName)ComboMdlUnit.Mdl.Rows.elementAt(selection)[1];
    InfoUnit.Unit.Id=Unit.Id; InfoUnit.Unit.Name=Unit.Name;
   }
  }
  
  // Qty
  CurrValid=Qty>0;
  if(!CurrValid){
   // Lbl_UnitAndQty.setForeground(CGUI.Color_Label_InputWrong);
   Valid.addError("\n- Inputan Qty belum benar (harus >0).");
  }
  else{
   // Lbl_UnitAndQty.setForeground(CGUI.Color_Label_InputRight);
   
   InfoUnit.Qty=Qty;
  }
  
  // Sell
  CurrValid=SellPriceEach>=0 && SellPrice>=0;
  if(!CurrValid){
   Lbl_Sell.setForeground(CGUI.Color_Label_InputWrong);
   Valid.addError("\n- Inputan Harga Jual belum benar (harus >=0).");
  }
  else{
   Lbl_Sell.setForeground(CGUI.Color_Label_InputRight);
   
   InfoUnit.SellPriceEach=SellPriceEach;
   InfoUnit.SellPrice=SellPrice;
  }
  
  // SellComment
  str=TA_SellComment.getText();
  CurrValid=PText.checkInput(str, true, 255, 0, 0, 0, 0);
  if(!CurrValid){
   Lbl_SellComment.setForeground(CGUI.Color_Label_InputWrong);
   Valid.addError("\n- Inputan Keterangan Harga Jual belum benar.");
  }
  else{
   Lbl_SellComment.setForeground(CGUI.Color_Label_InputRight);
   
   InfoUnit.SellComment=str;
  }
  
  // Sell Update
  CurrValid=true;
  InfoUnit.SellUpdate=null;
  if(CB_Update.isSelected()){InfoUnit.SellUpdate=PGUI.valueOfDateComponent(TF_UpdateY, CmB_UpdateM, CmB_UpdateD); CurrValid=InfoUnit.SellUpdate!=null;}
  if(!CurrValid){
   Lbl_Update.setForeground(CGUI.Color_Label_InputWrong);
   Valid.addError("\n- Inputan Tanggal Update belum benar.");
  }
  else{
   Lbl_Update.setForeground(CGUI.Color_Label_InputRight);
  }
  
  if(!Valid.IsValid){JOptionPane.showMessageDialog(null, "Inputan belum benar :\n"+Valid.getError()); return;}
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean ModeAdd=wMode==1;
  
  if(Activ){return;}
  Activ=true;
  
  setTitle(PText.getString(ModeAdd, "Tambah Satuan Lain", "Ubah Satuan Lain"));
  
  InfoUnit=(OInfoItemStockUnit)wInfoUnit.clone();
  
  initGUI();
  setFormMode();
  
  if(ModeAdd){
   focusUnit();
  }
  else{
   fillGUIWithSetVariables();
   
   focusSell();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void CmB_UnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_UnitKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : focusUpdate(); break;
   case KeyEvent.VK_RIGHT : focusQty(); break;
  }
 }//GEN-LAST:event_CmB_UnitKeyPressed

 private void TF_QtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QtyKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusUpdate(); break;
   case KeyEvent.VK_LEFT : focusUnit(); break;
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_DOWN : focusSell(); break;
  }
 }//GEN-LAST:event_TF_QtyKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusSell(); break;
   case KeyEvent.VK_RIGHT : PGUI.requestFocusInWindow(Btn_Cancel); break;
   case KeyEvent.VK_ENTER : Btn_OkActionPerformed(null); break;
  }
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_UP : focusSell(); break;
   case KeyEvent.VK_LEFT : PGUI.requestFocusInWindow(Btn_Ok); break;
   case KeyEvent.VK_ENTER : Btn_CancelActionPerformed(null); break;
  }
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_QtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QtyFocusGained
  DocumentListenerFocus=1;
  TF_Qty.selectAll();
 }//GEN-LAST:event_TF_QtyFocusGained

 private void CB_UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_UpdateActionPerformed
  PGUI.enableInput(CB_Update.isSelected(), TF_UpdateY, CmB_UpdateM, CmB_UpdateD, false);
 }//GEN-LAST:event_CB_UpdateActionPerformed

 private void Btn_UpdateSetTodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_UpdateSetTodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_Update, TF_UpdateY, CmB_UpdateM, CmB_UpdateD, false);
 }//GEN-LAST:event_Btn_UpdateSetTodayActionPerformed

 private void TF_UpdateYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_UpdateYFocusGained
  if(!PGUI.isEnabled(TF_UpdateY)){return;}
  TF_UpdateY.selectAll();
 }//GEN-LAST:event_TF_UpdateYFocusGained

 private void TF_SellFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellFocusGained
  DocumentListenerFocus=3;
  TF_Sell.selectAll();
 }//GEN-LAST:event_TF_SellFocusGained

 private void TF_SellFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_SellFocusLost

 private void TF_SellEachFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellEachFocusGained
  DocumentListenerFocus=2;
  TF_SellEach.selectAll();
 }//GEN-LAST:event_TF_SellEachFocusGained

 private void TF_SellEachFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellEachFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_SellEachFocusLost

 private void TF_SellEachKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellEachKeyPressed
  if(!TF_SellEach.isEditable()){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : if(TF_SellEach.getCaretPosition()==0){PGUI.requestFocusInWindow(TF_Sell);} break;
   case KeyEvent.VK_UP : focusQty(); break;
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_DOWN : PGUI.requestFocusInWindow(Btn_Ok); break;
  }
 }//GEN-LAST:event_TF_SellEachKeyPressed

 private void TF_SellKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellKeyPressed
  if(!TF_Sell.isEditable()){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_RIGHT : if(TF_Sell.getCaretPosition()==TF_Sell.getDocument().getLength()){PGUI.requestFocusInWindow(TF_SellEach);} break;
   case KeyEvent.VK_UP : focusQty(); break;
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_DOWN : PGUI.requestFocusInWindow(Btn_Ok); break;
  }
 }//GEN-LAST:event_TF_SellKeyPressed

 private void TF_UpdateYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_UpdateYKeyPressed
  if(!CB_Update.isSelected()){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : if(TF_UpdateY.getCaretPosition()==0){PGUI.requestFocusInWindow(CB_Update);} break;
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_RIGHT : if(TF_UpdateY.getCaretPosition()==TF_UpdateY.getDocument().getLength()){PGUI.requestFocusInWindow(CmB_UpdateM);} break;
   case KeyEvent.VK_DOWN : focusQty(); break;
  }
 }//GEN-LAST:event_TF_UpdateYKeyPressed

 private void CB_UpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpdateKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : CB_Update.setSelected(!CB_Update.isSelected()); break;
   case KeyEvent.VK_RIGHT : PGUI.requestFocusInWindow((Component)PCore.subtituteBool(CB_Update.isSelected(), TF_UpdateY, Btn_UpdateSetToday)); break;
   case KeyEvent.VK_DOWN : focusQty(); break;
  }
 }//GEN-LAST:event_CB_UpdateKeyPressed

 private void CmB_UpdateMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_UpdateMKeyPressed
  if(!CB_Update.isSelected()){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : PGUI.requestFocusInWindow(TF_UpdateY); break;
   case KeyEvent.VK_RIGHT : PGUI.requestFocusInWindow(CmB_UpdateD); break;
  }
 }//GEN-LAST:event_CmB_UpdateMKeyPressed

 private void CmB_UpdateDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_UpdateDKeyPressed
  if(!CB_Update.isSelected()){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : PGUI.requestFocusInWindow(CmB_UpdateM); break;
   case KeyEvent.VK_RIGHT : PGUI.requestFocusInWindow(Btn_UpdateSetToday); break;
  }
 }//GEN-LAST:event_CmB_UpdateDKeyPressed

 private void Btn_UpdateSetTodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_UpdateSetTodayKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_LEFT : PGUI.requestFocusInWindow((Component)PCore.subtituteBool(CB_Update.isSelected(), CmB_UpdateD, CB_Update)); break;
   case KeyEvent.VK_DOWN : focusQty(); break;
   case KeyEvent.VK_ENTER : Btn_UpdateSetTodayActionPerformed(null); break;
  }
 }//GEN-LAST:event_Btn_UpdateSetTodayKeyPressed

 private void TF_QtyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QtyFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_QtyFocusLost

 private void TA_SellCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_SellCommentFocusGained
  TA_SellComment.selectAll();
 }//GEN-LAST:event_TA_SellCommentFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_UpdateSetToday;
 private javax.swing.JCheckBox CB_Update;
 private javax.swing.JComboBox<String> CmB_Unit;
 private javax.swing.JComboBox<String> CmB_UpdateD;
 private javax.swing.JComboBox<String> CmB_UpdateM;
 private javax.swing.JLabel Lbl_InfoBuy;
 private javax.swing.JLabel Lbl_InfoSell;
 private javax.swing.JLabel Lbl_Item;
 private javax.swing.JLabel Lbl_Sell;
 private javax.swing.JLabel Lbl_SellComment;
 private javax.swing.JLabel Lbl_UnitAndQty;
 private javax.swing.JLabel Lbl_Update;
 private javax.swing.JTextArea TA_Item;
 private javax.swing.JTextArea TA_SellComment;
 private javax.swing.JTextField TF_InfoBuy;
 private javax.swing.JTextField TF_InfoBuyEach;
 private javax.swing.JTextField TF_InfoSell;
 private javax.swing.JTextField TF_InfoSellEach;
 private javax.swing.JTextField TF_InfoUnitStd;
 private javax.swing.JTextField TF_Qty;
 private javax.swing.JTextField TF_Sell;
 private javax.swing.JTextField TF_SellEach;
 private javax.swing.JTextField TF_UpdateY;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 // End of variables declaration//GEN-END:variables
}