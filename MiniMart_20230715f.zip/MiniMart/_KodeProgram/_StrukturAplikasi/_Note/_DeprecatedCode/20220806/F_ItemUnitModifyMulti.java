import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_ItemUnitModifyMulti extends XFormDialog {
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeQuantity; double Quantity;
 boolean ChangeSellPrice; boolean IsChangeSellPriceEach; double SellPrice;
 boolean ChangeSellPriceComment; boolean ChangeSellPriceCommentSubString; String SellPriceCommentFind; String SellPriceComment;
 boolean ChangeSellUpdate; Date SellUpdate;
 
 public F_ItemUnitModifyMulti(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Sell Price
  CmB_SellPrice.setSelectedIndex(1);
  
  // Sell Price Comment
  CB_SellCommentSubActionPerformed(null);
  
  // Update
  CB_SellUpdateIsSetActionPerformed(null);
 }
 
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  CB_Quantity.setSelected(false); CB_Quantity.setForeground(CGUI.Color_Label_InputRight); PGUI.clearText(TF_Quantity);
  CB_SellPrice.setSelected(false); CB_SellPrice.setForeground(CGUI.Color_Label_InputRight); PGUI.clearText(TF_SellPrice);
  CB_SellComment.setSelected(false); CB_SellComment.setForeground(CGUI.Color_Label_InputRight); PGUI.clearText(TF_SellCommentSub, TA_SellComment);
  CB_SellUpdate.setSelected(false); CB_SellUpdate.setForeground(CGUI.Color_Label_InputRight); PGUI.clearDateComponent(TF_SellUpdateY, CmB_SellUpdateM, CmB_SellUpdateD);
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Price = new javax.swing.ButtonGroup();
  TF_Quantity = new javax.swing.JTextField();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  CB_Quantity = new javax.swing.JCheckBox();
  Lbl_DataCount = new javax.swing.JLabel();
  Lbl_QuantityHelp = new javax.swing.JLabel();
  CB_SellUpdate = new javax.swing.JCheckBox();
  CmB_SellUpdateD = new javax.swing.JComboBox<>();
  CmB_SellUpdateM = new javax.swing.JComboBox<>();
  TF_SellUpdateY = new javax.swing.JTextField();
  CB_SellUpdateIsSet = new javax.swing.JCheckBox();
  TF_SellPrice = new javax.swing.JTextField();
  CB_SellPrice = new javax.swing.JCheckBox();
  CmB_SellPrice = new javax.swing.JComboBox<>();
  Lbl_SellPriceHelp = new javax.swing.JLabel();
  CB_SellComment = new javax.swing.JCheckBox();
  TF_SellCommentSub = new javax.swing.JTextField();
  CB_SellCommentSub = new javax.swing.JCheckBox();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_SellComment = new javax.swing.JTextArea();
  Btn_SellUpdateSetToday = new javax.swing.JButton();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_Quantity.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_Quantity.setMargin(new java.awt.Insets(0, 0, 0, 0));

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_Cancel.setNextFocusableComponent(TF_Quantity);
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(2, 4, 2, 4));
  Btn_Ok.setNextFocusableComponent(Btn_Cancel);
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });

  CB_Quantity.setText("Kuantitas");
  CB_Quantity.setMargin(new java.awt.Insets(0, 0, 0, 0));

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data");

  Lbl_QuantityHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QuantityHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QuantityHelp.setText("(?)");
  Lbl_QuantityHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QuantityHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QuantityHelpMouseClicked(evt);
   }
  });

  CB_SellUpdate.setText("Tgl Update");
  CB_SellUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CmB_SellUpdateD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

  CmB_SellUpdateM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - November", "12 - Desember" }));

  CB_SellUpdateIsSet.setText(" ");
  CB_SellUpdateIsSet.setIconTextGap(0);
  CB_SellUpdateIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdateIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellUpdateIsSetActionPerformed(evt);
   }
  });

  TF_SellPrice.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_SellPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CB_SellPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CmB_SellPrice.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hrg Jual / Unit Std", "Hrg Jual Total" }));

  Lbl_SellPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellPriceHelp.setText("(?)");
  Lbl_SellPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellPriceHelpMouseClicked(evt);
   }
  });

  CB_SellComment.setText("Ket Hrg Jual");
  CB_SellComment.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CB_SellCommentSub.setText("Ganti Sub-Kata");
  CB_SellCommentSub.setToolTipText("centang opsi ini utk mengganti sub-kata");
  CB_SellCommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellCommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellCommentSubActionPerformed(evt);
   }
  });

  TA_SellComment.setColumns(20);
  TA_SellComment.setRows(5);
  jScrollPane1.setViewportView(TA_SellComment);

  Btn_SellUpdateSetToday.setText("Hari Ini");
  Btn_SellUpdateSetToday.setMargin(new java.awt.Insets(2, 4, 2, 4));

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Lbl_DataCount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_SellUpdate)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_Quantity)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_QuantityHelp))
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_SellPrice)
        .addGap(0, 0, 0)
        .addComponent(CmB_SellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_SellPriceHelp))
       .addComponent(CB_SellComment))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_SellPrice, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_Quantity)
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
        .addComponent(CB_SellUpdateIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_SellUpdateY, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_SellUpdateM, 0, 199, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_SellUpdateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_SellUpdateSetToday))
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_SellCommentSub)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_SellCommentSub))
       .addComponent(jScrollPane1))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_Quantity)
     .addComponent(Lbl_QuantityHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_SellUpdateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellUpdate)
     .addComponent(CmB_SellUpdateM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SellUpdateY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellUpdateIsSet)
     .addComponent(Btn_SellUpdateSetToday))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellPrice)
     .addComponent(Lbl_SellPriceHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SellComment)
     .addComponent(TF_SellCommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellCommentSub))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)
     .addComponent(Lbl_DataCount))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrValid;
  
  ChangeQuantity=CB_Quantity.isSelected();
  ChangeSellPrice=CB_SellPrice.isSelected();
  ChangeSellPriceComment=CB_SellComment.isSelected();
  ChangeSellUpdate=CB_SellUpdate.isSelected();
  if(!ChangeQuantity && !ChangeSellPrice && !ChangeSellPriceComment && !ChangeSellUpdate){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  IsValid=true;
  
  if(ChangeQuantity){
   CurrValid=true;
   
   try{Quantity=Double.parseDouble(TF_Quantity.getText());}catch(Exception E){Quantity=-1;}
   if(Quantity<=0){CurrValid=false;}
   
   if(!CurrValid){IsValid=false; CB_Quantity.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Quantity.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeSellPrice){
   CurrValid=true;
   
   IsChangeSellPriceEach=CmB_SellPrice.getSelectedIndex()==0;
   
   try{SellPrice=Double.parseDouble(TF_SellPrice.getText());}catch(Exception E){SellPrice=-1;}
   if(SellPrice<0){CurrValid=false;}
   
   if(!CurrValid){IsValid=false; CB_SellPrice.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_SellPrice.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeSellPriceComment){
   CurrValid=true;
   
   SellPriceComment=TA_SellComment.getText();
   ChangeSellPriceCommentSubString=CB_SellCommentSub.isSelected();
   if(!ChangeSellPriceCommentSubString){CurrValid=PText.checkInput(SellPriceComment, true, 255, 0, 0, 0, 0);}
   else{
    SellPriceCommentFind=TF_SellCommentSub.getText();
    CurrValid=SellPriceCommentFind.length()!=0;
   }
   
   if(!CurrValid){IsValid=false; CB_SellComment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_SellComment.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeSellUpdate){
   CurrValid=true;
   
   SellUpdate=null;
   if(CB_SellUpdateIsSet.isSelected()){SellUpdate=PGUI.valueOfDateComponent(TF_SellUpdateY, CmB_SellUpdateM, CmB_SellUpdateD); CurrValid=SellUpdate!=null;}
   
   if(!CurrValid){IsValid=false; CB_SellUpdate.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_SellUpdate.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+
    "Silahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  closingForm(0);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;

  setTitle("Ubah Data Dari Beberapa Satuan Lain");

  Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data");
  
  PGUI.setDateComponent(new Date(), TF_SellUpdateY, CmB_SellUpdateM, CmB_SellUpdateD);

  PGUI.requestFocusInWindow(TF_SellPrice);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_QuantityHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QuantityHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- ( 1 ) Satuan Lain = ( Kuantitas ) Satuan Standar."+
   "\n"+PText.getInputInfo(false, CCore.CharsCount_Deci(), 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_QuantityHelpMouseClicked

 private void CB_SellUpdateIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellUpdateIsSetActionPerformed
  PGUI.enableInput(CB_SellUpdateIsSet.isSelected(), TF_SellUpdateY, CmB_SellUpdateM, CmB_SellUpdateD, false);
 }//GEN-LAST:event_CB_SellUpdateIsSetActionPerformed

 private void Lbl_SellPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, CCore.CharsCount_Deci(), 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_SellPriceHelpMouseClicked

 private void CB_SellCommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellCommentSubActionPerformed
  PGUI.enableInput(CB_SellCommentSub.isSelected(), TF_SellCommentSub, true);
 }//GEN-LAST:event_CB_SellCommentSubActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_SellUpdateSetToday;
 private javax.swing.JCheckBox CB_Quantity;
 private javax.swing.JCheckBox CB_SellComment;
 private javax.swing.JCheckBox CB_SellCommentSub;
 private javax.swing.JCheckBox CB_SellPrice;
 private javax.swing.JCheckBox CB_SellUpdate;
 private javax.swing.JCheckBox CB_SellUpdateIsSet;
 private javax.swing.JComboBox<String> CmB_SellPrice;
 private javax.swing.JComboBox<String> CmB_SellUpdateD;
 private javax.swing.JComboBox<String> CmB_SellUpdateM;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.JLabel Lbl_QuantityHelp;
 private javax.swing.JLabel Lbl_SellPriceHelp;
 private javax.swing.ButtonGroup RG_Price;
 private javax.swing.JTextArea TA_SellComment;
 private javax.swing.JTextField TF_Quantity;
 private javax.swing.JTextField TF_SellCommentSub;
 private javax.swing.JTextField TF_SellPrice;
 private javax.swing.JTextField TF_SellUpdateY;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
