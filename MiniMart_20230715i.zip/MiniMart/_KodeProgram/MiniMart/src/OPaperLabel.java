import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

public class OPaperLabel extends OPaper {
 
 /*
  Characteristics of Paper Label :
  - It is simulate "Self Adhesive Sticker Paper".
  - PaperWidth  = ImageableX + ( LabelWidth + [LabelSpacingHorizontal] ) ...
  - PaperHeight = ImageableY + ( (LabelSpacingVerticalA+LabelHeight) + [LabelSpacingVerticalB] ) ...
 */
 
 double LabelWidth, LabelHeight;
 double LabelSpacingHorizontal;
 double LabelSpacingVerticalA;
 double LabelSpacingVerticalB;
 
 int ColumnCount, RowCount;
 
 boolean DrawCutLine;
 boolean IsCustomPaperLabel;
 
 public OPaperLabel(){}
 public OPaperLabel(int Id, String Name, String Description, boolean IsRollPaper, Object AdditionalInfo, OPaperMargin MarginSt, OPaperMargin MarginTh,
  double RealWidth, double RealHeight, double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight,
  double WidthTolerance, double HeightTolerance, double MoveImageableX, double MoveImageableY,
  double LabelWidth, double LabelHeight, double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB,
  boolean AutoCalculateWidthHeightForMaximalLabelCount, boolean ReinitImageableWidth, boolean ReinitImageableHeight,
  boolean DrawCutLine, boolean IsCustomPaperLabel){
  
  super(Id, Name, Description, IsRollPaper, AdditionalInfo, MarginSt, MarginTh, RealWidth, RealHeight,
   RealImageableX, RealImageableY, RealImageableWidth, RealImageableHeight, WidthTolerance, HeightTolerance, MoveImageableX, MoveImageableY);
  setPaperLabelBasicInfo(LabelWidth, LabelHeight, LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB,
   AutoCalculateWidthHeightForMaximalLabelCount, ReinitImageableWidth, ReinitImageableHeight, DrawCutLine, IsCustomPaperLabel);
  
 }
 public OPaperLabel(OPaper Papr,
  double LabelWidth, double LabelHeight, double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB,
  boolean AutoCalculateWidthHeightForMaximalLabelCount, boolean ReinitImageableWidth, boolean ReinitImageableHeight,
  boolean DrawCutLine, boolean IsCustomPaperLabel){
  
  changeThisPaperWith(Papr);
  setPaperLabelBasicInfo(LabelWidth, LabelHeight, LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB,
   AutoCalculateWidthHeightForMaximalLabelCount, ReinitImageableWidth, ReinitImageableHeight, DrawCutLine, IsCustomPaperLabel);
  
 }

 void setPaperLabelBasicInfo(
  double LabelWidth, double LabelHeight, double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB,
  boolean AutoCalculateWidthHeightForMaximalLabelCount, boolean ReinitImageableWidth, boolean ReinitImageableHeight,
  boolean DrawCutLine, boolean IsCustomPaperLabel){
  setLabelSize(LabelWidth, LabelHeight, LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB,
   AutoCalculateWidthHeightForMaximalLabelCount, ReinitImageableWidth, ReinitImageableHeight);
  this.DrawCutLine=DrawCutLine;
  this.IsCustomPaperLabel=IsCustomPaperLabel;
 }
 protected void setLabelSize(
  double LabelWidth, double LabelHeight, double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB,
  boolean AutoCalculateWidthHeightForMaximalLabelCount, boolean ReinitImageableWidth, boolean ReinitImageableHeight) {
  double LblWidth=LabelWidth;
  double LblHeight=LabelHeight;
  
  if(AutoCalculateWidthHeightForMaximalLabelCount){
   if(PGraphics.gradingLabelCount(RealImageableWidth, RealImageableHeight, LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB,
    LabelWidth, LabelHeight, LabelHeight, LabelWidth, IsRollPaper, true, false, true)==2){
    LblWidth=LabelHeight;
    LblHeight=LabelWidth;
   }
  }
  this.LabelWidth=LblWidth;
  this.LabelHeight=LblHeight;
  
  this.LabelSpacingHorizontal = LabelSpacingHorizontal;
  this.LabelSpacingVerticalA = LabelSpacingVerticalA;
  this.LabelSpacingVerticalB = LabelSpacingVerticalB;
  
  initColumnAndRowCount(ReinitImageableWidth, ReinitImageableHeight);
 }
 private void initColumnAndRowCount(boolean ReinitImageableWidth, boolean ReinitImageableHeight){
  ODimensionAbsolute ColRow=PGraphics.calculateLabelColumnAndRowCount(RealImageableWidth, RealImageableHeight,
   LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB, LabelWidth, LabelHeight, IsRollPaper);
  ColumnCount=ColRow.ColumnsCount;
  RowCount=ColRow.RowsCount;
  reInitImageableArea(ReinitImageableWidth, ReinitImageableHeight);
 }
 private void reInitImageableArea(boolean ReinitImageableWidth, boolean ReinitImageableHeight){
  ODimension dim;
  OPaperMargin margin;
  double MaxImageableWidth, MaxImageableHeight;
  
  if(!(ReinitImageableWidth || ReinitImageableHeight)){return;}
  
  // re-set ImageableWidth & ImageableHeight
  dim=PGraphics.getDimension(RowCount, ColumnCount, LabelWidth, LabelHeight,
   LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB, false);
  if(!IsRollPaper){margin=MarginStandardMinimal;}else{margin=MarginThermalMinimal;}
  
  MaxImageableWidth=RealImageableWidth;
  if(ReinitImageableWidth){
   if(margin!=null){MaxImageableWidth=RealWidth-RealImageableX-margin.Right;}
   if(dim.getWidth()>MaxImageableWidth){MaxImageableWidth=dim.getWidth();}
  }
  MaxImageableHeight=RealImageableHeight;
  if(ReinitImageableHeight){
   if(margin!=null){MaxImageableHeight=RealHeight-RealImageableY-margin.Bottom;}
   if(dim.getHeight()>MaxImageableHeight){MaxImageableHeight=dim.getHeight();}
  }
  changeImageableArea(RealImageableX, RealImageableY, MaxImageableWidth, MaxImageableHeight);
 }
 
 public static boolean validate(double RealWidth, double RealHeight, double RealImageableX, double RealImageableY, double RealImageableWidth, double RealImageableHeight, boolean IsRollPaper,
  double LabelWidth, double LabelHeight, double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB){
  boolean ret=false;
  ODimensionAbsolute ColRow;
  
  do{
   if(OPaper.validate(RealWidth, RealHeight, RealImageableX, RealImageableY, RealImageableWidth, RealImageableHeight)==false){break;}
   if(LabelWidth<=0 || LabelHeight<=0 || LabelSpacingHorizontal<0 || LabelSpacingVerticalA<0 || LabelSpacingVerticalB<0){break;}
   ColRow=PGraphics.calculateLabelColumnAndRowCount(RealImageableWidth, RealImageableHeight,
    LabelSpacingHorizontal, LabelSpacingVerticalA, LabelSpacingVerticalB, LabelWidth, LabelHeight, IsRollPaper);
   if(ColRow.ColumnsCount==0 || ColRow.RowsCount==0){break;}
   ret=true;
  }while(false);
  
  return ret;
 }
 
 public BufferedImage getBufferedImage(double ScaleFactor){
  BufferedImage ret=null;
  
  if(!IsRollPaper){ret=getSamplePreviewNormalPaper(ScaleFactor);}
  else{ret=getSamplePreviewRollPaper(ScaleFactor);}
  
  return ret;
 }
 public BufferedImage getSamplePreviewNormalPaper(double ScaleFactor){
  BufferedImage ret;
  Graphics2D g;
  int row_curr;
  double Y;
  Color ColorPaper=(Color)PCore.subtituteBool(DrawCutLine, CGUI.White, new Color(255, 230, 65));
  
  // create BufferedImage
  ret=new BufferedImage(PMath.roundCustom(ScaleFactor*RealWidth, 0.2), PMath.roundCustom(ScaleFactor*RealHeight, 0.2), BufferedImage.TYPE_INT_RGB);
  g=ret.createGraphics();
  g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
  g.setBackground(ColorPaper);
  g.clearRect(0, 0, ret.getWidth(), ret.getHeight());
  g.scale(ScaleFactor, ScaleFactor);
  
  // draw
  row_curr=0;
  Y=RealImageableY;
  do{
   Y=Y+LabelSpacingVerticalA;
   
   drawRow(g, Y, false, false, 0);
   
   row_curr=row_curr+1;
   Y=Y+LabelHeight+LabelSpacingVerticalB;
  }while(row_curr!=RowCount);
  
  return ret;
 }
 public BufferedImage getSamplePreviewRollPaper(double ScaleFactor){
  BufferedImage ret;
  Graphics2D g;
  double Y;
  double HalfRowSize=0.3;
  Color ColorPaper=(Color)PCore.subtituteBool(DrawCutLine, CGUI.White, new Color(255, 230, 65));
  
  // create BufferedImage
  ret=new BufferedImage(PMath.roundCustom(ScaleFactor*RealWidth, 0.2),
   PMath.roundCustom(ScaleFactor*(LabelHeight*HalfRowSize+LabelSpacingVerticalB+LabelSpacingVerticalA+LabelHeight+LabelSpacingVerticalB+LabelSpacingVerticalA+LabelHeight*HalfRowSize), 0.2),
   BufferedImage.TYPE_INT_RGB);
  g=ret.createGraphics();
  g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
  g.setBackground(ColorPaper);
  g.clearRect(0, 0, ret.getWidth(), ret.getHeight());
  g.scale(ScaleFactor, ScaleFactor);
  
  // draw
  Y=0;
  
  drawRow(g, Y, true, false, HalfRowSize);
  Y=Y+LabelHeight*HalfRowSize+LabelSpacingVerticalB;
  
  drawSeparator(g, Y);
  
  Y=Y+LabelSpacingVerticalA;
  drawRow(g, Y, false, false, HalfRowSize);
  Y=Y+LabelHeight+LabelSpacingVerticalB;
  
  drawSeparator(g, Y);
  
  Y=Y+LabelSpacingVerticalA;
  drawRow(g, Y, true, true, HalfRowSize);
  
  return ret;
 }
 private void drawRow(Graphics2D g, double Y, boolean IsHalfRow, boolean IsHalfRowTop, double HalfRowSize){
  int col_curr;
  double X;
  double draw_height;
  double y_temp;
  boolean DrawLineByLine;
  double DrawLabelBorderThick=OUnit.mm_to_pixel(0.3);
  Color ColorLabel=(Color)PCore.subtituteBool(DrawCutLine, new Color(231, 255, 163), CGUI.White);
  Color ColorLabelBorder=CGUI.Black;
  
  g.setStroke(new BasicStroke((float)DrawLabelBorderThick));
  g.setColor((Color)PCore.subtituteBool(DrawCutLine, ColorLabelBorder, ColorLabel));
  
  col_curr=0;
  X=RealImageableX;
  draw_height=LabelHeight; if(IsHalfRow){draw_height=LabelHeight*HalfRowSize;}
  DrawLineByLine=false; if(IsHalfRow && DrawCutLine){DrawLineByLine=true;}
  y_temp=Y; if(!IsHalfRowTop){y_temp=Y+draw_height;}
  do{
   if(!DrawLineByLine){
    if(DrawCutLine){g.drawRect(PMath.round(X, 0), PMath.round(Y, 0), PMath.round(LabelWidth, 0), PMath.round(draw_height, 0));}
    else{g.fillRect(PMath.round(X, 0), PMath.round(Y, 0), PMath.round(LabelWidth, 0), PMath.round(draw_height, 0));}
   }
   else{
    g.drawLine(PMath.round(X, 0), PMath.round(Y, 0), PMath.round(X, 0), PMath.round(Y+draw_height, 0));
    g.drawLine(PMath.round(X+LabelWidth, 0), PMath.round(Y, 0), PMath.round(X+LabelWidth, 0), PMath.round(Y+draw_height, 0));
    g.drawLine(PMath.round(X, 0), PMath.round(y_temp, 0), PMath.round(X+LabelWidth, 0), PMath.round(y_temp, 0));
   }
   
   col_curr=col_curr+1;
   X=X+LabelWidth+LabelSpacingHorizontal;
  }while(col_curr!=ColumnCount);
 }
 void drawSeparator(Graphics2D g, double Y){
  double DrawSeparatorThick=OUnit.mm_to_pixel(0.3);
  Color ColorSeparator=CGUI.Gray128;
  
  g.setStroke(new BasicStroke((float)DrawSeparatorThick));
  g.setColor(ColorSeparator);
  g.drawLine(PMath.round(0, 0), PMath.round(Y, 0), PMath.round(RealWidth, 0), PMath.round(Y, 0));
 }

}