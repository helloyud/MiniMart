import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class F_QueryEtc extends XFormDialog
 implements OFormSupportsInstructions{
 
 // variables
 int TabResult[];
 int TabQuery[];
 OParam Param;
 
 // result table
 OCustomTableModel TableMdlResult;
 OCustomComboBoxModel CmBMdlIdColumn;
 OQuickListOfLong TempList;
 
 // query etc
 OCustomListModel ListMdlEtc;
 int LastSelectedRowEtc;
 
 // query payment
 OCustomListModel ListMdlPaymentCash;
 OCustomListModel ListMdlPaymentTransType;
 OCustomListModel ListMdlPaymentTransSubject;
 OCustomListModel ListMdlPaymentTransSalesman;
 OInstructionsTable InstPayment;
	
	// debt payment
	OCustomTableModel TableMdlDebtPayBillIn;
	OCustomTableModel TableMdlDebtPayBillOut;
	OInstructionsTable InstDebtPayTable;
	OInstructionsText InstDebtPayText;
	ODebtPaymentCalculator DebtPayCalculator;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 public F_QueryEtc(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // variables
  getIdentityOfTabResult();
  getIdentityOfTabQuery();
  Param=new OParam();
  Param.setParamCount(4); // Param.Object[] is used to pass value between this form and external process
  
  // tab Result Table
  TableMdlResult=new OCustomTableModel();
  TableMdlResult.emptyColumnsInfo();
  Tbl_Result.setModel(TableMdlResult);
  
  CmBMdlIdColumn=new OCustomComboBoxModel();
  CmBMdlIdColumn.setColumnsInfo(PCore.primArr(2, 1), 1);
  CmB_IdColumn.setModel(CmBMdlIdColumn);
  
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  updateTempListQuantity();
  
  // tab Result Text
  
  
  // tab Query Etc
  ListMdlEtc=new OCustomListModel(false);
   // string, OInstructions
  ListMdlEtc.setColumnsInfo(PCore.primArr(CCore.TypeInteger, 1, 1, 0), 1);
  List_QueryEtc.setModel(ListMdlEtc);
  ListMdlEtc.append(PMyShop.generateSimpleQueries());
  LastSelectedRowEtc=-1;
  
  // tab Query Payment
  ListMdlPaymentCash=new OCustomListModel(false);
  ListMdlPaymentCash.setColumnsInfo(PCore.primArr(2, 1), 1);
  List_PaymentCash.setModel(ListMdlPaymentCash);
  
  ListMdlPaymentTransType=new OCustomListModel(false);
  ListMdlPaymentTransType.setColumnsInfo(PCore.primArr(2, 1), 1);
  List_PaymentTransType.setModel(ListMdlPaymentTransType);
  
  ListMdlPaymentTransSubject=new OCustomListModel(false);
  ListMdlPaymentTransSubject.setColumnsInfo(PCore.primArr(3, 1), 1);
  List_PaymentTransSubject.setModel(ListMdlPaymentTransSubject);
  
  ListMdlPaymentTransSalesman=new OCustomListModel(false);
  ListMdlPaymentTransSalesman.setColumnsInfo(PCore.primArr(3, 1), 1);
  List_PaymentTransSalesman.setModel(ListMdlPaymentTransSalesman);
  
  InstPayment=PMyShop.instructionsForTable2(
   PCore.refArr("Tgl Bayar", "Id Tipe Trans", "Tipe Trans", "Id Trans", "{Id-Ext}", "Id Subjek", "Subjek", "Id Kas", "Kas Kredit", "Jumlah Byr", "Komentar Byr"),
   PCore.primArr(CCore.TypeDate, CCore.TypeInteger, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeInteger, CCore.TypeString, CCore.TypeDouble, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(11, OCustomTableModel.ShowOptionNormal), PCore.primArr(3), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(0, 2, 3, 4, 6, 8, 9, 10),
   PCore.primArr(CGUI.ColDate, CGUI.ColTextSml, CGUI.ColNum16, CGUI.ColNum16, CGUI.ColTextSml, CGUI.ColTextSml, CGUI.ColCur09_02, CGUI.ColTextMed),
   PCore.primArr(1, 3, 5, 7), PCore.primArr(false, false, false, false, false, false, false, false, false, true, false),
   new double[11], PCore.primArr(9), null);
  InstPayment.Next=PMyShop.instructionsForText2("Akumulasi jumlah pembayaran kredit pada hasil tabel adalah :");
		
		// tab Debt Payment
		TableMdlDebtPayBillIn=new OCustomTableModel();
		TableMdlDebtPayBillIn.setColumnsInfo(PCore.refArr("Tgl Tagih", "Jumlah", "Terlunasi"),
			PCore.primArr(CCore.TypeDate, CCore.TypeDouble, CCore.TypeDouble), PCore.primArr(0, 1, 2));
		Tbl_DebtPayIn.setModel(TableMdlDebtPayBillIn);
		PGUI.resizeTableColumn(Tbl_DebtPayIn, PCore.primArr(CGUI.ColDate, CGUI.ColCur09_02, CGUI.ColCur09_02));
		
		TableMdlDebtPayBillOut=new OCustomTableModel();
		TableMdlDebtPayBillOut.setColumnsInfo(PCore.refArr("Tgl Tagih", "Jumlah", "Terlunasi", "Cicil Awal", "Cicil Akhir"),
			PCore.primArr(CCore.TypeDate, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDate, CCore.TypeDate), PCore.primArr(0, 3, 4, 1, 2));
		Tbl_DebtPayOut.setModel(TableMdlDebtPayBillOut);
		PGUI.resizeTableColumn(Tbl_DebtPayOut, PCore.primArr(CGUI.ColDate, CGUI.ColDate, CGUI.ColDate, CGUI.ColCur09_02, CGUI.ColCur09_02));
		
		InstDebtPayText=PMyShop.instructionsForText2("");
		InstDebtPayTable=PMyShop.instructionsForTable3(
			PCore.newStringArray(10, ""),
			PCore.newIntegerArray(10, CCore.TypeString),
   PCore.newIntegerArray(10, OCustomTableModel.ShowOptionNormal),
			PCore.newIntegerArrayInOrderedSequence(10, 0, 1),
			PCore.primArr(CGUI.ColNum03, CGUI.ColDate, CGUI.ColCur09_02, CGUI.ColCur09_02, CGUI.ColCur09_02,
			 CGUI.ColCur09_02, CGUI.ColCur09_02, CGUI.ColCur09_02, CGUI.ColCur09_02 , CGUI.ColCur09_02),
			null, null);
		InstDebtPayText.Next=InstDebtPayTable;
		
		DebtPayCalculator=new ODebtPaymentCalculator();
		
		CmB_DebtPayInAddMethod.setSelectedIndex(3);
		CmB_DebtPayOutAddMethod.setSelectedIndex(3);
		
		PGUI.setDateComponent(PDate.calculateDateByDay(new Date(), 1, 2),
			TF_DebtPayCurrDateYear, CmB_DebtPayCurrDateMonth, CmB_DebtPayCurrDateDay);
  TF_DebtPayCurrSaving.setText(PText.doubleToString(0, true));
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
 }
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CmB_ChoosePayment,
    CB_PaymentTransId, TF_PaymentTransId,
    CB_PaymentComment, TF_PaymentComment,
    CB_PaymentDate, TF_PaymentStartYear, CmB_PaymentStartMonth, CmB_PaymentStartDay, TF_PaymentEndYear, CmB_PaymentEndMonth, CmB_PaymentEndDay,
    CB_PaymentPrice, TF_PaymentPrice1, TF_PaymentPrice2,
    CB_PaymentCash, CB_PaymentCashUndefined, List_PaymentCash, Btn_PaymentCashAdd, Btn_PaymentCashRemove,
    CB_PaymentTransType, CB_PaymentTransTypeUndefined, List_PaymentTransType, Btn_PaymentTransTypeAdd, Btn_PaymentTransTypeRemove,
    CB_PaymentTransSubject, CB_PaymentTransSubjectUndefined, List_PaymentTransSubject, Btn_PaymentTransSubjectAdd, Btn_PaymentTransSubjectRemove,
    CB_PaymentTransSalesman, CB_PaymentTransSalesmanUndefined, List_PaymentTransSalesman, Btn_PaymentTransSalesmanAdd, Btn_PaymentTransSalesmanRemove,
    
    TF_DebtPayCurrDateYear, CmB_DebtPayCurrDateMonth, CmB_DebtPayCurrDateDay,
    TF_DebtPayCurrSaving,
    Btn_DebtPayOutAdd, CmB_DebtPayOutAddMethod, Btn_DebtPayOutRemove, Btn_DebtPayOutEdit, Tbl_DebtPayOut,
    CB_BillsInWithAmountPaid, Btn_DebtPayInAdd, CmB_DebtPayInAddMethod, Btn_DebtPayInRemove, Btn_DebtPayInEdit, Tbl_DebtPayIn),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_QueryActionPerformed(null);
    }
   });
 }
 
 void clearComponents(){
  // cancel table editing
  Tbl_DebtPayIn.editingCanceled(null);
  Tbl_DebtPayOut.editingCanceled(null);
  
  // clear tabs result
  clearTabResults();
  TempList.removeAll();
  updateTempListQuantity();
  
  // clear tab query payment
  CB_PaymentTransId.setSelected(false); TF_PaymentTransId.setText("");
  CB_PaymentComment.setSelected(false); TF_PaymentComment.setText("");
  CB_PaymentDate.setSelected(false);
  CB_PaymentPrice.setSelected(false); TF_PaymentPrice1.setText(""); TF_PaymentPrice2.setText("");
  CB_PaymentCash.setSelected(false); CB_PaymentCashUndefined.setSelected(false); ListMdlPaymentCash.removeAll();
  CB_PaymentTransType.setSelected(false); CB_PaymentTransTypeUndefined.setSelected(false); ListMdlPaymentTransType.removeAll();
  CB_PaymentTransSubject.setSelected(false); CB_PaymentTransSubjectUndefined.setSelected(false); ListMdlPaymentTransSubject.removeAll();
  CB_PaymentTransSalesman.setSelected(false); CB_PaymentTransSalesmanUndefined.setSelected(false); ListMdlPaymentTransSalesman.removeAll();
		
		/* clear tab debt payment 
		TF_DebtPayCurrDateYear.setText("");
		TF_DebtPayCurrSaving.setText(PText.doubleToString(0, true));
		TableMdlDebtPayBillIn.removeAll();
		TableMdlDebtPayBillOut.removeAll();
		*/
 }
 public OParam getParameters(){return Param;}
 public Statement getStatement(){return IFV.Stm;}
 public JCheckBox getTableResultSign(){return CB_ResultSignTable;}
 public JTable getTable(){return Tbl_Result;}
 public JTextField getTableCount(){return TF_TableResultCount;}
 public JComboBox getTableIdColumn(){return CmB_IdColumn;}
 public JCheckBox getTextResultSign(){return CB_ResultSignText;}
 public JTextArea getText(){return TA_Result;}
 
 void onSelectedRowEtcChanged(){
  int row=List_QueryEtc.getSelectedIndex();
  if(row!=LastSelectedRowEtc){
   LastSelectedRowEtc=row;
   if(row!=-1){fillEtc(row);}
   else{clearEtc();}
  }
 }
 
 void clearTabResults(){
  // result table
  TableMdlResult.emptyColumnsInfo();
  TF_TableResultCount.setText("");
  CmBMdlIdColumn.removeAll();
  CmB_IdColumn.setSelectedIndex(-1);
  
  // result text
  TA_Result.setText("");
  
  // results's sign
  CB_ResultSignTable.setSelected(false);
  CB_ResultSignText.setSelected(false);
 }
 
 void fillEtc(int Row){
  TA_QueryEtcInfo.setText((String)ListMdlEtc.Mdl.Rows.elementAt(Row)[2]);
 }
 void clearEtc(){
  TA_QueryEtcInfo.setText("");
 }
 
 void updateTempListQuantity(){
  TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));
 }
 int checkIdColumn(){
  int ret=-1; // -1 no data or unvalid column id, >=0 valid column id
  int temp;
  
  temp=CmB_IdColumn.getSelectedIndex();
  if(temp!=-1){ret=(Integer)(CmBMdlIdColumn.Mdl.Rows.elementAt(temp)[0]);}
  if(ret==-1){
   JOptionPane.showMessageDialog(null, "Tidak dapat menambah ke 'Daftarku' !\nSilahkan memilih sebuah 'Kolom Id' yang valid !");
  }
  return ret;
 }
 
 void getIdentityOfTabQuery(){
  int temp, tabcount;
  String TabTitle;
  
  // tab 0 = what query ?
  tabcount=TabbedPane_Query.getTabCount();
  TabQuery=new int[tabcount];
  temp=0;
  do{
   TabTitle=TabbedPane_Query.getTitleAt(temp);
   do{
    if(PText.compare(TabTitle, "Lain", false)){TabQuery[temp]=0; break;}
    if(PText.compare(TabTitle, "Pembayaran", false)){TabQuery[temp]=301; break;}
				if(PText.compare(TabTitle, "Cicil Utang", false)){TabQuery[temp]=302; break;}
   }while(false);
   temp=temp+1;
  }while(temp!=tabcount);
 }
 void getIdentityOfTabResult(){
  int temp, tabcount;
  String TabTitle;
  
  // tab 0 = what result ?
  tabcount=TabbedPane_Result.getTabCount();
  TabResult=new int[tabcount];
  temp=0;
  do{
   TabTitle=TabbedPane_Result.getTitleAt(temp);
   do{
    if(PText.compare(TabTitle, "Teks", false)){TabResult[temp]=OInstructionsText.InstructionsType; break;}
    if(PText.compare(TabTitle, "Tabel", false)){TabResult[temp]=OInstructionsTable.InstructionsType; break;}
   }while(false);
   temp=temp+1;
  }while(temp!=tabcount);
 }
 void processQuery(){
  OInstructions Inst=null;
  boolean success;
  
  // validate input
  switch(TabQuery[TabbedPane_Query.getSelectedIndex()]){
   case 0   : Inst=prepareQueryEtc(); break;
   case 301 : Inst=prepareQueryPayment(); break;
			case 302 : Inst=prepareQueryDebtPayment(); break;
  }
  if(Inst==null){return;}
  
  // process query
  IFV.FSplashScreen.appear(this, "Memproses Query");
  IFV.FSplashScreen.inform(0, "Sedang memproses (harap menunggu)...", "-");
  
  clearTabResults(); success=true;
  try{
   Inst.executeChainedInstructions(this);
   
   // show result tab
   switch(Inst.getInstructionsType()){
    case OInstructionsText.InstructionsType:
     TabbedPane_Result.setSelectedIndex(PCore.findAValueInArray(TabResult, OInstructionsText.InstructionsType, 0));
     break;
    case OInstructionsTable.InstructionsType:
     TabbedPane_Result.setSelectedIndex(PCore.findAValueInArray(TabResult, OInstructionsTable.InstructionsType, 0));
     break;
   }
  }
  catch(Exception E){success=false;}
  
  IFV.FSplashScreen.disappear();
  
  if(!success){JOptionPane.showMessageDialog(null, "Terjadi kegagalan ketika memproses data !");}
 }
 OInstructions prepareQueryEtc(){
  OInstructions ret=null;
  int temp, QueryId;
  boolean allow;
  Object[] objs;
  
  temp=List_QueryEtc.getSelectedIndex();
  if(temp==-1){
   JOptionPane.showMessageDialog(null, "Silahkan memilih sebuah daftar pada 'Daftar Pencarian Lain' !");
   return ret;
  }
  
  objs=ListMdlEtc.Mdl.Rows.elementAt(temp);
  
  allow=false;
  do{
   QueryId=PCore.objInteger(objs[0], -1);
   
   if(!IFV.PrivGUIShowBuyPrice){
    if(QueryId==4001 || QueryId==4002 || (QueryId>=4101 && QueryId<=4104)){break;}
   }
   
   allow=true;
  }while(false);
  
  if(!IFV.canAccessGUI(3, true, allow)){return ret;}
  
  ret=(OInstructions)objs[3];
  
  return ret;
 }
 OInstructions prepareQueryPayment(){
  OInstructions ret=null;
  String TblTrans=null;
  String TblPay=null;
  boolean bool, defined;
  
  boolean isempty1, isempty2, confirst;
  String str, str1, str2;
  Double dbl1, dbl2;
  Date dt1, dt2;
  StringBuilder con=null;
  
  // check input
  bool=false;
  do{
   if(CB_PaymentTransId.isSelected()){
    if(!PText.checkInput(TF_PaymentTransId.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_PaymentComment.isSelected()){
    if(!PText.checkInput(TF_PaymentComment.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_PaymentDate.isSelected()){
    dt1=PGUI.valueOfDateComponent(TF_PaymentStartYear, CmB_PaymentStartMonth, CmB_PaymentStartDay);
    dt2=PGUI.valueOfDateComponent(TF_PaymentEndYear, CmB_PaymentEndMonth, CmB_PaymentEndDay);
    if(dt1==null && dt2==null){break;}
   }
   if(CB_PaymentPrice.isSelected()){
    str1=TF_PaymentPrice1.getText(); str2=TF_PaymentPrice2.getText();
    isempty1=PText.isEmptyString(str1, true, true); dbl1=PText.parseDouble(str1, null, null, true, true, false, 0, 0); if(!isempty1 && dbl1==null){break;}
    isempty2=PText.isEmptyString(str2, true, true); dbl2=PText.parseDouble(str2, null, null, true, true, false, 0, 0); if(!isempty2 && dbl2==null){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_PaymentCash.isSelected()){
    if(!CB_PaymentCashUndefined.isSelected() && ListMdlPaymentCash.getSize()==0){break;}
   }
   if(CB_PaymentTransType.isSelected()){
    if(!CB_PaymentTransTypeUndefined.isSelected() && ListMdlPaymentTransType.getSize()==0){break;}
   }
   if(CB_PaymentTransSubject.isSelected()){
    if(!CB_PaymentTransSubjectUndefined.isSelected() && ListMdlPaymentTransSubject.getSize()==0){break;}
   }
   if(CB_PaymentTransSalesman.isSelected()){
    if(!CB_PaymentTransSalesmanUndefined.isSelected() && ListMdlPaymentTransSalesman.getSize()==0){break;}
   }
   
   bool=true;
  }while(false);
  if(!bool){
   JOptionPane.showMessageDialog(null, "Masukan masih salah / tidak lengkap !");
   return ret;
  }
  
  // build condition
  con=new StringBuilder();
  switch(CmB_ChoosePayment.getSelectedIndex()){
   case 0 : // payment out of transactions
    TblTrans="Trans";
    TblPay="TransXPayment";
    break;
   case 1 : // payment in of transactions
    TblTrans="Trans";
    TblPay="TransXPaymentIn";
    break;
   case 2 : // payment out of pre-transactions
    TblTrans="PreTrans";
    TblPay="PreTransXPayment";
    break;
   case 3 : // payment in of pre-transactions
    TblTrans="PreTrans";
    TblPay="PreTransXPaymentIn";
    break;
  }
  if(CB_PaymentTransId.isSelected()){
   con.append(" and");
   
   str=TF_PaymentTransId.getText();
   con.append(" ("+PSql.genCheckWord("cast("+TblTrans+".Id as char(16))", str, true, true)+" or "+
    PSql.genCheckWord(TblTrans+".InfoIdExternal", str, true, true)+")");
  }
  if(CB_PaymentComment.isSelected()){
   con.append(" and");
   
   con.append(" "+PSql.genCheckWord(TblPay+".Comment", TF_PaymentComment.getText(), true, true));
  }
  if(CB_PaymentDate.isSelected()){
   con.append(" and");
   
   dt1=PGUI.valueOfDateComponent(TF_PaymentStartYear, CmB_PaymentStartMonth, CmB_PaymentStartDay);
   dt2=PGUI.valueOfDateComponent(TF_PaymentEndYear, CmB_PaymentEndMonth, CmB_PaymentEndDay);
   con.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{con.append(" and");}
    con.append(" PaymentDate>=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{con.append(" and");}
    con.append(" PaymentDate<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   con.append(")");
  }
  if(CB_PaymentPrice.isSelected()){
   con.append(" and");
   
   dbl1=PText.parseDouble(TF_PaymentPrice1.getText(), null, null); dbl2=PText.parseDouble(TF_PaymentPrice2.getText(), null, null);
   con.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{con.append(" and");}
    con.append(" Price>="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{con.append(" and");}
    con.append(" Price<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   con.append(")");
  }
  if(CB_PaymentCash.isSelected()){
   con.append(" and");
   con.append(" (");
   defined=false;
   if(ListMdlPaymentCash.getSize()!=0){
    con.append(" "+TblPay+".Cash in ("+PGUI.getElementList(ListMdlPaymentCash.Mdl.Rows, 0, ",", "", false)+")");
    defined=true;
   }
   if(CB_PaymentCashUndefined.isSelected()){
    if(defined){con.append(" or");}
    con.append(" "+TblPay+".Cash is "+CCore.vNull);
   }
   con.append(")");
  }
  if(CB_PaymentTransType.isSelected()){
   con.append(" and");
   con.append(" (");
   defined=false;
   if(ListMdlPaymentTransType.getSize()!=0){
    con.append(" TransType in ("+PGUI.getElementList(ListMdlPaymentTransType.Mdl.Rows, 0, ",", "", false)+")");
    defined=true;
   }
   if(CB_PaymentTransTypeUndefined.isSelected()){
    if(defined){con.append(" or");}
    con.append(" TransType is "+CCore.vNull);
   }
   con.append(")");
  }
  if(CB_PaymentTransSubject.isSelected()){
   con.append(" and");
   con.append(" (");
   defined=false;
   if(ListMdlPaymentTransSubject.getSize()!=0){
    con.append(" Subject in ("+PGUI.getElementList(ListMdlPaymentTransSubject.Mdl.Rows, 0, ",", "", false)+")");
    defined=true;
   }
   if(CB_PaymentTransSubjectUndefined.isSelected()){
    if(defined){con.append(" or");}
    con.append(" Subject is "+CCore.vNull);
   }
   con.append(")");
  }
  if(CB_PaymentTransSalesman.isSelected()){
   con.append(" and");
   con.append(" (");
   defined=false;
   if(ListMdlPaymentTransSalesman.getSize()!=0){
    con.append(" Salesman in ("+PGUI.getElementList(ListMdlPaymentTransSalesman.Mdl.Rows, 0, ",", "", false)+")");
    defined=true;
   }
   if(CB_PaymentTransSalesmanUndefined.isSelected()){
    if(defined){con.append(" or");}
    con.append(" Salesman is "+CCore.vNull);
   }
   con.append(")");
  }
   
  /*
   the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
   because there can be ambiguous column name, if other additional tables have the same column name as static tables

   for example :
   "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
   ~ should be changed into
   "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
   ~ to prevent ambiguous interpretation of column name between static table & additional table
  */
  
  // return OInstructions
  InstPayment.SqlQuery=
   "select PaymentDate, TransType, TransType.Name, "+TblTrans+", InfoIdExternal, Subject, Subject.Name, Cash, Cash.Name, Price, tb1.Comment from "+
    "(select "+TblPay+".PaymentDate, "+TblTrans+".TransType, "+TblPay+"."+TblTrans+", "+TblTrans+".InfoIdExternal, "+TblTrans+".Subject, "+TblPay+".Cash, "+TblPay+".Price, "+TblPay+".Comment from "+TblPay+
     ", "+TblTrans+" where "+TblPay+"."+TblTrans+"="+TblTrans+".Id"+con.toString()+") as tb1 "+
   "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id left join Cash on tb1.Cash=Cash.Id " +
   "order by PaymentDate desc, TransType.Name asc, tb1."+TblTrans+" desc;";
  ret=InstPayment;
  
  return ret;
 }
	OInstructions prepareQueryDebtPayment(){
		OInstructions ret=null;
		OValidation IsValid;
		
		Date CalcDate=null;
		Double SavingAmount;
		
		String str;
		
		Vector<Object[]> BillsOut=TableMdlDebtPayBillOut.Mdl.Rows;
		Vector<Object[]> BillsIn=TableMdlDebtPayBillIn.Mdl.Rows;
		
		Object[] Result;
		
		IsValid=new OValidation(true);
		
		// first phase validation
		CalcDate=PGUI.valueOfDateComponent(TF_DebtPayCurrDateYear, CmB_DebtPayCurrDateMonth, CmB_DebtPayCurrDateDay);
		if(CalcDate==null){IsValid.addError("\n- Inputan 'Akhir Hari' belum benar.");}
		
		SavingAmount=PText.parseDouble(TF_DebtPayCurrSaving.getText(), null, null, true, true, false, 0, 0);
		if(SavingAmount==null){IsValid.addError("\n- Inputan 'Saldo Kas Pada Akhir Hari' belum benar.");}
		
		if(BillsOut.size()==0){IsValid.addError("\n- Data 'Tagihan Utang' tdk boleh kosong.");}
		
		// second phase validation
		if(IsValid.getValid()){
			/* check if 'Calc Date' < 'Bill Out's Smallest Repay Period End'
			dt=PTable.getMinMaxDate(true, BillsOut, 4);
			if(PDate.grading(CalcDate, dt, Long.MIN_VALUE)!=2){IsValid.addError("\n- Inputan 'Akhir Hari' harus sebelum tanggal terkecil 'Cicil Akhir' dari 'Tagihan Utang'.");}
		 */
  }
		
		if(!IsValid.getValid()){
			JOptionPane.showMessageDialog(null, "Inputan belum benar / lengkap !\n"+IsValid.getError());
			return ret;
		}
		
		Result=DebtPayCalculator.calculate(CalcDate, SavingAmount, BillsOut, 0, 1, 2, 3, 4, BillsIn, 0, 1, 2, CB_BillsInWithAmountPaid.isSelected());
		if(Result==null){JOptionPane.showMessageDialog(null, "Gagal menghitung cicilan harian utk melunasi utang !"); return ret;}
		InstDebtPayText.ForeText=(String)Result[0];
		InstDebtPayTable.CustomTableData=(Vector<Object[]>)Result[1];
		ret=InstDebtPayText;
		
		return ret;
	}
 String queryOfTransBillsIn(boolean IsPreTrans, long[] TransType, boolean TransTypeEmpty){
  StringBuilder sourcetable, con, conpost;
  boolean con_defined, conpost_defined;
  boolean list_defined;
  String TblTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  
  sourcetable=new StringBuilder();
  con=new StringBuilder(); con_defined=false;
  conpost=new StringBuilder(); conpost_defined=false;
  
  if(!conpost_defined){conpost_defined=true; conpost.append(" having");}else{conpost.append(" and");}
		conpost.append(" ifnull(PriceItemOut,0)+ifnull(PricePaymentOut,0)>ifnull(PriceItemIn,0)+ifnull(PricePaymentIn,0)");
  
  if(!con_defined){con_defined=true; con.append(" where");}else{con.append(" and");}
  con.append(" (");
  list_defined=false;
  if(TransType.length!=0){
   con.append(" "+TblTrans+".TransType in ("+PText.toString(TransType, 0, TransType.length, ",")+")"); list_defined=true;
  }
  if(TransTypeEmpty){
   if(list_defined){con.append(" or");} con.append(" "+TblTrans+".TransType is "+CCore.vNull);
  }
  con.append(")");
  
  return queryOfTransBills(IsPreTrans, sourcetable.toString(), con.toString(), conpost.toString());
 }
 String queryOfTransBillsOut(boolean IsPreTrans, long[] TransType, boolean TransTypeEmpty){
  StringBuilder sourcetable, con, conpost;
  boolean con_defined, conpost_defined;
  boolean list_defined;
  String TblTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  
  sourcetable=new StringBuilder();
  con=new StringBuilder(); con_defined=false;
  conpost=new StringBuilder(); conpost_defined=false;
  
  if(!conpost_defined){conpost_defined=true; conpost.append(" having");}else{conpost.append(" and");}
		conpost.append(" ifnull(PriceItemIn,0)+ifnull(PricePaymentIn,0)>ifnull(PriceItemOut,0)+ifnull(PricePaymentOut,0)");
  
  if(!con_defined){con_defined=true; con.append(" where");}else{con.append(" and");}
  con.append(" (");
  list_defined=false;
  if(TransType.length!=0){
   con.append(" "+TblTrans+".TransType in ("+PText.toString(TransType, 0, TransType.length, ",")+")"); list_defined=true;
  }
  if(TransTypeEmpty){
   if(list_defined){con.append(" or");} con.append(" "+TblTrans+".TransType is "+CCore.vNull);
  }
  con.append(")");
  
  return queryOfTransBills(IsPreTrans, sourcetable.toString(), con.toString(), conpost.toString());
 }
 String queryOfTransBills(boolean IsPreTrans, String SourceTable, String Condition, String PostCondition){
  String TblTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans");
  return
   "select tb5.T_Id, tb5.*, Sum("+TblTrans+"XPaymentIn.Price) as 'PricePaymentIn' from "+
    "(select tb4.*, Sum("+TblTrans+"XPayment.Price) as 'PricePaymentOut' from "+
     "(select tb3.*, Sum(tb3.ItemOut_Price) as 'PriceItemOut', Sum(tb3.ItemOut_Stock*BuyPriceEstimation) as 'BasicPriceItemOut' from "+
      "(select tb2.*, "+TblTrans+"XItemOut.Item as 'ItemOut_Item', "+TblTrans+"XItemOut.Stock as 'ItemOut_Stock', "+TblTrans+"XItemOut.Price as 'ItemOut_Price' from "+
        "(select tb1.*, Sum("+TblTrans+"XItemIn.Price) as 'PriceItemIn' from "+
         "(select "+TblTrans+".*, "+TblTrans+".Id as 'T_Id' from "+TblTrans+SourceTable+Condition+") as tb1 "+
        "left join "+TblTrans+"XItemIn on tb1.Id="+TblTrans+"XItemIn."+TblTrans+" group by tb1.Id) as tb2 "+
      "left join "+TblTrans+"XItemOut on tb2.Id="+TblTrans+"XItemOut."+TblTrans+") as tb3 "+
     "left join Item on tb3.ItemOut_Item=Item.Id group by tb3.Id) as tb4 "+
    "left join "+TblTrans+"XPayment on tb4.Id="+TblTrans+"XPayment."+TblTrans+" group by tb4.Id) as tb5 "+
   "left join "+TblTrans+"XPaymentIn on tb5.Id="+TblTrans+"XPaymentIn."+TblTrans+" group by tb5.Id "+
   PostCondition;
 }
	void DebtPayAdd(boolean In){
		JComboBox CmB_AddMethod;
		OCustomTableModel TableMdl;
		String BillName;
		Vector<Object[]> TableMdlRows;
		Vector<Object[]> NewBills=null;
		Vector<Object[]> NewBills_1, NewBills_2;
  Long[] Ids;
		int temp, length;
		Object[] Bill;
		
		if(In){CmB_AddMethod=CmB_DebtPayInAddMethod; TableMdl=TableMdlDebtPayBillIn; BillName="Piutang";}
		else{CmB_AddMethod=CmB_DebtPayOutAddMethod; TableMdl=TableMdlDebtPayBillOut; BillName="Utang";}
		TableMdlRows=TableMdl.getRows();
		
		if(In){
			switch(CmB_AddMethod.getSelectedIndex()){
				case 0 :
     IFV.FBillInModify.wMode=1;
					if(IFV.FBillInModify.showForm()==false){return;} if(IFV.FBillInModify.DialogResult!=1){return;}
					NewBills=new Vector();
     NewBills.addElement(PCore.objArrVariant(IFV.FBillInModify.BillDate, IFV.FBillInModify.BillAmount, IFV.FBillInModify.BillAmountPaid));
					break;
				case 1 :
     IFV.FTransView.wIsViewMode=false; IFV.FTransView.wAllowMultipleSelection=true;
					if(IFV.FTransView.showForm()==false){return;} if(IFV.FTransView.DialogResult!=1){return;}
					NewBills=PMyShop.getBillsInFromTrans(IFV.Stm, IFV.FTransView.ChoosedId, false);
					break;
				case 2 :
     IFV.FPreTransView.wIsViewMode=false; IFV.FPreTransView.wAllowMultipleSelection=true;
					if(IFV.FPreTransView.showForm()==false){return;} if(IFV.FPreTransView.DialogResult!=1){return;}
					NewBills=PMyShop.getBillsInFromTrans(IFV.Stm, IFV.FPreTransView.ChoosedId, true);
					break;
				case 3 :
     if(IFV.FBillInAddAuto.showForm()==false){return;} if(IFV.FBillInAddAuto.DialogResult!=1){return;}
					
     Ids=PCore.refArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm,
      queryOfTransBillsIn(false, IFV.FBillInAddAuto.TransType, IFV.FBillInAddAuto.TransTypeEmpty),
      CCore.TypeLong, false, null));
     NewBills_1=PMyShop.getBillsInFromTrans(IFV.Stm, Ids, false);
     
     Ids=PCore.refArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm,
      queryOfTransBillsIn(true, IFV.FBillInAddAuto.TransType, IFV.FBillInAddAuto.TransTypeEmpty),
      CCore.TypeLong, false, null));
     NewBills_2=PMyShop.getBillsInFromTrans(IFV.Stm, Ids, true);
     
     NewBills=null; if(NewBills_1!=null && NewBills_2!=null){NewBills=PCore.concat(NewBills_1, NewBills_2);}
     
					break;
			}
		}
		else{
			switch(CmB_AddMethod.getSelectedIndex()){
				case 0 :
     IFV.FBillOutModify.wMode=1;
					if(IFV.FBillOutModify.showForm()==false){return;} if(IFV.FBillOutModify.DialogResult!=1){return;}
					NewBills=new Vector();
					NewBills.addElement(PCore.objArrVariant(IFV.FBillOutModify.BillDate, IFV.FBillOutModify.BillAmount, IFV.FBillOutModify.BillAmountPaid,
						IFV.FBillOutModify.RepayPeriodStart, IFV.FBillOutModify.RepayPeriodEnd));
					break;
				case 1 :
     IFV.FTransView.wIsViewMode=false; IFV.FTransView.wAllowMultipleSelection=true;
					if(IFV.FTransView.showForm()==false){return;} if(IFV.FTransView.DialogResult!=1){return;}
					NewBills=PMyShop.getBillsOutFromTrans(IFV.Stm, IFV.FTransView.ChoosedId, false);
					break;
				case 2 :
     IFV.FPreTransView.wIsViewMode=false; IFV.FPreTransView.wAllowMultipleSelection=true;
					if(IFV.FPreTransView.showForm()==false){return;} if(IFV.FPreTransView.DialogResult!=1){return;}
					NewBills=PMyShop.getBillsOutFromTrans(IFV.Stm, IFV.FPreTransView.ChoosedId, true);
					break;
				case 3 :
     if(IFV.FBillOutAddAuto.showForm()==false){return;} if(IFV.FBillOutAddAuto.DialogResult!=1){return;}
					
     Ids=PCore.refArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm,
      queryOfTransBillsOut(false, IFV.FBillOutAddAuto.TransType, IFV.FBillOutAddAuto.TransTypeEmpty),
      CCore.TypeLong, false, null));
     NewBills_1=PMyShop.getBillsOutFromTrans(IFV.Stm, Ids, false);
     
     Ids=PCore.refArrLong_VectObj(PDatabase.getListFromQuery(IFV.Stm,
      queryOfTransBillsOut(true, IFV.FBillOutAddAuto.TransType, IFV.FBillOutAddAuto.TransTypeEmpty),
      CCore.TypeLong, false, null));
     NewBills_2=PMyShop.getBillsOutFromTrans(IFV.Stm, Ids, true);
     
     NewBills=null; if(NewBills_1!=null && NewBills_2!=null){NewBills=PCore.concat(NewBills_1, NewBills_2);}
     
					break;
			}
		}
		if(NewBills==null){JOptionPane.showMessageDialog(null, "Terjadi error ketika memproses pengambilan data 'Tagihan "+BillName+"' !"); return;}
		
		length=NewBills.size();
		if(length==0){return;}
		
		temp=0;
		do{
			Bill=NewBills.elementAt(temp);
			TableMdl.insert(PTable.findInsertPos(TableMdlRows, 0, (Date)Bill[0], true, false, true), Bill);
			temp=temp+1;
		}while(temp!=length);
	}
	void DebtPayEdit(boolean In){
		JTable Tbl;
		OCustomTableModel TableMdl;
		Vector<Object[]> TableMdlRows;
		int[] rows;
		Object[] Bill=null;
		
		if(In){Tbl=Tbl_DebtPayIn; TableMdl=TableMdlDebtPayBillIn;}
		else{Tbl=Tbl_DebtPayOut; TableMdl=TableMdlDebtPayBillOut;}
		TableMdlRows=TableMdl.getRows();
		
		rows=Tbl.getSelectedRows();
		if(rows.length==0){return;}
		if(rows.length>1){JOptionPane.showMessageDialog(null, "Pilihan jamak tidak diperbolehkan utk operasi ini !"); return;}
		
		Bill=TableMdlRows.elementAt(rows[0]);
		if(In){
			IFV.FBillInModify.wBillDate=(Date)Bill[0];
			IFV.FBillInModify.wBillAmount=(Double)Bill[1];
			IFV.FBillInModify.wBillAmountPaid=(Double)Bill[2];
			IFV.FBillInModify.wMode=2;
			if(IFV.FBillInModify.showForm()==false){return;} if(IFV.FBillInModify.DialogResult!=1){return;}
			Bill=PCore.objArrVariant(IFV.FBillInModify.BillDate, IFV.FBillInModify.BillAmount, IFV.FBillInModify.BillAmountPaid);
		}
		else{
			IFV.FBillOutModify.wBillDate=(Date)Bill[0];
			IFV.FBillOutModify.wBillAmount=(Double)Bill[1];
			IFV.FBillOutModify.wBillAmountPaid=(Double)Bill[2];
			IFV.FBillOutModify.wRepayPeriodStart=(Date)Bill[3];
			IFV.FBillOutModify.wRepayPeriodEnd=(Date)Bill[4];
			IFV.FBillOutModify.wMode=2;
			if(IFV.FBillOutModify.showForm()==false){return;} if(IFV.FBillOutModify.DialogResult!=1){return;}
			Bill=PCore.objArrVariant(IFV.FBillOutModify.BillDate, IFV.FBillOutModify.BillAmount, IFV.FBillOutModify.BillAmountPaid,
				IFV.FBillOutModify.RepayPeriodStart, IFV.FBillOutModify.RepayPeriodEnd);
		}
		
		TableMdl.remove(rows[0]);
		TableMdl.insert(PTable.findInsertPos(TableMdlRows, 0, (Date)Bill[0], true, false, true), Bill);
	}
	void DebtPayRemove(boolean In){
		JTable Tbl;
		OCustomTableModel TableMdl;
		String BillName;
		int[] rows;
		
		if(In){Tbl=Tbl_DebtPayIn; TableMdl=TableMdlDebtPayBillIn; BillName="Piutang";}
		else{Tbl=Tbl_DebtPayOut; TableMdl=TableMdlDebtPayBillOut; BillName="Utang";}
		
		rows=Tbl.getSelectedRows();
		if(rows.length==0){return;}
		if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" 'Tagihan "+BillName+"' yg dipilih ?",
			"Konfirmasi Penghapusan 'Tagihan "+BillName+"'", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
		TableMdl.remove(rows);
	}
 
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
  }
 }
 void queryOnKeyPressed_TextRange1(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF1.getCaretPosition()==QTF1.getDocument().getLength()){
     QTF2.requestFocusInWindow();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange2(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_LEFT:
    if(QTF2.getCaretPosition()==0){
     QTF1.requestFocusInWindow();
    }
    break;
  }
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }
 
 //
 void focusQueryResult(){
  
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TabbedPane_Query = new javax.swing.JTabbedPane();
  Panel_QueryPayment = new javax.swing.JPanel();
  TF_PaymentTransId = new javax.swing.JTextField();
  Lbl_PaymentTransIdHelp = new javax.swing.JLabel();
  CB_PaymentTransId = new javax.swing.JCheckBox();
  CB_PaymentDate = new javax.swing.JCheckBox();
  CmB_PaymentStartDay = new javax.swing.JComboBox<>();
  CmB_PaymentStartMonth = new javax.swing.JComboBox<>();
  TF_PaymentStartYear = new javax.swing.JTextField();
  TF_PaymentEndYear = new javax.swing.JTextField();
  CmB_PaymentEndMonth = new javax.swing.JComboBox<>();
  CmB_PaymentEndDay = new javax.swing.JComboBox<>();
  TF_PaymentComment = new javax.swing.JTextField();
  CB_PaymentComment = new javax.swing.JCheckBox();
  Lbl_PaymentCommentHelp = new javax.swing.JLabel();
  CB_PaymentPrice = new javax.swing.JCheckBox();
  TF_PaymentPrice1 = new javax.swing.JTextField();
  Lbl_PaymentPriceHelp = new javax.swing.JLabel();
  CB_PaymentTransType = new javax.swing.JCheckBox();
  Btn_PaymentTransTypeAdd = new javax.swing.JButton();
  Btn_PaymentTransTypeRemove = new javax.swing.JButton();
  CB_PaymentTransSubject = new javax.swing.JCheckBox();
  Btn_PaymentTransSubjectAdd = new javax.swing.JButton();
  Btn_PaymentTransSubjectRemove = new javax.swing.JButton();
  CB_PaymentTransSalesman = new javax.swing.JCheckBox();
  Btn_PaymentTransSalesmanAdd = new javax.swing.JButton();
  Btn_PaymentTransSalesmanRemove = new javax.swing.JButton();
  CmB_ChoosePayment = new javax.swing.JComboBox<>();
  Lbl_ChoosePayment = new javax.swing.JLabel();
  jLabel1 = new javax.swing.JLabel();
  Btn_PaymentCashAdd = new javax.swing.JButton();
  Btn_PaymentCashRemove = new javax.swing.JButton();
  jLabel3 = new javax.swing.JLabel();
  TF_PaymentPrice2 = new javax.swing.JTextField();
  CB_PaymentTransTypeUndefined = new javax.swing.JCheckBox();
  CB_PaymentTransSubjectUndefined = new javax.swing.JCheckBox();
  CB_PaymentTransSalesmanUndefined = new javax.swing.JCheckBox();
  CB_PaymentCash = new javax.swing.JCheckBox();
  CB_PaymentCashUndefined = new javax.swing.JCheckBox();
  jScrollPane2 = new javax.swing.JScrollPane();
  List_PaymentCash = new XList();
  jScrollPane8 = new javax.swing.JScrollPane();
  List_PaymentTransType = new XList();
  jScrollPane4 = new javax.swing.JScrollPane();
  List_PaymentTransSubject = new XList();
  jScrollPane5 = new javax.swing.JScrollPane();
  List_PaymentTransSalesman = new XList();
  Panel_DebtPayment = new javax.swing.JPanel();
  Lbl_DebtPayCurrDate = new javax.swing.JLabel();
  CmB_DebtPayCurrDateDay = new javax.swing.JComboBox<>();
  CmB_DebtPayCurrDateMonth = new javax.swing.JComboBox<>();
  TF_DebtPayCurrDateYear = new javax.swing.JTextField();
  TF_DebtPayCurrSaving = new javax.swing.JTextField();
  Lbl_DebtPayAlreadySavingHelp = new javax.swing.JLabel();
  Lbl_DebtPayCurrSaving = new javax.swing.JLabel();
  jPanel2 = new javax.swing.JPanel();
  Btn_DebtPayOutEdit = new javax.swing.JButton();
  Btn_DebtPayOutRemove = new javax.swing.JButton();
  Btn_DebtPayOutAdd = new javax.swing.JButton();
  jLabel8 = new javax.swing.JLabel();
  CmB_DebtPayOutAddMethod = new javax.swing.JComboBox<>();
  Lbl_DebtPayOutHelp = new javax.swing.JLabel();
  jPanel3 = new javax.swing.JPanel();
  Btn_DebtPayInEdit = new javax.swing.JButton();
  Btn_DebtPayInRemove = new javax.swing.JButton();
  Btn_DebtPayInAdd = new javax.swing.JButton();
  jLabel9 = new javax.swing.JLabel();
  CmB_DebtPayInAddMethod = new javax.swing.JComboBox<>();
  Lbl_DebtPayInHelp = new javax.swing.JLabel();
  CB_BillsInWithAmountPaid = new javax.swing.JCheckBox();
  Lbl_DebtPayCurrDateHelp = new javax.swing.JLabel();
  Lbl_DebtPayCalculator = new javax.swing.JLabel();
  jScrollPane11 = new javax.swing.JScrollPane();
  Tbl_DebtPayOut = new XTable();
  jScrollPane9 = new javax.swing.JScrollPane();
  Tbl_DebtPayIn = new XTable();
  Panel_QueryEtc = new javax.swing.JPanel();
  jScrollPane7 = new javax.swing.JScrollPane();
  TA_QueryEtcInfo = new javax.swing.JTextArea();
  jScrollPane1 = new javax.swing.JScrollPane();
  List_QueryEtc = new XList();
  TabbedPane_Result = new javax.swing.JTabbedPane();
  Panel_ResultTable = new javax.swing.JPanel();
  Panel_ResultTableStatus = new javax.swing.JPanel();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel2 = new javax.swing.JLabel();
  TF_TableResultCount = new javax.swing.JTextField();
  CmB_IdColumn = new javax.swing.JComboBox<>();
  Btn_TempListClear = new javax.swing.JButton();
  jScrollPane10 = new javax.swing.JScrollPane();
  Tbl_Result = new XTable();
  Panel_ResultText = new javax.swing.JPanel();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_Result = new javax.swing.JTextArea();
  jPanel1 = new javax.swing.JPanel();
  Lbl_Result = new javax.swing.JLabel();
  CB_ResultSignTable = new javax.swing.JCheckBox();
  CB_ResultSignText = new javax.swing.JCheckBox();
  jPanel4 = new javax.swing.JPanel();
  Btn_Query = new javax.swing.JButton();
  Label_Query = new javax.swing.JLabel();

  setTitle("Kustom Query ( {Esc} untuk keluar)");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TabbedPane_Query.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);

  Panel_QueryPayment.setName("Payment"); // NOI18N

  TF_PaymentTransId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaymentTransIdFocusGained(evt);
   }
  });
  TF_PaymentTransId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaymentTransIdKeyPressed(evt);
   }
  });

  Lbl_PaymentTransIdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PaymentTransIdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_PaymentTransIdHelp.setText("(?)");
  Lbl_PaymentTransIdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_PaymentTransIdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PaymentTransIdHelpMouseClicked(evt);
   }
  });

  CB_PaymentTransId.setText("Id & {Ext}");
  CB_PaymentTransId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransIdKeyPressed(evt);
   }
  });

  CB_PaymentDate.setText("Rentang");
  CB_PaymentDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentDateKeyPressed(evt);
   }
  });

  CmB_PaymentStartDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_PaymentStartDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PaymentStartDayKeyPressed(evt);
   }
  });

  CmB_PaymentStartMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_PaymentStartMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PaymentStartMonthKeyPressed(evt);
   }
  });

  TF_PaymentStartYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaymentStartYearFocusGained(evt);
   }
  });
  TF_PaymentStartYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaymentStartYearKeyPressed(evt);
   }
  });

  TF_PaymentEndYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaymentEndYearFocusGained(evt);
   }
  });
  TF_PaymentEndYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaymentEndYearKeyPressed(evt);
   }
  });

  CmB_PaymentEndMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_PaymentEndMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PaymentEndMonthKeyPressed(evt);
   }
  });

  CmB_PaymentEndDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_PaymentEndDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_PaymentEndDayKeyPressed(evt);
   }
  });

  TF_PaymentComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaymentCommentFocusGained(evt);
   }
  });
  TF_PaymentComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaymentCommentKeyPressed(evt);
   }
  });

  CB_PaymentComment.setText("Komntr");
  CB_PaymentComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentCommentKeyPressed(evt);
   }
  });

  Lbl_PaymentCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PaymentCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_PaymentCommentHelp.setText("(?)");
  Lbl_PaymentCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_PaymentCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PaymentCommentHelpMouseClicked(evt);
   }
  });

  CB_PaymentPrice.setText("Pmbyarn");
  CB_PaymentPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentPriceKeyPressed(evt);
   }
  });

  TF_PaymentPrice1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaymentPrice1FocusGained(evt);
   }
  });
  TF_PaymentPrice1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaymentPrice1KeyPressed(evt);
   }
  });

  Lbl_PaymentPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_PaymentPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_PaymentPriceHelp.setText("(?)");
  Lbl_PaymentPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_PaymentPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_PaymentPriceHelpMouseClicked(evt);
   }
  });

  CB_PaymentTransType.setText("J Trans");
  CB_PaymentTransType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransTypeKeyPressed(evt);
   }
  });

  Btn_PaymentTransTypeAdd.setText("+");
  Btn_PaymentTransTypeAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentTransTypeAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentTransTypeAddActionPerformed(evt);
   }
  });
  Btn_PaymentTransTypeAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentTransTypeAddKeyPressed(evt);
   }
  });

  Btn_PaymentTransTypeRemove.setText("-");
  Btn_PaymentTransTypeRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentTransTypeRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentTransTypeRemoveActionPerformed(evt);
   }
  });
  Btn_PaymentTransTypeRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentTransTypeRemoveKeyPressed(evt);
   }
  });

  CB_PaymentTransSubject.setText("Subjek");
  CB_PaymentTransSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransSubjectKeyPressed(evt);
   }
  });

  Btn_PaymentTransSubjectAdd.setText("+");
  Btn_PaymentTransSubjectAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentTransSubjectAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentTransSubjectAddActionPerformed(evt);
   }
  });
  Btn_PaymentTransSubjectAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentTransSubjectAddKeyPressed(evt);
   }
  });

  Btn_PaymentTransSubjectRemove.setText("-");
  Btn_PaymentTransSubjectRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentTransSubjectRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentTransSubjectRemoveActionPerformed(evt);
   }
  });
  Btn_PaymentTransSubjectRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentTransSubjectRemoveKeyPressed(evt);
   }
  });

  CB_PaymentTransSalesman.setText("Sales");
  CB_PaymentTransSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransSalesmanKeyPressed(evt);
   }
  });

  Btn_PaymentTransSalesmanAdd.setText("+");
  Btn_PaymentTransSalesmanAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentTransSalesmanAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentTransSalesmanAddActionPerformed(evt);
   }
  });
  Btn_PaymentTransSalesmanAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentTransSalesmanAddKeyPressed(evt);
   }
  });

  Btn_PaymentTransSalesmanRemove.setText("-");
  Btn_PaymentTransSalesmanRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentTransSalesmanRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentTransSalesmanRemoveActionPerformed(evt);
   }
  });
  Btn_PaymentTransSalesmanRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentTransSalesmanRemoveKeyPressed(evt);
   }
  });

  CmB_ChoosePayment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pembayaran Keluar Pada Transaksi", "Pembayaran Masuk Pada Transaksi", "Pembayaran Keluar Pada Pra-Transaksi", "Pembayaran Masuk Pada Pra-Transaksi" }));
  CmB_ChoosePayment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ChoosePaymentKeyPressed(evt);
   }
  });

  Lbl_ChoosePayment.setText("Jenis Pembayaran :");

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("-");

  Btn_PaymentCashAdd.setText("+");
  Btn_PaymentCashAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentCashAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentCashAddActionPerformed(evt);
   }
  });
  Btn_PaymentCashAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentCashAddKeyPressed(evt);
   }
  });

  Btn_PaymentCashRemove.setText("-");
  Btn_PaymentCashRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_PaymentCashRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentCashRemoveActionPerformed(evt);
   }
  });
  Btn_PaymentCashRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PaymentCashRemoveKeyPressed(evt);
   }
  });

  jLabel3.setText("-");

  TF_PaymentPrice2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_PaymentPrice2FocusGained(evt);
   }
  });
  TF_PaymentPrice2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_PaymentPrice2KeyPressed(evt);
   }
  });

  CB_PaymentTransTypeUndefined.setText("ksg");
  CB_PaymentTransTypeUndefined.setToolTipText("sertakan data pembayaran pd transaksi yg 'jenis transaksi'-nya yg tdk didefenisikan");
  CB_PaymentTransTypeUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransTypeUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransTypeUndefinedKeyPressed(evt);
   }
  });

  CB_PaymentTransSubjectUndefined.setText("ksg");
  CB_PaymentTransSubjectUndefined.setToolTipText("sertakan data pembayaran pd transaksi yg 'subjek'-nya yg tdk didefenisikan");
  CB_PaymentTransSubjectUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransSubjectUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransSubjectUndefinedKeyPressed(evt);
   }
  });

  CB_PaymentTransSalesmanUndefined.setText("ksg");
  CB_PaymentTransSalesmanUndefined.setToolTipText("sertakan data pembayaran pd transaksi yg 'sales'-nya yg tdk didefenisikan");
  CB_PaymentTransSalesmanUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentTransSalesmanUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentTransSalesmanUndefinedKeyPressed(evt);
   }
  });

  CB_PaymentCash.setText("Kas Krdt");
  CB_PaymentCash.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentCashKeyPressed(evt);
   }
  });

  CB_PaymentCashUndefined.setText("ksg");
  CB_PaymentCashUndefined.setToolTipText("sertakan data pembayaran yg 'kas kredit'-nya yg tdk didefenisikan");
  CB_PaymentCashUndefined.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_PaymentCashUndefined.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_PaymentCashUndefinedKeyPressed(evt);
   }
  });

  List_PaymentCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PaymentCashKeyReleased(evt);
   }
  });
  jScrollPane2.setViewportView(List_PaymentCash);

  List_PaymentTransType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PaymentTransTypeKeyReleased(evt);
   }
  });
  jScrollPane8.setViewportView(List_PaymentTransType);

  List_PaymentTransSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PaymentTransSubjectKeyReleased(evt);
   }
  });
  jScrollPane4.setViewportView(List_PaymentTransSubject);

  List_PaymentTransSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PaymentTransSalesmanKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(List_PaymentTransSalesman);

  javax.swing.GroupLayout Panel_QueryPaymentLayout = new javax.swing.GroupLayout(Panel_QueryPayment);
  Panel_QueryPayment.setLayout(Panel_QueryPaymentLayout);
  Panel_QueryPaymentLayout.setHorizontalGroup(
   Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryPaymentLayout.createSequentialGroup()
    .addComponent(Lbl_ChoosePayment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CmB_ChoosePayment, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
   .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_PaymentDate)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_PaymentCommentHelp))
     .addComponent(CB_PaymentTransType)
     .addComponent(CB_PaymentTransSubject)
     .addComponent(CB_PaymentTransSalesman)
     .addComponent(CB_PaymentCash)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_PaymentTransSubjectUndefined)
       .addComponent(CB_PaymentTransSalesmanUndefined)
       .addComponent(CB_PaymentTransTypeUndefined)
       .addComponent(CB_PaymentCashUndefined)))
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentTransId)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_PaymentTransIdHelp))
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentPrice)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_PaymentPriceHelp)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryPaymentLayout.createSequentialGroup()
      .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(jScrollPane2)
       .addComponent(jScrollPane8)
       .addComponent(jScrollPane4)
       .addComponent(jScrollPane5))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
        .addComponent(Btn_PaymentCashRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(Btn_PaymentCashAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(Btn_PaymentTransTypeAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(Btn_PaymentTransTypeRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
        .addComponent(Btn_PaymentTransSubjectAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(Btn_PaymentTransSubjectRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
        .addComponent(Btn_PaymentTransSalesmanAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addComponent(Btn_PaymentTransSalesmanRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
     .addComponent(TF_PaymentTransId)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(TF_PaymentPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(jLabel3)
      .addGap(3, 3, 3)
      .addComponent(TF_PaymentPrice2))
     .addComponent(TF_PaymentComment)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(TF_PaymentStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(CmB_PaymentStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(CmB_PaymentStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel1)
      .addGap(2, 2, 2)
      .addComponent(TF_PaymentEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(CmB_PaymentEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(CmB_PaymentEndDay, 0, 146, Short.MAX_VALUE))))
  );
  Panel_QueryPaymentLayout.setVerticalGroup(
   Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_ChoosePayment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ChoosePayment))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_PaymentTransId)
     .addComponent(Lbl_PaymentTransIdHelp)
     .addComponent(TF_PaymentTransId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_PaymentComment)
     .addComponent(Lbl_PaymentCommentHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_PaymentDate)
     .addComponent(CmB_PaymentStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_PaymentStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_PaymentStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_PaymentEndDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_PaymentEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_PaymentEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_PaymentPrice)
     .addComponent(TF_PaymentPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentPriceHelp)
     .addComponent(jLabel3)
     .addComponent(TF_PaymentPrice2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(Btn_PaymentCashAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_PaymentCashRemove))
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentCash)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_PaymentCashUndefined))
     .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(Btn_PaymentTransTypeAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_PaymentTransTypeRemove))
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentTransType)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_PaymentTransTypeUndefined))
     .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(Btn_PaymentTransSubjectAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_PaymentTransSubjectRemove))
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentTransSubject)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_PaymentTransSubjectUndefined))
     .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(CB_PaymentTransSalesman)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_PaymentTransSalesmanUndefined)
      .addGap(0, 0, Short.MAX_VALUE))
     .addGroup(Panel_QueryPaymentLayout.createSequentialGroup()
      .addComponent(Btn_PaymentTransSalesmanAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_PaymentTransSalesmanRemove)
      .addContainerGap())
     .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)))
  );

  TabbedPane_Query.addTab("Pembayaran", Panel_QueryPayment);

  Lbl_DebtPayCurrDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayCurrDate.setText("Akhir Hari");

  CmB_DebtPayCurrDateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_DebtPayCurrDateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_DebtPayCurrDateDayKeyPressed(evt);
   }
  });

  CmB_DebtPayCurrDateMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1 - Januari", "2 - Februari", "3 - Maret", "4 - April", "5 - Mei", "6 - Juni", "7 - Juli", "8 - Agustus", "9 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  CmB_DebtPayCurrDateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_DebtPayCurrDateMonthKeyPressed(evt);
   }
  });

  TF_DebtPayCurrDateYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_DebtPayCurrDateYearFocusGained(evt);
   }
  });
  TF_DebtPayCurrDateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_DebtPayCurrDateYearKeyPressed(evt);
   }
  });

  TF_DebtPayCurrSaving.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_DebtPayCurrSavingFocusGained(evt);
   }
  });
  TF_DebtPayCurrSaving.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_DebtPayCurrSavingKeyPressed(evt);
   }
  });

  Lbl_DebtPayAlreadySavingHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayAlreadySavingHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_DebtPayAlreadySavingHelp.setText("(?)");
  Lbl_DebtPayAlreadySavingHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_DebtPayAlreadySavingHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_DebtPayAlreadySavingHelpMouseClicked(evt);
   }
  });

  Lbl_DebtPayCurrSaving.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayCurrSaving.setText("Saldo Kas Pd Akhir Hari");

  jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_DebtPayOutEdit.setText("Ubah");
  Btn_DebtPayOutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DebtPayOutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DebtPayOutEditActionPerformed(evt);
   }
  });
  Btn_DebtPayOutEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DebtPayOutEditKeyPressed(evt);
   }
  });

  Btn_DebtPayOutRemove.setText("Hapus");
  Btn_DebtPayOutRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DebtPayOutRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DebtPayOutRemoveActionPerformed(evt);
   }
  });
  Btn_DebtPayOutRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DebtPayOutRemoveKeyPressed(evt);
   }
  });

  Btn_DebtPayOutAdd.setText("Tambah");
  Btn_DebtPayOutAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DebtPayOutAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DebtPayOutAddActionPerformed(evt);
   }
  });
  Btn_DebtPayOutAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DebtPayOutAddKeyPressed(evt);
   }
  });

  jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel8.setText("Utang");

  CmB_DebtPayOutAddMethod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dari Input Biasa", "Dari Transaksi", "Dari Pra-Transaksi", "Otomatis" }));
  CmB_DebtPayOutAddMethod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_DebtPayOutAddMethodKeyPressed(evt);
   }
  });

  Lbl_DebtPayOutHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayOutHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_DebtPayOutHelp.setText("(?)");
  Lbl_DebtPayOutHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_DebtPayOutHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_DebtPayOutHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addComponent(jLabel8)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_DebtPayOutHelp)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_DebtPayOutAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_DebtPayOutAddMethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_DebtPayOutRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_DebtPayOutEdit))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_DebtPayOutEdit)
    .addComponent(Btn_DebtPayOutRemove)
    .addComponent(Btn_DebtPayOutAdd)
    .addComponent(jLabel8)
    .addComponent(CmB_DebtPayOutAddMethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Lbl_DebtPayOutHelp))
  );

  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_DebtPayInEdit.setText("Ubah");
  Btn_DebtPayInEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DebtPayInEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DebtPayInEditActionPerformed(evt);
   }
  });
  Btn_DebtPayInEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DebtPayInEditKeyPressed(evt);
   }
  });

  Btn_DebtPayInRemove.setText("Hapus");
  Btn_DebtPayInRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DebtPayInRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DebtPayInRemoveActionPerformed(evt);
   }
  });
  Btn_DebtPayInRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DebtPayInRemoveKeyPressed(evt);
   }
  });

  Btn_DebtPayInAdd.setText("Tambah");
  Btn_DebtPayInAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DebtPayInAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DebtPayInAddActionPerformed(evt);
   }
  });
  Btn_DebtPayInAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DebtPayInAddKeyPressed(evt);
   }
  });

  jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel9.setText("Piutang {Ops.}");

  CmB_DebtPayInAddMethod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dari Input Biasa", "Dari Transaksi", "Dari Pra-Transaksi", "Otomatis" }));
  CmB_DebtPayInAddMethod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_DebtPayInAddMethodKeyPressed(evt);
   }
  });

  Lbl_DebtPayInHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayInHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_DebtPayInHelp.setText("(?)");
  Lbl_DebtPayInHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_DebtPayInHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_DebtPayInHelpMouseClicked(evt);
   }
  });

  CB_BillsInWithAmountPaid.setText("{ - Terlunasi }");
  CB_BillsInWithAmountPaid.setToolTipText("jika opsi ini aktif, maka nilai Piutang akan diasumsikan adalah 'Jumlah - Terlunasi'");
  CB_BillsInWithAmountPaid.setIconTextGap(3);
  CB_BillsInWithAmountPaid.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BillsInWithAmountPaid.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BillsInWithAmountPaidKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
    .addComponent(jLabel9)
    .addGap(4, 4, 4)
    .addComponent(Lbl_DebtPayInHelp)
    .addGap(6, 6, 6)
    .addComponent(CB_BillsInWithAmountPaid)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_DebtPayInAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_DebtPayInAddMethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_DebtPayInRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_DebtPayInEdit))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_DebtPayInEdit)
    .addComponent(Btn_DebtPayInRemove)
    .addComponent(Btn_DebtPayInAdd)
    .addComponent(jLabel9)
    .addComponent(CmB_DebtPayInAddMethod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Lbl_DebtPayInHelp)
    .addComponent(CB_BillsInWithAmountPaid))
  );

  Lbl_DebtPayCurrDateHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayCurrDateHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_DebtPayCurrDateHelp.setText("(?)");
  Lbl_DebtPayCurrDateHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_DebtPayCurrDateHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_DebtPayCurrDateHelpMouseClicked(evt);
   }
  });

  Lbl_DebtPayCalculator.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DebtPayCalculator.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_DebtPayCalculator.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_DebtPayCalculator.setText("Hitung Rincian Besaran Cicilan Harian Utk Melunasi Utang");
  Lbl_DebtPayCalculator.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_DebtPayCalculator.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_DebtPayCalculatorMouseClicked(evt);
   }
  });

  Tbl_DebtPayOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_DebtPayOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_DebtPayOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_DebtPayOutKeyReleased(evt);
   }
  });
  jScrollPane11.setViewportView(Tbl_DebtPayOut);

  Tbl_DebtPayIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_DebtPayIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_DebtPayIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_DebtPayInKeyReleased(evt);
   }
  });
  jScrollPane9.setViewportView(Tbl_DebtPayIn);

  javax.swing.GroupLayout Panel_DebtPaymentLayout = new javax.swing.GroupLayout(Panel_DebtPayment);
  Panel_DebtPayment.setLayout(Panel_DebtPaymentLayout);
  Panel_DebtPaymentLayout.setHorizontalGroup(
   Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DebtPaymentLayout.createSequentialGroup()
    .addGroup(Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_DebtPayCurrDate)
     .addComponent(Lbl_DebtPayCurrSaving))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_DebtPaymentLayout.createSequentialGroup()
      .addComponent(TF_DebtPayCurrDateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_DebtPayCurrDateMonth, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_DebtPayCurrDateDay, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(TF_DebtPayCurrSaving))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(Lbl_DebtPayAlreadySavingHelp)
     .addComponent(Lbl_DebtPayCurrDateHelp)))
   .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Lbl_DebtPayCalculator, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane11)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane9)
  );
  Panel_DebtPaymentLayout.setVerticalGroup(
   Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_DebtPaymentLayout.createSequentialGroup()
    .addComponent(Lbl_DebtPayCalculator)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_DebtPayCurrDateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DebtPayCurrDate)
     .addComponent(CmB_DebtPayCurrDateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_DebtPayCurrDateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DebtPayCurrDateHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DebtPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DebtPayCurrSaving, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DebtPayAlreadySavingHelp)
     .addComponent(Lbl_DebtPayCurrSaving))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE))
  );

  TabbedPane_Query.addTab("Cicil Utang", Panel_DebtPayment);

  TA_QueryEtcInfo.setEditable(false);
  TA_QueryEtcInfo.setBackground(new java.awt.Color(204, 255, 204));
  TA_QueryEtcInfo.setColumns(20);
  TA_QueryEtcInfo.setFont(new java.awt.Font("Monospaced", 1, 13)); // NOI18N
  TA_QueryEtcInfo.setLineWrap(true);
  TA_QueryEtcInfo.setRows(1);
  TA_QueryEtcInfo.setWrapStyleWord(true);
  jScrollPane7.setViewportView(TA_QueryEtcInfo);

  List_QueryEtc.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
  List_QueryEtc.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_QueryEtcMouseReleased(evt);
   }
  });
  List_QueryEtc.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QueryEtcKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(List_QueryEtc);

  javax.swing.GroupLayout Panel_QueryEtcLayout = new javax.swing.GroupLayout(Panel_QueryEtc);
  Panel_QueryEtc.setLayout(Panel_QueryEtcLayout);
  Panel_QueryEtcLayout.setHorizontalGroup(
   Panel_QueryEtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 495, Short.MAX_VALUE)
   .addComponent(jScrollPane1)
  );
  Panel_QueryEtcLayout.setVerticalGroup(
   Panel_QueryEtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_QueryEtcLayout.createSequentialGroup()
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane_Query.addTab("Lain", Panel_QueryEtc);

  Panel_ResultTableStatus.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi id pd 'Kolom Id' dari baris2 yg dipilih dari 'DaftarKu'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan Id pada 'Kolom Id' dari baris2 yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu'");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setText("*Daftarku");

  TF_TableResultCount.setEditable(false);
  TF_TableResultCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_TableResultCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TableResultCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TableResultCount.setToolTipText("Jumlah data/record pada tabel");

  CmB_IdColumn.setToolTipText("Pilih 'Kolom Id' (kolom yang akan disimpan Id-nya ke 'Daftarku')");

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Panel_ResultTableStatusLayout = new javax.swing.GroupLayout(Panel_ResultTableStatus);
  Panel_ResultTableStatus.setLayout(Panel_ResultTableStatusLayout);
  Panel_ResultTableStatusLayout.setHorizontalGroup(
   Panel_ResultTableStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ResultTableStatusLayout.createSequentialGroup()
    .addComponent(TF_TableResultCount, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 195, Short.MAX_VALUE)
    .addComponent(jLabel2)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_IdColumn, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListSave)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListLoad)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListClear))
  );
  Panel_ResultTableStatusLayout.setVerticalGroup(
   Panel_ResultTableStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ResultTableStatusLayout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addGroup(Panel_ResultTableStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_TempListLoad)
     .addComponent(Btn_TempListSave)
     .addComponent(Btn_TempListRemove)
     .addComponent(Btn_TempListAdd)
     .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2)
     .addComponent(TF_TableResultCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_IdColumn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_TempListClear)))
  );

  Tbl_Result.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Result.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  Tbl_Result.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
  Tbl_Result.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Result.setRowHeight(18);
  Tbl_Result.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ResultKeyReleased(evt);
   }
  });
  jScrollPane10.setViewportView(Tbl_Result);

  javax.swing.GroupLayout Panel_ResultTableLayout = new javax.swing.GroupLayout(Panel_ResultTable);
  Panel_ResultTable.setLayout(Panel_ResultTableLayout);
  Panel_ResultTableLayout.setHorizontalGroup(
   Panel_ResultTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Panel_ResultTableStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane10)
  );
  Panel_ResultTableLayout.setVerticalGroup(
   Panel_ResultTableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_ResultTableLayout.createSequentialGroup()
    .addComponent(Panel_ResultTableStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE))
  );

  TabbedPane_Result.addTab("Tabel", Panel_ResultTable);

  TA_Result.setEditable(false);
  TA_Result.setBackground(new java.awt.Color(204, 255, 204));
  TA_Result.setColumns(20);
  TA_Result.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Result.setLineWrap(true);
  TA_Result.setRows(5);
  TA_Result.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_Result);

  javax.swing.GroupLayout Panel_ResultTextLayout = new javax.swing.GroupLayout(Panel_ResultText);
  Panel_ResultText.setLayout(Panel_ResultTextLayout);
  Panel_ResultTextLayout.setHorizontalGroup(
   Panel_ResultTextLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 773, Short.MAX_VALUE)
  );
  Panel_ResultTextLayout.setVerticalGroup(
   Panel_ResultTextLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE)
  );

  TabbedPane_Result.addTab("Teks", Panel_ResultText);

  Lbl_Result.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Result.setText("---- Hasil Pencarian :");

  CB_ResultSignTable.setText("Tabel");
  CB_ResultSignTable.setEnabled(false);
  CB_ResultSignTable.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CB_ResultSignText.setText("Teks");
  CB_ResultSignText.setEnabled(false);
  CB_ResultSignText.setMargin(new java.awt.Insets(0, 0, 0, 0));

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(Lbl_Result)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_ResultSignTable)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_ResultSignText)
    .addGap(0, 0, Short.MAX_VALUE))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Lbl_Result)
    .addComponent(CB_ResultSignTable)
    .addComponent(CB_ResultSignText))
  );

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });

  Label_Query.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Label_Query.setText("---- Pencarian");

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(Label_Query)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Query)
    .addComponent(Label_Query))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TabbedPane_Query)
     .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(TabbedPane_Result))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TabbedPane_Result))
     .addGroup(layout.createSequentialGroup()
      .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TabbedPane_Query)))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  Date dt;
  if(Activ){return;}
  Activ=true;
  
		dt=new Date();
  
		PGUI.setDateComponent(dt, TF_PaymentStartYear, CmB_PaymentStartMonth, CmB_PaymentStartDay);
  PGUI.setDateComponent(dt, TF_PaymentEndYear, CmB_PaymentEndMonth, CmB_PaymentEndDay);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_PaymentTransTypeAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentTransTypeAddActionPerformed
  Object[] NewRow;
  int count, temp;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTransType;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   count=IFV.FDataIdName.DataId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=(int)IFV.FDataIdName.DataId[temp];
    NewRow[1]=IFV.FDataIdName.DataName[temp];
    ListMdlPaymentTransType.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_PaymentTransTypeAddActionPerformed

 private void Btn_PaymentTransTypeRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentTransTypeRemoveActionPerformed
  ListMdlPaymentTransType.remove(List_PaymentTransType.getSelectedIndices());
 }//GEN-LAST:event_Btn_PaymentTransTypeRemoveActionPerformed

 private void Btn_PaymentTransSubjectAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSubjectAddActionPerformed
  Object[] NewRow;
  int count, temp;
  
  
  IFV.FSubject.wMode=1;
  IFV.FSubject.wDialogWithFItem=false;
  IFV.FSubject.wAllowMultipleSelection=true;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   count=IFV.FSubject.ChoosedId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=IFV.FSubject.ChoosedId[temp];
    NewRow[1]=IFV.FSubject.ChoosedName[temp];
    ListMdlPaymentTransSubject.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_PaymentTransSubjectAddActionPerformed

 private void Btn_PaymentTransSubjectRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSubjectRemoveActionPerformed
  ListMdlPaymentTransSubject.remove(List_PaymentTransSubject.getSelectedIndices());
 }//GEN-LAST:event_Btn_PaymentTransSubjectRemoveActionPerformed

 private void Btn_PaymentTransSalesmanAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSalesmanAddActionPerformed
  Object[] NewRow;
  int count, temp;
  
  
  IFV.FSubject.wMode=1;
  IFV.FSubject.wDialogWithFItem=false;
  IFV.FSubject.wAllowMultipleSelection=true;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   count=IFV.FSubject.ChoosedId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=IFV.FSubject.ChoosedId[temp];
    NewRow[1]=IFV.FSubject.ChoosedName[temp];
    ListMdlPaymentTransSalesman.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_PaymentTransSalesmanAddActionPerformed

 private void Btn_PaymentTransSalesmanRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSalesmanRemoveActionPerformed
  ListMdlPaymentTransSalesman.remove(List_PaymentTransSalesman.getSelectedIndices());
 }//GEN-LAST:event_Btn_PaymentTransSalesmanRemoveActionPerformed

 private void Lbl_PaymentTransIdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PaymentTransIdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_PaymentTransIdHelpMouseClicked

 private void Lbl_PaymentCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PaymentCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_PaymentCommentHelpMouseClicked

 private void Lbl_PaymentPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_PaymentPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter 2 >= Parameter 1.\n"+PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_PaymentPriceHelpMouseClicked

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  processQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  int[] rows;
  int temp;
  boolean ColumnIdIsInteger;
  int SelectedColumnId;
  
  SelectedColumnId=checkIdColumn();
  if(SelectedColumnId==-1){return;}
  
  rows=Tbl_Result.getSelectedRows();
  if(rows.length==0){return;}
  ColumnIdIsInteger=TableMdlResult.Mdl.ColumnsType[SelectedColumnId]==2;
  temp=0;
  do{
   if(ColumnIdIsInteger){TempList.addElement(PCore.objInteger(TableMdlResult.Mdl.Rows.elementAt(rows[temp])[SelectedColumnId], -1));}
   else{TempList.addElement(PCore.objLong(TableMdlResult.Mdl.Rows.elementAt(rows[temp])[SelectedColumnId], -1L));}
   temp=temp+1;
  }while(temp!=rows.length);
  updateTempListQuantity();
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  int[] rows;
  int temp;
  boolean ColumnIdIsInteger;
  int SelectedColumnId;
  
  SelectedColumnId=checkIdColumn();
  if(SelectedColumnId==-1){return;}
  
  rows=Tbl_Result.getSelectedRows();
  if(rows.length==0){return;}
  ColumnIdIsInteger=TableMdlResult.Mdl.ColumnsType[SelectedColumnId]==2;
  temp=0;
  do{
   if(ColumnIdIsInteger){TempList.removeElement(PCore.objInteger(TableMdlResult.Mdl.Rows.elementAt(rows[temp])[SelectedColumnId], -1));}
   else{TempList.removeElement(PCore.objLong(TableMdlResult.Mdl.Rows.elementAt(rows[temp])[SelectedColumnId], -1L));}
   temp=temp+1;
  }while(temp!=rows.length);
  updateTempListQuantity();
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  File f;
  String fstr;
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION){return;}
   
  f=IFV.FileChooser.getSelectedFile();
  if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
   JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
   return;
  }
  try{
   fstr=f.getCanonicalPath();
   if(PFile.compareIgnoreCaseExtension(fstr, "report")==false){
    f=new File(fstr+".report");
   }
  }
  catch(Exception E){
   JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !");
   return;
  }
  if(PEtc.saveIdToFile(TempList.getElements(), f, false,
   IFV.FSplashScreen, true, this, "Menulis Data DaftarKu")==false){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data report ke file !");
  }
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  File f;
  long[] tlist;
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showDialog(this, "Load")!=JFileChooser.APPROVE_OPTION){return;}
  f=IFV.FileChooser.getSelectedFile();
  if(PFile.compareIgnoreCaseExtension(f.getName(), "report")==false){
   JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+
    "Ekstensi file harus '.report'.");
   return;
  }
  tlist=PEtc.loadIdFromFile(f, false,
   IFV.FSplashScreen, true, this, "Membaca Data DaftarKu");
  if(tlist==null){
   JOptionPane.showMessageDialog(null, "Gagal membaca data report dari file !");
   return;
  }
  TempList.replaceElements(tlist, tlist.length);
  updateTempListQuantity();
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void TF_PaymentTransIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaymentTransIdKeyPressed
  PNav.onKey_Query_TF(this, CB_PaymentTransId, TF_PaymentTransId, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_ChoosePayment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_PaymentComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentTransId)));
 }//GEN-LAST:event_TF_PaymentTransIdKeyPressed

 private void TF_PaymentCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaymentCommentKeyPressed
  PNav.onKey_Query_TF(this, CB_PaymentComment, TF_PaymentComment, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentTransId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_PaymentStartYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentComment)));
 }//GEN-LAST:event_TF_PaymentCommentKeyPressed

 private void TF_PaymentPrice1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaymentPrice1KeyPressed
  PNav.onKey_Query_TF1(this, CB_PaymentPrice, TF_PaymentPrice1, TF_PaymentPrice2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentStartYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentCashAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentPrice)));
 }//GEN-LAST:event_TF_PaymentPrice1KeyPressed

 private void Btn_PaymentCashAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentCashAddActionPerformed
  Object[] NewRow;
  int count, temp;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCash;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   count=IFV.FDataIdName.DataId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=(int)IFV.FDataIdName.DataId[temp];
    NewRow[1]=IFV.FDataIdName.DataName[temp];
    ListMdlPaymentCash.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_PaymentCashAddActionPerformed

 private void Btn_PaymentCashRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentCashRemoveActionPerformed
  ListMdlPaymentCash.remove(List_PaymentCash.getSelectedIndices());
 }//GEN-LAST:event_Btn_PaymentCashRemoveActionPerformed

 private void TF_PaymentPrice2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaymentPrice2KeyPressed
  PNav.onKey_Query_TF2(this, CB_PaymentPrice, TF_PaymentPrice1, TF_PaymentPrice2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentEndYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentCashAdd)));
 }//GEN-LAST:event_TF_PaymentPrice2KeyPressed

 private void Lbl_DebtPayCurrDateHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_DebtPayCurrDateHelpMouseClicked
  JOptionPane.showMessageDialog(null,
    "- Data harus diisi."+
    "" // "\n- Tanggal 'Akhir Hari' < tanggal terkecil 'Cicil Akhir' dari 'Tagihan Utang'."
   );
 }//GEN-LAST:event_Lbl_DebtPayCurrDateHelpMouseClicked

 private void Btn_DebtPayInAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DebtPayInAddActionPerformed
  DebtPayAdd(true);
 }//GEN-LAST:event_Btn_DebtPayInAddActionPerformed

 private void Btn_DebtPayInRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DebtPayInRemoveActionPerformed
  DebtPayRemove(true);
 }//GEN-LAST:event_Btn_DebtPayInRemoveActionPerformed

 private void Btn_DebtPayInEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DebtPayInEditActionPerformed
  DebtPayEdit(true);
 }//GEN-LAST:event_Btn_DebtPayInEditActionPerformed

 private void Btn_DebtPayOutAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DebtPayOutAddActionPerformed
  DebtPayAdd(false);
 }//GEN-LAST:event_Btn_DebtPayOutAddActionPerformed

 private void Btn_DebtPayOutRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DebtPayOutRemoveActionPerformed
  DebtPayRemove(false);
 }//GEN-LAST:event_Btn_DebtPayOutRemoveActionPerformed

 private void Btn_DebtPayOutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DebtPayOutEditActionPerformed
  DebtPayEdit(false);
 }//GEN-LAST:event_Btn_DebtPayOutEditActionPerformed

 private void Lbl_DebtPayAlreadySavingHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_DebtPayAlreadySavingHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_DebtPayAlreadySavingHelpMouseClicked

 private void Lbl_DebtPayCalculatorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_DebtPayCalculatorMouseClicked
  IFV.FMessage.showMessage(
			"Form ini digunakan utk menghitung rincian besaran cicilan harian utk melunasi utang."+
			"\n\nAdapun mekanisme perhitungan dapat dilihat sbb :"+
			"\n\n- Perhitungan rincian besaran cicilan harian akan dimulai dari Tanggal 'Akhir Hari' + 1 hingga tanggal terbesar 'Cicil Akhir' dari 'Tagihan Utang'."+
			"\n\n- 'Saldo Kas Pd Akhir Hari' merepresentasikan jumlah uang yg ada di dalam 'Kas Utang' pada 'Akhir hari'."+
			"\n\n- Semua 'Tagihan Utang' & 'Tagihan Piutang' akan diakomodasi dalam perhitungan, kecuali 'Tagihan Piutang' setelah tanggal terbesar 'Tanggal Tagih' dari 'Tagihan Utang'."+
			"\n\n- Inputan 'Akhir Hari', 'Saldo Kas Pd Akhir Hari', & 'Tagihan Utang' wajib diisi, sedangkan inputan 'Tagihan Piutang' bersifat opsional (boleh dikosongkan)."
		);
 }//GEN-LAST:event_Lbl_DebtPayCalculatorMouseClicked

 private void Lbl_DebtPayOutHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_DebtPayOutHelpMouseClicked
  JOptionPane.showMessageDialog(null,
			"'Data Transaksi / Pra-Transaksi' wajib memiliki inputan 'Lama Kredit (Tgl Tagih)' & 'Periode Cicil Awal-Akhir'.");
 }//GEN-LAST:event_Lbl_DebtPayOutHelpMouseClicked

 private void Lbl_DebtPayInHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_DebtPayInHelpMouseClicked
  JOptionPane.showMessageDialog(null,
			"'Data Transaksi / Pra-Transaksi' wajib memiliki inputan 'Lama Kredit (Tgl Tagih)'.");
 }//GEN-LAST:event_Lbl_DebtPayInHelpMouseClicked

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  if(JOptionPane.showConfirmDialog(null, "Kosongkan data pada 'Daftarku' ?", "Konfirmasi Pengosongan Data Pada 'Daftarku'",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  TempList.removeAll();
  updateTempListQuantity();
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Tbl_ResultKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ResultKeyReleased
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_Tbl_ResultKeyReleased

 private void List_QueryEtcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QueryEtcKeyReleased
  onSelectedRowEtcChanged();
 }//GEN-LAST:event_List_QueryEtcKeyReleased

 private void List_QueryEtcMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_QueryEtcMouseReleased
  onSelectedRowEtcChanged();
 }//GEN-LAST:event_List_QueryEtcMouseReleased

 private void CmB_ChoosePaymentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ChoosePaymentKeyPressed
  PNav.onKey_CmB(this, CmB_ChoosePayment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_PaymentTransId)));
 }//GEN-LAST:event_CmB_ChoosePaymentKeyPressed

 private void CB_PaymentTransIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransIdKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_ChoosePayment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PaymentTransId)));
 }//GEN-LAST:event_CB_PaymentTransIdKeyPressed

 private void CB_PaymentCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentCommentKeyPressed
  PNav.onKey_CB(this, CB_PaymentComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentTransId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentDate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PaymentComment)));
 }//GEN-LAST:event_CB_PaymentCommentKeyPressed

 private void CB_PaymentDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentDateKeyPressed
  PNav.onKey_CB(this, CB_PaymentDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PaymentStartYear)));
 }//GEN-LAST:event_CB_PaymentDateKeyPressed

 private void TF_PaymentStartYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaymentStartYearKeyPressed
  PNav.onKey_TF(this, TF_PaymentStartYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_PaymentPrice1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_PaymentStartMonth)));
 }//GEN-LAST:event_TF_PaymentStartYearKeyPressed

 private void CmB_PaymentStartMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PaymentStartMonthKeyPressed
  PNav.onKey_CmB(this, CmB_PaymentStartMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_PaymentStartYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_PaymentStartDay)));
 }//GEN-LAST:event_CmB_PaymentStartMonthKeyPressed

 private void CmB_PaymentStartDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PaymentStartDayKeyPressed
  PNav.onKey_CmB(this, CmB_PaymentStartDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_PaymentStartMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PaymentEndYear)));
 }//GEN-LAST:event_CmB_PaymentStartDayKeyPressed

 private void TF_PaymentEndYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_PaymentEndYearKeyPressed
  PNav.onKey_TF(this, TF_PaymentEndYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_PaymentPrice2)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_PaymentStartDay)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_PaymentEndMonth)));
 }//GEN-LAST:event_TF_PaymentEndYearKeyPressed

 private void CmB_PaymentEndMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PaymentEndMonthKeyPressed
  PNav.onKey_CmB(this, CmB_PaymentEndMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_PaymentEndYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_PaymentEndDay)));
 }//GEN-LAST:event_CmB_PaymentEndMonthKeyPressed

 private void CmB_PaymentEndDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_PaymentEndDayKeyPressed
  PNav.onKey_CmB(this, CmB_PaymentEndDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_PaymentEndMonth)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_PaymentEndDayKeyPressed

 private void CB_PaymentPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentPriceKeyPressed
  PNav.onKey_CB(this, CB_PaymentPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentCash)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_PaymentPrice1)));
 }//GEN-LAST:event_CB_PaymentPriceKeyPressed

 private void CB_PaymentCashKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentCashKeyPressed
  PNav.onKey_CB(this, CB_PaymentCash, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentPrice)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentCashUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentCash)));
 }//GEN-LAST:event_CB_PaymentCashKeyPressed

 private void CB_PaymentCashUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentCashUndefinedKeyPressed
  PNav.onKey_CB(this, CB_PaymentCashUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentCash)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentTransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentCash)));
 }//GEN-LAST:event_CB_PaymentCashUndefinedKeyPressed

 private void List_PaymentCashKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PaymentCashKeyReleased
  PNav.onKey_List(this, List_PaymentCash, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentPrice1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransTypeAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentCash)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_PaymentCashAdd)));
 }//GEN-LAST:event_List_PaymentCashKeyReleased

 private void Btn_PaymentCashAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentCashAddKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentCashAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_PaymentPrice1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentCashRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentCash)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentCashAddKeyPressed

 private void Btn_PaymentCashRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentCashRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentCashRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentCashAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransTypeAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentCash)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentCashRemoveKeyPressed

 private void CB_PaymentTransTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransTypeKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentCashUndefined)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentTransTypeUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentTransType)));
 }//GEN-LAST:event_CB_PaymentTransTypeKeyPressed

 private void CB_PaymentTransTypeUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransTypeUndefinedKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransTypeUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentTransType)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentTransSubject)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentTransType)));
 }//GEN-LAST:event_CB_PaymentTransTypeUndefinedKeyPressed

 private void List_PaymentTransTypeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PaymentTransTypeKeyReleased
  PNav.onKey_List(this, List_PaymentTransType, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentCashAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransSubjectAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentTransType)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_PaymentTransTypeAdd)));
 }//GEN-LAST:event_List_PaymentTransTypeKeyReleased

 private void Btn_PaymentTransTypeAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentTransTypeAddKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentTransTypeAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentCashRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransTypeRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentTransType)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentTransTypeAddKeyPressed

 private void Btn_PaymentTransTypeRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentTransTypeRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentTransTypeRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransTypeAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransSubjectAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentTransType)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentTransTypeRemoveKeyPressed

 private void CB_PaymentTransSubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransSubjectKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransSubject, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentTransTypeUndefined)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentTransSubjectUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentTransSubject)));
 }//GEN-LAST:event_CB_PaymentTransSubjectKeyPressed

 private void CB_PaymentTransSubjectUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransSubjectUndefinedKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransSubjectUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentTransSubject)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentTransSalesman)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentTransSubject)));
 }//GEN-LAST:event_CB_PaymentTransSubjectUndefinedKeyPressed

 private void List_PaymentTransSubjectKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PaymentTransSubjectKeyReleased
  PNav.onKey_List(this, List_PaymentTransSubject, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransTypeAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransSalesmanAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentTransSubject)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_PaymentTransSubjectAdd)));
 }//GEN-LAST:event_List_PaymentTransSubjectKeyReleased

 private void Btn_PaymentTransSubjectAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSubjectAddKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentTransSubjectAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransTypeRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransSubjectRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentTransSubject)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentTransSubjectAddKeyPressed

 private void Btn_PaymentTransSubjectRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSubjectRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentTransSubjectRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransSubjectAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransSalesmanAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentTransSubject)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentTransSubjectRemoveKeyPressed

 private void CB_PaymentTransSalesmanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransSalesmanKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransSalesman, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentTransSubjectUndefined)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_PaymentTransSalesmanUndefined)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentTransSalesman)));
 }//GEN-LAST:event_CB_PaymentTransSalesmanKeyPressed

 private void CB_PaymentTransSalesmanUndefinedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_PaymentTransSalesmanUndefinedKeyPressed
  PNav.onKey_CB(this, CB_PaymentTransSalesmanUndefined, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_PaymentTransSalesman)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_PaymentTransSalesman)));
 }//GEN-LAST:event_CB_PaymentTransSalesmanUndefinedKeyPressed

 private void List_PaymentTransSalesmanKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PaymentTransSalesmanKeyReleased
  PNav.onKey_List(this, List_PaymentTransSalesman, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransSubjectAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_PaymentTransSalesman)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_PaymentTransSalesmanAdd)));
 }//GEN-LAST:event_List_PaymentTransSalesmanKeyReleased

 private void Btn_PaymentTransSalesmanAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSalesmanAddKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentTransSalesmanAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransSubjectRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PaymentTransSalesmanRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentTransSalesman)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentTransSalesmanAddKeyPressed

 private void Btn_PaymentTransSalesmanRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PaymentTransSalesmanRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_PaymentTransSalesmanRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PaymentTransSalesmanAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_PaymentTransSalesman)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_PaymentTransSalesmanRemoveKeyPressed

 private void TF_DebtPayCurrDateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_DebtPayCurrDateYearKeyPressed
  PNav.onKey_TF(this, TF_DebtPayCurrDateYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_DebtPayCurrSaving)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_DebtPayCurrDateMonth)));
 }//GEN-LAST:event_TF_DebtPayCurrDateYearKeyPressed

 private void CmB_DebtPayCurrDateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_DebtPayCurrDateMonthKeyPressed
  PNav.onKey_CmB(this, CmB_DebtPayCurrDateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_DebtPayCurrDateYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_DebtPayCurrDateDay)));
 }//GEN-LAST:event_CmB_DebtPayCurrDateMonthKeyPressed

 private void CmB_DebtPayCurrDateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_DebtPayCurrDateDayKeyPressed
  PNav.onKey_CmB(this, CmB_DebtPayCurrDateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_DebtPayCurrDateMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_DebtPayCurrSaving)));
 }//GEN-LAST:event_CmB_DebtPayCurrDateDayKeyPressed

 private void TF_DebtPayCurrSavingKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_DebtPayCurrSavingKeyPressed
  PNav.onKey_TF(this, TF_DebtPayCurrSaving, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DebtPayCurrDateYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_DebtPayOutAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_TF_DebtPayCurrSavingKeyPressed

 private void Btn_DebtPayOutAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DebtPayOutAddKeyPressed
  PNav.onKey_Btn(this, Btn_DebtPayOutAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DebtPayCurrSaving)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_DebtPayOutAddMethod)));
 }//GEN-LAST:event_Btn_DebtPayOutAddKeyPressed

 private void CmB_DebtPayOutAddMethodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_DebtPayOutAddMethodKeyPressed
  PNav.onKey_CmB(this, CmB_DebtPayOutAddMethod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_DebtPayOutAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_DebtPayOutRemove)));
 }//GEN-LAST:event_CmB_DebtPayOutAddMethodKeyPressed

 private void Btn_DebtPayOutRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DebtPayOutRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_DebtPayOutRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DebtPayCurrSaving)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_DebtPayOutAddMethod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_DebtPayOutEdit)));
 }//GEN-LAST:event_Btn_DebtPayOutRemoveKeyPressed

 private void Btn_DebtPayOutEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DebtPayOutEditKeyPressed
  PNav.onKey_Btn(this, Btn_DebtPayOutEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_DebtPayCurrSaving)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_DebtPayOutRemove)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_DebtPayOutEditKeyPressed

 private void Tbl_DebtPayOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_DebtPayOutKeyReleased
  PNav.onKey_Tbl(this, Tbl_DebtPayOut, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_DebtPayOutAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_DebtPayInAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Tbl_DebtPayOutKeyReleased

 private void CB_BillsInWithAmountPaidKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BillsInWithAmountPaidKeyPressed
  PNav.onKey_CB(this, CB_BillsInWithAmountPaid, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_DebtPayInAdd)));
 }//GEN-LAST:event_CB_BillsInWithAmountPaidKeyPressed

 private void Btn_DebtPayInAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DebtPayInAddKeyPressed
  PNav.onKey_Btn(this, Btn_DebtPayInAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BillsInWithAmountPaid)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_DebtPayInAddMethod)));
 }//GEN-LAST:event_Btn_DebtPayInAddKeyPressed

 private void CmB_DebtPayInAddMethodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_DebtPayInAddMethodKeyPressed
  PNav.onKey_CmB(this, CmB_DebtPayInAddMethod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_DebtPayInAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_DebtPayInRemove)));
 }//GEN-LAST:event_CmB_DebtPayInAddMethodKeyPressed

 private void Btn_DebtPayInRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DebtPayInRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_DebtPayInRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_DebtPayInAddMethod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_DebtPayInEdit)));
 }//GEN-LAST:event_Btn_DebtPayInRemoveKeyPressed

 private void Btn_DebtPayInEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DebtPayInEditKeyPressed
  PNav.onKey_Btn(this, Btn_DebtPayInEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_DebtPayOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_DebtPayIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_DebtPayInRemove)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_DebtPayInEditKeyPressed

 private void Tbl_DebtPayInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_DebtPayInKeyReleased
  PNav.onKey_Tbl(this, Tbl_DebtPayIn, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_DebtPayInAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Tbl_DebtPayInKeyReleased

 private void TF_PaymentTransIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaymentTransIdFocusGained
  PGUI.text_SelectAll(TF_PaymentTransId);
 }//GEN-LAST:event_TF_PaymentTransIdFocusGained

 private void TF_PaymentCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaymentCommentFocusGained
  PGUI.text_SelectAll(TF_PaymentComment);
 }//GEN-LAST:event_TF_PaymentCommentFocusGained

 private void TF_PaymentStartYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaymentStartYearFocusGained
  PGUI.text_SelectAll(TF_PaymentStartYear);
 }//GEN-LAST:event_TF_PaymentStartYearFocusGained

 private void TF_PaymentEndYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaymentEndYearFocusGained
  PGUI.text_SelectAll(TF_PaymentEndYear);
 }//GEN-LAST:event_TF_PaymentEndYearFocusGained

 private void TF_PaymentPrice1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaymentPrice1FocusGained
  PGUI.text_SelectAll(TF_PaymentPrice1);
 }//GEN-LAST:event_TF_PaymentPrice1FocusGained

 private void TF_PaymentPrice2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_PaymentPrice2FocusGained
  PGUI.text_SelectAll(TF_PaymentPrice2);
 }//GEN-LAST:event_TF_PaymentPrice2FocusGained

 private void TF_DebtPayCurrDateYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_DebtPayCurrDateYearFocusGained
  PGUI.text_SelectAll(TF_DebtPayCurrDateYear);
 }//GEN-LAST:event_TF_DebtPayCurrDateYearFocusGained

 private void TF_DebtPayCurrSavingFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_DebtPayCurrSavingFocusGained
  PGUI.text_SelectAll(TF_DebtPayCurrSaving);
 }//GEN-LAST:event_TF_DebtPayCurrSavingFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_DebtPayInAdd;
 private javax.swing.JButton Btn_DebtPayInEdit;
 private javax.swing.JButton Btn_DebtPayInRemove;
 private javax.swing.JButton Btn_DebtPayOutAdd;
 private javax.swing.JButton Btn_DebtPayOutEdit;
 private javax.swing.JButton Btn_DebtPayOutRemove;
 private javax.swing.JButton Btn_PaymentCashAdd;
 private javax.swing.JButton Btn_PaymentCashRemove;
 private javax.swing.JButton Btn_PaymentTransSalesmanAdd;
 private javax.swing.JButton Btn_PaymentTransSalesmanRemove;
 private javax.swing.JButton Btn_PaymentTransSubjectAdd;
 private javax.swing.JButton Btn_PaymentTransSubjectRemove;
 private javax.swing.JButton Btn_PaymentTransTypeAdd;
 private javax.swing.JButton Btn_PaymentTransTypeRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JCheckBox CB_BillsInWithAmountPaid;
 private javax.swing.JCheckBox CB_PaymentCash;
 private javax.swing.JCheckBox CB_PaymentCashUndefined;
 private javax.swing.JCheckBox CB_PaymentComment;
 private javax.swing.JCheckBox CB_PaymentDate;
 private javax.swing.JCheckBox CB_PaymentPrice;
 private javax.swing.JCheckBox CB_PaymentTransId;
 private javax.swing.JCheckBox CB_PaymentTransSalesman;
 private javax.swing.JCheckBox CB_PaymentTransSalesmanUndefined;
 private javax.swing.JCheckBox CB_PaymentTransSubject;
 private javax.swing.JCheckBox CB_PaymentTransSubjectUndefined;
 private javax.swing.JCheckBox CB_PaymentTransType;
 private javax.swing.JCheckBox CB_PaymentTransTypeUndefined;
 private javax.swing.JCheckBox CB_ResultSignTable;
 private javax.swing.JCheckBox CB_ResultSignText;
 private javax.swing.JComboBox<String> CmB_ChoosePayment;
 private javax.swing.JComboBox<String> CmB_DebtPayCurrDateDay;
 private javax.swing.JComboBox<String> CmB_DebtPayCurrDateMonth;
 private javax.swing.JComboBox<String> CmB_DebtPayInAddMethod;
 private javax.swing.JComboBox<String> CmB_DebtPayOutAddMethod;
 private javax.swing.JComboBox<String> CmB_IdColumn;
 private javax.swing.JComboBox<String> CmB_PaymentEndDay;
 private javax.swing.JComboBox<String> CmB_PaymentEndMonth;
 private javax.swing.JComboBox<String> CmB_PaymentStartDay;
 private javax.swing.JComboBox<String> CmB_PaymentStartMonth;
 private javax.swing.JLabel Label_Query;
 private javax.swing.JLabel Lbl_ChoosePayment;
 private javax.swing.JLabel Lbl_DebtPayAlreadySavingHelp;
 private javax.swing.JLabel Lbl_DebtPayCalculator;
 private javax.swing.JLabel Lbl_DebtPayCurrDate;
 private javax.swing.JLabel Lbl_DebtPayCurrDateHelp;
 private javax.swing.JLabel Lbl_DebtPayCurrSaving;
 private javax.swing.JLabel Lbl_DebtPayInHelp;
 private javax.swing.JLabel Lbl_DebtPayOutHelp;
 private javax.swing.JLabel Lbl_PaymentCommentHelp;
 private javax.swing.JLabel Lbl_PaymentPriceHelp;
 private javax.swing.JLabel Lbl_PaymentTransIdHelp;
 private javax.swing.JLabel Lbl_Result;
 private XList List_PaymentCash;
 private XList List_PaymentTransSalesman;
 private XList List_PaymentTransSubject;
 private XList List_PaymentTransType;
 private XList List_QueryEtc;
 private javax.swing.JPanel Panel_DebtPayment;
 private javax.swing.JPanel Panel_QueryEtc;
 private javax.swing.JPanel Panel_QueryPayment;
 private javax.swing.JPanel Panel_ResultTable;
 private javax.swing.JPanel Panel_ResultTableStatus;
 private javax.swing.JPanel Panel_ResultText;
 private javax.swing.JTextArea TA_QueryEtcInfo;
 private javax.swing.JTextArea TA_Result;
 private javax.swing.JTextField TF_DebtPayCurrDateYear;
 private javax.swing.JTextField TF_DebtPayCurrSaving;
 private javax.swing.JTextField TF_PaymentComment;
 private javax.swing.JTextField TF_PaymentEndYear;
 private javax.swing.JTextField TF_PaymentPrice1;
 private javax.swing.JTextField TF_PaymentPrice2;
 private javax.swing.JTextField TF_PaymentStartYear;
 private javax.swing.JTextField TF_PaymentTransId;
 private javax.swing.JTextField TF_TableResultCount;
 private javax.swing.JTextField TF_TempListQuantity;
 private javax.swing.JTabbedPane TabbedPane_Query;
 private javax.swing.JTabbedPane TabbedPane_Result;
 private XTable Tbl_DebtPayIn;
 private XTable Tbl_DebtPayOut;
 private XTable Tbl_Result;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 // End of variables declaration//GEN-END:variables
}
