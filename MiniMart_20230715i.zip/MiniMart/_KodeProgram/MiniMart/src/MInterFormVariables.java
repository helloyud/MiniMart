import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.KeyboardFocusManager;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.io.File;
import java.lang.reflect.Method;
import javax.print.PrintService;
import javax.swing.JFileChooser;
import java.net.URLClassLoader;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalLookAndFeel;

public class MInterFormVariables {

 public final static OApplicationVersion VersionOfApplication=CApp.getVersionOfApplication();
 public final static ODatabaseVersion VersionOfDatabase=CApp.getVersionOfDatabase();

 boolean IsError;
 String Step, SubStep;
 boolean DirectLogin;

 OKeyboardFocusManager KeyboardManager;

 // Variables from Configuration.txt
 OConfiguration Conf;

 // Variables
 Class Clas;
 URLClassLoader NewClassLoader;
 OParameterValueGroup AppInfo;
 String RunningDirectory;
 String BackupDirectory;
 String UserHomeDirectory;
 String TransLock;
 String TransPendLock;
 String PreTransLock;
 String PreTransPendLock;
 String RevStockLock;
 String OpnameLock;
 String OrderLock;
 String ConvertRuleLock;
 String ConvertingLock;
 Object StmSync;
 OParam Params;
 OGregorianCalendar Cal;
 OPreventAutoFire PreventAutoFire;
 
 BufferedImage AppLogo;
 BufferedImage UserLogo;
 
 PrintService PrinterDefault;

 OPaper CurrentReceiptPaper;
 PrintService CurrentReceiptPrinter;

 OPaper CurrentReportPaper;
 PrintService CurrentReportPrinter;

 OFont FontApp;
 OFont FontPrint;
 OFont FontPrintReceipt;
 OFont FontPrintReceiptThermal;
 OFont FontLabel;
 
 OPrintGeneratorReceipt PrintGenReceipt;
 OPrintGeneratorItem PrintGenItem;
 OPrintGeneratorItemCatalog PrintGenItemCatalog;
 OPrintGeneratorItemOrder PrintGenItemOrder;
 OPrintGeneratorItemCheckList PrintGenItemCheckList;
 OPrintGeneratorConvertRule PrintGenConvertRule;
 OPrintGeneratorConverting PrintGenConverting;
 OPrintGeneratorSubject PrintGenSubject;
 OPrintGeneratorTrans PrintGenTrans;
 OPrintGeneratorTransPayment PrintGenTransPayment;
 OPrintGeneratorLabel PrintGenLabel;
 OPrintGeneratorRevStock PrintGenRevStock;
 
 OBarcodeGeneratorEAN BarcodeGenEAN;
 
 Vector<OLabelCreator> LabelCreatorsItem;
 
 OFileFilterCsv CsvFileFilter;
 OFileFilterShop ShopFileFilter;
 OFileFilterImage ImageFileFilter;
 OFileFilterReport ReportFileFilter;
 OFileFilterLabel LabelFileFilter;
 
 // current user/connection's properties
 String CurrentUser;
 String CurrentPassword;
 Connection Conn;
 Statement Stm;
 boolean CurrentUserIsAdmin;
 
 // current database properties
 String CurrentDatabase;
 boolean[] CurrentUserPrivDb;
 boolean CurrentUserPrivDbPublic; // indicates the current user has at least one of public user access
 boolean CurrentUserPrivDbPrivate; // indicates the current user has at least one of private user access
 
 boolean PrivGUIShowBuyPrice;
 boolean PrivGUIShowItemSupplierList;
 boolean PrivGUIAddTrans;
 boolean PrivGUIShowTransList;
 boolean PrivGUIShowTransItemIn;
 boolean PrivGUIShowTransItemOut;
 boolean PrivGUIAddPreTrans;
 boolean PrivGUIShowPreTransList;
 boolean PrivGUIShowPreTransItemIn;
 boolean PrivGUIShowPreTransItemOut;

 // Forms
 F_Main FMain;
 F_Login FLogin;
 F_About FAbout;
 F_SetupDatabase FSetupDatabase;
 F_User FUser;
 F_UserModify FUserModify;
 F_UserDbPermission FUserDbPerm;
 F_Message FMessage;
 F_ApplicationInfo FAppInfo;

 F_DataIdName FDataIdName;
 F_DataIdNameImportAdd FDataIdNameImportAdd;
 F_IdNameModifyMulti FIdNameModifyMulti;
 F_Item FItem;
 F_ItemPreview FItemPreview;
 F_ItemModify FItemModify;
 F_ItemModifyMulti FItemModifyMulti;
 F_ItemVariantModify FItemVariantModify;
 F_ItemVariantModifyMulti FItemVariantModifyMulti;
 F_ItemSupplierModify FItemSupplierModify;
 F_ItemSupplierModifyMulti FItemSupplierModifyMulti;
 F_ItemImportAdd FItemImportAdd;
 F_ItemImportUpdate FItemImportUpdate;
 F_RevStock FRevStock;
 F_RevStockModify FRevStockModify;
 F_RevStockModifyMulti FRevStockModifyMulti;
 F_ConvertRule FConvertRule;
 F_ConvertRuleModify FConvertRuleModify;
 F_ConvertRuleModifyMulti FConvertRuleModifyMulti;
 F_ConvertRulePreview FConvertRulePreview;
 F_Converting FConverting;
 F_ConvertingModify FConvertingModify;
 F_ConvertingModifyMulti FConvertingModifyMulti;
 F_ConvertItemModify FConvertItemModify;
 F_ConvertItemModifyMulti FConvertItemModifyMulti;
 F_PrintItemCSV FPrintItemCSV;
 F_Subject FSubject;
 F_SubjectPreview FSubjectPreview;
 F_SubjectModify FSubjectModify;
 F_SubjectModifyMulti FSubjectModifyMulti;
 F_SubjectImportAdd FSubjectImportAdd;
 F_AddressModify FAddressModify;
 F_AddressModifyMulti FAddressModifyMulti;
 F_ContactModify FContactModify;
 F_ContactModifyMulti FContactModifyMulti;
 F_BankAccountModify FBankAccountModify;
 F_BankAccountModifyMulti FBankAccountModifyMulti;
 F_PrintSubjectCSV FPrintSubjectCSV;
 F_TransNew FTransNew;
 F_TransFinishSummary FTransFinishSummary;
 F_TransItemModify FTransItemModify;
 F_TransItemModifyMulti FTransItemModifyMulti;
 F_TransItemInOperation FTransItemInOperation;
 F_TransItemOutOperation FTransItemOutOperation;
 F_TransPending FTransPending;
 F_TransView FTransView;
 F_TransView FPreTransView;
 F_TransPreview FTransPreview;
 F_TransModify FTransModify;
 F_TransModifyMulti FTransModifyMulti;
 F_TransPaymentModify FTransPaymentModify;
 F_TransPaymentModifyMulti FTransPaymentModifyMulti;
 F_OrderModify FOrderModify;
 F_OrderModifyMulti FOrderModifyMulti;
 F_InputName FInputName;
 F_EditName FEditName;
 F_PrintSetting FPrintSetting;
 F_PrintDialog FPrintDialog;
 F_PrintPage FPrintPage;
 F_PrintItemReport FPrintItemReport;
 F_PrintRevStock FPrintRevStock;
 F_PrintTransReport FPrintTransReport;
 F_PrintTransReceipt FPrintTransReceipt;
 F_PrintTransCSV FPrintTransCSV;
 F_PrintConvertRule FPrintConvertRule;
 F_PrintConverting FPrintConverting;
 F_QueryEtc FQueryEtc;
	F_BillOutModify FBillOutModify;
 F_BillOutAddAuto FBillOutAddAuto;
	F_BillInModify FBillInModify;
 F_BillInAddAuto FBillInAddAuto;
 F_ItemLabel FItemLabel;
 F_ItemLabelModify FItemLabelModify;
 F_ItemLabelModifyMulti FItemLabelModifyMulti;
 F_PaperLabel FPaperLabel;
 F_PaperLabelModify FPaperLabelModify;
 F_TestPrintInfo FTestPrintInfo;
 F_SplashScreen FSplashScreen;
 F_CsvImportExport FCsvImportExport;
 F_CsvReadOption FCsvReadOption;
 F_CsvWriteOption FCsvWriteOption;
 F_ImagePreview FImagePreview;
 XFormFileChooser FileChooser;

 public void initializeVar(){
  IsError=true;
  FSplashScreen=null;
  
  do{
   try{
    fillStep("1"); loadBasicVariables();
    
    FSplashScreen=new F_SplashScreen(this);
    FSplashScreen.appear(null, "Mempersiapkan Aplikasi");
    
    fillStep("2"); initVariables();
    fillStep("3"); initForms();
    fillStep("4"); setupAppConnection();
   }
   catch(Exception E){System.out.println(E.toString()); break;}
   IsError=false;
  }while(false);

  if(FSplashScreen!=null){
   if(FSplashScreen.isVisible()){FSplashScreen.disappear();}
  }
 }
 
 //
 void fillStep(String Step){
  clearStep();
  this.Step=Step;
 }
 void clearStep(){
  Step=null;
  clearSubStep();
 }
 void fillSubStep(String SubStep){this.SubStep=SubStep;}
 void clearSubStep(){SubStep=null;}
 public String getInfoStep(){
  StringBuilder ret=new StringBuilder();
  
  do{
   if(PText.isEmptyString(Step, false, true)){ret.append("~"); break;} ret.append(Step);
   if(PText.isEmptyString(SubStep, false, true)){break;} ret.append("-"+SubStep);
  }
  while(false);
  
  return ret.toString();
 }
 
 //
 void loadBasicVariables() throws Exception{
  fillSubStep("a"); preLoadExternal();
  fillSubStep("b"); loadExternal();
  fillSubStep("c"); postLoadExternal();
 }
 void preLoadExternal() throws Exception{
  loadSystemVariables();
  registerGlobalKey();
  loadPrinterDefault();
 }
 void loadExternal() throws Exception{
  loadConfigurationFile();
  loadJarFiles();
  loadFontFiles();
 }
 void postLoadExternal() throws Exception{
  loadLookAndFeel();
  loadGUIGlobalSetting();
 }
 
 //
 void loadSystemVariables() throws Exception{
  RunningDirectory=System.getProperty("user.dir");
  if(RunningDirectory.charAt(RunningDirectory.length()-1)!=File.separatorChar){
   RunningDirectory=RunningDirectory+File.separatorChar;
  }
  Clas=getClass();
 }
 void loadGUIGlobalSetting() throws Exception{
  UIManager.put("ToggleButton.select", CGUI.Color_ToggleButton_Selected);
 }
 void registerGlobalKey() throws Exception{
  KeyboardManager=new OKeyboardFocusManager(this);
  KeyboardFocusManager.setCurrentKeyboardFocusManager(KeyboardManager);
 }
 void loadPrinterDefault() throws Exception{
  PrinterDefault=PPrint.getOperatingSystemDefaultPrinter(null);
  if(PrinterDefault==null){throw new Exception();}
 }
 void loadConfigurationFile() throws Exception{
  Conf=new OConfiguration(
   "127.0.0.1", 3306, "root", "",
   "",
   PFile.toDirectory(System.getProperty("user.home"), '/'),
   PFile.toDirectory(System.getProperty("user.home"), '/'),
   PText.getRandom(PMyShop.getWelcomeMessage()),
   true,
   CPrint.A4, PrinterDefault,
   CPrint.Thermal80, PrinterDefault,
   new OPaperMargin(CPrint.StandardPaperMarginTopDefault, CPrint.StandardPaperMarginBottomDefault, CPrint.StandardPaperMarginLeftDefault, CPrint.StandardPaperMarginRightDefault),
   new OPaperMargin(CPrint.ThermalPaperMarginTopDefault, CPrint.ThermalPaperMarginBottomDefault, CPrint.ThermalPaperMarginLeftDefault, CPrint.ThermalPaperMarginRightDefault)
  );

  PEtc.getConfiguration(new File(RunningDirectory+"lib"+CCore.Slash+"Konfigurasi.txt"), Conf);
 }
 void loadJarFiles() throws Exception{
  URLClassLoader NewClassLoader;
  Method mthod;
  Object[] parameters;
  
  /* load external jar file can't be done dynamically (load jar file during runtime) because of compability issue in Java 9
  NewClassLoader=(URLClassLoader)ClassLoader.getSystemClassLoader();
  mthod=URLClassLoader.class.getDeclaredMethod("addURL", new Class[]{URL.class});
  mthod.setAccessible(true);
  parameters=new Object[1];

   // load mysql_jdbc jar
  parameters[0]=new File(RunningDirectory+"lib"+CCore.Slash+"mysql-connector-java.jar").toURI().toURL();
  mthod.invoke(NewClassLoader, parameters);
  */
  Class.forName("com.mysql.jdbc.Driver");
 }
 void loadFontFiles() throws Exception{
  Font fnt=null;
  GraphicsEnvironment GraphEnv;
  
  Vector<Object[]> LoadFonts;
  Object[] CurrLoadFonts;
  int temp, count;
  boolean bool;
  OFont ofnt;
  
  /* note: GraphicsEnvironment.registerFont() returns true if it has successfully installed the font in current application's runtime,
     otherwise (such as the font is already exist in computer's system operation) it will returns false. */
  GraphEnv=GraphicsEnvironment.getLocalGraphicsEnvironment();

  LoadFonts=new Vector(); // font variable, internal font file, external font file 

  ofnt=new OFont(); FontApp=ofnt;
  LoadFonts.addElement(PCore.objArrVariant(ofnt, "/font/font-app.ttf", null));
  ofnt=new OFont(); FontPrint=ofnt;
  LoadFonts.addElement(PCore.objArrVariant(ofnt, "/font/font-print-report.ttf", RunningDirectory+"lib"+CCore.Slash+"Kustomisasi Font"+CCore.Slash+"font-cetak-laporan.ttf"));
  ofnt=new OFont(); FontPrintReceipt=ofnt;
  LoadFonts.addElement(PCore.objArrVariant(ofnt, "/font/font-print-receipt.ttf", RunningDirectory+"lib"+CCore.Slash+"Kustomisasi Font"+CCore.Slash+"font-cetak-nota.ttf"));
  ofnt=new OFont(); FontPrintReceiptThermal=ofnt;
  LoadFonts.addElement(PCore.objArrVariant(ofnt, "/font/font-print-receipt-thermal.ttf", RunningDirectory+"lib"+CCore.Slash+"Kustomisasi Font"+CCore.Slash+"font-cetak-nota-thermal.ttf"));
  ofnt=new OFont(); FontLabel=ofnt;
  LoadFonts.addElement(PCore.objArrVariant(ofnt, "/font/font-print-label.ttf", RunningDirectory+"lib"+CCore.Slash+"Kustomisasi Font"+CCore.Slash+"font-cetak-label.ttf"));

  count=LoadFonts.size();
  temp=0;
  do{
   CurrLoadFonts=LoadFonts.elementAt(temp);

   bool=false;
   if(CurrLoadFonts[2]!=null){
    do{
     try{
      fnt=Font.createFont(Font.TRUETYPE_FONT, new File((String)CurrLoadFonts[2]));
      if(!PFont.isMonospace(fnt)){break;}
     }
     catch(Exception E){break;}
     bool=true;
    }while(false);
   }
   if(!bool){fnt=Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream((String)CurrLoadFonts[1]));}
   GraphEnv.registerFont(fnt); ((OFont)CurrLoadFonts[0]).setFont(fnt.getFamily());

   temp=temp+1;
  }while(temp!=count);
 }
 void loadLookAndFeel() throws Exception{
  LookAndFeel Laf;
  
  /*
  Laf=IntelliJTheme.createLaf(getClass().getResourceAsStream("/laf/SolarizedLight.theme.json"));
  */
  Laf=new MetalLookAndFeel();
  
  do{
   try{UIManager.setLookAndFeel(Laf); break;}catch(Exception E){}
   try{UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel"); break;}catch(Exception E){}
   try{UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); break;}catch(Exception E){}
  }while(false);
 }
 
 //
 void initVariables() throws Exception{
  FSplashScreen.inform(0, "Menginisialisasi variabel aplikasi...", "-");
  
  FSplashScreen.inform(0, null, "Menginisialisasi variabel");
  
  AppInfo=PMyShop.getParameterValueOfApplicationInfo(VersionOfDatabase);
  CsvFileFilter=new OFileFilterCsv();
  ShopFileFilter=new OFileFilterShop();
  ImageFileFilter=new OFileFilterImage();
  ReportFileFilter=new OFileFilterReport();
  LabelFileFilter=new OFileFilterLabel();
  TransLock="TransLock";
  TransPendLock="TransPendLock";
  PreTransLock="PreTransLock";
  PreTransPendLock="PreTransPendLock";
  RevStockLock="RevStockLock";
  OpnameLock="OpnameLock";
  OrderLock="OrderLock";
  ConvertRuleLock="ConvertRuleLock";
  ConvertingLock="ConvertingLock";
  CurrentReportPaper=Conf.DefaultReportPaper.cloneWithMargin(CPrint.getMargin(true, 1), Conf.ThermalPaperMargin);
  CurrentReportPrinter=Conf.DefaultReportPrinter;
  CurrentReceiptPaper=Conf.DefaultReceiptPaper.cloneWithMargin(Conf.StandardPaperMargin, Conf.ThermalPaperMargin);
  CurrentReceiptPrinter=Conf.DefaultReceiptPrinter;
  PrintGenReceipt=new OPrintGeneratorReceipt(FontApp);
  PrintGenItem=new OPrintGeneratorItem(FontApp);
  PrintGenItemCatalog=new OPrintGeneratorItemCatalog(FontApp);
  PrintGenItemOrder=new OPrintGeneratorItemOrder(FontApp);
  PrintGenItemCheckList=new OPrintGeneratorItemCheckList(FontApp);
  PrintGenConvertRule=new OPrintGeneratorConvertRule(FontApp);
  PrintGenConverting=new OPrintGeneratorConverting(FontApp);
  PrintGenSubject=new OPrintGeneratorSubject(FontApp);
  PrintGenTrans=new OPrintGeneratorTrans(FontApp);
  PrintGenTransPayment=new OPrintGeneratorTransPayment(FontApp);
  PrintGenLabel=new OPrintGeneratorLabel();
  PrintGenRevStock=new OPrintGeneratorRevStock(FontApp);
  BarcodeGenEAN=new OBarcodeGeneratorEAN();
  LabelCreatorsItem=PMyShop.getLabelCreatorsItem(FontApp, FontLabel, Conf.StandardPaperMargin, Conf.ThermalPaperMargin);
  BackupDirectory=RunningDirectory+"lib"+File.separatorChar+"BackupData"+File.separatorChar;
  UserHomeDirectory=PFile.toDirectory(System.getProperty("user.home"), File.separatorChar);
  try{AppLogo=ImageIO.read(getClass().getResource("/pic/logo.png"));}catch(Exception E){}
  try{UserLogo=ImageIO.read(new File(RunningDirectory+"lib"+CCore.Slash+"Kustomisasi Gambar"+CCore.Slash+"img-logoku.png"));}catch(Exception E){}

  StmSync=new Object();
  Params=new OParam();
  Params.setParamCount(4);
  Cal=new OGregorianCalendar();
  PreventAutoFire=new OPreventAutoFire();
  
  FSplashScreen.inform(20, null, null);
 }
 void initForms() throws Exception{
  FSplashScreen.inform(0, "Menginisialisasi form aplikasi...", "-");
  
  fillSubStep("a");
  FSplashScreen.inform(0, null, "Menginisialisasi form umum");
  
  FMain=new F_Main(this);
  FAbout=new F_About(this);
  FLogin=new F_Login(this);
  FSetupDatabase=new F_SetupDatabase(this);
  FAppInfo=new F_ApplicationInfo(this);
  FCsvImportExport=new F_CsvImportExport(this);
  FCsvReadOption=new F_CsvReadOption(this);
  FCsvWriteOption=new F_CsvWriteOption(this);

  FPrintSetting=new F_PrintSetting(this);
  FPrintDialog=new F_PrintDialog(this);
  FPrintPage=new F_PrintPage(this);

  FDataIdName=new F_DataIdName(this);
  FDataIdNameImportAdd=new F_DataIdNameImportAdd(this);
  FInputName=new F_InputName(this);
  FEditName=new F_EditName(this);
  FIdNameModifyMulti=new F_IdNameModifyMulti(this);
  FMessage=new F_Message(this);
  FileChooser=new XFormFileChooser();
  FileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
  FileChooser.setCurrentDirectory(new File(UserHomeDirectory));

  FSplashScreen.inform(15, null, null);

  fillSubStep("b");
  FSplashScreen.inform(0, null, "Menginisialisasi form barang");

  FItem=new F_Item(this);
  FItemPreview=new F_ItemPreview(this);
  FItemModify=new F_ItemModify(this);
  FItemModifyMulti=new F_ItemModifyMulti(this);
  FItemVariantModify=new F_ItemVariantModify(this);
  FItemVariantModifyMulti=new F_ItemVariantModifyMulti(this);
  FItemSupplierModify=new F_ItemSupplierModify(this);
  FItemSupplierModifyMulti=new F_ItemSupplierModifyMulti(this);
  FItemImportAdd=new F_ItemImportAdd(this);
  FItemImportUpdate=new F_ItemImportUpdate(this);
  FRevStock=new F_RevStock(this);
  FRevStockModify=new F_RevStockModify(this);
  FRevStockModifyMulti=new F_RevStockModifyMulti(this);
  FConvertRule=new F_ConvertRule(this);
  FConvertRuleModify=new F_ConvertRuleModify(this);
  FConvertRuleModifyMulti=new F_ConvertRuleModifyMulti(this);
  FConvertRulePreview=new F_ConvertRulePreview(this);
  FConverting=new F_Converting(this);
  FConvertingModify=new F_ConvertingModify(this);
  FConvertingModifyMulti=new F_ConvertingModifyMulti(this);
  FConvertItemModify=new F_ConvertItemModify(this);
  FConvertItemModifyMulti=new F_ConvertItemModifyMulti(this);
  FPrintConvertRule=new F_PrintConvertRule(this);
  FPrintConverting=new F_PrintConverting(this);
  FItemLabel=new F_ItemLabel(this);
  FItemLabelModify=new F_ItemLabelModify(this);
  FItemLabelModifyMulti=new F_ItemLabelModifyMulti(this);
  FPrintItemReport=new F_PrintItemReport(this);
  FPrintItemCSV=new F_PrintItemCSV(this);
  FPrintRevStock=new F_PrintRevStock(this);

  FSplashScreen.inform(15, null, null);

  fillSubStep("c");
  FSplashScreen.inform(0, null, "Menginisialisasi form subjek");

  FSubject=new F_Subject(this);
  FSubjectPreview=new F_SubjectPreview(this);
  FSubjectModify=new F_SubjectModify(this);
  FSubjectModifyMulti=new F_SubjectModifyMulti(this);
  FSubjectImportAdd=new F_SubjectImportAdd(this);
  FAddressModify=new F_AddressModify(this);
  FAddressModifyMulti=new F_AddressModifyMulti(this);
  FContactModify=new F_ContactModify(this);
  FContactModifyMulti=new F_ContactModifyMulti(this);
  FBankAccountModify=new F_BankAccountModify(this);
  FBankAccountModifyMulti=new F_BankAccountModifyMulti(this);
  FPrintSubjectCSV=new F_PrintSubjectCSV(this);

  FSplashScreen.inform(15, null, null);

  fillSubStep("d");
  FSplashScreen.inform(0, null, "Menginisialisasi form transaksi");

  FTransNew=new F_TransNew(this);
  FTransFinishSummary=new F_TransFinishSummary(this);
  FTransPending=new F_TransPending(this);
  FTransView=new F_TransView(this, false);
  FPreTransView=new F_TransView(this, true);
  FTransPreview=new F_TransPreview(this);
  FTransModify=new F_TransModify(this);
  FTransModifyMulti=new F_TransModifyMulti(this);
  FTransItemModify=new F_TransItemModify(this);
  FTransItemModifyMulti=new F_TransItemModifyMulti(this);
  FTransItemInOperation=new F_TransItemInOperation(this);
  FTransItemOutOperation=new F_TransItemOutOperation(this);
  FTransPaymentModify=new F_TransPaymentModify(this);
  FTransPaymentModifyMulti=new F_TransPaymentModifyMulti(this);
  FPrintTransReport=new F_PrintTransReport(this);
  FPrintTransReceipt=new F_PrintTransReceipt(this);
  FPrintTransCSV=new F_PrintTransCSV(this);
  FOrderModify=new F_OrderModify(this);
  FOrderModifyMulti=new F_OrderModifyMulti(this);

  FSplashScreen.inform(15, null, null);

  fillSubStep("e");
  FSplashScreen.inform(0, null, "Menginisialisasi form khusus");

  FUser=new F_User(this);
  FUserModify=new F_UserModify(this);
  FUserDbPerm=new F_UserDbPermission(this);

  FQueryEtc=new F_QueryEtc(this);
  FBillOutModify=new F_BillOutModify(this);
  FBillOutAddAuto=new F_BillOutAddAuto(this);
  FBillInModify=new F_BillInModify(this);
  FBillInAddAuto=new F_BillInAddAuto(this);

  FPaperLabel=new F_PaperLabel(this);
  FPaperLabelModify=new F_PaperLabelModify(this);
  FTestPrintInfo=new F_TestPrintInfo(this);
  
  FImagePreview=new F_ImagePreview(this);

  FSplashScreen.inform(15, null, null);
 }
 void setupAppConnection() throws Exception{
  FSplashScreen.inform(0, "Mencoba koneksi ke database server MySQL...", "-");
  
  Conn=null; Stm=null;
  CurrentDatabase=null;
  DirectLogin=false;
  if(Conf.User.length()!=0){
   DirectLogin=setupConnectionAndUseADatabase(Conf.User, Conf.Password, Conf.DefaultDatabase);
   if(DirectLogin){FSplashScreen.inform(0, null, "Berhasil login");}
   else{FSplashScreen.inform(0, null, "Gagal login");}
  }
  
  FSplashScreen.inform(5, null, null);
 }
 
 // setup user (public)
 public boolean setupConnection(String User, String Password){
  boolean ret=false;
  
  do{
   if(!openConnectionObjects(User, Password)){break;}
   fillCurrentUser(User, Password);
   
   ret=true;
  }while(false);
  
  if(!ret){closeConnectionObjects();}
  
  return ret;
 }
 public boolean setupConnectionAndUseADatabase(String User, String Password, String InitDb){
  boolean ret=setupConnection(User, Password);
  
  if(ret){useADatabase(InitDb);}
  
  return ret;
 }
 public void closeConnection(boolean AlsoRemoveConnectionProperties){
  closeConnectionObjects();
  if(AlsoRemoveConnectionProperties){removeConnectionProperties();}
 }
 public boolean refreshConnection(boolean ShowMessage){
  boolean ret=false;
  
  do{
   closeConnection(false);
   if(!setupConnection(CurrentUser, CurrentPassword)){break;}
   if(!useADatabase(CurrentDatabase)){break;}
   ret=true;
  }while(false);
  
  if(ShowMessage){
   if(ret){JOptionPane.showMessageDialog(null, "Berhasil menyegarkan koneksi ke Database Server !");}
   else{JOptionPane.showMessageDialog(null, "Gagal menyegarkan koneksi ke Database Server !");}
  }
  
  return ret;
 }
 
 // setup user (private)
 Connection getConnection(String User, String Password){
  Connection ret=null;
  Connection rettemp;
  do{
   try{
    if(Password.length()!=0){rettemp=DriverManager.getConnection("jdbc:mysql://"+Conf.Host+":"+String.valueOf(Conf.Port), User, Password);}
    else{rettemp=DriverManager.getConnection("jdbc:mysql://"+Conf.Host+":"+String.valueOf(Conf.Port)+"/?user='"+PSql.norm(User)+"'");}
   }
   catch(Exception E){break;}
   ret=rettemp;
  }while(false);
  return ret;
 }
 boolean openConnectionObjects(String User, String Password){
  boolean ret=false;
  do{
   Conn=getConnection(User, Password); if(Conn==null){break;}
   try{Stm=Conn.createStatement();}catch(Exception E){break;}
   ret=true;
  }while(false);
  return ret;
 }
 void closeConnectionObjects(){
  if(Stm!=null){
   try{Stm.close();}catch(Exception E){}
   Stm=null;
  }
  if(Conn!=null){
   try{Conn.close();}catch(Exception E){}
   Conn=null;
  }
 }
 void fillCurrentUser(String User, String Password){
  CurrentUser=User; CurrentPassword=Password;
  fillCurrentUserIsAdmin();
 }
 void clearCurrentUser(){
  CurrentUser=null; CurrentPassword=null;
  clearCurrentUserIsAdmin();
 }
 void fillCurrentUserIsAdmin(){CurrentUserIsAdmin=PDatabaseUser.hasAdminPrivilleges(Stm, CurrentUser)==1;}
 void clearCurrentUserIsAdmin(){CurrentUserIsAdmin=false;}
 void removeConnectionProperties(){
  clearCurrentDatabase();
  clearCurrentUser();
 }
 
 // setup database (public)
 public boolean useADatabase(String ADatabase){
  boolean ret=useDb(Stm, ADatabase);

  if(ret==false){return ret;}
  
  fillCurrentDatabase(ADatabase);

  return ret;
 }
 
 // setup database (private)
 boolean useDb(Statement Stm, String Db){
  boolean ret=true;

  do{
   if(Db==null){break;}
   if(Db.length()==0){break;}
   try{Stm.execute("use "+Db+";");}catch(Exception E_){ret=false;}
  }while(false);

  return ret;
 }
 void fillCurrentDatabase(String ADatabase){
  CurrentDatabase=ADatabase;
  if(CurrentDatabase!=null){
   if(CurrentDatabase.length()==0){CurrentDatabase=null;}
  }
  fillCurrentUserPrivDb();
 }
 void clearCurrentDatabase(){
  CurrentDatabase=null;
  clearCurrentUserPrivDb();
 }
 void fillCurrentUserPrivDb(){
  boolean[] PrivDb;
  
  clearCurrentUserPrivDb();
  
  if(CurrentDatabase!=null){
   PrivDb=PDatabaseUser.getDatabasePrivilleges(Stm, CurrentUser, CurrentDatabase, true, true);
   if(PrivDb!=null){CurrentUserPrivDb=PrivDb;}
  }
  fillCurrentUserPrivDbInfo();
  
  fillPrivGUI();
 }
 void clearCurrentUserPrivDb(){
  CurrentUserPrivDb=PCore.newBooleanArray(PDatabaseUser.DatabasePrivillegesCount, false);
  fillCurrentUserPrivDbInfo();
  clearPrivGUI();
 }
 void fillCurrentUserPrivDbInfo(){
  CurrentUserPrivDbPublic=PCore.checkBool(false, false, CurrentUserPrivDb[1], CurrentUserPrivDb[3], CurrentUserPrivDb[5], CurrentUserPrivDb[7]);
  CurrentUserPrivDbPrivate=PCore.checkBool(false, false, CurrentUserPrivDb[2], CurrentUserPrivDb[4], CurrentUserPrivDb[6], CurrentUserPrivDb[8]);
 }
 void fillPrivGUI(){
  clearPrivGUI();
  
  // set PrivGUI for admin
  if(CurrentUserIsAdmin){setAllPrivGUI(true); return;}
  
  // set PrivGUI for non-admin
  if(CurrentUserPrivDb[0]){} /* View All */
  if(CurrentUserPrivDb[1]){setPrivGUI(false, true, true, false, false, false, false, false, false, false, false);} /* Item Public */
  if(CurrentUserPrivDb[2]){} /* Item Private */
  if(CurrentUserPrivDb[3]){} /* Subject Public */
  if(CurrentUserPrivDb[4]){} /* Subject Private */
  if(CurrentUserPrivDb[5]){setPrivGUI(false, false, false, true, true, false, true, false, false, false, false);} /* Trans Public */
  if(CurrentUserPrivDb[6]){setPrivGUI(false, false, false, false, false, true, false, false, false, false, false);} /* Trans Private */
  if(CurrentUserPrivDb[7]){setPrivGUI(false, false, false, false, false, false, false, true, true, false, true);} /* PreTrans Public */
  if(CurrentUserPrivDb[8]){setPrivGUI(false, false, false, false, false, false, false, false, false, true, false);} /* PreTrans Private */
 }
 void clearPrivGUI(){setAllPrivGUI(false);}
 void setPrivGUI(boolean StrictSet,
  boolean vPrivGUIShowBuyPrice, boolean vPrivGUIShowItemSupplierList,
  boolean vPrivGUIAddTrans, boolean vPrivGUIShowTransList, boolean vPrivGUIShowTransItemIn, boolean vPrivGUIShowTransItemOut,
  boolean vPrivGUIAddPreTrans, boolean vPrivGUIShowPreTransList, boolean vPrivGUIShowPreTransItemIn, boolean vPrivGUIShowPreTransItemOut){
  if(StrictSet || vPrivGUIShowBuyPrice){PrivGUIShowBuyPrice=vPrivGUIShowBuyPrice;}
  if(StrictSet || vPrivGUIShowItemSupplierList){PrivGUIShowItemSupplierList=vPrivGUIShowItemSupplierList;}
  if(StrictSet || vPrivGUIAddTrans){PrivGUIAddTrans=vPrivGUIAddTrans;}
  if(StrictSet || vPrivGUIShowTransList){PrivGUIShowTransList=vPrivGUIShowTransList;}
  if(StrictSet || vPrivGUIShowTransItemIn){PrivGUIShowTransItemIn=vPrivGUIShowTransItemIn;}
  if(StrictSet || vPrivGUIShowTransItemOut){PrivGUIShowTransItemOut=vPrivGUIShowTransItemOut;}
  if(StrictSet || vPrivGUIAddPreTrans){PrivGUIAddPreTrans=vPrivGUIAddPreTrans;}
  if(StrictSet || vPrivGUIShowPreTransList){PrivGUIShowPreTransList=vPrivGUIShowPreTransList;}
  if(StrictSet || vPrivGUIShowPreTransItemIn){PrivGUIShowPreTransItemIn=vPrivGUIShowPreTransItemIn;}
  if(StrictSet || vPrivGUIShowPreTransItemOut){PrivGUIShowPreTransItemOut=vPrivGUIShowPreTransItemOut;}
 }
 void setAllPrivGUI(boolean Value){
  setPrivGUI(true, Value, Value, Value, Value, Value, Value, Value, Value, Value, Value);
 }
 
 //
 public boolean canAccessGUI(int AccessGUI_Type, boolean ShowMessage, boolean NonAdminAllowCondition){
  // MessageType : 1 Form, 2 Feature, 3 Search Query
  boolean ret=CurrentUserIsAdmin || NonAdminAllowCondition;
  String GuiType=null;
  
  if(!ret && ShowMessage){
   switch(AccessGUI_Type){
    case 1 : GuiType="form"; break;
    case 2 : GuiType="fitur"; break;
    case 3 : GuiType="pencarian"; break;
   }
   JOptionPane.showMessageDialog(null, "Maaf, anda tidak berhak mengakses "+GuiType+" ini !");
  }
  
  return ret;
 }
 
 //
 void closeApplication(){
  closeConnection(true);
  System.exit(0);
 }

}