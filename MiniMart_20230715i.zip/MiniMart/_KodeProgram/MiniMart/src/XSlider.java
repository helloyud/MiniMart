import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JSlider;

public class XSlider extends JSlider {
 
 int OnKeyPress_SliderValue;
 int FocusState;
 
 public XSlider(){
  super();
  
  addKeyListener(new KeyAdapter(){
    public void keyPressed(KeyEvent evt){
     setFocusState(CGUI.FocusState_Work);
     setOnKeyPressSliderValue(getValue());
    }
   });
  
  addFocusListener(new FocusAdapter(){
    public void focusGained(FocusEvent evt){setFocusState(CGUI.FocusState_Enter);}
    public void focusLost(FocusEvent evt){setFocusState(CGUI.FocusState_Leave);}
   });
 }
 
 void setOnKeyPressSliderValue(int SliderValue){
  OnKeyPress_SliderValue=SliderValue;
 }
 void setFocusState(int Value){
  FocusState=Value;
 }

}