import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class ODrawComponentLabel extends ODrawComponent {
 
 // create BufferedImage using specific OLabelCreator
 OLabelCreator LabelCreator;
 OLabelData LabelData;
 
 // post-process operation
 boolean Rotate90Degree;
 
 // finally, draw the BufferedImage at (OffsetX, OffsetY) of the paper

 public ODrawComponentLabel(double OffsetX, double OffsetY,
  OLabelCreator LabelCreator, OLabelData LabelData, boolean Rotate90Degree) {
  this.OffsetX=OffsetX;
  this.OffsetY=OffsetY;
  this.LabelCreator=LabelCreator;
  this.LabelData=LabelData;
  this.Rotate90Degree=Rotate90Degree;
 }
 
 public void draw(Graphics2D graphics, OGraphicsProperties Prop){
  BufferedImage MemImg;
  double scaleup;
  
  LabelCreator.setLabelData(LabelData);
  scaleup=1.5;
  MemImg=LabelCreator.createBufferedImage(Prop.scalefactor_image_max*scaleup);

  PGraphics.paintImageXY(graphics, OffsetX, OffsetY, MemImg, true, Prop.scalefactor_image_diff, 1*(1/scaleup), PCore.subtBool_Int(!Rotate90Degree, CGraph.Rotate_000Degree, CGraph.Rotate_270Degree));
 }
 
 public ODimension calcDrawDimension(){
  ODimension ret=new ODimension();
  double width, height;
  
  width=PCore.subtBool_Double(!Rotate90Degree, LabelCreator.Papr.LabelWidth, LabelCreator.Papr.LabelHeight);
  height=PCore.subtBool_Double(!Rotate90Degree, LabelCreator.Papr.LabelHeight, LabelCreator.Papr.LabelWidth);
  ret.setSize(width, height);
  
  return ret;
 }
 
}