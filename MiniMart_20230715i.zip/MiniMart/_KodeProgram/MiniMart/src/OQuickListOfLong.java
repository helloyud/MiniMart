import java.util.Vector;

class OQuickListOfLong {
 
 long[] Elements;
 int ArrayLength;
 
 int InitialCapacity;
 int GrowCapacity;
 
 int ElementsCount;
 
 boolean Sorted;
 boolean OnlyPositiveValue;
 int IntervalSearch;
 
 OQuickListOfLong(int InitialCapacity, int GrowCapacity, boolean Sorted, boolean OnlyPositiveValue){
  Elements=new long[InitialCapacity];
  ArrayLength=InitialCapacity;
  
  this.InitialCapacity=InitialCapacity;
  this.GrowCapacity=GrowCapacity;
  
  ElementsCount=0;
  
  this.Sorted=Sorted;
  this.OnlyPositiveValue=OnlyPositiveValue;
  IntervalSearch=128;
 }
 
 int addElement(long Element){
  int ret=-1; // -1 add a new element, >= 0 found
  int temp;
  
  if(OnlyPositiveValue){
   if(Element<0){return 0;}
  }
  
  // search if exists
  temp=checkElement(Element);
  
  if(temp<0){
   // add a new Element
   addAt((-1*temp)-1, Element);
  }
  else{ret=temp;}
  
  
  return ret;
 }
 int[] addElements(long[] Elmts, boolean IsAdd){
  Vector<Integer> ret=new Vector();
  int temp, length;
  boolean bool;
  
  if(Elmts==null){return PCore.primArr_VectInt(ret);}
  length=Elmts.length;
  if(length==0){return PCore.primArr_VectInt(ret);}
  
  temp=0;
  do{
   if(IsAdd){bool=addElement(Elmts[temp])==-1;}
   else{bool=removeElement(Elmts[temp]);}
   
   if(bool){ret.addElement(temp);}
   
   temp=temp+1;
  }while(temp!=length);
  
  return PCore.primArr_VectInt(ret);
 }
 void appendElement(long Element){
  if(OnlyPositiveValue){
   if(Element<0){return;}
  }
  
  if(Sorted){addElement(Element);}
  else{addAt(ElementsCount, Element);}
 }
 boolean removeElement(long Element){
  int temp;
  
  if(OnlyPositiveValue){
   if(Element<0){return false;}
  }
  
  temp=checkElement(Element);
  
  if(temp>=0){removeAt(temp);}
  return temp>=0;
 }
 void removeElementAtIndex(int[] Index){
  // Index must sorted ascending
  int temp;
  temp=Index.length-1;
  do{
   removeAt(Index[temp]);
   temp=temp-1;
  }while(temp!=-1);
 }
 void removeElementsAtIndexUnsorted(int[] Index){
  int temp, length;
  length=Index.length;
  int[] UpdateableIndex=Index.clone();
  temp=0;
  do{
   removeAt(UpdateableIndex[temp]);
   updateSelectedIndicesAfterRemove(UpdateableIndex, temp);
   
   temp=temp+1;
  }while(temp!=length);
 }
 void removeAll(){
  if(ArrayLength!=InitialCapacity){
   Elements=new long[InitialCapacity];
   ArrayLength=InitialCapacity;
  }
  ElementsCount=0;
 }
 void replaceElements(long[] NewElements, int NewElementsCount){
  boolean IsEmpty=false;
  
  if(NewElements==null){IsEmpty=true;}
  else{if(NewElements.length==0){IsEmpty=true;}}
  if(!IsEmpty){Elements=NewElements;}
  else{Elements=new long[InitialCapacity];}
  ArrayLength=Elements.length;
  
  ElementsCount=NewElementsCount;
  if(ElementsCount>ArrayLength){ElementsCount=ArrayLength;}
  
  if(Sorted){PCore.sort(Elements, ElementsCount);}
 }
 long[] getElements(){
  long[] ret=new long[ElementsCount];
  if(ElementsCount!=0){
   copyArray(0, ElementsCount, ret, 0);
  }
  return ret;
 }
 int checkElement(long Element){
  int ret; // (0 ... ElementsCount-1) found index, (-1 ... -(ElementsCount+1)) not found / insert index
  int temp, temp2;
  boolean find, loop, searchforward;
  
  find=false;
  
  temp=0;
  if(ElementsCount!=0){
   if(Sorted){
    searchforward=true;
    if(ElementsCount!=1){
     if(Element>Elements[ElementsCount-1]){searchforward=false;}
     else{
      if(Element>=Elements[0]){
       if(Elements[ElementsCount-1]-Element < Element-Elements[0]){searchforward=false;}
      }
     }
    }
    
    // search forward
    if(searchforward){
     temp=0;
     do{
      temp2=temp+IntervalSearch;
      if(temp2>=ElementsCount){temp2=ElementsCount-1;}

      if(Element<=Elements[temp2]){
       loop=true;
       do{
        if(Element<=Elements[temp]){break;}
        temp=temp+1;
       }while(loop);
       break;
      }

      temp=temp2+1;
     }while(temp!=ElementsCount);
     
     if(temp!=ElementsCount){
      if(Element==Elements[temp]){find=true;}
     }
    }
    // search backward
    else{
     temp=ElementsCount-1;
     do{
      temp2=temp-IntervalSearch;
      if(temp2<0){temp2=0;}

      if(Element>=Elements[temp2]){
       loop=true;
       do{
        if(Element>=Elements[temp]){break;}
        temp=temp-1;
       }while(loop);
       break;
      }

      temp=temp2-1;
     }while(temp!=-1);
     
     if(temp!=-1){
      if(Element==Elements[temp]){find=true;}
     }
     if(!find){temp=temp+1;}
    }
   }
   else{
    do{
     if(Elements[temp]==Element){find=true; break;}
     temp=temp+1;
    }while(temp!=ElementsCount);
   }
  }
  
  ret=temp;
  if(!find){ret=-1*(ret+1);}
  
  return ret;
 }

 void removeAt(int Index){
  if(Index!=ElementsCount-1){copyArray(Index+1, ElementsCount-(Index+1), Elements, Index);}
  ElementsCount=ElementsCount-1;
 }
 void addAt(int Index, long Value){
  long[] NewArray;
  if(ElementsCount==ArrayLength){
   NewArray=new long[ArrayLength+GrowCapacity];
   copyArray(0, ArrayLength, NewArray, 0);
   Elements=NewArray;
   ArrayLength=ArrayLength+GrowCapacity;
  }
  if(Index!=ElementsCount){copyArray(Index, (ElementsCount-Index), Elements, Index+1);}
  Elements[Index]=Value;
  ElementsCount=ElementsCount+1;
 }
 void changeAt(int Index, long Value){
  Elements[Index]=Value;
 }
 long getValueObject(int DataType, Object Obj){
  long ret=-1;
  
  switch(DataType){
   case CCore.TypeInteger : ret=PCore.objInteger(Obj, -1); break;
   case CCore.TypeLong : ret=PCore.objLong(Obj, -1L); break;
  }
  
  return ret;
 }
 private void copyArray(int StartOffset, int Length, long[] DestArray, int DestStartOffset){
  System.arraycopy(Elements, StartOffset, DestArray, DestStartOffset, Length);
 }
 private void updateSelectedIndicesAfterRemove(int[] SelectedIndices, int RemovedAt){
  // on assumption that remove operation is from up to down
  int temp, length;
  int RealIndex, currindex;
  length=SelectedIndices.length;
  if(RemovedAt!=length-1){
   RealIndex=SelectedIndices[RemovedAt];
   temp=RemovedAt+1;
   do{
    currindex=SelectedIndices[temp];
    if(currindex>RealIndex){SelectedIndices[temp]=currindex-1;}
    temp=temp+1;
   }while(temp!=length);
  }
 }
 
}