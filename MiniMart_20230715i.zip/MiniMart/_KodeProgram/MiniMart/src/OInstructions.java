import java.util.Vector;

public abstract class OInstructions {
 
 // this instructions identity
 public abstract int getInstructionsType();
 
 // data from previous instructions
 Vector<OAnObject> PreviousData;
 
 public int[] Instructions;
 
 public OInstructions Next;

 public OInstructions() {
  PreviousData=new Vector();
  Next=null;
 }
 
 public OInstructions executeChainedInstructions(OFormSupportsInstructions Form) throws Exception{
  OInstructions ret=null; // return last Instructions object
  OInstructions Inst=this;
  do{
   ret=Inst;
   Inst.process(Form);
   Inst=Inst.Next;
  }while(Inst!=null);
  return ret;
 }

 private void process(OFormSupportsInstructions Form) throws Exception{
  processing(Form);
  clearProcessedData();
 }
 private void clearProcessedData(){
  PreviousData.clear();
  clearProcessedDataAdditional();
 }
 
 abstract void processing(OFormSupportsInstructions Form) throws Exception;
 abstract void clearProcessedDataAdditional();
 
}