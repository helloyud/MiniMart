import java.awt.Component;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public class PCore {
 
 static OGregorianCalendar Cal=new OGregorianCalendar();
 
 // new
 public static boolean[] newBooleanArray(int ArrayLength, boolean InitializeValue){
  boolean[] ret=new boolean[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static int[] newIntegerArray(int ArrayLength, int InitializeValue){
  int[] ret=new int[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static int[] newIntegerArrayInOrderedSequence(int ArrayLength, int StartValue, int AddValue){
  int[] ret=new int[ArrayLength];
  int temp, CurrValue;
  if(ArrayLength!=0){
   CurrValue=StartValue;
   temp=0;
   do{
    ret[temp]=CurrValue;
    CurrValue=CurrValue+AddValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static long[] newLongArray(int ArrayLength, long InitializeValue){
  long[] ret=new long[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static double[] newDoubleArray(int ArrayLength, double InitializeValue){
  double[] ret=new double[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static char[] newCharacterArray(int ArrayLength, char InitializeValue){
  char[] ret=new char[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static char[] newCharacterArrayInOrderedSequence(char StartValue, char EndValue){
  char[] ret=null;
  int vStart=StartValue;
  int temp, count;
  count=(int)EndValue-vStart+1;
  if(count<=0){return ret;}
  ret=new char[count];
  temp=0;
  do{
   ret[temp]=(char)(vStart+temp);
   temp=temp+1;
  }while(temp!=count);
  return ret;
 }
 public static String[] newStringArray(int ArrayLength, String InitializeValue){
  String[] ret=new String[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 public static Object[] newObjectArray(int ArrayLength, Object InitializeValue){
  Object[] ret=new Object[ArrayLength];
  int temp;
  if(ArrayLength!=0){
   temp=0;
   do{
    ret[temp]=InitializeValue;
    temp=temp+1;
   }while(temp!=ArrayLength);
  }
  return ret;
 }
 
 //
 public static long[] convertPrimArrIntToLong(int[] Data){
  long[] ret=null;
  int temp, count;
  long AData;
  
  if(Data==null){return ret;}
  count=Data.length;
  ret=new long[count]; if(count==0){return ret;}
  
  temp=0;
  do{
   AData=Data[temp];
   
   ret[temp]=AData;
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 public static int[] convertPrimArrLongToInt(long[] Data){
  int[] ret=null;
  int temp, count;
  int AData;
  
  if(Data==null){return ret;}
  count=Data.length;
  ret=new int[count]; if(count==0){return ret;}
  
  temp=0;
  do{
   AData=(int)Data[temp];
   
   ret[temp]=AData;
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 
 // Reference array (typing values) -> Primitive array
 public static char[] primArr(Character... MultiData){
  char[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new char[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static int[] primArr(Integer... MultiData){
  int[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new int[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static long[] primArr(Long... MultiData){
  long[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new long[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static boolean[] primArr(Boolean... MultiData){
  boolean[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new boolean[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static double[] primArr(Double... MultiData){
  double[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new double[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Vector -> Primitive array
 public static int[] primArr_VectInt(Vector<Integer> MultiData){
  int[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new int[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static long[] primArr_VectLong(Vector<Long> MultiData){
  long[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new long[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static char[] primArr_VectChar(Vector<Character> MultiData){
  char[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new char[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static String[] primArr_VectString(Vector<String> MultiData){
  String[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new String[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Vector<Object> -> Primitive array
 public static int[] primArrInt_VectObj(Vector<Object> MultiData){
  int[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new int[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=(Integer)MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static long[] primArrLong_VectObj(Vector<Object> MultiData){
  long[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new long[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=(Long)MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Reference array (typing values) -> Reference array
 public static Boolean[] refArr(Boolean... MultiData){return MultiData;}
 public static Integer[] refArr(Integer... MultiData){return MultiData;}
 public static Long[] refArr(Long... MultiData){return MultiData;}
 public static Double[] refArr(Double... MultiData){return MultiData;}
 public static String[] refArr(String... MultiData){return MultiData;}
 public static Component[] cmpArr(Component... MultiData){return MultiData;}
 
 // Primitive array -> Reference array
 public static Boolean[] refArr_PrimArr(boolean[] MultiData){
  Boolean[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Boolean[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Integer[] refArr_PrimArr(int[] MultiData){
  Integer[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Integer[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Long[] refArr_PrimArr(long[] MultiData){
  Long[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Long[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Double[] refArr_PrimArr(double[] MultiData){
  Double[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Double[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Vector -> Reference array
 public static Boolean[] refArr_VectBool(Vector<Boolean> MultiData){
  Boolean[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new Boolean[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static String[] refArr_VectStr(Vector<String> MultiData){
  String[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new String[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static String[] refArr_VectCharToStr(Vector<Character> MultiData){
  String[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new String[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2).toString();
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 public static Integer[] refArrInt_VectObj(Vector<Object> MultiData){
  Integer[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new Integer[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=(Integer)MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Long[] refArrLong_VectObj(Vector<Object> MultiData){
  Long[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new Long[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=(Long)MultiData.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Reference array (typing values) -> Vector
 public static Vector<String> vect(String... MultiData){
  Vector<String> ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(MultiData[temp2]);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Vector<Integer> vect(Integer... MultiData){
  Vector<Integer> ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(MultiData[temp2]);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Vector<Long> vect(Long... MultiData){
  Vector<Long> ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(MultiData[temp2]);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Reference array (typing values) -> Object array
 public static Object[] objArr(Integer... MultiData){
  Object[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Object[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Object[] objArr(String... MultiData){
  Object[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Object[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Object[] objArrVariant(Object... MultiData){
  Object[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Object[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Primitive array -> Object array
 public static Object[] objArr_PrimArr(int[] MultiData){
  Object[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Object[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Object[] objArr_PrimArr(long[] MultiData){
  Object[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.length;
  ret=new Object[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData[temp2];
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Vector<?> -> Object array
 public static Object[] objArr_Vect(Vector<?> Source){
  Object[] ret=null;
  int temp, temp2;
  
  if(Source==null){return ret;}
  temp=Source.size();
  ret=new Object[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=Source.elementAt(temp2);
   temp2=temp2+1;
  }while(temp2!=temp);
  
  return ret;
 }
 
 // Vector<Object> -> String array
 public static String[] strArr_VectObj(Vector<Object> MultiData){
  String[] ret=null;
  int temp, temp2;
  if(MultiData==null){return ret;}
  temp=MultiData.size();
  ret=new String[temp];
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret[temp2]=MultiData.elementAt(temp2).toString();
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Object array (typing values) -> Vector<Object>
 public static Vector<Object> vectObj(Object... Source){
  Vector<Object> ret=null;
  int temp, temp2;
  if(Source==null){return ret;}
  temp=Source.length;
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(Source[temp2]);
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // Vector<?> -> Vector<Object>
 public static Vector<Object> vectObj_Vect(Vector<?> Source){
  Vector<Object> ret=null;
  int temp, temp2;
  if(Source==null){return ret;}
  temp=Source.size();
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(Source.elementAt(temp2));
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 // 
 public static void concatVect(Vector<Integer> Data, int[] NewData, int[] DataSubIndex){
  int NewDataLength, SubIndexLength, temp, idx;
  int Value;
  
  if(NewData==null){return;} NewDataLength=NewData.length; if(NewDataLength==0){return;}
  if(DataSubIndex==null){return;} SubIndexLength=DataSubIndex.length; if(SubIndexLength==0){return;}
  
  temp=0;
  do{
   idx=DataSubIndex[temp];
   
   if(idx>=0 && idx<NewDataLength){
    Value=NewData[idx];
    Data.addElement(Value);
   } 
   
   temp=temp+1;
  }while(temp!=SubIndexLength);
 }
 public static void concatVect(Vector<Integer> Data, int[] NewData){
  if(NewData==null){return;}
  concatVect(Data, NewData, PCore.newIntegerArrayInOrderedSequence(NewData.length, 0, 1));
 }
 public static void concatVect(Vector<Integer> Data, Integer[] NewData, int[] DataSubIndex){
  int NewDataLength, SubIndexLength, temp, idx;
  Integer Value;
  
  if(NewData==null){return;} NewDataLength=NewData.length; if(NewDataLength==0){return;}
  if(DataSubIndex==null){return;} SubIndexLength=DataSubIndex.length; if(SubIndexLength==0){return;}
  
  temp=0;
  do{
   idx=DataSubIndex[temp];
   
   if(idx>=0 && idx<NewDataLength){
    Value=NewData[idx];
    Data.addElement(Value);
   }
   
   temp=temp+1;
  }while(temp!=SubIndexLength);
 }
 public static void concatVect(Vector<Integer> Data, Integer[] NewData){
  if(NewData==null){return;}
  concatVect(Data, NewData, PCore.newIntegerArrayInOrderedSequence(NewData.length, 0, 1));
 }
 public static void concatVect(Vector<String> Data, String[] NewData, int[] DataSubIndex){
  int NewDataLength, SubIndexLength, temp, idx;
  String Value;
  
  if(NewData==null){return;} NewDataLength=NewData.length; if(NewDataLength==0){return;}
  if(DataSubIndex==null){return;} SubIndexLength=DataSubIndex.length; if(SubIndexLength==0){return;}
  
  temp=0;
  do{
   idx=DataSubIndex[temp];
   
   if(idx>=0 && idx<NewDataLength){
    Value=NewData[idx];
    Data.addElement(Value);
   }
   
   temp=temp+1;
  }while(temp!=SubIndexLength);
 }
 public static void concatVect(Vector<String> Data, String[] NewData){
  if(NewData==null){return;}
  concatVect(Data, NewData, PCore.newIntegerArrayInOrderedSequence(NewData.length, 0, 1));
 }
 public static void concatVect(Vector<Integer> Data, boolean AddNullValue, Vector<Integer>... NewData){
  int vectcount, vecttemp, avectcount, avecttemp;
  Vector<Integer> ANewData;
  Integer Value;
  
  do{
   if(NewData==null){break;}
   vectcount=NewData.length; if(vectcount==0){break;}
   
   vecttemp=0;
   do{
    do{
     ANewData=NewData[vecttemp]; if(ANewData==null){break;}
     avectcount=ANewData.size(); if(avectcount==0){break;}
     
     avecttemp=0;
     do{
      do{
       Value=ANewData.elementAt(avecttemp);
       if(Value==null){
        if(!AddNullValue){break;}
       }
       Data.addElement(Value);
      }while(false);
      
      avecttemp=avecttemp+1;
     }while(avecttemp!=avectcount);
    }while(false);
    
    vecttemp=vecttemp+1;
   }while(vecttemp!=vectcount);
  }while(false);
 }
 
 // add array
 public static int[] concatArr(int[] Data, int[] DataSubIndex, Integer... NewData){
  Vector<Integer> ret=null;
  
  if(Data==null || NewData==null){return primArr_VectInt(ret);}
  
  ret=new Vector();
  concatVect(ret, Data, DataSubIndex);
  concatVect(ret, NewData, newIntegerArrayInOrderedSequence(NewData.length, 0, 1));
  
  return primArr_VectInt(ret);
 }
 
 // sub array
 public static boolean[] subArr(boolean[] Data, int[] SubIndexes){
  boolean[] ret;
  int temp, sublength, datalength;
  
  if(Data==null || SubIndexes==null){return Data;}
  datalength=Data.length;
  sublength=SubIndexes.length;
  if(datalength==0 || sublength>datalength){return Data;}
  
  ret=new boolean[sublength];
  if(sublength!=0){
   temp=0;
   do{
    if(SubIndexes[temp]>=datalength){return Data;}
    ret[temp]=Data[SubIndexes[temp]];
    temp=temp+1;
   }while(temp!=sublength);
  }
  
  return ret;
 }
 public static int[] subArr(int[] Arr, int BeginIndex, int Count){
  int[] ret;
  int length, CopyCount;
  
  if(Arr==null){return null;}
  length=Arr.length;
  if(length==0 || BeginIndex>=length || Count<=0){return null;}
  
  CopyCount=Count;
  if(BeginIndex+CopyCount>length){CopyCount=length-BeginIndex;}
  ret=new int[CopyCount];
  System.arraycopy(Arr, BeginIndex, ret, 0, CopyCount);
  
  return ret;
 }
 public static int[] subArr(int[] Data, int[] SubIndexes){
  int[] ret;
  int temp, sublength, datalength;
  
  if(Data==null || SubIndexes==null){return Data;}
  datalength=Data.length;
  sublength=SubIndexes.length;
  if(datalength==0 || sublength>datalength){return Data;}
  
  ret=new int[sublength];
  if(sublength!=0){
   temp=0;
   do{
    if(SubIndexes[temp]>=datalength){return Data;}
    ret[temp]=Data[SubIndexes[temp]];
    temp=temp+1;
   }while(temp!=sublength);
  }
  
  return ret;
 }
 public static long[] subArr(long[] Arr, int BeginIndex, int Count){
  long[] ret;
  int length, CopyCount;
  
  if(Arr==null){return null;}
  length=Arr.length;
  if(length==0 || BeginIndex>=length || Count<=0){return null;}
  
  CopyCount=Count;
  if(BeginIndex+CopyCount>length){CopyCount=length-BeginIndex;}
  ret=new long[CopyCount];
  System.arraycopy(Arr, BeginIndex, ret, 0, CopyCount);
  
  return ret;
 }
 public static long[] subArr(long[] Data, int[] SubIndexes){
  long[] ret;
  int temp, sublength, datalength;
  
  if(Data==null || SubIndexes==null){return Data;}
  datalength=Data.length;
  sublength=SubIndexes.length;
  if(datalength==0 || sublength>datalength){return Data;}
  
  ret=new long[sublength];
  if(sublength!=0){
   temp=0;
   do{
    if(SubIndexes[temp]>=datalength){return Data;}
    ret[temp]=Data[SubIndexes[temp]];
    temp=temp+1;
   }while(temp!=sublength);
  }
  
  return ret;
 }
 public static Integer[] subArr(Integer[] Arr, int BeginIndex, int Count){
  Integer[] ret;
  int length, CopyCount;
  
  if(Arr==null){return null;}
  length=Arr.length;
  if(length==0 || BeginIndex>=length || Count<=0){return null;}
  
  CopyCount=Count;
  if(BeginIndex+CopyCount>length){CopyCount=length-BeginIndex;}
  ret=new Integer[CopyCount];
  System.arraycopy(Arr, BeginIndex, ret, 0, CopyCount);
  
  return ret;
 }
 public static Long[] subArr(Long[] Arr, int BeginIndex, int Count){
  Long[] ret;
  int length, CopyCount;
  
  if(Arr==null){return null;}
  length=Arr.length;
  if(length==0 || BeginIndex>=length || Count<=0){return null;}
  
  CopyCount=Count;
  if(BeginIndex+CopyCount>length){CopyCount=length-BeginIndex;}
  ret=new Long[CopyCount];
  System.arraycopy(Arr, BeginIndex, ret, 0, CopyCount);
  
  return ret;
 }
 
 // sub vector
 public static Vector<Boolean> subVect(Vector<Boolean> Vect, int[] SubIndexes){
  Vector<Boolean> ret=null;
  
  int temp, sublength, datalength;
  
  if(Vect==null || SubIndexes==null){return Vect;}
  datalength=Vect.size();
  sublength=SubIndexes.length;
  if(datalength==0 || sublength>datalength){return Vect;}
  
  ret=new Vector();
  if(sublength!=0){
   temp=0;
   do{
    if(SubIndexes[temp]>=datalength){return Vect;}
    ret.addElement(Vect.elementAt(SubIndexes[temp]));
    temp=temp+1;
   }while(temp!=sublength);
  }
  
  return ret;
 }
 
 // check array empty
 public static boolean isArrayEmpty(boolean[] Arr, boolean CheckLength){
  boolean ret=Arr==null; if(!ret && CheckLength){ret=Arr.length==0;} return ret;
 }
 public static boolean isArrayEmpty(int[] Arr, boolean CheckLength){
  boolean ret=Arr==null; if(!ret && CheckLength){ret=Arr.length==0;} return ret;
 }
 public static boolean isArrayEmpty(long[] Arr, boolean CheckLength){
  boolean ret=Arr==null; if(!ret && CheckLength){ret=Arr.length==0;} return ret;
 }
 public static boolean isArrayEmpty(String[] Arr, boolean CheckLength){
  boolean ret=Arr==null; if(!ret && CheckLength){ret=Arr.length==0;} return ret;
 }
 
 public static boolean isVectorEmpty(Vector<?> Vect, boolean CheckLength){
  boolean ret=Vect==null; if(!ret && CheckLength){ret=Vect.size()==0;} return ret;
 }
 
 public static boolean isObjectsEmpty(Object[] Objs, boolean CheckLength){
  boolean ret=Objs==null; if(!ret && CheckLength){ret=Objs.length==0;} return ret;
 }
 
 // subtitute
 public static Object subtituteObj(Object Data, Object ReturnIfNotNull, Object ReturnIfNull){
  if(Data==null){return ReturnIfNull;}
  return ReturnIfNotNull;
 }
 public static Object subtituteBool(boolean Value, Object ReturnIfTrue, Object ReturnIfFalse){
  if(Value){return ReturnIfTrue;}
  return ReturnIfFalse;
 }
	public static Object subtituteLong(long Number, long NegativeThreshold, Object ReturnIfPositive, Object ReturnIfNegative){
  if(Number<=NegativeThreshold){return ReturnIfNegative;}
  return ReturnIfPositive;
 }
	public static Object subtituteDouble(double Number, double NegativeThreshold, Object ReturnIfPositive, Object ReturnIfNegative){
  if(Number<=NegativeThreshold){return ReturnIfNegative;}
  return ReturnIfPositive;
 }
	public static Integer subtBool_Int(boolean Value, Integer ReturnTrue, Integer ReturnFalse){
		if(Value){return ReturnTrue;}else{return ReturnFalse;}
	}
	public static Long subtBool_Long(boolean Value, Long ReturnTrue, Long ReturnFalse){
		if(Value){return ReturnTrue;}else{return ReturnFalse;}
	}
	public static Double subtBool_Double(boolean Value, Double ReturnTrue, Double ReturnFalse){
		if(Value){return ReturnTrue;}else{return ReturnFalse;}
	}
 public static int retrieveInt(int Number, int[] CheckIf, int[] CheckReturn, int ReturnIfCheckNotFound){
  int ret=ReturnIfCheckNotFound;
  int temp, CheckCount;
  
  if(CheckIf==null){return ret;}
  CheckCount=CheckIf.length;
  if(CheckCount==0){return ret;}
  
  temp=0;
  do{
   if(Number==CheckIf[temp]){break;}
   temp=temp+1;
  }while(temp!=CheckCount);
  if(temp!=CheckCount){ret=CheckReturn[temp];}
  
  return ret;
 }
 public static int[] changeValue(int[] Data, int[] ChangeIndex, int[] ChangeValue){
  int[] ret=Data;
  int datalength, changelength, temp, idx;
  
  if(ret==null || ChangeIndex==null){return ret;}
  datalength=ret.length; changelength=ChangeIndex.length;
  if(datalength==0 || changelength==0){return ret;}
  
  temp=0;
  do{
   idx=ChangeIndex[temp];
   if(idx>=0 && idx<datalength){
    Data[idx]=ChangeValue[temp];
   }
   
   temp=temp+1;
  }while(temp!=changelength);
  
  return ret;
 }
 public static boolean[] changeValue(boolean[] Data, int[] ChangeIndex, boolean[] ChangeValue){
  boolean[] ret=Data;
  int datalength, changelength, temp, idx;
  
  if(ret==null || ChangeIndex==null){return ret;}
  datalength=ret.length; changelength=ChangeIndex.length;
  if(datalength==0 || changelength==0){return ret;}
  
  temp=0;
  do{
   idx=ChangeIndex[temp];
   if(idx>=0 && idx<datalength){
    Data[idx]=ChangeValue[temp];
   }
   
   temp=temp+1;
  }while(temp!=changelength);
  
  return ret;
 }
	
 // Object -> Ref
 public static Date objDate(Object Data, Date ReturnIfNull){if(Data==null){return ReturnIfNull;}else{return (Date)Data;}}
	public static String objString(Object Data, String ReturnIfNull){if(Data==null){return ReturnIfNull;}else{return (String)Data;}}
	public static Integer objInteger(Object Data, Integer ReturnIfNull){if(Data==null){return ReturnIfNull;}else{return (Integer)Data;}}
	public static Long objLong(Object Data, Long ReturnIfNull){if(Data==null){return ReturnIfNull;}else{return (Long)Data;}}
	public static Double objDouble(Object Data, Double ReturnIfNull){if(Data==null){return ReturnIfNull;}else{return (Double)Data;}}
	public static Boolean objBoolean(Object Data, Boolean ReturnIfNull){if(Data==null){return ReturnIfNull;}else{return (Boolean)Data;}}
 public static Integer objNumberInteger(int DataType, Object Data, Integer ReturnIfNull){
  Integer ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  switch(DataType){
   case CCore.TypeInteger : ret=(Integer)Data; break;
   case CCore.TypeLong    : ret=((Long)Data).intValue(); break;
   case CCore.TypeDouble  : ret=((Double)Data).intValue(); break;
  }
  
  return ret;
 }
 public static Long objNumberLong(int DataType, Object Data, Long ReturnIfNull){
  Long ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  switch(DataType){
   case CCore.TypeInteger : ret=((Integer)Data).longValue(); break;
   case CCore.TypeLong    : ret=(Long)Data; break;
   case CCore.TypeDouble  : ret=((Double)Data).longValue(); break;
  }
  
  return ret;
 }
 public static Double objNumberDouble(int DataType, Object Data, Double ReturnIfNull){
  Double ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  switch(DataType){
   case CCore.TypeInteger : ret=((Integer)Data).doubleValue(); break;
   case CCore.TypeLong    : ret=((Long)Data).doubleValue(); break;
   case CCore.TypeDouble  : ret=(Double)Data; break;
  }
  
  return ret;
 }
 
 public static long getValueIntLong(Object Data, boolean IsInteger, long ReturnIfNull){
  long ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  if(IsInteger){ret=(Integer)Data;}
  else{ret=(Long)Data;}
  
  return ret;
 }
 public static double getValueIntDouble(Object Data, boolean IsInteger, double ReturnIfNull){
  double ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  if(IsInteger){ret=(Integer)Data;}
  else{ret=(Double)Data;}
  
  return ret;
 }
 public static double getValueLongDouble(Object Data, boolean IsLong, double ReturnIfNull){
  double ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  if(IsLong){ret=(Long)Data;}
  else{ret=(Double)Data;}
  
  return ret;
 }
 public static double getValueDouble(Object Data, double ReturnIfNull){
  double ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  do{
   if(Data instanceof Integer){ret=(Integer)Data; break;}
   if(Data instanceof Long){ret=(Long)Data; break;}
   if(Data instanceof Float){ret=(Float)Data; break;}
   if(Data instanceof Double){ret=(Double)Data; break;}
  }while(false);
  
  return ret;
 }
 public static long getValueLong(Object Data, long ReturnIfNull){
  long ret=ReturnIfNull;
  
  if(Data==null){return ret;}
  
  do{
   if(Data instanceof Integer){ret=(Integer)Data; break;}
   if(Data instanceof Long){ret=(Long)Data; break;}
   if(Data instanceof Float){ret=((Float)Data).longValue(); break;}
   if(Data instanceof Double){ret=((Double)Data).longValue(); break;}
  }while(false);
  
  return ret;
 }
 
 // others
 public static Object replaceNullAs(Object Source, Object ReturnValueIfSourceIsNull){
  Object ret=Source;
  if(Source==null){ret=ReturnValueIfSourceIsNull;}
  return ret;
 }
 
 public static boolean isEmptyString(Object Obj, boolean CheckWhiteSpace, boolean ReturnIfNull){
  String Str=null; if(Obj!=null){Str=Obj.toString();}
  return PText.isEmptyString(Str, CheckWhiteSpace, ReturnIfNull);
 }
 
 public static Object[] toSingleRow(Object SingleData){
  Object[] ret=new Object[1];
  ret[0]=SingleData;
  return ret;
 }
 public static Vector<Object[]> toMultiRows(Object... Data){
  Vector<Object[]> ret=null;
  int temp, temp2;
  if(Data==null){return ret;}
  temp=Data.length;
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(toSingleRow(Data[temp2]));
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static Vector<Object[]> toMultiRows2(Object... Data){
  Vector<Object[]> ret=new Vector(1);
  ret.addElement(Data);
  return ret;
 }
 public static Vector<Object[]> toMultiRows(Vector<?> Data){
  Vector<Object[]> ret=null;
  int temp, temp2;
  if(Data==null){return ret;}
  temp=Data.size();
  ret=new Vector(temp);
  if(temp==0){return ret;}
  temp2=0;
  do{
   ret.addElement(toSingleRow(Data.elementAt(temp2)));
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 
 public static boolean compareValue(int[] Var1, int[] Var2){
  boolean ret=true;
  int temp, temp2;
  
  if(Var1==null || Var2==null){return false;}
  
  temp=Var1.length;
  if(temp!=Var2.length){return false;}
  if(temp==0){return true;}
  
  temp2=0;
  do{
   if(Var1[temp2]!=Var2[temp2]){ret=false; break;}
   temp2=temp2+1;
  }while(temp2!=temp);
  
  return ret;
 }
 public static boolean compareValue(long[] Var1, long[] Var2){
  boolean ret=true;
  int temp, temp2;
  
  if(Var1==null || Var2==null){return false;}
  
  temp=Var1.length;
  if(temp!=Var2.length){return false;}
  if(temp==0){return true;}
  
  temp2=0;
  do{
   if(Var1[temp2]!=Var2[temp2]){ret=false; break;}
   temp2=temp2+1;
  }while(temp2!=temp);
  
  return ret;
 }
 
 public static boolean[] invertValue(boolean[] Data){
  boolean[] ret;
  int count, temp;
  
  if(Data==null){return null;}
  
  count=Data.length;
  ret=new boolean[count];
  if(count!=0){
   temp=0;
   do{
    ret[temp]=!Data[temp];
    temp=temp+1;
   }while(temp!=count);
  }
  
  return ret;
 }
 
 public static void fillValue(Object[] Data, Object Value){
  int count, temp;
  
  count=0; if(Data!=null){count=Data.length;}
  if(count==0){return;}
  
  temp=0;
  do{
   Data[temp]=Value;
   
   temp=temp+1;
  }while(temp!=count);
 }
 
 public static Object[] clone(Object[] Data){
  Object[] ret;
  int colcount, coltemp;
  
  ret=null;
  if(Data==null){return ret;}

  colcount=Data.length;
  ret=new Object[colcount];
  if(colcount==0){return ret;}

  coltemp=0;
  do{
   ret[coltemp]=Data[coltemp];

   coltemp=coltemp+1;
  }while(coltemp!=colcount);
  
  return ret;
 }
 public static Vector<Object[]> clone(Vector<Object[]> Data){
  Vector<Object[]> ret;
  int rowcount, rowtemp;
  
  ret=null;
  if(Data==null){return ret;}
  
  ret=new Vector();
  rowcount=Data.size(); if(rowcount==0){return ret;}

  rowtemp=0;
  do{
   ret.addElement(clone(Data.elementAt(rowtemp)));
   
   rowtemp=rowtemp+1;
  }while(rowtemp!=rowcount);
  
  return ret;
 }
 
 public static Integer gradingObjectByNull(Integer ReturnIfBothValueIsNotNull, Object Value1, Object Value2){
  Integer ret=ReturnIfBothValueIsNotNull;
  
  do{
   if(Value1==null && Value2==null){ret=0; break;}
   if(Value1!=null && Value2==null){ret=1; break;}
   if(Value1==null && Value2!=null){ret=2; break;}
  }while(false);
  
  return ret;
 }
 public static Integer gradingBoolean(Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  Object V_1, V_2;
  Integer GradingByNull;
  boolean v1, v2;
  
  do{
   if(!Value1_AcceptIfNull && Value1==null){break;}
   if(!Value2_AcceptIfNull && Value2==null){break;}
   
   V_1=subtituteObj(Value1, Value1, Value1_IfNull);
   V_2=subtituteObj(Value2, Value2, Value2_IfNull);
   
   GradingByNull=gradingObjectByNull(null, V_1, V_2); if(GradingByNull!=null){ret=GradingByNull; break;}
   
   ret=0;
   v1=objBoolean(V_1, false);
   v2=objBoolean(V_2, false);
   if(v1!=v2){
    if(v1==true){ret=1;}else{ret=2;}
   }
  }while(false);
  
  return ret;
 }
 public static Integer gradingInteger(Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  Object V_1, V_2;
  Integer GradingByNull;
  int v1, v2;
  
  do{
   if(!Value1_AcceptIfNull && Value1==null){break;}
   if(!Value2_AcceptIfNull && Value2==null){break;}
   
   V_1=subtituteObj(Value1, Value1, Value1_IfNull);
   V_2=subtituteObj(Value2, Value2, Value2_IfNull);
   
   GradingByNull=gradingObjectByNull(null, V_1, V_2); if(GradingByNull!=null){ret=GradingByNull; break;}
   
   ret=0;
   v1=objInteger(V_1, -1);
   v2=objInteger(V_2, -1);
   if(v1!=v2){
    if(v1>v2){ret=1;}else{ret=2;}
   }
  }while(false);
  
  return ret;
 }
 public static Integer gradingLong(Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  Object V_1, V_2;
  Integer GradingByNull;
  long v1, v2;
  
  do{
   if(!Value1_AcceptIfNull && Value1==null){break;}
   if(!Value2_AcceptIfNull && Value2==null){break;}
   
   V_1=subtituteObj(Value1, Value1, Value1_IfNull);
   V_2=subtituteObj(Value2, Value2, Value2_IfNull);
   
   GradingByNull=gradingObjectByNull(null, V_1, V_2); if(GradingByNull!=null){ret=GradingByNull; break;}
   
   ret=0;
   v1=objLong(V_1, -1L);
   v2=objLong(V_2, -1L);
   if(v1!=v2){
    if(v1>v2){ret=1;}else{ret=2;}
   }
  }while(false);
  
  return ret;
 }
 public static Integer gradingDouble(Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  Object V_1, V_2;
  Integer GradingByNull;
  double v1, v2;
  
  do{
   if(!Value1_AcceptIfNull && Value1==null){break;}
   if(!Value2_AcceptIfNull && Value2==null){break;}
   
   V_1=subtituteObj(Value1, Value1, Value1_IfNull);
   V_2=subtituteObj(Value2, Value2, Value2_IfNull);
   
   GradingByNull=gradingObjectByNull(null, V_1, V_2); if(GradingByNull!=null){ret=GradingByNull; break;}
   
   ret=0;
   v1=objDouble(V_1, -1D);
   v2=objDouble(V_2, -1D);
   if(v1!=v2){
    if(v1>v2){ret=1;}else{ret=2;}
   }
  }while(false);
  
  return ret;
 }
 public static Integer gradingString(Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  Object V_1, V_2;
  Integer GradingByNull;
  String v1, v2;
  
  do{
   if(!Value1_AcceptIfNull && Value1==null){break;}
   if(!Value2_AcceptIfNull && Value2==null){break;}
   
   V_1=subtituteObj(Value1, Value1, Value1_IfNull);
   V_2=subtituteObj(Value2, Value2, Value2_IfNull);
   
   GradingByNull=gradingObjectByNull(null, V_1, V_2); if(GradingByNull!=null){ret=GradingByNull; break;}
   
   ret=0;
   v1=objString(V_1, null);
   v2=objString(V_2, null);
   ret=PText.grading(v1, v2, false);
  }while(false);
  
  return ret;
 }
 public static Integer gradingDate(Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  Object V_1, V_2;
  Integer GradingByNull;
  Date v1, v2;
  
  do{
   if(!Value1_AcceptIfNull && Value1==null){break;}
   if(!Value2_AcceptIfNull && Value2==null){break;}
   
   V_1=subtituteObj(Value1, Value1, Value1_IfNull);
   V_2=subtituteObj(Value2, Value2, Value2_IfNull);
   
   GradingByNull=gradingObjectByNull(null, V_1, V_2); if(GradingByNull!=null){ret=GradingByNull; break;}
   
   ret=0;
   v1=objDate(V_1, null);
   v2=objDate(V_2, null);
   ret=PDate.grading(v1, v2, Long.MIN_VALUE);
  }while(false);
  
  return ret;
 }
 public static Integer grading(int ValueType, Integer ReturnIfError,
  Object Value1, boolean Value1_AcceptIfNull, Object Value1_IfNull,
  Object Value2, boolean Value2_AcceptIfNull, Object Value2_IfNull){
  Integer ret=ReturnIfError;
  
  switch(ValueType){
   case CCore.TypeBoolean : ret=gradingBoolean(ReturnIfError, Value1, Value1_AcceptIfNull, Value1_IfNull, Value2, Value2_AcceptIfNull, Value2_IfNull); break;
   case CCore.TypeInteger : ret=gradingInteger(ReturnIfError, Value1, Value1_AcceptIfNull, Value1_IfNull, Value2, Value2_AcceptIfNull, Value2_IfNull); break;
   case CCore.TypeLong : ret=gradingLong(ReturnIfError, Value1, Value1_AcceptIfNull, Value1_IfNull, Value2, Value2_AcceptIfNull, Value2_IfNull); break;
   case CCore.TypeDouble : ret=gradingDouble(ReturnIfError, Value1, Value1_AcceptIfNull, Value1_IfNull, Value2, Value2_AcceptIfNull, Value2_IfNull); break;
   case CCore.TypeString : ret=gradingString(ReturnIfError, Value1, Value1_AcceptIfNull, Value1_IfNull, Value2, Value2_AcceptIfNull, Value2_IfNull); break;
   case CCore.TypeDate : ret=gradingDate(ReturnIfError, Value1, Value1_AcceptIfNull, Value1_IfNull, Value2, Value2_AcceptIfNull, Value2_IfNull); break;
  }
  
  return ret;
 }
 
 public static int find(int DataType, Object[] Data, Object Value){
  int ret=-1;
  int temp, count;
  
  count=0; if(Data!=null){count=Data.length;}
  if(count==0){return ret;}
  
  temp=0;
  do{
   if(grading(DataType, -1, Data[temp], true, null, Value, true, null)==0){ret=temp; break;}
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 
 public static String[] concat(boolean IncludeNullValue, String[]... MultiValues){
  Vector<String> ret=new Vector();
  int length, temp, valuelength, valuetemp;
  String[] Value;
  
  if(MultiValues==null){return refArr_VectStr(ret);}
  
  length=MultiValues.length;
  if(length==0){return refArr_VectStr(ret);}
  
  temp=0;
  do{
   Value=MultiValues[temp];
   
   do{
    if(Value==null){break;}
    valuelength=Value.length;
    if(valuelength==0){break;}
    valuetemp=0;
    do{
     if(IncludeNullValue || Value[valuetemp]!=null){
      ret.addElement(Value[valuetemp]);
     }
     
     valuetemp=valuetemp+1;
    }while(valuetemp!=valuelength);
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return refArr_VectStr(ret);
 }
 public static Vector<Object[]> concat(Vector<Object[]>... MultiValues){
  Vector<Object[]> ret=new Vector();
  int length, temp, valuelength, valuetemp;
  Vector<Object[]> Value;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   Value=MultiValues[temp];
   
   do{
    if(Value==null){break;}
    valuelength=Value.size();
    if(valuelength==0){break;}
    valuetemp=0;
    do{
     ret.addElement(Value.elementAt(valuetemp));
     valuetemp=valuetemp+1;
    }while(valuetemp!=valuelength);
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static void copyArray(Object[] Source, int Source_CopyOffset, int Source_CopyLength, Object[] Dest, int Dest_PasteOffset){
  int copylength, temp, add, a, b,
   source_length, source_start, source_end,
   dest_length, dest_start, dest_end;
  
  // initialize variables
  copylength=Source_CopyLength;
  
  source_length=0; if(Source!=null){source_length=Source.length;}
  source_start=Source_CopyOffset;
  source_end=source_start+copylength-1;
  
  dest_length=0; if(Dest!=null){dest_length=Dest.length;}
  dest_start=Dest_PasteOffset;
  dest_end=dest_start+copylength-1;
  
  if(
   copylength<=0 ||
   source_length==0 || source_start>source_length-1 || source_end<0 || 
   dest_length==0 || dest_start>dest_length-1 || dest_end<0){
   return;
  }
  
  // set start
  if(source_start<0 || dest_start<0){
   a=0; if(source_start<0){a=0-source_start;}
   b=0; if(dest_start<0){b=0-dest_start;}
   add=PMath.getMinMaxInt(a, b, false);
   
   source_start=source_start+add;
   dest_start=dest_start+add;
   copylength=copylength-add;
   
   if(source_start>source_length-1 || dest_start>dest_length-1){return;}
  }
  
  // set end
  if(source_end>source_length-1 || dest_end>dest_length-1){
   a=0; if(source_end>source_length-1){a=source_end-(source_length-1);}
   b=0; if(dest_end>dest_length-1){b=dest_end-(dest_length-1);}
   add=PMath.getMinMaxInt(a, b, false);
   
   source_end=source_end-add;
   dest_end=dest_end-add;
   copylength=copylength-add;
   
   if(source_end<0 || dest_end<0){return;}
  }
  
  // copying
  if(copylength<=0){return;}
  
  temp=0;
  do{
   Dest[dest_start+temp]=Source[source_start+temp];
   temp=temp+1;
  }while(temp!=copylength);
 }
 
 public static int[] insert(int[] Data, int InsertIndex, Integer... InsertValue){
  Vector<Integer> ret=null;
  Integer Value;
  int DataLength, InsertLength, temp;
  
  DataLength=0; if(Data!=null){DataLength=Data.length;}
  InsertLength=0; if(InsertValue!=null){InsertLength=InsertValue.length;}
  
  if((InsertIndex<0 || InsertIndex>DataLength) || InsertLength==0 || Data==null){return Data;}
  
  ret=new Vector();
  
  // add Data to before insert index
  if(Data!=null && InsertIndex!=0){
   temp=0;
   do{
    ret.addElement(Data[temp]);
    temp=temp+1;
   }while(temp!=InsertIndex);
  }
  
  // add InsertValue at insert index
  temp=0;
  do{
   Value=InsertValue[temp];
   if(Value!=null){ret.addElement(Value);}
   temp=temp+1;
  }while(temp!=InsertLength);
  
  // add Data to after insert index
  if(Data!=null && InsertIndex!=DataLength){
   temp=InsertIndex;
   do{
    ret.addElement(Data[temp]);
    temp=temp+1;
   }while(temp!=DataLength);
  }
  
  return primArr_VectInt(ret);
 }
 
 public static int findAValueInArray(int[] Values, int Value, int NotFoundReturnValue){
  int ret=NotFoundReturnValue; // NotFoundReturnValue - not found, >=0 - found index
  int temp, temp2;
  if(Values==null){return ret;}
  temp=Values.length;
  if(temp==0){return ret;}
  temp2=0;
  do{
   if(Values[temp2]==Value){ret=temp2; break;}
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static int findAValueInArray(long[] Values, long Value, int NotFoundReturnValue){
  int ret=NotFoundReturnValue; // NotFoundReturnValue - not found, >=0 - found index
  int temp, temp2;
  if(Values==null){return ret;}
  temp=Values.length;
  if(temp==0){return ret;}
  temp2=0;
  do{
   if(Values[temp2]==Value){ret=temp2; break;}
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static int findAValueInArray(double[] Values, double Value, int NotFoundReturnValue){
  int ret=NotFoundReturnValue; // NotFoundReturnValue - not found, >=0 - found index
  int temp, temp2;
  if(Values==null){return ret;}
  temp=Values.length;
  if(temp==0){return ret;}
  temp2=0;
  do{
   if(Values[temp2]==Value){ret=temp2; break;}
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static int findAValueInArray(Component[] Values, Component Value, int NotFoundReturnValue){
  int ret=NotFoundReturnValue; // NotFoundReturnValue - not found, >=0 - found index
  int temp, temp2;
  if(Values==null){return ret;}
  temp=Values.length;
  if(temp==0){return ret;}
  temp2=0;
  do{
   if(Values[temp2]==Value){ret=temp2; break;}
   temp2=temp2+1;
  }while(temp2!=temp);
  return ret;
 }
 public static int findString_VectArrStr(Vector<String[]> Data, int Column, String Word){
  int ret=-1;
  int temp, length;
  length=Data.size();
  if(length!=0){
   temp=0;
   do{
    if(PText.compare(Data.elementAt(temp)[Column], Word, false)){
     ret=temp;
     break;
    }
    temp=temp+1;
   }while(temp!=length);
  }
  return ret;
 }
 
 public static boolean checkBool(boolean UseLogicAnd, boolean ReturnEmpty, Boolean... MultiValues){
  boolean ret=ReturnEmpty;
  int temp, length;
  boolean LogicCounter;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  ret=(Boolean)subtituteBool(UseLogicAnd, true, false);
  LogicCounter=(Boolean)subtituteBool(UseLogicAnd, false, true);
  
  temp=0;
  do{
   if(MultiValues[temp]==LogicCounter){ret=!ret; break;}
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static Integer getMinMax_Integer(boolean IsMinimal, Integer[] MultiValues){
  Integer ret=null;
  Integer value;
  int temp, length;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   
   do{
    value=MultiValues[temp];
    
    // keep 'ret' value if ...
    if(value==null){break;}
    if(ret!=null){
     if(IsMinimal){
      if(value.intValue()>=ret.intValue()){break;}
     }
     else{
      if(value.intValue()<=ret.intValue()){break;}
     }
    }
    
    // change 'ret' value
    ret=value;
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static Long getMinMax_Long(boolean IsMinimal, Long[] MultiValues){
  Long ret=null;
  Long value;
  int temp, length;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   
   do{
    value=MultiValues[temp];
    
    // keep 'ret' value if ...
    if(value==null){break;}
    if(ret!=null){
     if(IsMinimal){
      if(value.longValue()>=ret.longValue()){break;}
     }
     else{
      if(value.longValue()<=ret.longValue()){break;}
     }
    }
    
    // change 'ret' value
    ret=value;
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static Double getMinMax_Double(boolean IsMinimal, Double[] MultiValues){
  Double ret=null;
  Double value;
  int temp, length;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   
   do{
    value=MultiValues[temp];
    
    // keep 'ret' value if ...
    if(value==null){break;}
    if(ret!=null){
     if(IsMinimal){
      if(value.doubleValue()>=ret.doubleValue()){break;}
     }
     else{
      if(value.doubleValue()<=ret.doubleValue()){break;}
     }
    }
    
    // change 'ret' value
    ret=value;
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static Integer getMinMax_Integer(boolean IsMinimal, int[] MultiValues){
  Integer ret=null;
  int value;
  int temp, length;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   
   do{
    value=MultiValues[temp];
    
    // keep 'ret' value if ...
    if(ret!=null){
     if(IsMinimal){
      if(value>=ret.intValue()){break;}
     }
     else{
      if(value<=ret.intValue()){break;}
     }
    }
    
    // change 'ret' value
    ret=value;
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static Long getMinMax_Long(boolean IsMinimal, long[] MultiValues){
  Long ret=null;
  long value;
  int temp, length;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   
   do{
    value=MultiValues[temp];
    
    // keep 'ret' value if ...
    if(ret!=null){
     if(IsMinimal){
      if(value>=ret.longValue()){break;}
     }
     else{
      if(value<=ret.longValue()){break;}
     }
    }
    
    // change 'ret' value
    ret=value;
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static Double getMinMax_Double(boolean IsMinimal, double[] MultiValues){
  Double ret=null;
  double value;
  int temp, length;
  
  if(MultiValues==null){return ret;}
  
  length=MultiValues.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   
   do{
    value=MultiValues[temp];
    
    // keep 'ret' value if ...
    if(ret!=null){
     if(IsMinimal){
      if(value>=ret.doubleValue()){break;}
     }
     else{
      if(value<=ret.doubleValue()){break;}
     }
    }
    
    // change 'ret' value
    ret=value;
   }while(false);
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static boolean betweenRangeInt(int Value, int MinValue, int MaxValue){return Value>=MinValue && Value<=MaxValue;}
 public static boolean betweenRangeLong(long Value, long MinValue, long MaxValue){return Value>=MinValue && Value<=MaxValue;}
 public static boolean betweenRangeDouble(double Value, double MinValue, double MaxValue){return Value>=MinValue && Value<=MaxValue;}
 public static boolean betweenRange(int[] Values, int MinValue, int MaxValue, boolean ReturnIfNull, boolean ReturnIfEmpty){
  boolean ret=true;
  int temp, length;
  
  if(Values==null){return ReturnIfNull;}
  length=Values.length;
  if(length==0){return ReturnIfEmpty;}
  
  temp=0;
  do{
   if(!betweenRangeInt(Values[temp], MinValue, MaxValue)){ret=false; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static boolean betweenRange(long[] Values, long MinValue, long MaxValue, boolean ReturnIfNull, boolean ReturnIfEmpty){
  boolean ret=true;
  int temp, length;
  
  if(Values==null){return ReturnIfNull;}
  length=Values.length;
  if(length==0){return ReturnIfEmpty;}
  
  temp=0;
  do{
   if(!betweenRangeLong(Values[temp], MinValue, MaxValue)){ret=false; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static boolean betweenRange(double[] Values, double MinValue, double MaxValue, boolean ReturnIfNull, boolean ReturnIfEmpty){
  boolean ret=true;
  int temp, length;
  
  if(Values==null){return ReturnIfNull;}
  length=Values.length;
  if(length==0){return ReturnIfEmpty;}
  
  temp=0;
  do{
   if(!betweenRangeDouble(Values[temp], MinValue, MaxValue)){ret=false; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 /* sort algorithm (bubble sort)
    3, 1, 6, 2, 5, 8, 9, 0, 4
    <- *

    1, 3, 6, 2, 5, 8, 9, 0, 4
       <-    *

    1, 2, 3, 6, 5, 8, 9, 0, 4
             <- *

    1, 2, 3, 5, 6, 8, 9, 0, 4
    <-                   *

    0, 1, 2, 3, 5, 6, 8, 9, 4
                <-          *

    0, 1, 2, 3, 4, 5, 6, 8, 9
 */
 public static void sort(long[] Data, int Length){
  int temp, temp2, count;
  long dt;
  count=Length;
  if(count>1){
   temp=1;
   do{
    dt=Data[temp];
    temp2=temp-1;
    if(Data[temp2]>dt){
     if(temp2!=0){
      do{
       if(Data[temp2-1]<=dt){break;}
       temp2=temp2-1;
      }while(temp2!=0);
     }
     System.arraycopy(Data, temp2, Data, temp2+1, temp-temp2);
     Data[temp2]=dt;
    }
    temp=temp+1;
   }while(temp!=count);
  }
 }
 public static void sort(int[] Data, int Length){
  int temp, temp2, count;
  int dt;
  count=Length;
  if(count>1){
   temp=1;
   do{
    dt=Data[temp];
    temp2=temp-1;
    if(Data[temp2]>dt){
     if(temp2!=0){
      do{
       if(Data[temp2-1]<=dt){break;}
       temp2=temp2-1;
      }while(temp2!=0);
     }
     System.arraycopy(Data, temp2, Data, temp2+1, temp-temp2);
     Data[temp2]=dt;
    }
    temp=temp+1;
   }while(temp!=count);
  }
 }
 
 public static int getRandomIndex(int IndexCount){
  // return random index in range (1 ... IndexCount)
  int ret=-1;
  int DynamicValue;
  long v1, v2, v3, v4;
  
  if(IndexCount<=0){return ret;}
  
  v1=System.currentTimeMillis();
  v2=new Object().hashCode();
  v3=(Cal.get(Calendar.MONTH)+1)*Cal.get(Calendar.DAY_OF_WEEK);
  v4=new Object().hashCode()%IndexCount*3;
  if(v1<0){v1=-1*v1;} if(v2<0){v2=-1*v2;} if(v3<0){v3=-1*v3;} if(v4<0){v4=-1*v4;}
  
  DynamicValue=(int)(v1-v2-v3-v4);
  if(DynamicValue<0){DynamicValue=-1*DynamicValue;}
  
  ret=DynamicValue%IndexCount;
  
  return ret;
 }
 public static String getBinaryString(byte[] Bytes, String Separator){
  StringBuilder ret=null;
  int temp, length;
  
  if(Bytes==null){return null;}
  
  ret=new StringBuilder();
  length=Bytes.length;
  if(length!=0){
   temp=0;
   do{
    if(temp!=0){ret.append(Separator);}
    ret.append(Bytes[temp]);
    temp=temp+1;
   }while(temp!=length);
  }
  
  return ret.toString();
 }
 
 
 
}