import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class F_ItemModify extends XFormDialog{
 
 // set
 int wMode; // 0 NewMode, 1 EditMode, 2 ViewOnlyMode
 long wId;
 OInfoItem wInfoItem;
 
 // get
 long Id;
 String Name;
 boolean IsActive;
 String Comment;
 int StockUnitId;
 String StockUnitName;
 double Stock;
 boolean UpdateStock;
 double MinStock;
 double MaxStock;
 boolean IsOpname;
 boolean IsReorder;
 double OrderMinPack;
 double OrderEachPackQty;
 double OrderEachPackThreshold;
 boolean HasExpireDate;
 int ExpireCheckPeriod;
 int ExpireThreshold;
 double SellPrice;
 String SellPriceComment;
 Date SellUpdate;
 double BuyPriceEst;
 String BuyPriceComment;
 Date BuyUpdate;
 Double OpStock;
 Date OpExpire;
 double OrderQty;
 
 public F_ItemModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  enableInputInDateComponents(CB_SellUpdateOn.isSelected(), TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay);
  enableInputInDateComponents(CB_BuyUpdateOn.isSelected(), TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay);
  enableInputInDateComponents(CB_OpExpireOn.isSelected(), TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay);
  
  clearComponents();
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Generate, Btn_CheckAvailable, TF_Id,
    TF_Name,
    CB_Active,
    TA_Comment,
    Btn_ChooseStockUnit, Btn_ClearStockUnit,
    CB_AutoUpdateStock,
    TF_Stock,
    TF_MinStock,
    TF_MaxStock,
    CB_IsOpname,
    CB_IsReorder,
    TF_OrderEachPackQty,
    TF_OrderEachPackThreshold,
    TF_OrderMinPack,
    
    CB_Exp,
    TF_ExpireCheckPeriod,
    TF_ExpireThreshold,
    TF_Sell,
    CB_SellUpdateOn, TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay, Btn_SellUpdateSetToday,
    TA_SellComment,
    TF_BuyPriceEst,
    CB_BuyUpdateOn, TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay, Btn_BuyUpdateSetToday,
    TA_BuyComment,
    TF_OpStock,
    CB_OpExpireOn, TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay,
    TF_OrderQty,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     if(Btn_Ok.isVisible()){Btn_OkActionPerformed(null);}
    }
   });
 }

 
 void clearComponents(){
  Lbl_Id.setForeground(CGUI.Color_Label_InputPrimary); TF_Id.setText("");
  Lbl_Name.setForeground(CGUI.Color_Label_InputPrimary); TF_Name.setText("");
  Lbl_Active.setForeground(CGUI.Color_Label_InputPrimary); CB_Active.setSelected(true);
  Lbl_Comment.setForeground(CGUI.Color_Label_InputSecondary); TA_Comment.setText("");
  
  Lbl_StockUnit.setForeground(CGUI.Color_Label_InputPrimary); TF_StockUnit.setText("");
  Lbl_Stock.setForeground(CGUI.Color_Label_InputPrimary); TF_Stock.setText("0");
  Lbl_AutoUpdateStock.setForeground(CGUI.Color_Label_InputPrimary); CB_AutoUpdateStock.setSelected(true);
  Lbl_MinStock.setForeground(CGUI.Color_Label_InputPrimary); TF_MinStock.setText("0");
  Lbl_MaxStock.setForeground(CGUI.Color_Label_InputPrimary); TF_MaxStock.setText("0");
  
  Lbl_IsOpname.setForeground(CGUI.Color_Label_InputPrimary); CB_IsOpname.setSelected(true);
  Lbl_IsReorder.setForeground(CGUI.Color_Label_InputPrimary); CB_IsReorder.setSelected(true);
  Lbl_OrderMinPack.setForeground(CGUI.Color_Label_InputSecondary); TF_OrderMinPack.setText("1");
  Lbl_OrderEachPackQty.setForeground(CGUI.Color_Label_InputPrimary); TF_OrderEachPackQty.setText("1");
  Lbl_OrderEachPackThreshold.setForeground(CGUI.Color_Label_InputSecondary); TF_OrderEachPackThreshold.setText(PText.doubleToString(CApp.Default_Item_OrderEachPackThreshold, true));
  
  Lbl_Exp.setForeground(CGUI.Color_Label_InputPrimary); CB_Exp.setSelected(false);
  Lbl_ExpireCheckPeriod.setForeground(CGUI.Color_Label_InputPrimary); TF_ExpireCheckPeriod.setText("");
  Lbl_ExpireThreshold.setForeground(CGUI.Color_Label_InputPrimary); TF_ExpireThreshold.setText("");
  
  Lbl_Sell.setForeground(CGUI.Color_Label_InputPrimary); TF_Sell.setText("0");
  Lbl_SellComment.setForeground(CGUI.Color_Label_InputSecondary); TA_SellComment.setText("");
  Lbl_SellUpdate.setForeground(CGUI.Color_Label_InputSecondary); TF_SellUpdateYear.setText(""); CB_SellUpdateOn.setSelected(false); CB_SellUpdateOnActionPerformed(null);
  Lbl_BuyPriceEst.setForeground(CGUI.Color_Label_InputPrimary); TF_BuyPriceEst.setText("0");
  Lbl_BuyComment.setForeground(CGUI.Color_Label_InputSecondary); TA_BuyComment.setText("");
  Lbl_BuyUpdate.setForeground(CGUI.Color_Label_InputSecondary); TF_BuyUpdateYear.setText(""); CB_BuyUpdateOn.setSelected(false); CB_BuyUpdateOnActionPerformed(null);
  
  Lbl_OpStock.setForeground(CGUI.Color_Label_InputSecondary); TF_OpStock.setText("");
  Lbl_OpExpire.setForeground(CGUI.Color_Label_InputSecondary); TF_OpExpireYear.setText(""); CB_OpExpireOn.setSelected(false); CB_OpExpireOnActionPerformed(null);
  Lbl_OrderQty.setForeground(CGUI.Color_Label_InputSecondary); TF_OrderQty.setText("");
  
  clearSetVariables();
 }
 
 void clearSetVariables(){
  wInfoItem=null;
 }
 
 void fillComponentsWithSetVariables(){
  TF_Id.setText(String.valueOf(wId));
  TF_Name.setText(wInfoItem.Name);
  CB_Active.setSelected(wInfoItem.IsActive);
  if(wInfoItem.Comment!=null){TA_Comment.setText(wInfoItem.Comment);}
  
  StockUnitId=wInfoItem.StockUnit; if(wInfoItem.StockUnitName!=null){TF_StockUnit.setText(wInfoItem.StockUnitName);}
  TF_Stock.setText(PText.doubleToString(wInfoItem.Stock, true));
  CB_AutoUpdateStock.setSelected(wInfoItem.UpdateStock);
  TF_MinStock.setText(PText.doubleToString(wInfoItem.MinStock, true));
  TF_MaxStock.setText(PText.doubleToString(wInfoItem.MaxStock, true));
  
  CB_IsOpname.setSelected(wInfoItem.IsOpname);
  CB_IsReorder.setSelected(wInfoItem.IsReorder);
  TF_OrderMinPack.setText(PText.doubleToString(wInfoItem.OrderMinPack, true));
  TF_OrderEachPackQty.setText(PText.doubleToString(wInfoItem.OrderEachPackQty, true));
  TF_OrderEachPackThreshold.setText(PText.doubleToString(wInfoItem.OrderEachPackThreshold, true));
  
  CB_Exp.setSelected(wInfoItem.HasExpireDate);
  TF_ExpireCheckPeriod.setText(PText.getString(wInfoItem.ExpireCheckPeriod, "", -1, false));
  TF_ExpireThreshold.setText(PText.getString(wInfoItem.ExpireThreshold, "", -1, false));
  
  TF_Sell.setText(PText.doubleToString(wInfoItem.SellPrice, true));
  if(wInfoItem.SellPriceComment!=null){TA_SellComment.setText(wInfoItem.SellPriceComment);}
  PGUI.setDateComponent(wInfoItem.SellUpdate, CB_SellUpdateOn, TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay, true);
  TF_BuyPriceEst.setText(PText.doubleToString(wInfoItem.BuyPriceEstimation, true));
  if(wInfoItem.BuyPriceComment!=null){TA_BuyComment.setText(wInfoItem.BuyPriceComment);}
  PGUI.setDateComponent(wInfoItem.BuyUpdate, CB_BuyUpdateOn, TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay, true);
  
  TF_OpStock.setText(PText.getStringDouble2(wInfoItem.OpnameStock, "", false, true));
  CB_OpExpireOn.setSelected(wInfoItem.OpnameExpire!=null);
  enableInputInDateComponents(CB_OpExpireOn.isSelected(), TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay);
  if(wInfoItem.OpnameExpire!=null){PGUI.setDateComponent(wInfoItem.OpnameExpire, TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay);}
  TF_OrderQty.setText(PText.getStringDouble(wInfoItem.OrderQuantity, "", -0.1, false, true));
 }
 
 void EditMode(boolean Enable){
  Btn_ChooseStockUnit.setEnabled(Enable);
  Btn_ClearStockUnit.setEnabled(Enable);
  Btn_Ok.setVisible(Enable);
  Btn_Generate.setVisible(Enable);
  Btn_CheckAvailable.setVisible(Enable);
  if(Enable==true){Btn_Cancel.setText("Batal {Esc}");}
  else{Btn_Cancel.setText("Tutup {Esc}");}
 }

 void enableInputInDateComponents(boolean Enable, JTextField CompYear, JComboBox CompMonth, JComboBox CompDay){
  CompYear.setEnabled(Enable);
  CompMonth.setEnabled(Enable);
  CompDay.setEnabled(Enable);
 }
 
 boolean fill_GenId(){
  boolean ret=false;
  Long Id;
  
  do{
   Id=PMyShop.generateNewIdOnItem(IFV.Stm, IFV.BarcodeGenEAN);
   if(Id==null){break;}
   TF_Id.setText(String.valueOf(Id));
   ret=true;
  }while(false);
  
  return ret;
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jSeparator1 = new javax.swing.JSeparator();
  jPanel1 = new javax.swing.JPanel();
  jPanel8 = new javax.swing.JPanel();
  TF_Sell = new javax.swing.JTextField();
  Lbl_Sell = new javax.swing.JLabel();
  Lbl_SellHelp = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_SellComment = new javax.swing.JTextArea();
  Lbl_SellComment = new javax.swing.JLabel();
  Lbl_SellCommentHelp = new javax.swing.JLabel();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_BuyComment = new javax.swing.JTextArea();
  Lbl_BuyComment = new javax.swing.JLabel();
  Lbl_BuyCommentHelp = new javax.swing.JLabel();
  TF_BuyPriceEst = new javax.swing.JTextField();
  Lbl_BuyPriceEst = new javax.swing.JLabel();
  Lbl_BuyPriceEstHelp = new javax.swing.JLabel();
  CmB_SellUpdateDay = new javax.swing.JComboBox<>();
  CmB_SellUpdateMonth = new javax.swing.JComboBox<>();
  TF_SellUpdateYear = new javax.swing.JTextField();
  CB_SellUpdateOn = new javax.swing.JCheckBox();
  Lbl_SellUpdate = new javax.swing.JLabel();
  CmB_BuyUpdateDay = new javax.swing.JComboBox<>();
  CmB_BuyUpdateMonth = new javax.swing.JComboBox<>();
  CB_BuyUpdateOn = new javax.swing.JCheckBox();
  TF_BuyUpdateYear = new javax.swing.JTextField();
  Lbl_BuyUpdate = new javax.swing.JLabel();
  Btn_SellUpdateSetToday = new javax.swing.JButton();
  Btn_BuyUpdateSetToday = new javax.swing.JButton();
  jSeparator4 = new javax.swing.JSeparator();
  jPanel6 = new javax.swing.JPanel();
  TF_OpStock = new javax.swing.JTextField();
  Lbl_OpStock = new javax.swing.JLabel();
  Lbl_OpStockHelp = new javax.swing.JLabel();
  CmB_OpExpireDay = new javax.swing.JComboBox<>();
  CmB_OpExpireMonth = new javax.swing.JComboBox<>();
  TF_OpExpireYear = new javax.swing.JTextField();
  CB_OpExpireOn = new javax.swing.JCheckBox();
  Lbl_OpExpire = new javax.swing.JLabel();
  TF_OrderQty = new javax.swing.JTextField();
  Lbl_OrderQty = new javax.swing.JLabel();
  Lbl_OrderQtyHelp = new javax.swing.JLabel();
  jSeparator5 = new javax.swing.JSeparator();
  jPanel7 = new javax.swing.JPanel();
  CB_Exp = new javax.swing.JCheckBox();
  Lbl_Exp = new javax.swing.JLabel();
  TF_ExpireCheckPeriod = new javax.swing.JTextField();
  jLabel5 = new javax.swing.JLabel();
  Lbl_ExpireCheckPeriod = new javax.swing.JLabel();
  Lbl_ExpireCheckPeriodHelp = new javax.swing.JLabel();
  TF_ExpireThreshold = new javax.swing.JTextField();
  jLabel6 = new javax.swing.JLabel();
  Lbl_ExpireThreshold = new javax.swing.JLabel();
  Lbl_ExpireThresholdHelp = new javax.swing.JLabel();
  jPanel2 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  TF_Id = new javax.swing.JTextField();
  Lbl_Id = new javax.swing.JLabel();
  Lbl_IdHelp = new javax.swing.JLabel();
  Btn_Generate = new javax.swing.JButton();
  Btn_CheckAvailable = new javax.swing.JButton();
  Lbl_Name = new javax.swing.JLabel();
  Lbl_NameHelp = new javax.swing.JLabel();
  CB_Active = new javax.swing.JCheckBox();
  Lbl_Active = new javax.swing.JLabel();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  Lbl_Comment = new javax.swing.JLabel();
  Lbl_CommentHelp = new javax.swing.JLabel();
  TF_Name = new javax.swing.JTextField();
  jPanel5 = new javax.swing.JPanel();
  Btn_ClearStockUnit = new javax.swing.JButton();
  Btn_ChooseStockUnit = new javax.swing.JButton();
  TF_StockUnit = new javax.swing.JTextField();
  Lbl_StockUnit = new javax.swing.JLabel();
  TF_Stock = new javax.swing.JTextField();
  Lbl_Stock = new javax.swing.JLabel();
  Lbl_StockHelp = new javax.swing.JLabel();
  CB_AutoUpdateStock = new javax.swing.JCheckBox();
  Lbl_AutoUpdateStock = new javax.swing.JLabel();
  TF_MinStock = new javax.swing.JTextField();
  Lbl_MinStock = new javax.swing.JLabel();
  Lbl_MinStockHelp = new javax.swing.JLabel();
  TF_MaxStock = new javax.swing.JTextField();
  Lbl_MaxStock = new javax.swing.JLabel();
  Lbl_MaxStockHelp = new javax.swing.JLabel();
  TF_OrderEachPackQty = new javax.swing.JTextField();
  Lbl_OrderEachPackQty = new javax.swing.JLabel();
  Lbl_OrderEachPackQtyHelp = new javax.swing.JLabel();
  jLabel3 = new javax.swing.JLabel();
  TF_OrderEachPackThreshold = new javax.swing.JTextField();
  Lbl_OrderEachPackThreshold = new javax.swing.JLabel();
  Lbl_OrderEachPackThresholdHelp = new javax.swing.JLabel();
  TF_OrderMinPack = new javax.swing.JTextField();
  Lbl_OrderMinPack = new javax.swing.JLabel();
  Lbl_OrderMinPackHelp = new javax.swing.JLabel();
  CB_IsReorder = new javax.swing.JCheckBox();
  Lbl_IsReorder = new javax.swing.JLabel();
  CB_IsOpname = new javax.swing.JCheckBox();
  Lbl_IsOpname = new javax.swing.JLabel();
  jSeparator2 = new javax.swing.JSeparator();
  jPanel3 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();

  setTitle("A");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  TF_Sell.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellFocusGained(evt);
   }
  });
  TF_Sell.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellKeyPressed(evt);
   }
  });

  Lbl_Sell.setText("Harga Jual");
  Lbl_Sell.setRequestFocusEnabled(false);

  Lbl_SellHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellHelp.setText("(?)");
  Lbl_SellHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellHelpMouseClicked(evt);
   }
  });

  TA_SellComment.setColumns(5);
  TA_SellComment.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_SellComment.setLineWrap(true);
  TA_SellComment.setWrapStyleWord(true);
  TA_SellComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TA_SellCommentFocusGained(evt);
   }
  });
  TA_SellComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_SellCommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_SellComment);

  Lbl_SellComment.setText("~ Ket. Jual (Ops)");
  Lbl_SellComment.setRequestFocusEnabled(false);

  Lbl_SellCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_SellCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_SellCommentHelp.setText("(?)");
  Lbl_SellCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_SellCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_SellCommentHelpMouseClicked(evt);
   }
  });

  TA_BuyComment.setColumns(5);
  TA_BuyComment.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_BuyComment.setLineWrap(true);
  TA_BuyComment.setWrapStyleWord(true);
  TA_BuyComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TA_BuyCommentFocusGained(evt);
   }
  });
  TA_BuyComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyCommentKeyPressed(evt);
   }
  });
  jScrollPane3.setViewportView(TA_BuyComment);

  Lbl_BuyComment.setText("~ Ket. Beli (Ops)");
  Lbl_BuyComment.setRequestFocusEnabled(false);

  Lbl_BuyCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyCommentHelp.setText("(?)");
  Lbl_BuyCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyCommentHelpMouseClicked(evt);
   }
  });

  TF_BuyPriceEst.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyPriceEstFocusGained(evt);
   }
  });
  TF_BuyPriceEst.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceEstKeyPressed(evt);
   }
  });

  Lbl_BuyPriceEst.setText("Kisaran Harga Beli");

  Lbl_BuyPriceEstHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceEstHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceEstHelp.setText("(?)");
  Lbl_BuyPriceEstHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceEstHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceEstHelpMouseClicked(evt);
   }
  });

  CmB_SellUpdateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_SellUpdateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateDayKeyPressed(evt);
   }
  });

  CmB_SellUpdateMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_SellUpdateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_SellUpdateMonthKeyPressed(evt);
   }
  });

  TF_SellUpdateYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_SellUpdateYearFocusGained(evt);
   }
  });
  TF_SellUpdateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_SellUpdateYearKeyPressed(evt);
   }
  });

  CB_SellUpdateOn.setText(" ");
  CB_SellUpdateOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SellUpdateOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SellUpdateOnActionPerformed(evt);
   }
  });
  CB_SellUpdateOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_SellUpdateOnKeyPressed(evt);
   }
  });

  Lbl_SellUpdate.setText("~ Tgl Update Jual (Ops)");

  CmB_BuyUpdateDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_BuyUpdateDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDayKeyPressed(evt);
   }
  });

  CmB_BuyUpdateMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_BuyUpdateMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateMonthKeyPressed(evt);
   }
  });

  CB_BuyUpdateOn.setText(" ");
  CB_BuyUpdateOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdateOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyUpdateOnActionPerformed(evt);
   }
  });
  CB_BuyUpdateOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateOnKeyPressed(evt);
   }
  });

  TF_BuyUpdateYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_BuyUpdateYearFocusGained(evt);
   }
  });
  TF_BuyUpdateYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateYearKeyPressed(evt);
   }
  });

  Lbl_BuyUpdate.setText("~ Tgl Update Beli (Ops)");

  Btn_SellUpdateSetToday.setText("Hari Ini");
  Btn_SellUpdateSetToday.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_SellUpdateSetToday.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_SellUpdateSetTodayActionPerformed(evt);
   }
  });
  Btn_SellUpdateSetToday.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_SellUpdateSetTodayKeyPressed(evt);
   }
  });

  Btn_BuyUpdateSetToday.setText("Hari Ini");
  Btn_BuyUpdateSetToday.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_BuyUpdateSetToday.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_BuyUpdateSetTodayActionPerformed(evt);
   }
  });
  Btn_BuyUpdateSetToday.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_BuyUpdateSetTodayKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(Lbl_BuyComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyCommentHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(Lbl_Sell)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_SellHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(Lbl_BuyPriceEst)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPriceEstHelp))
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(Lbl_SellComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_SellCommentHelp))
     .addComponent(Lbl_SellUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
     .addComponent(Lbl_BuyUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_Sell)
     .addComponent(jScrollPane1)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(CB_BuyUpdateOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_BuyUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_BuyUpdateMonth, 0, 178, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_BuyUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_BuyUpdateSetToday))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
      .addComponent(CB_SellUpdateOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_SellUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_SellUpdateMonth, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_SellUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_SellUpdateSetToday))
     .addComponent(TF_BuyPriceEst)))
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Sell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Sell)
     .addComponent(Lbl_SellHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_SellUpdateSetToday)
     .addComponent(CmB_SellUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_SellUpdateOn)
     .addComponent(TF_SellUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_SellUpdateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_SellUpdate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_SellComment)
      .addComponent(Lbl_SellCommentHelp))
     .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_BuyPriceEst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_BuyPriceEst)
     .addComponent(Lbl_BuyPriceEstHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_BuyUpdateDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyUpdateOn)
     .addComponent(TF_BuyUpdateYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_BuyUpdate)
     .addComponent(Btn_BuyUpdateSetToday))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)
     .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_BuyComment)
      .addComponent(Lbl_BuyCommentHelp))))
  );

  TF_OpStock.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OpStockFocusGained(evt);
   }
  });
  TF_OpStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpStockKeyPressed(evt);
   }
  });

  Lbl_OpStock.setText("Op-Stok (Slsih) (Ops)");

  Lbl_OpStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OpStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OpStockHelp.setText("(?)");
  Lbl_OpStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OpStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OpStockHelpMouseClicked(evt);
   }
  });

  CmB_OpExpireDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_OpExpireDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpireDayKeyPressed(evt);
   }
  });

  CmB_OpExpireMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01-Jan", "02-Feb", "03-Mar", "04-Apr", "05-Mei", "06-Jun", "07-Jul", "08-Agu", "09-Sep", "10-Okt", "11-Nop", "12-Des" }));
  CmB_OpExpireMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_OpExpireMonthKeyPressed(evt);
   }
  });

  TF_OpExpireYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OpExpireYearFocusGained(evt);
   }
  });
  TF_OpExpireYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OpExpireYearKeyPressed(evt);
   }
  });

  CB_OpExpireOn.setText(" ");
  CB_OpExpireOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OpExpireOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OpExpireOnActionPerformed(evt);
   }
  });
  CB_OpExpireOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_OpExpireOnKeyPressed(evt);
   }
  });

  Lbl_OpExpire.setText("Op. Expire (Ops)");

  TF_OrderQty.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderQtyFocusGained(evt);
   }
  });
  TF_OrderQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderQtyKeyPressed(evt);
   }
  });

  Lbl_OrderQty.setText("Order Qty (Ops)");

  Lbl_OrderQtyHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderQtyHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderQtyHelp.setText("(?)");
  Lbl_OrderQtyHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderQtyHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderQtyHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel6Layout.createSequentialGroup()
      .addComponent(Lbl_OrderQty)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OrderQtyHelp))
     .addGroup(jPanel6Layout.createSequentialGroup()
      .addComponent(Lbl_OpStock)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_OpStockHelp))
     .addComponent(Lbl_OpExpire, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_OpStock)
     .addGroup(jPanel6Layout.createSequentialGroup()
      .addComponent(CB_OpExpireOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_OpExpireYear, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_OpExpireMonth, 0, 234, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_OpExpireDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(TF_OrderQty)))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OpStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OpStock)
     .addComponent(Lbl_OpStockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_OpExpireDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_OpExpireMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_OpExpireYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_OpExpireOn)
     .addComponent(Lbl_OpExpire))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OrderQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderQty)
     .addComponent(Lbl_OrderQtyHelp)))
  );

  CB_Exp.setText(" ");
  CB_Exp.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Exp.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ExpKeyPressed(evt);
   }
  });

  Lbl_Exp.setText("Berkadaluarsa");
  Lbl_Exp.setRequestFocusEnabled(false);

  TF_ExpireCheckPeriod.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ExpireCheckPeriodFocusGained(evt);
   }
  });
  TF_ExpireCheckPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpireCheckPeriodKeyPressed(evt);
   }
  });

  jLabel5.setText("hari");

  Lbl_ExpireCheckPeriod.setText("~ Cek Exp. Tiap (Ops)");

  Lbl_ExpireCheckPeriodHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpireCheckPeriodHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpireCheckPeriodHelp.setText("(?)");
  Lbl_ExpireCheckPeriodHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpireCheckPeriodHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpireCheckPeriodHelpMouseClicked(evt);
   }
  });

  TF_ExpireThreshold.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ExpireThresholdFocusGained(evt);
   }
  });
  TF_ExpireThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ExpireThresholdKeyPressed(evt);
   }
  });

  jLabel6.setText("hari");

  Lbl_ExpireThreshold.setText("~ Batas Exp. (Ops)");

  Lbl_ExpireThresholdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ExpireThresholdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ExpireThresholdHelp.setText("(?)");
  Lbl_ExpireThresholdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ExpireThresholdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ExpireThresholdHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(Lbl_ExpireThreshold)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ExpireThresholdHelp))
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(Lbl_ExpireCheckPeriod)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ExpireCheckPeriodHelp))
     .addComponent(Lbl_Exp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addComponent(CB_Exp)
      .addContainerGap(371, Short.MAX_VALUE))
     .addGroup(jPanel7Layout.createSequentialGroup()
      .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(TF_ExpireCheckPeriod)
       .addComponent(TF_ExpireThreshold))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)))))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Exp)
     .addComponent(Lbl_Exp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpireCheckPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel5)
     .addComponent(Lbl_ExpireCheckPeriod)
     .addComponent(Lbl_ExpireCheckPeriodHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ExpireThreshold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel6)
     .addComponent(Lbl_ExpireThreshold)
     .addComponent(Lbl_ExpireThresholdHelp)))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator4)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator5)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_Id.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_IdFocusGained(evt);
   }
  });
  TF_Id.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_IdKeyPressed(evt);
   }
  });

  Lbl_Id.setText("Id");
  Lbl_Id.setRequestFocusEnabled(false);

  Lbl_IdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_IdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_IdHelp.setText("(?)");
  Lbl_IdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_IdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_IdHelpMouseClicked(evt);
   }
  });

  Btn_Generate.setText("Gen");
  Btn_Generate.setToolTipText("Buat sebuah Id unik (kompatible dengan EAN-8 atau EAN-13)");
  Btn_Generate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  Btn_Generate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_GenerateActionPerformed(evt);
   }
  });
  Btn_Generate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_GenerateKeyPressed(evt);
   }
  });

  Btn_CheckAvailable.setText("Cek");
  Btn_CheckAvailable.setToolTipText("Cek ketersediaan Id");
  Btn_CheckAvailable.setMargin(new java.awt.Insets(0, 0, 0, 0));
  Btn_CheckAvailable.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CheckAvailableActionPerformed(evt);
   }
  });
  Btn_CheckAvailable.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CheckAvailableKeyPressed(evt);
   }
  });

  Lbl_Name.setText("Nama");
  Lbl_Name.setRequestFocusEnabled(false);

  Lbl_NameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_NameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_NameHelp.setText("(?)");
  Lbl_NameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_NameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_NameHelpMouseClicked(evt);
   }
  });

  CB_Active.setText(" ");
  CB_Active.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Active.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ActiveKeyPressed(evt);
   }
  });

  Lbl_Active.setText("Masih Aktif");
  Lbl_Active.setRequestFocusEnabled(false);

  TA_Comment.setColumns(5);
  TA_Comment.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_Comment.setLineWrap(true);
  TA_Comment.setWrapStyleWord(true);
  TA_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_Comment);

  Lbl_Comment.setText("Ket. (Ops)");
  Lbl_Comment.setRequestFocusEnabled(false);

  Lbl_CommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentHelp.setText("(?)");
  Lbl_CommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentHelpMouseClicked(evt);
   }
  });

  TF_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(Lbl_Name)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_NameHelp))
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(Lbl_Id)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_IdHelp)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Generate)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_CheckAvailable))
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(Lbl_Comment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_CommentHelp))
     .addComponent(Lbl_Active, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_Id)
     .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addComponent(CB_Active)
      .addContainerGap())
     .addComponent(TF_Name)))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Id)
     .addComponent(Lbl_IdHelp)
     .addComponent(Btn_Generate)
     .addComponent(Btn_CheckAvailable))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Name)
     .addComponent(Lbl_NameHelp)
     .addComponent(TF_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Active)
     .addComponent(CB_Active))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 229, Short.MAX_VALUE)
     .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_Comment)
      .addComponent(Lbl_CommentHelp))))
  );

  Btn_ClearStockUnit.setText("-");
  Btn_ClearStockUnit.setToolTipText("hapus satuan stok yang dipilih");
  Btn_ClearStockUnit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearStockUnitActionPerformed(evt);
   }
  });
  Btn_ClearStockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearStockUnitKeyPressed(evt);
   }
  });

  Btn_ChooseStockUnit.setText("...");
  Btn_ChooseStockUnit.setToolTipText("Pilih satuan stok");
  Btn_ChooseStockUnit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseStockUnit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseStockUnitActionPerformed(evt);
   }
  });
  Btn_ChooseStockUnit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseStockUnitKeyPressed(evt);
   }
  });

  TF_StockUnit.setEditable(false);
  TF_StockUnit.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_StockUnit.setText("Sat. Stok (Ops)");
  Lbl_StockUnit.setRequestFocusEnabled(false);

  TF_Stock.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_StockFocusGained(evt);
   }
  });
  TF_Stock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_StockKeyPressed(evt);
   }
  });

  Lbl_Stock.setText("~ Stok");
  Lbl_Stock.setToolTipText("");
  Lbl_Stock.setRequestFocusEnabled(false);

  Lbl_StockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_StockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_StockHelp.setText("(?)");
  Lbl_StockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_StockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_StockHelpMouseClicked(evt);
   }
  });

  CB_AutoUpdateStock.setText(" ");
  CB_AutoUpdateStock.setToolTipText("centang opsi ini jika stok brg akan otomatis diperbarui ketika melakukan transaksi");
  CB_AutoUpdateStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AutoUpdateStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_AutoUpdateStockKeyPressed(evt);
   }
  });

  Lbl_AutoUpdateStock.setText("Perbarui Stok");

  TF_MinStock.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_MinStockFocusGained(evt);
   }
  });
  TF_MinStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_MinStockKeyPressed(evt);
   }
  });

  Lbl_MinStock.setText("~ Stok Minimal");
  Lbl_MinStock.setRequestFocusEnabled(false);

  Lbl_MinStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MinStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_MinStockHelp.setText("(?)");
  Lbl_MinStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_MinStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_MinStockHelpMouseClicked(evt);
   }
  });

  TF_MaxStock.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_MaxStockFocusGained(evt);
   }
  });
  TF_MaxStock.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_MaxStockKeyPressed(evt);
   }
  });

  Lbl_MaxStock.setText("~ Stok Maksimal");
  Lbl_MaxStock.setRequestFocusEnabled(false);

  Lbl_MaxStockHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MaxStockHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_MaxStockHelp.setText("(?)");
  Lbl_MaxStockHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_MaxStockHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_MaxStockHelpMouseClicked(evt);
   }
  });

  TF_OrderEachPackQty.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderEachPackQtyFocusGained(evt);
   }
  });
  TF_OrderEachPackQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackQtyKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackQty.setText("~ Order Qty / Pak");

  Lbl_OrderEachPackQtyHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackQtyHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackQtyHelp.setText("(?)");
  Lbl_OrderEachPackQtyHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackQtyHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackQtyHelpMouseClicked(evt);
   }
  });

  jLabel3.setText("%");

  TF_OrderEachPackThreshold.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderEachPackThresholdFocusGained(evt);
   }
  });
  TF_OrderEachPackThreshold.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderEachPackThresholdKeyPressed(evt);
   }
  });

  Lbl_OrderEachPackThreshold.setText("~ Pembulatan / Pak");

  Lbl_OrderEachPackThresholdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderEachPackThresholdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderEachPackThresholdHelp.setText("(?)");
  Lbl_OrderEachPackThresholdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderEachPackThresholdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderEachPackThresholdHelpMouseClicked(evt);
   }
  });

  TF_OrderMinPack.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrderMinPackFocusGained(evt);
   }
  });
  TF_OrderMinPack.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrderMinPackKeyPressed(evt);
   }
  });

  Lbl_OrderMinPack.setText("~ Order Min Pak");
  Lbl_OrderMinPack.setToolTipText("");

  Lbl_OrderMinPackHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_OrderMinPackHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_OrderMinPackHelp.setText("(?)");
  Lbl_OrderMinPackHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_OrderMinPackHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_OrderMinPackHelpMouseClicked(evt);
   }
  });

  CB_IsReorder.setText(" ");
  CB_IsReorder.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsReorder.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsReorderKeyPressed(evt);
   }
  });

  Lbl_IsReorder.setText("Di-Reorder");

  CB_IsOpname.setText(" ");
  CB_IsOpname.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsOpname.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsOpnameKeyPressed(evt);
   }
  });

  Lbl_IsOpname.setText("Di-Opname");

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_Stock)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_StockHelp))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_MaxStock)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_MaxStockHelp))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_MinStock)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_MinStockHelp))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_OrderEachPackQty)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_OrderEachPackQtyHelp))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_OrderEachPackThreshold)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_OrderEachPackThresholdHelp))
       .addGroup(jPanel5Layout.createSequentialGroup()
        .addComponent(Lbl_OrderMinPack)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_OrderMinPackHelp)))
      .addGap(0, 5, Short.MAX_VALUE))
     .addComponent(Lbl_StockUnit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_IsOpname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_IsReorder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_AutoUpdateStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_OrderMinPack)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(TF_OrderEachPackThreshold)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jLabel3))
     .addComponent(TF_OrderEachPackQty)
     .addComponent(TF_MaxStock, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_MinStock, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_Stock, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addComponent(TF_StockUnit, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)
      .addGap(0, 0, 0)
      .addComponent(Btn_ChooseStockUnit)
      .addGap(3, 3, 3)
      .addComponent(Btn_ClearStockUnit))
     .addGroup(jPanel5Layout.createSequentialGroup()
      .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_IsOpname)
       .addComponent(CB_IsReorder)
       .addComponent(CB_AutoUpdateStock))
      .addGap(0, 0, Short.MAX_VALUE))))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_ClearStockUnit)
     .addComponent(Btn_ChooseStockUnit)
     .addComponent(TF_StockUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_StockUnit))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_AutoUpdateStock)
     .addComponent(CB_AutoUpdateStock))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Stock)
     .addComponent(Lbl_StockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_MinStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_MinStock)
     .addComponent(Lbl_MinStockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_MaxStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_MaxStock)
     .addComponent(Lbl_MaxStockHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_IsOpname)
     .addComponent(Lbl_IsOpname))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_IsReorder)
     .addComponent(Lbl_IsReorder))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OrderEachPackQty)
     .addComponent(Lbl_OrderEachPackQty)
     .addComponent(Lbl_OrderEachPackQtyHelp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel3)
     .addComponent(TF_OrderEachPackThreshold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderEachPackThreshold)
     .addComponent(Lbl_OrderEachPackThresholdHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_OrderMinPack, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_OrderMinPack)
     .addComponent(Lbl_OrderMinPackHelp)))
  );

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator2)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(layout.createSequentialGroup()
      .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jSeparator1)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addGap(18, 18, 18)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Lbl_IdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_IdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 18, 2, 0, 0, 0, false));
 }//GEN-LAST:event_Lbl_IdHelpMouseClicked

 private void Lbl_NameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_NameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 150, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_NameHelpMouseClicked

 private void Lbl_StockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_StockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_StockHelpMouseClicked

 private void Lbl_MinStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_MinStockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_MinStockHelpMouseClicked

 private void Lbl_MaxStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_MaxStockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_MaxStockHelpMouseClicked

 private void Lbl_CommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_CommentHelpMouseClicked

 private void Lbl_SellHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_SellHelpMouseClicked

 private void Lbl_SellCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_SellCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_SellCommentHelpMouseClicked

 private void Lbl_BuyCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_BuyCommentHelpMouseClicked

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   // title
   if(wMode==0){setTitle("Tambah Barang Baru");}
   else if(wMode==1){setTitle("Ubah Barang");}
   else{setTitle("Lihat Keterangan Barang");}
   
   // contents
   if(wMode==0){
    StockUnitId=-1;
    EditMode(true);
    fill_GenId();
   }
   else{
    fillComponentsWithSetVariables();
    if(wMode==1){EditMode(true);}
    else{EditMode(false);}
   }
   if(wMode==0){TF_Name.requestFocusInWindow();}
   else if(wMode==1){TF_Name.requestFocusInWindow();}
   else{Btn_Cancel.requestFocusInWindow();}
  }
 }//GEN-LAST:event_formWindowActivated

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  DialogResult=0;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrCheck;
  Date dt_exp, dt_sell, dt_buy;
  double dbl;
  
  IsValid=true;
  if(PText.checkInput(TF_Id.getText(), false, CCore.CharsCount_Long(), 2, 0, 0, 0)==true){Lbl_Id.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_Id.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_Name.getText(), false, 150, 0, 1, 1, 0)==true){Lbl_Name.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_Name.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TA_Comment.getText(), true, CApp.DbVarcharMaxSize, 0, 1, 1, 0)==true){Lbl_Comment.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_Comment.setForeground(CGUI.Color_Label_InputWrong);}
  
  if(PText.checkInput(TF_Stock.getText(), false, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)==true){Lbl_Stock.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_Stock.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_MinStock.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)==true){Lbl_MinStock.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_MinStock.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_MaxStock.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)==true){Lbl_MaxStock.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_MaxStock.setForeground(CGUI.Color_Label_InputWrong);}
  
  if(PText.checkInput(TF_OrderMinPack.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 7)==true){Lbl_OrderMinPack.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_OrderMinPack.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_OrderEachPackQty.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 7)==true){Lbl_OrderEachPackQty.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_OrderEachPackQty.setForeground(CGUI.Color_Label_InputWrong);}
  CurrCheck=false;
  do{
   if(!PText.checkInput(TF_OrderEachPackThreshold.getText(), false, CCore.CharsCount_DoublePercentage(), 6, 6, 6, 7)){break;}
   dbl=Double.parseDouble(TF_OrderEachPackThreshold.getText());
   if(!(dbl>0 && dbl<=100)){break;}
   CurrCheck=true;
  }while(false);
  if(CurrCheck){Lbl_OrderEachPackThreshold.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_OrderEachPackThreshold.setForeground(CGUI.Color_Label_InputWrong);}
  
  if(PText.checkInput(TF_ExpireCheckPeriod.getText(), true, CCore.CharsCount_Int(), 2, 7, 0, 0)==true){Lbl_ExpireCheckPeriod.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_ExpireCheckPeriod.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_ExpireThreshold.getText(), true, CCore.CharsCount_Int(), 2, 3, 0, 0)==true){Lbl_ExpireThreshold.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_ExpireThreshold.setForeground(CGUI.Color_Label_InputWrong);}
  
  if(PText.checkInput(TF_Sell.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)==true){Lbl_Sell.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_Sell.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TA_SellComment.getText(), true, CApp.DbVarcharMaxSize, 0, 1, 1, 0)==true){Lbl_SellComment.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_SellComment.setForeground(CGUI.Color_Label_InputWrong);}
  CurrCheck=true; dt_sell=null;
  if(CB_SellUpdateOn.isSelected()){dt_sell=PGUI.valueOfDateComponent(TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay); CurrCheck=dt_sell!=null;}
  if(CurrCheck){Lbl_SellUpdate.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_SellUpdate.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_BuyPriceEst.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)==true){Lbl_BuyPriceEst.setForeground(CGUI.Color_Label_InputPrimary);}
  else{IsValid=false; Lbl_BuyPriceEst.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TA_BuyComment.getText(), true, CApp.DbVarcharMaxSize, 0, 1, 1, 0)==true){Lbl_BuyComment.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_BuyComment.setForeground(CGUI.Color_Label_InputWrong);}
  CurrCheck=true; dt_buy=null;
  if(CB_BuyUpdateOn.isSelected()){dt_buy=PGUI.valueOfDateComponent(TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay); CurrCheck=dt_buy!=null;}
  if(CurrCheck){Lbl_BuyUpdate.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_BuyUpdate.setForeground(CGUI.Color_Label_InputWrong);}
  
  if(PText.checkInput(TF_OpStock.getText(), true, CCore.CharsCount_DeciSigned(), 8, 6, 8, 6)==true){Lbl_OpStock.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_OpStock.setForeground(CGUI.Color_Label_InputWrong);}
  CurrCheck=true; dt_exp=null;
  if(CB_OpExpireOn.isSelected()){dt_exp=PGUI.valueOfDateComponent(TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay); CurrCheck=dt_exp!=null;}
  if(CurrCheck){Lbl_OpExpire.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_OpExpire.setForeground(CGUI.Color_Label_InputWrong);}
  if(PText.checkInput(TF_OrderQty.getText(), true, CCore.CharsCount_Deci(), 6, 6, 6, 6)==true){Lbl_OrderQty.setForeground(CGUI.Color_Label_InputSecondary);}
  else{IsValid=false; Lbl_OrderQty.setForeground(CGUI.Color_Label_InputWrong);}

  if(IsValid==true){
   Id=Long.parseLong(TF_Id.getText());
   Name=TF_Name.getText();
   IsActive=CB_Active.isSelected();
   Comment=TA_Comment.getText();
   
   StockUnitName=TF_StockUnit.getText();
   Stock=Double.parseDouble(TF_Stock.getText());
   UpdateStock=CB_AutoUpdateStock.isSelected();
   MinStock=Double.parseDouble(TF_MinStock.getText());
   MaxStock=Double.parseDouble(TF_MaxStock.getText());
   
   IsOpname=CB_IsOpname.isSelected();
   IsReorder=CB_IsReorder.isSelected();
   OrderMinPack=Double.parseDouble(TF_OrderMinPack.getText());
   OrderEachPackQty=Double.parseDouble(TF_OrderEachPackQty.getText());
   OrderEachPackThreshold=Double.parseDouble(TF_OrderEachPackThreshold.getText());
   
   HasExpireDate=CB_Exp.isSelected();
   ExpireCheckPeriod=PText.parseInt(TF_ExpireCheckPeriod.getText(), -1, -1);
   ExpireThreshold=PText.parseInt(TF_ExpireThreshold.getText(), -1, -1);
   
   SellPrice=Double.parseDouble(TF_Sell.getText());
   SellPriceComment=TA_SellComment.getText();
   SellUpdate=dt_sell;
   BuyPriceEst=Double.parseDouble(TF_BuyPriceEst.getText());
   BuyPriceComment=TA_BuyComment.getText();
   BuyUpdate=dt_buy;
   
   OpStock=PText.parseDouble(TF_OpStock.getText(), null, null);
   OpExpire=dt_exp;
   OrderQty=PText.parseDouble(TF_OrderQty.getText(), -1D, -1D);
   
   DialogResult=1;
   clearComponents();
   Activ=false;
   setVisible(false);
  }
  else{
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !\n"+
    "Silahkan perbaiki masukan pada label berwarna merah !");
  }
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_ClearStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearStockUnitActionPerformed
  StockUnitId=-1;
  TF_StockUnit.setText("");
 }//GEN-LAST:event_Btn_ClearStockUnitActionPerformed

 private void Btn_ChooseStockUnitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseStockUnitActionPerformed
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=false;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblStockUnit;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   StockUnitId=(int)IFV.FDataIdName.DataId[0];
   TF_StockUnit.setText(IFV.FDataIdName.DataName[0]);
  }
 }//GEN-LAST:event_Btn_ChooseStockUnitActionPerformed

 private void Btn_GenerateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_GenerateActionPerformed
  if(fill_GenId()==false){
   JOptionPane.showMessageDialog(null, "Gagal meng-generate Id baru !");
  }
 }//GEN-LAST:event_Btn_GenerateActionPerformed

 private void Lbl_ExpireCheckPeriodHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpireCheckPeriodHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Lakukan pengecekan kadaluarsa setiap .... hari.\n"+
   "- Data di-input dalam satuan hari.\n"+
   PText.getInputInfo(true, 9, 2, 7, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpireCheckPeriodHelpMouseClicked

 private void Lbl_ExpireThresholdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ExpireThresholdHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Peringatan kadaluarsa .... hari menjelang tanggal kadaluarsa.\n"+
   "- Data di-input dalam satuan hari.\n"+
   PText.getInputInfo(true, 9, 2, 3, 0, 0, false));
 }//GEN-LAST:event_Lbl_ExpireThresholdHelpMouseClicked

 private void Btn_CheckAvailableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CheckAvailableActionPerformed
  int check;
  String IdText=TF_Id.getText();
  String Msg=null;
  if(!PText.checkInput(IdText, false, CCore.CharsCount_Long(), 2, 0, 0, 0)){
   JOptionPane.showMessageDialog(null, "Tidak dapat mengecek : Masukan Id belum benar !");
   return;
  }
  check=PMyShop.checkExistIdOnItem(Long.parseLong(IdText), IFV.Stm);
  switch(check){
   case  0 : Msg="Id tersedia (belum terpakai) !"; break;
   case  1 : Msg="Id sudah terpakai !"; break;
   case -1 : Msg="Gagal mengecek ketersediaan Id !"; break;
  }
  JOptionPane.showMessageDialog(null, Msg);
 }//GEN-LAST:event_Btn_CheckAvailableActionPerformed

 private void Lbl_OpStockHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OpStockHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 13, 8, 6, 8, 6, false));
 }//GEN-LAST:event_Lbl_OpStockHelpMouseClicked

 private void CB_OpExpireOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OpExpireOnActionPerformed
  enableInputInDateComponents(CB_OpExpireOn.isSelected(), TF_OpExpireYear, CmB_OpExpireMonth, CmB_OpExpireDay);
 }//GEN-LAST:event_CB_OpExpireOnActionPerformed

 private void Lbl_BuyPriceEstHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceEstHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPriceEstHelpMouseClicked

 private void Lbl_OrderQtyHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderQtyHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_OrderQtyHelpMouseClicked

 private void CB_SellUpdateOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SellUpdateOnActionPerformed
  enableInputInDateComponents(CB_SellUpdateOn.isSelected(), TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay);
 }//GEN-LAST:event_CB_SellUpdateOnActionPerformed

 private void CB_BuyUpdateOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyUpdateOnActionPerformed
  enableInputInDateComponents(CB_BuyUpdateOn.isSelected(), TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay);
 }//GEN-LAST:event_CB_BuyUpdateOnActionPerformed

 private void Btn_SellUpdateSetTodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_SellUpdateSetTodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_SellUpdateOn, TF_SellUpdateYear, CmB_SellUpdateMonth, CmB_SellUpdateDay, false);
 }//GEN-LAST:event_Btn_SellUpdateSetTodayActionPerformed

 private void Btn_BuyUpdateSetTodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_BuyUpdateSetTodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_BuyUpdateOn, TF_BuyUpdateYear, CmB_BuyUpdateMonth, CmB_BuyUpdateDay, false);
 }//GEN-LAST:event_Btn_BuyUpdateSetTodayActionPerformed

 private void Lbl_OrderEachPackThresholdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackThresholdHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   "- Bulatkan menjadi 1 pak jika 'sisa perhitungan' >= 'n' % x 'Order Qty / Pak'."+"\n"+
   "- Jangkauan nilai 'n' adalah 0 < 'n' <= 100."+"\n"+
   PText.getInputInfo(false, 6, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackThresholdHelpMouseClicked

 private void Lbl_OrderMinPackHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderMinPackHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderMinPackHelpMouseClicked

 private void Lbl_OrderEachPackQtyHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_OrderEachPackQtyHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 12, 6, 6, 6, 7, false));
 }//GEN-LAST:event_Lbl_OrderEachPackQtyHelpMouseClicked

 private void Btn_GenerateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_GenerateKeyPressed
  PNav.onKey_Btn(this, Btn_Generate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_CheckAvailable)));
 }//GEN-LAST:event_Btn_GenerateKeyPressed

 private void Btn_CheckAvailableKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CheckAvailableKeyPressed
  PNav.onKey_Btn(this, Btn_CheckAvailable, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Generate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Id)));
 }//GEN-LAST:event_Btn_CheckAvailableKeyPressed

 private void TF_IdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_IdKeyPressed
  PNav.onKey_TF(this, TF_Id, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Name)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_CheckAvailable)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_IdKeyPressed

 private void TF_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameKeyPressed
  PNav.onKey_TF(this, TF_Name, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Id)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Active)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_NameKeyPressed

 private void CB_ActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ActiveKeyPressed
  PNav.onKey_CB(this, CB_Active, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_CB_ActiveKeyPressed

 private void TA_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentKeyPressed
  PNav.onKey_TA(this, TA_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Active)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TA_CommentKeyPressed

 private void Btn_ChooseStockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseStockUnitKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseStockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_AutoUpdateStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearStockUnit)));
 }//GEN-LAST:event_Btn_ChooseStockUnitKeyPressed

 private void Btn_ClearStockUnitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearStockUnitKeyPressed
  PNav.onKey_Btn(this, Btn_ClearStockUnit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_AutoUpdateStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_Btn_ClearStockUnitKeyPressed

 private void CB_AutoUpdateStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_AutoUpdateStockKeyPressed
  PNav.onKey_CB(this, CB_AutoUpdateStock, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseStockUnit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Stock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_CB_AutoUpdateStockKeyPressed

 private void TF_StockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_StockKeyPressed
  PNav.onKey_TF(this, TF_Stock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_AutoUpdateStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_MinStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_StockKeyPressed

 private void TF_MinStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_MinStockKeyPressed
  PNav.onKey_TF(this, TF_MinStock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Stock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_MaxStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_MinStockKeyPressed

 private void TF_MaxStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_MaxStockKeyPressed
  PNav.onKey_TF(this, TF_MaxStock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_MinStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsOpname)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_MaxStockKeyPressed

 private void CB_IsReorderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsReorderKeyPressed
  PNav.onKey_CB(this, CB_IsReorder, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsOpname)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_CB_IsReorderKeyPressed

 private void TF_OrderEachPackQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackQty, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsReorder)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderEachPackThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_OrderEachPackQtyKeyPressed

 private void TF_OrderEachPackThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdKeyPressed
  PNav.onKey_TF(this, TF_OrderEachPackThreshold, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderMinPack)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_OrderEachPackThresholdKeyPressed

 private void TF_OrderMinPackKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderMinPackKeyPressed
  PNav.onKey_TF(this, TF_OrderMinPack, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderEachPackThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Exp)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_TF_OrderMinPackKeyPressed

 private void CB_ExpKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ExpKeyPressed
  PNav.onKey_CB(this, CB_Exp, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderMinPack)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpireCheckPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_ExpKeyPressed

 private void TF_ExpireCheckPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpireCheckPeriodKeyPressed
  PNav.onKey_TF(this, TF_ExpireCheckPeriod, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Exp)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ExpireThreshold)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpireCheckPeriodKeyPressed

 private void TF_ExpireThresholdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ExpireThresholdKeyPressed
  PNav.onKey_TF(this, TF_ExpireThreshold, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpireCheckPeriod)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Sell)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ExpireThresholdKeyPressed

 private void TF_SellKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellKeyPressed
  PNav.onKey_TF(this, TF_Sell, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ExpireThreshold)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_SellKeyPressed

 private void CB_SellUpdateOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_SellUpdateOnKeyPressed
  PNav.onKey_CB(this, CB_SellUpdateOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_SellUpdateYear, Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_CB_SellUpdateOnKeyPressed

 private void TF_SellUpdateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_SellUpdateYearKeyPressed
  PNav.onKey_TF(this, TF_SellUpdateYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateMonth, Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_TF_SellUpdateYearKeyPressed

 private void CmB_SellUpdateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateMonthKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_SellUpdateYear, CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_SellUpdateDay, Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_CmB_SellUpdateMonthKeyPressed

 private void CmB_SellUpdateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_SellUpdateDayKeyPressed
  PNav.onKey_CmB(this, CmB_SellUpdateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SellUpdateMonth, CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_SellUpdateSetToday)));
 }//GEN-LAST:event_CmB_SellUpdateDayKeyPressed

 private void Btn_SellUpdateSetTodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_SellUpdateSetTodayKeyPressed
  PNav.onKey_Btn(this, Btn_SellUpdateSetToday, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Sell)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_SellComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_SellUpdateDay, CB_SellUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_SellUpdateSetTodayKeyPressed

 private void TA_SellCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_SellCommentKeyPressed
  PNav.onKey_TA(this, TA_SellComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_SellUpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_SellCommentKeyPressed

 private void TF_BuyPriceEstKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceEst, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_SellComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPriceEstKeyPressed

 private void CB_BuyUpdateOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateOnKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdateOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateYear, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CB_BuyUpdateOnKeyPressed

 private void TF_BuyUpdateYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateYearKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateMonth, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_TF_BuyUpdateYearKeyPressed

 private void CmB_BuyUpdateMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateMonthKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateYear, CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateDay, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CmB_BuyUpdateMonthKeyPressed

 private void CmB_BuyUpdateDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDayKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateMonth, CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CmB_BuyUpdateDayKeyPressed

 private void Btn_BuyUpdateSetTodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_BuyUpdateSetTodayKeyPressed
  PNav.onKey_Btn(this, Btn_BuyUpdateSetToday, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceEst)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateDay, CB_BuyUpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_BuyUpdateSetTodayKeyPressed

 private void TA_BuyCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyCommentKeyPressed
  PNav.onKey_TA(this, TA_BuyComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OpStock)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyCommentKeyPressed

 private void TF_OpStockKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpStockKeyPressed
  PNav.onKey_TF(this, TF_OpStock, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_OpExpireOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OpStockKeyPressed

 private void CB_OpExpireOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_OpExpireOnKeyPressed
  PNav.onKey_CB(this, CB_OpExpireOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OpExpireYear)));
 }//GEN-LAST:event_CB_OpExpireOnKeyPressed

 private void TF_OpExpireYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OpExpireYearKeyPressed
  PNav.onKey_TF(this, TF_OpExpireYear, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OpStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_OrderQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_OpExpireOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpireMonth)));
 }//GEN-LAST:event_TF_OpExpireYearKeyPressed

 private void CmB_OpExpireMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpireMonthKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpireMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_OpExpireYear, CB_OpExpireOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_OpExpireDay)));
 }//GEN-LAST:event_CmB_OpExpireMonthKeyPressed

 private void CmB_OpExpireDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_OpExpireDayKeyPressed
  PNav.onKey_CmB(this, CmB_OpExpireDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_OpExpireMonth, CB_OpExpireOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_OrderQty)));
 }//GEN-LAST:event_CmB_OpExpireDayKeyPressed

 private void TF_OrderQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrderQtyKeyPressed
  PNav.onKey_TF(this, TF_OrderQty, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_OpExpireOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Id)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_OrderQtyKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrderQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void CB_IsOpnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsOpnameKeyPressed
  PNav.onKey_CB(this, CB_IsOpname, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_MaxStock)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsReorder)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_Exp)));
 }//GEN-LAST:event_CB_IsOpnameKeyPressed

 private void TF_StockFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_StockFocusGained
  PGUI.text_SelectAll(TF_Stock);
 }//GEN-LAST:event_TF_StockFocusGained

 private void TF_MinStockFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_MinStockFocusGained
  PGUI.text_SelectAll(TF_MinStock);
 }//GEN-LAST:event_TF_MinStockFocusGained

 private void TF_MaxStockFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_MaxStockFocusGained
  PGUI.text_SelectAll(TF_MaxStock);
 }//GEN-LAST:event_TF_MaxStockFocusGained

 private void TF_OrderEachPackQtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderEachPackQtyFocusGained
  PGUI.text_SelectAll(TF_OrderEachPackQty);
 }//GEN-LAST:event_TF_OrderEachPackQtyFocusGained

 private void TF_OrderEachPackThresholdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderEachPackThresholdFocusGained
  PGUI.text_SelectAll(TF_OrderEachPackThreshold);
 }//GEN-LAST:event_TF_OrderEachPackThresholdFocusGained

 private void TF_OrderMinPackFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderMinPackFocusGained
  PGUI.text_SelectAll(TF_OrderMinPack);
 }//GEN-LAST:event_TF_OrderMinPackFocusGained

 private void TF_ExpireCheckPeriodFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ExpireCheckPeriodFocusGained
  PGUI.text_SelectAll(TF_ExpireCheckPeriod);
 }//GEN-LAST:event_TF_ExpireCheckPeriodFocusGained

 private void TF_ExpireThresholdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ExpireThresholdFocusGained
  PGUI.text_SelectAll(TF_ExpireThreshold);
 }//GEN-LAST:event_TF_ExpireThresholdFocusGained

 private void TF_SellFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellFocusGained
  PGUI.text_SelectAll(TF_Sell);
 }//GEN-LAST:event_TF_SellFocusGained

 private void TF_SellUpdateYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_SellUpdateYearFocusGained
  PGUI.text_SelectAll(TF_SellUpdateYear);
 }//GEN-LAST:event_TF_SellUpdateYearFocusGained

 private void TF_BuyPriceEstFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyPriceEstFocusGained
  PGUI.text_SelectAll(TF_BuyPriceEst);
 }//GEN-LAST:event_TF_BuyPriceEstFocusGained

 private void TF_BuyUpdateYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_BuyUpdateYearFocusGained
  PGUI.text_SelectAll(TF_BuyUpdateYear);
 }//GEN-LAST:event_TF_BuyUpdateYearFocusGained

 private void TA_SellCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_SellCommentFocusGained
  PGUI.text_SelectAll(TA_SellComment);
 }//GEN-LAST:event_TA_SellCommentFocusGained

 private void TA_BuyCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TA_BuyCommentFocusGained
  PGUI.text_SelectAll(TA_BuyComment);
 }//GEN-LAST:event_TA_BuyCommentFocusGained

 private void TF_OpStockFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OpStockFocusGained
  PGUI.text_SelectAll(TF_OpStock);
 }//GEN-LAST:event_TF_OpStockFocusGained

 private void TF_OpExpireYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OpExpireYearFocusGained
  PGUI.text_SelectAll(TF_OpExpireYear);
 }//GEN-LAST:event_TF_OpExpireYearFocusGained

 private void TF_OrderQtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrderQtyFocusGained
  PGUI.text_SelectAll(TF_OrderQty);
 }//GEN-LAST:event_TF_OrderQtyFocusGained

 private void TF_IdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_IdFocusGained
  PGUI.text_SelectAll(TF_Id);
 }//GEN-LAST:event_TF_IdFocusGained


 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_BuyUpdateSetToday;
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_CheckAvailable;
 private javax.swing.JButton Btn_ChooseStockUnit;
 private javax.swing.JButton Btn_ClearStockUnit;
 private javax.swing.JButton Btn_Generate;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_SellUpdateSetToday;
 private javax.swing.JCheckBox CB_Active;
 private javax.swing.JCheckBox CB_AutoUpdateStock;
 private javax.swing.JCheckBox CB_BuyUpdateOn;
 private javax.swing.JCheckBox CB_Exp;
 private javax.swing.JCheckBox CB_IsOpname;
 private javax.swing.JCheckBox CB_IsReorder;
 private javax.swing.JCheckBox CB_OpExpireOn;
 private javax.swing.JCheckBox CB_SellUpdateOn;
 private javax.swing.JComboBox<String> CmB_BuyUpdateDay;
 private javax.swing.JComboBox<String> CmB_BuyUpdateMonth;
 private javax.swing.JComboBox<String> CmB_OpExpireDay;
 private javax.swing.JComboBox<String> CmB_OpExpireMonth;
 private javax.swing.JComboBox<String> CmB_SellUpdateDay;
 private javax.swing.JComboBox<String> CmB_SellUpdateMonth;
 private javax.swing.JLabel Lbl_Active;
 private javax.swing.JLabel Lbl_AutoUpdateStock;
 private javax.swing.JLabel Lbl_BuyComment;
 private javax.swing.JLabel Lbl_BuyCommentHelp;
 private javax.swing.JLabel Lbl_BuyPriceEst;
 private javax.swing.JLabel Lbl_BuyPriceEstHelp;
 private javax.swing.JLabel Lbl_BuyUpdate;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_CommentHelp;
 private javax.swing.JLabel Lbl_Exp;
 private javax.swing.JLabel Lbl_ExpireCheckPeriod;
 private javax.swing.JLabel Lbl_ExpireCheckPeriodHelp;
 private javax.swing.JLabel Lbl_ExpireThreshold;
 private javax.swing.JLabel Lbl_ExpireThresholdHelp;
 private javax.swing.JLabel Lbl_Id;
 private javax.swing.JLabel Lbl_IdHelp;
 private javax.swing.JLabel Lbl_IsOpname;
 private javax.swing.JLabel Lbl_IsReorder;
 private javax.swing.JLabel Lbl_MaxStock;
 private javax.swing.JLabel Lbl_MaxStockHelp;
 private javax.swing.JLabel Lbl_MinStock;
 private javax.swing.JLabel Lbl_MinStockHelp;
 private javax.swing.JLabel Lbl_Name;
 private javax.swing.JLabel Lbl_NameHelp;
 private javax.swing.JLabel Lbl_OpExpire;
 private javax.swing.JLabel Lbl_OpStock;
 private javax.swing.JLabel Lbl_OpStockHelp;
 private javax.swing.JLabel Lbl_OrderEachPackQty;
 private javax.swing.JLabel Lbl_OrderEachPackQtyHelp;
 private javax.swing.JLabel Lbl_OrderEachPackThreshold;
 private javax.swing.JLabel Lbl_OrderEachPackThresholdHelp;
 private javax.swing.JLabel Lbl_OrderMinPack;
 private javax.swing.JLabel Lbl_OrderMinPackHelp;
 private javax.swing.JLabel Lbl_OrderQty;
 private javax.swing.JLabel Lbl_OrderQtyHelp;
 private javax.swing.JLabel Lbl_Sell;
 private javax.swing.JLabel Lbl_SellComment;
 private javax.swing.JLabel Lbl_SellCommentHelp;
 private javax.swing.JLabel Lbl_SellHelp;
 private javax.swing.JLabel Lbl_SellUpdate;
 private javax.swing.JLabel Lbl_Stock;
 private javax.swing.JLabel Lbl_StockHelp;
 private javax.swing.JLabel Lbl_StockUnit;
 private javax.swing.JTextArea TA_BuyComment;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextArea TA_SellComment;
 private javax.swing.JTextField TF_BuyPriceEst;
 private javax.swing.JTextField TF_BuyUpdateYear;
 private javax.swing.JTextField TF_ExpireCheckPeriod;
 private javax.swing.JTextField TF_ExpireThreshold;
 private javax.swing.JTextField TF_Id;
 private javax.swing.JTextField TF_MaxStock;
 private javax.swing.JTextField TF_MinStock;
 private javax.swing.JTextField TF_Name;
 private javax.swing.JTextField TF_OpExpireYear;
 private javax.swing.JTextField TF_OpStock;
 private javax.swing.JTextField TF_OrderEachPackQty;
 private javax.swing.JTextField TF_OrderEachPackThreshold;
 private javax.swing.JTextField TF_OrderMinPack;
 private javax.swing.JTextField TF_OrderQty;
 private javax.swing.JTextField TF_Sell;
 private javax.swing.JTextField TF_SellUpdateYear;
 private javax.swing.JTextField TF_Stock;
 private javax.swing.JTextField TF_StockUnit;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 // End of variables declaration//GEN-END:variables
}
