import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class F_ImagePreview extends XFormDialog {
 
 // set
 String wTitle;
 String wImageDir;
 int wModeFetchList; // 1 fetch list by provided list, 2 fetch list by query
 Vector<Object> wList; // the data type must be String
 String wQuery; // query must have only 1 column & the data type must be String
 boolean wAutoHideListPic;
 
 //
 OCustomListModel ListMdlListPic;
 int ListPic_PictureColumnIndex;
 boolean ListPicCleared;
 int LastSelectedRowListPic;
 boolean InfoPicCleared;
 
 public F_ImagePreview(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  ListMdlListPic=new OCustomListModel(false);
  ListMdlListPic.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  List_Pic.setModel(ListMdlListPic);
  LastSelectedRowListPic=-1;
  ListPicCleared=true;
  InfoPicCleared=true;
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    ),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
 }
 
 void clearComponents(){
  clearListPic();
  
  clearSetVariables();
 }
 void clearSetVariables(){
  wList=null;
  wQuery=null;
 }
 
 void onSelectedRowChangedListPic(boolean UpdateAnyway){
  int CurrRow=List_Pic.getSelectedIndex();
  
  if(!(CurrRow!=LastSelectedRowListPic || UpdateAnyway)){return;}
  
  LastSelectedRowListPic=CurrRow;
  
  if(CurrRow!=-1){fillInfoPic(CurrRow);}else{clearInfoPic();}
 }
 void fillListPic(){
  Vector<Object[]> ListContents=null;
  
  clearListPic();
  
  if(wModeFetchList==1){
   ListContents=PCore.toMultiRows(wList);
  }
  else if(wModeFetchList==1){
   ListContents=PCore.toMultiRows(PDatabase.getListFromQuery(IFV.Stm, wQuery, CCore.TypeString, false, null));
  }
  
  ListMdlListPic.append(ListContents);
  
  ListPicCleared=false;
 }
 void clearListPic(){
  if(ListPicCleared){return;}
  
  ListMdlListPic.removeAll(); LastSelectedRowListPic=-1; clearInfoPic();
  
  ListPicCleared=true;
 }
 void fillInfoPic(int Row){
  String PictureFile;
  
  PictureFile=ListMdlListPic.getElementAt(Row);
  PGUI.fillPanelPictureURL(Pnl_Pic, wImageDir, PictureFile);
  
  InfoPicCleared=false;
 }
 void clearInfoPic(){
  if(InfoPicCleared){return;}
  
  PGUI.fillPanelPictureURL(Pnl_Pic, wImageDir, null);
  
  InfoPicCleared=true;
 }
 
 void fillComponentsWithSetVariables(){
  fillListPic();
 }
 void setVisibilityOfListPic(){
  boolean Visible;
  
  Visible=true; if(wAutoHideListPic && ListMdlListPic.getSize()<=1){Visible=false;}
  
  Pnl_ListPic.setVisible(Visible);
 }
 void selectPicture(boolean AutoSelect){
  if(AutoSelect && ListMdlListPic.getSize()!=0){List_Pic.setSelectedIndex(0); onSelectedRowChangedListPic(true);}
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  Pnl_Pic = new XImgBoxURL();
  Pnl_ListPic = new javax.swing.JPanel();
  jScrollPane1 = new javax.swing.JScrollPane();
  List_Pic = new XList();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  List_Pic.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_PicMouseReleased(evt);
   }
  });
  List_Pic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PicKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(List_Pic);

  javax.swing.GroupLayout Pnl_ListPicLayout = new javax.swing.GroupLayout(Pnl_ListPic);
  Pnl_ListPic.setLayout(Pnl_ListPicLayout);
  Pnl_ListPicLayout.setHorizontalGroup(
   Pnl_ListPicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 650, Short.MAX_VALUE)
  );
  Pnl_ListPicLayout.setVerticalGroup(
   Pnl_ListPicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_Pic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Pnl_ListPic, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addComponent(Pnl_Pic, javax.swing.GroupLayout.DEFAULT_SIZE, 615, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(Pnl_ListPic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  
  setTitle(wTitle);
  
  fillComponentsWithSetVariables();
  // setVisibilityOfListPic();
  selectPicture(true);
  
  PGUI.requestFocusInWindow((Component)PCore.subtituteBool(Pnl_ListPic.isVisible(), List_Pic, Pnl_Pic));
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void List_PicKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PicKeyReleased
  onSelectedRowChangedListPic(false);
 }//GEN-LAST:event_List_PicKeyReleased

 private void List_PicMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_PicMouseReleased
  onSelectedRowChangedListPic(false);
 }//GEN-LAST:event_List_PicMouseReleased

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private XList List_Pic;
 private javax.swing.JPanel Pnl_ListPic;
 private XImgBoxURL Pnl_Pic;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
