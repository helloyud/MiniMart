import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.util.Date;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;

public class F_PaperLabel extends XFormDialog {
 
 OCustomListModel ListMdlPaper;
 int LastSelectedRowPaper;
 final int Dpi=300;
 
 OLabelCreatorTestPrint LabelCreatorTestPrint;
 OLabelDataTestPrint LabelDataTestPrint;
 OCustomComboBoxModel ComboMdlPrinters;
 SpinnerNumberModel SpinMdlMovePrintHeadH;
 SpinnerNumberModel SpinMdlMovePrintHeadV;
 
 public F_PaperLabel(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  ListMdlPaper=new OCustomListModel(false);
  ListMdlPaper.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_PaperLabel.setModel(ListMdlPaper);
  LastSelectedRowPaper=-1;
  
  // panel test print
  LabelCreatorTestPrint=new OLabelCreatorTestPrint(IFV.FontApp, new OFontLayout(8.0f, false, false), IFV.FontLabel, IFV.Conf.StandardPaperMargin, IFV.Conf.ThermalPaperMargin);
  LabelDataTestPrint=new OLabelDataTestPrint(OLabelDataTestPrint.ModeNormal);
  
  ComboMdlPrinters=new OCustomComboBoxModel();
  ComboMdlPrinters.setColumnsInfo(PCore.primArr(CCore.TypeUnknown, CCore.TypeString), 1);
  CmB_Printers.setModel(ComboMdlPrinters);
  
  SpinMdlMovePrintHeadH=new SpinnerNumberModel(0D, -15D, 15D, 0.5D);
  Spin_MovePrintHeadHorizontal.setModel(SpinMdlMovePrintHeadH);
  ((JSpinner.DefaultEditor)Spin_MovePrintHeadHorizontal.getEditor()).getTextField().setEditable(false);
  
  SpinMdlMovePrintHeadV=new SpinnerNumberModel(0D, -15D, 15D, 0.5D);
  Spin_MovePrintHeadVertical.setModel(SpinMdlMovePrintHeadV);
  ((JSpinner.DefaultEditor)Spin_MovePrintHeadVertical.getEditor()).getTextField().setEditable(false);
 }
 public void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    ),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // panel test print
  ComboMdlPrinters.removeAll();
  
  // panel paper
  clearListPaper();
 }
 
 void onSelectedRowListPaperChanged(boolean UpdateAnyway){
  int SelectedRow=List_PaperLabel.getSelectedIndex();
  int Id=0;
  OInfoCustomPaperLabel PaperInfo=null;
  OPaperLabel Papr;
  boolean Fill;
  
  if(LastSelectedRowPaper==SelectedRow && !UpdateAnyway){return;}
  
  LastSelectedRowPaper=SelectedRow;
  
  Fill=false;
  
  do{
   if(SelectedRow==-1){break;}
   Id=(Integer)ListMdlPaper.Mdl.Rows.elementAt(SelectedRow)[0];
   PaperInfo=PMyShop.getCustomPaperLabelInfo(IFV.Stm, Id);
   if(PaperInfo==null){
    JOptionPane.showMessageDialog(null, "Gagal mengambil informasi kertas label dari database !");
    break;
   }
   Fill=true;
  }while(false);
  if(!Fill){
   clearPaperDetail();
   clearPaperPreview();
   return;
  }
  
  
  Papr=PaperInfo.getPaperLabel(false, null, null);
  fillPaperDetail(Papr);
  fillPaperPreview(Papr);
 }
 void fillListPaper(){
  clearListPaper();
  
  PDatabase.queryToList(IFV.Stm, "select Id, Name from CustomPaperLabel order by Name asc;", ListMdlPaper, false, null, -1, false, -1);
 }
 void clearListPaper(){
  ListMdlPaper.removeAll();
  onSelectedRowListPaperChanged(false);
 }
 void fillPaperDetail(OPaperLabel Papr){
  CB_IsThermalRollPaper.setSelected(Papr.IsRollPaper); CB_DrawCutLine.setSelected(Papr.DrawCutLine);
  TF_PaperName.setText(Papr.Name);
  TF_PaperWidth.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.RealWidth))+" mm");
  TF_PaperHeight.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.RealHeight))+" mm");
  TF_MarginLeft.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.RealImageableX))+" mm");
  TF_MarginTop.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.RealImageableY))+" mm");
  TF_LabelWidth.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.LabelWidth))+" mm");
  TF_LabelHeight.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.LabelHeight))+" mm");
  TF_LabelGapHorizontal.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.LabelSpacingHorizontal))+" mm");
  TF_LabelGapVerticalA.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.LabelSpacingVerticalA))+" mm");
  TF_LabelGapVerticalB.setText(PText.priceToString(OUnit.pixel_to_mm(Papr.LabelSpacingVerticalB))+" mm");
  TF_ColumnCount.setText(PText.intToString(Papr.ColumnCount));
  TF_RowCount.setText(PText.intToString(Papr.RowCount));
  TF_LabelCount.setText(PText.intToString(Papr.ColumnCount*Papr.RowCount));
 }
 void clearPaperDetail(){
  CB_IsThermalRollPaper.setSelected(false); CB_DrawCutLine.setSelected(false);
  TF_PaperName.setText("");
  TF_PaperWidth.setText(""); TF_PaperHeight.setText("");
  TF_MarginLeft.setText(""); TF_MarginTop.setText("");
  TF_LabelWidth.setText(""); TF_LabelHeight.setText("");
  TF_LabelGapHorizontal.setText(""); TF_LabelGapVerticalA.setText(""); TF_LabelGapVerticalB.setText("");
  TF_ColumnCount.setText(""); TF_RowCount.setText(""); TF_LabelCount.setText("");
 }
 void fillPaperPreview(OPaperLabel Papr){
  Panel_Img.setImageSource(Papr.getBufferedImage((double)Dpi/(double)72)); Panel_Img.repaint();
 }
 void clearPaperPreview(){
  Panel_Img.setImageSource(null); Panel_Img.repaint();
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }
 
 //
 void focusQueryResult(){
  if(!ListMdlPaper.Mdl.Rows.isEmpty()){
   if(List_PaperLabel.getSelectedIndex()==-1){PGUI.setSelectedRow(List_PaperLabel, 0); onSelectedRowListPaperChanged(false);}
   List_PaperLabel.requestFocusInWindow();
  }
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jPanel2 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  TF_PaperWidth = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  TF_MarginLeft = new javax.swing.JTextField();
  jLabel3 = new javax.swing.JLabel();
  TF_LabelWidth = new javax.swing.JTextField();
  jLabel2 = new javax.swing.JLabel();
  TF_LabelGapHorizontal = new javax.swing.JTextField();
  jLabel4 = new javax.swing.JLabel();
  jLabel7 = new javax.swing.JLabel();
  jLabel8 = new javax.swing.JLabel();
  jLabel9 = new javax.swing.JLabel();
  jLabel10 = new javax.swing.JLabel();
  jLabel11 = new javax.swing.JLabel();
  jLabel12 = new javax.swing.JLabel();
  jLabel13 = new javax.swing.JLabel();
  jLabel14 = new javax.swing.JLabel();
  TF_PaperHeight = new javax.swing.JTextField();
  TF_MarginTop = new javax.swing.JTextField();
  TF_LabelHeight = new javax.swing.JTextField();
  TF_LabelGapVerticalA = new javax.swing.JTextField();
  TF_LabelCount = new javax.swing.JTextField();
  jLabel17 = new javax.swing.JLabel();
  TF_PaperName = new javax.swing.JTextField();
  jLabel18 = new javax.swing.JLabel();
  jPanel1 = new javax.swing.JPanel();
  CB_DrawCutLine = new javax.swing.JCheckBox();
  CB_IsThermalRollPaper = new javax.swing.JCheckBox();
  TF_LabelGapVerticalB = new javax.swing.JTextField();
  jLabel5 = new javax.swing.JLabel();
  TF_RowCount = new javax.swing.JTextField();
  jLabel6 = new javax.swing.JLabel();
  TF_ColumnCount = new javax.swing.JTextField();
  jLabel15 = new javax.swing.JLabel();
  jLabel16 = new javax.swing.JLabel();
  jPanel7 = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  CmB_Printers = new javax.swing.JComboBox<>();
  Lbl_Printer = new javax.swing.JLabel();
  jPanel6 = new javax.swing.JPanel();
  Lbl_MovePrintHead = new javax.swing.JLabel();
  Spin_MovePrintHeadVertical = new javax.swing.JSpinner();
  Lbl_MovePrintHeadHorizontal = new javax.swing.JLabel();
  Spin_MovePrintHeadHorizontal = new javax.swing.JSpinner();
  Lbl_MovePrintHeadVertical = new javax.swing.JLabel();
  jPanel8 = new javax.swing.JPanel();
  Lbl_TestHelp = new javax.swing.JLabel();
  Btn_Test = new javax.swing.JButton();
  jPanel3 = new javax.swing.JPanel();
  Btn_Remove = new javax.swing.JButton();
  Btn_Edit = new javax.swing.JButton();
  Btn_Add = new javax.swing.JButton();
  jScrollPane1 = new javax.swing.JScrollPane();
  List_PaperLabel = new XList();
  Panel_Img = new XImgBoxMemory();

  setTitle("Kustomisasi Kertas Label");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  TF_PaperWidth.setEditable(false);
  TF_PaperWidth.setBackground(new java.awt.Color(204, 255, 204));
  TF_PaperWidth.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  jLabel1.setText("Ukuran Kertas");

  TF_MarginLeft.setEditable(false);
  TF_MarginLeft.setBackground(new java.awt.Color(204, 255, 204));
  TF_MarginLeft.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  jLabel3.setText("Margin Kertas");

  TF_LabelWidth.setEditable(false);
  TF_LabelWidth.setBackground(new java.awt.Color(204, 255, 204));
  TF_LabelWidth.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  jLabel2.setText("Ukuran Label");

  TF_LabelGapHorizontal.setEditable(false);
  TF_LabelGapHorizontal.setBackground(new java.awt.Color(204, 255, 204));
  TF_LabelGapHorizontal.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
  jLabel4.setText("Gap Antar Label");
  jLabel4.setToolTipText("");

  jLabel7.setText("Lebar");

  jLabel8.setText("Kiri");

  jLabel9.setText("Lebar");

  jLabel10.setText("Horizontal");

  jLabel11.setText("Tinggi");

  jLabel12.setText("Atas");

  jLabel13.setText("Tinggi");

  jLabel14.setText("Vertikal-A");

  TF_PaperHeight.setEditable(false);
  TF_PaperHeight.setBackground(new java.awt.Color(204, 255, 204));

  TF_MarginTop.setEditable(false);
  TF_MarginTop.setBackground(new java.awt.Color(204, 255, 204));

  TF_LabelHeight.setEditable(false);
  TF_LabelHeight.setBackground(new java.awt.Color(204, 255, 204));

  TF_LabelGapVerticalA.setEditable(false);
  TF_LabelGapVerticalA.setBackground(new java.awt.Color(204, 255, 204));

  TF_LabelCount.setEditable(false);
  TF_LabelCount.setBackground(new java.awt.Color(204, 255, 204));

  jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel17.setText("Jumlah Label");

  TF_PaperName.setEditable(false);
  TF_PaperName.setBackground(new java.awt.Color(204, 255, 204));

  jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel18.setText("Nama Kertas");

  CB_DrawCutLine.setText("Gambar Garis Potong");
  CB_DrawCutLine.setEnabled(false);
  CB_DrawCutLine.setMargin(new java.awt.Insets(0, 0, 0, 0));

  CB_IsThermalRollPaper.setText("Berjenis Kertas Rol");
  CB_IsThermalRollPaper.setEnabled(false);
  CB_IsThermalRollPaper.setMargin(new java.awt.Insets(0, 0, 0, 0));

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(CB_IsThermalRollPaper)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_DrawCutLine))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_DrawCutLine)
    .addComponent(CB_IsThermalRollPaper))
  );

  TF_LabelGapVerticalB.setEditable(false);
  TF_LabelGapVerticalB.setBackground(new java.awt.Color(204, 255, 204));

  jLabel5.setText("Vertikal-B");

  TF_RowCount.setEditable(false);
  TF_RowCount.setBackground(new java.awt.Color(204, 255, 204));

  jLabel6.setText("Baris");

  TF_ColumnCount.setEditable(false);
  TF_ColumnCount.setBackground(new java.awt.Color(204, 255, 204));

  jLabel15.setText("Kolom");

  jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel16.setText("Kolom & Baris Label");

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_LabelCount)
     .addComponent(TF_PaperName)
     .addGroup(jPanel4Layout.createSequentialGroup()
      .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
       .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_MarginLeft, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_LabelWidth, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_LabelGapHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_ColumnCount, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(TF_PaperWidth, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
       .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_LabelGapVerticalA)
       .addComponent(TF_LabelHeight)
       .addComponent(TF_MarginTop)
       .addComponent(TF_LabelGapVerticalB)
       .addComponent(TF_RowCount)
       .addComponent(TF_PaperHeight)))))
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaperName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel18))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaperWidth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1)
     .addComponent(jLabel7)
     .addComponent(jLabel11)
     .addComponent(TF_PaperHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_MarginLeft, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel3)
     .addComponent(jLabel8)
     .addComponent(jLabel12)
     .addComponent(TF_MarginTop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelWidth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel2)
     .addComponent(jLabel9)
     .addComponent(jLabel13)
     .addComponent(TF_LabelHeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelGapHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel4)
     .addComponent(jLabel10)
     .addComponent(jLabel14)
     .addComponent(TF_LabelGapVerticalA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelGapVerticalB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel5))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_RowCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel6)
     .addComponent(TF_ColumnCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel15)
     .addComponent(jLabel16))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_LabelCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel17)))
  );

  Lbl_Printer.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Printer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_Printer.setText("Printer :");

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(CmB_Printers, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(Lbl_Printer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(Lbl_Printer)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CmB_Printers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Lbl_MovePrintHead.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MovePrintHead.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_MovePrintHead.setText("Geser Print-Head (mm) :");

  Spin_MovePrintHeadVertical.setToolTipText("Geser print-head secara vertikal (atas (-) ... bawah (+)) sepanjang .... mm");

  Lbl_MovePrintHeadHorizontal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MovePrintHeadHorizontal.setText("Hor");

  Spin_MovePrintHeadHorizontal.setToolTipText("Geser print-head secara horizontal (kiri (-) ... kanan (+)) sepanjang .... mm");

  Lbl_MovePrintHeadVertical.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MovePrintHeadVertical.setText("Ver");

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(Lbl_MovePrintHeadHorizontal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Spin_MovePrintHeadHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Lbl_MovePrintHeadVertical)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Spin_MovePrintHeadVertical, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
   .addComponent(Lbl_MovePrintHead, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(Lbl_MovePrintHead)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Spin_MovePrintHeadVertical, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_MovePrintHeadHorizontal)
     .addComponent(Spin_MovePrintHeadHorizontal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_MovePrintHeadVertical)))
  );

  Lbl_TestHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_TestHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_TestHelp.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
  Lbl_TestHelp.setText("(?)");
  Lbl_TestHelp.setToolTipText("Menampilkan penjelasan mengenai Tes Print");
  Lbl_TestHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_TestHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_TestHelpMouseClicked(evt);
   }
  });

  Btn_Test.setText("Tes Print");
  Btn_Test.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Test.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TestActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Lbl_TestHelp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Btn_Test)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(Lbl_TestHelp)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Test))
  );

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
    .addGap(0, 0, 0)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
  );

  Btn_Remove.setText("Hapus {F3}");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  Btn_Edit.setText("Ubah {F2}");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Add.setText("Buat Baru {F1}");
  Btn_Add.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Add.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(Btn_Add)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Edit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Remove))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Remove)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Add))
  );

  List_PaperLabel.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_PaperLabelMouseReleased(evt);
   }
  });
  List_PaperLabel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PaperLabelKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(List_PaperLabel);

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Panel_Img.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(Panel_Img, javax.swing.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Panel_Img, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddActionPerformed
  OValidation Error;
  Long Id=null;
  int updateresult, insertrow;
  OInfoCustomPaperLabel Data;
  Object[] UpdateData;
  
  IFV.FPaperLabelModify.wMode=1;
  
  if(IFV.FPaperLabelModify.showForm()==false){return;}
  if(IFV.FPaperLabelModify.DialogResult!=1){return;}
  
  Data=IFV.FPaperLabelModify.Data;
  Error=new OValidation(false);
  
  do{
   try{
    Id=PDatabase.generateNewId(null, IFV.Stm, "select Id from CustomPaperLabel order by Id asc;");
    if(Id==null){Error.addError("Terjadi error dalam pembuatan Id !"); break;}
    
    try{
     IFV.Stm.executeUpdate(
      "insert into CustomPaperLabel("+
       "Id, Name, IsRollPaper, DrawCutLine, PaperWidth, PaperHeight, MarginLeft, MarginTop, LabelWidth, LabelHeight, LabelGapHorizontal, LabelGapVerticalA, LabelGapVerticalB"+
      ") values("+
       Id+","+"'"+PSql.norm(Data.PaperName)+"'"+","+
       PText.getString(Data.IsRollPaper, CCore.vTrue, CCore.vFalse)+","+PText.getString(Data.DrawCutLine, CCore.vTrue, CCore.vFalse)+","+
       PText.doubleToString(OUnit.pixel_to_mm(Data.PaperWidth), false)+","+PText.doubleToString(OUnit.pixel_to_mm(Data.PaperHeight), false)+","+
       PText.doubleToString(OUnit.pixel_to_mm(Data.MarginLeft), false)+","+PText.doubleToString(OUnit.pixel_to_mm(Data.MarginTop), false)+","+
       PText.doubleToString(OUnit.pixel_to_mm(Data.LabelWidth), false)+","+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelHeight), false)+","+
       PText.doubleToString(OUnit.pixel_to_mm(Data.LabelGapHorizontal), false)+","+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelGapVerticalA), false)+","+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelGapVerticalB), false)+
      ")");
    }
    catch(Exception E){
     Error.addError(
      "Terjadi error dalam operasi penambahan data, mungkin dikarenakan \n"+
      "'Nama Kertas' yg didefenisikan sudah ada / terduplikasi !");
     break;
    }
   }
   catch(Exception E){Error.addError("Terjadi error dalam operasi penambahan data !"); break;}
   Error.setValid(true);
  }while(false);
  if(!Error.getValid()){
   JOptionPane.showMessageDialog(null, Error.getError());
   return;
  }
  
  UpdateData=PCore.objArrVariant(Id.intValue(), Data.PaperName);
  insertrow=PGUI.findInsertPos(ListMdlPaper, 1, Data.PaperName, false, true, true);
  ListMdlPaper.insert(insertrow, UpdateData); List_PaperLabel.setSelectedIndex(insertrow); List_PaperLabel.ensureIndexIsVisible(insertrow);
  onSelectedRowListPaperChanged(true);
 }//GEN-LAST:event_Btn_AddActionPerformed

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  OValidation Error;
  int Id, updateresult, insertrow;
  OInfoCustomPaperLabel Data;
  Object[] UpdateData;
  int[] rows=List_PaperLabel.getSelectedIndices();
  
  if(rows.length==0){return;}
  
  if(rows.length>1){
   JOptionPane.showMessageDialog(null, "Pilihan jamak tidak diperbolehkan untuk operasi ini !");
   return;
  }
  
  UpdateData=ListMdlPaper.Mdl.Rows.elementAt(rows[0]);
  Id=(Integer)UpdateData[0];
  
  Data=PMyShop.getCustomPaperLabelInfo(IFV.Stm, Id);
  if(Data==null){
   JOptionPane.showMessageDialog(null,
    "Tidak dapat melanjutkan karena gagal memperoleh \n"+
    "informasi kertas label dari database !");
   return;
  }
  IFV.FPaperLabelModify.wMode=2;
  IFV.FPaperLabelModify.wData=Data;
  
  if(IFV.FPaperLabelModify.showForm()==false){return;}
  if(IFV.FPaperLabelModify.DialogResult!=1){return;}
  
  Data=IFV.FPaperLabelModify.Data;
  Error=new OValidation(false);
  
  do{
   try{
    try{
     IFV.Stm.executeUpdate(
      "update CustomPaperLabel set "+
       "Name="+"'"+PSql.norm(Data.PaperName)+"'"+","+
       "IsRollPaper="+PText.getString(Data.IsRollPaper, CCore.vTrue, CCore.vFalse)+","+
       "DrawCutLine="+PText.getString(Data.DrawCutLine, CCore.vTrue, CCore.vFalse)+","+
       "PaperWidth="+PText.doubleToString(OUnit.pixel_to_mm(Data.PaperWidth), false)+","+
       "PaperHeight="+PText.doubleToString(OUnit.pixel_to_mm(Data.PaperHeight), false)+","+
       "MarginLeft="+PText.doubleToString(OUnit.pixel_to_mm(Data.MarginLeft), false)+","+
       "MarginTop="+PText.doubleToString(OUnit.pixel_to_mm(Data.MarginTop), false)+","+
       "LabelWidth="+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelWidth), false)+","+
       "LabelHeight="+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelHeight), false)+","+
       "LabelGapHorizontal="+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelGapHorizontal), false)+","+
       "LabelGapVerticalA="+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelGapVerticalA), false)+","+
       "LabelGapVerticalB="+PText.doubleToString(OUnit.pixel_to_mm(Data.LabelGapVerticalB), false)+
      " where Id="+Id);
    }
    catch(Exception E){
     Error.addError(
      "Terjadi error dalam operasi pengubahan data, mungkin dikarenakan \n"+
      "'Nama Kertas' yg didefenisikan sudah ada / terduplikasi !");
     break;
    }
   }
   catch(Exception E){Error.addError("Terjadi error dalam operasi pengubahan data !"); break;}
   Error.setValid(true);
  }while(false);
  if(!Error.getValid()){
   JOptionPane.showMessageDialog(null, Error.getError());
   return;
  }
  
  UpdateData=PCore.objArrVariant(UpdateData[0], Data.PaperName);
  ListMdlPaper.remove(rows[0]);
  insertrow=PGUI.findInsertPos(ListMdlPaper, 1, Data.PaperName, false, true, true);
  ListMdlPaper.insert(insertrow, UpdateData); List_PaperLabel.setSelectedIndex(insertrow); List_PaperLabel.ensureIndexIsVisible(insertrow);
  onSelectedRowListPaperChanged(true);
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  int[] rows=List_PaperLabel.getSelectedIndices();
  int[] removedrows;
  boolean[] IsRemove;
  int temp;
  
  if(rows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+rows.length+" kertas label yg dipilih ?",
   "Konfirmasi Penghapusan Kertas Label", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
   return;
  }
  
  IsRemove=PCore.newBooleanArray(rows.length, false);
  temp=0;
  do{
   if(PDatabase.removeARecord(IFV.Stm, "CustomPaperLabel", (Integer)ListMdlPaper.Mdl.Rows.elementAt(rows[temp])[0])){
    IsRemove[temp]=true;
   }
   temp=temp+1;
  }while(temp!=rows.length);
  removedrows=PGUI.getPickedRows(rows, IsRemove, true);
  
  if(removedrows.length!=0){
   ListMdlPaper.remove(removedrows);
   onSelectedRowListPaperChanged(true);
  }
  if(removedrows.length!=rows.length){
   JOptionPane.showMessageDialog(null, "Gagal menghapus "+(rows.length-removedrows.length)+" kertas label !");
  }
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  int temp;
  
  if(Activ){return;}
  
  Activ=true;
  
  // panel test print
  PPrint.fillPrinters(ComboMdlPrinters);
  temp=PGUI.findString(ComboMdlPrinters, 1, IFV.CurrentReportPrinter.getName());
  if(temp!=-1){CmB_Printers.setSelectedIndex(temp);}
  
  // panel paper
  fillListPaper();
  
  //
  focusQueryResult(); PGUI.requestFocusInWindow(List_PaperLabel);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_TestHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_TestHelpMouseClicked
  if(IFV.FTestPrintInfo.showForm()==false){return;}
 }//GEN-LAST:event_Lbl_TestHelpMouseClicked

 private void Btn_TestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TestActionPerformed
  int[] SelectedPapers=List_PaperLabel.getSelectedIndices();
  Object[] RowData;
  int Id;
  OInfoCustomPaperLabel InfoCustomPaperLabel;
  OPaperLabel PaperLabel;
  Book GenBook;
  OValidation valid;
  
  // check input
   // check input direct return
  if(SelectedPapers.length==0){return;}
  if(SelectedPapers.length>1){JOptionPane.showMessageDialog(null, "Pilihan jamak tidak diperbolehkan untuk operasi ini !"); return;}
  
   // check input indirect return (with information)
  valid=new OValidation(true);
  if(CmB_Printers.getSelectedIndex()==-1){valid.addError("\n- Tidak ada printer yang terpilih.");}
  if(!valid.getValid()){JOptionPane.showMessageDialog(null, "Terdapat masukan yang masih salah !\n"+valid.getError()); return;}
  
  // ask confirmation to perform operation
  RowData=ListMdlPaper.Mdl.Rows.elementAt(SelectedPapers[0]);
  if(JOptionPane.showConfirmDialog(null, "Tes print pada kertas label '"+RowData[1]+"' ?", "Konfirmasi Tes Print",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  // perform operation
  Id=(Integer)RowData[0];
  InfoCustomPaperLabel=PMyShop.getCustomPaperLabelInfo(IFV.Stm, Id);
  if(InfoCustomPaperLabel==null){
   JOptionPane.showMessageDialog(null,
    "Tidak dapat melanjutkan karena gagal memperoleh \n"+
    "informasi kertas label dari database !");
   return;
  }
  
  PaperLabel=InfoCustomPaperLabel.getPaperLabel(CApp.AddPaperSizeTolerance, IFV.Conf.StandardPaperMargin, IFV.Conf.ThermalPaperMargin);
  PaperLabel.changeMoveImageableXY(
   OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadH.getValue(), 0)),
   OUnit.mm_to_pixel(PCore.getValueDouble(SpinMdlMovePrintHeadV.getValue(), 0)));
  IFV.PrintGenLabel.setPrintVariables(PaperLabel, LabelCreatorTestPrint, PPrint.generateTestPrintLabels(PaperLabel, LabelDataTestPrint), 1, 1, PaperLabel.RowCount);
  GenBook=IFV.PrintGenLabel.generateBook(null);
  if(GenBook==null){JOptionPane.showMessageDialog(null, "Tidak dapat mencetak : Gagal membuat data print !"); return;}
  
  do{
   if(PPrint.print(GenBook, (PrintService)ComboMdlPrinters.Mdl.Rows.elementAt(CmB_Printers.getSelectedIndex())[0],
    "TestPrint_"+PText.dateToString(new Date(), 101), true)){break;}
   if(JOptionPane.showConfirmDialog(null, "Tidak dapat mencetak ke printer !\nCoba cetak lagi ?",
    "Konfirmasi Percobaan Pencetakan Ulang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){break;}
  }while(true);
 }//GEN-LAST:event_Btn_TestActionPerformed

 private void List_PaperLabelKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PaperLabelKeyReleased
  onSelectedRowListPaperChanged(false);
 }//GEN-LAST:event_List_PaperLabelKeyReleased

 private void List_PaperLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_PaperLabelMouseReleased
  onSelectedRowListPaperChanged(false);
 }//GEN-LAST:event_List_PaperLabelMouseReleased

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Add;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Test;
 private javax.swing.JCheckBox CB_DrawCutLine;
 private javax.swing.JCheckBox CB_IsThermalRollPaper;
 private javax.swing.JComboBox<String> CmB_Printers;
 private javax.swing.JLabel Lbl_MovePrintHead;
 private javax.swing.JLabel Lbl_MovePrintHeadHorizontal;
 private javax.swing.JLabel Lbl_MovePrintHeadVertical;
 private javax.swing.JLabel Lbl_Printer;
 private javax.swing.JLabel Lbl_TestHelp;
 private XList List_PaperLabel;
 private XImgBoxMemory Panel_Img;
 private javax.swing.JSpinner Spin_MovePrintHeadHorizontal;
 private javax.swing.JSpinner Spin_MovePrintHeadVertical;
 private javax.swing.JTextField TF_ColumnCount;
 private javax.swing.JTextField TF_LabelCount;
 private javax.swing.JTextField TF_LabelGapHorizontal;
 private javax.swing.JTextField TF_LabelGapVerticalA;
 private javax.swing.JTextField TF_LabelGapVerticalB;
 private javax.swing.JTextField TF_LabelHeight;
 private javax.swing.JTextField TF_LabelWidth;
 private javax.swing.JTextField TF_MarginLeft;
 private javax.swing.JTextField TF_MarginTop;
 private javax.swing.JTextField TF_PaperHeight;
 private javax.swing.JTextField TF_PaperName;
 private javax.swing.JTextField TF_PaperWidth;
 private javax.swing.JTextField TF_RowCount;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel12;
 private javax.swing.JLabel jLabel13;
 private javax.swing.JLabel jLabel14;
 private javax.swing.JLabel jLabel15;
 private javax.swing.JLabel jLabel16;
 private javax.swing.JLabel jLabel17;
 private javax.swing.JLabel jLabel18;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
