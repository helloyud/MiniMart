import java.awt.event.ActionEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class F_ConvertingModifyMulti extends XFormDialog{
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeConvDate; Date ConvDate;
 boolean ChangeReasonOfConv; int ReasonOfConvId; String ReasonOfConvName;
 boolean ChangeConvRuleDirection; boolean ConvRuleDirection;
 boolean ChangeConvRuleCount; double ConvRuleCount;

 /**
  * Creates new form F_ItemSupplierModify
  */
 public F_ConvertingModifyMulti(MInterFormVariables IFV_) {
  Date dt;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  RB_ConvRuleDirectionForward.setSelected(true);
  
  dt=new Date();
  PGUI.setDateComponent(dt, TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD);
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_ConvDate, TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD,
    CB_ReasonOfConv, Btn_ChooseReasonOfConv, Btn_ClearChoosedReasonOfConv,
    CB_ConvRuleDirection, RB_ConvRuleDirectionForward, RB_ConvRuleDirectionBackward,
    CB_ConvRuleCount, TF_ConvRuleCount,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  CB_ConvDate.setSelected(false); CB_ConvDate.setForeground(CGUI.Color_Label_InputRight);
  CB_ReasonOfConv.setSelected(false); TF_ReasonOfConv.setText("");
  CB_ConvRuleDirection.setSelected(false);
  CB_ConvRuleCount.setSelected(false); CB_ConvRuleCount.setForeground(CGUI.Color_Label_InputRight); TF_ConvRuleCount.setText("");
  
  clearSetVariables();
 }
 void clearSetVariables(){
  
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_ConvRuleDirection = new javax.swing.ButtonGroup();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_DataCount = new javax.swing.JLabel();
  CmB_ConvDateD = new javax.swing.JComboBox<>();
  CmB_ConvDateM = new javax.swing.JComboBox<>();
  TF_ConvDateY = new javax.swing.JTextField();
  CB_ConvDate = new javax.swing.JCheckBox();
  RB_ConvRuleDirectionForward = new javax.swing.JRadioButton();
  CB_ConvRuleDirection = new javax.swing.JCheckBox();
  RB_ConvRuleDirectionBackward = new javax.swing.JRadioButton();
  CB_ReasonOfConv = new javax.swing.JCheckBox();
  TF_ConvRuleCount = new javax.swing.JTextField();
  CB_ConvRuleCount = new javax.swing.JCheckBox();
  Btn_ClearChoosedReasonOfConv = new javax.swing.JButton();
  Btn_ChooseReasonOfConv = new javax.swing.JButton();
  TF_ReasonOfConv = new javax.swing.JTextField();

  setTitle("Ubah Data Dari Beberapa Konversi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data");

  CmB_ConvDateD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_ConvDateD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ConvDateDKeyPressed(evt);
   }
  });

  CmB_ConvDateM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember" }));
  CmB_ConvDateM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_ConvDateMKeyPressed(evt);
   }
  });

  TF_ConvDateY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ConvDateYFocusGained(evt);
   }
  });
  TF_ConvDateY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ConvDateYKeyPressed(evt);
   }
  });

  CB_ConvDate.setText("Tanggal");
  CB_ConvDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ConvDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ConvDateKeyPressed(evt);
   }
  });

  RG_ConvRuleDirection.add(RB_ConvRuleDirectionForward);
  RB_ConvRuleDirectionForward.setText("A ke B");
  RB_ConvRuleDirectionForward.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ConvRuleDirectionForward.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ConvRuleDirectionForwardKeyPressed(evt);
   }
  });

  CB_ConvRuleDirection.setText("Arah Aturan Konversi");
  CB_ConvRuleDirection.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ConvRuleDirection.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ConvRuleDirectionKeyPressed(evt);
   }
  });

  RG_ConvRuleDirection.add(RB_ConvRuleDirectionBackward);
  RB_ConvRuleDirectionBackward.setText("B ke A");
  RB_ConvRuleDirectionBackward.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ConvRuleDirectionBackward.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ConvRuleDirectionBackwardKeyPressed(evt);
   }
  });

  CB_ReasonOfConv.setText("Alasan");
  CB_ReasonOfConv.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ReasonOfConv.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ReasonOfConvKeyPressed(evt);
   }
  });

  TF_ConvRuleCount.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ConvRuleCountFocusGained(evt);
   }
  });
  TF_ConvRuleCount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ConvRuleCountKeyPressed(evt);
   }
  });

  CB_ConvRuleCount.setText("Jumlah Aturan Konversi");
  CB_ConvRuleCount.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ConvRuleCount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ConvRuleCountKeyPressed(evt);
   }
  });

  Btn_ClearChoosedReasonOfConv.setText("-");
  Btn_ClearChoosedReasonOfConv.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ClearChoosedReasonOfConv.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ClearChoosedReasonOfConvActionPerformed(evt);
   }
  });
  Btn_ClearChoosedReasonOfConv.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ClearChoosedReasonOfConvKeyPressed(evt);
   }
  });

  Btn_ChooseReasonOfConv.setText("...");
  Btn_ChooseReasonOfConv.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseReasonOfConv.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseReasonOfConvActionPerformed(evt);
   }
  });
  Btn_ChooseReasonOfConv.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseReasonOfConvKeyPressed(evt);
   }
  });

  TF_ReasonOfConv.setEditable(false);
  TF_ReasonOfConv.setBackground(new java.awt.Color(204, 255, 204));

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Lbl_DataCount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(178, 178, 178)
      .addComponent(TF_ConvDateY, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_ConvDateM, 0, 245, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_ConvDateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(CB_ConvDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(CB_ReasonOfConv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(CB_ConvRuleCount, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
       .addComponent(CB_ConvRuleDirection, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(RB_ConvRuleDirectionForward)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
        .addComponent(RB_ConvRuleDirectionBackward)
        .addGap(0, 0, Short.MAX_VALUE))
       .addComponent(TF_ConvRuleCount)
       .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
        .addComponent(TF_ReasonOfConv)
        .addGap(0, 0, 0)
        .addComponent(Btn_ChooseReasonOfConv)
        .addGap(3, 3, 3)
        .addComponent(Btn_ClearChoosedReasonOfConv)))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_ConvDateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_ConvDateM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ConvDateY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ConvDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_ReasonOfConv)
     .addComponent(Btn_ClearChoosedReasonOfConv)
     .addComponent(Btn_ChooseReasonOfConv)
     .addComponent(TF_ReasonOfConv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_ConvRuleDirectionForward)
     .addComponent(CB_ConvRuleDirection)
     .addComponent(RB_ConvRuleDirectionBackward))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_ConvRuleCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ConvRuleCount))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)
     .addComponent(Lbl_DataCount))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  
  ReasonOfConvId=-1;
  
  Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data");
  
  PGUI.requestFocusInWindow(Btn_ChooseReasonOfConv);
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  closingForm(0);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrCheck;
  String str;
  
  ChangeConvDate=CB_ConvDate.isSelected();
  ChangeReasonOfConv=CB_ReasonOfConv.isSelected();
  ChangeConvRuleDirection=CB_ConvRuleDirection.isSelected();
  ChangeConvRuleCount=CB_ConvRuleCount.isSelected();
  
  if(!ChangeConvDate && !ChangeReasonOfConv && !ChangeConvRuleDirection && !ChangeConvRuleCount){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  // check inputs validity
  IsValid=true;
  
  if(ChangeConvDate){
   ConvDate=PGUI.valueOfDateComponent(TF_ConvDateY, CmB_ConvDateM, CmB_ConvDateD);
   CurrCheck=ConvDate!=null;
   
   if(!CurrCheck){IsValid=false; CB_ConvDate.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_ConvDate.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeConvRuleDirection){
   ConvRuleDirection=RB_ConvRuleDirectionForward.isSelected();
  }
  
  if(ChangeConvRuleCount){
   str=TF_ConvRuleCount.getText();
   CurrCheck=PText.checkInput(str, false, CCore.CharsCount_Deci(), 6, 6, 6, 7);
   if(CurrCheck){ConvRuleCount=PText.parseDouble(str, -1D, -1D);}
   
   if(!CurrCheck){IsValid=false; CB_ConvRuleCount.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_ConvRuleCount.setForeground(CGUI.Color_Label_InputRight);}
  }
   
  // set get Variables
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !"+
    "\nSilahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_ChooseReasonOfConvKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseReasonOfConvKeyPressed
  PNav.onKey_Btn(this, Btn_ChooseReasonOfConv, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ConvDateY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ConvRuleDirectionForward)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ReasonOfConv)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ClearChoosedReasonOfConv)));
 }//GEN-LAST:event_Btn_ChooseReasonOfConvKeyPressed

 private void Btn_ChooseReasonOfConvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseReasonOfConvActionPerformed
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=false;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblReasonOfConv;
  IFV.FDataIdName.wUseCustomTitle=false;
  
  if(!IFV.FDataIdName.showForm()){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  ReasonOfConvId=(int)IFV.FDataIdName.DataId[0];
  ReasonOfConvName=IFV.FDataIdName.DataName[0];
  TF_ReasonOfConv.setText(ReasonOfConvName);
 }//GEN-LAST:event_Btn_ChooseReasonOfConvActionPerformed

 private void Btn_ClearChoosedReasonOfConvKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedReasonOfConvKeyPressed
  PNav.onKey_Btn(this, Btn_ClearChoosedReasonOfConv, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ConvDateY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(RB_ConvRuleDirectionForward)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ChooseReasonOfConv)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ClearChoosedReasonOfConvKeyPressed

 private void Btn_ClearChoosedReasonOfConvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ClearChoosedReasonOfConvActionPerformed
  ReasonOfConvId=-1;
  TF_ReasonOfConv.setText("");
 }//GEN-LAST:event_Btn_ClearChoosedReasonOfConvActionPerformed

 private void CB_ConvDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ConvDateKeyPressed
  PNav.onKey_CB(this, CB_ConvDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ReasonOfConv)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ConvDateY)));
 }//GEN-LAST:event_CB_ConvDateKeyPressed

 private void TF_ConvDateYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ConvDateYKeyPressed
  PNav.onKey_TF(this, TF_ConvDateY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ChooseReasonOfConv)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ConvDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_ConvDateM)));
 }//GEN-LAST:event_TF_ConvDateYKeyPressed

 private void CmB_ConvDateMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ConvDateMKeyPressed
  PNav.onKey_CmB(this, CmB_ConvDateM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ConvDateY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_ConvDateD)));
 }//GEN-LAST:event_CmB_ConvDateMKeyPressed

 private void CmB_ConvDateDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_ConvDateDKeyPressed
  PNav.onKey_CmB(this, CmB_ConvDateD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_ConvDateM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseReasonOfConv)));
 }//GEN-LAST:event_CmB_ConvDateDKeyPressed

 private void CB_ReasonOfConvKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ReasonOfConvKeyPressed
  PNav.onKey_CB(this, CB_ReasonOfConv, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ConvDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ConvRuleDirection)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseReasonOfConv)));
 }//GEN-LAST:event_CB_ReasonOfConvKeyPressed

 private void CB_ConvRuleDirectionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ConvRuleDirectionKeyPressed
  PNav.onKey_CB(this, CB_ConvRuleDirection, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ReasonOfConv)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_ConvRuleCount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ConvRuleDirectionForward)));
 }//GEN-LAST:event_CB_ConvRuleDirectionKeyPressed

 private void RB_ConvRuleDirectionForwardKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ConvRuleDirectionForwardKeyPressed
  PNav.onKey_RB(this, RB_ConvRuleDirectionForward, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseReasonOfConv)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ConvRuleCount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ConvRuleDirection)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ConvRuleDirectionBackward)));
 }//GEN-LAST:event_RB_ConvRuleDirectionForwardKeyPressed

 private void RB_ConvRuleDirectionBackwardKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ConvRuleDirectionBackwardKeyPressed
  PNav.onKey_RB(this, RB_ConvRuleDirectionBackward, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ChooseReasonOfConv)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_ConvRuleCount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ConvRuleDirectionForward)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_RB_ConvRuleDirectionBackwardKeyPressed

 private void CB_ConvRuleCountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ConvRuleCountKeyPressed
  PNav.onKey_CB(this, CB_ConvRuleCount, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ConvRuleDirection)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_ConvRuleCount)));
 }//GEN-LAST:event_CB_ConvRuleCountKeyPressed

 private void TF_ConvRuleCountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ConvRuleCountKeyPressed
  PNav.onKey_TF(this, TF_ConvRuleCount, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ConvRuleDirectionForward)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_ConvRuleCount)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_ConvRuleCountKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ConvRuleCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_ConvRuleCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_ConvDateYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ConvDateYFocusGained
  PGUI.text_SelectAll(TF_ConvDateY);
 }//GEN-LAST:event_TF_ConvDateYFocusGained

 private void TF_ConvRuleCountFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ConvRuleCountFocusGained
  PGUI.text_SelectAll(TF_ConvRuleCount);
 }//GEN-LAST:event_TF_ConvRuleCountFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseReasonOfConv;
 private javax.swing.JButton Btn_ClearChoosedReasonOfConv;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_ConvDate;
 private javax.swing.JCheckBox CB_ConvRuleCount;
 private javax.swing.JCheckBox CB_ConvRuleDirection;
 private javax.swing.JCheckBox CB_ReasonOfConv;
 private javax.swing.JComboBox<String> CmB_ConvDateD;
 private javax.swing.JComboBox<String> CmB_ConvDateM;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.JRadioButton RB_ConvRuleDirectionBackward;
 private javax.swing.JRadioButton RB_ConvRuleDirectionForward;
 private javax.swing.ButtonGroup RG_ConvRuleDirection;
 private javax.swing.JTextField TF_ConvDateY;
 private javax.swing.JTextField TF_ConvRuleCount;
 private javax.swing.JTextField TF_ReasonOfConv;
 // End of variables declaration//GEN-END:variables
}
