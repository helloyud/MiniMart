import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_User extends XFormDialog {
 
 // List User
 OCustomListModel ListMdlUser;
 int UserLastRowSelected;
 
 // List Db
 OCustomListModel ListMdlDb;
 int DbLastRowSelected;
 
 boolean Filled;
 boolean FilledDb;
 
 // Other Var
 
 
 /**
  * Creates new form F_User
  */
 public F_User(MInterFormVariables IFV_) {
  int[] ColType;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  ListMdlUser=new OCustomListModel(false);
  ColType=new int[1];
  ColType[0]=1;
  ListMdlUser.setColumnsInfo(ColType, 0);
  List_User.setModel(ListMdlUser);
  UserLastRowSelected=-1;
  
  ListMdlDb=new OCustomListModel(false);
  ColType=new int[2];
  ColType[0]=CCore.TypeString;
  ColType[1]=CCore.TypeString;
  ListMdlDb.setColumnsInfo(ColType, 0);
  List_Db.setModel(ListMdlDb);
  DbLastRowSelected=-1;
  
  Filled=false;
  FilledDb=false;
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    List_User, Btn_UserAdd, Btn_UserReset, Btn_UserRemove,
    Btn_AdminAdd, Btn_DbEdit, List_Db),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_UserAddActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_UserRemoveActionPerformed(null);
    }
   });
  
  // f4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0, true), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_UserResetActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  ListMdlUser.removeAll();
  UserLastRowSelected=-1;
  
  ListMdlDb.removeAll();
  DbLastRowSelected=-1;
  
  clearAccess(false);
 }
 
 void onListUserChangeSelection(boolean UpdateAnyway){
  int row=List_User.getSelectedIndex();
  if(row!=UserLastRowSelected || UpdateAnyway){
   UserLastRowSelected=row;
   if(row!=-1){fillAccess((String)ListMdlUser.Mdl.Rows.elementAt(row)[0]);}
   else{clearAccess(false);}
  }
 }
 void fillAccess(String User){
  boolean bool;
  int temp, rowdb;
  bool=false;
  do{
   if(fillAccessLocation(User)==false){break;}
   
   temp=PDatabaseUser.hasAdminPrivilleges(IFV.Stm, User);
   if(temp==-1){break;}
   CB_Admin.setSelected(temp==1);
   
   rowdb=List_Db.getSelectedIndex();
   if(rowdb!=-1){
    fillAccessDb(User, (String)ListMdlDb.Mdl.Rows.elementAt(rowdb)[0]);
   }
   else{clearAccessDb();}
   
   bool=true;
  }while(false);
  if(bool){
   Filled=true;
  }
  else{
   clearAccess(true);
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam mengambil daftar ijin akses !");
  }
 }
 void clearAccess(boolean ClearAnyway){
  if(Filled || ClearAnyway){
   clearAccessLocation();
   CB_Admin.setSelected(false);
   clearAccessDb();
   Filled=false;
  }
 }
 
 void onListDbChangeSelection(boolean UpdateAnyway){
  int row=List_Db.getSelectedIndex();
  int rowuser;
  if(row!=DbLastRowSelected || UpdateAnyway){
   DbLastRowSelected=row;
   rowuser=List_User.getSelectedIndex();
   if(row!=-1 && rowuser!=-1){fillAccessDb((String)ListMdlUser.Mdl.Rows.elementAt(rowuser)[0], (String)ListMdlDb.Mdl.Rows.elementAt(row)[0]);}
   else{clearAccessDb();}
  }
 }
 void fillAccessDb(String User, String Db){
  boolean[] result=PDatabaseUser.getDatabasePrivilleges(IFV.Stm, User, Db, false, true);
  if(result!=null){
   CB_DbSelect.setSelected(result[0]);
   CB_DbItem.setSelected(result[1]);
   CB_DbItemPrivate.setSelected(result[2]);
   CB_DbSubject.setSelected(result[3]);
   CB_DbSubjectPrivate.setSelected(result[4]);
   CB_DbTrans.setSelected(result[5]);
   CB_DbTransPrivate.setSelected(result[6]);
   CB_DbPreTrans.setSelected(result[7]);
   CB_DbPreTransPrivate.setSelected(result[8]);
   FilledDb=true;
  }
  else{
   clearAccessDb();
   JOptionPane.showMessageDialog(null, "terjadi kegagalan dlm mengambil daftar ijin akses pd suatu database !");
  }
 }
 void clearAccessDb(){
  if(FilledDb){
   CB_DbSelect.setSelected(false);
   CB_DbItem.setSelected(false);
   CB_DbItemPrivate.setSelected(false);
   CB_DbSubject.setSelected(false);
   CB_DbSubjectPrivate.setSelected(false);
   CB_DbTrans.setSelected(false);
   CB_DbTransPrivate.setSelected(false);
   CB_DbPreTrans.setSelected(false);
   CB_DbPreTransPrivate.setSelected(false);
   FilledDb=false;
  }
 }
 boolean fillAccessLocation(String User){
  boolean ret=false;
  boolean[] result=PDatabaseUser.checkAccessLocation(IFV.Stm, User);
  if(result!=null){
   CB_HostLocal.setSelected(result[0]);
   CB_HostRemote.setSelected(result[1]);
   ret=true;
  }
  return ret;
 }
 void clearAccessLocation(){
  CB_HostLocal.setSelected(false);
  CB_HostRemote.setSelected(false);
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, false);
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  Lbl_ListUser = new javax.swing.JLabel();
  Btn_UserAdd = new javax.swing.JButton();
  Btn_UserReset = new javax.swing.JButton();
  Btn_UserRemove = new javax.swing.JButton();
  Panel_Admin = new javax.swing.JPanel();
  Btn_AdminAdd = new javax.swing.JButton();
  Lbl_Admin = new javax.swing.JLabel();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_Admin = new javax.swing.JTextArea();
  CB_Admin = new javax.swing.JCheckBox();
  Panel_Db = new javax.swing.JPanel();
  Lbl_Db = new javax.swing.JLabel();
  Btn_DbEdit = new javax.swing.JButton();
  Panel_DbAccess = new javax.swing.JPanel();
  CB_DbItem = new javax.swing.JCheckBox();
  CB_DbSubject = new javax.swing.JCheckBox();
  CB_DbSelect = new javax.swing.JCheckBox();
  CB_DbTrans = new javax.swing.JCheckBox();
  CB_DbTransPrivate = new javax.swing.JCheckBox();
  CB_DbItemPrivate = new javax.swing.JCheckBox();
  CB_DbSubjectPrivate = new javax.swing.JCheckBox();
  CB_DbPreTrans = new javax.swing.JCheckBox();
  CB_DbPreTransPrivate = new javax.swing.JCheckBox();
  jScrollPane3 = new javax.swing.JScrollPane();
  List_Db = new XList();
  Panel_Host = new javax.swing.JPanel();
  CB_HostLocal = new javax.swing.JCheckBox();
  CB_HostRemote = new javax.swing.JCheckBox();
  Lbl_Host = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  List_User = new XList();

  setTitle("Kelola User MySQL Dan Perijinan Akses");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Lbl_ListUser.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ListUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_ListUser.setText("Daftar User MySQL");

  Btn_UserAdd.setText("Buat Baru {F1}");
  Btn_UserAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_UserAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_UserAddActionPerformed(evt);
   }
  });
  Btn_UserAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_UserAddKeyPressed(evt);
   }
  });

  Btn_UserReset.setText("Reset Password {F4}");
  Btn_UserReset.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_UserReset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_UserResetActionPerformed(evt);
   }
  });
  Btn_UserReset.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_UserResetKeyPressed(evt);
   }
  });

  Btn_UserRemove.setText("Hapus {F3}");
  Btn_UserRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_UserRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_UserRemoveActionPerformed(evt);
   }
  });
  Btn_UserRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_UserRemoveKeyPressed(evt);
   }
  });

  Panel_Admin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

  Btn_AdminAdd.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_AdminAdd.setText("Beri");
  Btn_AdminAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AdminAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AdminAddActionPerformed(evt);
   }
  });
  Btn_AdminAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AdminAddKeyPressed(evt);
   }
  });

  Lbl_Admin.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Admin.setText("- - - Kewenangan Admin");

  TA_Admin.setEditable(false);
  TA_Admin.setBackground(new java.awt.Color(204, 255, 204));
  TA_Admin.setColumns(20);
  TA_Admin.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
  TA_Admin.setLineWrap(true);
  TA_Admin.setRows(1);
  TA_Admin.setText("- Admin memiliki semua ijin akses.\n- Mengelola user MySQL.\n- Mengelola database.\n- Melakukan pemulihan database.");
  TA_Admin.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_Admin);

  CB_Admin.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_Admin.setText("Aktif");
  CB_Admin.setContentAreaFilled(false);
  CB_Admin.setEnabled(false);
  CB_Admin.setMargin(new java.awt.Insets(0, 0, 0, 0));

  javax.swing.GroupLayout Panel_AdminLayout = new javax.swing.GroupLayout(Panel_Admin);
  Panel_Admin.setLayout(Panel_AdminLayout);
  Panel_AdminLayout.setHorizontalGroup(
   Panel_AdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_AdminLayout.createSequentialGroup()
    .addComponent(Lbl_Admin)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_Admin)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
    .addComponent(Btn_AdminAdd))
   .addComponent(jScrollPane5)
  );
  Panel_AdminLayout.setVerticalGroup(
   Panel_AdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_AdminLayout.createSequentialGroup()
    .addGroup(Panel_AdminLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_AdminAdd)
     .addComponent(Lbl_Admin)
     .addComponent(CB_Admin))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE))
  );

  Panel_Db.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

  Lbl_Db.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Db.setText("- - - Ijin Akses Pd Suatu 'Database'");

  Btn_DbEdit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_DbEdit.setText("Ubah");
  Btn_DbEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_DbEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_DbEditActionPerformed(evt);
   }
  });
  Btn_DbEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_DbEditKeyPressed(evt);
   }
  });

  Panel_DbAccess.setBackground(new java.awt.Color(204, 255, 204));
  Panel_DbAccess.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

  CB_DbItem.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbItem.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbItem.setText("Mengelola Data Barang");
  CB_DbItem.setContentAreaFilled(false);
  CB_DbItem.setEnabled(false);

  CB_DbSubject.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbSubject.setText("Mengelola Data Subjek");
  CB_DbSubject.setContentAreaFilled(false);
  CB_DbSubject.setEnabled(false);

  CB_DbSelect.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbSelect.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbSelect.setText("Melihat Data");
  CB_DbSelect.setContentAreaFilled(false);
  CB_DbSelect.setEnabled(false);

  CB_DbTrans.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbTrans.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbTrans.setText("Mengelola Transaksi");
  CB_DbTrans.setContentAreaFilled(false);
  CB_DbTrans.setEnabled(false);

  CB_DbTransPrivate.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbTransPrivate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbTransPrivate.setText("+ Privasi");
  CB_DbTransPrivate.setToolTipText("");
  CB_DbTransPrivate.setContentAreaFilled(false);
  CB_DbTransPrivate.setEnabled(false);

  CB_DbItemPrivate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbItemPrivate.setText("+ Privasi");
  CB_DbItemPrivate.setContentAreaFilled(false);
  CB_DbItemPrivate.setEnabled(false);

  CB_DbSubjectPrivate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbSubjectPrivate.setText("+ Privasi");
  CB_DbSubjectPrivate.setContentAreaFilled(false);
  CB_DbSubjectPrivate.setEnabled(false);

  CB_DbPreTrans.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbPreTrans.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbPreTrans.setText("Mengelola PraTransaksi");
  CB_DbPreTrans.setEnabled(false);

  CB_DbPreTransPrivate.setBackground(new java.awt.Color(204, 255, 204));
  CB_DbPreTransPrivate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_DbPreTransPrivate.setText("+ Privasi");
  CB_DbPreTransPrivate.setEnabled(false);

  javax.swing.GroupLayout Panel_DbAccessLayout = new javax.swing.GroupLayout(Panel_DbAccess);
  Panel_DbAccess.setLayout(Panel_DbAccessLayout);
  Panel_DbAccessLayout.setHorizontalGroup(
   Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DbAccessLayout.createSequentialGroup()
    .addGroup(Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_DbAccessLayout.createSequentialGroup()
      .addComponent(CB_DbSubject)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_DbSubjectPrivate))
     .addGroup(Panel_DbAccessLayout.createSequentialGroup()
      .addComponent(CB_DbItem)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_DbItemPrivate))
     .addComponent(CB_DbSelect)
     .addGroup(Panel_DbAccessLayout.createSequentialGroup()
      .addComponent(CB_DbTrans)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_DbTransPrivate))
     .addGroup(Panel_DbAccessLayout.createSequentialGroup()
      .addComponent(CB_DbPreTrans)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(CB_DbPreTransPrivate)))
    .addContainerGap(74, Short.MAX_VALUE))
  );
  Panel_DbAccessLayout.setVerticalGroup(
   Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DbAccessLayout.createSequentialGroup()
    .addComponent(CB_DbSelect)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_DbItem)
     .addComponent(CB_DbItemPrivate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_DbSubject)
     .addComponent(CB_DbSubjectPrivate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_DbPreTrans)
     .addComponent(CB_DbPreTransPrivate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Panel_DbAccessLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_DbTrans)
     .addComponent(CB_DbTransPrivate)))
  );

  List_Db.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
  List_Db.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_DbMouseReleased(evt);
   }
  });
  List_Db.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_DbKeyReleased(evt);
   }
  });
  jScrollPane3.setViewportView(List_Db);

  javax.swing.GroupLayout Panel_DbLayout = new javax.swing.GroupLayout(Panel_Db);
  Panel_Db.setLayout(Panel_DbLayout);
  Panel_DbLayout.setHorizontalGroup(
   Panel_DbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_DbLayout.createSequentialGroup()
    .addComponent(Lbl_Db)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_DbEdit))
   .addComponent(Panel_DbAccess, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  Panel_DbLayout.setVerticalGroup(
   Panel_DbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addGroup(Panel_DbLayout.createSequentialGroup()
    .addGroup(Panel_DbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_DbEdit)
     .addComponent(Lbl_Db))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(Panel_DbAccess, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Panel_Host.setBackground(new java.awt.Color(204, 255, 204));
  Panel_Host.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

  CB_HostLocal.setBackground(new java.awt.Color(204, 255, 204));
  CB_HostLocal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_HostLocal.setText("Server");
  CB_HostLocal.setContentAreaFilled(false);
  CB_HostLocal.setEnabled(false);

  CB_HostRemote.setBackground(new java.awt.Color(204, 255, 204));
  CB_HostRemote.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_HostRemote.setText("Lain");
  CB_HostRemote.setContentAreaFilled(false);
  CB_HostRemote.setEnabled(false);

  Lbl_Host.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Host.setText("Dapat mengakses di komputer :");
  Lbl_Host.setToolTipText("");

  javax.swing.GroupLayout Panel_HostLayout = new javax.swing.GroupLayout(Panel_Host);
  Panel_Host.setLayout(Panel_HostLayout);
  Panel_HostLayout.setHorizontalGroup(
   Panel_HostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_HostLayout.createSequentialGroup()
    .addComponent(Lbl_Host)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(CB_HostLocal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_HostRemote)
    .addContainerGap(10, Short.MAX_VALUE))
  );
  Panel_HostLayout.setVerticalGroup(
   Panel_HostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_HostLayout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addGroup(Panel_HostLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_HostLocal)
     .addComponent(CB_HostRemote)
     .addComponent(Lbl_Host)))
  );

  List_User.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
  List_User.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_UserMouseReleased(evt);
   }
  });
  List_User.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_UserKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(List_User);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Btn_UserAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
      .addComponent(Btn_UserReset)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_UserRemove))
     .addComponent(Lbl_ListUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jScrollPane1))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Panel_Admin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Panel_Host, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Panel_Db, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_ListUser)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(jScrollPane1)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
       .addComponent(Btn_UserAdd)
       .addComponent(Btn_UserReset)
       .addComponent(Btn_UserRemove)))
     .addGroup(layout.createSequentialGroup()
      .addComponent(Panel_Host, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Panel_Admin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Panel_Db, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_UserAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_UserAddActionPerformed
  int temp, length;
  Object[] NewData;
  String usr;
  int insertpos;
  IFV.FUserModify.wMode=1;
  
  if(IFV.FUserModify.showForm()==false){return;}
  if(IFV.FUserModify.DialogResult!=1){return;}
  usr=IFV.FUserModify.User;
  if(PDatabaseUser.createUser(IFV.Stm, usr, IFV.FUserModify.UserPassword)==0){
   JOptionPane.showMessageDialog(null, "Gagal membuat user !"+
    "\nMungkin dikarenakan nama user sudah ada.");
   return;
  }
  // searching if user has exist or not in the user list
  length=ListMdlUser.Mdl.Rows.size();
  temp=0;
  if(length!=0){
   do{
    if(PText.compare(usr, (String)ListMdlUser.Mdl.Rows.elementAt(temp)[0], false)){break;}
    temp=temp+1;
   }while(temp!=length);
  }
  //
  insertpos=temp;
  if(temp==length){
   NewData=new Object[1];
   NewData[0]=IFV.FUserModify.User;
   insertpos=PGUI.findInsertPos(ListMdlUser, 0, IFV.FUserModify.User, false, true, true);
   ListMdlUser.insert(insertpos, NewData);
  }
  List_User.setSelectedIndex(insertpos); List_User.ensureIndexIsVisible(insertpos); onListUserChangeSelection(true);
 }//GEN-LAST:event_Btn_UserAddActionPerformed

 private void Btn_UserResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_UserResetActionPerformed
  int row=List_User.getSelectedIndex();
  String User;
  if(row!=-1){
   User=(String)ListMdlUser.Mdl.Rows.elementAt(row)[0];
   if(PText.compare(User, IFV.CurrentUser, false)){
    JOptionPane.showMessageDialog(null, "Maaf, tidak dapat 'menghapus' atau 'meng-reset password' pada 'User Saat Ini' !");
    return;
   }
   IFV.FUserModify.wMode=2;
   IFV.FUserModify.wUser=User;
   
   if(IFV.FUserModify.showForm()==false){return;}
   if(IFV.FUserModify.DialogResult==1){
    if(PDatabaseUser.changePassword(IFV.Stm, User, IFV.FUserModify.UserPassword)<=0){
     JOptionPane.showMessageDialog(null, "Gagal mengubah password !");
    }
   }
  }
 }//GEN-LAST:event_Btn_UserResetActionPerformed

 private void Btn_UserRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_UserRemoveActionPerformed
  int row=List_User.getSelectedIndex();
  String usr;
  if(row==-1){return;}
  usr=(String)ListMdlUser.Mdl.Rows.elementAt(row)[0];
  if(PText.compare(usr, IFV.CurrentUser, false)){
   JOptionPane.showMessageDialog(null, "Maaf, tidak dapat 'menghapus' atau 'meng-reset password' pada 'User Saat Ini' !");
   return;
  }
  if(PText.compare(usr, "root", false)){
   JOptionPane.showMessageDialog(null, "Maaf, user 'root' tidak dapat dihapus !");
   return;
  }
  if(JOptionPane.showConfirmDialog(null, "Hapus user '"+usr+"' ?",
   "Konfirmasi Penghapusan User", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  if(PDatabaseUser.dropUser(IFV.Stm, usr)==0){JOptionPane.showMessageDialog(null, "Gagal menghapus user !"); return;}
  ListMdlUser.remove(row);
  onListUserChangeSelection(true);
 }//GEN-LAST:event_Btn_UserRemoveActionPerformed

 private void Btn_AdminAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AdminAddActionPerformed
  int row=List_User.getSelectedIndex();
  String usr;
  if(row==-1){return;}
  usr=(String)ListMdlUser.Mdl.Rows.elementAt(row)[0];
  if(JOptionPane.showConfirmDialog(null, "Beri kewenangan admin pada user '"+usr+"' ?",
   "Konfirmasi pemberian kewenangan admin pd seorang user", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  if(PDatabaseUser.grantAdminPrivilleges(IFV.Stm, usr)==0){
   JOptionPane.showMessageDialog(null, "Gagal memberi kewenangan admin pd user !");
   return;
  }
  CB_Admin.setSelected(true);
  
  if(PText.compare(usr, IFV.CurrentUser, false)){IFV.fillCurrentUserIsAdmin();}
 }//GEN-LAST:event_Btn_AdminAddActionPerformed

 private void Btn_DbEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_DbEditActionPerformed
  boolean bool, selected;
  int rowuser, rowdb;
  String usr, db;
  rowuser=List_User.getSelectedIndex();
  rowdb=List_Db.getSelectedIndex();
  if(rowuser==-1 || rowdb==-1){return;}
  usr=(String)ListMdlUser.Mdl.Rows.elementAt(rowuser)[0];
  db=(String)ListMdlDb.Mdl.Rows.elementAt(rowdb)[0];
  IFV.FUserDbPerm.wUser=usr;
  IFV.FUserDbPerm.wDatabase=db;
  IFV.FUserDbPerm.wSelect=CB_DbSelect.isSelected();
  IFV.FUserDbPerm.wItem=CB_DbItem.isSelected();
  IFV.FUserDbPerm.wItemPrivate=CB_DbItemPrivate.isSelected();
  IFV.FUserDbPerm.wSubject=CB_DbSubject.isSelected();
  IFV.FUserDbPerm.wSubjectPrivate=CB_DbSubjectPrivate.isSelected();
  IFV.FUserDbPerm.wTrans=CB_DbTrans.isSelected();
  IFV.FUserDbPerm.wTransPrivate=CB_DbTransPrivate.isSelected();
  IFV.FUserDbPerm.wPreTrans=CB_DbPreTrans.isSelected();
  IFV.FUserDbPerm.wPreTransPrivate=CB_DbPreTransPrivate.isSelected();
  
  if(IFV.FUserDbPerm.showForm()==false){return;}
  if(IFV.FUserDbPerm.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Mengubah Ijin Akses Database");
  
  IFV.FSplashScreen.inform(0, "Sedang memproses (harap menunggu)...", "-");
  
  bool=true;
  
  selected=IFV.FUserDbPerm.Select;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 0, false)==false){bool=false;}
  else{CB_DbSelect.setSelected(selected);}
  
  IFV.FSplashScreen.inform(20, null, null);
  
  selected=IFV.FUserDbPerm.Item;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 1, false)==false){bool=false;}
  else{CB_DbItem.setSelected(selected);}
  
  selected=IFV.FUserDbPerm.ItemPrivate;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 2, false)==false){bool=false;}
  else{CB_DbItemPrivate.setSelected(selected);}
  
  IFV.FSplashScreen.inform(20, null, null);
  
  selected=IFV.FUserDbPerm.Subject;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 3, false)==false){bool=false;}
  else{CB_DbSubject.setSelected(selected);}
  
  selected=IFV.FUserDbPerm.SubjectPrivate;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 4, false)==false){bool=false;}
  else{CB_DbSubjectPrivate.setSelected(selected);}
  
  IFV.FSplashScreen.inform(20, null, null);
  
  selected=IFV.FUserDbPerm.Trans;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 5, false)==false){bool=false;}
  else{CB_DbTrans.setSelected(selected);}
  
  selected=IFV.FUserDbPerm.TransPrivate;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 6, false)==false){bool=false;}
  else{CB_DbTransPrivate.setSelected(selected);}
  
  IFV.FSplashScreen.inform(20, null, null);
  
  selected=IFV.FUserDbPerm.PreTrans;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 7, false)==false){bool=false;}
  else{CB_DbPreTrans.setSelected(selected);}
  
  selected=IFV.FUserDbPerm.PreTransPrivate;
  if(PDatabaseUser.grantDatabasePrivilleges(IFV.Stm, selected, usr, db, 8, false)==false){bool=false;}
  else{CB_DbPreTransPrivate.setSelected(selected);}
  
  IFV.FSplashScreen.inform(20, null, null);
  
  IFV.FSplashScreen.disappear();
  
  if(!bool){
   JOptionPane.showMessageDialog(null, "Terdapat kegagalan dalam mengubah ijin akses user pada database !");
  }
  
  if(PText.compare(usr, IFV.CurrentUser, false)){
   IFV.fillCurrentUserPrivDb();
  }
 }//GEN-LAST:event_Btn_DbEditActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean bool;
  if(!Activ){
   Activ=true;
   
   bool=true;
   // fill list user
   if(PDatabase.queryToList(IFV.Stm,
    "select user from mysql.user where (user<>'' and user is not "+CCore.vNull+") group by user order by user asc;",
    ListMdlUser, false, null, -1, false, -1)==-1){
    bool=false;
   }
   // fill list db
   if(PDatabaseApp.queryDatabaseToModel(IFV.Stm, ListMdlDb)==-1){
    bool=false;
   }
   
   if(bool){
    if(ListMdlDb.Mdl.Rows.size()!=0){
     List_Db.setSelectedIndex(0);
     onListDbChangeSelection(false);
    }
    if(ListMdlUser.Mdl.Rows.size()!=0){
     List_User.setSelectedIndex(0);
     onListUserChangeSelection(false);
    }
    PGUI.requestFocusInWindow(List_User);
   }
   else{
    clearComponents();
    JOptionPane.showMessageDialog(null, "Terjadi kegagalan dlm mengambil daftar user atau database !");
   }
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void List_UserKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_UserKeyReleased
  onListUserChangeSelection(false);
  
  int consumed=PNav.onKey_List(this, List_User, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_UserAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_AdminAdd)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_List_UserKeyReleased

 private void List_UserMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_UserMouseReleased
  onListUserChangeSelection(false);
 }//GEN-LAST:event_List_UserMouseReleased

 private void List_DbKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_DbKeyReleased
  onListDbChangeSelection(false);
  
  int consumed=PNav.onKey_List(this, List_Db, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_DbEdit)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_User)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_List_DbKeyReleased

 private void List_DbMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_DbMouseReleased
  onListDbChangeSelection(false);
 }//GEN-LAST:event_List_DbMouseReleased

 private void Btn_UserAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_UserAddKeyPressed
  PNav.onKey_Btn(this, Btn_UserAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_User)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_UserReset)));
 }//GEN-LAST:event_Btn_UserAddKeyPressed

 private void Btn_UserResetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_UserResetKeyPressed
  PNav.onKey_Btn(this, Btn_UserReset, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_User)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_UserAdd)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_UserRemove)));
 }//GEN-LAST:event_Btn_UserResetKeyPressed

 private void Btn_UserRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_UserRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_UserRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_User)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_UserReset)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_UserRemoveKeyPressed

 private void Btn_AdminAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AdminAddKeyPressed
  PNav.onKey_Btn(this, Btn_AdminAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_DbEdit)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_User)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_AdminAddKeyPressed

 private void Btn_DbEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_DbEditKeyPressed
  PNav.onKey_Btn(this, Btn_DbEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_AdminAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Db)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_User)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_DbEditKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_AdminAdd;
 private javax.swing.JButton Btn_DbEdit;
 private javax.swing.JButton Btn_UserAdd;
 private javax.swing.JButton Btn_UserRemove;
 private javax.swing.JButton Btn_UserReset;
 private javax.swing.JCheckBox CB_Admin;
 private javax.swing.JCheckBox CB_DbItem;
 private javax.swing.JCheckBox CB_DbItemPrivate;
 private javax.swing.JCheckBox CB_DbPreTrans;
 private javax.swing.JCheckBox CB_DbPreTransPrivate;
 private javax.swing.JCheckBox CB_DbSelect;
 private javax.swing.JCheckBox CB_DbSubject;
 private javax.swing.JCheckBox CB_DbSubjectPrivate;
 private javax.swing.JCheckBox CB_DbTrans;
 private javax.swing.JCheckBox CB_DbTransPrivate;
 private javax.swing.JCheckBox CB_HostLocal;
 private javax.swing.JCheckBox CB_HostRemote;
 private javax.swing.JLabel Lbl_Admin;
 private javax.swing.JLabel Lbl_Db;
 private javax.swing.JLabel Lbl_Host;
 private javax.swing.JLabel Lbl_ListUser;
 private XList List_Db;
 private XList List_User;
 private javax.swing.JPanel Panel_Admin;
 private javax.swing.JPanel Panel_Db;
 private javax.swing.JPanel Panel_DbAccess;
 private javax.swing.JPanel Panel_Host;
 private javax.swing.JTextArea TA_Admin;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane5;
 // End of variables declaration//GEN-END:variables
}
