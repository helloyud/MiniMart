import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public abstract class OAction extends AbstractAction {
 
 public void actionPerformed(ActionEvent e) {}
 
}