import java.awt.image.BufferedImage;

public class XImgBoxMemory extends XImgBox {
 
 BufferedImage MemImg;
 
 public void setImageSource(BufferedImage MemImg){
  this.MemImg=MemImg;
  
  updateImageSource();
  updateImgSizeAndPosition(true);
 }
 protected boolean isImageSourceAvailable(){
  return MemImg!=null;
 }
 protected BufferedImage readImageSource(){
  return MemImg;
 }

}