import java.util.Date;

public class OApplicationVersion {
 
 Date RevisiDate;
 String RevisiDate_Variant;

 public OApplicationVersion(Date RevisiDate, String RevisiDate_Variant) {
  this.RevisiDate = RevisiDate;
  this.RevisiDate_Variant = RevisiDate_Variant;
 }
 
 public String toString(){
  StringBuilder ret=new StringBuilder();
  
  ret.append(PText.dateToString(RevisiDate, 3));
  ret.append("-");
  ret.append(RevisiDate_Variant);
  
  return ret.toString();
 }
 
}