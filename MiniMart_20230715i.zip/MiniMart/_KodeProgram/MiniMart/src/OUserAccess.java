public class OUserAccess {

 String User;
 boolean[] Access;

 public OUserAccess(String User, boolean[] Access) {
  this.User = User;
  this.Access = Access;
 }
 
}