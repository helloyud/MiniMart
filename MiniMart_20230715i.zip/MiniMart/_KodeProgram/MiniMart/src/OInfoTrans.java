import java.util.Date;

public class OInfoTrans {
 
 long TransId;
 String InfoIdExternal;
 boolean Important;
 Date Dt;
 int TypeId; String TypeName;
 int CashInId; String CashInName; String CashInComment;
 int CashOutId; String CashOutName; String CashOutComment;
 long SubjectId; String SubjectName;
 long SalesmanId; String SalesmanName;
 int CreditDays;
	Date RepaymentPeriodStart; Date RepaymentPeriodEnd;
 String Comment;
 
}