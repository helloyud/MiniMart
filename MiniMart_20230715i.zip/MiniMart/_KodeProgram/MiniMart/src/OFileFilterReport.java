import java.io.File;
import javax.swing.filechooser.FileFilter;

public class OFileFilterReport extends FileFilter {
 public boolean accept(File path){
  boolean ret=true;
  if(path.isFile()){
   ret=PFile.compareIgnoreCaseExtension(path.getName(), "report");
  }
  return ret;
 }
 public String getDescription(){
  return new String("File Data Report MiniMart (.report)");
 }
}