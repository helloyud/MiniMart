import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_ConvertItemModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 int wConvert; // 1 Rule Of Convert, 2 Converting
 int wMode; // 0 Add_new, 1 edit
 long wItemId;
 double wQuantity;
 
 // get
  // Item
 boolean RecheckId;
 long CheckedId, I_CheckedId;
 OInfoItem ItemInfo, I_ItemInfo;
 boolean InputInfoClearedItem;
 
  // Qty
 double Qty, I_Qty;
 
 //
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 
 public F_ConvertItemModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  I_ItemInfo=new OInfoItem();
  
  EnableDocumentListener=new VBoolean(true);
  
  TF_ItemId.setToolTipText("{F6} ket brg, {Spasi} cari brg, {Enter} tbh brg, {Down} ubah qty & hrg");
  TF_ItemId.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    
   });
  TF_Quantity.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    
   });
  EnableDocumentListener.Value=true;
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  DocumentListenerFocus=-1;
  
  InputInfoClearedItem=true;
 }
 
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_ItemId, Btn_ChooseItem,
    TF_Quantity,
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseItemActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearInputItem();
  DocumentListenerFocus=-1;
 }
 
 // Input Item Methods
  // Item
 void inputItem(){
  if(!changeItemMetadata()){return;}
  afterChangeItemMetadata();
 }
 boolean changeItemMetadata(){
  boolean ret=false;
  OInfoItem InfoItem;
  
  do{
   // Parse TF_ItemId
   try{I_CheckedId=Long.parseLong(TF_ItemId.getText());}catch(Exception E){break;}
   
   // Check if Item is exist in database
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId, false); if(InfoItem==null){break;}
   
   // init input-item's non-gui variables
   I_ItemInfo=InfoItem;
   changeItemQuantityPrice();
   
   ret=true;
  }while(false);
  
  if(!ret){I_CheckedId=-1; clearItem();}
  
  RecheckId=false;
  
  return ret;
 }
 void afterChangeItemMetadata(){
  // init input-item's gui variables
  setIQty(I_Qty, false);
  
  fillInputInfoItem();
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
 }
 void fillInputInfoItem(){
  if(I_CheckedId==-1){clearInputInfoItem(); return;}
  
  TA_ItemName.setText(I_ItemInfo.Name);
  TF_ItemStockUnit.setText(PText.getString(I_ItemInfo.StockUnitName, "", false));
  CB_ItemUpStock.setSelected(I_ItemInfo.UpdateStock);
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  PGUI.clearText(TA_ItemName, TF_ItemStockUnit);
  CB_ItemUpStock.setSelected(false);
  
  InputInfoClearedItem=true;
 }
 void clearItem(){
  clearInputInfoItem();
 }
 void focusItem(){
  PGUI.requestFocusInWindow(TF_ItemId);
 }
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_Quantity, "");}}
 }
 void inputQuantity(){
  I_Qty=PText.parseDouble(TF_Quantity.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}
  
  if(I_Qty<=0){return;}
 }
 void focusQty(){
  PGUI.requestFocusInWindow(TF_Quantity);
 }
  // Others
 void fillInputVariablesIntoRealVariables(){
  CheckedId=I_CheckedId;
  ItemInfo=I_ItemInfo;
  
  Qty=I_Qty;
 }
 void clearInputItem(){
  EnableDocumentListener.Value=false;
  
  TF_ItemId.setText(""); I_CheckedId=-1; RecheckId=false; clearItem();
  setIQty(-1, true);
  
  EnableDocumentListener.Value=true;
 }
 void changeDocument(JTextField TF, String Str){
  EnableDocumentListener.Value=false;
  TF.setText(Str);
  EnableDocumentListener.Value=true;
 }
 void focus(JTextField TF){
  TF.requestFocusInWindow();
 }
 void enableItemIdEdit(boolean Enable){
  TF_ItemId.setEditable(Enable);
  if(Enable){TF_ItemId.setBackground(CGUI.Color_TextBox_FocusOff);}
  else{TF_ItemId.setBackground(CGUI.Color_TextBox_Uneditable);}
  Btn_ChooseItem.setEnabled(Enable);
 }
 
 //
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ItemId){TF_ItemIdKeyPressed(e);}
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Price = new javax.swing.ButtonGroup();
  Lbl_ItemId = new javax.swing.JLabel();
  TF_Quantity = new javax.swing.JTextField();
  Lbl_Quantity = new javax.swing.JLabel();
  TF_ItemId = new javax.swing.JTextField();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_ItemName = new javax.swing.JTextArea();
  TF_ItemStockUnit = new javax.swing.JTextField();
  CB_ItemUpStock = new javax.swing.JCheckBox();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Btn_ChooseItem = new javax.swing.JButton();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Lbl_ItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ItemId.setText("Id Barang");
  Lbl_ItemId.setRequestFocusEnabled(false);

  TF_Quantity.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_Quantity.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_QuantityFocusLost(evt);
   }
  });
  TF_Quantity.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QuantityKeyPressed(evt);
   }
  });

  Lbl_Quantity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_Quantity.setText("Kuantitas");

  TF_ItemId.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
  TF_ItemId.setToolTipText("");
  TF_ItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ItemIdFocusLost(evt);
   }
  });
  TF_ItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemIdKeyPressed(evt);
   }
  });

  TA_ItemName.setEditable(false);
  TA_ItemName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemName.setColumns(20);
  TA_ItemName.setLineWrap(true);
  TA_ItemName.setToolTipText("klik utk melihat keterangan barang");
  TA_ItemName.setWrapStyleWord(true);
  TA_ItemName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_ItemName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_ItemNameMouseClicked(evt);
   }
  });
  jScrollPane1.setViewportView(TA_ItemName);

  TF_ItemStockUnit.setEditable(false);
  TF_ItemStockUnit.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemStockUnit.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_ItemStockUnit.setToolTipText("Jumlah Stok");

  CB_ItemUpStock.setText("Diperbarui");
  CB_ItemUpStock.setToolTipText("Pembaruan Stok Saat Transaksi");
  CB_ItemUpStock.setEnabled(false);
  CB_ItemUpStock.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemUpStock.setRequestFocusEnabled(false);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Btn_ChooseItem.setText("{Ctrl+I}");
  Btn_ChooseItem.setToolTipText("Pilih sebuah barang");
  Btn_ChooseItem.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ChooseItem.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseItemActionPerformed(evt);
   }
  });
  Btn_ChooseItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseItemKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Lbl_ItemId)
       .addComponent(Lbl_Quantity))
      .addGap(29, 29, 29)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_ItemId)
        .addGap(0, 0, 0)
        .addComponent(Btn_ChooseItem))
       .addComponent(jScrollPane1)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_ItemStockUnit, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_ItemUpStock)))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_ItemId)
     .addComponent(TF_ItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_ChooseItem))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Quantity)
     .addComponent(TF_ItemStockUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_ItemUpStock, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addGap(13, 13, 13))
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  if(RecheckId){changeItemMetadata();}
  
  if(I_CheckedId==-1 || I_Qty<=0){JOptionPane.showMessageDialog(null, "Masukan belum benar !\nSilahkan periksa kembali !"); return;}
  
  fillInputVariablesIntoRealVariables();
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  closingForm(0);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  OInfoItem InfoItem;
  
  if(Activ){return;}
  
  Activ=true;
  
  I_CheckedId=-1; RecheckId=false;
  I_Qty=-1;
  
  if(wMode==0){
   setTitle("Tambah Barang Baru Pada "+PText.getString(wConvert==1, "Aturan Konversi", "Konversi Barang"));
   enableItemIdEdit(true);
   
   TF_ItemId.requestFocusInWindow();
  }
  else{
   setTitle("Ubah Barang Pada "+PText.getString(wConvert==1, "Aturan Konversi", "Konversi Barang"));
   enableItemIdEdit(false);
   
   EnableDocumentListener.Value=false;
   
   I_CheckedId=wItemId; RecheckId=false;
   
   TF_ItemId.setText(String.valueOf(I_CheckedId));
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId, false); if(InfoItem==null){InfoItem=new OInfoItem();}
   I_ItemInfo=InfoItem;
   
   I_Qty=wQuantity;
   
   setIQty(I_Qty, false);

   fillInputInfoItem();
   
   EnableDocumentListener.Value=true;
   
   TF_Quantity.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void TF_ItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  if(Activ && RecheckId){inputItem();}
 }//GEN-LAST:event_TF_ItemIdFocusLost

 private void TF_ItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemIdKeyPressed
  if(!PGUI.isEnabled(TF_ItemId)){return;}
  
  int consumed=PNav.onKey_TF(this, TF_ItemId, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ChooseItem)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F6 : if(RecheckId){inputItem();} break;
   case KeyEvent.VK_SPACE : evt.consume(); Btn_ChooseItemActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_ItemIdKeyPressed

 private void TF_QuantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QuantityKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Quantity, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QuantityKeyPressed

 private void Btn_ChooseItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseItemActionPerformed
  if(!Btn_ChooseItem.isEnabled()){return;}
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  // change ItemDet's variables directly from FItem
  I_CheckedId=IFV.FItem.ChoosedId[0];
  PGUI.changeDocument(EnableDocumentListener, TF_ItemId, String.valueOf(I_CheckedId));
  inputItem();

  PGUI.focus(TF_Quantity, false);
 }//GEN-LAST:event_Btn_ChooseItemActionPerformed

 private void TF_QuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusGained
  DocumentListenerFocus=1;
  PGUI.text_SelectAll(TF_Quantity);
 }//GEN-LAST:event_TF_QuantityFocusGained

 private void TF_QuantityFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QuantityFocusLost
  DocumentListenerFocus=-1;
 }//GEN-LAST:event_TF_QuantityFocusLost

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Quantity)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TF_ItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ItemId, TF_ItemId_ShortcutKeys);
  
  PGUI.text_SelectAll(TF_ItemId);
 }//GEN-LAST:event_TF_ItemIdFocusGained

 private void TA_ItemNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_ItemNameMouseClicked
  if(I_CheckedId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_ItemNameMouseClicked

 private void Btn_ChooseItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseItemKeyPressed
  if(!PGUI.isEnabled(Btn_ChooseItem)){return;}
  
  PNav.onKey_Btn(this, Btn_ChooseItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_Quantity)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseItemKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ChooseItem;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_ItemUpStock;
 private javax.swing.JLabel Lbl_ItemId;
 private javax.swing.JLabel Lbl_Quantity;
 private javax.swing.ButtonGroup RG_Price;
 private javax.swing.JTextArea TA_ItemName;
 private javax.swing.JTextField TF_ItemId;
 private javax.swing.JTextField TF_ItemStockUnit;
 private javax.swing.JTextField TF_Quantity;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
