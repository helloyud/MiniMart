public class ODatabaseTableColumnType {
 
 int Type;
 boolean Nullable;
 int SinceVersion;

 public ODatabaseTableColumnType(int Type, boolean Nullable, int SinceVersion) {
  this.Type = Type;
  this.Nullable = Nullable;
  this.SinceVersion = SinceVersion;
 }

}