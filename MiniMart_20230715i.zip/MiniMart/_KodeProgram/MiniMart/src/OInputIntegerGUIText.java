import javax.swing.JTextField;

public class OInputIntegerGUIText extends OInput {

 JTextField GUI_Text;
 boolean AcceptEmptyInput;
 boolean AcceptZero;
 boolean PositiveOnly;
 boolean WithinRange;
 int Range1, Range2;
 
 VInteger Value;

 public OInputIntegerGUIText(JTextField GUI_Text, boolean AcceptEmptyInput, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, int Range1, int Range2) {
  this.GUI_Text = GUI_Text;
  this.AcceptEmptyInput = AcceptEmptyInput;
  this.AcceptZero = AcceptZero;
  this.PositiveOnly = PositiveOnly;
  this.WithinRange=WithinRange;
  this.Range1=Range1;
  this.Range2=Range2;
  
  Value=new VInteger();
 }
 
 public boolean isValid(){return PGUI.checkInputInteger(GUI_Text, Value, AcceptEmptyInput, AcceptZero, PositiveOnly, WithinRange, Range1, Range2);}
 public Object getValue(){return Value.Value;}

}