public class OParameterValue {

 String Parameter;
 int ValueType;
 Object Value;
 Object ValueDefault;
 boolean ValueIsAlready;
 
 boolean ValueAlwaysReferToValueDefault;

 public OParameterValue(String Parameter, int ValueType, Object Value, Object ValueDefault, boolean ValueIsAlready,
  boolean ValueAlwaysReferToValueDefault) {
  this.Parameter = Parameter;
  this.ValueType=ValueType;
  this.Value = Value;
  this.ValueDefault=ValueDefault;
  this.ValueIsAlready=ValueIsAlready;
  this.ValueAlwaysReferToValueDefault=ValueAlwaysReferToValueDefault;
 }
 public OParameterValue(OParameterValue Data) {
  this(Data.Parameter, Data.ValueType, Data.Value, Data.ValueDefault, Data.ValueIsAlready, Data.ValueAlwaysReferToValueDefault);
 }
 
 public OParameterValue resetValue(){
  Value=null; ValueIsAlready=false;
  return this;
 }
 public void setValue(Object Value, boolean IsSetValueDefault){
  Object value_;
  if(!IsSetValueDefault){value_=Value;}else{value_=ValueDefault;}
  this.Value=value_; ValueIsAlready=true;
 }
 public Object getValue(boolean IsGetValueDefault, int GetValueIfNotIsAlreadyReturn){
  Object ret=null;
  
  do{
   if(ValueAlwaysReferToValueDefault || IsGetValueDefault){ret=ValueDefault; break;}
   if(ValueIsAlready){ret=Value; break;}
   switch(GetValueIfNotIsAlreadyReturn){
    case 0 : ret=null; break;
    case 1 : ret=ValueDefault; break;
    case 2 : ret=Value; break;
   }
  }while(false);
   
  return ret;
 }
 
}