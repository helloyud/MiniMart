import java.awt.event.KeyAdapter;

public class OKeyAdapter extends KeyAdapter {
 
 
 
}