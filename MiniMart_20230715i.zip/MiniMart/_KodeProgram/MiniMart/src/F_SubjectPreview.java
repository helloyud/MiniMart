import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.table.TableColumnModel;

public class F_SubjectPreview extends XFormPreview {

 // Set
 long wId;
 OInfoSubject wInfoSubject;
 
 // Pic
 boolean SIPicClear;
 OCustomListModel ListMdlPic;
 int LastSelectedRowPic;
 boolean PanelImageClear;
 
 // Bio
 boolean SIBioClear;
 
 boolean SIAddrClear;
 OCustomTableModel TableMdlAddr;
	String[] TableMdlAddrColsName;
	int[] TableMdlAddrColsType, TableMdlAddrColsShowOption, TableMdlAddrColsVisible, TableAddrColsWidth;
	boolean[] TableMdlAddrColsEditable;
 int LastSelectedRowAddr;
 boolean InfoAddrClear;
 
 boolean SIContClear;
 OCustomTableModel TableMdlCont;
	String[] TableMdlContColsName;
	int[] TableMdlContColsType, TableMdlContColsShowOption, TableMdlContColsVisible, TableContColsWidth;
	boolean[] TableMdlContColsEditable;
 int LastSelectedRowCont;
 boolean InfoContClear;
 
 boolean SIAccClear;
 OCustomTableModel TableMdlAcc;
	String[] TableMdlAccColsName;
	int[] TableMdlAccColsType, TableMdlAccColsShowOption, TableMdlAccColsVisible, TableAccColsWidth;
	boolean[] TableMdlAccColsEditable;
 int LastSelectedRowAcc;
 boolean InfoAccClear;
 
 // Etc
 boolean SIEtcClear;
 
  // Cat
 boolean SICatClear;
 OCustomListModel ListMdlCat;
 int LastSelectedRowCat;
 boolean InfoCatClear;
 int CategoriesCount;
 
  // Tag
 boolean SITagClear;
 OCustomListModel ListMdlTag;
 int LastSelectedRowTag;
 boolean InfoTagClear;
 int TagsCount;
 
 public F_SubjectPreview(MInterFormVariables IFV_) {
  TableColumnModel ColMdl;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Pic
  SIPicClear=true;
  
  ListMdlPic=new OCustomListModel(false);
  ListMdlPic.setColumnsInfo(PCore.primArr(CCore.TypeString), 0);
  List_Pic.setModel(ListMdlPic);
  
  LastSelectedRowPic=-1;
  PanelImageClear=true;
  
  // Bio
  SIBioClear=true;
  
   // addr
  SIAddrClear=true;
  
  TableMdlAddr=new OCustomTableModel();
  Tbl_Addr.setModel(TableMdlAddr);
  
  TableMdlAddrColsName=PMyShop.getSubjectAddr_ColumnsName();
  TableMdlAddrColsType=PMyShop.getSubjectAddr_ColumnsType();
  TableMdlAddrColsShowOption=PMyShop.getSubjectAddr_ColumnsShowOption();
  TableMdlAddrColsEditable=PMyShop.getSubjectAddr_ColumnsEditable(false, false);
  LastSelectedRowAddr=-1;
  InfoAddrClear=true;
  
  PGUI.setSelected(true, CB_AddrViewCity, CB_AddrViewComment);
  
  buildTableAddrViewStructure(true, true);
  updateTableAddrView(false);
  
   // cont
  SIContClear=true;
  
  TableMdlCont=new OCustomTableModel();
  Tbl_Cont.setModel(TableMdlCont);
  
  TableMdlContColsName=PMyShop.getSubjectCont_ColumnsName();
  TableMdlContColsType=PMyShop.getSubjectCont_ColumnsType();
  TableMdlContColsShowOption=PMyShop.getSubjectCont_ColumnsShowOption();
  TableMdlContColsEditable=PMyShop.getSubjectCont_ColumnsEditable(false, false);
  LastSelectedRowCont=-1;
  InfoContClear=true;
  
  PGUI.setSelected(true, CB_ContViewContactType, CB_ContViewComment);
  
  buildTableContViewStructure(true, true);
  updateTableContView(false);
  
   // acc
  SIAccClear=true;
  
  TableMdlAcc=new OCustomTableModel();
  Tbl_Acc.setModel(TableMdlAcc);
  
  TableMdlAccColsName=PMyShop.getSubjectAcc_ColumnsName();
  TableMdlAccColsType=PMyShop.getSubjectAcc_ColumnsType();
  TableMdlAccColsShowOption=PMyShop.getSubjectAcc_ColumnsShowOption();
  TableMdlAccColsEditable=PMyShop.getSubjectAcc_ColumnsEditable(false, false);
  LastSelectedRowAcc=-1;
  InfoAccClear=true;
  
  PGUI.setSelected(true, CB_AccViewBankPlatform, CB_AccViewComment);
  
  buildTableAccViewStructure(true, true);
  updateTableAccView(false);
  
  // Etc
  SIEtcClear=true;
  
   // Cat
  SICatClear=true;
  
  ListMdlCat=new OCustomListModel(false);
  ListMdlCat.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_Cat.setModel(ListMdlCat);
  
  LastSelectedRowCat=-1;
  InfoCatClear=true;
  
   // Tag
  SITagClear=true;
  
  ListMdlTag=new OCustomListModel(false);
  ListMdlTag.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_Tag.setModel(ListMdlTag);
  
  LastSelectedRowTag=-1;
  InfoTagClear=true;
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    ),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
 }
 
 public boolean proceed(Object AKey){
  boolean ret=false;
  
  do{
   wId=(Long)AKey;
   
   wInfoSubject=PMyShop.getSubjectInfo(IFV.Stm, wId);
   if(wInfoSubject==null){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public String getName(){return "subjek";}
 
 void clearComponents(){
  clearPic();
  clearBio();
  clearEtc();
  
  clearSetVariables();
 }
 
 // Pic
 void onPicRowSelected(boolean UpdateAnyway){
  int row=List_Pic.getSelectedIndex();
  
  if(LastSelectedRowPic==row && !UpdateAnyway){return;}
  
  LastSelectedRowPic=row;
  if(row==-1){clearInfoPic(); return;}
  fillInfoPic(row);
 }
 void fillPic(){
  int datacount;
  
  clearPic();
  
  SIPicClear=false;
  
  datacount=PDatabase.queryToList(IFV.Stm,
   "select SubjectXPicture.FileName from SubjectXPicture where "+
   "SubjectXPicture.Subject="+wId+" order by SubjectXPicture.FileName asc",
   ListMdlPic, false, null, -1, false, -1);
  if(datacount==-1){clearPic(); return;}
  if(datacount>0){List_Pic.setSelectedIndex(0); onPicRowSelected(true);}
 }
 void clearPic(){
  if(SIPicClear){return;}
  
  ListMdlPic.removeAll();
  LastSelectedRowPic=-1;
  clearInfoPic();
  
  SIPicClear=true;
 }
 void fillInfoPic(int PicRowSelected){
  Object[] Objs=ListMdlPic.Mdl.Rows.elementAt(PicRowSelected);
  
  PGUI.fillPanelPictureURL(Pnl_Image, IFV.Conf.ImageDirSubject, PCore.objString(Objs[0], null));
  
  PanelImageClear=false;
 }
 void clearInfoPic(){
  if(PanelImageClear){return;}
  
  PGUI.fillPanelPictureURL(Pnl_Image, IFV.Conf.ImageDirSubject, null);

  PanelImageClear=true;
 }
 
 // Bio
 void fillBio(){
  boolean error;
  
  // clear list and list index, but not other components and index
  if(!SIBioClear){
   clearAddr();
   clearCont();
   clearAcc();
  }
  
  // fetch list data
  SIBioClear=false;
  
  error=true;
  do{
   if(!fillAddr()){break;}
   if(!fillCont()){break;}
   if(!fillAcc()){break;}
   
   error=false;
  }while(false);
  
  if(error){clearBio();}
 }
 void clearBio(){
  if(SIBioClear){return;}
  
  clearAddr();
  clearCont();
  clearAcc();

  SIBioClear=true;
 }
 
 // Address
 void onSelectedRowAddrChanged(boolean UpdateAnyway){
  int row=Tbl_Addr.getSelectedRow();
  if(LastSelectedRowAddr==row && !UpdateAnyway){return;}
  LastSelectedRowAddr=row;
  if(row==-1){clearInfoAddr(); return;}
  fillInfoAddr(row);
 }
 
 boolean fillAddr(){
  boolean ret=false;
  int datacount;
  
  clearAddr();
  if(wId<0){return true;}
  
  SIAddrClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getSubjectAddr_Query(PCore.primArr(wId), false, null, false, -1, null, false),
    TableMdlAddr, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Addr.changeSelection(0, 0, false, false); onSelectedRowAddrChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearAddr();}
  
  return ret;
 }
 void clearAddr(){
  if(SIAddrClear){return;}
  
  TableMdlAddr.removeAll();
  LastSelectedRowAddr=-1;
  clearInfoAddr();
  
  SIAddrClear=true;
 }
 void fillInfoAddr(int row){
  Object[] objs;
  String City, Address, Comment;
  
  if(row==-1){return;}
  
  /* "enumeration", "city_id", "city_name", "address", "comment" */
  
  objs=TableMdlAddr.Mdl.Rows.elementAt(row);
  City=PCore.objString(objs[2], null);
  Address=PCore.objString(objs[3], null);
  Comment=PCore.objString(objs[4], null);
  
  TF_AddrInfoCity.setText(PText.getString(City, "", false));
  TA_AddrInfoDetail.setText(
   PText.getString(Address, "", false)+
   PText.getString(Comment, "", "\n{ "+Comment+" }", true));
  
  InfoAddrClear=false;
 }
 void clearInfoAddr(){
  if(InfoAddrClear){return;}
  
  PGUI.clearText(TF_AddrInfoCity, TA_AddrInfoDetail);
  
  InfoAddrClear=true;
 }
 
 void updateTableAddrView(boolean Requery){
  TableMdlAddr.updateColumnsInfo(TableMdlAddrColsName, TableMdlAddrColsType, TableMdlAddrColsShowOption,
   TableMdlAddrColsVisible, TableMdlAddrColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Addr, TableAddrColsWidth);
  if(!Requery){onSelectedRowAddrChanged(false);}
  else{fillAddr();}
 }
 void buildTableAddrColumns(){
  TableMdlAddrColsVisible=PMyShop.getSubjectAddr_ColumnsVisible(CB_AddrViewCity.isSelected(), CB_AddrViewComment.isSelected());
  TableAddrColsWidth=PMyShop.getSubjectAddr_ColumnsWidth(CB_AddrViewCity.isSelected(), CB_AddrViewComment.isSelected());
 }
 void buildTableAddrOrderBy(){}
 void buildTableAddrViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableAddrColumns();}
  if(RebuildOrderBy){buildTableAddrOrderBy();}
 }
 void changeAddrViewByNormal(){
  buildTableAddrViewStructure(true, false);
  updateTableAddrView(false);
 }
 
 // Contact
 void onSelectedRowContChanged(boolean UpdateAnyway){
  int row=Tbl_Cont.getSelectedRow();
  if(LastSelectedRowCont==row && !UpdateAnyway){return;}
  LastSelectedRowCont=row;
  if(row==-1){clearInfoCont(); return;}
  fillInfoCont(row);
 }
 
 boolean fillCont(){
  boolean ret=false;
  int datacount;
  
  clearCont();
  if(wId<0){return true;}
  
  SIContClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getSubjectCont_Query(PCore.primArr(wId), false, null, false, -1, null, false),
    TableMdlCont, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Cont.changeSelection(0, 0, false, false); onSelectedRowContChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearCont();}
  
  return ret;
 }
 void clearCont(){
  if(SIContClear){return;}
  
  TableMdlCont.removeAll();
  LastSelectedRowCont=-1;
  clearInfoCont();
  
  SIContClear=true;
 }
 void fillInfoCont(int row){
  Object[] objs;
  String ContactType, Contact, Comment;
  
  if(row==-1){return;}
  
  /* "enumeration", "contacttype_id", "contacttype_name", "contact", "comment" */
  
  objs=TableMdlCont.Mdl.Rows.elementAt(row);
  ContactType=PCore.objString(objs[2], null);
  Contact=PCore.objString(objs[3], null);
  Comment=PCore.objString(objs[4], null);
  
  TF_ContInfoType.setText(PText.getString(ContactType, "", false));
  TA_ContInfoDetail.setText(
   PText.getString(Contact, "", false)+
   PText.getString(Comment, "", "\n{ "+Comment+" }", true));
  
  InfoContClear=false;
 }
 void clearInfoCont(){
  if(InfoContClear){return;}
  
  PGUI.clearText(TF_ContInfoType, TA_ContInfoDetail);
  
  InfoContClear=true;
 }
 
 void updateTableContView(boolean Requery){
  TableMdlCont.updateColumnsInfo(TableMdlContColsName, TableMdlContColsType, TableMdlContColsShowOption,
   TableMdlContColsVisible, TableMdlContColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Cont, TableContColsWidth);
  if(!Requery){onSelectedRowContChanged(false);}
  else{fillCont();}
 }
 void buildTableContColumns(){
  TableMdlContColsVisible=PMyShop.getSubjectCont_ColumnsVisible(CB_ContViewContactType.isSelected(), CB_ContViewComment.isSelected());
  TableContColsWidth=PMyShop.getSubjectCont_ColumnsWidth(CB_ContViewContactType.isSelected(), CB_ContViewComment.isSelected());
 }
 void buildTableContOrderBy(){}
 void buildTableContViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableContColumns();}
  if(RebuildOrderBy){buildTableContOrderBy();}
 }
 void changeContViewByNormal(){
  buildTableContViewStructure(true, false);
  updateTableContView(false);
 }
 
 // Bank Account
 void onSelectedRowAccChanged(boolean UpdateAnyway){
  int row=Tbl_Acc.getSelectedRow();
  if(LastSelectedRowAcc==row && !UpdateAnyway){return;}
  LastSelectedRowAcc=row;
  if(row==-1){clearInfoAcc(); return;}
  fillInfoAcc(row);
 }
 
 boolean fillAcc(){
  boolean ret=false;
  int datacount;
  
  clearAcc();
  if(wId<0){return true;}
  
  SIAccClear=false;
  do{
   datacount=PDatabase.queryToTable(IFV.Stm, PMyShop.getSubjectAcc_Query(PCore.primArr(wId), false, null, false, -1, null, false),
    TableMdlAcc, false, false, null, -1, false, -1);
   if(datacount==-1){break;}

   if(datacount>0){Tbl_Acc.changeSelection(0, 0, false, false); onSelectedRowAccChanged(false);}
   
   ret=true;
  }while(false);
  if(!ret){clearAcc();}
  
  return ret;
 }
 void clearAcc(){
  if(SIAccClear){return;}
  
  TableMdlAcc.removeAll();
  LastSelectedRowAcc=-1;
  clearInfoAcc();
  
  SIAccClear=true;
 }
 void fillInfoAcc(int row){
  Object[] objs;
  String BankPlatform, BankAccount, Comment;
  
  if(row==-1){return;}
  
  /* "enumeration", "bankplatform_id", "bankplatform_name", "bankaccount", "comment" */
  
  objs=TableMdlAcc.Mdl.Rows.elementAt(row);
  BankPlatform=PCore.objString(objs[2], null);
  BankAccount=PCore.objString(objs[3], null);
  Comment=PCore.objString(objs[4], null);
  
  TF_AccInfoBankPlatform.setText(PText.getString(BankPlatform, "", false));
  TA_AccInfoDetail.setText(
   PText.getString(BankAccount, "", false)+
   PText.getString(Comment, "", "\n{ "+Comment+" }", true));
  
  InfoAccClear=false;
 }
 void clearInfoAcc(){
  if(InfoAccClear){return;}
  
  PGUI.clearText(TF_AccInfoBankPlatform, TA_AccInfoDetail);
  
  InfoAccClear=true;
 }
 
 void updateTableAccView(boolean Requery){
  TableMdlAcc.updateColumnsInfo(TableMdlAccColsName, TableMdlAccColsType, TableMdlAccColsShowOption,
   TableMdlAccColsVisible, TableMdlAccColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Acc, TableAccColsWidth);
  if(!Requery){onSelectedRowAccChanged(false);}
  else{fillAcc();}
 }
 void buildTableAccColumns(){
  TableMdlAccColsVisible=PMyShop.getSubjectAcc_ColumnsVisible(CB_AccViewBankPlatform.isSelected(), CB_AccViewComment.isSelected());
  TableAccColsWidth=PMyShop.getSubjectAcc_ColumnsWidth(CB_AccViewBankPlatform.isSelected(), CB_AccViewComment.isSelected());
 }
 void buildTableAccOrderBy(){}
 void buildTableAccViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableAccColumns();}
  if(RebuildOrderBy){buildTableAccOrderBy();}
 }
 void changeAccViewByNormal(){
  buildTableAccViewStructure(true, false);
  updateTableAccView(false);
 }
 
 // Etc
 void fillEtc(){
  boolean bool;
  
  clearEtc();
  
  SIEtcClear=false;
  
  bool=false;
  do{
   if(!fillCat()){break;}
   if(!fillTag()){break;}
   bool=true;
  }while(false);
  if(!bool){clearEtc();}
 }
 void clearEtc(){
  if(SIEtcClear){return;}
  
  clearCat();
  clearTag();
  
  SIEtcClear=true;
 }
 
  // Cat
 void onCatRowSelected(boolean UpdateAnyway){
  int row=List_Cat.getSelectedIndex();
  
  if(LastSelectedRowCat==row && !UpdateAnyway){return;}
  
  LastSelectedRowCat=row;
  if(row==-1){clearInfoCat(); return;}
  fillInfoCat(row);
 }
 boolean fillCat(){
  boolean ret=false;
  int datacount;
  
  clearCat();
  
  SICatClear=false;
  do{
   datacount=PDatabase.queryToList(IFV.Stm,
    "select CategoryId, Name as 'CategoryName' from "+
     "(select CategoryOfSubject as 'CategoryId' from SubjectXCategory where Subject="+wId+") as tb1 "+
    "inner join CategoryOfSubject on tb1.CategoryId=CategoryOfSubject.Id order by Name asc",
    ListMdlCat, false, null, -1, false, -1);
   if(datacount==-1){break;}
   CategoriesCount=datacount;
   if(datacount>0){List_Cat.setSelectedIndex(0); onCatRowSelected(true);}
   
   ret=true;
  }while(false);
  if(!ret){clearCat();}
  
  return ret;
 }
 void clearCat(){
  if(SICatClear){return;}
  
  ListMdlCat.removeAll();
  LastSelectedRowCat=-1;
  clearInfoCat();
  CategoriesCount=0;
  
  SICatClear=true;
 }
 void fillInfoCat(int CatRowSelected){
  Object[] Objs=ListMdlCat.Mdl.Rows.elementAt(CatRowSelected);
  
  
  
  InfoCatClear=false;
 }
 void clearInfoCat(){
  if(InfoCatClear){return;}
  
  
  
  InfoCatClear=true;
 }
 
  // Tag
 void onTagRowSelected(boolean UpdateAnyway){
  int row=List_Tag.getSelectedIndex();
  
  if(LastSelectedRowTag==row && !UpdateAnyway){return;}
  
  LastSelectedRowTag=row;
  if(row==-1){clearInfoTag(); return;}
  fillInfoTag(row);
 }
 boolean fillTag(){
  boolean ret=false;
  int datacount;
  
  clearTag();
  
  SITagClear=false;
  do{
   datacount=PDatabase.queryToList(IFV.Stm,
     "select TagId, Name as 'TagName' from "+
     "(select TagOfSubject as 'TagId' from SubjectXTag where Subject="+wId+") as tb1 "+
    "inner join TagOfSubject on tb1.TagId=TagOfSubject.Id order by Name asc",
    ListMdlTag, false, null, -1, false, -1);
   if(datacount==-1){break;}
   TagsCount=datacount;
   if(datacount>0){List_Tag.setSelectedIndex(0); onTagRowSelected(true);}
   
   ret=true;
  }while(false);
  if(!ret){clearTag();}
  
  return ret;
 }
 void clearTag(){
  if(SITagClear){return;}
  
  ListMdlTag.removeAll();
  LastSelectedRowTag=-1;
  clearInfoTag();
  TagsCount=0;
  
  SITagClear=true;
 }
 void fillInfoTag(int TagRowSelected){
  Object[] Objs=ListMdlTag.Mdl.Rows.elementAt(TagRowSelected);
  
  
  
  InfoTagClear=false;
 }
 void clearInfoTag(){
  if(InfoTagClear){return;}
  
  

  InfoTagClear=true;
 }
 
 // Others
 void clearSetVariables(){
  wInfoSubject=null;
 }
 void fillComponentsWithSetVariables(){
  TF_Name.setText(wInfoSubject.Name);
  TF_Birthday.setText(PText.dateToString(wInfoSubject.Birthday, 2));
  TA_Comment.setText(PText.getString(wInfoSubject.Comment, "", false));
  
  //
  fillPic();
  fillBio();
  fillEtc();
 }
 void initPrivGUIShow(){
  
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jSeparator1 = new javax.swing.JSeparator();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_Pic = new javax.swing.JPanel();
  Pnl_Image = new XImgBoxURL();
  jScrollPane9 = new javax.swing.JScrollPane();
  List_Pic = new XList();
  Panel_Bio = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  Lbl_Addr = new javax.swing.JLabel();
  jScrollPane4 = new javax.swing.JScrollPane();
  Tbl_Addr = new XTable();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_AddrInfoDetail = new javax.swing.JTextArea();
  TF_AddrInfoCity = new javax.swing.JTextField();
  CB_AddrViewComment = new javax.swing.JToggleButton();
  CB_AddrViewCity = new javax.swing.JToggleButton();
  jPanel5 = new javax.swing.JPanel();
  Lbl_Cont = new javax.swing.JLabel();
  jScrollPane2 = new javax.swing.JScrollPane();
  Tbl_Cont = new XTable();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_ContInfoDetail = new javax.swing.JTextArea();
  TF_ContInfoType = new javax.swing.JTextField();
  CB_ContViewComment = new javax.swing.JToggleButton();
  CB_ContViewContactType = new javax.swing.JToggleButton();
  jPanel6 = new javax.swing.JPanel();
  CB_AccViewComment = new javax.swing.JToggleButton();
  CB_AccViewBankPlatform = new javax.swing.JToggleButton();
  Lbl_Acc = new javax.swing.JLabel();
  jScrollPane7 = new javax.swing.JScrollPane();
  Tbl_Acc = new XTable();
  jScrollPane8 = new javax.swing.JScrollPane();
  TA_AccInfoDetail = new javax.swing.JTextArea();
  TF_AccInfoBankPlatform = new javax.swing.JTextField();
  Panel_Etc = new javax.swing.JPanel();
  jPanel1 = new javax.swing.JPanel();
  jLabel1 = new javax.swing.JLabel();
  jScrollPane10 = new javax.swing.JScrollPane();
  List_Cat = new XList();
  jPanel2 = new javax.swing.JPanel();
  jLabel2 = new javax.swing.JLabel();
  jScrollPane6 = new javax.swing.JScrollPane();
  List_Tag = new XList();
  jPanel3 = new javax.swing.JPanel();
  TF_Name = new javax.swing.JTextField();
  Lbl_Name = new javax.swing.JLabel();
  TF_Birthday = new javax.swing.JTextField();
  Lbl_Birthday = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  Lbl_Comment = new javax.swing.JLabel();

  setTitle("Keterangan Subjek");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  List_Pic.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    List_PicMouseReleased(evt);
   }
  });
  List_Pic.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_PicKeyReleased(evt);
   }
  });
  jScrollPane9.setViewportView(List_Pic);

  javax.swing.GroupLayout Panel_PicLayout = new javax.swing.GroupLayout(Panel_Pic);
  Panel_Pic.setLayout(Panel_PicLayout);
  Panel_PicLayout.setHorizontalGroup(
   Panel_PicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_Image, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
   .addComponent(jScrollPane9)
  );
  Panel_PicLayout.setVerticalGroup(
   Panel_PicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_PicLayout.createSequentialGroup()
    .addComponent(Pnl_Image, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("Gambar", Panel_Pic);

  Lbl_Addr.setText("Alamat");

  Tbl_Addr.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Addr.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Addr.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_Addr.setRowHeight(17);
  Tbl_Addr.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_AddrMouseReleased(evt);
   }
  });
  Tbl_Addr.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_AddrKeyReleased(evt);
   }
  });
  jScrollPane4.setViewportView(Tbl_Addr);

  TA_AddrInfoDetail.setEditable(false);
  TA_AddrInfoDetail.setBackground(new java.awt.Color(204, 255, 204));
  TA_AddrInfoDetail.setColumns(20);
  TA_AddrInfoDetail.setLineWrap(true);
  TA_AddrInfoDetail.setRows(1);
  TA_AddrInfoDetail.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_AddrInfoDetail);

  TF_AddrInfoCity.setEditable(false);
  TF_AddrInfoCity.setBackground(new java.awt.Color(204, 255, 204));

  CB_AddrViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_AddrViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AddrViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_AddrViewComment.setText("Ket");
  CB_AddrViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AddrViewComment.setIconTextGap(0);
  CB_AddrViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AddrViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AddrViewCommentActionPerformed(evt);
   }
  });

  CB_AddrViewCity.setBackground(new java.awt.Color(204, 204, 204));
  CB_AddrViewCity.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AddrViewCity.setForeground(new java.awt.Color(102, 102, 0));
  CB_AddrViewCity.setText("Kota");
  CB_AddrViewCity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AddrViewCity.setIconTextGap(0);
  CB_AddrViewCity.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AddrViewCity.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AddrViewCityActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(Lbl_Addr)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_AddrViewCity)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_AddrViewComment))
   .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
   .addComponent(jScrollPane3)
   .addComponent(TF_AddrInfoCity)
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Addr)
     .addComponent(CB_AddrViewComment)
     .addComponent(CB_AddrViewCity))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_AddrInfoCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Lbl_Cont.setText("Kontak");

  Tbl_Cont.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Cont.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Cont.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_Cont.setRowHeight(17);
  Tbl_Cont.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ContMouseReleased(evt);
   }
  });
  Tbl_Cont.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ContKeyReleased(evt);
   }
  });
  jScrollPane2.setViewportView(Tbl_Cont);

  TA_ContInfoDetail.setEditable(false);
  TA_ContInfoDetail.setBackground(new java.awt.Color(204, 255, 204));
  TA_ContInfoDetail.setColumns(20);
  TA_ContInfoDetail.setLineWrap(true);
  TA_ContInfoDetail.setRows(1);
  TA_ContInfoDetail.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_ContInfoDetail);

  TF_ContInfoType.setEditable(false);
  TF_ContInfoType.setBackground(new java.awt.Color(204, 255, 204));

  CB_ContViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ContViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ContViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ContViewComment.setText("Ket");
  CB_ContViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ContViewComment.setIconTextGap(0);
  CB_ContViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ContViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ContViewCommentActionPerformed(evt);
   }
  });

  CB_ContViewContactType.setBackground(new java.awt.Color(204, 204, 204));
  CB_ContViewContactType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ContViewContactType.setForeground(new java.awt.Color(102, 102, 0));
  CB_ContViewContactType.setText("Tipe");
  CB_ContViewContactType.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ContViewContactType.setIconTextGap(0);
  CB_ContViewContactType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ContViewContactType.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ContViewContactTypeActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(Lbl_Cont)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_ContViewContactType)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ContViewComment))
   .addComponent(jScrollPane5)
   .addComponent(TF_ContInfoType)
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Cont)
     .addComponent(CB_ContViewComment)
     .addComponent(CB_ContViewContactType))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_ContInfoType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  CB_AccViewComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_AccViewComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AccViewComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_AccViewComment.setText("Ket");
  CB_AccViewComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AccViewComment.setIconTextGap(0);
  CB_AccViewComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AccViewComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AccViewCommentActionPerformed(evt);
   }
  });

  CB_AccViewBankPlatform.setBackground(new java.awt.Color(204, 204, 204));
  CB_AccViewBankPlatform.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_AccViewBankPlatform.setForeground(new java.awt.Color(102, 102, 0));
  CB_AccViewBankPlatform.setText("Bank");
  CB_AccViewBankPlatform.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_AccViewBankPlatform.setIconTextGap(0);
  CB_AccViewBankPlatform.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AccViewBankPlatform.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_AccViewBankPlatformActionPerformed(evt);
   }
  });

  Lbl_Acc.setText("Rekening");

  Tbl_Acc.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Acc.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_AccMouseReleased(evt);
   }
  });
  Tbl_Acc.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_AccKeyReleased(evt);
   }
  });
  jScrollPane7.setViewportView(Tbl_Acc);

  TA_AccInfoDetail.setEditable(false);
  TA_AccInfoDetail.setBackground(new java.awt.Color(204, 255, 204));
  TA_AccInfoDetail.setColumns(20);
  TA_AccInfoDetail.setLineWrap(true);
  TA_AccInfoDetail.setRows(1);
  TA_AccInfoDetail.setWrapStyleWord(true);
  jScrollPane8.setViewportView(TA_AccInfoDetail);

  TF_AccInfoBankPlatform.setEditable(false);
  TF_AccInfoBankPlatform.setBackground(new java.awt.Color(204, 255, 204));

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addComponent(Lbl_Acc)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(CB_AccViewBankPlatform)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_AccViewComment))
   .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
   .addComponent(jScrollPane8)
   .addComponent(TF_AccInfoBankPlatform)
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createSequentialGroup()
    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_AccViewComment)
     .addComponent(CB_AccViewBankPlatform)
     .addComponent(Lbl_Acc))
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_AccInfoBankPlatform, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Panel_BioLayout = new javax.swing.GroupLayout(Panel_Bio);
  Panel_Bio.setLayout(Panel_BioLayout);
  Panel_BioLayout.setHorizontalGroup(
   Panel_BioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_BioLayout.setVerticalGroup(
   Panel_BioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_BioLayout.createSequentialGroup()
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("Biodata", Panel_Bio);

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("- - Kategori");

  jScrollPane10.setViewportView(List_Cat);

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel1)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 603, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
    .addComponent(jLabel1)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE))
  );

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setText("- - Tag");

  jScrollPane6.setViewportView(List_Tag);

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jLabel2)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane6)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addComponent(jLabel2)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout Panel_EtcLayout = new javax.swing.GroupLayout(Panel_Etc);
  Panel_Etc.setLayout(Panel_EtcLayout);
  Panel_EtcLayout.setHorizontalGroup(
   Panel_EtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Panel_EtcLayout.setVerticalGroup(
   Panel_EtcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_EtcLayout.createSequentialGroup()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  TabbedPane.addTab("Dll", Panel_Etc);

  TF_Name.setEditable(false);
  TF_Name.setBackground(new java.awt.Color(204, 255, 204));
  TF_Name.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N

  Lbl_Name.setText("Nama");

  TF_Birthday.setEditable(false);
  TF_Birthday.setBackground(new java.awt.Color(204, 255, 204));
  TF_Birthday.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N

  Lbl_Birthday.setText("Tanggal Lahir");

  TA_Comment.setEditable(false);
  TA_Comment.setBackground(new java.awt.Color(204, 255, 204));
  TA_Comment.setColumns(20);
  TA_Comment.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_Comment.setLineWrap(true);
  TA_Comment.setRows(1);
  TA_Comment.setWrapStyleWord(true);
  jScrollPane1.setViewportView(TA_Comment);

  Lbl_Comment.setText("Keterangan");

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_Birthday, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
     .addComponent(Lbl_Comment, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_Name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_Birthday)
     .addComponent(TF_Name)
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Name))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Birthday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Birthday))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(Lbl_Comment)
      .addGap(0, 0, Short.MAX_VALUE))
     .addComponent(jScrollPane1)))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(TabbedPane)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jSeparator1)
     .addComponent(TabbedPane, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 641, Short.MAX_VALUE)
     .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;

  initPrivGUIShow();

  fillComponentsWithSetVariables();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Tbl_AddrMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_AddrMouseReleased
  onSelectedRowAddrChanged(false);
 }//GEN-LAST:event_Tbl_AddrMouseReleased

 private void Tbl_AddrKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_AddrKeyReleased
  onSelectedRowAddrChanged(false);
 }//GEN-LAST:event_Tbl_AddrKeyReleased

 private void Tbl_ContKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ContKeyReleased
  onSelectedRowContChanged(false);
 }//GEN-LAST:event_Tbl_ContKeyReleased

 private void Tbl_ContMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ContMouseReleased
  onSelectedRowContChanged(false);
 }//GEN-LAST:event_Tbl_ContMouseReleased

 private void List_PicKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_PicKeyReleased
  onPicRowSelected(false);
 }//GEN-LAST:event_List_PicKeyReleased

 private void List_PicMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_List_PicMouseReleased
  onPicRowSelected(false);
 }//GEN-LAST:event_List_PicMouseReleased

 private void Tbl_AccKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_AccKeyReleased
  onSelectedRowAccChanged(false);
 }//GEN-LAST:event_Tbl_AccKeyReleased

 private void Tbl_AccMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_AccMouseReleased
  onSelectedRowAccChanged(false);
 }//GEN-LAST:event_Tbl_AccMouseReleased

 private void CB_AddrViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AddrViewCommentActionPerformed
  changeAddrViewByNormal();
 }//GEN-LAST:event_CB_AddrViewCommentActionPerformed

 private void CB_AddrViewCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AddrViewCityActionPerformed
  changeAddrViewByNormal();
 }//GEN-LAST:event_CB_AddrViewCityActionPerformed

 private void CB_ContViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ContViewCommentActionPerformed
  changeContViewByNormal();
 }//GEN-LAST:event_CB_ContViewCommentActionPerformed

 private void CB_ContViewContactTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ContViewContactTypeActionPerformed
  changeContViewByNormal();
 }//GEN-LAST:event_CB_ContViewContactTypeActionPerformed

 private void CB_AccViewCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AccViewCommentActionPerformed
  changeAccViewByNormal();
 }//GEN-LAST:event_CB_AccViewCommentActionPerformed

 private void CB_AccViewBankPlatformActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_AccViewBankPlatformActionPerformed
  changeAccViewByNormal();
 }//GEN-LAST:event_CB_AccViewBankPlatformActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JToggleButton CB_AccViewBankPlatform;
 private javax.swing.JToggleButton CB_AccViewComment;
 private javax.swing.JToggleButton CB_AddrViewCity;
 private javax.swing.JToggleButton CB_AddrViewComment;
 private javax.swing.JToggleButton CB_ContViewComment;
 private javax.swing.JToggleButton CB_ContViewContactType;
 private javax.swing.JLabel Lbl_Acc;
 private javax.swing.JLabel Lbl_Addr;
 private javax.swing.JLabel Lbl_Birthday;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_Cont;
 private javax.swing.JLabel Lbl_Name;
 private XList List_Cat;
 private XList List_Pic;
 private XList List_Tag;
 private javax.swing.JPanel Panel_Bio;
 private javax.swing.JPanel Panel_Etc;
 private javax.swing.JPanel Panel_Pic;
 private XImgBoxURL Pnl_Image;
 private javax.swing.JTextArea TA_AccInfoDetail;
 private javax.swing.JTextArea TA_AddrInfoDetail;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextArea TA_ContInfoDetail;
 private javax.swing.JTextField TF_AccInfoBankPlatform;
 private javax.swing.JTextField TF_AddrInfoCity;
 private javax.swing.JTextField TF_Birthday;
 private javax.swing.JTextField TF_ContInfoType;
 private javax.swing.JTextField TF_Name;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_Acc;
 private XTable Tbl_Addr;
 private XTable Tbl_Cont;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 private javax.swing.JSeparator jSeparator1;
 // End of variables declaration//GEN-END:variables
}
