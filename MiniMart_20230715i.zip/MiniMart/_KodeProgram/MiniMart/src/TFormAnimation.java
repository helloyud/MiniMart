public class TFormAnimation extends Thread{
  
 OFormAnimation Form;
 private boolean Stop;
 int Delay;
 int FirstDelay;

 TFormAnimation(OFormAnimation Form, int Delay, int FirstDelay){
  Stop=false;
  this.Form=Form;
  this.Delay=Delay;
  this.FirstDelay=FirstDelay;
 }

 public void run(){
  try{
   if(FirstDelay!=0){Thread.sleep(FirstDelay);}
   do{
    synchronized(this){
     if(Stop){break;}
     Form.animate();
    }
    if(Delay!=0){Thread.sleep(Delay);}
   }while(true);
  }
  catch(Exception E){}
 }
 
 public void terminate(){
  synchronized(this){Stop=true;}
 }
 
}