public class ODefMinMax {

 double Default;
 double Minimal;
 double Maximal;
 
 public ODefMinMax(){}
 public ODefMinMax(double Default, double Minimal, double Maximal) {
  this.Default = Default;
  this.Minimal = Minimal;
  this.Maximal = Maximal;
 }

}