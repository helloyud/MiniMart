import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;

public class OCsvStreamWriter extends OutputStreamWriter {
 
 /*
  - Compatible with RFC-4180
  - Field Delimiter = "
  - Fields Separator = ,
  - Records Separator = \n
  - Charset = UTF-8
 */
 
 char FieldDelimiter;
 char FieldsSeparator;
 char RecordsSeparator;
 
 //
 public OCsvStreamWriter(OutputStream os,
  char FieldDelimiter, char FieldsSeparator, char RecordsSeparator) throws UnsupportedEncodingException{
  super(os, CCore.CsvDefaultCharset);
  setSeparatorChar(FieldDelimiter, FieldsSeparator, RecordsSeparator);
  RecordsSeparator=CCore.CsvDefaultRecordsSeparator;
 }
 
 //
 public void setSeparatorChar(char FieldDelimiter, char FieldsSeparator, char RecordsSeparator){
  this.FieldDelimiter=FieldDelimiter;
  this.FieldsSeparator=FieldsSeparator;
  this.RecordsSeparator=RecordsSeparator;
 }
 
 //
 public void writeRecordsSeparator() throws IOException{
  write(RecordsSeparator);
 }
 public void writeFieldsSeparator() throws IOException{
  write(FieldsSeparator);
 }
 public void writeNull() throws IOException{
  write(delimite(""));
 }
 public void writeBoolean(boolean value) throws IOException{
  write(delimite(PText.getString(value, CCore.vTrueIndonesia, CCore.vFalseIndonesia)));
 }
 public void writeInt(int value) throws IOException{
  write(delimite(String.valueOf(value)));
 }
 public void writeLong(long value) throws IOException{
  write(delimite(String.valueOf(value)));
 }
 public void writeDouble(double value) throws IOException{
  write(delimite(PText.doubleToString(value, true)));
 }
 public void writeChar(char value) throws IOException{
  write(delimite(String.valueOf(value)));
 }
 public void writeString(String value) throws IOException{
  write(delimite(localizeText(value)));
 }
 public void writeDate(Date value) throws IOException{
  write(delimite(PText.dateToString(value, 1)));
 }
 public void writeObject(Object value, int Type) throws IOException{
  if(value==null){writeNull();}
  else{
   switch(Type){
    case CCore.TypeBoolean : writeBoolean((Boolean)value); break;
    case CCore.TypeInteger : writeInt((Integer)value); break;
    case CCore.TypeLong : writeLong((Long)value); break;
    case CCore.TypeDouble : writeDouble((Double)value); break;
    case CCore.TypeChar : writeChar((Character)value); break;
    case CCore.TypeString : writeString((String)value); break;
    case CCore.TypeDate : writeDate((Date)value); break;
    default : break;
   }
  }
 }
 
 //
 private String delimite(String Field){
  return FieldDelimiter+Field+FieldDelimiter;
 }
 private String localizeText(String Txt){
  String ret=Txt;
  StringBuilder strb;
  boolean change;
  int temp, size;
  char ch;
  
  if(Txt==null){return "";}
  
  size=Txt.length();
  if(size==0){return ret;}
  
  change=false;
  strb=new StringBuilder();
  temp=0;
  do{
   ch=Txt.charAt(temp);
   do{
    if(ch==FieldDelimiter){change=true; strb.append(String.valueOf(FieldDelimiter)+String.valueOf(FieldDelimiter)); break;}
    if(PText.isLineBreak(ch)){change=true; strb.append('~'); break;}
    strb.append(ch);
   }while(false);
   temp=temp+1;
  }while(temp!=size);
  if(change){ret=strb.toString();}
  
  return ret;
 }
 
}