import java.sql.ResultSetMetaData;
import java.util.Vector;
import java.util.Date;
import javax.swing.table.AbstractTableModel;

class OCustomTableModel extends AbstractTableModel
 implements OCustomModel{

 public static final int ShowOptionNormal=0;
 public static final int ShowOptionObject=1;
 
 OCustomModelCommon Mdl;

 // set
 String[] ColumnsName;
 int[] ColumnsVisible;
 int[] ColumnsShowOption;
 
 boolean[] ColumnsEditable;
 
 boolean DisplayData;
 
 int ColumnsVisibleCount;
 
 Integer IntegerType;
 Long LongType;
 Double DoubleType;
 Boolean BooleanType;
 Date DateType;
 String StringType;
 
 // constructor
 public OCustomTableModel(){
  init(false, false, false, false, -1);
 }
 public OCustomTableModel(boolean EnableCheck, boolean CheckDefaultNewValue, boolean CheckEditable){
  init(EnableCheck, CheckDefaultNewValue, CheckEditable, false, -1);
 }
 public OCustomTableModel(boolean EnableCheck, boolean CheckDefaultNewValue, boolean CheckEditable, boolean EnableIndex, int IndexColumn){
  init(EnableCheck, CheckDefaultNewValue, CheckEditable, EnableIndex, IndexColumn);
 }
 void init(boolean EnableCheck, boolean CheckDefaultNewValue, boolean CheckEditable, boolean EnableIndex, int IndexColumn){
  IntegerType=new Integer(0);
  LongType=new Long(0);
  DoubleType=new Double(0);
  BooleanType=new Boolean(false);
  DateType=new Date();
  StringType=new String("");
  
  Mdl=new OCustomModelCommon();
  Mdl.init(this, EnableCheck, CheckDefaultNewValue, CheckEditable, EnableIndex, IndexColumn);
  
  DisplayData=true;
 }
 
 // metadata methods
 void setColumnsInfo(String[] ColumnsName_, int[] ColumnsType_, int[] ColumnsShowOption_, int[] ColumnsVisible_, boolean[] ColumnsEditable_){
  ColumnsName=ColumnsName_;
  Mdl.ColumnsType=ColumnsType_;
  Mdl.ColumnsCount=ColumnsName.length;
  ColumnsShowOption=ColumnsShowOption_;
  ColumnsVisible=ColumnsVisible_;
  ColumnsVisibleCount=ColumnsVisible.length;
  ColumnsEditable=ColumnsEditable_;
 }
 void setColumnsInfo(String[] ColumnsName_, int[] ColumnsType_, int[] ColumnsShowOption_, int[] ColumnsVisible_){
  int colcount=ColumnsName_.length;
  setColumnsInfo(ColumnsName_, ColumnsType_, ColumnsShowOption_, ColumnsVisible_, PCore.newBooleanArray(colcount, false));
 }
 void setColumnsInfo(String[] ColumnsName_, int[] ColumnsType_, int[] ColumnsVisible_){
  int colcount=ColumnsName_.length;
  setColumnsInfo(ColumnsName_, ColumnsType_, PCore.newIntegerArray(colcount, ShowOptionNormal), ColumnsVisible_);
 }
 void updateColumnsInfo(String[] ColumnsName_, int[] ColumnsType_, int[] ColumnsShowOption_, int[] ColumnsVisible_, boolean[] ColumnsEditable_, boolean RemoveData){
  if(RemoveData){removeAll();}
  setColumnsInfo(ColumnsName_, ColumnsType_, ColumnsShowOption_, ColumnsVisible_, ColumnsEditable_);
  fireTableStructureChanged();
 }
 void updateColumnsInfo(String[] ColumnsName_, int[] ColumnsType_, int[] ColumnsShowOption_, int[] ColumnsVisible_, boolean RemoveData){
  int colcount=ColumnsName_.length;
  updateColumnsInfo(ColumnsName_, ColumnsType_, ColumnsShowOption_, ColumnsVisible_, PCore.newBooleanArray(colcount, false), RemoveData);
 }
 void updateColumnsInfo(String[] ColumnsName_, int[] ColumnsType_, int[] ColumnsVisible_, boolean RemoveData){
  int colcount=ColumnsName_.length;
  updateColumnsInfo(ColumnsName_, ColumnsType_, PCore.newIntegerArray(colcount, ShowOptionNormal), ColumnsVisible_, RemoveData);
 }
 public void updateColumnsInfo(ResultSetMetaData RsM) throws Exception{
  String[] ColumnsName_;
  int[] ColumnsType_;
  int[] ColumnsShowOption_;
  int[] ColumnsVisible_;
  boolean[] ColumnsEditable_;
  int temp, temp_;
  removeAll();
  temp=RsM.getColumnCount();
  ColumnsName_=new String[temp];
  ColumnsType_=new int[temp];
  ColumnsShowOption_=PCore.newIntegerArray(temp, ShowOptionNormal);
  ColumnsVisible_=new int[temp];
  ColumnsEditable_=PCore.newBooleanArray(temp, false);
  temp_=0;
  do{
   ColumnsName_[temp_]=RsM.getColumnLabel(temp_+1);
   ColumnsType_[temp_]=PDatabase.convertJavaSQLDataTypeToMyType(RsM, temp_+1);
   ColumnsVisible_[temp_]=temp_;
   temp_=temp_+1;
  }while(temp_!=temp);
  setColumnsInfo(ColumnsName_, ColumnsType_, ColumnsShowOption_, ColumnsVisible_, ColumnsEditable_);
  fireTableStructureChanged();
 }
 void emptyColumnsInfo(){
  String[] ColumnsName_=new String[0];
  int[] ColumnsType_=new int[0];
  int[] ColumnsShowOption_=PCore.newIntegerArray(0, ShowOptionNormal);
  int[] ColumnsVisible_=new int[0];
  boolean[] ColumnsEditable_=PCore.newBooleanArray(0, false);
  removeAll();
  setColumnsInfo(ColumnsName_, ColumnsType_, ColumnsShowOption_, ColumnsVisible_, ColumnsEditable_);
  fireTableStructureChanged();
 }
 
 // Mdl methods
 public int getColumnsCount(){return Mdl.getColumnsCount();}
 public int[] getColumnsType(){return Mdl.getColumnsType();}
 
 public Vector<Object[]> getRows(){return Mdl.getRows();}

 public void insert_(int RowIndex, Object[] NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.insert_(RowIndex, NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void insert(int RowIndex, Object[] NewRow, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.insert(RowIndex, NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void insert(int RowIndex, Object[] NewRow){Mdl.insert(RowIndex, NewRow);}
 public void append_(Object[] NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append_(NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append(NewRow, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Object[] NewRow){Mdl.append(NewRow);}
 public void append(Vector<Object[]> NewData, int Data_AddMode, int[] Data_ByCustomCols, int Check_AddMode, boolean Check_ByValue, int Check_ByDataCol){
  Mdl.append(NewData, Data_AddMode, Data_ByCustomCols, Check_AddMode, Check_ByValue, Check_ByDataCol);
 }
 public void append(Vector<Object[]> NewData){Mdl.append(NewData);}
 public void remove_(int RowIndex){Mdl.remove_(RowIndex);}
 public void remove(int RowIndex){Mdl.remove(RowIndex);}
 public void remove(int[] RowsIndex){Mdl.remove(RowsIndex);}
 public void remove(int[] RowsIndex, boolean[] IsRemove){Mdl.remove(RowsIndex, IsRemove);}
 public void removeAll(){Mdl.removeAll();}
 public void changeValue_(int RowIndex, Object[] NewValue){Mdl.changeValue_(RowIndex, NewValue);}
 public void changeValue(int RowIndex, Object[] NewValue){Mdl.changeValue(RowIndex, NewValue);}
 
 public Vector<Object[]> subData(int[] Columns, int[] SelectedRows){return Mdl.subData(Columns, SelectedRows);}
 public Object[] getObjects(int Column, int[] SelectedRows){return Mdl.getObjects(Column, SelectedRows);}
 public long[] getIds(int Column, int[] SelectedRows){return Mdl.getIds(Column, SelectedRows);}
 
 public boolean isCheckable(){return Mdl.isCheckable();}
 public Vector<Boolean> getCheckList(){return Mdl.getCheckList();}
 public Vector<Boolean> getCheckList(int[] Rows){return Mdl.getCheckList(Rows);}
 public boolean getCheckDefaultNewValue(){return Mdl.getCheckDefaultNewValue();}
 public int getCheckedCount(){return Mdl.getCheckedCount();}
 public void setCheckedCount(int CheckedCount){Mdl.setCheckedCount(CheckedCount);}
 public void addCheckedCount(int AddValue, boolean IsAdd){Mdl.addCheckedCount(AddValue, IsAdd);}
 public boolean getChecked(int RowIndex){return Mdl.getChecked(RowIndex);}
 public int[] getChecked(boolean Value){return Mdl.getChecked(Value);}
 public int[] getChecked(int[] RowsIndex, boolean Value){return Mdl.getChecked(RowsIndex, Value);}
 public long[] getCheckedLong(int Column){return Mdl.getCheckedLong(Column);}
 public boolean setChecked(int RowIndex, boolean Chk){return Mdl.setChecked(RowIndex, Chk);}
 public int[] setChecked(int[] Indices, boolean Chk){return Mdl.setChecked(Indices, Chk);}
 public int[] checkAll(boolean CheckValue){return Mdl.checkAll(CheckValue);}
 public Object[] check(long[] Data, int Column, int[] RangeRows, int IfFound_AddRowMode, boolean IfFound_IsUpdate, boolean IfFound_UpdateValue,
  int IfNotFound_AddRowMode, boolean IfNotFound_IsUpdate, boolean IfNotFound_UpdateValue){
  return Mdl.check(Data, Column, RangeRows, IfFound_AddRowMode, IfFound_IsUpdate, IfFound_UpdateValue,
   IfNotFound_AddRowMode, IfNotFound_IsUpdate, IfNotFound_UpdateValue);
 }
 public int[] check(long[] Data, boolean Chk, int Column){
  return Mdl.check(Data, Chk, Column);
 }
 
 // GUI methods
 public int convertColumnIndexFromViewToModel(int ViewIndex){
  int ColIndex=ViewIndex;
  if(Mdl.EnableCheck){
   if(ColIndex==0){return -1;}
   ColIndex=ColIndex-1;
  }
  return ColumnsVisible[ColIndex];
 }
 public boolean isCellEditable(int rowIndex, int columnIndex){
  int ColIndex=columnIndex;
  if(Mdl.EnableCheck){
   if(ColIndex==0){return Mdl.CheckEditable;}
   ColIndex=ColIndex-1;
  }
  return ColumnsEditable[ColumnsVisible[ColIndex]];
 }
 public Class<?> getColumnClass(int ColumnIndex) {
  Class<?> c=Object.class;
  int ColIndex, ColVisible;
  do{
   
   ColIndex=ColumnIndex;
   
   if(Mdl.EnableCheck){
    if(ColIndex==0){c=BooleanType.getClass(); break;}
    ColIndex=ColIndex-1;
   }
   
   ColVisible=ColumnsVisible[ColIndex];
   
   if(ColumnsShowOption[ColVisible]==ShowOptionObject){break;}
   
   switch(Mdl.ColumnsType[ColVisible]){
    case CCore.TypeString   : c=StringType.getClass(); break;
    case CCore.TypeInteger  : c=IntegerType.getClass(); break;
    case CCore.TypeLong     : c=LongType.getClass(); break;
    case CCore.TypeDouble   : c=DoubleType.getClass(); break; 
    case CCore.TypeBoolean  : c=BooleanType.getClass(); break;
    case CCore.TypeDate     : c=DateType.getClass(); break;
   }
  
  }while(false);
  return c;
 }
 public int getColumnCount(){
  int temp=0;
  if(Mdl.EnableCheck){temp=temp+1;}
  return ColumnsVisibleCount+temp;
 }
 public String getColumnName(int ColumnIndex){
  String ret=null;
  String ColName=null;
  boolean IsEditable=false;
  int ColIndex=ColumnIndex;
  int ColVisible;
  
  do{
   if(Mdl.EnableCheck){
    if(ColIndex==0){ColName=""; IsEditable=Mdl.CheckEditable; break;}
    ColIndex=ColIndex-1;
   }
   ColVisible=ColumnsVisible[ColIndex];
   ColName=ColumnsName[ColVisible];
   IsEditable=ColumnsEditable[ColVisible];
  }while(false);
   
  ret=ColName;
  if(IsEditable){ret="*"+ret;}
  
  return ret;
 }
 public int getRowCount(){
  return getSize();
 }
 public Object getValueAt(int RowIndex, int ColumnIndex){
  int ColIndex=ColumnIndex;
  if(Mdl.EnableCheck){
   if(ColIndex==0){return Mdl.Checked.elementAt(RowIndex);}
   ColIndex=ColIndex-1;
  }
  return Mdl.Rows.elementAt(RowIndex)[ColumnsVisible[ColIndex]];
 }
 public void setValueAt(Object NewValue, int RowIndex, int ColumnIndex){
  int ColIndex=ColumnIndex;
  Boolean bool;
  if(Mdl.EnableCheck){
   if(ColIndex==0){
    bool=Mdl.CheckDefaultNewValue; if(NewValue!=null){if(NewValue instanceof Boolean){bool=(Boolean)NewValue;}}
    if(Mdl.Checked.elementAt(RowIndex)!=bool){
     if(bool){Mdl.CheckedCount=Mdl.CheckedCount+1;}
     else{Mdl.CheckedCount=Mdl.CheckedCount-1;}
     Mdl.Checked.setElementAt(bool, RowIndex);
					refreshCellUpdated(RowIndex, ColumnIndex);
    }
    return;
   }
   ColIndex=ColIndex-1;
  }
  Mdl.Rows.elementAt(RowIndex)[ColumnsVisible[ColIndex]]=NewValue;
  refreshCellUpdated(RowIndex, ColumnIndex);
 }
 public int getSize(){
  int ret=0;
  if(DisplayData){ret=ret+Mdl.Rows.size();}
  return ret;
 }
 public void fireTableRowsInserted(int StartIndex, int EndIndex){
  if(!DisplayData){return;}
  super.fireTableRowsInserted(StartIndex, EndIndex);
 }
 public void fireTableRowsUpdated(int StartIndex, int EndIndex){
  if(!DisplayData){return;}
  super.fireTableRowsUpdated(StartIndex, EndIndex);
 }
 public void fireTableRowsDeleted(int StartIndex, int EndIndex){
  if(!DisplayData){return;}
  super.fireTableRowsDeleted(StartIndex, EndIndex);
 }
 public void fireTableCellUpdated(int RowIndex, int ColumnIndex){
  if(!DisplayData){return;}
  super.fireTableCellUpdated(RowIndex, ColumnIndex);
 }
 public void refreshInsert(int StartIndex, int EndIndex){fireTableRowsInserted(StartIndex, EndIndex);}
 public void refreshUpdate(int StartIndex, int EndIndex){fireTableRowsUpdated(StartIndex, EndIndex);}
 public void refreshRemove(int StartIndex, int EndIndex){fireTableRowsDeleted(StartIndex, EndIndex);}
 public void refreshCellUpdated(int RowIndex, int ColumnIndex){fireTableCellUpdated(RowIndex, ColumnIndex);}
 public void changeDisplay(boolean DisplayData_){
  int count;
  
  if(DisplayData==DisplayData_){
   return;
  }
  
  // clear current display
  count=getSize();
  if(count!=0){
   DisplayData=false;
   super.fireTableRowsDeleted(0, count-1);
  }
  
  // update current display
  DisplayData=DisplayData_;
  count=getSize();
  if(count!=0){
   super.fireTableRowsInserted(0, count-1);
  }
 }
 
}