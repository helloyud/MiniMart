import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Vector;

public class OPrintGeneratorConverting extends OPrintGenerator{

 // additional printing properties
 LinkedList<Long> Id;
 int OrderMode;
 boolean OptList_Item;
 boolean OptList_ItemCategorized;
 
 //
 /*
    CurrOperation :

    21 rule main,
    31 rule item-in's header, 32 rule item-in's category header, 33 rule item-in's list,
    41 rule item-out's header, 42 rule item-out's category header, 43 rule item-out's list
 */
 final int Op_Main=21;
 final int Op_ItemIn_Header=31; final int Op_ItemIn_CategoryHeader=32; final int Op_ItemIn_List=33;
 final int Op_ItemOut_Header=41; final int Op_ItemOut_CategoryHeader=42; final int Op_ItemOut_List=43;
 
 String DbItemIn, DbItemOut;
 String IdQ;
 int CurrOperation;
 ODrawTableRow TableNewRow, TableNewRow2, TableNewRow3;
 Statement Stm2; ResultSet Rs2;
 OQuickListOfLong PrintedItems;
 
 // Main Header
 VDrawTable Table_MainHeader;
 
 // Main List
 VDrawTable Table_Main;
 
 final int PointOfMainCharCount=2;
 final String PointOfMain="*";
 
  // Query
 String Query_WithoutOrderBy;
 String Query_OrderBy;
 String Query_TbHaving;
 
  // Record
 int[] Record_ColType;
 int Record_ColCount;
 int Record_Col_ConvId, Record_Col_Date, Record_Col_ReasonId, Record_Col_ReasonName, Record_Col_RuleId, Record_Col_RuleName,
  Record_Col_RuleDirection, Record_Col_RuleCount, Record_Col_ItemOutCount, Record_Col_ItemInCount;
 
 boolean NextRecord;
 Object[] CurrRecord, BefRecord;
 
  // Table
 OInset Inset;
 int[] Table_Cols;
 
 final int Table_ColId_ConvPoint=0;
 final int Table_ColId_ConvDateOrder=1;
 final int Table_ColId_ConvDate=2;
 final int Table_ColId_ConvReasonOrder=3;
 final int Table_ColId_ConvReason=4;
 final int Table_ColId_ConvRuleOrder=5;
 final int Table_ColId_ConvRule=6;
 final int Table_ColId_ConvRuleDirection=7;
 final int Table_ColId_ConvRuleCount=8;
 
  // Ordering
 VLong NumberOfOrderDate; VBoolean FirstOrderDate;
 VLong NumberOfOrderReason; VBoolean FirstOrderReason;
 VLong NumberOfOrderRule; VBoolean FirstOrderRule;
 
 Vector<VLong> Order_Number;
 Vector<VBoolean> Order_First;
 Vector<Integer> Order_RecordCol;
 
 // Main Info
 long CurrMain_Id;
 int CurrMain_InfoItemInCount;
 int CurrMain_InfoItemOutCount;
 
 // List Items
 VDrawTable Table_ListItem, Table_ListItemCategoryHeader;
 
 int ItemIdsCount;
 String ItemIdsStr;
 
 Vector<OIdName> ItemCategories;
 int ItemCurrCategory;
 
 Vector<Object[]> ItemList;
 int ItemListItemCount;
 int ItemListCurrItem;
 
 //
 final int PointOfListCharCount=2;
 final String PointOfListItemOut=">";
 final String PointOfListItemIn="<";
 final String PointOfListCategory="+";
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 final int ColSizeNumberOfOrder=6;
 final int ColSizeConvDate=10;
 final int ColSizeConvReason=17;
 final int ColSizeRuleDirection=5;
 final int ColSizeRuleCount=7;
 final int ColSizeItemQty=7;
 final int ColSizeItemStockUnit=10;
 final int ColSizeTextMin=10;
 final int ColSizeTextMed=20;
 final int ColSizeTextMax=30;
 final String NumberOfOrder_Dot=".";
 double PostTextAddLineSpacing, ItemCategoryAddLineSpacing;
 double MainToDetailAddLineSpacing;
 double TableListXIndent;
 int MaxCharList;
 double CellAreaMinHeight;
 boolean EnablePreAddLineSpacing, EnablePostAddLineSpacing;
 
 OPrintGeneratorConverting(OFont FontStandard) {
  super(FontStandard);
  
  Table_Main=new VDrawTable(); Table_MainHeader=new VDrawTable();
  Table_ListItem=new VDrawTable(); Table_ListItemCategoryHeader=new VDrawTable();
  
  NumberOfOrderDate=new VLong(); FirstOrderDate=new VBoolean();
  NumberOfOrderReason=new VLong(); FirstOrderReason=new VBoolean();
  NumberOfOrderRule=new VLong(); FirstOrderRule=new VBoolean();
 }
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> Id,
  
  int OrderMode,
  boolean OptList_Item, boolean OptList_ItemCategorized){
  
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.Id=Id;
  
  this.OrderMode=OrderMode;
  this.OptList_Item=OptList_Item;
  this.OptList_ItemCategorized=OptList_ItemCategorized;
 }
 
 // standard private methods
	protected boolean hasHeader(){return true;}
 protected boolean hasFooter(){return true;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.5f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(7.5f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  CellAreaMinHeight=NormalHeight;
  Inset=new OInset(0.2*FontHeight, 0.2*FontHeight, 0.7*FontWidth, 0.7*FontWidth);
  PostTextAddLineSpacing=0.2*FontHeight;
  ItemCategoryAddLineSpacing=0.6*FontHeight;
 }
 protected void prepareFirstPageData() throws Exception{
  ODrawTableColumnMetadata[] Columns;
  ODrawTableColumnMetadata Column=null;
  int temp, column_resize;
  double temp_d, TableListWidth;
  ODrawTable tbl;
  
  //
  DbItemOut="ConvXItemOut";
  DbItemIn="ConvXItemIn";
  
  Stm2=Stm.getConnection().createStatement();
  
  saveId();
  BefRecord=null;
  
  //
  initVar_All();
  
  // Main
  Columns=new ODrawTableColumnMetadata[Table_Cols.length];
  temp=0; column_resize=-1;
  do{
   switch(Table_Cols[temp]){
    case Table_ColId_ConvPoint : Column=new ODrawTableColumnMetadata(null, PointOfListCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvDateOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvDate : Column=new ODrawTableColumnMetadata("Tanggal", ColSizeConvDate*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvReasonOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvReason : Column=new ODrawTableColumnMetadata("Alasan", ColSizeConvReason*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvRuleOrder : Column=new ODrawTableColumnMetadata(null, ColSizeNumberOfOrder*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvRule : Column=new ODrawTableColumnMetadata("Aturan", 0); column_resize=temp; break;
    case Table_ColId_ConvRuleDirection : Column=new ODrawTableColumnMetadata("Arah", ColSizeRuleDirection*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
    case Table_ColId_ConvRuleCount : Column=new ODrawTableColumnMetadata("Jumlah", ColSizeRuleCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight)); break;
   }
   Columns[temp]=Column;
   temp=temp+1;
  }while(temp!=Table_Cols.length);
  if(column_resize==-1){throw new Exception();}
  temp_d=ColumnarWidth-PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)>temp_d){throw new Exception();}
  Columns[column_resize].Width=temp_d;
  
  Table_Main.Value=new ODrawTable(Columns, Inset, (ODrawTableBorder)PCore.subtituteBool(!OptList_Item, ODrawTableBorder.DefaultFillAll, ODrawTableBorder.DefaultFillEmpty));
  
  Table_MainHeader.Value=Table_Main.Value.createNewTable();
  Table_MainHeader.Value.insertARow(0, Table_MainHeader.Value.getRowHeader(FontType, LineSpacing,
   new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalCenter), false, 1, true, 0, true, 1.0, 1, '~'));
  Table_MainHeader.Value.Border=ODrawTableBorder.DefaultFillEmpty;
  
  // Main Detail
  MainToDetailAddLineSpacing=0.3*FontHeight;
  
  TableListXIndent=Table_Main.Value.Columns[0].Width;
  TableListWidth=ColumnarWidth-TableListXIndent;
  MaxCharList=(int)(TableListWidth/FontWidth);
  
   // List Item Out - In
  Columns=new ODrawTableColumnMetadata[3+1];
  Columns[0]=new ODrawTableColumnMetadata(null, PointOfListCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[1]=new ODrawTableColumnMetadata("Barang", 0);
  Columns[2]=new ODrawTableColumnMetadata("Qty", ColSizeItemQty*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[3]=new ODrawTableColumnMetadata("Satuan", ColSizeItemStockUnit*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)+temp_d>TableListWidth){throw new Exception();}
  Columns[1].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillAll);
  Table_ListItem.Value=tbl.createNewTable();
  
  Columns=new ODrawTableColumnMetadata[1];
  Columns[0]=new ODrawTableColumnMetadata("Kategori", 0);
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  Columns[0].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillEmpty);
  Table_ListItemCategoryHeader.Value=tbl.createNewTable();
  
  // doing the first operation
  preInitLayoutVarDefault();
  queryMain(); if(!getNextMain()){throw new Exception();}
  CurrOperation=Op_Main;
  postInitLayoutVarDefault();
 }
 protected void addHeader() throws Exception{
  DrawComponents.add(new ODrawComponentTable(0, CurrY, Table_MainHeader.Value));
  CurrY=CurrY+Table_MainHeader.Value.Height;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  CurrY=CurrY+HeaderAddLineSpacing;
 }
 protected boolean addColumnar() throws Exception{
  VBoolean KeepPrinting=new VBoolean(true);
  VBoolean CloseTable=new VBoolean();
  VDrawTable CurrTable=null;
  boolean processed;
  double PreAddLineSpacing, PostAddLineSpacing;
  Vector<String> Words=null;
  double Pos_X=0;
  double Pos_Y=0;
  double WordsBox_Width=0;
  double WordsBox_Height=0;
  OAlignment WordsBox_Alignment=null;
  OAlignment WordsBox_AlignmentDefault=new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop);
  
  do{
   
   do{
    // Operation without check
    PreAddLineSpacing=0; PostAddLineSpacing=PostTextAddLineSpacing;
    Pos_X=BaseX;
    WordsBox_Alignment=WordsBox_AlignmentDefault;
    
    processed=true;
    do{
     if(CurrOperation==Op_ItemOut_Header){
      PreAddLineSpacing=MainToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Barang Keluar { Jumlah : "+PText.intToString(CurrMain_InfoItemOutCount)+" }",
       MaxCharList, true, MaxCharList-1, 1, '~'));
      WordsBox_Width=Table_ListItem.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     if(CurrOperation==Op_ItemIn_Header){
      PreAddLineSpacing=MainToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Barang Masuk { Jumlah : "+PText.intToString(CurrMain_InfoItemInCount)+" }",
       MaxCharList, true, MaxCharList-1, 1, '~'));
      WordsBox_Width=Table_ListItem.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     
     processed=false;
    }while(false);
    if(processed){
     if(IsANewColumnar){IsANewColumnar=false;}
     else{if(EnablePreAddLineSpacing){CurrY=CurrY+PreAddLineSpacing;}}
     
     Pos_Y=BaseY+CurrY;
     WordsBox_Height=Words.size()*NormalHeight;
     
     DrawComponents.add(new ODrawComponentText(Pos_X, Pos_Y, FontType, Words, WordsBox_Width, WordsBox_Height, LineSpacing, WordsBox_Alignment));

     CurrY=CurrY+WordsBox_Height; if(EnablePostAddLineSpacing){CurrY=CurrY+PostAddLineSpacing;}
     
     processNextOperation(KeepPrinting, CloseTable, 0);
     
     break;
    }
    
    // Operation with check
    PreAddLineSpacing=0; PostAddLineSpacing=0;
    Pos_X=BaseX;
    
    processed=true;
    do{
     if(CurrOperation==Op_Main){CurrTable=Table_Main; break;}
     
     if(CurrOperation==Op_ItemIn_CategoryHeader){CurrTable=Table_ListItemCategoryHeader; Pos_X=Pos_X+TableListXIndent; PreAddLineSpacing=ItemCategoryAddLineSpacing; break;}
     if(CurrOperation==Op_ItemIn_List){CurrTable=Table_ListItem; Pos_X=Pos_X+TableListXIndent; break;}
     
     if(CurrOperation==Op_ItemOut_CategoryHeader){CurrTable=Table_ListItemCategoryHeader; Pos_X=Pos_X+TableListXIndent; PreAddLineSpacing=ItemCategoryAddLineSpacing; break;}
     if(CurrOperation==Op_ItemOut_List){CurrTable=Table_ListItem; Pos_X=Pos_X+TableListXIndent; break;}
     
     processed=false;
    }while(false);
    if(processed){
     if(IsANewColumnar){IsANewColumnar=false;}
     else{if(EnablePreAddLineSpacing){CurrY=CurrY+PreAddLineSpacing;}}
     
     Pos_Y=BaseY+CurrY;
     
     CurrTable.Value.insertARow(CurrTable.Value.Rows.size(), TableNewRow);
     
     processNextOperation(KeepPrinting, CloseTable, CurrTable.Value.Height);
     
     if(CloseTable.Value){
      DrawComponents.addElement(new ODrawComponentTable(Pos_X, Pos_Y, CurrTable.Value));
      CurrY=CurrY+CurrTable.Value.Height; if(EnablePostAddLineSpacing){CurrY=CurrY+PostAddLineSpacing;}
      CurrTable.Value=CurrTable.Value.createNewTable();
     }
     
     break;
    }
   }while(false);
   
   if(!KeepPrinting.Value){break;}
   
  }while(KeepPrinting.Value);
		return false;
 }
 void preInitLayoutVarDefault(){
  EnablePreAddLineSpacing=true;
  EnablePostAddLineSpacing=true;
 }
 void postInitLayoutVarDefault(){
  if(TableNewRow==null){TableNewRow=TableNewRow2;}
 }
 void processNextOperation(VBoolean KeepPrinting, VBoolean CloseTable, double CurrDrawComponentHeight) throws Exception{
  double NextDrawComponentHeight;
  int BefOp;
  
  NextDrawComponentHeight=0;
  BefOp=CurrOperation;
  CloseTable.Value=false;
  TableNewRow=null;
  
  preInitLayoutVarDefault();
  
  do{
   
   // List Items Out
   if(OptList_Item){
    // from ... next to 'list_item_out_header'
    if(CurrOperation==Op_Main){
     preparePrintItem(true);
     if(OptList_ItemCategorized){
      prepareItemCategorized(true);
      if(getItemNextCategory(true)){
       CurrOperation=Op_ItemOut_Header; EnablePostAddLineSpacing=false;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
     else{
      queryItem(true);
      if(getNextItem(true)){
       CurrOperation=Op_ItemOut_Header;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
       break;
      }
     }
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_out_header' next to 'list_item_out_category_header'
     if(CurrOperation==Op_ItemOut_Header){CurrOperation=Op_ItemOut_CategoryHeader; TableNewRow=TableNewRow3; break;}
    }
    
    // from ... next to 'list_item_out_data'
    if(CurrOperation==Op_ItemOut_Header || CurrOperation==Op_ItemOut_CategoryHeader){
     CurrOperation=Op_ItemOut_List; break;
    }

    // from 'list_item_out_data' next to 'list_item_out_data'
    if(CurrOperation==Op_ItemOut_List){
     if(getNextItem(true)){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_out_category_summary' next to 'list_item_out_category_header'
     if(CurrOperation==Op_ItemOut_List){
      if(getItemNextCategory(true)){
       CurrOperation=Op_ItemOut_CategoryHeader; TableNewRow=TableNewRow3;
       NextDrawComponentHeight=ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
    }
   }
   
   // List Items In
   if(OptList_Item){
    // from ... next to 'list_item_in_header'
    if(CurrOperation==Op_Main || CurrOperation==Op_ItemOut_List){
     preparePrintItem(false);
     if(OptList_ItemCategorized){
      prepareItemCategorized(false);
      if(getItemNextCategory(false)){
       CurrOperation=Op_ItemIn_Header; EnablePostAddLineSpacing=false;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
     else{
      queryItem(false);
      if(getNextItem(false)){
       CurrOperation=Op_ItemIn_Header;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
       break;
      }
     }
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_in_header' next to 'list_item_in_category_header'
     if(CurrOperation==Op_ItemIn_Header){CurrOperation=Op_ItemIn_CategoryHeader; TableNewRow=TableNewRow3; break;}
    }
    
    // from ... next to 'list_item_in_data'
    if(CurrOperation==Op_ItemIn_Header || CurrOperation==Op_ItemIn_CategoryHeader){CurrOperation=Op_ItemIn_List; break;}

    // from 'list_item_in_data' next to 'list_item_in_data'
    if(CurrOperation==Op_ItemIn_List){
     if(getNextItem(false)){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_in_category_summary' next to 'list_item_in_category_header'
     if(CurrOperation==Op_ItemIn_List){
      if(getItemNextCategory(false)){
       CurrOperation=Op_ItemIn_CategoryHeader; TableNewRow=TableNewRow3;
       NextDrawComponentHeight=ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
    }
   }
   
   // from ... next to 'main'
   if(CurrOperation==Op_Main || CurrOperation==Op_ItemOut_List || CurrOperation==Op_ItemIn_List){
    if(!getNextMain()){KeepPrinting.Value=false; break;}
    CurrOperation=Op_Main;
    NextDrawComponentHeight=TableNewRow2.Height;
    break;
   }
  }while(false);
  
  postInitLayoutVarDefault();
  
  if(checkOverColumnarHeight(CurrDrawComponentHeight+NextDrawComponentHeight)){KeepPrinting.Value=false;}
  if(CurrOperation!=BefOp || KeepPrinting.Value==false){CloseTable.Value=true;}
 }
 protected void addFooter() throws Exception{
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  PText.fillStringToChars(TxtPage, "Hal. "+CurrPage, PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  if(!NextRecord){return false;}
  return true;
 }
 protected void clearVar(){
  Id=null;
  IdQ=null;
  ItemCategories=null;
  ItemIdsStr=null;
  ItemList=null;
  PrintedItems=null;
  TableNewRow=null;
  TableNewRow2=null;
  TableNewRow3=null;
  BefRecord=null;
  CurrRecord=null;
  Query_OrderBy=null;
  try{Rs2.close();}catch(Exception E){} Rs2=null;
  try{Stm2.close();}catch(Exception E){} Stm2=null;
 }
 
 // additional private methods
 
 // Main
 void saveId(){
  StringBuilder strb=new StringBuilder();
  strb=strb.append(Id.pop().toString());
  if(!Id.isEmpty()){
   do{
    strb=strb.append(","+Id.pop().toString());
   }while(!Id.isEmpty());
  }
  IdQ=strb.toString();
 }
 private void initVar_QueryAndRecord(){
  Query_WithoutOrderBy=
   "select tb4.Id, ConvDate, ReasonOfConv, ReasonOfConvName, "+
   "RuleOfConv, RuleOfConvName, IsActive, LastUpdate, "+
   "RuleOfConvDirection, RuleOfConvCount, ItemOutCount, Count(ConvXItemIn.Conv) as 'ItemInCount' from "+
    "(select tb3.*, Count(ConvXItemOut.Conv) as 'ItemOutCount' from "+
     "(select tb2.*, RuleOfConv.Name as 'RuleOfConvName', IsActive, LastUpdate from "+
      "(select tb1.*, ReasonOfConv.Name as 'ReasonOfConvName' from "+
       "(select Conv.* from Conv where Id in ("+IdQ+")) as tb1 "+
      "left join ReasonOfConv on tb1.ReasonOfConv=ReasonOfConv.Id) as tb2 "+
     "inner join RuleOfConv on tb2.RuleOfConv=RuleOfConv.Id) as tb3 "+
    "left join ConvXItemOut on tb3.Id=ConvXItemOut.Conv group by tb3.Id) as tb4 "+
   "left join ConvXItemIn on tb4.Id=ConvXItemIn.Conv group by tb4.Id";
  Query_TbHaving="tb4";
  
  Record_Col_ConvId=0;
  Record_Col_Date=1;
  Record_Col_ReasonId=2;
  Record_Col_ReasonName=3;
  Record_Col_RuleId=4;
  Record_Col_RuleName=5;
  Record_Col_RuleDirection=8;
  Record_Col_RuleCount=9;
  Record_Col_ItemOutCount=10;
  Record_Col_ItemInCount=11;
  
  Record_ColType=PCore.primArr(CCore.TypeLong, CCore.TypeDate, CCore.TypeInteger, CCore.TypeString,
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeDate,
   CCore.TypeBoolean, CCore.TypeDouble, CCore.TypeInteger, CCore.TypeInteger);
  Record_ColCount=Record_ColType.length;
 }
 private void initVar_Query_OrderBy(){
  StringBuilder strb;
  
  String Order_Date, Order_Reason, Order_Rule;
  
  strb=new StringBuilder();
  
  strb.append(" order by");
  
  Order_Date   = " ConvDate desc";
  Order_Reason = " ReasonOfConvName asc";
  Order_Rule   = " RuleOfConvName asc";
  switch(OrderMode){
   case 0 : strb.append(Order_Date+","+Order_Rule+","+Order_Reason); break;
   case 1 : strb.append(Order_Date+","+Order_Reason+","+Order_Rule); break;
   case 2 : strb.append(Order_Rule+","+Order_Date+","+Order_Reason); break;
   case 3 : strb.append(Order_Rule+","+Order_Reason+","+Order_Date); break;
   case 4 : strb.append(Order_Reason+","+Order_Date+","+Order_Rule); break;
   case 5 : strb.append(Order_Reason+","+Order_Rule+","+Order_Date); break;
  }
  strb.append(", "+Query_TbHaving+".Id desc");
  
  Query_OrderBy=strb.toString();
 }
 private void initVar_Table_Ordering(){
  final int Id_Date=1;
  final int Id_Reason=2;
  final int Id_Rule=3;
  int[] Cols=null;
  int temp;
  
  Order_Number=new Vector();
  Order_First=new Vector();
  Order_RecordCol=new Vector();
  
  switch(OrderMode){
   case 0 : Cols=PCore.primArr(Id_Date, Id_Rule, Id_Reason); break;
   case 1 : Cols=PCore.primArr(Id_Date, Id_Reason, Id_Rule); break;
   case 2 : Cols=PCore.primArr(Id_Rule, Id_Date, Id_Reason); break;
   case 3 : Cols=PCore.primArr(Id_Rule, Id_Reason, Id_Date); break;
   case 4 : Cols=PCore.primArr(Id_Reason, Id_Date, Id_Rule); break;
   case 5 : Cols=PCore.primArr(Id_Reason, Id_Rule, Id_Date); break;
  }
  
  temp=0;
  do{
   switch(Cols[temp]){
    case Id_Date    : Order_Number.addElement(NumberOfOrderDate); Order_First.addElement(FirstOrderDate); Order_RecordCol.addElement(Record_Col_Date); break;
    case Id_Reason  : Order_Number.addElement(NumberOfOrderReason); Order_First.addElement(FirstOrderReason); Order_RecordCol.addElement(Record_Col_ReasonId); break;
    case Id_Rule    : Order_Number.addElement(NumberOfOrderRule); Order_First.addElement(FirstOrderRule); Order_RecordCol.addElement(Record_Col_RuleId); break;
   }
   temp=temp+1;
  }while(temp!=Cols.length);
 }
 private void initVar_Table_Columns(){
  switch(OrderMode){
   case 0 : Table_Cols=PCore.primArr(Table_ColId_ConvPoint, Table_ColId_ConvDate, Table_ColId_ConvRule, Table_ColId_ConvReason, Table_ColId_ConvRuleDirection, Table_ColId_ConvRuleCount); break;
   case 1 : Table_Cols=PCore.primArr(Table_ColId_ConvPoint, Table_ColId_ConvDate, Table_ColId_ConvReason, Table_ColId_ConvRule, Table_ColId_ConvRuleDirection, Table_ColId_ConvRuleCount); break;
   case 2 : Table_Cols=PCore.primArr(Table_ColId_ConvPoint, Table_ColId_ConvRule, Table_ColId_ConvDate, Table_ColId_ConvReason, Table_ColId_ConvRuleDirection, Table_ColId_ConvRuleCount); break;
   case 3 : Table_Cols=PCore.primArr(Table_ColId_ConvPoint, Table_ColId_ConvRule, Table_ColId_ConvReason, Table_ColId_ConvDate, Table_ColId_ConvRuleDirection, Table_ColId_ConvRuleCount); break;
   case 4 : Table_Cols=PCore.primArr(Table_ColId_ConvPoint, Table_ColId_ConvReason, Table_ColId_ConvDate, Table_ColId_ConvRule, Table_ColId_ConvRuleDirection, Table_ColId_ConvRuleCount); break;
   case 5 : Table_Cols=PCore.primArr(Table_ColId_ConvPoint, Table_ColId_ConvReason, Table_ColId_ConvRule, Table_ColId_ConvDate, Table_ColId_ConvRuleDirection, Table_ColId_ConvRuleCount); break;
  }
 }
 private void initVar_All(){
  initVar_QueryAndRecord();
  initVar_Query_OrderBy();
  initVar_Table_Ordering();
  initVar_Table_Columns();
 }
 private void queryMain() throws Exception{
  Rs=Stm.executeQuery(Query_WithoutOrderBy+Query_OrderBy);
 }
 void resetOrder(int Index){
  int Idx=Index;
  
  Order_First.elementAt(Idx).Value=true;
  
  if(Idx==Order_First.size()-1){return;}
  
  Idx=Idx+1;
  Order_Number.elementAt(Idx).Value=1;
  resetOrder(Idx);
 }
 boolean isCurrRecordSameWithBefRecord(int OrderIndex) throws Exception{
  Integer ret;
  int RecordCol=Order_RecordCol.elementAt(OrderIndex);
  Object BefValue, CurrValue;
  
  BefValue=BefRecord[RecordCol]; CurrValue=CurrRecord[RecordCol];
  
  ret=PCore.grading(Record_ColType[RecordCol], null, CurrValue, true, null, BefValue, true, null);
  if(ret==null){throw new Exception();}
  
  return ret==0;
 }
 private void defineCurrMain() throws Exception{
  boolean IsSame;
  int temp, length;
  VLong OrderNum;
  
  // define curr main variables
  CurrMain_Id=PCore.objLong(CurrRecord[Record_Col_ConvId], -1L);
  CurrMain_InfoItemOutCount=PCore.objInteger(CurrRecord[Record_Col_ItemOutCount], 0);
  CurrMain_InfoItemInCount=PCore.objInteger(CurrRecord[Record_Col_ItemInCount], 0);
  
  // define order variables
  if(BefRecord==null){
   Order_Number.elementAt(0).Value=1;
   resetOrder(0);
   return;
  }
  
  temp=0; length=Order_First.size();
  do{
   IsSame=isCurrRecordSameWithBefRecord(temp);
   if(!IsSame){
    OrderNum=Order_Number.elementAt(temp);
    OrderNum.Value=OrderNum.Value+1;
    resetOrder(temp);
    break;
   }
   Order_First.elementAt(temp).Value=false;
   
   temp=temp+1;
  }while(temp!=length);
 }
 private boolean getNextMain() throws Exception{
  int insertpos;
  ODimension dim;
  
  NextRecord=Rs.next();
  if(!NextRecord){return false;}
  
  CurrRecord=new Object[Record_ColCount];
  PDatabase.fillResultSetToRow(Rs, CurrRecord, Record_ColType, false, null, null);
  
  defineCurrMain();
  BefRecord=CurrRecord;
  
  TableNewRow2=new ODrawTableRow(0, Table_Main.Value.ColumnsCount);
  
  TableNewRow2.setCell(0, new ODrawTableCellText(PointOfMain,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvDateOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderDate.Value || OptList_Item, PText.intToString(NumberOfOrderDate.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvDate, -1),
   new ODrawTableCellText(PText.getString(FirstOrderDate.Value || OptList_Item, PText.dateToString(PCore.objDate(CurrRecord[Record_Col_Date], null), 1), ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvReasonOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderReason.Value || OptList_Item, PText.intToString(NumberOfOrderReason.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvReason, -1),
   new ODrawTableCellText(PText.getString(FirstOrderReason.Value || OptList_Item, PText.getString(PCore.objString(CurrRecord[Record_Col_ReasonName], null), "Tdk didefenisikan", true), ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvRuleOrder, -1),
   new ODrawTableCellText(PText.getString(FirstOrderRule.Value || OptList_Item, PText.intToString(NumberOfOrderRule.Value)+NumberOfOrder_Dot, ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvRule, -1),
   new ODrawTableCellText(PText.getString(FirstOrderRule.Value || OptList_Item, PCore.objString(CurrRecord[Record_Col_RuleName], ""), ""),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvRuleDirection, -1),
   new ODrawTableCellText(PText.getString(PCore.objBoolean(CurrRecord[Record_Col_RuleDirection], true), CApp.ConvRuleDirForward, CApp.ConvRuleDirBackward),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  TableNewRow2.setCell(PCore.findAValueInArray(Table_Cols, Table_ColId_ConvRuleCount, -1),
   new ODrawTableCellText(PText.priceToString(PCore.objDouble(CurrRecord[Record_Col_RuleCount], -1D)),
    FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  insertpos=Table_Main.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_Main.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_Main.Value.Inset.InsetTop+Table_Main.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_Main.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_Main.Value.Inset.InsetTop+Table_Main.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_Main.Value, insertpos);
  }
  
  return true;
 }
 
 // Item
 private void preparePrintItem(boolean IsItemOut){
  PrintedItems=new OQuickListOfLong(1024, 1024, true, false);
 }
 private void getItemIds(boolean IsItemOut) throws Exception{
  StringBuilder strb;
  long ItemId;
  String DbItem=PText.getString(IsItemOut, DbItemOut, DbItemIn);
  
  ItemIdsCount=0;
  ItemIdsStr=null;
  
  Rs2=Stm2.executeQuery("select Item from "+DbItem+" where Conv="+CurrMain_Id);
  
  if(!Rs2.next()){return;}
  
  strb=new StringBuilder();
  do{
   if(ItemIdsCount!=0){strb.append(",");}

   ItemId=Rs2.getLong(1);
   strb.append(ItemId);

   ItemIdsCount=ItemIdsCount+1;
  }while(Rs2.next());
  ItemIdsStr=strb.toString();
 }
 private void getItemCategories(boolean IsItemOut) throws Exception{
  OIdName CategoryOfItem;
  boolean ThereIsNull;
  
  ItemCategories=new Vector();
  ItemCurrCategory=-1;
  
  if(ItemIdsCount==0){return;}
  
  Rs2=Stm2.executeQuery(
   "select CategoryOfItem, Name from "+
    "(select CategoryOfItem from "+
     "(select Id as 'ItemId' from Item where Id in("+ItemIdsStr+")) as tb1 "+
    "left join ItemXCategory on tb1.ItemId=ItemXCategory.Item group by CategoryOfItem) as tb2 "+
   "left join CategoryOfItem on tb2.CategoryOfItem=CategoryOfItem.Id order by Name asc");
  
  if(!Rs2.next()){throw new Exception();}
  
  ThereIsNull=false;
  do{
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=Rs2.getLong(1);
   CategoryOfItem.Name=Rs2.getString(2);
   if(Rs2.wasNull()){ThereIsNull=true;}
   else{ItemCategories.addElement(CategoryOfItem);}
  }while(Rs2.next());
  if(ThereIsNull){
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=-1;
   CategoryOfItem.Name="Tidak didefenisikan";
   ItemCategories.addElement(CategoryOfItem);
  }
 }
 private void prepareItemCategorized(boolean IsItemOut) throws Exception{
  getItemIds(IsItemOut);
  getItemCategories(IsItemOut);
 }
 private void fillItemCategorySummary(boolean IsItemOut, int Count){
  ItemListItemCount=Count;
 }
 private void clearItemCategorySummary(boolean IsItemOut){
  ItemListItemCount=0;
 }
 private boolean getItemNextCategory(boolean IsItemOut) throws Exception{
  boolean ThereIs;
  
  ThereIs=false;
  do{
   
   if(ItemCurrCategory<ItemCategories.size()){
    ItemCurrCategory=ItemCurrCategory+1;
    clearItemCategorySummary(IsItemOut);
   }
   
   if(ItemCurrCategory==ItemCategories.size()){break;}
   
   queryItem(IsItemOut);
   if(getNextItem(IsItemOut)){ThereIs=true; break;}
   
  }while(!ThereIs);
  if(!ThereIs){return false;}
  
  getItemCategoryHeader(IsItemOut);
  return true;
 }
 private void getItemCategoryHeader(boolean IsItemOut){
  int insertpos;
  ODimension dim;
  
  TableNewRow3=new ODrawTableRow(0, Table_ListItemCategoryHeader.Value.ColumnsCount);
  TableNewRow3.setCell(0, new ODrawTableCellText(ItemCategories.elementAt(ItemCurrCategory).Name+" ( "+PText.intToString(ItemListItemCount)+" )",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItemCategoryHeader.Value.Rows.size();
  if(!TableNewRow3.preGenerateCellsDrawContents(Table_ListItemCategoryHeader.Value, insertpos)){
   TableNewRow3.clearAllCells();
   TableNewRow3.setHeight(CellAreaMinHeight+(Table_ListItemCategoryHeader.Value.Inset.InsetTop+Table_ListItemCategoryHeader.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow3.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItemCategoryHeader.Value, insertpos);
   TableNewRow3.setHeight(dim.getHeight()+(Table_ListItemCategoryHeader.Value.Inset.InsetTop+Table_ListItemCategoryHeader.Value.Inset.InsetBottom));
   TableNewRow3.generateCellsDrawContents(Table_ListItemCategoryHeader.Value, insertpos);
  }
 }
 private void queryItem(boolean IsItemOut) throws Exception{
  String Query;
  String con=null;
  String DbItem=PText.getString(IsItemOut, DbItemOut, DbItemIn);
  
  ItemList=new Vector();
  ItemListCurrItem=-1;
  
  // Item-Id, Item-Name, Qty, Stock-Unit
  Query=
   "select Item, ItemName, ItemQty, StockUnit.Name as 'ItemStockUnitName' from "+
    "(select tb1.*, Item.Name as 'ItemName', StockUnit from "+
     "(select Item as 'Item', Stock as 'ItemQty' from "+DbItem+" where Conv="+CurrMain_Id+") as tb1 "+
    "left join Item on tb1.Item=Item.Id) as tb2 "+
   "left join StockUnit on tb2.StockUnit=StockUnit.Id "+
   "order by ItemName asc";
  
  if(OptList_ItemCategorized){
   if(ItemCategories.elementAt(ItemCurrCategory).Id==-1){con=" is "+CCore.vNull;}
   else{con="="+ItemCategories.elementAt(ItemCurrCategory).Id;}
   Query=
    "select c1.*, CategoryOfItem from "+
     "("+Query+") as c1 "+
    "left join ItemXCategory on c1.Item=ItemXCategory.Item where CategoryOfItem"+con+" "+
    "order by ItemName asc";
  }
  
  if(PDatabase.queryToRows(Stm2, Query, ItemList,
   PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeString),
   null, false, null, null, false, false, null, -1, false, -1, true, true, false, PrintedItems, 0)==-1){throw new Exception();}
  
  fillItemCategorySummary(IsItemOut, ItemList.size());
 }
 private boolean getNextItem(boolean IsItemOut) throws Exception{
  int insertpos;
  ODimension dim;
  Object[] objs;
  long ItemId; String ItemName; double ItemQty; String ItemStockUnit;
  
  if(ItemListCurrItem<ItemList.size()){ItemListCurrItem=ItemListCurrItem+1;;}
  
  if(ItemListCurrItem==ItemList.size()){return false;}
  
  objs=ItemList.elementAt(ItemListCurrItem);
  ItemId=PCore.objLong(objs[0], -1L);
  ItemName=PCore.objString(objs[1], null);
  ItemQty=PCore.objDouble(objs[2], 0D);
  ItemStockUnit=PCore.objString(objs[3], null);
  
  TableNewRow2=new ODrawTableRow(0, Table_ListItem.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PText.getString(IsItemOut, PointOfListItemOut, PointOfListItemIn),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(1, new ODrawTableCellText(ItemName+" ("+ItemId+")",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.priceToString(ItemQty),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.getString(ItemStockUnit, "", false),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItem.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_ListItem.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_ListItem.Value.Inset.InsetTop+Table_ListItem.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItem.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_ListItem.Value.Inset.InsetTop+Table_ListItem.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_ListItem.Value, insertpos);
  }
  
  return true;
 }

}