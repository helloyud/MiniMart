public class ODimension {
 double Width;
 double Height;

 public ODimension() {}
 public ODimension(double Width, double Height) {
  setSize(Width, Height);
 }
 
 void setSize(double Width, double Height){
  this.Width = Width;
  this.Height = Height;
 }
 double getWidth(){return Width;}
 double getHeight(){return Height;}
 
}