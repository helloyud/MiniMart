public class OPreciseDecimal {
 
 //
 int FractionDigit;
 long FractionConst;
 
 int RoundDigit;
 long RoundConst;
 long RoundUpMinimal;
 
 char NumericSeparatorThousand;
 char NumericSeparatorFraction;
 
 // UnRounded
 VDouble UnRounded_Value;
 VDouble UnRounded_PositiveValue;
 
 VBoolean UnRounded_IsPositive;
 
 VLong UnRounded_Number;
 VInteger UnRounded_NumberLength;
 VInteger UnRounded_NumberWithSeparatorLength;
 
 VLong UnRounded_Fraction;
 VInteger UnRounded_FractionLength;
 
 long Round;
 
 // Rounded
 VDouble Rounded_Value;
 VDouble Rounded_PositiveValue;
 
 VBoolean Rounded_IsPositive;
 
 VLong Rounded_Number;
 VInteger Rounded_NumberLength;
 VInteger Rounded_NumberWithSeparatorLength;
 
 VLong Rounded_Fraction;
 VInteger Rounded_FractionLength;
 
 public OPreciseDecimal(){
  initReferenceVariables();
 }
 public OPreciseDecimal(int FractionDigit, int RoundDigit, char NumericSeparatorThousand, char NumericSeparatorFraction){
  this();
  setFractionDigit(FractionDigit);
  setRoundDigit(RoundDigit);
  setNumericSeparator(NumericSeparatorThousand, NumericSeparatorFraction);
 }
 public OPreciseDecimal(double Number, int FractionDigit, int RoundDigit, char NumericSeparatorThousand, char NumericSeparatorFraction){
  this(FractionDigit, RoundDigit, NumericSeparatorThousand, NumericSeparatorFraction);
  changeValue(Number);
 }
 public OPreciseDecimal(int FractionDigit, int RoundDigit){this(FractionDigit, RoundDigit, CCore.NumericSeparatorThousand, CCore.NumericSeparatorFraction);}
 public OPreciseDecimal(double Number, int FractionDigit, int RoundDigit){this(Number, FractionDigit, RoundDigit, CCore.NumericSeparatorThousand, CCore.NumericSeparatorFraction);}
 private void initReferenceVariables(){
  // unrounded
  UnRounded_Value=new VDouble();
  UnRounded_PositiveValue=new VDouble();
  
  UnRounded_IsPositive=new VBoolean();
  
  UnRounded_Number=new VLong();
  UnRounded_NumberLength=new VInteger();
  UnRounded_NumberWithSeparatorLength=new VInteger();

  UnRounded_Fraction=new VLong();
  UnRounded_FractionLength=new VInteger();
  
  // rounded
  Rounded_Value=new VDouble();
  Rounded_PositiveValue=new VDouble();
  
  Rounded_IsPositive=new VBoolean();
  
  Rounded_Number=new VLong();
  Rounded_NumberLength=new VInteger();
  Rounded_NumberWithSeparatorLength=new VInteger();

  Rounded_Fraction=new VLong();
  Rounded_FractionLength=new VInteger();
 }
 
 private void setFractionDigit(int FractionDigit){
  this.FractionDigit=FractionDigit;
  FractionConst=PMath.getMultiplierOfTen(FractionDigit);
 }
 private void setRoundDigit(int RoundDigit){
  this.RoundDigit=RoundDigit;
  RoundConst=PMath.getMultiplierOfTen(RoundDigit);
  RoundUpMinimal=RoundConst/2; if(RoundDigit>=3){RoundUpMinimal=RoundUpMinimal-1;}
 }
 public void setNumericSeparator(char NumericSeparatorThousand, char NumericSeparatorFraction){
  this.NumericSeparatorThousand=NumericSeparatorThousand;
  this.NumericSeparatorFraction=NumericSeparatorFraction;
 }
 
 private void setValue(boolean UnRounded, double Value_){
  VDouble Value=(VDouble)PCore.subtituteBool(UnRounded, UnRounded_Value, Rounded_Value);
  VDouble PositiveValue=(VDouble)PCore.subtituteBool(UnRounded, UnRounded_PositiveValue, Rounded_PositiveValue);

  Value.Value=Value_;
  PositiveValue.Value=PCore.subtBool_Double(Value.Value>=0, Value.Value, -1*Value.Value);
 }
 
 private void initValue(boolean UnRounded){
  initSign(UnRounded);
  initNumber(UnRounded);
  initFraction(UnRounded);
  if(UnRounded){initRound();}
 }
 private void initSign(boolean UnRounded){
  VBoolean IsPositive=(VBoolean)PCore.subtituteBool(UnRounded, UnRounded_IsPositive, Rounded_IsPositive);
  VDouble Value=(VDouble)PCore.subtituteBool(UnRounded, UnRounded_Value, Rounded_Value);
  
  IsPositive.Value=Value.Value>=0;
 }
 private void initNumber(boolean UnRounded){
  VLong Number=(VLong)PCore.subtituteBool(UnRounded, UnRounded_Number, Rounded_Number);
  VDouble PositiveValue=(VDouble)PCore.subtituteBool(UnRounded, UnRounded_PositiveValue, Rounded_PositiveValue);
  
  Number.Value=(long)PositiveValue.Value;
  calcNumberLength(UnRounded);
 }
 private void calcNumberLength(boolean UnRounded){
  VLong Number=(VLong)PCore.subtituteBool(UnRounded, UnRounded_Number, Rounded_Number);
  VInteger NumberLength=(VInteger)PCore.subtituteBool(UnRounded, UnRounded_NumberLength, Rounded_NumberLength);
  VInteger NumberWithSeparatorLength=(VInteger)PCore.subtituteBool(UnRounded, UnRounded_NumberWithSeparatorLength, Rounded_NumberWithSeparatorLength);
  
  NumberLength.Value=calcNumberLength(Number.Value);
  NumberWithSeparatorLength.Value=calcNumberWithSeparatorLength(Number.Value);
 }
 private int calcNumberLength(long Number){return PText.getCharsCountOfNumber(Number, false, false);}
 private int calcNumberWithSeparatorLength(long Number){return PText.getCharsCountOfNumber(Number, true, false);}
 private void initFraction(boolean UnRounded){
  VLong Fraction=(VLong)PCore.subtituteBool(UnRounded, UnRounded_Fraction, Rounded_Fraction);
  VDouble PositiveValue=(VDouble)PCore.subtituteBool(UnRounded, UnRounded_PositiveValue, Rounded_PositiveValue);
  
  Fraction.Value=(long)((PositiveValue.Value%1)*FractionConst);
  calcFractionLength(UnRounded);
 }
 private void calcFractionLength(boolean UnRounded){
  VInteger FractionLength=(VInteger)PCore.subtituteBool(UnRounded, UnRounded_FractionLength, Rounded_FractionLength);
  VLong Fraction=(VLong)PCore.subtituteBool(UnRounded, UnRounded_Fraction, Rounded_Fraction);
  
  FractionLength.Value=calcFractionLength(Fraction.Value);
 }
 private int calcFractionLength(long Fraction){
  int ret=0;
  long temp=Fraction;
  
  if(Fraction==0 || FractionDigit==0){return ret;}
  
  ret=FractionDigit;
  do{
   if(temp%10!=0){break;}
   ret=ret-1;
   temp=temp/10;
  }while(ret!=0);
  
  return ret;
 }
 private void initRound(){
  Round=(long)((((UnRounded_Value.Value%1)*FractionConst)%1)*RoundConst);
 }
 
 private void roundingValue(){
  double value;
  boolean ispositive;
  long number, fraction;
  
  ispositive=UnRounded_IsPositive.Value;
  number=UnRounded_Number.Value;
  fraction=UnRounded_Fraction.Value;
  
  // start rounding up here
  if(Round>=RoundUpMinimal){
   fraction=fraction+1;
   if(fraction==FractionConst){fraction=0; number=number+1;}
  }
  // end rounding up here
  
  /*
  value=(double)number+((double)fraction/(double)FractionConst);
  value=PCore.subtBool_Double(ispositive, value, -1*value);
  setValue(false, value);
  initValue(false);
  */
  
  Rounded_IsPositive.Value=ispositive;
  
  Rounded_Number.Value=number;
  Rounded_NumberLength.Value=calcNumberLength(Rounded_Number.Value);
  Rounded_NumberWithSeparatorLength.Value=calcNumberWithSeparatorLength(Rounded_Number.Value);
  
  Rounded_Fraction.Value=fraction;
  Rounded_FractionLength.Value=calcFractionLength(Rounded_Fraction.Value);
  
  value=(double)Rounded_Number.Value+((double)Rounded_Fraction.Value/(double)FractionConst);
  value=PCore.subtBool_Double(Rounded_IsPositive.Value, value, -1*value);
  Rounded_Value.Value=value;
  Rounded_PositiveValue.Value=PCore.subtBool_Double(Rounded_Value.Value>=0, Rounded_Value.Value, -1*Rounded_Value.Value);
 }
 
 public void changeValue(double Value){
  setValue(true, Value);
  
  initValue(true);
  
  roundingValue();
 }
 public void changeFraction(int FractionDigit){
  setFractionDigit(FractionDigit);
  
  initFraction(true);
  initRound();
  
  roundingValue();
 }
 public void changeRound(int RoundDigit){
  setRoundDigit(RoundDigit);
  
  initRound();
  
  roundingValue();
 }
 public void changeFractionAndRound(int FractionDigit, int RoundDigit){
  setFractionDigit(FractionDigit);
  setRoundDigit(RoundDigit);
  
  initFraction(true);
  initRound();
  
  roundingValue();
 }
 
 public String getString(boolean UnRounded, boolean WithSeparator, int MaxChar, boolean ForceFitInto_MaxChar){
  StringBuilder ret=new StringBuilder();
  VBoolean IsPositive=(VBoolean)PCore.subtituteBool(UnRounded, UnRounded_IsPositive, Rounded_IsPositive);
  VLong Number=(VLong)PCore.subtituteBool(UnRounded, UnRounded_Number, Rounded_Number);
  VLong Fraction=(VLong)PCore.subtituteBool(UnRounded, UnRounded_Fraction, Rounded_Fraction);
  int length_until_number, length_left;
  String FractionString;

  // add sign
  if(IsPositive.Value==false){ret.append("-");}

  // add number
  if(!WithSeparator){ret.append(String.valueOf(Number.Value));}
  else{ret.append(PText.intToString(Number.Value, NumericSeparatorThousand));}

  // add fraction
  do{
   length_until_number=ret.length();
   length_left=MaxChar-(length_until_number+1); // (length_until_number+1) to include " fraction's dot '.' "
   
   if(Fraction.Value==0 || length_left<=0){break;}
   
   ret.append(NumericSeparatorFraction);
   
   FractionString=PText.paddingNumber(Fraction.Value, FractionDigit);
   FractionString=PText.trim(FractionString, null, 2, PCore.primArr('0'));
   if(FractionString.length()>length_left){FractionString=PText.subString(FractionString, 0, length_left-1);}
   ret.append(FractionString);
  }while(false);
  
  // force fit
  if(ForceFitInto_MaxChar && ret.length()>MaxChar){
   ret=new StringBuilder(PText.subString(ret.toString(), 0, MaxChar-1));
  }
  
  return ret.toString();
 }
 
 public String toString(){
  return getString(false, false, Integer.MAX_VALUE, false);
 }
 
}