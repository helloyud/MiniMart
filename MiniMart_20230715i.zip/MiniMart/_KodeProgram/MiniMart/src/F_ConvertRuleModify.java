import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class F_ConvertRuleModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 int wMode; // 1 Add, 2 Edit
 
 // get
 OInfoConvertRule InfoConvertRule;
 
 // Add Item
  // Item
 boolean RecheckId;
 long CheckedId, I_CheckedId;
 OInfoItem ItemInfo, I_ItemInfo;
 boolean InputInfoClearedItem;
 
  // Qty
 double Qty, I_Qty;
 
  //
 VBoolean EnableDocumentListener; // always enable, except when document will be changed by setText()
 int DocumentListenerFocus;
 int[] TF_ItemId_ShortcutKeys;
 
 // Item Out
 OCustomTableModel TableMdlItemOut;
 VInteger LastSelectedRowItemOut;
 VBoolean ItemOutInfoClear;
 
 // Item In
 OCustomTableModel TableMdlItemIn;
 VInteger LastSelectedRowItemIn;
 VBoolean ItemInInfoClear;
 
 public F_ConvertRuleModify(MInterFormVariables IFV_){
  String[] ColName;
  int[] ColType, ColShowOption, ColVisible, Editable, ColWidth;
  boolean[] ColEditable;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  this.IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Add Item
  I_ItemInfo=new OInfoItem();
  
  EnableDocumentListener=new VBoolean(true);
  
  TF_AddItemId.setToolTipText("{F6} ket brg, {Spasi} cari brg, {Enter} tbh brg, {Down} ubah qty & hrg");
  TF_AddItemId.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(!RecheckId && EnableDocumentListener.Value){
      RecheckId=true;
     }
    }
    
   });
  TF_AddItemQty.getDocument().addDocumentListener(new DocumentListener(){

    public void changedUpdate(DocumentEvent e) {}
    public void insertUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    public void removeUpdate(DocumentEvent e) {
     if(DocumentListenerFocus==1 && EnableDocumentListener.Value){
      inputQuantity();
     }
    }
    
   });
  EnableDocumentListener.Value=true;
  TF_ItemId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  DocumentListenerFocus=-1;
  
  InputInfoClearedItem=true;
   
  RecheckId=false; I_CheckedId=-1;
  I_Qty=-1;
  
  // Convert
  ColName=PMyShop.getConvertItems_ColumnsName();
  ColType=PMyShop.getConvertItems_ColumnsType();
  ColShowOption=PCore.changeValue(PCore.newIntegerArray(ColName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  ColVisible=PCore.primArr(1, 2, 3, 0, 4);
  Editable=PCore.primArr(2);
  ColEditable=PCore.changeValue(PCore.newBooleanArray(ColName.length, false),
   Editable, PCore.newBooleanArray(Editable.length, true));
  ColWidth=PCore.primArr(CGUI.ColTextLrg, CGUI.ColNumSep04, CGUI.ColTextTiny, CGUI.ColNum13, CGUI.ColCheck);
  
  TableMdlItemOut=new OCustomTableModel(false, false, false, true, 0); TableMdlItemOut.setColumnsInfo(ColName, ColType, ColShowOption, ColVisible, ColEditable);
  Tbl_ItemOut.setModel(TableMdlItemOut); PGUI.resizeTableColumn(Tbl_ItemOut, ColWidth);
  refreshItemCount(true);
  LastSelectedRowItemOut=new VInteger(-1);
  ItemOutInfoClear=new VBoolean(true);
  Tbl_ItemOut.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem(true);}
   };
  Pnl_ItemOutInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  TableMdlItemIn=new OCustomTableModel(false, false, false, true, 0); TableMdlItemIn.setColumnsInfo(ColName, ColType, ColShowOption, ColVisible, ColEditable);
  Tbl_ItemIn.setModel(TableMdlItemIn); PGUI.resizeTableColumn(Tbl_ItemIn, ColWidth);
  refreshItemCount(false);
  LastSelectedRowItemIn=new VInteger(-1);
  ItemInInfoClear=new VBoolean(true);
  Tbl_ItemIn.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem(false);}
   };
  Pnl_ItemInInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  //
  clearComponents();
 }
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_Name, CB_IsActive,
    
    Btn_AddItemA, Btn_AddItemB,
    TF_AddItemId, Btn_AddItemChooseId,
    TF_AddItemQty,
    
    Btn_ItemOutMove, Btn_ItemOutEdit, Btn_ItemOutRemove,
    Tbl_ItemOut,
    
    Btn_ItemInMove, Btn_ItemInEdit, Btn_ItemInRemove,
    Tbl_ItemIn,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // F2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddItemAActionPerformed(null);
    }
   });
  
  // F3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddItemBActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
  
  // Ctrl+I
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK, false), "ctrl_i");
  act.put("ctrl_i", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_AddItemChooseIdActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  clearInput();
  clearInputItem(); DocumentListenerFocus=-1;
 }
 
 // Header
 void clearInputHeader(){
  TF_Name.setText("");
  CB_IsActive.setSelected(true);
 }
 
 // Add Item
  // Item
 void inputItem(){
  if(!changeItemMetadata()){return;}
  afterChangeItemMetadata();
 }
 boolean changeItemMetadata(){
  boolean ret=false;
  OInfoItem InfoItem;
  
  do{
   // Parse TF_ItemId
   try{I_CheckedId=Long.parseLong(TF_AddItemId.getText());}catch(Exception E){break;}
   
   // Check if Item is exist in database
   InfoItem=PMyShop.getItemInfo(IFV.Stm, I_CheckedId, false); if(InfoItem==null){break;}
   
   // init input-item's non-gui variables
   I_ItemInfo=InfoItem;
   changeItemQuantityPrice();
   
   ret=true;
  }while(false);
  
  if(!ret){I_CheckedId=-1; clearItem();}
  
  RecheckId=false;
  
  return ret;
 }
 void afterChangeItemMetadata(){
  // init input-item's gui variables
  setIQty(I_Qty, false);
  
  fillInputInfoItem();
 }
 void changeItemQuantityPrice(){
  if(I_Qty<=0){I_Qty=1;}
 }
 void fillInputInfoItem(){
  if(I_CheckedId==-1){clearInputInfoItem(); return;}
  
  TA_AddItemIdInfoName.setText(I_ItemInfo.Name);
  TF_AddItemIdInfoStockUnit.setText(PText.getString(I_ItemInfo.StockUnitName, "", false));
  CB_AddItemIdInfoUpdate.setSelected(I_ItemInfo.UpdateStock);
  
  InputInfoClearedItem=false;
 }
 void clearInputInfoItem(){
  if(InputInfoClearedItem){return;}
  
  PGUI.clearText(TA_AddItemIdInfoName, TF_AddItemIdInfoStockUnit);
  CB_AddItemIdInfoUpdate.setSelected(false);
  
  InputInfoClearedItem=true;
 }
 void clearItem(){
  clearInputInfoItem();
 }
 void focusItem(){
  PGUI.requestFocusInWindow(TF_AddItemId);
 }
  // Qty
 void setIQty(double Value, boolean ClearInvalidValue){
  I_Qty=Value;
  
  if(I_Qty>0){PGUI.changeDocument(EnableDocumentListener, TF_AddItemQty, PText.doubleToString(I_Qty, true));}
  else{if(ClearInvalidValue){PGUI.changeDocument(EnableDocumentListener, TF_AddItemQty, "");}}
 }
 void inputQuantity(){
  I_Qty=PText.parseDouble(TF_AddItemQty.getText(), -1D, -1D); if(I_Qty<=0){I_Qty=-1;}
  
  if(I_Qty<=0){return;}
 }
 void focusQty(){
  PGUI.requestFocusInWindow(TF_AddItemQty);
 }
  // Others
 void fillInputVariablesIntoRealVariables(){
  CheckedId=I_CheckedId;
  ItemInfo=I_ItemInfo;
  
  Qty=I_Qty;
 }
 void clearInputItem(){
  EnableDocumentListener.Value=false;
  
  TF_AddItemId.setText(""); I_CheckedId=-1; RecheckId=false; clearItem();
  setIQty(-1, true);
  
  EnableDocumentListener.Value=true;
 }
 void changeDocument(JTextField TF, String Str){
  EnableDocumentListener.Value=false;
  TF.setText(Str);
  EnableDocumentListener.Value=true;
 }
 void focus(JTextField TF){
  TF.requestFocusInWindow();
 }
 void enableItemIdEdit(boolean Enable){
  TF_AddItemId.setEditable(Enable);
  if(Enable){TF_AddItemId.setBackground(CGUI.Color_TextBox_FocusOff);}
  else{TF_AddItemId.setBackground(CGUI.Color_TextBox_Uneditable);}
  Btn_AddItemChooseId.setEnabled(Enable);
 }
 
 // List Items
 void onSelectedRowChangedItem(boolean IsItemOut, boolean UpdateAnyway){
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  VInteger LastSelectedRow=(VInteger)PCore.subtituteBool(IsItemOut, LastSelectedRowItemOut, LastSelectedRowItemIn);
  
  int row;
  
  row=Tbl.getSelectedRow();
  if(LastSelectedRow.Value==row && !UpdateAnyway){return;}
  
  LastSelectedRow.Value=row;
  if(row==-1){clearItemInfo(IsItemOut);}
  else{fillItemInfo(IsItemOut, row);}
 }
 void onEditingTableItem(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int Row, Col;
  int result=0;
  boolean IsSame;
  
  Row=Tbl.Editing_Row;
  Col=TableMdl.convertColumnIndexFromViewToModel(Tbl.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdl.Mdl.ColumnsType[Col], null, Tbl.Editing_ValueOld, true, null, Tbl.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){break;}
   result=onEditingTableItem(IsItemOut, Row, Col); break;
  }while(false);
  
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableItem(boolean IsItemOut, int Row, int Col){
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int ret=0;
  boolean valid;
  OEditConvertItem Edit;
  
  do{
   Edit=new OEditConvertItem();
   valid=true;
   switch(Col){
    // double not null, positive only, >0
    case 2 : Edit.EditQuantity=true; Edit.EditedQuantity=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedQuantity<=0){valid=false;} break;
   }
   if(!valid){ret=-2; break;}

   editItems(IsItemOut, PCore.primArr(Row), Edit);
  }while(false);
  
  return ret;
 }
 
 void refreshItemCount(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  JTextField TF_ItemCount=(JTextField)PCore.subtituteBool(IsItemOut, TF_ItemOutSumCount, TF_ItemInSumCount);
  
  TF_ItemCount.setText(PText.intToString(TableMdl.getRowCount()));
 }
 
 int addItem_(boolean IsItemOut,
  long CheckedId, String ItemName, double CheckedQuantity, String ItemStockUnit, Object ItemUpdateStock, Object ItemPictureFile, Object ItemCategory){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  
  int ret;
  int temp;
  Object[] NewRow;
  double Qty;
  
  // search for existed item in table
  ret=TableMdl.Mdl.Index.checkElement(CheckedId);

  // add item
  if(ret<0){
   // define new row's insert position
   ret=0;
   temp=TableMdl.Mdl.Rows.size();
   if(temp!=0){
    do{
     if(PText.grading(ItemName, (String)TableMdl.Mdl.Rows.elementAt(ret)[1], false)==1){break;}
     ret=ret+1;
    }while(ret!=temp);
   }
   // insert a new row
   NewRow=new Object[7];
   NewRow[0]=CheckedId;
   NewRow[1]=ItemName;
   NewRow[2]=CheckedQuantity;
   NewRow[3]=PText.getString(ItemStockUnit, null,
    PText.getString(PText.findElementCharacter(CCore.Chars_WhiteSpace, PText.getCharAt(ItemStockUnit, 0))==-1, " ", "")+ItemStockUnit, true);
   NewRow[4]=ItemUpdateStock;
   NewRow[5]=ItemPictureFile;
   NewRow[6]=ItemCategory;
   TableMdl.insert(ret, NewRow);
  }
  else{
   NewRow=TableMdl.Mdl.Rows.elementAt(ret);
   Qty=(Double)NewRow[2]+CheckedQuantity; NewRow[2]=Qty;
   TableMdl.changeValue(ret, NewRow);
  }
  
  return ret;
 }
 void addItem(boolean IsItemOut,
  long CheckedId, String ItemName, double CheckedQuantity, String ItemStockUnit, Object ItemUpdateStock, Object ItemPictureFile, Object ItemCategory){
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int insertpos;
  
  insertpos=addItem_(IsItemOut, CheckedId, ItemName, CheckedQuantity, ItemStockUnit, ItemUpdateStock, ItemPictureFile, ItemCategory);
  refreshItemCount(IsItemOut);
  Tbl.changeSelection(insertpos, 0, false, false); onSelectedRowChangedItem(IsItemOut, true);
 }
 void addItem(boolean IsItemOut){
  long ItemId;
  
  if(RecheckId){changeItemMetadata();}
  
  if(I_CheckedId==-1 || I_Qty<=0){JOptionPane.showMessageDialog(null, "Masukan belum benar !\nSilahkan periksa kembali !"); return;}
  
  fillInputVariablesIntoRealVariables();
  ItemId=ItemInfo.PrimaryId;
  addItem(IsItemOut, ItemId, ItemInfo.Name, Qty, ItemInfo.StockUnitName, ItemInfo.UpdateStock, ItemInfo.PictureFile, ItemInfo.CategoryName);

  clearInputItem();
  TF_AddItemId.requestFocusInWindow();
 }
 void editItems(boolean IsItemOut, int[] Rows, OEditConvertItem Edit){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  
  Vector<OTableCellUpdater> ChangeValues;
  
  ChangeValues=new Vector();
  if(Edit.EditQuantity){
   ChangeValues.addElement(new OTableCellUpdaterByObject(2, Edit.EditedQuantity));
  }
  
  PGUI.changeElements(TableMdl, Rows, ChangeValues);
  
  // onSelectedRowChangedItem(IsItemOut, true);
 }
 void editItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  F_ConvertItemModify fm1=IFV.FConvertItemModify;
  F_ConvertItemModifyMulti fm2=IFV.FConvertItemModifyMulti;
  
  int[] rows;
  OEditConvertItem Edit;
  Object[] objs;
  
  rows=Tbl.getSelectedRows();
  if(rows.length==0){return;}
  
  Edit=new OEditConvertItem();
  
  if(rows.length==1){
   objs=TableMdl.Mdl.Rows.elementAt(rows[0]);
   
   fm1.wConvert=1;
   fm1.wMode=2;
   fm1.wItemId=PCore.objLong(objs[0], -1L);
   fm1.wQuantity=PCore.objDouble(objs[2], 0D);
   
   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}
   
   Edit.EditQuantity=true; Edit.EditedQuantity=fm1.Qty;
  }
  else{
   fm2.wConvert=1;
   fm2.wDataCount=rows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.EditQuantity=fm2.ChangeQuantity; Edit.EditedQuantity=fm2.Quantity;
  }
  
  editItems(IsItemOut, rows, Edit);
 }
 void removeItems(boolean IsItemOut, int[] rows){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  
  if(rows.length==0){return;}
  
  if(rows.length!=TableMdl.Mdl.Rows.size()){TableMdl.remove(rows);}
  else{TableMdl.removeAll();}
  
  refreshItemCount(IsItemOut);
  onSelectedRowChangedItem(IsItemOut, true);
 }
 void removeItems(boolean IsItemOut){
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int[] rows;
  
  rows=Tbl.getSelectedRows();
  if(rows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+PText.intToString(rows.length)+" barang yg dipilih dari "+PText.getString(IsItemOut, "Sisi A", "Sisi B")+" ?",
   "Konfirmasi Penghapusan Barang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  removeItems(IsItemOut, rows);
 }
 void moveItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  boolean ItemDest=!IsItemOut;
  XTable TblDest=(XTable)PCore.subtituteBool(ItemDest, Tbl_ItemOut, Tbl_ItemIn);
  
  int[] rows;
  int temp, length;
  int insertpos;
  Object[] CurrData;
  
  rows=Tbl.getSelectedRows();
  length=rows.length;
  if(length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Pindahkan "+PText.intToString(length)+" barang yg dipilih ke "+PText.getString(ItemDest, "Sisi A", "Sisi B")+" ?",
   "Konfirmasi Pemindahan Barang", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  temp=0;
  do{
   CurrData=TableMdl.Mdl.Rows.elementAt(rows[temp]);
   insertpos=addItem_(ItemDest, (Long)CurrData[0], (String)CurrData[1], (Double)CurrData[2], PCore.objString(CurrData[3], null), CurrData[4], CurrData[5], CurrData[6]);
   temp=temp+1;
  }while(temp!=length);
  refreshItemCount(ItemDest);
  TblDest.changeSelection(insertpos, 0, false, false); onSelectedRowChangedItem(ItemDest, true);
  
  removeItems(IsItemOut, rows);
 }
 
 void fillItemInfo(boolean IsItemOut, int row){
  VBoolean ItemInfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, ItemOutInfoClear, ItemInInfoClear);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  Object[] objs;
  
  objs=TableMdl.Mdl.Rows.elementAt(row);
  TA_InfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[1]);
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, objs[5]);
  
  ItemInfoClear.Value=false;
 }
 void clearItemInfo(boolean IsItemOut){
  VBoolean ItemInfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, ItemOutInfoClear, ItemInInfoClear);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  
  if(ItemInfoClear.Value){return;}
  
  TA_InfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, null);
  
  ItemInfoClear.Value=true;
 }
 
 void clearInputItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  
  TableMdl.removeAll(); onSelectedRowChangedItem(IsItemOut, false);
  refreshItemCount(IsItemOut);
 }
 void clearItems(){clearInputItems(true); clearInputItems(false);}
 
 // Others
 void fillComponentsWithSetVariables(){
  fillWithSetVariables_Header();
  fillWithSetVariables_Item(true); fillWithSetVariables_Item(false);
 }
 void fillWithSetVariables_Header(){
  TF_Name.setText(InfoConvertRule.Name);
  CB_IsActive.setSelected(InfoConvertRule.IsActive);
 }
 void fillWithSetVariables_Item(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlItemOut, TableMdlItemIn);
  Vector<Object[]> ListItem=(Vector<Object[]>)PCore.subtituteBool(IsItemOut, InfoConvertRule.ListItemA, InfoConvertRule.ListItemB);
  
  TableMdl.append(ListItem);
  refreshItemCount(IsItemOut);
 }
 
 void clearInput(){
  clearInputHeader();
  clearItems();
 }
 
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_AddItemId){TF_AddItemIdKeyPressed(e);}
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_AddItemChoose = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  jPanel8 = new javax.swing.JPanel();
  TF_Name = new javax.swing.JTextField();
  Lbl_Name = new javax.swing.JLabel();
  CB_IsActive = new javax.swing.JCheckBox();
  Lbl_IsActive = new javax.swing.JLabel();
  jLabel8 = new javax.swing.JLabel();
  Lbl_NameHelp = new javax.swing.JLabel();
  jPanel9 = new javax.swing.JPanel();
  jPanel10 = new javax.swing.JPanel();
  Btn_AddItemB = new javax.swing.JButton();
  Btn_AddItemA = new javax.swing.JButton();
  Lbl_AddItemChoose = new javax.swing.JLabel();
  jPanel11 = new javax.swing.JPanel();
  Btn_AddItemChooseId = new javax.swing.JButton();
  TF_AddItemId = new javax.swing.JTextField();
  Lbl_AddItemId = new javax.swing.JLabel();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_AddItemIdInfoName = new javax.swing.JTextArea();
  Lbl_AddItemQty = new javax.swing.JLabel();
  TF_AddItemIdInfoStockUnit = new javax.swing.JTextField();
  CB_AddItemIdInfoUpdate = new javax.swing.JCheckBox();
  TF_AddItemQty = new javax.swing.JTextField();
  jSeparator1 = new javax.swing.JSeparator();
  jPanel2 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  Btn_ItemOutRemove = new javax.swing.JButton();
  Btn_ItemOutEdit = new javax.swing.JButton();
  Btn_ItemOutMove = new javax.swing.JButton();
  TF_ItemOutSumCount = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_ItemOut = new XTable();
  jPanel5 = new javax.swing.JPanel();
  Pnl_ItemOutInfoPreview = new XImgBoxURL();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemOutInfoName = new javax.swing.JTextArea();
  jPanel6 = new javax.swing.JPanel();
  jScrollPane5 = new javax.swing.JScrollPane();
  Tbl_ItemIn = new XTable();
  jPanel12 = new javax.swing.JPanel();
  Btn_ItemInRemove = new javax.swing.JButton();
  Btn_ItemInEdit = new javax.swing.JButton();
  Btn_ItemInMove = new javax.swing.JButton();
  TF_ItemInSumCount = new javax.swing.JTextField();
  jLabel10 = new javax.swing.JLabel();
  jPanel13 = new javax.swing.JPanel();
  Pnl_ItemInInfoPreview = new XImgBoxURL();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_ItemInInfoName = new javax.swing.JTextArea();
  jSeparator2 = new javax.swing.JSeparator();
  jPanel7 = new javax.swing.JPanel();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jPanel8.setBackground(new java.awt.Color(221, 219, 192));

  TF_Name.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_Name.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_NameFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_NameFocusLost(evt);
   }
  });
  TF_Name.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_NameKeyPressed(evt);
   }
  });

  Lbl_Name.setText("Nama");

  CB_IsActive.setText(" ");
  CB_IsActive.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsActive.setOpaque(false);
  CB_IsActive.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsActiveKeyPressed(evt);
   }
  });

  Lbl_IsActive.setText("Aktif");

  jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
  jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel8.setText("Aturan Konversi");

  Lbl_NameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_NameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_NameHelp.setText("(?)");
  Lbl_NameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_NameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_NameHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_IsActive, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(jPanel8Layout.createSequentialGroup()
      .addComponent(Lbl_Name)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_NameHelp)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
      .addComponent(CB_IsActive)
      .addContainerGap())
     .addComponent(TF_Name)))
   .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(jLabel8)
    .addGap(18, 18, 18)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Name)
     .addComponent(Lbl_NameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_IsActive)
     .addComponent(Lbl_IsActive))
    .addContainerGap(151, Short.MAX_VALUE))
  );

  jPanel9.setBackground(new java.awt.Color(221, 219, 192));

  jPanel10.setOpaque(false);

  Btn_AddItemB.setText("Ke Sisi B {F3}");
  Btn_AddItemB.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddItemB.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddItemBActionPerformed(evt);
   }
  });
  Btn_AddItemB.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddItemBKeyPressed(evt);
   }
  });

  Btn_AddItemA.setText("Ke Sisi A {F2}");
  Btn_AddItemA.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddItemA.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddItemAActionPerformed(evt);
   }
  });
  Btn_AddItemA.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddItemAKeyPressed(evt);
   }
  });

  Lbl_AddItemChoose.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_AddItemChoose.setText("- - -   Tambah Barang");

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
    .addComponent(Lbl_AddItemChoose)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_AddItemA)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_AddItemB))
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_AddItemB)
    .addComponent(Btn_AddItemA)
    .addComponent(Lbl_AddItemChoose))
  );

  jPanel11.setOpaque(false);

  Btn_AddItemChooseId.setText("{Ctrl+I}");
  Btn_AddItemChooseId.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_AddItemChooseId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_AddItemChooseIdActionPerformed(evt);
   }
  });
  Btn_AddItemChooseId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_AddItemChooseIdKeyPressed(evt);
   }
  });

  TF_AddItemId.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_AddItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_AddItemIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_AddItemIdFocusLost(evt);
   }
  });
  TF_AddItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_AddItemIdKeyPressed(evt);
   }
  });

  Lbl_AddItemId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_AddItemId.setText("Id Barang");

  TA_AddItemIdInfoName.setEditable(false);
  TA_AddItemIdInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_AddItemIdInfoName.setColumns(20);
  TA_AddItemIdInfoName.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_AddItemIdInfoName.setLineWrap(true);
  TA_AddItemIdInfoName.setRows(1);
  TA_AddItemIdInfoName.setToolTipText("klik utk melihat keterangan barang");
  TA_AddItemIdInfoName.setWrapStyleWord(true);
  TA_AddItemIdInfoName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TA_AddItemIdInfoName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TA_AddItemIdInfoNameMouseClicked(evt);
   }
  });
  jScrollPane4.setViewportView(TA_AddItemIdInfoName);

  Lbl_AddItemQty.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_AddItemQty.setText("Kuantitas");

  TF_AddItemIdInfoStockUnit.setEditable(false);
  TF_AddItemIdInfoStockUnit.setBackground(new java.awt.Color(204, 255, 204));
  TF_AddItemIdInfoStockUnit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CB_AddItemIdInfoUpdate.setText("Diperbarui");
  CB_AddItemIdInfoUpdate.setEnabled(false);
  CB_AddItemIdInfoUpdate.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
  CB_AddItemIdInfoUpdate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_AddItemIdInfoUpdate.setOpaque(false);

  TF_AddItemQty.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_AddItemQty.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_AddItemQtyFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_AddItemQtyFocusLost(evt);
   }
  });
  TF_AddItemQty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_AddItemQtyKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_AddItemId, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
     .addComponent(Lbl_AddItemQty, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addGap(10, 10, 10)
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)
     .addGroup(jPanel11Layout.createSequentialGroup()
      .addComponent(TF_AddItemId)
      .addGap(0, 0, 0)
      .addComponent(Btn_AddItemChooseId))
     .addGroup(jPanel11Layout.createSequentialGroup()
      .addComponent(TF_AddItemQty, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_AddItemIdInfoStockUnit)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_AddItemIdInfoUpdate))))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_AddItemChooseId)
     .addComponent(TF_AddItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_AddItemId))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_AddItemQty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_AddItemIdInfoStockUnit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_AddItemIdInfoUpdate)
     .addComponent(Lbl_AddItemQty)))
  );

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  jPanel3.setBackground(new java.awt.Color(255, 204, 153));
  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel4.setOpaque(false);

  Btn_ItemOutRemove.setText("Hapus");
  Btn_ItemOutRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutRemoveActionPerformed(evt);
   }
  });
  Btn_ItemOutRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ItemOutRemoveKeyPressed(evt);
   }
  });

  Btn_ItemOutEdit.setText("Ubah");
  Btn_ItemOutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutEditActionPerformed(evt);
   }
  });
  Btn_ItemOutEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ItemOutEditKeyPressed(evt);
   }
  });

  Btn_ItemOutMove.setText(">>");
  Btn_ItemOutMove.setToolTipText("pindahkan barang2 yg dipilih ke Sisi-B");
  Btn_ItemOutMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutMoveActionPerformed(evt);
   }
  });
  Btn_ItemOutMove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ItemOutMoveKeyPressed(evt);
   }
  });

  TF_ItemOutSumCount.setEditable(false);
  TF_ItemOutSumCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutSumCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("Sisi A");

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
    .addComponent(TF_ItemOutSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutRemove))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_ItemOutRemove)
    .addComponent(Btn_ItemOutEdit)
    .addComponent(Btn_ItemOutMove)
    .addComponent(TF_ItemOutSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel1))
  );

  Tbl_ItemOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemOut.setRowHeight(17);
  Tbl_ItemOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemOutMouseReleased(evt);
   }
  });
  Tbl_ItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemOutKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_ItemOut);

  Pnl_ItemOutInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemOutInfoName.setEditable(false);
  TA_ItemOutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoName.setColumns(20);
  TA_ItemOutInfoName.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_ItemOutInfoName.setLineWrap(true);
  TA_ItemOutInfoName.setRows(1);
  TA_ItemOutInfoName.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemOutInfoName);

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 554, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel6.setBackground(new java.awt.Color(204, 255, 102));
  jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Tbl_ItemIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemIn.setRowHeight(17);
  Tbl_ItemIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemInMouseReleased(evt);
   }
  });
  Tbl_ItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemInKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(Tbl_ItemIn);

  jPanel12.setOpaque(false);

  Btn_ItemInRemove.setText("Hapus");
  Btn_ItemInRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInRemoveActionPerformed(evt);
   }
  });
  Btn_ItemInRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ItemInRemoveKeyPressed(evt);
   }
  });

  Btn_ItemInEdit.setText("Ubah");
  Btn_ItemInEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInEditActionPerformed(evt);
   }
  });
  Btn_ItemInEdit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ItemInEditKeyPressed(evt);
   }
  });

  Btn_ItemInMove.setText("<<");
  Btn_ItemInMove.setToolTipText("pindahkan barang2 yg dipilih ke Sisi-A");
  Btn_ItemInMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInMoveActionPerformed(evt);
   }
  });
  Btn_ItemInMove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ItemInMoveKeyPressed(evt);
   }
  });

  TF_ItemInSumCount.setEditable(false);
  TF_ItemInSumCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInSumCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel10.setText("Sisi B");

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
    .addComponent(TF_ItemInSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInRemove))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_ItemInRemove)
    .addComponent(Btn_ItemInEdit)
    .addComponent(Btn_ItemInMove)
    .addComponent(TF_ItemInSumCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel10))
  );

  Pnl_ItemInInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemInInfoName.setEditable(false);
  TA_ItemInInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoName.setColumns(20);
  TA_ItemInInfoName.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
  TA_ItemInInfoName.setLineWrap(true);
  TA_ItemInInfoName.setRows(1);
  TA_ItemInInfoName.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_ItemInInfoName);

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane6)
  );

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane5)
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  Btn_Cancel.setText("Cancel {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addComponent(Btn_Ok)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_Ok))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jSeparator1)
     .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation valid;
  
  InfoConvertRule=new OInfoConvertRule(); valid=new OValidation(true);
  
  InfoConvertRule.Name=TF_Name.getText();
  if(!PText.checkInput(InfoConvertRule.Name, false, CApp.DbVarcharMaxSize, 0, 1, 1, 0)){
   valid.addError("\n- Inputan Nama belum benar.");
  }
  
  InfoConvertRule.IsActive=CB_IsActive.isSelected();
  
  InfoConvertRule.LastUpdate=null;
  
  InfoConvertRule.ListItemA=TableMdlItemOut.getRows();
  InfoConvertRule.ListItemB=TableMdlItemIn.getRows();
  /*
  if(InfoConvertRule.ListItemA.size()==0 || InfoConvertRule.ListItemB.size()==0){
   valid.addError("\n- Tabel Sisi A & Table Sisi B tidak boleh kosong.");
  }
  */
  
  if(!valid.getValid()){JOptionPane.showMessageDialog(null, "Inputan masih salah !\n"+valid.getError()); return;}
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_AddItemBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddItemBActionPerformed
  addItem(false);
 }//GEN-LAST:event_Btn_AddItemBActionPerformed

 private void Btn_AddItemChooseIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddItemChooseIdActionPerformed
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=false;
  
  if(!IFV.FItem.showForm()){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  // change ItemDet's variables directly from FItem
  I_CheckedId=IFV.FItem.ChoosedId[0];
  PGUI.changeDocument(EnableDocumentListener, TF_AddItemId, String.valueOf(I_CheckedId));
  inputItem();
  
  TF_AddItemQty.requestFocusInWindow();
 }//GEN-LAST:event_Btn_AddItemChooseIdActionPerformed

 private void Btn_ItemOutMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutMoveActionPerformed
  moveItems(true);
 }//GEN-LAST:event_Btn_ItemOutMoveActionPerformed

 private void Btn_ItemOutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutEditActionPerformed
  editItems(true);
 }//GEN-LAST:event_Btn_ItemOutEditActionPerformed

 private void Btn_ItemOutRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutRemoveActionPerformed
  removeItems(true);
 }//GEN-LAST:event_Btn_ItemOutRemoveActionPerformed

 private void Btn_ItemInMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInMoveActionPerformed
  moveItems(false);
 }//GEN-LAST:event_Btn_ItemInMoveActionPerformed

 private void Btn_ItemInRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInRemoveActionPerformed
  removeItems(false);
 }//GEN-LAST:event_Btn_ItemInRemoveActionPerformed

 private void Btn_ItemInEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInEditActionPerformed
  editItems(false);
 }//GEN-LAST:event_Btn_ItemInEditActionPerformed

 private void TF_AddItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_AddItemIdKeyPressed
  int consumed=PNav.onKey_TF(this, TF_AddItemId, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_AddItemA)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_AddItemChooseId)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER :
   case KeyEvent.VK_DOWN : if(Activ && RecheckId){inputItem();} PGUI.focus(TF_AddItemQty, false); break;
   case KeyEvent.VK_F6 : if(RecheckId){inputItem();} break;
   case KeyEvent.VK_SPACE : evt.consume(); Btn_AddItemChooseIdActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_AddItemIdKeyPressed

 private void TF_AddItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_AddItemIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_AddItemId, TF_ItemId_ShortcutKeys);
  TF_AddItemId.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_AddItemId);
 }//GEN-LAST:event_TF_AddItemIdFocusGained

 private void TF_AddItemIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_AddItemIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  TF_AddItemId.setBackground(CGUI.Color_TextBox_FocusOff);
  
  if(Activ && RecheckId){inputItem();}
 }//GEN-LAST:event_TF_AddItemIdFocusLost

 private void TF_AddItemQtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_AddItemQtyFocusGained
  DocumentListenerFocus=1;
  TF_AddItemQty.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_AddItemQty);
 }//GEN-LAST:event_TF_AddItemQtyFocusGained

 private void TF_AddItemQtyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_AddItemQtyFocusLost
  DocumentListenerFocus=-1;
  TF_AddItemQty.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_AddItemQtyFocusLost

 private void TF_AddItemQtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_AddItemQtyKeyPressed
  PNav.onKey_TF(this, TF_AddItemQty, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_AddItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_AddItemQtyKeyPressed

 private void TF_NameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_NameKeyPressed
  PNav.onKey_TF(this, TF_Name, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsActive)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_NameKeyPressed

 private void Tbl_ItemOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemOutKeyReleased
  onSelectedRowChangedItem(true, false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ItemOut, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ItemOutMove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_ItemInMove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_ItemOutKeyReleased

 private void Tbl_ItemOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemOutMouseReleased
  onSelectedRowChangedItem(true, false);
 }//GEN-LAST:event_Tbl_ItemOutMouseReleased

 private void Tbl_ItemInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemInKeyReleased
  onSelectedRowChangedItem(false, false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ItemIn, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_ItemInMove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_ItemInKeyReleased

 private void Tbl_ItemInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemInMouseReleased
  onSelectedRowChangedItem(false, false);
 }//GEN-LAST:event_Tbl_ItemInMouseReleased

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  
  if(wMode==1){
   setTitle("Buat Aturan Konversi");
   
   PGUI.requestFocusInWindow(TF_Name);
  }
  else{
   setTitle("Ubah Aturan Konversi");
   
   fillComponentsWithSetVariables();
   
   PGUI.requestFocusInWindow(TF_Name);
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void CB_IsActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsActiveKeyPressed
  PNav.onKey_CB(this, CB_IsActive, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Name)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_AddItemA)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_IsActiveKeyPressed

 private void Lbl_NameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_NameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_NameHelpMouseClicked

 private void Pnl_ItemOutInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemOut, TableMdlItemOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutInfoPreviewMouseClicked

 private void Pnl_ItemInInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemIn, TableMdlItemIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInInfoPreviewMouseClicked

 private void Btn_AddItemAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_AddItemAActionPerformed
  addItem(true);
 }//GEN-LAST:event_Btn_AddItemAActionPerformed

 private void TF_NameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_NameFocusGained
  TF_Name.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_Name);
 }//GEN-LAST:event_TF_NameFocusGained

 private void TF_NameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_NameFocusLost
  TF_Name.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_NameFocusLost

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_AddItemQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_AddItemQty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void TA_AddItemIdInfoNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TA_AddItemIdInfoNameMouseClicked
  if(I_CheckedId==-1){return;}
  
  PMyShop.viewFormInfo(I_CheckedId, IFV.FItemPreview);
 }//GEN-LAST:event_TA_AddItemIdInfoNameMouseClicked

 private void Btn_AddItemAKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddItemAKeyPressed
  PNav.onKey_Btn(this, Btn_AddItemA, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActive)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_AddItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_AddItemB)));
 }//GEN-LAST:event_Btn_AddItemAKeyPressed

 private void Btn_AddItemBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddItemBKeyPressed
  PNav.onKey_Btn(this, Btn_AddItemB, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActive)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_AddItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_AddItemA)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_AddItemBKeyPressed

 private void Btn_AddItemChooseIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_AddItemChooseIdKeyPressed
  PNav.onKey_Btn(this, Btn_AddItemChooseId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_AddItemA)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_AddItemQty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_AddItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_AddItemChooseIdKeyPressed

 private void Btn_ItemOutMoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ItemOutMoveKeyPressed
  PNav.onKey_Btn(this, Btn_ItemOutMove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ItemOutEdit)));
 }//GEN-LAST:event_Btn_ItemOutMoveKeyPressed

 private void Btn_ItemOutEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ItemOutEditKeyPressed
  PNav.onKey_Btn(this, Btn_ItemOutEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ItemOutMove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ItemOutRemove)));
 }//GEN-LAST:event_Btn_ItemOutEditKeyPressed

 private void Btn_ItemOutRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ItemOutRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_ItemOutRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ItemOutEdit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ItemOutRemoveKeyPressed

 private void Btn_ItemInMoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ItemInMoveKeyPressed
  PNav.onKey_Btn(this, Btn_ItemInMove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ItemInEdit)));
 }//GEN-LAST:event_Btn_ItemInMoveKeyPressed

 private void Btn_ItemInEditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ItemInEditKeyPressed
  PNav.onKey_Btn(this, Btn_ItemInEdit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ItemInMove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ItemInRemove)));
 }//GEN-LAST:event_Btn_ItemInEditKeyPressed

 private void Btn_ItemInRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ItemInRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_ItemInRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_ItemInEdit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ItemInRemoveKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_AddItemA;
 private javax.swing.JButton Btn_AddItemB;
 private javax.swing.JButton Btn_AddItemChooseId;
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ItemInEdit;
 private javax.swing.JButton Btn_ItemInMove;
 private javax.swing.JButton Btn_ItemInRemove;
 private javax.swing.JButton Btn_ItemOutEdit;
 private javax.swing.JButton Btn_ItemOutMove;
 private javax.swing.JButton Btn_ItemOutRemove;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JCheckBox CB_AddItemIdInfoUpdate;
 private javax.swing.JCheckBox CB_IsActive;
 private javax.swing.JLabel Lbl_AddItemChoose;
 private javax.swing.JLabel Lbl_AddItemId;
 private javax.swing.JLabel Lbl_AddItemQty;
 private javax.swing.JLabel Lbl_IsActive;
 private javax.swing.JLabel Lbl_Name;
 private javax.swing.JLabel Lbl_NameHelp;
 private XImgBoxURL Pnl_ItemInInfoPreview;
 private XImgBoxURL Pnl_ItemOutInfoPreview;
 private javax.swing.ButtonGroup RG_AddItemChoose;
 private javax.swing.JTextArea TA_AddItemIdInfoName;
 private javax.swing.JTextArea TA_ItemInInfoName;
 private javax.swing.JTextArea TA_ItemOutInfoName;
 private javax.swing.JTextField TF_AddItemId;
 private javax.swing.JTextField TF_AddItemIdInfoStockUnit;
 private javax.swing.JTextField TF_AddItemQty;
 private javax.swing.JTextField TF_ItemInSumCount;
 private javax.swing.JTextField TF_ItemOutSumCount;
 private javax.swing.JTextField TF_Name;
 private XTable Tbl_ItemIn;
 private XTable Tbl_ItemOut;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 // End of variables declaration//GEN-END:variables
}
