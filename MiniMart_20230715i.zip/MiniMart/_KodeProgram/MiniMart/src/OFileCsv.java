import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Vector;

public class OFileCsv extends File {
 
 char FieldDelimiter;
 char[] FieldsSeparators;
 char[] RecordsSeparators;
 boolean IncludeWhiteSpaceInField;
 
 int SampleRecordsMaxCount;
 
 OValidation IsValid;
 
 String FilePath;
 String FileName;
 
 long RecordsCount;
 int FieldsCount; // get Fields Count by reading the first record (table's header)
 
 Vector<String> Header;
 Vector<Vector<String>> SampleRecords;
 
 public OFileCsv(File f, char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators, boolean IncludeWhiteSpaceInField,
  int SampleRecordsMaxCount, OFormInformProgress Progress){
  super(f.getPath());
  
  setSeparatorChar(FieldDelimiter, FieldsSeparators, RecordsSeparators);
  this.IncludeWhiteSpaceInField=IncludeWhiteSpaceInField;
  this.SampleRecordsMaxCount=SampleRecordsMaxCount;
  
  FileName=getName();
  FilePath=getPath();
  
  generateFileInfo(Progress);
 }
 
 //
 public void setSeparatorChar(char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators){
  this.FieldDelimiter=FieldDelimiter;
  this.FieldsSeparators=FieldsSeparators;
  this.RecordsSeparators=RecordsSeparators;
 }
 
 void generateFileInfo(OFormInformProgress Progress){
  OValidation vl;
  IsValid=new OValidation(true);
  do{
   if(!PFile.compareIgnoreCaseExtension(FileName, "csv")){IsValid.addError("Ekstensi file bukan '.csv' !"); break;}
   vl=parseCSV(Progress); if(!vl.IsValid){IsValid.addError(vl.getError()); break;}
  }while(false);
 }
 
 OValidation parseCSV(OFormInformProgress Progress){
  OValidation ret=new OValidation(true);
  int SampleRecordsCount;
  Vector<String> Record;
  FileInputStream fis=null;
  BufferedInputStream bis=null;
  OCsvStreamReader csr=null;
  boolean error;
  int Step=0;
  String str=null;
  
  FieldsCount=0;
  RecordsCount=0;
  SampleRecords=new Vector();
  
  error=false;
  do{
   try{
    Progress.inform(0, "Mempersiapkan proses pembacaan ...", "-");
    
    Progress.inform(0, null, null);
    
    Step=1;
    
    fis=new FileInputStream(this);
    bis=new BufferedInputStream(fis);
    csr=new OCsvStreamReader(bis, FieldDelimiter, FieldsSeparators, RecordsSeparators, IncludeWhiteSpaceInField);
    
    Progress.inform(4, null, null);
    
    Progress.inform(0, "Membaca data file ...", "-");
    
    // read the first record (assumed as table's header)
    Progress.inform(0, null, "Membaca header tabel");
    
    Step=2;
    
    do{
     Header=csr.readNextRecord(true);
    }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile && csr.LastReadRecord_EmptyRecord);
    if(!csr.LastReadRecord_EmptyRecord){FieldsCount=Header.size();}
    
    Progress.inform(1, null, null);
    
    if(csr.LastReadChar_CharType==csr.CharType_EndOfFile){break;}

    // read the second record and so on ... (assumed as table's contents)
    Progress.inform(0, null, "Membaca isi data tabel");
    
    Step=3;
    
    SampleRecordsCount=0;
    do{
     
     Record=csr.readNextRecord(SampleRecordsCount<SampleRecordsMaxCount);
     
     do{
      if(csr.LastReadRecord_EmptyRecord){break;}
      if(csr.LastReadRecord_FieldsCount!=FieldsCount){error=true; break;}
      RecordsCount=RecordsCount+1;
      if(SampleRecordsCount<SampleRecordsMaxCount){
       SampleRecords.addElement(Record);
       SampleRecordsCount=SampleRecordsCount+1;
      }
     }while(false);
     if(error){break;}
     
    }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile);
    
    Progress.inform(95, null, null);
   }
   catch(Exception E){error=true;}
  }while(false);
  
  if(error){
   switch(Step){
    case 1 : str="Gagal membuka file !"; break;
    case 2 : str="Gagal membaca header tabel {"+csr.LastReadRecord_TrackReading.toString()+"} !"; break;
    case 3 : str="Gagal membaca isi data tabel yang ke-"+PText.intToString(RecordsCount+1)+" {"+csr.LastReadRecord_TrackReading.toString()+"} !"; break;
   }
   ret.addError(PText.getString(str, "", false));
  }
  
  if(csr!=null){try{csr.close();}catch(Exception E){}}
  if(bis!=null){try{bis.close();}catch(Exception E){}}
  if(fis!=null){try{fis.close();}catch(Exception E){}}
  
  return ret;
 }
 
}