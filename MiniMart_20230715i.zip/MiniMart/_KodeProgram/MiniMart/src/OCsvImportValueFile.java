import java.util.Vector;

public class OCsvImportValueFile extends OCsvImportValueCheckable {
 
 int FileFieldIndex;
 int FileFieldType;
 
 String FileFieldInText;
 OValue FileFieldInData;

 public OCsvImportValueFile(boolean GetValidFromThisClass,
  int FileFieldIndex, int FileFieldType) {
  super(GetValidFromThisClass);
  initVariables(FileFieldIndex, FileFieldType);
 }
 
 public void initVariables(int FileFieldIndex, int FileFieldType){
  this.FileFieldIndex = FileFieldIndex;
  this.FileFieldType = FileFieldType;
 }

 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile) {super.prepareGenerateSQLValue(LastReadRecordFromFile);}
 
 public int checkAndGenSQLValue(){
  int ret=OCsvImportValueCheckable.CheckError;
  int FieldsCount;
  
  do{
   if(FileFieldIndex<0){break;}
   FieldsCount=LastReadRecordFromFile.size();
   if(FieldsCount==0 || FileFieldIndex>FieldsCount-1){break;}
   FileFieldInText=LastReadRecordFromFile.elementAt(FileFieldIndex);
   FileFieldInData=OCsvStreamReader.getFieldValue(FileFieldInText, FileFieldType);
   if(FileFieldInData==null){break;}
   switch(FileFieldInData.getState()){
    case OValue.StateDefinedNull : ret=OCsvImportValueCheckable.CheckEmpty; break;
    case OValue.StateDefinedNoError :
     GeneratedSQLValue.setGeneratedSQLValue(PDatabase.getSQLString(FileFieldInData.getValue(), FileFieldType, CCore.vNull, false));
     ret=OCsvImportValueCheckable.CheckValid; break;
   }
  }while(false);
  
  return ret;
 }

}