public class OUnit {
 
 public static final double  mm_inch        = 1.0/25.4;
 public static final double  inch_mm        = 25.4;
 public static final double  inch_pixel     = 72;
 public static final double  pixel_inch     = 1.0/72.0;
 
 public static double inch_to_mm     (double Value){return Value*inch_mm;}
 public static double inch_to_pixel  (double Value){return Value*inch_pixel;}
 public static double mm_to_inch     (double Value){return Value*mm_inch;}
 public static double pixel_to_inch  (double Value){return Value*pixel_inch;}
 public static double mm_to_pixel    (double Value){return Value*mm_inch*inch_pixel;}
 public static double pixel_to_mm    (double Value){return Value*pixel_inch*inch_mm;}

}