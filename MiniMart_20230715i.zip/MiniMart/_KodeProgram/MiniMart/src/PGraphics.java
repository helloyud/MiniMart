import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class PGraphics {
 
 private static FontRenderContext Frc=new FontRenderContext(new AffineTransform(), true, true);

 // text
 public static ODrawInfoString getDrawInfoString(Font Fnt){
  ODrawInfoString ret=new ODrawInfoString();
  LineMetrics lmetrics=Fnt.getLineMetrics("Wg", Frc);
  
  ret.LineAscent=lmetrics.getAscent();
  ret.LineDescent=lmetrics.getDescent();
  ret.LineHeight=ret.LineAscent+ret.LineDescent;
  
  ret.SingleCharWidth=Fnt.getStringBounds("W", Frc).getWidth();
  
  return ret;
 }
 public static double getStringWidth(Font Fnt, String Str){
  Rectangle2D StringBox=Fnt.getStringBounds(Str, Frc);
  return StringBox.getWidth();
 }
 public static double getStringHeight(Font Fnt, String Str){
  Rectangle2D StringBox=Fnt.getStringBounds(Str, Frc);
  return StringBox.getHeight();
 }
 public static ODimension getStringDimension(Font Fnt, String Str){
  Rectangle2D StringBox=Fnt.getStringBounds(Str, Frc);
  return new ODimension(StringBox.getWidth(), StringBox.getHeight());
 }
 public static ODimension getStringFullDimension(Font Fnt, String Str){
  Rectangle2D StringBox=Fnt.getStringBounds(Str, Frc);
  LineMetrics lmetrics=Fnt.getLineMetrics("Wg", Frc);
  return new ODimension(StringBox.getWidth(), lmetrics.getAscent()+lmetrics.getDescent());
 }
 public static int getCharCountAtAreaWidth(Font Fnt, double AreaWidth){return (int)(AreaWidth/getStringWidth(Fnt, "W"));}
 public static double getInsetY(double BoxHeight, Font Fn, int TextLineCount, double TextLineSpacing, int Alignment){
  double ret=0;
  LineMetrics lmetrics;
  double line_height, text_totalheight;
  
  if(Alignment!=OAlignment.VerticalCenter && Alignment!=OAlignment.VerticalBottom){return ret;}
  
  lmetrics=Fn.getLineMetrics("Wg", Frc);
  line_height=lmetrics.getAscent()+lmetrics.getDescent();
  text_totalheight=TextLineCount*line_height+(TextLineCount-1)*TextLineSpacing;
  
  if(Alignment==OAlignment.VerticalCenter){ret=(BoxHeight-text_totalheight)/2;}
  else{ret=BoxHeight-text_totalheight;}
  
  return ret;
 }
 public static double getInsetX(double BoxWidth, Font Fnt, String Str, int Alignment){
  double ret=0;
  double text_size;
  
  if(Alignment!=OAlignment.HorizontalCenter && Alignment!=OAlignment.HorizontalRight){return ret;}
  
  text_size=Fnt.getStringBounds(Str, Frc).getWidth();
  if(Alignment==OAlignment.HorizontalCenter){ret=BoxWidth/2-text_size/2;}
  else{ret=BoxWidth-text_size;}
  
  return ret;
 }
 public static ODimension getDimension(Font Fn, int RowsCount, int ColumnsCount,
  double MarginHorizontal, double MarginVertical, double AddLineSpacing){
  ODimension ret=new ODimension();
  ODrawInfoString Text=getDrawInfoString(Fn);
  
  ret.setSize(
   2*MarginHorizontal+(ColumnsCount*Text.SingleCharWidth),
   2*MarginVertical+(RowsCount*Text.LineHeight+(RowsCount-1)*AddLineSpacing)
  );
  
  return ret;
 }
 public static ODimension getDimension(int RowsCount, int ColumnsCount,
  double LabelWidth, double LabelHeight, double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB,
  boolean IsRollPaper){
  ODimension ret=new ODimension();
  
  ret.Width=ColumnsCount*LabelWidth+(ColumnsCount-1)*LabelSpacingHorizontal;
  ret.Height=RowsCount*(LabelSpacingVerticalA+LabelHeight)+(RowsCount-1)*LabelSpacingVerticalB;
  if(IsRollPaper){ret.Height=ret.Height+LabelSpacingVerticalB;}
  
  return ret;
 }
 public static ODimensionAbsolute calculateLabelColumnAndRowCount(double BoxWidth, double BoxHeight,
  double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB, double LabelWidth, double LabelHeight,
  boolean IsRollPaper){
  ODimensionAbsolute ret=new ODimensionAbsolute();
  double coordinate, basic_size, additional_size;
  
  ret.ColumnsCount=0;
  basic_size=LabelWidth;
  additional_size=0;
  coordinate=0;
  do{
   if(coordinate+basic_size+additional_size>BoxWidth){break;}
   ret.ColumnsCount=ret.ColumnsCount+1;
   coordinate=coordinate+basic_size+LabelSpacingHorizontal;
  }while(coordinate<BoxWidth);
  
  ret.RowsCount=0;
  basic_size=LabelSpacingVerticalA+LabelHeight;
  additional_size=0; if(IsRollPaper){additional_size=LabelSpacingVerticalB;}
  coordinate=0;
  do{
   if(coordinate+basic_size+additional_size>BoxHeight){break;}
   ret.RowsCount=ret.RowsCount+1;
   coordinate=coordinate+basic_size+LabelSpacingVerticalB;
  }while(coordinate<BoxHeight);
  
  return ret;
 }
 public static int gradingLabelCount(double BoxWidth, double BoxHeight,
  double LabelSpacingHorizontal, double LabelSpacingVerticalA, double LabelSpacingVerticalB,
  double Label1_Width, double Label1_Height, double Label2_Width, double Label2_Height,
  boolean IsRollPaper,
  boolean CheckEqual, boolean CheckEqualByWidth, boolean CheckEqualByLowest){
  int ret=0; // 0 : label 1 = label 2, 1 : label 1 > label 2, 2 : label 2 > label 1
  ODimensionAbsolute L1, L2;
  int L1_count, L2_count;
  
  L1=calculateLabelColumnAndRowCount(BoxWidth, BoxHeight, LabelSpacingHorizontal,
   LabelSpacingVerticalA, LabelSpacingVerticalB, Label1_Width, Label1_Height, IsRollPaper);
  L2=calculateLabelColumnAndRowCount(BoxWidth, BoxHeight, LabelSpacingHorizontal,
   LabelSpacingVerticalA, LabelSpacingVerticalB, Label2_Width, Label2_Height, IsRollPaper);
  L1_count=L1.RowsCount*L1.ColumnsCount;
  L2_count=L2.RowsCount*L2.ColumnsCount;
  if(L1_count!=L2_count){
   if(L1_count>L2_count){ret=1;}else{ret=2;}
  }
  else{
   if(CheckEqual){
    if(CheckEqualByWidth){
     if(Label1_Width!=Label2_Width){
      if(CheckEqualByLowest){
       if(Label1_Width<Label2_Width){ret=1;}else{ret=2;}
      }
      else{
       if(Label1_Width>Label2_Width){ret=1;}else{ret=2;}
      }
     }
    }
    else{
     if(Label1_Height!=Label2_Height){
      if(CheckEqualByLowest){
       if(Label1_Height<Label2_Height){ret=1;}else{ret=2;}
      }
      else{
       if(Label1_Height>Label2_Height){ret=1;}else{ret=2;}
      }
     }
    }
   }
  }
  
  return ret;
 }
 public static boolean isRotated(int Orientation, double Width, double Height){
  boolean Rotate;
  
  switch(Orientation){
   case CPrint.PortraitOrientation : Rotate=Width>Height; break;
   case CPrint.LandscapeOrientation : Rotate=Width<Height; break;
   default : Rotate=false; break;
  }
  
  return Rotate;
 }
 public static ODimension getDimensionInOrientation(int Orientation, double Width, double Height){
  ODimension ret=new ODimension(Width, Height);
  
  if(isRotated(Orientation, Width, Height)){ret.setSize(Height, Width);}
  
  return ret;
 }

 public static BufferedImage getImageString(String Word, Font f, double ScaleFactor){
  // use GlyphVector
  BufferedImage ret;
  LineMetrics lmetric;
  Graphics2D g;
  float ascent;
  
  lmetric=f.getLineMetrics(Word, Frc);
  ascent=lmetric.getAscent();
  
  ret=new BufferedImage(
   PMath.round(f.getStringBounds(Word, Frc).getWidth()*ScaleFactor, 1),
   PMath.round((ascent+lmetric.getDescent())*ScaleFactor, 1),
   BufferedImage.TYPE_INT_RGB);
  
  g=ret.createGraphics();
  g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
  g.setBackground(CGUI.White);
  g.setColor(CGUI.Black);
  g.clearRect(0, 0, ret.getWidth(), ret.getHeight());
  g.scale(ScaleFactor, ScaleFactor);
  g.setFont(f);
  g.drawString(Word, 0, ascent);
  
  return ret;
 }

 // image
 /*
  if DrawInGraphicsRatio1 is enabled, then
   assume that the size of MemImg has already been created to match with the current graphic's ScaleFactor,
   so, it will not be drawn with any scale transformation and thus will be drawn with ScaleFactor 1
  otherwise,
   "MemImg and graphics" are assumed has the same ScaleFactor (1 : 1)
 */
 public static OCoordinate calculateCoordinate(double BoxWidth, double BoxHeight,
  double ImageWidth, double ImageHeight, double ImageScale, int ImageRotation,
  boolean AutoFitLargeImgToBox, boolean AutoFitSmallImgToBox, OAlignment Alignment,
  boolean AllowNegativeOffsetX, boolean AllowNegativeOffsetY){
  OCoordinate ret=new OCoordinate();
  boolean IsRotation=ImageRotation==CGraph.Rotate_090Degree || ImageRotation==CGraph.Rotate_270Degree;
  boolean FitToBox;
  double scale, BxWidth, BxHeight, ImgWidth, ImgHeight, dbl;
  OAlignment Align=Alignment;
  
  BxWidth=BoxWidth;
  BxHeight=BoxHeight;
  ImgWidth=PCore.subtBool_Double(!IsRotation, ImageWidth, ImageHeight)*ImageScale;
  ImgHeight=PCore.subtBool_Double(!IsRotation, ImageHeight, ImageWidth)*ImageScale;
  
  FitToBox=false;
  if(AutoFitSmallImgToBox || AutoFitLargeImgToBox){
   FitToBox=true;
   do{
    if((ImgWidth>BxWidth || ImgHeight>BxHeight) && AutoFitLargeImgToBox){break;}
    if((ImgWidth<BxWidth && ImgHeight<BxHeight) && AutoFitSmallImgToBox){break;}
    FitToBox=false;
   }while(false);
  }
  
  scale=1;
  if(FitToBox){
   // scale img to fit with box width
   scale=BxWidth/ImgWidth;
   // if (scale img to fit with box width is not match) then scale img to fit with box height
   if(ImgHeight*scale>BxHeight){scale=BxHeight/ImgHeight;}
  }
  ret.Width=ImgWidth*scale; ret.Height=ImgHeight*scale;
  
  if(Align==null){Align=new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalCenter);}
  switch(Align.AlignmentHorizontal){
   case OAlignment.HorizontalLeft : ret.OffsetX=0; break;
   case OAlignment.HorizontalCenter : ret.OffsetX=(BxWidth-ret.Width)/2; break;
   case OAlignment.HorizontalRight : ret.OffsetX=BxWidth-ret.Width; break;
  }
  if(!AllowNegativeOffsetX && ret.OffsetX<0){ret.OffsetX=0;}
  switch(Align.AlignmentVertical){
   case OAlignment.VerticalTop : ret.OffsetY=0; break;
   case OAlignment.VerticalCenter : ret.OffsetY=(BxHeight-ret.Height)/2; break;
   case OAlignment.VerticalBottom : ret.OffsetY=BxHeight-ret.Height; break;
  }
  if(!AllowNegativeOffsetY && ret.OffsetY<0){ret.OffsetY=0;}
  
  if(IsRotation){dbl=ret.Width; ret.Width=ret.Height; ret.Height=dbl;}
  
  return ret;
 }
 public static void manipulateGraphicsDrawInRatio1(Graphics2D g, boolean DrawInGraphicsRatio1, OScaleFactor ScaleDiff){
  AffineTransform at;
  double scalefactor_g_x, scalefactor_g_y;
  
  if(!DrawInGraphicsRatio1){return;}
  
  at=g.getTransform(); scalefactor_g_x=at.getScaleX(); scalefactor_g_y=at.getScaleY();
  g.scale(1/scalefactor_g_x, 1/scalefactor_g_y);
  
  if(ScaleDiff==null){return;}
  g.scale(ScaleDiff.X, ScaleDiff.Y);
 }
 public static void manipulateGraphicsRotation(Graphics2D g, int Rotation, double ImgWidth, double ImgHeight){
  double translate_x, translate_y, rotate_degree;
  
  if(Rotation==CGraph.Rotate_000Degree){return;}
  
  translate_x=0; translate_y=0; rotate_degree=0;
  switch(Rotation){
   case CGraph.Rotate_090Degree : translate_y=ImgWidth; rotate_degree=270; break;
   case CGraph.Rotate_180Degree : translate_x=ImgWidth; translate_y=ImgHeight; rotate_degree=180; break;
   case CGraph.Rotate_270Degree : translate_x=ImgHeight; rotate_degree=90; break;
  }
  g.translate(translate_x, translate_y);
  g.rotate(Math.toRadians(rotate_degree));
 }
 public static void paintImageXY(Graphics2D g, double OffsetX, double OffsetY,
  BufferedImage MemImg, boolean DrawInGraphicsRatio1, OScaleFactor ScaleDiff, double ScaleFactor, int Rotation){
  AffineTransform at;
  double img_w, img_h;
  
  if(MemImg==null){return;}
  at=g.getTransform();
  
  img_w=MemImg.getWidth(); img_h=MemImg.getHeight();
  
  g.translate(OffsetX, OffsetY);
  
  manipulateGraphicsDrawInRatio1(g, DrawInGraphicsRatio1, ScaleDiff);
  g.scale(ScaleFactor, ScaleFactor);
  manipulateGraphicsRotation(g, Rotation, img_w, img_h);
  g.drawImage(MemImg, 0, 0, PMath.round(img_w, 0), PMath.round(img_h, 0), null);
  
  g.setTransform(at);
 }
 public static void paintImageInBox(Graphics2D g, double OffsetX, double OffsetY,
  BufferedImage MemImg, boolean DrawInGraphicsRatio1, OScaleFactor ScaleDiff, double ScaleFactor, int Rotation,
  double BoxWidth, double BoxHeight, OAlignment Alignment, boolean IsAutoFit){
  // "MemImg and Box" are assumed has the same ScaleFactor (1 : 1)
  OCoordinate cor;
  AffineTransform at;
  double img_w, img_h, box_w, box_h,
   scalefactor_g_x, scalefactor_g_y, scalefactor_g_max;
  
  if(MemImg==null){return;}
  at=g.getTransform();
  
  img_w=MemImg.getWidth(); img_h=MemImg.getHeight();
  box_w=BoxWidth; box_h=BoxHeight;
  scalefactor_g_x=at.getScaleX(); scalefactor_g_y=at.getScaleY(); scalefactor_g_max=PMath.getMinMaxDouble(scalefactor_g_x, scalefactor_g_y, false);
  
  g.translate(OffsetX, OffsetY);
  manipulateGraphicsDrawInRatio1(g, DrawInGraphicsRatio1, ScaleDiff);
  if(DrawInGraphicsRatio1){box_w=box_w*scalefactor_g_max; box_h=box_h*scalefactor_g_max;}
  
  cor=calculateCoordinate(box_w, box_h, img_w, img_h, ScaleFactor, Rotation, IsAutoFit, false, Alignment, true, true);
  
  if(cor.Width!=0 && cor.Height!=0){
   g.translate(cor.OffsetX, cor.OffsetY);
   manipulateGraphicsRotation(g, Rotation, cor.Width, cor.Height);
   g.drawImage(MemImg, 0, 0, PMath.round(cor.Width, 0), PMath.round(cor.Height, 0), null);
  }
  
  g.setTransform(at);
 }

 public static void paintLine(Graphics2D g, double OffsetX, double OffsetY, double DestX, double DestY, double BorderWidth){
  Stroke strok=g.getStroke();
  g.setStroke(new BasicStroke((float)BorderWidth));
  g.drawLine(PMath.round(OffsetX, 0), PMath.round(OffsetY, 0), PMath.round(DestX, 0), PMath.round(DestY, 0));
  g.setStroke(strok);
 }

 // other
 public static BufferedImage cropHeightBarcode(boolean CroppingByRatio,
  BufferedImage MemImg, double BoxWidth, double BoxHeight){
  // both MemImg and Box are assumed has the same ScaleFactor
  BufferedImage ret=MemImg;
  double h, h_crop, y;
  double h_ratio_box, h_ratio_img;
  
  h=MemImg.getHeight();
  if(h<=BoxHeight){return ret;}
  
  if(!CroppingByRatio){h_crop=BoxHeight;}
  else{
   h_ratio_box=(double)BoxHeight/(double)BoxWidth;
   h_ratio_img=(double)h/(double)MemImg.getWidth();
   if(h_ratio_img<=h_ratio_box){return ret;}

   if(MemImg.getWidth()<=BoxWidth){h_crop=BoxHeight;}
   else{h_crop=h_ratio_box*MemImg.getWidth();}
  }
  
  y=(h/2)-(h_crop/2); if(y<0){y=0;}
  if(y+h_crop>h){h_crop=h-y;}
  ret=ret.getSubimage(0, PMath.round(y, 0), MemImg.getWidth(), PMath.round(h_crop, 0));
  
  return ret;
 }
 
}