public class OEditConvertItem {
 
 boolean EditQuantity; Double EditedQuantity;

 public OEditConvertItem(){clearAll();}
 
 OEditConvertItem clearAll(){
  init(
   false, -1);
  
  return this;
 }
 OEditConvertItem init(
  boolean EditQuantity, double EditedQuantity) {
  
  this.EditQuantity = EditQuantity; this.EditedQuantity = EditedQuantity;
  
  return this;
 }
 
}