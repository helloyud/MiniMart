import java.util.Date;
import java.util.Vector;

public class PTable {
 
 public static Vector<Object[]> subData(Vector<Object[]> Data, int[] SelectedRows, int[] ColumnsIndex){
  Vector<Object[]> ret=new Vector();
  int rowlength, rowtemp, collength, coltemp;
  Object[] DataObjs, RetObjs;
  
  rowlength=SelectedRows.length;
  collength=ColumnsIndex.length;
  
  if(rowlength==0){return ret;}
  
  rowtemp=0;
  do{
   DataObjs=Data.elementAt(SelectedRows[rowtemp]);
   
   RetObjs=new Object[collength];
   coltemp=0;
   do{
    RetObjs[coltemp]=DataObjs[ColumnsIndex[coltemp]];
    
    coltemp=coltemp+1;
   }while(coltemp!=collength);
   ret.addElement(RetObjs);
   
   rowtemp=rowtemp+1;
  }while(rowtemp!=rowlength);
  
  return ret;
 }
 public static Object[] subDataOfObjects(Vector<Object[]> Data, int[] SelectedRows, int ColumnsIndex){
  Object[] ret;
  int rowlength, rowtemp;
  Object[] DataObjs;
  
  rowlength=SelectedRows.length;
  ret=new Object[rowlength];
  
  if(rowlength==0){return ret;}
  
  rowtemp=0;
  do{
   DataObjs=Data.elementAt(SelectedRows[rowtemp]);
   
   ret[rowtemp]=DataObjs[ColumnsIndex];
   
   rowtemp=rowtemp+1;
  }while(rowtemp!=rowlength);
  
  return ret;
 }
 public static long[] subDataOfIds(Vector<Object[]> Data, int[] ColumnType, int[] SelectedRows, int ColumnIndex){
  long[] ret;
  int temp, length;
  boolean IsInteger=ColumnType[ColumnIndex]==CCore.TypeInteger;
		Object obj;
  
  length=SelectedRows.length;
  ret=PCore.newLongArray(length, -1);
  if(length==0){return ret;}
  
  temp=0;
  do{
			obj=Data.elementAt(SelectedRows[temp])[ColumnIndex];
			if(obj!=null){
				if(IsInteger){ret[temp]=(Integer)obj;}else{ret[temp]=(Long)obj;}
			}
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static String[] subDataOfStrings(Vector<Object[]> Data, int[] ColumnType, int[] SelectedRows, int ColumnIndex){
  String[] ret;
  int temp, length;
		Object obj;
  
  length=SelectedRows.length;
  ret=PCore.newStringArray(length, null);
  if(length==0){return ret;}
  
  temp=0;
  do{
			obj=Data.elementAt(SelectedRows[temp])[ColumnIndex];
   
   if(obj!=null){
    ret[temp]=(String)obj;
   }
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static int findData(int[] ColumnType, boolean ColumnTypeInVect, Vector<Object[]> Vect, int[] CheckCols_Vect, Object[] Data, int[] CheckCols_Data, int StartIndex, int Count){
  int ret=-1;
  int temp, Until;
		Object[] CurrRow;
  
  if(Vect==null){return ret;}
  Until=StartIndex+Count;
  if(Vect.size()==0 || Until>Vect.size()){return ret;}
  
  temp=StartIndex;
  do{
			CurrRow=Vect.elementAt(temp);
			if(CurrRow!=null){
				if(compare(ColumnType, ColumnTypeInVect, CurrRow, CheckCols_Vect, Data, CheckCols_Data)){ret=temp; break;}
			}
   temp=temp+1;
  }while(temp!=Until);
  
  return ret;
 }
 public static int findData(int[] ColumnType, boolean ColumnTypeInVect, Vector<Object[]> Vect, int[] CheckCols_Vect, Object[] Data, int[] CheckCols_Data){
  if(Vect==null){return -1;} return findData(ColumnType, ColumnTypeInVect, Vect, CheckCols_Vect, Data, CheckCols_Data, 0, Vect.size());
 }
	public static int findNumber(Vector<Object[]> Vect, long Num, int ObjIndex, boolean IsInteger, int StartIndex, int Count){
  int ret=-1;
  int temp, Until;
  long ObjNum;
		Object Obj;
  
  if(Vect==null){return ret;}
  Until=StartIndex+Count;
  if(Vect.size()==0 || Until>Vect.size()){return ret;}
  
  temp=StartIndex;
  do{
			Obj=Vect.elementAt(temp)[ObjIndex];
			if(Obj!=null){
				if(IsInteger){ObjNum=(Integer)Obj;}else{ObjNum=(Long)Obj;}
				if(ObjNum==Num){ret=temp; break;}
			}
   temp=temp+1;
  }while(temp!=Until);
  
  return ret;
 }
 public static int findNumber(Vector<Object[]> Vect, long Num, int ObjIndex, boolean IsInteger){
  if(Vect==null){return -1;} return findNumber(Vect, Num, ObjIndex, IsInteger, 0, Vect.size());
 }
 public static int findString(Vector<Object[]> Data, int Column, String Word, int StartIndex, int Count){
  int ret=-1;
  int temp, Until;
		Object Obj;
  
  if(Data==null){return ret;}
  Until=StartIndex+Count;
  if(Data.size()==0 || Until>Data.size()){return ret;}
  
  temp=StartIndex;
  do{
   Obj=Data.elementAt(temp)[Column];
   if(Obj!=null){
    if(PText.compare(Obj.toString(), Word, false)){ret=temp; break;}
   }
   temp=temp+1;
  }while(temp!=Until);
  
  return ret;
 }
 public static int findString(Vector<Object[]> Data, int Column, String Word){
  if(Data==null){return -1;} return findString(Data, Column, Word, 0, Data.size());
 }
	
 public static int findInsertPos(Vector<Object[]> Rows, int Column, String Word, int StartIndex, int Count,
		boolean IgnoreFoundIndex, boolean ReturnFirstFoundIndex, boolean ReturnPositiveIndex){
  int ret;
  int until, grade;
		boolean isfound;
  
		ret=StartIndex; isfound=false;
		until=StartIndex+Count;
  do{
   if(Rows==null){break;}
   if(Rows.size()==0 || until>Rows.size()){break;}
   do{
    grade=PText.grading(Word, PText.getStringObj(Rows.elementAt(ret)[Column], "", false), false);
    if(grade==1){break;}
    else{
     if(grade==0 && !IgnoreFoundIndex){isfound=true; if(ReturnFirstFoundIndex){break;}}
    }
    ret=ret+1;
   }while(ret!=until);
   if(isfound && !ReturnFirstFoundIndex){ret=ret-1;}
  }while(false);
		
		if(!isfound && !ReturnPositiveIndex){ret=-1*(ret+1);}
  
  return ret;
 }
 public static int findInsertPos(Vector<Object[]> Rows, int Column, String Word,
		boolean IgnoreFoundIndex, boolean ReturnFirstFoundIndex, boolean ReturnPositiveIndex){
  return findInsertPos(Rows, Column, Word, 0, Rows.size(), IgnoreFoundIndex, ReturnFirstFoundIndex, ReturnPositiveIndex);
 }
 public static int findInsertPos(Vector<Object[]> Rows, int Column, Date Value, int StartIndex, int Count,
		boolean IgnoreFoundIndex, boolean ReturnFirstFoundIndex, boolean ReturnPositiveIndex){
  int ret;
  int until, grade;
		Date Dt;
		boolean isfound;
  
		ret=StartIndex; isfound=false;
		until=StartIndex+Count;
  do{
   if(Rows==null){break;}
   if(Rows.size()==0 || until>Rows.size()){break;}
		 do{
				Dt=PCore.objDate(Rows.elementAt(ret)[Column], null);
				grade=PDate.grading(Dt, Value, Long.MIN_VALUE);
				if(grade==1){break;}
				else{
					if(grade==0 && !IgnoreFoundIndex){isfound=true; if(ReturnFirstFoundIndex){break;}}
				}
				ret=ret+1;
			}while(ret!=until);
			if(isfound && !ReturnFirstFoundIndex){ret=ret-1;}
		}while(false);
		
		if(!isfound && !ReturnPositiveIndex){ret=-1*(ret+1);}
  
  return ret;
 }
 public static int findInsertPos(Vector<Object[]> Rows, int Column, Date Value,
		boolean IgnoreFoundIndex, boolean ReturnFirstFoundIndex, boolean ReturnPositiveIndex){
  return findInsertPos(Rows, Column, Value, 0, Rows.size(), IgnoreFoundIndex, ReturnFirstFoundIndex, ReturnPositiveIndex);
 }
	
 public static int[] inspectLong(long[] Number, Vector<Object[]> Rows, int Column, boolean IsInteger, boolean ReturnFound, boolean ReturnIndexFromModel){
  Vector<Integer> ret=null;
  int temp, numlength, mdllength, found_mdlindex;
  boolean isfound;
  
  if(Number==null){return null;}
  
  ret=new Vector();
  numlength=Number.length;
  mdllength=Rows.size();
  if(numlength==0 || (!ReturnFound && ReturnIndexFromModel) ||
   (mdllength==0 && ReturnIndexFromModel) || (mdllength==0 && !ReturnIndexFromModel && ReturnFound)){
   return PCore.primArr_VectInt(ret);
  }
  
  if(mdllength==0){return PCore.newIntegerArrayInOrderedSequence(numlength, 0, 1);}
  
  temp=0;
  do{
   found_mdlindex=findNumber(Rows, Number[temp], Column, IsInteger, 0, mdllength);
   isfound=found_mdlindex!=-1;
   
   if((isfound==ReturnFound) || (!isfound==!ReturnFound)){
    if(ReturnIndexFromModel){ret.addElement(found_mdlindex);}
    else{ret.addElement(temp);}
   }
   
   temp=temp+1;
  }while(temp!=numlength);
  
  return PCore.primArr_VectInt(ret);
 }
	
 public static Object[] sumColumns(Vector<Object[]> Rows, int[] ColumnsType, int[] ColumnsIndex, int[] SelectedRows){
  Object[] ret;
  double[] result_double;
  long[] result_long;
  int tempcol, colcount, temprow, rowcount;
  Object[] CurrRow;
		Object obj;
  
  colcount=ColumnsIndex.length;
  result_long=PCore.newLongArray(colcount, 0);
  result_double=PCore.newDoubleArray(colcount, 0);
  
  rowcount=SelectedRows.length;
  if(Rows.size()!=0 && rowcount!=0){
   temprow=0;
   do{
    CurrRow=Rows.elementAt(SelectedRows[temprow]);
    
    tempcol=0;
    do{
					obj=CurrRow[ColumnsIndex[tempcol]];
					if(obj!=null){
						switch(ColumnsType[ColumnsIndex[tempcol]]){
							case CCore.TypeInteger : result_long[tempcol]=result_long[tempcol]+(Integer)obj;	break;
							case CCore.TypeLong : result_long[tempcol]=result_long[tempcol]+(Long)obj;	break;
							case CCore.TypeDouble : result_double[tempcol]=result_double[tempcol]+(Double)obj;	break;
						}
					}
     tempcol=tempcol+1;
    }while(tempcol!=colcount);
    
    temprow=temprow+1;
   }while(temprow!=rowcount);
  }
  
  ret=new Object[colcount];
  tempcol=0;
  do{
   switch(ColumnsType[ColumnsIndex[tempcol]]){
    case CCore.TypeInteger : ret[tempcol]=result_long[tempcol]; break;
    case CCore.TypeLong : ret[tempcol]=result_long[tempcol]; break;
    case CCore.TypeDouble : ret[tempcol]=result_double[tempcol]; break;
   }
   tempcol=tempcol+1;
  }while(tempcol!=colcount);
  
  return ret;
 }
	public static Object[] sumColumns(Vector<Object[]> Rows, int[] ColumnsType, int[] ColumnsIndex){
		return sumColumns(Rows, ColumnsType, ColumnsIndex, PCore.newIntegerArrayInOrderedSequence(Rows.size(), 0, 1));
	}
	
	public static Date getMinMaxDate(boolean IsMinimal, Vector<Object[]> Rows, int Column){
		Date ret=null;
		int temp, length;
		Date dt;
		int grade_mode;
		
		length=Rows.size();
		if(length==0){return ret;}
		
		ret=PCore.objDate(Rows.elementAt(0)[Column], null);
		if(length==1){return ret;}
		
		grade_mode=PCore.subtBool_Int(IsMinimal, 1, 2);
		temp=1;
		do{
			dt=PCore.objDate(Rows.elementAt(temp)[Column], null);
			if(PDate.grading(ret, dt, Long.MIN_VALUE)==grade_mode){ret=dt;}
			temp=temp+1;
		}while(temp!=length);
		
		return ret;
	}
 public static Object getCellValue(Vector<Object[]> Rows, int[] ColumnsType,
  int ActiveRow, int ActiveColumn, OTableCellReference CellRef,
  Object ReturnInvalidCell, Object ReturnNullValue){
  int Row;
		int Col;
  Object obj;
  
		Row=ActiveRow;
		switch(CellRef.GetRowMode){
			case 1 : Row=CellRef.GetRow; break;
			case 2 : Row=ActiveRow+CellRef.GetRow; break;
		}
		
		Col=ActiveColumn;
		switch(CellRef.GetColMode){
			case 1 : Col=CellRef.GetCol; break;
			case 2 : Col=ActiveColumn+CellRef.GetCol; break;
		}
		
		if(Row<0 || Row>=Rows.size() || Col<0 || Col>=ColumnsType.length){return ReturnInvalidCell;}
		
  obj=Rows.elementAt(Row)[Col];
  
  if(obj==null){return ReturnNullValue;}
  
  return obj;
 }
 public static Object getCellValue(OCustomModel Model,
  int ActiveRow, int ActiveColumn, OTableCellReference CellRef,
  Object ReturnInvalidCell, Object ReturnNullValue){
  return getCellValue(Model.getRows(), Model.getColumnsType(), ActiveRow, ActiveColumn, CellRef, ReturnInvalidCell, ReturnNullValue);
 }
 public static boolean compare(int[] ColumnsType, Vector<Object[]> ListA, Vector<Object[]> ListB, int[] CheckOnCustomColumns,
  int CheckMode, int CheckMode_ById_IdColumn){
  boolean ret=false;
  int line_A, line_B=0, size, size_A, size_B;
  Object[] RowA;
  boolean dobreak, found;
  OQuickListOfLong AlreadyFound_B;
  
  do{
   size_A=0; if(ListA!=null){size_A=ListA.size();}
   size_B=0; if(ListB!=null){size_B=ListB.size();}
   if(size_A!=size_B){break;}
   
   size=size_A; if(size==0){ret=true; break;}
   
   line_A=0; AlreadyFound_B=new OQuickListOfLong(1024, 1024, true, false);
   do{
    RowA=ListA.elementAt(line_A);
    
    dobreak=false;
    if(CheckMode==1){ // check Row-A with the same line of Row-B
     line_B=line_A;
     if(!compare(ColumnsType, true, RowA, CheckOnCustomColumns, ListB.elementAt(line_B), CheckOnCustomColumns)){dobreak=true;}
    }
    else{ // check Row-A with all lines of Row-B
     line_B=0; found=false;
     do{
      do{
       if(AlreadyFound_B.checkElement(line_B)>=0){break;}
       if(CheckMode==3){
        if(PCore.grading(ColumnsType[CheckMode_ById_IdColumn], -1, RowA[CheckMode_ById_IdColumn], true, null, ListB.elementAt(line_B)[CheckMode_ById_IdColumn], true, null)!=0){break;}
       }
       found=compare(ColumnsType, true, RowA, CheckOnCustomColumns, ListB.elementAt(line_B), CheckOnCustomColumns);
      }while(false);
      if(found){break;}
      
      line_B=line_B+1;
     }while(line_B!=size);
     if(line_B==size){dobreak=true;}
    }
    if(dobreak){break;}
    if(line_A!=size-1){
     // add found line-B as long as not at the last row of A
     AlreadyFound_B.addElement(line_B);
    }
    
    line_A=line_A+1;
   }while(line_A!=size);
   if(line_A!=size){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean compare(int[] ColumnsType, boolean ColumnsTypeInA, Object[] RowA, int[] CheckOnCustomColumns_RowA, Object[] RowB, int[] CheckOnCustomColumns_RowB){
  boolean ret=false;
  int temp, col_A, col_B, coltype;
  
  do{
   if(RowA==null || RowB==null){break;}
   
   temp=0;
   do{
    col_A=CheckOnCustomColumns_RowA[temp]; col_B=CheckOnCustomColumns_RowB[temp];
    if(ColumnsTypeInA){coltype=ColumnsType[col_A];}else{coltype=ColumnsType[col_B];}
    if(PCore.grading(coltype, -1, RowA[col_A], true, null, RowB[col_B], true, null)!=0){break;}
    temp=temp+1;
   }while(temp!=CheckOnCustomColumns_RowA.length);
   if(temp!=CheckOnCustomColumns_RowA.length){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean compare(Object[] TableRow, int[] TableColsType, Vector<Object[]> ChecksData, Vector<Integer> TableCheckCols, boolean UsingLogicAnd){
  int checkcurr, checkcount, tablecol;
  boolean ret=false;
  boolean found;
  Object[] CheckData;
  
  checkcount=ChecksData.size(); if(checkcount==0){return ret;}
  
  checkcurr=0;
  do{
   tablecol=TableCheckCols.elementAt(checkcurr);
   CheckData=ChecksData.elementAt(checkcurr);
   
   found=PCore.find(TableColsType[tablecol], CheckData, TableRow[tablecol])!=-1;

   if(UsingLogicAnd){
    if(!found){break;}
   }
   else{
    if(found){break;}
   }

   checkcurr=checkcurr+1;
  }while(checkcurr!=checkcount);

  if(UsingLogicAnd){
   if(checkcurr==checkcount){ret=true;}
  }
  else{
   if(checkcurr!=checkcount){ret=true;}
  }
  
  return ret;
 }
 public static int[] findAll(
  Vector<Object[]> TableRows, int[] TableColsType,
  Vector<Object[]> ChecksData, Vector<Integer> TableCheckCols,
  boolean UsingLogicAnd, boolean ReturnMatchTableRow){
  Vector<Integer> ret=new Vector();
  boolean match;
  int rowcount, rowcurr, checkcount;
  Object[] TableRow;
  
  do{
   rowcount=TableRows.size();
   checkcount=ChecksData.size();
   if(rowcount==0 || checkcount==0){break;}

   rowcurr=0;
   do{
    TableRow=TableRows.elementAt(rowcurr);
    
    match=compare(TableRow, TableColsType, ChecksData, TableCheckCols, UsingLogicAnd);
    
    if((match && ReturnMatchTableRow) || (!match && !ReturnMatchTableRow)){
     ret.addElement(rowcurr);
    }
    
    rowcurr=rowcurr+1;
   }while(rowcurr!=rowcount);
  }while(false);
  
  return PCore.primArr_VectInt(ret);
 }
 public static int[] findAll(
  Vector<Object[]> TableRows, int[] TableColsType, int[] TableLookupCols,
  Vector<Object[]> ChecksData, int[] ChecksDataLookupCols,
  boolean ReturnMatchTableRow){
  Vector<Integer> ret=new Vector();
  boolean match;
  int rowcount, rowcurr, checkcount;
  Object[] TableRow;
  
  do{
   rowcount=TableRows.size();
   checkcount=ChecksData.size();
   if(rowcount==0 || checkcount==0){break;}

   rowcurr=0;
   do{
    TableRow=TableRows.elementAt(rowcurr);
    
    match=findData(TableColsType, false, ChecksData, ChecksDataLookupCols, TableRow, TableLookupCols)!=-1;
    
    if((match && ReturnMatchTableRow) || (!match && !ReturnMatchTableRow)){
     ret.addElement(rowcurr);
    }
    
    rowcurr=rowcurr+1;
   }while(rowcurr!=rowcount);
  }while(false);
  
  return PCore.primArr_VectInt(ret);
 }

}