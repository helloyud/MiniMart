import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.table.TableColumnModel;

public class F_TransPreview extends XFormPreview {
 
 // Set
 boolean wIsPreTrans; boolean wIsPending; long wId;
 OInfoTrans wInfoTrans;
 
 String TransName;
 
 // Item In
 OCustomTableModel TableMdlItemIn;
	String[] TableMdlItemInColsName;
	int[] TableMdlItemInColsType, TableMdlItemInColsShowOption, TableMdlItemInColsVisible, TableItemInColsWidth;
	boolean[] TableMdlItemInColsEditable;
 String QueryItemInOrderBy, QueryItemInTbHaving;
 boolean TIItemInClear; // table-content cleared sign
 int LastSelectedRowItemIn;
 boolean InfoItemInClear; // panel-info cleared sign
 
 boolean[] ItemInSumColumn; double[] ItemInSumResult;
 int ItemInTotalCount; int ItemInTotalCheckedCount; double ItemInTotalPrice;
 
 // Item Out
 OCustomTableModel TableMdlItemOut;
	String[] TableMdlItemOutColsName;
	int[] TableMdlItemOutColsType, TableMdlItemOutColsShowOption, TableMdlItemOutColsVisible, TableItemOutColsWidth;
	boolean[] TableMdlItemOutColsEditable;
 String QueryItemOutOrderBy, QueryItemOutTbHaving;
 boolean TIItemOutClear; // table-content cleared sign
 int LastSelectedRowItemOut;
 boolean InfoItemOutClear; // panel-info cleared sign
 
 boolean[] ItemOutSumColumn; double[] ItemOutSumResult;
 int ItemOutTotalCount; int ItemOutTotalCheckedCount; double ItemOutTotalPrice; double ItemOutTotalBasicPrice;
 
 // Pay Out
 OCustomTableModel TableMdlPayOut;
 boolean TIPayOutClear; // table-content cleared sign
 int LastSelectedRowPayOut;
 boolean InfoPayOutClear; // panel-info cleared sign
 
 boolean[] PayOutSumColumn; double[] PayOutSumResult;
 int PayOutTotalCount; double PayOutTotalPrice;
 
 // Pay In
 OCustomTableModel TableMdlPayIn;
 boolean TIPayInClear; // table-content cleared sign
 int LastSelectedRowPayIn;
 boolean InfoPayInClear; // panel-info cleared sign
 
 boolean[] PayInSumColumn; double[] PayInSumResult;
 int PayInTotalCount; double PayInTotalPrice;
 
 public F_TransPreview(MInterFormVariables IFV_) {
  TableColumnModel ColMdl;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // Item In
  TableMdlItemIn=new OCustomTableModel(true, CApp.Default_TransItem_Checked, false);
  Tbl_ItemIn.setModel(TableMdlItemIn);
  TableMdlItemInColsName=PCore.refArr("Id Brg", "Nm Brg", "Nama Brg", "Qty", "Satuan", "Hrg Total", "Hrg Sat.", "Komentar",
   "File Gambar", "Kategori");
	 TableMdlItemInColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeString, CCore.TypeString);
  TableMdlItemInColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableMdlItemInColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  TableMdlItemInColsEditable=PCore.newBooleanArray(TableMdlItemInColsName.length, false);
  ItemInSumColumn=PCore.primArr(false, false, false, false, false, true, false, false, false, false);
  ItemInSumResult=new double[ItemInSumColumn.length];
  QueryItemInTbHaving="tb4";
  TIItemInClear=true;
  LastSelectedRowItemIn=-1;
  InfoItemInClear=true;
  CB_ItemInCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableItemInViewStructure(true, true);
  updateTableItemInView(false);
  
  CmB_ItemInFind.setSelectedIndex(1);
  
  Pnl_ItemInInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Item Out
  TableMdlItemOut=new OCustomTableModel(true, CApp.Default_TransItem_Checked, false);
  Tbl_ItemOut.setModel(TableMdlItemOut);
  TableMdlItemOutColsName=PCore.refArr("Id Brg", "Nm Brg", "Nama Brg", "Qty", "Satuan", "Hrg Total", "Hrg Sat.", "Komentar",
   "File Gambar", "Kategori", "H-Beli Sat.", "HPP");
  TableMdlItemOutColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble);
  TableMdlItemOutColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableMdlItemOutColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  TableMdlItemOutColsEditable=PCore.newBooleanArray(TableMdlItemOutColsName.length, false);
  ItemOutSumColumn=PCore.primArr(false, false, false, false, false, true, false, false, false, false, false, true);
  ItemOutSumResult=new double[ItemOutSumColumn.length];
  QueryItemOutTbHaving="tb4";
  TIItemOutClear=true;
  LastSelectedRowItemOut=-1;
  InfoItemOutClear=true;
  CB_ItemOutCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableItemOutViewStructure(true, true);
  updateTableItemOutView(false);
  
  CmB_ItemOutFind.setSelectedIndex(1);
  
  Pnl_ItemOutInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // Pay Out
  TableMdlPayOut=new OCustomTableModel();
  TableMdlPayOut.setColumnsInfo(
   PCore.refArr("Enumerasi", "Tanggal", "KasId", "Kas Kredit", "Jumlah", "Keterangan"),
   PCore.primArr(CCore.TypeInteger, CCore.TypeDate, CCore.TypeInteger, CCore.TypeString, CCore.TypeDouble, CCore.TypeString),
   PCore.primArr(1, 3, 4, 5));
  Tbl_PayOut.setModel(TableMdlPayOut);
  PayOutSumColumn=PCore.primArr(false, false, false, false, true, false);
  PayOutSumResult=new double[PayOutSumColumn.length];
  ColMdl=Tbl_PayOut.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(90);
  ColMdl.getColumn(1).setPreferredWidth(135);
  ColMdl.getColumn(2).setPreferredWidth(105);
  ColMdl.getColumn(3).setPreferredWidth(190);
  
  TIPayOutClear=true;
  LastSelectedRowPayOut=-1;
  InfoPayOutClear=true;
  
  // Pay In
  TableMdlPayIn=new OCustomTableModel();
  TableMdlPayIn.setColumnsInfo(
   PCore.refArr("Enumerasi", "Tanggal", "KasId", "Kas Kredit", "Jumlah", "Keterangan"),
   PCore.primArr(CCore.TypeInteger, CCore.TypeDate, CCore.TypeInteger, CCore.TypeString, CCore.TypeDouble, CCore.TypeString),
   PCore.primArr(1, 3, 4, 5));
  Tbl_PayIn.setModel(TableMdlPayIn);
  PayInSumColumn=PCore.primArr(false, false, false, false, true, false);
  PayInSumResult=new double[PayInSumColumn.length];
  ColMdl=Tbl_PayIn.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(90);
  ColMdl.getColumn(1).setPreferredWidth(135);
  ColMdl.getColumn(2).setPreferredWidth(105);
  ColMdl.getColumn(3).setPreferredWidth(190);
  
  TIPayInClear=true;
  LastSelectedRowPayIn=-1;
  InfoPayInClear=true;
 }
 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_ItemInFind, Tbl_ItemIn,
    
    TF_ItemOutFind, Tbl_ItemOut),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
 }
 
 public boolean proceed(Object AKey){
  boolean ret=false;
  Object[] objs;
  
  do{
   TransName=PText.getString(!wIsPreTrans, "Transaksi", "Pra-Transaksi")+PText.getString(!wIsPending, "", " Pending");
   
   objs=(Object[])AKey;
   wIsPreTrans=(Boolean)objs[0];
   wIsPending=(Boolean)objs[1];
   wId=(Long)objs[2];
   
   if(!wIsPending){wInfoTrans=PMyShop.getTransInfo(IFV.Stm, wIsPreTrans, wId);}
   else{wInfoTrans=PMyShop.getTransPendingInfo(IFV.Stm, wIsPreTrans, wId);}
   
   if(wInfoTrans==null){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public String getName(){return TransName;}
 
 void clearComponents(){
  clearItemIn(); PGUI.clearText(TF_ItemInFind);
  clearItemOut(); PGUI.clearText(TF_ItemOutFind);
  clearPayOut();
  clearPayIn();
  
  clearSetVariables();
 }
 
 void clearSetVariables(){
  wInfoTrans=null;
 }
 
 void fillComponentsWithSetVariables(){
  TF_Id.setText(PText.separate(String.valueOf(wInfoTrans.TransId), " - ", PCore.primArr(4, 2, 2, 4, 4)));
  CB_IsImportant.setSelected(wInfoTrans.Important);
  TF_IdExternal.setText(PText.getString(wInfoTrans.InfoIdExternal, "", true));
  TF_TransDate.setText(PText.dateToString(wInfoTrans.Dt, 2));
  TF_TransType.setText(PText.getString(wInfoTrans.TypeId, -1, wInfoTrans.TypeName, ""));
  TA_CashIn.setText(getStringOfCash(wInfoTrans.CashInId, wInfoTrans.CashInName, wInfoTrans.CashInComment));
  TA_CashOut.setText(getStringOfCash(wInfoTrans.CashOutId, wInfoTrans.CashOutName, wInfoTrans.CashOutComment));
  TF_Subject.setText(PText.getString(wInfoTrans.SubjectId, -1, wInfoTrans.SubjectName, ""));
  TF_Salesman.setText(PText.getString(wInfoTrans.SalesmanId, -1, wInfoTrans.SalesmanName, ""));
  TF_Salesman.setText(PText.getString(wInfoTrans.CreditDays, -1,
   wInfoTrans.CreditDays+" hari ("+PText.dateToString(PDate.calculateDateByDay(wInfoTrans.Dt, wInfoTrans.CreditDays, 1), 2)+")", ""));
  TF_RepaymentPeriod.setText(PText.getString(wInfoTrans.RepaymentPeriodStart==null || wInfoTrans.RepaymentPeriodEnd==null, "",
   PText.dateToString(wInfoTrans.RepaymentPeriodStart, 2)+" - "+PText.dateToString(wInfoTrans.RepaymentPeriodEnd, 2)));
  TA_Comment.setText(PText.getString(wInfoTrans.Comment, "", false));
  
  fillItemIn();
  fillItemOut();
  fillPayOut();
  fillPayIn();
 }
 String getStringOfCash(int CashId, String CashName, String CashComment){
  StringBuilder ret;
  boolean first;
  
  ret=new StringBuilder(); first=true;
  if(CashId!=-1){
   if(first){first=false;}else{ret.append("\n");} ret.append(CashName);
  }
  if(!PText.isEmptyString(CashComment, false, true)){
   if(first){first=false;}else{ret.append("\n");} ret.append("{ "+CashComment+" }");
  }
  
  return ret.toString();
 }
 
 void updateTableItemInView(boolean Requery){
  TableMdlItemIn.updateColumnsInfo(TableMdlItemInColsName, TableMdlItemInColsType, TableMdlItemInColsShowOption,
   TableMdlItemInColsVisible, TableMdlItemInColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_ItemIn, TableItemInColsWidth);
  if(!Requery){onSelectedRowItemInChanged(false);}
  else{fillItemIn();}
 }
 void buildTableItemInColumns(){
  boolean IsCategorized=CB_ItemInCategorized.isSelected();
  TableMdlItemInColsVisible=PCore.primArr(2, 3, 6, 5);
  TableItemInColsWidth=PCore.primArr(25, 260, 40, 75, 85);
  if(!IsCategorized){
   TableMdlItemInColsVisible=PCore.insert(TableMdlItemInColsVisible, TableMdlItemInColsVisible.length, 0);
   TableItemInColsWidth=PCore.insert(TableItemInColsWidth, TableItemInColsWidth.length, 95);
  }
  else{
   TableMdlItemInColsVisible=PCore.insert(TableMdlItemInColsVisible, 0, 9);
   TableItemInColsWidth=PCore.insert(TableItemInColsWidth, 1, 130);
  }
 }
 void buildTableItemInOrderBy(){
  boolean IsCategorized=CB_ItemInCategorized.isSelected();
  QueryItemInOrderBy=PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }
 void buildTableItemInViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableItemInColumns();}
  if(RebuildOrderBy){buildTableItemInOrderBy();}
 }
 void changeItemInViewByCategorized(){
  buildTableItemInViewStructure(true, true);
  updateTableItemInView(true);
 }
 
 void updateTableItemOutView(boolean Requery){
  TableMdlItemOut.updateColumnsInfo(TableMdlItemOutColsName, TableMdlItemOutColsType, TableMdlItemOutColsShowOption,
   TableMdlItemOutColsVisible, TableMdlItemOutColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_ItemOut, TableItemOutColsWidth);
  if(!Requery){onSelectedRowItemOutChanged(false);}
  else{fillItemOut();}
 }
 void buildTableItemOutColumns(){
  boolean IsCategorized=CB_ItemOutCategorized.isSelected();
  boolean IsShowBasicPrice=CB_ItemOutShowBasicPrice.isSelected();
  if(!IsShowBasicPrice){
   TableMdlItemOutColsVisible=PCore.primArr(2, 3, 6, 5);
   TableItemOutColsWidth=PCore.primArr(25, 260, 40, 75, 85);
  }
  else{
   TableMdlItemOutColsVisible=PCore.primArr(2, 3, 5, 11);
   TableItemOutColsWidth=PCore.primArr(25, 260, 40, 85, 85);
  }
  if(!IsCategorized){
   TableMdlItemOutColsVisible=PCore.insert(TableMdlItemOutColsVisible, TableMdlItemOutColsVisible.length, 0);
   TableItemOutColsWidth=PCore.insert(TableItemOutColsWidth, TableItemOutColsWidth.length, 95);
  }
  else{
   TableMdlItemOutColsVisible=PCore.insert(TableMdlItemOutColsVisible, 0, 9);
   TableItemOutColsWidth=PCore.insert(TableItemOutColsWidth, 1, 130);
  }
 }
 void buildTableItemOutOrderBy(){
  boolean IsCategorized=CB_ItemOutCategorized.isSelected();
  QueryItemOutOrderBy=PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }
 void buildTableItemOutViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableItemOutColumns();}
  if(RebuildOrderBy){buildTableItemOutOrderBy();}
 }
 void changeItemOutViewByHPP(){
  buildTableItemOutViewStructure(true, false);
  updateTableItemOutView(false);
 }
 void changeItemOutViewByCategorized(){
  buildTableItemOutViewStructure(true, true);
  updateTableItemOutView(true);
 }
 
 void onSelectedRowItemInChanged(boolean UpdateAnyway){
  int row=Tbl_ItemIn.getSelectedRow();
  if(LastSelectedRowItemIn==row && !UpdateAnyway){return;}
  LastSelectedRowItemIn=row;
  if(row==-1){clearInfoItemIn(); return;}
  fillInfoItemIn(row);
 }
 void onSelectedRowItemOutChanged(boolean UpdateAnyway){
  int row=Tbl_ItemOut.getSelectedRow();
  if(LastSelectedRowItemOut==row && !UpdateAnyway){return;}
  LastSelectedRowItemOut=row;
  if(row==-1){clearInfoItemOut(); return;}
  fillInfoItemOut(row);
 }
 void onSelectedRowPayOutChanged(boolean UpdateAnyway){
  int row=Tbl_PayOut.getSelectedRow();
  if(LastSelectedRowPayOut==row && !UpdateAnyway){return;}
  LastSelectedRowPayOut=row;
  if(row==-1){clearInfoPayOut(); return;}
  fillInfoPayOut(row);
 }
 void onSelectedRowPayInChanged(boolean UpdateAnyway){
  int row=Tbl_PayIn.getSelectedRow();
  if(LastSelectedRowPayIn==row && !UpdateAnyway){return;}
  LastSelectedRowPayIn=row;
  if(row==-1){clearInfoPayIn(); return;}
  fillInfoPayIn(row);
 }
 
 String queryOfItemIn(boolean IsPreTrans, boolean IsPending, long TransId, boolean IsItemCategorized, long[] Item){
  String TableTrans, Con, OrderBy;
  
  TableTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans")+PText.getString(!IsPending, "", "Pend");
  Con=""; if(!PCore.isArrayEmpty(Item, true)){Con=" and Item in("+PText.toString(Item, 0, Item.length, ",")+")";}
  OrderBy=PText.getString(!IsItemCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
  
  return 
   "select TransItem, ItemName, ItemNm, TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, PictureFile, Min(CategoryOfItem.Name) as 'CategoryName', TransItemChecked from "+
    "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
     "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
      "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit from "+
       "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
       "from "+TableTrans+"XItemIn where "+TableTrans+"="+TransId+Con+") as tb1 "+
      "left join Item on tb1.TransItem=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
    "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem) as tb4 "+
   "left join ItemXCategory on tb4.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.TransItem"+
   QueryItemInOrderBy;
 }
 String queryOfItemOut(boolean IsPreTrans, boolean IsPending, long TransId, boolean IsItemCategorized, long[] Item){
  String TableTrans, Con, OrderBy;
  
  TableTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans")+PText.getString(!IsPending, "", "Pend");
  Con=""; if(!PCore.isArrayEmpty(Item, true)){Con=" and Item in("+PText.toString(Item, 0, Item.length, ",")+")";}
  OrderBy=PText.getString(!IsItemCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
  
  return 
   "select TransItem, ItemName, ItemNm, TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, PictureFile, Min(CategoryOfItem.Name) as 'CategoryName', BuyPriceEstimation, TransItemPriceTotalBasic, TransItemChecked from "+
    "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
     "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
      "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit, BuyPriceEstimation, TransItemQty*BuyPriceEstimation as 'TransItemPriceTotalBasic' from "+
       "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
       "from "+TableTrans+"XItemOut where "+TableTrans+"="+TransId+Con+") as tb1 "+
      "left join Item on tb1.TransItem=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
    "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem) as tb4 "+
   "left join ItemXCategory on tb4.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.TransItem"+
   QueryItemOutOrderBy;
 }
 String queryOfPay(boolean IsPreTrans, boolean IsPending, boolean IsPayIn, long TransId, long[] Enumerations){
  String TableTrans, TablePay, Con, OrderBy;
  
  TableTrans=PText.getString(!IsPreTrans, "Trans", "PreTrans")+PText.getString(!IsPending, "", "Pend");
  if(!IsPending){TablePay=TableTrans+"X"+PText.getString(!IsPayIn, "Payment", "PaymentIn");}
  else{TablePay=TableTrans+"X"+PText.getString(!IsPayIn, "PaymentOut", "PaymentIn");}
  Con=""; if(!PCore.isArrayEmpty(Enumerations, true)){Con=" and Enumeration in("+PText.toString(Enumerations, 0, Enumerations.length, ",")+")";}
  OrderBy=" order by PaymentDate asc, Cash.Name asc";
  
  return 
   "select Enumeration, PaymentDate, Cash, Cash.Name as 'CashName', Price, Comment from "+
    "(select * from "+TablePay+" where "+TableTrans+"="+TransId+Con+") as tb1 "+
   "left join Cash on tb1.Cash=Cash.Id"+
   OrderBy;
 }
 
 void changeSummaryItemIn(int Count, int CheckedCount, double Price){
  ItemInTotalCount=Count;
  ItemInTotalCheckedCount=CheckedCount;
  ItemInTotalPrice=Price;
  
  PGUI.fillCountAndChecked(true, TF_SummaryItemInCount, ItemInTotalCount, ItemInTotalCheckedCount);
  PGUI.fillPrice(true, TF_SummaryItemInPrice, ItemInTotalPrice);
  
  PGUI.fillCountAndChecked(true, TF_ItemInCount, ItemInTotalCount, ItemInTotalCheckedCount);
  PGUI.fillPrice(true, TF_ItemInPrice, ItemInTotalPrice);
 }
 void fillItemIn(){
  int datacount;
  
  clearItemIn();
  
  TIItemInClear=false;
  
  datacount=PDatabase.queryToTableWithSum(IFV.Stm, queryOfItemIn(wIsPreTrans, wIsPending, wId, CB_ItemInCategorized.isSelected(), null),
   TableMdlItemIn, ItemInSumColumn, ItemInSumResult, false, false, null, -1, true, 10);
  if(datacount==-1){clearItemIn(); return;}
  
  changeSummaryItemIn(TableMdlItemIn.getRowCount(), TableMdlItemIn.getCheckedCount(), ItemInSumResult[5]);
  
  if(datacount>0){Tbl_ItemIn.changeSelection(0, 0, false, false); onSelectedRowItemInChanged(false);}
 }
 void clearItemIn(){
  if(TIItemInClear){return;}
  
  TableMdlItemIn.removeAll();
  changeSummaryItemIn(0, 0, 0);
  LastSelectedRowItemIn=-1;
  clearInfoItemIn();
  
  TIItemInClear=true;
 }
 void fillInfoItemIn(int row){
  Object[] objs=TableMdlItemIn.Mdl.Rows.elementAt(row);
  
  TA_ItemInInfoCategory.setText(PCore.objString(objs[9], ""));
  TA_ItemInInfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemInInfoPreview, IFV.Conf.ImageDirItem, objs[8]);
  
  InfoItemInClear=false;
 }
 void clearInfoItemIn(){
  if(InfoItemInClear){return;}
  
  TA_ItemInInfoCategory.setText("");
  TA_ItemInInfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_ItemInInfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoItemInClear=true;
 }
 
 void changeSummaryItemOut(int Count, int CheckedCount, double Price, double BasicPrice){
  ItemOutTotalCount=Count;
  ItemOutTotalCheckedCount=CheckedCount;
  ItemOutTotalPrice=Price;
  ItemOutTotalBasicPrice=BasicPrice;
  
  PGUI.fillCountAndChecked(true, TF_SummaryItemOutCount, ItemOutTotalCount, ItemOutTotalCheckedCount);
  PGUI.fillPrice(true, TF_SummaryItemOutPrice, ItemOutTotalPrice);
  refreshSummaryItemOutBasicPrice();
  
  PGUI.fillCountAndChecked(true, TF_ItemOutCount, ItemOutTotalCount, ItemOutTotalCheckedCount);
  PGUI.fillPrice(true, TF_ItemOutPrice, ItemOutTotalPrice);
 }
 void refreshSummaryItemOutBasicPrice(){PGUI.fillPrice(CB_SummaryItemOutBasic.isSelected(), TF_SummaryItemOutBasicPrice, ItemOutTotalBasicPrice);}
 void fillItemOut(){
  int datacount;
  
  clearItemOut();
  
  TIItemOutClear=false;
  
  datacount=PDatabase.queryToTableWithSum(IFV.Stm, queryOfItemOut(wIsPreTrans, wIsPending, wId, CB_ItemOutCategorized.isSelected(), null),
   TableMdlItemOut, ItemOutSumColumn, ItemOutSumResult, false, false, null, -1, true, 12);
  if(datacount==-1){clearItemOut(); return;}
  
  changeSummaryItemOut(TableMdlItemOut.getRowCount(), TableMdlItemOut.getCheckedCount(), ItemOutSumResult[5], ItemOutSumResult[11]);
  
  if(datacount>0){Tbl_ItemOut.changeSelection(0, 0, false, false); onSelectedRowItemOutChanged(false);}
 }
 void clearItemOut(){
  if(TIItemOutClear){return;}
  
  TableMdlItemOut.removeAll();
  changeSummaryItemOut(0, 0, 0, 0);
  LastSelectedRowItemOut=-1;
  clearInfoItemOut();
  
  TIItemOutClear=true;
 }
 void fillInfoItemOut(int row){
  Object[] objs=TableMdlItemOut.Mdl.Rows.elementAt(row);
  
  TA_ItemOutInfoCategory.setText(PCore.objString(objs[9], ""));
  TA_ItemOutInfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemOutInfoPreview, IFV.Conf.ImageDirItem, objs[8]);
  
  InfoItemOutClear=false;
 }
 void clearInfoItemOut(){
  if(InfoItemOutClear){return;}
  
  TA_ItemOutInfoCategory.setText("");
  TA_ItemOutInfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_ItemOutInfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoItemOutClear=true;
 }
 
 void changeSummaryPayOut(int Count, double Price){
  PayOutTotalCount=Count;
  PayOutTotalPrice=Price;
  
  PGUI.fillCount(true, TF_SummaryPayOutCount, PayOutTotalCount);
  PGUI.fillPrice(true, TF_SummaryPayOutPrice, PayOutTotalPrice);
  
  PGUI.fillCount(true, TF_PayOutCount, PayOutTotalCount);
  PGUI.fillPrice(true, TF_PayOutPrice, PayOutTotalPrice);
 }
 void fillPayOut(){
  int datacount;
  
  clearPayOut();
  
  TIPayOutClear=false;
  
  datacount=PDatabase.queryToTableWithSum(IFV.Stm, queryOfPay(wIsPreTrans, wIsPending, false, wId, null),
   TableMdlPayOut, PayOutSumColumn, PayOutSumResult, false, false, null, -1, false, -1);
  if(datacount==-1){clearPayOut(); return;}
  
  changeSummaryPayOut(TableMdlPayOut.getRowCount(), PayOutSumResult[4]);
  
  if(datacount>0){Tbl_PayOut.changeSelection(0, 0, false, false); onSelectedRowPayOutChanged(false);}
 }
 void clearPayOut(){
  if(TIPayOutClear){return;}
  
  TableMdlPayOut.removeAll();
  changeSummaryPayOut(0, 0);
  LastSelectedRowPayOut=-1;
  clearInfoPayOut();
  
  TIPayOutClear=true;
 }
 void fillInfoPayOut(int row){
  Object[] objs=TableMdlPayOut.Mdl.Rows.elementAt(row);
  
  TF_PayOutInfoDate.setText(PText.dateToString((Date)objs[1], 2));
  TF_PayOutInfoCash.setText(PText.getStringObj(objs[3], "", false));
  TF_PayOutInfoPrice.setText(PText.priceToString((Double)objs[4]));
  TA_PayOutInfoComment.setText(PText.getStringObj(objs[5], "", false));
  
  InfoPayOutClear=false;
 }
 void clearInfoPayOut(){
  if(InfoPayOutClear){return;}
  
  TF_PayOutInfoDate.setText("");
  TF_PayOutInfoCash.setText("");
  TF_PayOutInfoPrice.setText("");
  TA_PayOutInfoComment.setText("");
  
  InfoPayOutClear=true;
 }
 
 void changeSummaryPayIn(int Count, double Price){
  PayInTotalCount=Count;
  PayInTotalPrice=Price;
  
  PGUI.fillCount(true, TF_SummaryPayInCount, PayInTotalCount);
  PGUI.fillPrice(true, TF_SummaryPayInPrice, PayInTotalPrice);
  
  PGUI.fillCount(true, TF_PayInCount, PayInTotalCount);
  PGUI.fillPrice(true, TF_PayInPrice, PayInTotalPrice);
 }
 void fillPayIn(){
  int datacount;
  
  clearPayIn();
  
  TIPayInClear=false;
  
  datacount=PDatabase.queryToTableWithSum(IFV.Stm, queryOfPay(wIsPreTrans, wIsPending, true, wId, null),
   TableMdlPayIn, PayInSumColumn, PayInSumResult, false, false, null, -1, false, -1);
  if(datacount==-1){clearPayIn(); return;}
  
  changeSummaryPayIn(TableMdlPayIn.getRowCount(), PayInSumResult[4]);
  
  if(datacount>0){Tbl_PayIn.changeSelection(0, 0, false, false); onSelectedRowPayInChanged(false);}
 }
 void clearPayIn(){
  if(TIPayInClear){return;}
  
  TableMdlPayIn.removeAll();
  changeSummaryPayIn(0, 0);
  LastSelectedRowPayIn=-1;
  clearInfoPayIn();
  
  TIPayInClear=true;
 }
 void fillInfoPayIn(int row){
  Object[] objs=TableMdlPayIn.Mdl.Rows.elementAt(row);
  
  TF_PayInInfoDate.setText(PText.dateToString((Date)objs[1], 2));
  TF_PayInInfoCash.setText(PText.getStringObj(objs[3], "", false));
  TF_PayInInfoPrice.setText(PText.priceToString((Double)objs[4]));
  TA_PayInInfoComment.setText(PText.getStringObj(objs[5], "", false));
  
  InfoPayInClear=false;
 }
 void clearInfoPayIn(){
  if(InfoPayInClear){return;}
  
  TF_PayInInfoDate.setText("");
  TF_PayInInfoCash.setText("");
  TF_PayInInfoPrice.setText("");
  TA_PayInInfoComment.setText("");
  
  InfoPayInClear=true;
 }
 
 void findItemIn(int Mode){
  int Selected, FindIndex;
  int Column=0;
  int ColumnType;
  
  String str=TF_ItemInFind.getText();
  if(str.length()==0){return;}
  if(TableMdlItemIn.Mdl.Rows.size()==0){JOptionPane.showMessageDialog(null, "Tabel barang masuk dalam keadaan kosong !"); return;}
  
  switch(CmB_ItemInFind.getSelectedIndex()){
   case 1 : Column=2; break;
   case 2 : Column=9; break;
   default : Column=0; break;
  }
  ColumnType=TableMdlItemIn.getColumnsType()[Column];
  Selected=Tbl_ItemIn.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlItemIn, Column, ColumnType, str, Selected, Mode);
  
  if(FindIndex==-1){JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang masuk !"); return;}
  
  if(Selected==FindIndex){return;}
  Tbl_ItemIn.changeSelection(FindIndex, 0, false, false);
  onSelectedRowItemInChanged(false);
 }
 void findItemOut(int Mode){
  int Selected, FindIndex;
  int Column=0;
  int ColumnType;
  
  String str=TF_ItemOutFind.getText();
  if(str.length()==0){return;}
  if(TableMdlItemOut.Mdl.Rows.size()==0){JOptionPane.showMessageDialog(null, "Tabel barang keluar dalam keadaan kosong !"); return;}
  
  switch(CmB_ItemOutFind.getSelectedIndex()){
   case 1 : Column=2; break;
   case 2 : Column=9; break;
   default : Column=0; break;
  }
  ColumnType=TableMdlItemOut.getColumnsType()[Column];
  Selected=Tbl_ItemOut.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlItemOut, Column, ColumnType, str, Selected, Mode);
  
  if(FindIndex==-1){JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang keluar !"); return;}
  
  if(Selected==FindIndex){return;}
  Tbl_ItemOut.changeSelection(FindIndex, 0, false, false);
  onSelectedRowItemOutChanged(false);
 }
 
 void initPrivGUIShow(){
  boolean ShowData;
  int tab;
  
  // Buy Price
  ShowData=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;

  PGUI.setEnabled(ShowData, CB_SummaryItemOutBasic);
  if(!ShowData && CB_SummaryItemOutBasic.isSelected()){CB_SummaryItemOutBasic.setSelected(false); CB_SummaryItemOutBasicActionPerformed(null);}
  
  PGUI.setEnabled(ShowData, CB_ItemOutShowBasicPrice);
  if(!ShowData && CB_ItemOutShowBasicPrice.isSelected()){CB_ItemOutShowBasicPrice.setSelected(false); CB_ItemOutShowBasicPriceActionPerformed(null);}
 
  // Item In
  ShowData=IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemIn, IFV.PrivGUIShowPreTransItemIn);
  
  tab=0;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(1);}
  
  // Item Out
  ShowData=IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemOut, IFV.PrivGUIShowPreTransItemOut);
  
  tab=2;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(1);}
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  jSeparator1 = new javax.swing.JSeparator();
  jPanel18 = new javax.swing.JPanel();
  jPanel19 = new javax.swing.JPanel();
  TF_SummaryItemInCount = new javax.swing.JTextField();
  Lbl_SummaryItemIn = new javax.swing.JLabel();
  TF_SummaryPayOutCount = new javax.swing.JTextField();
  Lbl_SummaryPayOut = new javax.swing.JLabel();
  TF_SummaryItemInPrice = new javax.swing.JTextField();
  TF_SummaryPayOutPrice = new javax.swing.JTextField();
  TF_SummaryItemOutCount = new javax.swing.JTextField();
  TF_SummaryItemOutPrice = new javax.swing.JTextField();
  TF_SummaryItemOutBasicPrice = new javax.swing.JTextField();
  TF_SummaryPayInPrice = new javax.swing.JTextField();
  Lbl_SummaryItemOut = new javax.swing.JLabel();
  Lbl_SummaryPayIn = new javax.swing.JLabel();
  TF_SummaryPayInCount = new javax.swing.JTextField();
  CB_SummaryItemOutBasic = new javax.swing.JCheckBox();
  TabbedPane = new javax.swing.JTabbedPane();
  Pnl_ItemIn = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  TF_ItemInCount = new javax.swing.JTextField();
  TF_ItemInPrice = new javax.swing.JTextField();
  CB_ItemInCategorized = new javax.swing.JToggleButton();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_ItemIn = new XTable();
  jPanel3 = new javax.swing.JPanel();
  Pnl_ItemInInfoPreview = new XImgBoxURL();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemInInfoCategory = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_ItemInInfoName = new javax.swing.JTextArea();
  jPanel15 = new javax.swing.JPanel();
  Btn_ItemInTempListRemove = new javax.swing.JButton();
  Btn_ItemInTempListAdd = new javax.swing.JButton();
  jLabel2 = new javax.swing.JLabel();
  Btn_ItemInFindNext = new javax.swing.JButton();
  Btn_ItemInFindBef = new javax.swing.JButton();
  CmB_ItemInFind = new javax.swing.JComboBox<>();
  TF_ItemInFind = new javax.swing.JTextField();
  Pnl_PayOut = new javax.swing.JPanel();
  jPanel1 = new javax.swing.JPanel();
  TF_PayOutCount = new javax.swing.JTextField();
  TF_PayOutPrice = new javax.swing.JTextField();
  jPanel2 = new javax.swing.JPanel();
  TF_PayOutInfoDate = new javax.swing.JTextField();
  Lbl_PayOutInfoDate = new javax.swing.JLabel();
  TF_PayOutInfoCash = new javax.swing.JTextField();
  Lbl_PayOutInfoCash = new javax.swing.JLabel();
  TF_PayOutInfoPrice = new javax.swing.JTextField();
  Lbl_PayOutInfoPrice = new javax.swing.JLabel();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_PayOutInfoComment = new javax.swing.JTextArea();
  Lbl_PayOutInfoComment = new javax.swing.JLabel();
  jScrollPane11 = new javax.swing.JScrollPane();
  Tbl_PayOut = new XTable();
  Pnl_ItemOut = new javax.swing.JPanel();
  jPanel6 = new javax.swing.JPanel();
  TF_ItemOutCount = new javax.swing.JTextField();
  TF_ItemOutPrice = new javax.swing.JTextField();
  CB_ItemOutCategorized = new javax.swing.JToggleButton();
  CB_ItemOutShowBasicPrice = new javax.swing.JToggleButton();
  jPanel7 = new javax.swing.JPanel();
  Pnl_ItemOutInfoPreview = new XImgBoxURL();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_ItemOutInfoCategory = new javax.swing.JTextArea();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_ItemOutInfoName = new javax.swing.JTextArea();
  jScrollPane10 = new javax.swing.JScrollPane();
  Tbl_ItemOut = new XTable();
  jPanel14 = new javax.swing.JPanel();
  Btn_ItemOutTempListRemove = new javax.swing.JButton();
  Btn_ItemOutTempListAdd = new javax.swing.JButton();
  jLabel3 = new javax.swing.JLabel();
  CmB_ItemOutFind = new javax.swing.JComboBox<>();
  Btn_ItemOutFindNext = new javax.swing.JButton();
  Btn_ItemOutFindBef = new javax.swing.JButton();
  TF_ItemOutFind = new javax.swing.JTextField();
  Pnl_PayIn = new javax.swing.JPanel();
  jPanel4 = new javax.swing.JPanel();
  TF_PayInCount = new javax.swing.JTextField();
  TF_PayInPrice = new javax.swing.JTextField();
  jScrollPane12 = new javax.swing.JScrollPane();
  Tbl_PayIn = new XTable();
  jPanel10 = new javax.swing.JPanel();
  TF_PayInInfoDate = new javax.swing.JTextField();
  Lbl_PayInInfoDate = new javax.swing.JLabel();
  TF_PayInInfoCash = new javax.swing.JTextField();
  TF_PayInInfoPrice = new javax.swing.JTextField();
  Lbl_PayInInfoCash = new javax.swing.JLabel();
  Lbl_PayInInfoPrice = new javax.swing.JLabel();
  jScrollPane13 = new javax.swing.JScrollPane();
  TA_PayInInfoComment = new javax.swing.JTextArea();
  Lbl_PayInInfoComment = new javax.swing.JLabel();
  jSeparator2 = new javax.swing.JSeparator();
  jPanel8 = new javax.swing.JPanel();
  jPanel13 = new javax.swing.JPanel();
  TF_Subject = new javax.swing.JTextField();
  Lbl_Subject = new javax.swing.JLabel();
  TF_Salesman = new javax.swing.JTextField();
  Lbl_Salesman = new javax.swing.JLabel();
  jPanel12 = new javax.swing.JPanel();
  jScrollPane7 = new javax.swing.JScrollPane();
  TA_CashIn = new javax.swing.JTextArea();
  Lbl_CashIn = new javax.swing.JLabel();
  jScrollPane8 = new javax.swing.JScrollPane();
  TA_CashOut = new javax.swing.JTextArea();
  Lbl_CashOut = new javax.swing.JLabel();
  jSeparator6 = new javax.swing.JSeparator();
  jSeparator5 = new javax.swing.JSeparator();
  jPanel11 = new javax.swing.JPanel();
  TF_TransDate = new javax.swing.JTextField();
  Lbl_TransDate = new javax.swing.JLabel();
  TF_CreditDays = new javax.swing.JTextField();
  Lbl_CreditDays = new javax.swing.JLabel();
  TF_RepaymentPeriod = new javax.swing.JTextField();
  Lbl_RepaymentPeriod = new javax.swing.JLabel();
  jSeparator4 = new javax.swing.JSeparator();
  jPanel9 = new javax.swing.JPanel();
  TF_Id = new javax.swing.JTextField();
  Lbl_Id = new javax.swing.JLabel();
  CB_IsImportant = new javax.swing.JCheckBox();
  TF_IdExternal = new javax.swing.JTextField();
  Lbl_IdExternal = new javax.swing.JLabel();
  TF_TransType = new javax.swing.JTextField();
  Lbl_TransType = new javax.swing.JLabel();
  jSeparator3 = new javax.swing.JSeparator();
  jPanel16 = new javax.swing.JPanel();
  Lbl_Comment = new javax.swing.JLabel();
  jScrollPane9 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();

  setTitle("Keterangan Transaksi");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

  TF_SummaryItemInCount.setEditable(false);
  TF_SummaryItemInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryItemInCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  Lbl_SummaryItemIn.setText("Barang Masuk");

  TF_SummaryPayOutCount.setEditable(false);
  TF_SummaryPayOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryPayOutCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  Lbl_SummaryPayOut.setText("{ Bayar Keluar }");

  TF_SummaryItemInPrice.setEditable(false);
  TF_SummaryItemInPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryItemInPrice.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  TF_SummaryPayOutPrice.setEditable(false);
  TF_SummaryPayOutPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryPayOutPrice.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  TF_SummaryItemOutCount.setEditable(false);
  TF_SummaryItemOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryItemOutCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  TF_SummaryItemOutPrice.setEditable(false);
  TF_SummaryItemOutPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryItemOutPrice.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  TF_SummaryItemOutBasicPrice.setEditable(false);
  TF_SummaryItemOutBasicPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryItemOutBasicPrice.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  TF_SummaryPayInPrice.setEditable(false);
  TF_SummaryPayInPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryPayInPrice.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  Lbl_SummaryItemOut.setText("Barang Keluar");

  Lbl_SummaryPayIn.setText("{ Bayar Masuk }");

  TF_SummaryPayInCount.setEditable(false);
  TF_SummaryPayInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_SummaryPayInCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

  CB_SummaryItemOutBasic.setText("{ HPP }");
  CB_SummaryItemOutBasic.setToolTipText("centang utk melihat nilai Harga Pokok Penjualan (HPP)");
  CB_SummaryItemOutBasic.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_SummaryItemOutBasic.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_SummaryItemOutBasic.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_SummaryItemOutBasicActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
  jPanel19.setLayout(jPanel19Layout);
  jPanel19Layout.setHorizontalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel19Layout.createSequentialGroup()
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(TF_SummaryItemInPrice, javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_SummaryItemInCount, javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_SummaryItemIn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_SummaryPayOutPrice)
     .addComponent(TF_SummaryPayOutCount)
     .addComponent(Lbl_SummaryPayOut, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_SummaryItemOutCount)
     .addComponent(TF_SummaryItemOutPrice)
     .addComponent(Lbl_SummaryItemOut, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_SummaryItemOutBasicPrice)
     .addComponent(CB_SummaryItemOutBasic, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_SummaryPayIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(TF_SummaryPayInCount)
     .addComponent(TF_SummaryPayInPrice)))
  );
  jPanel19Layout.setVerticalGroup(
   jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel19Layout.createSequentialGroup()
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_SummaryItemOutBasic)
     .addComponent(Lbl_SummaryItemOut)
     .addComponent(Lbl_SummaryPayOut)
     .addComponent(Lbl_SummaryItemIn)
     .addComponent(Lbl_SummaryPayIn))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SummaryItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryPayOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryPayInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(4, 4, 4)
    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_SummaryItemInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryPayOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryItemOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryItemOutBasicPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_SummaryPayInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  jPanel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 2, 2, 2));

  TF_ItemInCount.setEditable(false);
  TF_ItemInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_ItemInPrice.setEditable(false);
  TF_ItemInPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInPrice.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CB_ItemInCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemInCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemInCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemInCategorized.setText("K");
  CB_ItemInCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemInCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemInCategorized.setIconTextGap(0);
  CB_ItemInCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemInCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_ItemInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemInCategorized)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_ItemInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_ItemInCategorized))
  );

  Tbl_ItemIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemIn.setRowHeight(17);
  Tbl_ItemIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemInMouseReleased(evt);
   }
  });
  Tbl_ItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemInKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_ItemIn);

  Pnl_ItemInInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemInInfoCategory.setEditable(false);
  TA_ItemInInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoCategory.setColumns(20);
  TA_ItemInInfoCategory.setLineWrap(true);
  TA_ItemInInfoCategory.setRows(1);
  TA_ItemInInfoCategory.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemInInfoCategory);

  TA_ItemInInfoName.setEditable(false);
  TA_ItemInInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoName.setColumns(20);
  TA_ItemInInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoName.setLineWrap(true);
  TA_ItemInInfoName.setRows(1);
  TA_ItemInInfoName.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_ItemInInfoName);

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addComponent(jScrollPane3)))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(jPanel3Layout.createSequentialGroup()
      .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)))
    .addGap(0, 0, 0))
  );

  jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_ItemInTempListRemove.setText("-");
  Btn_ItemInTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_ItemInTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInTempListRemoveActionPerformed(evt);
   }
  });

  Btn_ItemInTempListAdd.setText("+");
  Btn_ItemInTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_ItemInTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInTempListAddActionPerformed(evt);
   }
  });

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setText("*");

  Btn_ItemInFindNext.setText(">");
  Btn_ItemInFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInFindNextActionPerformed(evt);
   }
  });

  Btn_ItemInFindBef.setText("<");
  Btn_ItemInFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInFindBefActionPerformed(evt);
   }
  });

  CmB_ItemInFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nama Brg", "Kategori" }));

  TF_ItemInFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemInFindFocusGained(evt);
   }
  });
  TF_ItemInFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemInFindKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
    .addComponent(CmB_ItemInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_ItemInFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInFindNext)
    .addGap(18, 18, 18)
    .addComponent(jLabel2)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInTempListRemove))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_ItemInTempListRemove)
    .addComponent(Btn_ItemInTempListAdd)
    .addComponent(jLabel2)
    .addComponent(Btn_ItemInFindNext)
    .addComponent(Btn_ItemInFindBef)
    .addComponent(CmB_ItemInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_ItemInFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Pnl_ItemInLayout = new javax.swing.GroupLayout(Pnl_ItemIn);
  Pnl_ItemIn.setLayout(Pnl_ItemInLayout);
  Pnl_ItemInLayout.setHorizontalGroup(
   Pnl_ItemInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
   .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Pnl_ItemInLayout.setVerticalGroup(
   Pnl_ItemInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_ItemInLayout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("Barang Masuk", Pnl_ItemIn);

  jPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 2, 2, 2));

  TF_PayOutCount.setEditable(false);
  TF_PayOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_PayOutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_PayOutPrice.setEditable(false);
  TF_PayOutPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_PayOutPrice.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(TF_PayOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_PayOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, Short.MAX_VALUE))
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_PayOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_PayOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_PayOutInfoDate.setEditable(false);
  TF_PayOutInfoDate.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PayOutInfoDate.setText("Tanggal");

  TF_PayOutInfoCash.setEditable(false);
  TF_PayOutInfoCash.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PayOutInfoCash.setText("Kas Kredit");

  TF_PayOutInfoPrice.setEditable(false);
  TF_PayOutInfoPrice.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PayOutInfoPrice.setText("Jumlah");

  TA_PayOutInfoComment.setEditable(false);
  TA_PayOutInfoComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_PayOutInfoComment.setColumns(20);
  TA_PayOutInfoComment.setLineWrap(true);
  TA_PayOutInfoComment.setRows(1);
  TA_PayOutInfoComment.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_PayOutInfoComment);

  Lbl_PayOutInfoComment.setText("Keterangan");

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_PayOutInfoDate)
     .addComponent(Lbl_PayOutInfoCash)
     .addComponent(Lbl_PayOutInfoPrice)
     .addComponent(Lbl_PayOutInfoComment))
    .addGap(18, 18, 18)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane6)
     .addComponent(TF_PayOutInfoPrice)
     .addComponent(TF_PayOutInfoCash)
     .addComponent(TF_PayOutInfoDate)))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PayOutInfoDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PayOutInfoDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PayOutInfoCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PayOutInfoCash))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PayOutInfoPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PayOutInfoPrice))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
     .addComponent(Lbl_PayOutInfoComment)))
  );

  Tbl_PayOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_PayOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_PayOut.setRowHeight(17);
  Tbl_PayOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_PayOutMouseReleased(evt);
   }
  });
  Tbl_PayOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_PayOutKeyReleased(evt);
   }
  });
  jScrollPane11.setViewportView(Tbl_PayOut);

  javax.swing.GroupLayout Pnl_PayOutLayout = new javax.swing.GroupLayout(Pnl_PayOut);
  Pnl_PayOut.setLayout(Pnl_PayOutLayout);
  Pnl_PayOutLayout.setHorizontalGroup(
   Pnl_PayOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Pnl_PayOutLayout.setVerticalGroup(
   Pnl_PayOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_PayOutLayout.createSequentialGroup()
    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 353, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("{ Bayar Keluar }", Pnl_PayOut);

  jPanel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 2, 2, 2));

  TF_ItemOutCount.setEditable(false);
  TF_ItemOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_ItemOutPrice.setEditable(false);
  TF_ItemOutPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutPrice.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CB_ItemOutCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutCategorized.setText("K");
  CB_ItemOutCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemOutCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutCategorized.setIconTextGap(0);
  CB_ItemOutCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutCategorizedActionPerformed(evt);
   }
  });

  CB_ItemOutShowBasicPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutShowBasicPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutShowBasicPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutShowBasicPrice.setText("HPP");
  CB_ItemOutShowBasicPrice.setToolTipText("tekan tombol 'HPP' utk menampilkan Harga Pokok Penjualan (HPP)");
  CB_ItemOutShowBasicPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutShowBasicPrice.setIconTextGap(0);
  CB_ItemOutShowBasicPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutShowBasicPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutShowBasicPriceActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_ItemOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutShowBasicPrice)
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_ItemOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_ItemOutCategorized)
    .addComponent(CB_ItemOutShowBasicPrice))
  );

  Pnl_ItemOutInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemOutInfoCategory.setEditable(false);
  TA_ItemOutInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoCategory.setColumns(20);
  TA_ItemOutInfoCategory.setLineWrap(true);
  TA_ItemOutInfoCategory.setRows(1);
  TA_ItemOutInfoCategory.setWrapStyleWord(true);
  jScrollPane4.setViewportView(TA_ItemOutInfoCategory);

  TA_ItemOutInfoName.setEditable(false);
  TA_ItemOutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoName.setColumns(20);
  TA_ItemOutInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoName.setLineWrap(true);
  TA_ItemOutInfoName.setRows(1);
  TA_ItemOutInfoName.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_ItemOutInfoName);

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane4)
     .addComponent(jScrollPane5)))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
   .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel7Layout.createSequentialGroup()
    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemOut.setRowHeight(17);
  Tbl_ItemOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemOutMouseReleased(evt);
   }
  });
  Tbl_ItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemOutKeyReleased(evt);
   }
  });
  jScrollPane10.setViewportView(Tbl_ItemOut);

  jPanel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_ItemOutTempListRemove.setText("-");
  Btn_ItemOutTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_ItemOutTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutTempListRemoveActionPerformed(evt);
   }
  });

  Btn_ItemOutTempListAdd.setText("+");
  Btn_ItemOutTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_ItemOutTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutTempListAddActionPerformed(evt);
   }
  });

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setText("*");

  CmB_ItemOutFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nama Brg", "Kategori" }));

  Btn_ItemOutFindNext.setText(">");
  Btn_ItemOutFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutFindNextActionPerformed(evt);
   }
  });

  Btn_ItemOutFindBef.setText("<");
  Btn_ItemOutFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutFindBefActionPerformed(evt);
   }
  });

  TF_ItemOutFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ItemOutFindFocusGained(evt);
   }
  });
  TF_ItemOutFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ItemOutFindKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addComponent(CmB_ItemOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_ItemOutFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutFindNext)
    .addGap(18, 18, 18)
    .addComponent(jLabel3)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutTempListRemove))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_ItemOutTempListRemove)
    .addComponent(Btn_ItemOutTempListAdd)
    .addComponent(jLabel3)
    .addComponent(CmB_ItemOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_ItemOutFindNext)
    .addComponent(Btn_ItemOutFindBef)
    .addComponent(TF_ItemOutFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout Pnl_ItemOutLayout = new javax.swing.GroupLayout(Pnl_ItemOut);
  Pnl_ItemOut.setLayout(Pnl_ItemOutLayout);
  Pnl_ItemOutLayout.setHorizontalGroup(
   Pnl_ItemOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Pnl_ItemOutLayout.setVerticalGroup(
   Pnl_ItemOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_ItemOutLayout.createSequentialGroup()
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("Barang Keluar", Pnl_ItemOut);

  jPanel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(2, 2, 2, 2));

  TF_PayInCount.setEditable(false);
  TF_PayInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_PayInCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_PayInPrice.setEditable(false);
  TF_PayInPrice.setBackground(new java.awt.Color(204, 255, 204));
  TF_PayInPrice.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(TF_PayInCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_PayInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, Short.MAX_VALUE))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_PayInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_PayInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Tbl_PayIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_PayIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_PayIn.setRowHeight(17);
  Tbl_PayIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_PayInMouseReleased(evt);
   }
  });
  Tbl_PayIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_PayInKeyReleased(evt);
   }
  });
  jScrollPane12.setViewportView(Tbl_PayIn);

  TF_PayInInfoDate.setEditable(false);
  TF_PayInInfoDate.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PayInInfoDate.setText("Tanggal");

  TF_PayInInfoCash.setEditable(false);
  TF_PayInInfoCash.setBackground(new java.awt.Color(204, 255, 204));

  TF_PayInInfoPrice.setEditable(false);
  TF_PayInInfoPrice.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PayInInfoCash.setText("Kas Kredit");

  Lbl_PayInInfoPrice.setText("Jumlah");

  TA_PayInInfoComment.setEditable(false);
  TA_PayInInfoComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_PayInInfoComment.setColumns(20);
  TA_PayInInfoComment.setLineWrap(true);
  TA_PayInInfoComment.setRows(1);
  TA_PayInInfoComment.setWrapStyleWord(true);
  jScrollPane13.setViewportView(TA_PayInInfoComment);

  Lbl_PayInInfoComment.setText("Keterangan");

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_PayInInfoDate)
     .addComponent(Lbl_PayInInfoCash)
     .addComponent(Lbl_PayInInfoPrice)
     .addComponent(Lbl_PayInInfoComment))
    .addGap(18, 18, 18)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane13)
     .addComponent(TF_PayInInfoPrice)
     .addComponent(TF_PayInInfoCash)
     .addComponent(TF_PayInInfoDate)))
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PayInInfoDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PayInInfoDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PayInInfoCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PayInInfoCash))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PayInInfoPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PayInInfoPrice))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane13, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE)
     .addComponent(Lbl_PayInInfoComment)))
  );

  javax.swing.GroupLayout Pnl_PayInLayout = new javax.swing.GroupLayout(Pnl_PayIn);
  Pnl_PayIn.setLayout(Pnl_PayInLayout);
  Pnl_PayInLayout.setHorizontalGroup(
   Pnl_PayInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  Pnl_PayInLayout.setVerticalGroup(
   Pnl_PayInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_PayInLayout.createSequentialGroup()
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 353, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("{ Bayar Masuk }", Pnl_PayIn);

  javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
  jPanel18.setLayout(jPanel18Layout);
  jPanel18Layout.setHorizontalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator2)
   .addComponent(TabbedPane)
  );
  jPanel18Layout.setVerticalGroup(
   jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel18Layout.createSequentialGroup()
    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(TabbedPane))
  );

  TF_Subject.setEditable(false);
  TF_Subject.setBackground(new java.awt.Color(204, 255, 204));
  TF_Subject.setToolTipText("klik utk melihat keterangan subjek");
  TF_Subject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_Subject.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_SubjectMouseClicked(evt);
   }
  });

  Lbl_Subject.setText("Subjek");

  TF_Salesman.setEditable(false);
  TF_Salesman.setBackground(new java.awt.Color(204, 255, 204));
  TF_Salesman.setToolTipText("klik utk melihat keterangan sales");
  TF_Salesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_Salesman.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_SalesmanMouseClicked(evt);
   }
  });

  Lbl_Salesman.setText("Sales");

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(Lbl_Salesman, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
     .addComponent(Lbl_Subject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_Subject)
     .addComponent(TF_Salesman)))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Subject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Subject))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Salesman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Salesman)))
  );

  TA_CashIn.setEditable(false);
  TA_CashIn.setBackground(new java.awt.Color(204, 255, 204));
  TA_CashIn.setColumns(20);
  TA_CashIn.setLineWrap(true);
  TA_CashIn.setRows(1);
  TA_CashIn.setWrapStyleWord(true);
  jScrollPane7.setViewportView(TA_CashIn);

  Lbl_CashIn.setText("Kas Masuk Tunai");

  TA_CashOut.setEditable(false);
  TA_CashOut.setBackground(new java.awt.Color(204, 255, 204));
  TA_CashOut.setColumns(20);
  TA_CashOut.setLineWrap(true);
  TA_CashOut.setRows(1);
  TA_CashOut.setWrapStyleWord(true);
  jScrollPane8.setViewportView(TA_CashOut);

  Lbl_CashOut.setText("Kas Keluar Tunai");

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(Lbl_CashOut, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
     .addComponent(Lbl_CashIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
     .addComponent(jScrollPane8)))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_CashIn)
     .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CashOut)))
  );

  TF_TransDate.setEditable(false);
  TF_TransDate.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_TransDate.setText("Tanggal");

  TF_CreditDays.setEditable(false);
  TF_CreditDays.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_CreditDays.setText("Lama Kredit");

  TF_RepaymentPeriod.setEditable(false);
  TF_RepaymentPeriod.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_RepaymentPeriod.setText("Periode Cicil");

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(Lbl_RepaymentPeriod, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
     .addComponent(Lbl_CreditDays, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_TransDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_TransDate)
     .addComponent(TF_CreditDays)
     .addComponent(TF_RepaymentPeriod)))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createSequentialGroup()
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_TransDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_CreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_CreditDays))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_RepaymentPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_RepaymentPeriod)))
  );

  TF_Id.setEditable(false);
  TF_Id.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_Id.setText("Id");

  CB_IsImportant.setText("Penting");
  CB_IsImportant.setEnabled(false);
  CB_IsImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));

  TF_IdExternal.setEditable(false);
  TF_IdExternal.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_IdExternal.setText("{ Id External }");

  TF_TransType.setEditable(false);
  TF_TransType.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_TransType.setText("Jenis");

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addComponent(Lbl_Id, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_IdExternal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
     .addComponent(Lbl_TransType, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_IdExternal)
     .addGroup(jPanel9Layout.createSequentialGroup()
      .addComponent(TF_Id, javax.swing.GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_IsImportant))
     .addComponent(TF_TransType, javax.swing.GroupLayout.Alignment.TRAILING)))
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Id)
     .addComponent(CB_IsImportant))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_IdExternal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_IdExternal))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_TransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_TransType)))
  );

  Lbl_Comment.setText("Keterangan");

  TA_Comment.setEditable(false);
  TA_Comment.setBackground(new java.awt.Color(204, 255, 204));
  TA_Comment.setColumns(20);
  TA_Comment.setLineWrap(true);
  TA_Comment.setRows(1);
  TA_Comment.setWrapStyleWord(true);
  jScrollPane9.setViewportView(TA_Comment);

  javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
  jPanel16.setLayout(jPanel16Layout);
  jPanel16Layout.setHorizontalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel16Layout.createSequentialGroup()
    .addComponent(Lbl_Comment, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane9))
  );
  jPanel16Layout.setVerticalGroup(
   jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel16Layout.createSequentialGroup()
    .addComponent(Lbl_Comment)
    .addGap(0, 0, Short.MAX_VALUE))
   .addComponent(jScrollPane9)
  );

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jSeparator6)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator5)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator4)
   .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jSeparator3)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jSeparator1)
     .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ){return;}
  
  Activ=true;
  
  setTitle("Keterangan "+TransName);
  
  initPrivGUIShow();
  
  fillComponentsWithSetVariables();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void TF_ItemOutFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemOutFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ItemOutFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemOut)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_ItemOutFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ItemOutFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: Btn_ItemOutFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_ItemOutFindKeyPressed

 private void Btn_ItemOutFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutFindBefActionPerformed
  findItemOut(2);
 }//GEN-LAST:event_Btn_ItemOutFindBefActionPerformed

 private void Btn_ItemOutFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutFindNextActionPerformed
  findItemOut(1);
 }//GEN-LAST:event_Btn_ItemOutFindNextActionPerformed

 private void Btn_ItemOutTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutTempListAddActionPerformed
  int[] rows=Tbl_ItemOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlItemOut.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_ItemOutTempListAddActionPerformed

 private void Btn_ItemOutTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutTempListRemoveActionPerformed
  int[] rows=Tbl_ItemOut.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlItemOut.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_ItemOutTempListRemoveActionPerformed

 private void TF_ItemInFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ItemInFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ItemInFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_ItemIn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_ItemInFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_ItemInFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: Btn_ItemInFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_ItemInFindKeyPressed

 private void Btn_ItemInFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInFindBefActionPerformed
  findItemIn(2);
 }//GEN-LAST:event_Btn_ItemInFindBefActionPerformed

 private void Btn_ItemInFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInFindNextActionPerformed
  findItemIn(1);
 }//GEN-LAST:event_Btn_ItemInFindNextActionPerformed

 private void Btn_ItemInTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInTempListAddActionPerformed
  int[] rows=Tbl_ItemIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlItemIn.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_ItemInTempListAddActionPerformed

 private void Btn_ItemInTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInTempListRemoveActionPerformed
  int[] rows=Tbl_ItemIn.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlItemIn.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_ItemInTempListRemoveActionPerformed

 private void Tbl_ItemInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemInMouseReleased
  onSelectedRowItemInChanged(false);
 }//GEN-LAST:event_Tbl_ItemInMouseReleased

 private void Tbl_ItemInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemInKeyReleased
  onSelectedRowItemInChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ItemIn, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemInFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_ItemInKeyReleased

 private void Tbl_PayOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_PayOutKeyReleased
  onSelectedRowPayOutChanged(false);
 }//GEN-LAST:event_Tbl_PayOutKeyReleased

 private void Tbl_PayOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_PayOutMouseReleased
  onSelectedRowPayOutChanged(false);
 }//GEN-LAST:event_Tbl_PayOutMouseReleased

 private void Tbl_ItemOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemOutKeyReleased
  onSelectedRowItemOutChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_ItemOut, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ItemOutFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_Tbl_ItemOutKeyReleased

 private void Tbl_ItemOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemOutMouseReleased
  onSelectedRowItemOutChanged(false);
 }//GEN-LAST:event_Tbl_ItemOutMouseReleased

 private void Tbl_PayInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_PayInKeyReleased
  onSelectedRowPayInChanged(false);
 }//GEN-LAST:event_Tbl_PayInKeyReleased

 private void Tbl_PayInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_PayInMouseReleased
  onSelectedRowPayInChanged(false);
 }//GEN-LAST:event_Tbl_PayInMouseReleased

 private void CB_SummaryItemOutBasicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_SummaryItemOutBasicActionPerformed
  refreshSummaryItemOutBasicPrice();
 }//GEN-LAST:event_CB_SummaryItemOutBasicActionPerformed

 private void Pnl_ItemOutInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemOut, TableMdlItemOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutInfoPreviewMouseClicked

 private void Pnl_ItemInInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemIn, TableMdlItemIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInInfoPreviewMouseClicked

 private void TF_SubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_SubjectMouseClicked
  if(wInfoTrans.SubjectId==-1){return;}
  PMyShop.viewFormInfo(wInfoTrans.SubjectId, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_SubjectMouseClicked

 private void TF_SalesmanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_SalesmanMouseClicked
  if(wInfoTrans.SalesmanId==-1){return;}
  PMyShop.viewFormInfo(wInfoTrans.SalesmanId, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_SalesmanMouseClicked

 private void CB_ItemInCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemInCategorizedActionPerformed
  changeItemInViewByCategorized();
 }//GEN-LAST:event_CB_ItemInCategorizedActionPerformed

 private void CB_ItemOutCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutCategorizedActionPerformed
  changeItemOutViewByCategorized();
 }//GEN-LAST:event_CB_ItemOutCategorizedActionPerformed

 private void CB_ItemOutShowBasicPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutShowBasicPriceActionPerformed
  changeItemOutViewByHPP();
 }//GEN-LAST:event_CB_ItemOutShowBasicPriceActionPerformed

 private void TF_ItemInFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemInFindFocusGained
  PGUI.text_SelectAll(TF_ItemInFind);
 }//GEN-LAST:event_TF_ItemInFindFocusGained

 private void TF_ItemOutFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ItemOutFindFocusGained
  PGUI.text_SelectAll(TF_ItemOutFind);
 }//GEN-LAST:event_TF_ItemOutFindFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_ItemInFindBef;
 private javax.swing.JButton Btn_ItemInFindNext;
 private javax.swing.JButton Btn_ItemInTempListAdd;
 private javax.swing.JButton Btn_ItemInTempListRemove;
 private javax.swing.JButton Btn_ItemOutFindBef;
 private javax.swing.JButton Btn_ItemOutFindNext;
 private javax.swing.JButton Btn_ItemOutTempListAdd;
 private javax.swing.JButton Btn_ItemOutTempListRemove;
 private javax.swing.JCheckBox CB_IsImportant;
 private javax.swing.JToggleButton CB_ItemInCategorized;
 private javax.swing.JToggleButton CB_ItemOutCategorized;
 private javax.swing.JToggleButton CB_ItemOutShowBasicPrice;
 private javax.swing.JCheckBox CB_SummaryItemOutBasic;
 private javax.swing.JComboBox<String> CmB_ItemInFind;
 private javax.swing.JComboBox<String> CmB_ItemOutFind;
 private javax.swing.JLabel Lbl_CashIn;
 private javax.swing.JLabel Lbl_CashOut;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_CreditDays;
 private javax.swing.JLabel Lbl_Id;
 private javax.swing.JLabel Lbl_IdExternal;
 private javax.swing.JLabel Lbl_PayInInfoCash;
 private javax.swing.JLabel Lbl_PayInInfoComment;
 private javax.swing.JLabel Lbl_PayInInfoDate;
 private javax.swing.JLabel Lbl_PayInInfoPrice;
 private javax.swing.JLabel Lbl_PayOutInfoCash;
 private javax.swing.JLabel Lbl_PayOutInfoComment;
 private javax.swing.JLabel Lbl_PayOutInfoDate;
 private javax.swing.JLabel Lbl_PayOutInfoPrice;
 private javax.swing.JLabel Lbl_RepaymentPeriod;
 private javax.swing.JLabel Lbl_Salesman;
 private javax.swing.JLabel Lbl_Subject;
 private javax.swing.JLabel Lbl_SummaryItemIn;
 private javax.swing.JLabel Lbl_SummaryItemOut;
 private javax.swing.JLabel Lbl_SummaryPayIn;
 private javax.swing.JLabel Lbl_SummaryPayOut;
 private javax.swing.JLabel Lbl_TransDate;
 private javax.swing.JLabel Lbl_TransType;
 private javax.swing.JPanel Pnl_ItemIn;
 private XImgBoxURL Pnl_ItemInInfoPreview;
 private javax.swing.JPanel Pnl_ItemOut;
 private XImgBoxURL Pnl_ItemOutInfoPreview;
 private javax.swing.JPanel Pnl_PayIn;
 private javax.swing.JPanel Pnl_PayOut;
 private javax.swing.JTextArea TA_CashIn;
 private javax.swing.JTextArea TA_CashOut;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextArea TA_ItemInInfoCategory;
 private javax.swing.JTextArea TA_ItemInInfoName;
 private javax.swing.JTextArea TA_ItemOutInfoCategory;
 private javax.swing.JTextArea TA_ItemOutInfoName;
 private javax.swing.JTextArea TA_PayInInfoComment;
 private javax.swing.JTextArea TA_PayOutInfoComment;
 private javax.swing.JTextField TF_CreditDays;
 private javax.swing.JTextField TF_Id;
 private javax.swing.JTextField TF_IdExternal;
 private javax.swing.JTextField TF_ItemInCount;
 private javax.swing.JTextField TF_ItemInFind;
 private javax.swing.JTextField TF_ItemInPrice;
 private javax.swing.JTextField TF_ItemOutCount;
 private javax.swing.JTextField TF_ItemOutFind;
 private javax.swing.JTextField TF_ItemOutPrice;
 private javax.swing.JTextField TF_PayInCount;
 private javax.swing.JTextField TF_PayInInfoCash;
 private javax.swing.JTextField TF_PayInInfoDate;
 private javax.swing.JTextField TF_PayInInfoPrice;
 private javax.swing.JTextField TF_PayInPrice;
 private javax.swing.JTextField TF_PayOutCount;
 private javax.swing.JTextField TF_PayOutInfoCash;
 private javax.swing.JTextField TF_PayOutInfoDate;
 private javax.swing.JTextField TF_PayOutInfoPrice;
 private javax.swing.JTextField TF_PayOutPrice;
 private javax.swing.JTextField TF_RepaymentPeriod;
 private javax.swing.JTextField TF_Salesman;
 private javax.swing.JTextField TF_Subject;
 private javax.swing.JTextField TF_SummaryItemInCount;
 private javax.swing.JTextField TF_SummaryItemInPrice;
 private javax.swing.JTextField TF_SummaryItemOutBasicPrice;
 private javax.swing.JTextField TF_SummaryItemOutCount;
 private javax.swing.JTextField TF_SummaryItemOutPrice;
 private javax.swing.JTextField TF_SummaryPayInCount;
 private javax.swing.JTextField TF_SummaryPayInPrice;
 private javax.swing.JTextField TF_SummaryPayOutCount;
 private javax.swing.JTextField TF_SummaryPayOutPrice;
 private javax.swing.JTextField TF_TransDate;
 private javax.swing.JTextField TF_TransType;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_ItemIn;
 private XTable Tbl_ItemOut;
 private XTable Tbl_PayIn;
 private XTable Tbl_PayOut;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel16;
 private javax.swing.JPanel jPanel18;
 private javax.swing.JPanel jPanel19;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane12;
 private javax.swing.JScrollPane jScrollPane13;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 private javax.swing.JSeparator jSeparator6;
 // End of variables declaration//GEN-END:variables
}
