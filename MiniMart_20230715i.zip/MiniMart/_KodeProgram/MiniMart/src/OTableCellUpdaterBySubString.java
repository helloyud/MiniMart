import java.util.Vector;

public class OTableCellUpdaterBySubString
 extends OTableCellUpdater{
 
 boolean CaseSensitive;
 String Find;
 String ReplaceWith;

 public OTableCellUpdaterBySubString(int TableColumnIndex,
  boolean CaseSensitive, String Find, String ReplaceWith) {
  init(TableColumnIndex);
  this.CaseSensitive=CaseSensitive;
  this.Find = Find;
  this.ReplaceWith = ReplaceWith;
 }

 public void update(int TableRowIndex){
  Vector<Object[]> Data=getRows();
		Object Obj;
		Obj=Data.elementAt(TableRowIndex)[TableColumnIndex];
		if(Obj==null){return;}
  Data.elementAt(TableRowIndex)[TableColumnIndex]=PText.findAndReplace(CaseSensitive, Obj.toString(), Find, ReplaceWith);
 }
 
}