import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

public class F_Converting extends XFormDialog
 implements OFormWithTempList{
 
 // set
 int wMode; // 0 Normal (New, Edit, Remove), 1 Choose (Choose)
 boolean wDialogWithFItem;
 boolean wAllowMultipleSelection;
 
 // get
 Long[] ChoosedId;
 
 // query
 OCustomListModel ListMdlQConvertingReason;
 OCustomTableModel TableMdlQConvRule;
 OCustomTableModel TableMdlQItem;
 
 Component LastFocusedCmpSearch;
 
 // convert rule
  // Temp List
 OQuickListOfLong TempList;
 
  // Additional Filter
 VInteger LastResultFilterSubset;
 
  // Table
 OCustomTableModel TableMdlConv;
	
	String[] TableConvColsName;
	int[] TableConvColsType, TableConvColsShowOption, TableConvColsVisible, TableConvColsWidth;
	boolean[] TableConvColsEditable;
	
 boolean LastQueryDefined;
 int LastQueryOperationBy;
	int LQ_Limit;
    // Static Filter
 String LQ_StaticSourceTable, LQ_StaticCondition, LQ_StaticPostCondition;
 boolean LQ_StaticConditionDefined, LQ_StaticPostConditionDefined;
    // Dynamic Filter
 int LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
    // Additional Filter
 boolean LQ_WithAdditionalFilter;
    // Order By
 String LQ_OrderBy;
    // Table Having
 String QHavingTbl;
 
 int LastSelectedRow;
 boolean InfoConvClear;
 
 int LastSelectedOrderMode;
 
  // Table - List Items
	String[] TableConvItemsColsName;
	int[] TableConvItemsColsType, TableConvItemsColsShowOption;
	boolean[] TableConvItemsColsEditable;
	
 OCustomTableModel TableMdlConvItemsOut;
 VIntegerArray TableConvItemsOutColsVisible, TableConvItemsOutColsWidth;
 
 VInteger LastSelectedRowConvItemsOut;
 VBoolean InfoConvItemsOutClear;
 
 OCustomTableModel TableMdlConvItemsIn;
 VIntegerArray TableConvItemsInColsVisible, TableConvItemsInColsWidth;
 
 VInteger LastSelectedRowConvItemsIn;
 VBoolean InfoConvItemsInClear;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 public F_Converting(MInterFormVariables IFV_) {
  int[] Editable;
  Date dt;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  this.IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  // query
  ListMdlQConvertingReason=new OCustomListModel(false);
  ListMdlQConvertingReason.setColumnsInfo(PCore.primArr(CCore.TypeInteger, CCore.TypeString), 1);
  List_QConvertingReason.setModel(ListMdlQConvertingReason);
  
  TableMdlQConvRule=new OCustomTableModel();
  TableMdlQConvRule.setColumnsInfo(
   PCore.refArr("Id", "Nama"),
   PCore.primArr(CCore.TypeLong, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(2, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(1));
  Tbl_QConvRule.setModel(TableMdlQConvRule);
  Tbl_QConvRule.setTableHeader(null); SP_TblQConvRule.setColumnHeaderView(null);
  
  TableMdlQItem=new OCustomTableModel();
  TableMdlQItem.setColumnsInfo(
   PCore.refArr("Id", "Nama"),
   PCore.primArr(CCore.TypeLong, CCore.TypeString),
   PCore.changeValue(PCore.newIntegerArray(2, OCustomTableModel.ShowOptionNormal),
    PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)),
   PCore.primArr(1, 0));
  Tbl_QItem.setModel(TableMdlQItem);
  PGUI.resizeTableColumn(Tbl_QItem, PCore.primArr(CGUI.ColTextLrg, CGUI.ColNum13));
  
  RB_QConvertingDirectionForward.setSelected(true);
 
  dt=new Date();
  PGUI.setDateComponent(dt, TF_QConvertingDateStartY, CmB_QConvertingDateStartM, CmB_QConvertingDateStartD);
  PGUI.setDateComponent(dt, TF_QConvertingDateEndY, CmB_QConvertingDateEndM, CmB_QConvertingDateEndD);
 
  LastFocusedCmpSearch=null;
  
  // converting
   // Temp List
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  updateTempListQuantity();
  
   // Additional Filter
  LastResultFilterSubset=new VInteger(CmB_ResultFilterSubset.getSelectedIndex());
  
   // Table - List Items
  TableConvItemsColsName=PMyShop.getConvertItems_ColumnsName();
  TableConvItemsColsType=PMyShop.getConvertItems_ColumnsType();
  TableConvItemsColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableConvItemsColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(-1);
  TableConvItemsColsEditable=PCore.changeValue(PCore.newBooleanArray(TableConvItemsColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));

    // Item Out
  TableMdlConvItemsOut=new OCustomTableModel(); Tbl_ItemOut.setModel(TableMdlConvItemsOut);
  TableConvItemsOutColsVisible=new VIntegerArray();
  TableConvItemsOutColsWidth=new VIntegerArray();

  LastSelectedRowConvItemsOut=new VInteger(-1);
  InfoConvItemsOutClear=new VBoolean(true);
  
  CB_ItemOutViewCategorized.setSelected(false);
  buildTableConvItemsViewStructure(true, true);
  updateTableConvItemsView(true, false);
  
  Tbl_ItemOut.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e){onEditingTableItem(true);}
   };
  
  Pnl_ItemOutInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

    // Item In
  TableMdlConvItemsIn=new OCustomTableModel(); Tbl_ItemIn.setModel(TableMdlConvItemsIn);
  TableConvItemsInColsVisible=new VIntegerArray();
  TableConvItemsInColsWidth=new VIntegerArray();

  LastSelectedRowConvItemsIn=new VInteger(-1);
  InfoConvItemsInClear=new VBoolean(true);
  
  CB_ItemInViewCategorized.setSelected(false);
  buildTableConvItemsViewStructure(false, true);
  updateTableConvItemsView(false, false);
  
  Tbl_ItemIn.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e){onEditingTableItem(false);}
   };
  
  Pnl_ItemInInfoPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
   // Table
  TableMdlConv=new OCustomTableModel(true, false, true);
  Tbl_Conv.setModel(TableMdlConv);
  
  TableConvColsName=PCore.refArr(
   "Id", "Tgl Konversi", "Alasan Konversi",
   "Id Aturan Konversi", "Aturan Konversi", "Aktif",
   "Arah", "Jumlah",
   "Jumlah Barang Keluar", "Jumlah Barang Masuk");
		TableConvColsType=PCore.primArr(
   CCore.TypeLong, CCore.TypeDate, CCore.TypeString,
   CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean,
   CCore.TypeString, CCore.TypeDouble,
   CCore.TypeInteger, CCore.TypeInteger);
  TableConvColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableConvColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(-1);
  TableConvColsEditable=PCore.changeValue(PCore.newBooleanArray(TableConvColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
  
  QHavingTbl="tb4";
  clearLastQuery();
  
  CmB_OrderMode.setSelectedIndex(1); LastSelectedOrderMode=CmB_OrderMode.getSelectedIndex();
  
  buildTableConvViewStructure(true, true);
  updateTableConvView(false);
  
  Tbl_Conv.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e){onEditingTableConv();}
   };
  
  LastSelectedRow=-1;
  InfoConvClear=true;
  
  updateQueryCount();
  updateQueryTempListCount();
  
  //
  clearComponents();
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
  Btn_Query.setToolTipText("hasil pencarian terbatas hingga "+PText.intToString(CApp.FormQueryLimit)+" data");
 }
 void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Query,
    CB_QConvertingDirection, RB_QConvertingDirectionForward, RB_QConvertingDirectionBackward,
    CB_QCheck, CmB_QCheck,
    CB_QConvertingDate, TF_QConvertingDateStartY, CmB_QConvertingDateStartM, CmB_QConvertingDateStartD,
    TF_QConvertingDateEndY, CmB_QConvertingDateEndM, CmB_QConvertingDateEndD,
    CB_QItemId, CmB_QItemId, TF_QItemId,
    CB_QItemName, TF_QItemName,
    CB_QConvRuleName, TF_QConvRuleName,
    CB_QConvertingCount, TF_QConvertingCount1, TF_QConvertingCount2,
    CB_QConvertingReason, CB_QConvertingReasonEmpty, List_QConvertingReason, Btn_QConvertingReasonAdd, Btn_QConvertingReasonRemove,
    CB_QConvRule, Tbl_QConvRule, Btn_QConvRuleAdd, Btn_QConvRuleRemove,
    CB_QItem, Tbl_QItem, Btn_QItemAdd, Btn_QItemRemove,
    
    TF_Find, Tbl_Conv),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_NewActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_QueryActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  // cancel table editing
  Tbl_Conv.editingCanceled(null);
  Tbl_ItemIn.editingCanceled(null);
  Tbl_ItemOut.editingCanceled(null);
  
  // query
  clearTabQuery();
  LastFocusedCmpSearch=null;
  
  // convert rule
  clearLastQuery(); clearConv(); PGUI.clearText(TF_Find);
 }
 
 // methods of query
 void runQuery(){
  boolean input_valid, list_defined, confirst;
  String str1=null;
  String str2=null;
  StringBuilder tb_items, tb_items2;
  boolean bool1, isempty1, isempty2, isconpost;
  long[] numbers, ids;
  Long lg1, lg2;
  Double dbl1, dbl2;
  Date dt1, dt2;
  VBoolean Con_Defined;
  StringBuilder StcCon;
  
  StringBuilder StcSourceTable;
  StringBuilder StcCondition;
  StringBuilder StcPostConditions;
  
  boolean query_defined;
  VBoolean stc_con_defined;
  VBoolean stc_conpost_defined;
  
  int WithTempList;
  
  // validating input
  input_valid=false;
  do{
   if(CB_QConvertingDate.isSelected()){
    dt1=PGUI.valueOfDateComponent(TF_QConvertingDateStartY, CmB_QConvertingDateStartM, CmB_QConvertingDateStartD);
    dt2=PGUI.valueOfDateComponent(TF_QConvertingDateEndY, CmB_QConvertingDateEndM, CmB_QConvertingDateEndD);
    if(dt1==null || dt2==null){break;}
   }
   if(CB_QItemId.isSelected()){
    if(!PText.checkInput(TF_QItemId.getText(), false, CCore.CharsCount_Long(), 2, 0, 0, 0)){break;}
   }
   if(CB_QItemName.isSelected()){
    if(!PText.checkInput(TF_QItemName.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_QConvRuleName.isSelected()){
    if(!PText.checkInput(TF_QConvRuleName.getText(), false, 0, 0, 0, 0, 0)){break;}
   }
   if(CB_QConvertingCount.isSelected()){
    str1=TF_QConvertingCount1.getText(); str2=TF_QConvertingCount2.getText();
    isempty1=PText.isEmptyString(str1, true, true); if(!PText.checkInput(str1, true, CCore.CharsCount_Deci(), 6, 6, 6, 6)){break;}
    isempty2=PText.isEmptyString(str2, true, true); if(!PText.checkInput(str2, true, CCore.CharsCount_Deci(), 6, 6, 6, 6)){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QConvertingReason.isSelected()){
    if(ListMdlQConvertingReason.Mdl.Rows.size()==0 && !CB_QConvertingReasonEmpty.isSelected()){break;}
   }
   if(CB_QConvRule.isSelected()){
    if(TableMdlQConvRule.Mdl.Rows.size()==0){break;}
   }
   if(CB_QItem.isSelected()){
    if(TableMdlQItem.Mdl.Rows.size()==0){break;}
   }
   input_valid=true;
  }while(false);
  if(!input_valid){JOptionPane.showMessageDialog(null, "Tidak dapat mencari : masukan masih salah / belum lengkap !"); return;}
  
  if(!IFV.canAccessGUI(3, true,
    true
  )){return;}
  
  // build query
  query_defined=true;
  StcSourceTable=new StringBuilder();
  StcCondition=new StringBuilder(); stc_con_defined=new VBoolean(false);
  StcPostConditions=new StringBuilder(); stc_conpost_defined=new VBoolean(false);
  
  WithTempList=0;
  
  if(CB_QCheck.isSelected()){
   switch(CmB_QCheck.getSelectedIndex()){
    case 0 :
     if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostConditions.append(" having");}else{StcPostConditions.append(" and");}
     StcPostConditions.append(" (ItemOutCount=0 or ItemInCount=0)"); break;
   }
  }
  
  if(CB_QConvertingDirection.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Conv.RuleOfConvDirection="+PText.getString(RB_QConvertingDirectionForward.isSelected(), CCore.vTrue, CCore.vFalse));
  }
  
  if(CB_QConvertingDate.isSelected()){
   str1="Conv.ConvDate";
   dt1=PGUI.valueOfDateComponent(TF_QConvertingDateStartY, CmB_QConvertingDateStartM, CmB_QConvertingDateStartD);
   dt2=PGUI.valueOfDateComponent(TF_QConvertingDateEndY, CmB_QConvertingDateEndM, CmB_QConvertingDateEndD);
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+">=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+"<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   StcCondition.append(")");
  }

  if(CB_QItemId.isSelected()){
   bool1=CmB_QItemId.getSelectedIndex()==0;
   str1=TF_QItemId.getText();
   tb_items=new StringBuilder("("+PMyShop.getQueryOfFindItemIds(
     PText.getString(bool1, String.valueOf(Long.parseLong(str1)), str1), !bool1, "Item.Id as 'ItemId'", null, true, null, false
    )+") as items");
   
   StcSourceTable.append(", ("+
     "(select Conv from ConvXItemOut, "+tb_items+" where ConvXItemOut.Item=items.ItemId group by Conv) "+
     "union distinct "+
     "(select Conv from ConvXItemIn, "+tb_items+" where ConvXItemIn.Item=items.ItemId group by Conv) "+
    ") as Conv_ItemId");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Conv.Id=Conv_ItemId.Conv");
  }

  if(CB_QItemName.isSelected()){
   tb_items2=new StringBuilder(", ("+
     "(select Id as 'ItemId' from Item where "+PSql.genCheckWord("Name", TF_QItemName.getText(), true, true)+") "+
     "union distinct "+
     "(select Item from ItemXVariant where "+PSql.genCheckWord("Variant", TF_QItemName.getText(), true, true)+" group by Item) "+
    ") as item_name");
   
   tb_items=new StringBuilder("(select Id as 'ItemId' from Item"+tb_items2+" where Item.Id=item_name.ItemId) as items");
   
   StcSourceTable.append(", ("+
     "(select Conv from ConvXItemOut, "+tb_items+" where ConvXItemOut.Item=items.ItemId group by Conv) "+
     "union distinct "+
     "(select Conv from ConvXItemIn, "+tb_items+" where ConvXItemIn.Item=items.ItemId group by Conv) "+
    ") as Conv_ItemName");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Conv.Id=Conv_ItemName.Conv");
  }
  
  if(CB_QConvRuleName.isSelected()){
   StcSourceTable.append(", ("+
     "select Conv.Id from Conv, "+
      "(select Id from RuleOfConv where "+PSql.genCheckWord("Name", TF_QConvRuleName.getText(), true, true)+") as tb1 "+
     "where Conv.RuleOfConv=tb1.Id"+
    ") as Conv_ConvRuleName");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Conv.Id=Conv_ConvRuleName.Id");
  }
  
  if(CB_QConvertingCount.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   str1="Conv.RuleOfConvCount";
   dbl1=PText.parseDouble(TF_QConvertingCount1.getText(), null, null); dbl2=PText.parseDouble(TF_QConvertingCount2.getText(), null, null);
   StcCondition.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCondition.append(" and");}
    StcCondition.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCondition.append(")");
  }
  
  if(CB_QConvertingReason.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" (");
   list_defined=false;
   if(ListMdlQConvertingReason.Mdl.Rows.size()!=0){
    StcCondition.append(" Conv.ReasonOfConv in ("+PGUI.getElementList(ListMdlQConvertingReason.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QConvertingReasonEmpty.isSelected()){
    if(list_defined){StcCondition.append(" or");} StcCondition.append(" Conv.ReasonOfConv is "+CCore.vNull);
   }
   StcCondition.append(")");
  }
  
  if(CB_QConvRule.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Conv.RuleOfConv in ("+PGUI.getElementList(TableMdlQConvRule.Mdl.Rows, 0, ",", "", false)+")");
  }
  
  if(CB_QItem.isSelected()){
   tb_items=new StringBuilder("(select Id as 'ItemId' from Item where Id in("+PGUI.getElementList(TableMdlQItem.Mdl.Rows, 0, ",", "", false)+")) as items");
   
   StcSourceTable.append(", ("+
     "(select Conv from ConvXItemOut, "+tb_items+" where ConvXItemOut.Item=items.ItemId group by Conv) "+
     "union distinct "+
     "(select Conv from ConvXItemIn, "+tb_items+" where ConvXItemIn.Item=items.ItemId group by Conv) "+
    ") as Conv_Item");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" Conv.Id=Conv_Item.Conv");
  }
  
  if(!query_defined){clearLastQuery();}
  else{
   setLastQuery(1, CApp.FormQueryLimit,
    StcSourceTable.toString(), StcCondition.toString(), stc_con_defined.Value, StcPostConditions.toString(), stc_conpost_defined.Value,
    WithTempList, true);
  }
  fillConv();
 }
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: QCB.setSelected(true); Btn_QueryActionPerformed(null); break;
   case KeyEvent.VK_RIGHT: if(QTF.getCaretPosition()==QTF.getDocument().getLength()){focusConv(true);} break;
  }
 }
 void queryOnKeyPressed_TextRange1(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF1.getCaretPosition()==QTF1.getDocument().getLength()){
     QTF2.requestFocusInWindow();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange2(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_LEFT:
    if(QTF2.getCaretPosition()==0){
     QTF1.requestFocusInWindow();
    }
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF2.getCaretPosition()==QTF2.getDocument().getLength()){
     if(!TableMdlConv.Mdl.Rows.isEmpty()){
      if(Tbl_Conv.getSelectedRow()==-1){Tbl_Conv.changeSelection(0, 0, false, false); onSelectedRowChanged(false);}
      Tbl_Conv.requestFocusInWindow();
     }
    }
    break;
  }
 }
 void clearTabQuery(){
  CB_QCheck.setSelected(false);
  CB_QConvertingDirection.setSelected(false);
  CB_QConvertingDate.setSelected(false);
  PGUI.clear(CB_QItemId, TF_QItemId);
  PGUI.clear(CB_QItemName, TF_QItemName);
  PGUI.clear(CB_QConvRuleName, TF_QConvRuleName);
  PGUI.clear(CB_QConvertingCount, TF_QConvertingCount1, TF_QConvertingCount2);
  CB_QConvertingReason.setSelected(false); CB_QConvertingReasonEmpty.setSelected(false); ListMdlQConvertingReason.removeAll();
  CB_QConvRule.setSelected(false); TableMdlQConvRule.removeAll();
  CB_QItem.setSelected(false); TableMdlQItem.removeAll();
 }
 void focusQuery(){
  if(LastFocusedCmpSearch==null){LastFocusedCmpSearch=TF_QItemName;}
  PGUI.requestFocusInWindow(LastFocusedCmpSearch);
 }
 
 // methods of convert rule
  // Table
 void updateTableConvView(boolean Requery){
  TableMdlConv.updateColumnsInfo(TableConvColsName, TableConvColsType, TableConvColsShowOption,
   TableConvColsVisible, TableConvColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Conv, TableConvColsWidth);
  if(!Requery){onSelectedRowChanged(false);}else{fillConv();}
 }
 void buildTableConvColumns(){
  int ColWidth_Rule=600;
  
  switch(CmB_OrderMode.getSelectedIndex()){
   case 0 :
    TableConvColsVisible=PCore.primArr(1, 4, 2, 6, 7);
    TableConvColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColDate+10, ColWidth_Rule, CGUI.ColTextSml, CGUI.ColTextMini, CGUI.ColNumSep06);
    break;
   case 1 :
    TableConvColsVisible=PCore.primArr(1, 2, 4, 6, 7);
    TableConvColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColDate+10, CGUI.ColTextSml, ColWidth_Rule, CGUI.ColTextMini, CGUI.ColNumSep06);
    break;
   case 2 :
    TableConvColsVisible=PCore.primArr(4, 1, 2, 6, 7);
    TableConvColsWidth=PCore.primArr(CGUI.ColCheck, ColWidth_Rule, CGUI.ColDate+10, CGUI.ColTextSml, CGUI.ColTextMini, CGUI.ColNumSep06);
    break;
   case 3 :
    TableConvColsVisible=PCore.primArr(4, 2, 1, 6, 7);
    TableConvColsWidth=PCore.primArr(CGUI.ColCheck, ColWidth_Rule, CGUI.ColTextSml, CGUI.ColDate+10, CGUI.ColTextMini, CGUI.ColNumSep06);
    break;
   case 4 :
    TableConvColsVisible=PCore.primArr(2, 1, 4, 6, 7);
    TableConvColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextSml, CGUI.ColDate+10, ColWidth_Rule, CGUI.ColTextMini, CGUI.ColNumSep06);
    break;
   case 5 :
    TableConvColsVisible=PCore.primArr(2, 4, 1, 6, 7);
    TableConvColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextSml, ColWidth_Rule, CGUI.ColDate+10, CGUI.ColTextMini, CGUI.ColNumSep06);
    break;
  }
 }
 void buildTableConvOrderBy(){
  StringBuilder strb;
  String Order_Date, Order_Reason, Order_ConvRule;
  
  strb=new StringBuilder();
  strb.append(" order by");
  
  Order_Date     = " ConvDate desc";
  Order_Reason   = " ReasonOfConvName asc";
  Order_ConvRule = " RuleOfConvName asc";
  switch(CmB_OrderMode.getSelectedIndex()){
   case 0 : strb.append(Order_Date+","+Order_ConvRule+","+Order_Reason); break;
   case 1 : strb.append(Order_Date+","+Order_Reason+","+Order_ConvRule); break;
   case 2 : strb.append(Order_ConvRule+","+Order_Date+","+Order_Reason); break;
   case 3 : strb.append(Order_ConvRule+","+Order_Reason+","+Order_Date); break;
   case 4 : strb.append(Order_Reason+","+Order_Date+","+Order_ConvRule); break;
   case 5 : strb.append(Order_Reason+","+Order_ConvRule+","+Order_Date); break;
  }
  strb.append(", "+QHavingTbl+".Id desc");
  
  LQ_OrderBy=strb.toString();
 }
 void buildTableConvViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableConvColumns();}
  if(RebuildOrderBy){buildTableConvOrderBy();}
 }
 void changeConvViewByNormal(){
  buildTableConvViewStructure(true, false);
  updateTableConvView(false);
 }
 void changeConvViewByOrderMode(){
  buildTableConvViewStructure(true, true);
  updateTableConvView(true);
 }
 
 void onSelectedRowChanged(boolean UpdateAnyway){
  int row=Tbl_Conv.getSelectedRow();
  
  if(row==LastSelectedRow && !UpdateAnyway){return;}
  
  LastSelectedRow=row;
  
  if(row==-1){clearInfoConv(false, true, true); return;}
  
  fillInfoConv(row, true, true);
 }
 void onSelectedOrderModeChanged(boolean UpdateAnyway){
  int CurrRow=CmB_OrderMode.getSelectedIndex();
  
  if(CurrRow==LastSelectedOrderMode && !UpdateAnyway){return;}
  
  LastSelectedOrderMode=CurrRow;
  
  // change table view
  changeConvViewByOrderMode();
 }
 
 void updateQueryCount(){TF_QueryCount.setText(PText.intToString(TableMdlConv.getRowCount()));}
 void updateQueryTempListCount(){TF_QueryTempListCount.setText("( "+PText.intToString(TableMdlConv.getCheckedCount())+" )");}
 
 void setLastQuery(int LastQueryOperationBy, int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConDefined, String StaticPostCondition, boolean StaticPostConDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  this.LastQueryOperationBy=LastQueryOperationBy;
  
  LQ_Limit=Limit;
  
		LQ_StaticSourceTable=StaticSourceTable;
		LQ_StaticCondition=StaticCondition; LQ_StaticConditionDefined=StaticConDefined;
		LQ_StaticPostCondition=StaticPostCondition; LQ_StaticPostConditionDefined=StaticPostConDefined;
  
  LQ_DynamicTempList=DynamicTempList;
  
  LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  LastQueryDefined=true;
 }
 void clearLastQuery(){LastQueryDefined=false;}
 String getQuery(){
  String ret=null;
  String Limit;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  long[] tlist;
  boolean con_defined, conpost_defined;
  
  do{
   // build query
   con_defined=LQ_StaticConditionDefined; conpost_defined=LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   if(LQ_DynamicTempList!=0){
    if(TempList.ElementsCount==0){if(LQ_DynamicTempList==1){break;}}
    else{
     if(!con_defined){con_defined=true; DynamicCondition.append(" where");}else{DynamicCondition.append(" and");}
     tlist=TempList.getElements();
     DynamicCondition.append(" Conv.Id"+PText.getString(LQ_DynamicTempList, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
    }
   }
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   if(LQ_WithAdditionalFilter){
    if(LastResultFilterSubset.Value!=0){
     if(LastResultFilterSubset.Value!=LQ_DynamicTempList){
      if(LQ_DynamicTempList!=0){break;}
      if(TempList.ElementsCount==0){if(LastResultFilterSubset.Value==1){break;}}
      else{
       if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
       tlist=TempList.getElements();
       AdditionalCondition.append(" Conv.Id"+PText.getString(LastResultFilterSubset.Value, 1, 2, " in", " not in", null)+
        "("+PText.toString(tlist, 0, tlist.length, ",")+")");
      }
     }
    }
   }
   
    // finally, build query
   Limit=PText.getString(LQ_Limit, 0, " limit "+LQ_Limit, "");
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
   ret=
    "select tb4.Id, ConvDate, ReasonOfConvName, "+
    "RuleOfConv, RuleOfConvName, IsActive, "+
    "if(RuleOfConvDirection,"+CApp.ConvRuleDirForwardSQL()+","+CApp.ConvRuleDirBackwardSQL()+"), RuleOfConvCount, ItemOutCount, Count(ConvXItemIn.Conv) as 'ItemInCount' from "+
     "(select tb3.*, Count(ConvXItemOut.Conv) as 'ItemOutCount' from "+
      "(select tb2.*, RuleOfConv.Name as 'RuleOfConvName', IsActive, LastUpdate from "+
       "(select tb1.*, ReasonOfConv.Name as 'ReasonOfConvName' from "+
        "(select Conv.* from Conv"+
        LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
        LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+") as tb1 "+
       "left join ReasonOfConv on tb1.ReasonOfConv=ReasonOfConv.Id) as tb2 "+
      "inner join RuleOfConv on tb2.RuleOfConv=RuleOfConv.Id) as tb3 "+
     "left join ConvXItemOut on tb3.Id=ConvXItemOut.Conv group by tb3.Id) as tb4 "+
    "left join ConvXItemIn on tb4.Id=ConvXItemIn.Conv group by tb4.Id"+
    LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+
    LQ_OrderBy+Limit;
  }while(false);
  
  return ret;
 }
 void fillConv(){
  String Query;
  
  clearConv();
  
  if(!LastQueryDefined){return;}
  
  Query=getQuery(); if(Query==null){return;}
  if(PDatabase.queryToTable(IFV.Stm, Query, TableMdlConv, false, true, TempList, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil query konversi dari database !");
  }
  updateQueryCount(); updateQueryTempListCount();
 }
 void clearConv(){
  TableMdlConv.removeAll(); onSelectedRowChanged(true);
  updateQueryCount(); updateQueryTempListCount();
 }
 void fillInfoConv(int row, boolean FillHeader, boolean FillListItems){
  Object[] objs=TableMdlConv.Mdl.Rows.elementAt(row);
  long Id=PCore.objLong(objs[0], -1L);
  
  if(FillHeader){TF_ConvInfoName.setText(PCore.objString(objs[4], ""));}
  if(FillListItems){fillConvItems(true, Id, true); fillConvItems(false, Id, true);}
  
  InfoConvClear=false;
 }
 void clearInfoConv(boolean ClearAnyway, boolean ClearHeader, boolean ClearListItems){
  if(InfoConvClear && !ClearAnyway){return;}
  
  if(ClearHeader){TF_ConvInfoName.setText("");}
  if(ClearListItems){clearConvItems(true); clearConvItems(false);}
  
  InfoConvClear=true;
 }
 
 void findInTableConv(int Mode){
  int Selected, FindIndex, Column;
  String str;
  
  str=TF_Find.getText(); if(str.length()==0){return;}
  if(TableMdlConv.Mdl.Rows.size()==0){JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !"); return;}
  
  switch(CmB_Find.getSelectedIndex()){
   case 0 : Column=4; break;
   case 1 : Column=2; break;
   default : Column=4; break;
  }
  Selected=Tbl_Conv.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlConv, Column, TableMdlConv.Mdl.ColumnsType[Column], str, Selected, Mode);
  if(FindIndex==-1){JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !"); return;}
  if(Selected==FindIndex){return;}
  Tbl_Conv.changeSelection(FindIndex, 0, false, false);
  onSelectedRowChanged(false);
 }
 
 void chooseData(){
  int[] rows;
  int temp, count;
  Object[] ARow;
  
  rows=Tbl_Conv.getSelectedRows(); count=rows.length;
  if(count==0){JOptionPane.showMessageDialog(null, "Anda harus memilih sebuah data aturan konversi pada tabel !"); return;}
  
  ChoosedId=new Long[count];
  
  temp=0;
  do{
   ARow=TableMdlConv.Mdl.Rows.elementAt(rows[temp]);
   
   ChoosedId[temp]=PCore.objLong(ARow[0], null);
   
   temp=temp+1;
  }while(temp!=count);
  
  closingForm(1);
  setVisible(false);
 }
 void onEditingTableConv(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=Tbl_Conv.Editing_Row;
  Col=TableMdlConv.convertColumnIndexFromViewToModel(Tbl_Conv.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdlConv.Mdl.ColumnsType[Col], null, Tbl_Conv.Editing_ValueOld, true, null, Tbl_Conv.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableConv_Check(Row); break;}
   result=onEditingTableConv_Conv(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableConv_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  PMyShop.tempListAdd(this, this, PGUI.getIdsFromSelectedRows(TableMdlConv, PCore.primArr(Row), 0), PCore.objBoolean(Tbl_Conv.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingTableConv_Conv(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  boolean valid, FetchDataOld;
  OEditConverting Edit;
  
  do{
   Edit=new OEditConverting();
   FetchDataOld=false;
   valid=true;
   switch(Col){
    
   }
   if(!valid){ret=-2; break;}

   if(editConv(PCore.primArr(Row), FetchDataOld, null, Edit, false)!=0){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 int editConv(int[] Rows, boolean FetchDataOld, OInfoConverting DataOld, OEditConverting Edit, boolean WithSplashScreen){
  /*
   EditMode :
   - 1 : complete, both header & list-items
   - 2 : only header
  */
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Id has already exist
  boolean error;
  long Id;
  Object[] RowData;
  int Row, count;
  Vector<OTableCellUpdater> Values, PostValues;
  OFormInformProgress Progress;
  
  do{
   count=Rows.length;
   Row=Rows[0]; RowData=TableMdlConv.Mdl.Rows.elementAt(Row); Id=(Long)RowData[0];

   Values=new Vector(); PostValues=new Vector();

   if(Edit.EditConvDate){
    Values.addElement(new OTableCellUpdaterByObject(1, Edit.EditedConvDate));
   }
   if(Edit.EditReasonOfConv){
    Values.addElement(new OTableCellUpdaterByObject(2, PText.getString(Edit.EditedReasonOfConvId, -1, Edit.EditedReasonOfConvName, null)));
   }
   if(Edit.EditConvRuleDirection){
    Values.addElement(new OTableCellUpdaterByObject(6, PText.getString(Edit.EditedConvRuleDirection, CApp.ConvRuleDirForward, CApp.ConvRuleDirBackward)));
   }
   if(Edit.EditConvRuleCount){
    Values.addElement(new OTableCellUpdaterByObject(7, Edit.EditedConvRuleCount));
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)
   

   // update
   error=false;
   
   if(WithSplashScreen){IFV.FSplashScreen.appear(this, "Mengubah Aturan Konversi");}
   if(WithSplashScreen){IFV.FSplashScreen.inform(0, "Mengubah "+PText.intToString(count)+" aturan konversi, harap menunggu ...", null);}
   
   do{
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(75);}

    Progress=null; if(WithSplashScreen){Progress=IFV.FSplashScreen;}
    ret=PMyShop.convertingEdit(IFV.Stm, TableMdlConv.getIds(0, Rows), FetchDataOld, DataOld, Edit, Progress);
    if(ret!=0){error=true; break;}
    
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(100);}

    // post-update
     // update table
    PGUI.changeElements(TableMdlConv, Rows, Values);
    PGUI.changeElements(TableMdlConv, Rows, PostValues);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(20, null, null);}

     // update detail
    clearInfoConv(true, true, true);
    fillInfoConv(Row, true, true);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(5, null, null);}
   }while(false);
   
   if(WithSplashScreen){IFV.FSplashScreen.disappear();}
   
   if(error){break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 void editConv(){
  boolean WithSplashScreen=false, FetchDataOld=false;
  long Id;
  int[] rows;
  OInfoConverting DataOld=null;
  OEditConverting Edit;
  F_ConvertingModify fm1=IFV.FConvertingModify;
  F_ConvertingModifyMulti fm2=IFV.FConvertingModifyMulti;
  boolean IsSame_Header, IsSame_ListItems;
  int result;
  
  rows=Tbl_Conv.getSelectedRows(); if(rows.length==0){return;}
  
  Edit=new OEditConverting();
  if(rows.length==1){
   Id=(Long)TableMdlConv.Mdl.Rows.elementAt(rows[0])[0];
   DataOld=PMyShop.getConvertingInfo(IFV.Stm, Id, true, false);
   if(DataOld==null){JOptionPane.showMessageDialog(null, "Gagal mengambil data Aturan Konversi !"); return;}
   
   fm1.wMode=2;
   fm1.InfoConverting=DataOld;
   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}
   
   WithSplashScreen=false;
   FetchDataOld=false;
   
   Edit.init(
    true, fm1.InfoConverting.ConvDate,
    true, fm1.InfoConverting.ReasonOfConvId, fm1.InfoConverting.ReasonOfConvName,
    true, fm1.InfoConverting.ConvRuleDirection,
    true, fm1.InfoConverting.ConvRuleCount);
  }
  else{
   fm2.wDataCount=rows.length;
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   WithSplashScreen=true;
   FetchDataOld=false;
   
   Edit.init(
    fm2.ChangeConvDate, fm2.ConvDate,
    fm2.ChangeReasonOfConv, fm2.ReasonOfConvId, fm2.ReasonOfConvName,
    fm2.ChangeConvRuleDirection, fm2.ConvRuleDirection,
    fm2.ChangeConvRuleCount, fm2.ConvRuleCount);
  }
  
  result=editConv(rows, FetchDataOld, DataOld, Edit, WithSplashScreen);
  if(result!=0){JOptionPane.showMessageDialog(null, "Gagal mengubah data !"); return;}
 }
 void addConv(){
  F_ConvertingModify fm1=IFV.FConvertingModify;
  F_ConvertRule fm2=IFV.FConvertRule;
  
  long Id;
  Object[] NewRow;
  int FindColumn, insertpos;
  String FindName;
  boolean found;
  
  fm2.wMode=1;
  fm2.wDialogWithFItem=true;
  fm2.wAllowMultipleSelection=false;
  fm2.wChooseActiveOnly=true;
  
  if(!fm2.showForm()){return;}
  if(fm2.DialogResult!=1){return;}
  
  fm1.wMode=1;
  fm1.wModeAdd_InitConvRule=fm2.ChoosedId[0];
  if(!fm1.showForm()){return;}
  if(fm1.DialogResult!=1){return;}
  
  Id=PMyShop.convertingAdd(IFV.Stm, IFV.ConvertingLock, fm1.InfoConverting);
  if(Id==-1){JOptionPane.showMessageDialog(null, "Gagal menambah data Konversi !"); return;}
  
  NewRow=new Object[8];
  NewRow[0]=Id;
  NewRow[1]=fm1.InfoConverting.ConvDate;
  NewRow[2]=PText.getString(fm1.InfoConverting.ReasonOfConvId, -1, fm1.InfoConverting.ReasonOfConvName, null);
  NewRow[3]=fm1.InfoConverting.ConvRule.Id;
  NewRow[4]=fm1.InfoConverting.ConvRule.Name;
  NewRow[5]=fm1.InfoConverting.ConvRule.IsActive;
  NewRow[6]=PText.getString(fm1.InfoConverting.ConvRuleDirection, CApp.ConvRuleDirForward, CApp.ConvRuleDirBackward);
  NewRow[7]=fm1.InfoConverting.ConvRuleCount;
  
  insertpos=TableMdlConv.getRowCount();
  TableMdlConv.insert(insertpos, NewRow);

  updateQueryCount();
  found=TempList.checkElement(Id)>=0;
  TableMdlConv.setChecked(insertpos, found); updateQueryTempListCount();
  
  Tbl_Conv.changeSelection(insertpos, 0, false, false); onSelectedRowChanged(true);
 }
 void removeConv(boolean IsCancelling){
  int[] rows;
  boolean result;
  
  rows=Tbl_Conv.getSelectedRows(); if(rows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null,
   PText.getString(IsCancelling, "Batalkan", "Hapus")+" "+PText.intToString(rows.length)+" data konversi yg dipilih pada tabel ?"+
   PText.getString(IsCancelling, "", "\nPerhatian: operasi ini akan menghapus data secara permanen di database !"),
   "Konfirmasi "+PText.getString(IsCancelling, "Pembatalan", "Penghapusan"), JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  IFV.FSplashScreen.appear(this, PText.getString(IsCancelling, "Membatalkan", "Menghapus")+" Data Konversi");
  IFV.FSplashScreen.inform(0, PText.getString(IsCancelling, "Membatalkan", "Menghapus")+" "+PText.intToString(rows.length)+" data konversi, harap menunggu ...", "-");
  
  result=PMyShop.convertingRemove(IsCancelling, IFV.Stm, IFV.ConvertingLock, TableMdlConv.getIds(0, rows), IFV.FSplashScreen);
  
  IFV.FSplashScreen.disappear();
  
  if(!result){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !"); return;}
  
  TableMdlConv.remove(rows); onSelectedRowChanged(true);
  updateQueryCount(); updateQueryTempListCount();
 }
 
 void printReport(){
  int count, temp;
  LinkedList<Long> Ids;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  F_PrintConverting fm=IFV.FPrintConverting;
  
  count=TableMdlConv.Mdl.Rows.size(); if(count==0){return;}

  fm.wOrderMode=LastSelectedOrderMode;
  fm.wListItem=0;
  fm.wListItemCategorized=0;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}

  IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
  IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
  IFV.FPrintDialog.wPrintSettingMode=2;
  IFV.FPrintDialog.wEnableOption=false;

  if(!IFV.FPrintDialog.showForm()){return;}
  if(IFV.FPrintDialog.DialogResult!=1){return;}
  PaperType=IFV.FPrintDialog.PaperType;
  Printer=IFV.FPrintDialog.Printer;

  temp=0; Ids=new LinkedList(); TempRows=TableMdlConv.Mdl.Rows;
  do{
   Ids.addLast((Long)TempRows.elementAt(temp)[0]);
   temp=temp+1;
  }while(temp!=count);

  IFV.PrintGenConverting.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, Ids,
   fm.OrderMode,
   fm.ListItem, fm.ListItemCategorized);

  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  bk=IFV.PrintGenConverting.generateBook(IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  if(bk==null){JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !"); return;}

  if(IFV.FPrintDialog.ChoosePage){
   IFV.FPrintPage.wBook=bk;

   if(!IFV.FPrintPage.showForm()){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
  }

  if(!PPrint.print(bk, Printer, "LapKonversi_"+PText.dateToString(new Date(), 101), false)){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !"); return;}
 }
 void printCSV(){
  F_PrintConverting fm1=IFV.FPrintConverting;
  F_CsvWriteOption fm2=IFV.FCsvWriteOption;
  File f;
  long OperationResult;
  long[] Ids;
  
  if(TableMdlConv.Mdl.Rows.size()==0){return;}
  
  fm1.wOrderMode=LastSelectedOrderMode;
  fm1.wListItem=0;
  fm1.wListItemCategorized=0;
  if(!fm1.showForm()){return;}
  if(fm1.DialogResult!=1){return;}
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(!fm2.showForm()){return;}
  if(fm2.DialogResult!=1){return;}
  
  Ids=TableMdlConv.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableMdlConv.Mdl.Rows.size(), 0, 1));
  
  IFV.FSplashScreen.appear(this, "Print Data Ke File CSV");
  OperationResult=PMyShop.printConvertingCSV(
   IFV.FSplashScreen, IFV.Stm, f, fm2.FieldDelimiter, fm2.FieldsSeparator, CCore.CsvDefaultRecordsSeparator, Ids,
   fm1.OrderMode,
   fm1.ListItem, fm1.ListItemCategorized);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses print data ke file CSV !"+"\n"+PMyShop.getCSVErrorMessage()); return;}
  
  /*
  JOptionPane.showMessageDialog(null,
   "Operasi berhasil !\n"+
   "Total data yg di-print ke file CSV = "+PText.intToString(OperationResult));
  */
 }
 
 void focusConv(boolean PushFocus){
  if(TableMdlConv.Mdl.Rows.isEmpty()){return;}
  
  if(Tbl_Conv.getSelectedRow()==-1){
   if(!PushFocus){return;}
   Tbl_Conv.changeSelection(0, 0, false, false); onSelectedRowChanged(false);
  }
  PGUI.requestFocusInWindow(Tbl_Conv);
 }
 
  // Table - List Items
 void updateTableConvItemsView(boolean IsItemOut, boolean Requery){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  VIntegerArray ColsVisible=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsVisible, TableConvItemsInColsVisible);
  VIntegerArray ColsWidth=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsWidth, TableConvItemsInColsWidth);
  
  int row;
  long Id;
  
  TableMdl.updateColumnsInfo(TableConvItemsColsName, TableConvItemsColsType, TableConvItemsColsShowOption,
   ColsVisible.Value, TableConvItemsColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl, ColsWidth.Value);
  if(!Requery){onSelectedRowChangedConvItems(IsItemOut, false);}
  else{
   Id=-1; row=Tbl_Conv.getSelectedRow(); if(row!=-1){Id=(Long)TableMdlConv.Mdl.Rows.elementAt(row)[0];}
   fillConvItems(IsItemOut, Id, false);
  }
 }
 void buildTableConvItemsColumns(boolean IsItemOut){
  JToggleButton CB_ViewCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  boolean IsCategorized=CB_ViewCategorized.isSelected();
  VIntegerArray ColsVisible=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsVisible, TableConvItemsInColsVisible);
  VIntegerArray ColsWidth=(VIntegerArray)PCore.subtituteBool(IsItemOut, TableConvItemsOutColsWidth, TableConvItemsInColsWidth);
  
  ColsVisible.Value=PMyShop.getConvertItems_ColumnsVisible(IsCategorized);
  ColsWidth.Value=PMyShop.getConvertItems_ColumnsWidth(IsCategorized);
 }
 void buildTableConvItemsViewStructure(boolean IsItemOut, boolean RebuildColumns){
  if(RebuildColumns){buildTableConvItemsColumns(IsItemOut);}
 }
 void changeConvItemsViewByCategorized(boolean IsItemOut){
  buildTableConvItemsViewStructure(IsItemOut, true);
  updateTableConvItemsView(IsItemOut, true);
 }
 
 void onEditingTableItem(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int ItemRow, ItemCol;
  int result=0;
  boolean IsSame;
  
  ItemRow=Tbl.Editing_Row;
  ItemCol=TableMdl.convertColumnIndexFromViewToModel(Tbl.Editing_Col);
  
  if(ItemCol!=-1){
   IsSame=PCore.grading(TableMdl.Mdl.ColumnsType[ItemCol], null, Tbl.Editing_ValueOld, true, null, Tbl.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(ItemCol==-1){result=0; break;}
   result=onEditingTableItem_Item(IsItemOut, ItemRow, ItemCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableItem_Item(boolean IsItemOut, int ItemRow, int ItemCol){
  int ret=0;
  
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  boolean valid;
  int ConvRow;
  OEditConvertItem Edit;
  
  do{
   ConvRow=Tbl_Conv.getSelectedRow(); if(ConvRow==-1){break;}
   
   Edit=new OEditConvertItem();
   valid=true;
   switch(ItemCol){
    // double not null, positive only, >0
    case 2 : Edit.EditQuantity=true; Edit.EditedQuantity=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedQuantity<=0){valid=false;} break;
   }
   if(!valid){ret=-2; break;}

   if(!convItemsEdit(IsItemOut, ConvRow, PCore.primArr(ItemRow), Edit)){ret=-1; break;}
  }while(false);
  
  return ret;
 }
 
 void onSelectedRowChangedConvItems(boolean IsItemOut, boolean UpdateAnyway){
  VInteger LastSelectedRow=(VInteger)PCore.subtituteBool(IsItemOut, LastSelectedRowConvItemsOut, LastSelectedRowConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int row=Tbl.getSelectedRow();
  
  if(LastSelectedRow.Value==row && !UpdateAnyway){return;}
  
  LastSelectedRow.Value=row;
  
  if(row==-1){clearConvItemsInfo(IsItemOut); return;}
  
  fillConvItemsInfo(IsItemOut, row);
 }
 
 void refreshConvItemsCount(boolean IsItemOut){
  JTextField TF_Count=(JTextField)PCore.subtituteBool(IsItemOut, TF_ItemOutCount, TF_ItemInCount);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  TF_Count.setText(PText.intToString(TableMdl.getRowCount()));
 }
 void fillConvItems(boolean IsItemOut, long Id, boolean SelectAData){
  JToggleButton CB_ViewCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  Vector<Object[]> result;
  
  clearConvItems(IsItemOut);
  
  if(Id==-1){return;}
  
  result=PMyShop.getConvertItems(IFV.Stm, false, IsItemOut, Id, CB_ViewCategorized.isSelected());
  if(result==null){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dlm mengambil daftar barang "+PText.getString(IsItemOut, "Keluar", "Masuk")+" !");
   return;
  }
  
  TableMdl.append(result);
  refreshConvItemsCount(IsItemOut);
  
  if(!SelectAData || TableMdl.getRowCount()==0){return;}
  Tbl.changeSelection(0, 0, false, false); onSelectedRowChangedConvItems(IsItemOut, false);
 }
 void clearConvItems(boolean IsItemOut){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  TableMdl.removeAll(); onSelectedRowChangedConvItems(IsItemOut, true);
  refreshConvItemsCount(IsItemOut);
 }
 void fillConvItemsInfo(boolean IsItemOut, int Row){
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  JTextArea TA_InfoCategory=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoCategory, TA_ItemInInfoCategory);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  VBoolean InfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, InfoConvItemsOutClear, InfoConvItemsInClear);
  
  Object[] objs=TableMdl.Mdl.Rows.elementAt(Row);
  
  TA_InfoCategory.setText(PCore.objString(objs[6], ""));
  TA_InfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+PCore.objString(objs[1], ""));
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, objs[5]);
  
  InfoClear.Value=false;
 }
 void clearConvItemsInfo(boolean IsItemOut){
  XImgBoxURL Pnl_InfoPreview=(XImgBoxURL)PCore.subtituteBool(IsItemOut, Pnl_ItemOutInfoPreview, Pnl_ItemInInfoPreview);
  JTextArea TA_InfoCategory=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoCategory, TA_ItemInInfoCategory);
  JTextArea TA_InfoName=(JTextArea)PCore.subtituteBool(IsItemOut, TA_ItemOutInfoName, TA_ItemInInfoName);
  VBoolean InfoClear=(VBoolean)PCore.subtituteBool(IsItemOut, InfoConvItemsOutClear, InfoConvItemsInClear);
  
  if(InfoClear.Value){return;}
  
  TA_InfoCategory.setText("");
  TA_InfoName.setText("");
  PGUI.fillPanelPictureURL(Pnl_InfoPreview, IFV.Conf.ImageDirItem, null);
  
  InfoClear.Value=true;
 }
 
 void convItemsAdd(boolean IsItemOut){
  int ConvRow;
  long ItemId;
  Object[] NewRow;
  F_ConvertItemModify fm=IFV.FConvertItemModify;
  
  ConvRow=Tbl_Conv.getSelectedRow(); if(ConvRow==-1){return;}

  fm.wConvert=2;
  fm.wMode=0;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  ItemId=fm.ItemInfo.PrimaryId;
  
  NewRow=new Object[7];
  NewRow[0]=ItemId;
  NewRow[1]=fm.ItemInfo.Name;
  NewRow[2]=fm.Qty;
  NewRow[3]=fm.ItemInfo.StockUnitName;
  NewRow[4]=fm.ItemInfo.UpdateStock;
  NewRow[5]=fm.ItemInfo.PictureFile;
  NewRow[6]=fm.ItemInfo.CategoryName;
  
  if(!convItemsAdd(IsItemOut, PCore.primArr(ConvRow), ConvRow, PCore.toMultiRows2(NewRow))){
   JOptionPane.showMessageDialog(null, "Gagal menambah data barang !"); return;}
 }
 boolean convItemsAdd(boolean IsItemOut, int[] ConvRows, int ConvRow, Vector<Object[]> NewRows){
  boolean ret=false;
  
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int insertpos;
  
  do{
   insertpos=convItemsAdd_(IsItemOut, ConvRows, ConvRow, NewRows); if(insertpos==-1){break;}
   
   refreshConvItemsCount(IsItemOut);
   Tbl_Item.changeSelection(insertpos, 0, false, false); onSelectedRowChangedConvItems(IsItemOut, true);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 int convItemsAdd_(boolean IsItemOut, int[] ConvRows, int ConvRow, Vector<Object[]> NewRows){
  int ret=-1;
  long[] ConvIds=TableMdlConv.getIds(0, ConvRows);
  
  do{
   if(!PMyShop.convertingAddItem2(IsItemOut, true, IFV.Stm, ConvIds, NewRows)){break;}
   ret=convItemsAdd_GUI(IsItemOut, ConvRow, PTable.subDataOfIds(NewRows, PMyShop.getConvertItems_ColumnsType(), PCore.newIntegerArrayInOrderedSequence(NewRows.size(), 0, 1), 0));
  }while(false);
  
  return ret;
 }
 int convItemsAdd_GUI(boolean IsItemOut, int ConvRow, long[] Items){
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  JToggleButton CB_ItemCategorized=(JToggleButton)PCore.subtituteBool(IsItemOut, CB_ItemOutViewCategorized, CB_ItemInViewCategorized);
  boolean IsCategorized=CB_ItemCategorized.isSelected();
  
  int ret=-1;
  int temp, count;
  long ItemId;
  int FindColumn;
  String FindName;
  Object[] NewRow;
  Vector<Object[]> NewRows;
  long ConvId=(Long)TableMdlConv.Mdl.Rows.elementAt(ConvRow)[0];
  
  do{
   NewRows=PMyShop.getConvertItems(IFV.Stm, false, IsItemOut, ConvId, IsCategorized, Items); if(NewRows==null){break;}
   count=NewRows.size(); if(count==0){break;}
   
   temp=0;
   do{
    NewRow=NewRows.elementAt(temp);
    ItemId=PCore.objLong(NewRow[0], -1L);
    ret=PTable.findNumber(TableMdlItem.Mdl.Rows, ItemId, 0, false);
    if(ret==-1){
     if(!IsCategorized){FindColumn=1;}else{FindColumn=6;}
     FindName=PCore.objString(NewRow[FindColumn], null);
     ret=PGUI.findInsertPos(TableMdlItem, FindColumn, FindName, false, true, true);
     TableMdlItem.insert(ret, NewRow);
    }
    else{
     TableMdlItem.changeValue(ret, NewRow);
    }
    
    temp=temp+1;
   }while(temp!=count);
  }while(false);
  
  return ret;
 }
 void convItemsEdit(boolean IsItemOut){
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int ConvRow;
  int[] ItemRows;
  OEditConvertItem Edit=new OEditConvertItem();
  F_ConvertItemModify fm1=IFV.FConvertItemModify;
  F_ConvertItemModifyMulti fm2=IFV.FConvertItemModifyMulti;
  
  ConvRow=Tbl_Conv.getSelectedRow(); if(ConvRow==-1){return;}
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}

  if(ItemRows.length==1){
   fm1.wConvert=2;
   fm1.wMode=1;
   fm1.wItemId=(Long)TableMdlItem.Mdl.Rows.elementAt(ItemRows[0])[0];
   fm1.wQuantity=(Double)TableMdlItem.Mdl.Rows.elementAt(ItemRows[0])[2];
   
   if(!fm1.showForm()){return;}
   if(fm1.DialogResult!=1){return;}

   Edit.init(
    true, fm1.Qty);
  }
  else{
   fm2.wDataCount=ItemRows.length;
   
   if(!fm2.showForm()){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    fm2.ChangeQuantity, fm2.Quantity);
  }
  
  if(!convItemsEdit(IsItemOut, ConvRow, ItemRows, Edit)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data barang !"); return;}
 }
 boolean convItemsEdit(boolean IsItemOut, int ConvRow, int[] ItemRows, OEditConvertItem Edit){
  boolean ret=false;
  long ConvId=(Long)TableMdlConv.Mdl.Rows.elementAt(ConvRow)[0];
  
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  Vector<OTableCellUpdater> ChangeValues;
  
  do{
   if(!PMyShop.convertingEditItems(IsItemOut, IFV.Stm, ConvId, TableMdlItem.getIds(0, ItemRows), Edit)){break;}
   
   ChangeValues=new Vector();
   
   if(Edit.EditQuantity){
    ChangeValues.addElement(new OTableCellUpdaterByObject(2, Edit.EditedQuantity));
   }
   
   PGUI.changeElements(TableMdlItem, ItemRows, ChangeValues);

   // fillConvItemsInfo(IsItemOut, ItemRows[0]);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void convItemsCancel(boolean IsItemOut){
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int ConvRow;
  int[] ItemRows;
  
  ConvRow=Tbl_Conv.getSelectedRow(); if(ConvRow==-1){return;}
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Batalkan "+ItemRows.length+" barang "+PText.getString(IsItemOut, "keluar", "masuk")+" yang dipilih ?",
   "Konfirmasi Pembatalan Barang "+PText.getString(IsItemOut, "Keluar", "Masuk"), JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!convItemsCancel(IsItemOut, ConvRow, ItemRows)){
   JOptionPane.showMessageDialog(null, "Gagal membatalkan data barang !"); return;}
 }
 boolean convItemsCancel(boolean IsItemOut, int ConvRow, int[] ItemRows){
  boolean ret=false;
  long ConvId=(Long)TableMdlConv.Mdl.Rows.elementAt(ConvRow)[0];
  
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  
  do{
   if(!PMyShop.convertingCancelItems(IsItemOut, IFV.Stm, ConvId, TableMdlItem.getIds(0, ItemRows))){break;}
   
   TableMdlItem.remove(ItemRows); onSelectedRowChangedConvItems(IsItemOut, true);
   refreshConvItemsCount(IsItemOut);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 void convItemsMove(boolean IsItemOut){
  XTable Tbl_Item=(XTable)PCore.subtituteBool(IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  int ConvRow;
  int[] ItemRows;
  
  ConvRow=Tbl_Conv.getSelectedRow(); if(ConvRow==-1){return;}
  
  ItemRows=Tbl_Item.getSelectedRows(); if(ItemRows.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null,
   "Pindahkan "+ItemRows.length+" barang "+PText.getString(IsItemOut, "keluar", "masuk")+" yang dipilih "+
   "ke daftar "+PText.getString(IsItemOut, "barang masuk", "barang keluar")+" ?",
   "Konfirmasi Pemindahan Barang "+PText.getString(IsItemOut, "Keluar", "Masuk"), JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  
  if(!convItemsMove(IsItemOut, ConvRow, ItemRows)){
   JOptionPane.showMessageDialog(null, "Gagal memindahkan data barang !"); return;}
 }
 boolean convItemsMove(boolean IsItemOut, int ConvRow, int[] ItemRows){
  boolean ret=false;
  
  OCustomTableModel TableMdlItemSrc=(OCustomTableModel)PCore.subtituteBool(IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  OCustomTableModel TableMdlItemDest=(OCustomTableModel)PCore.subtituteBool(!IsItemOut, TableMdlConvItemsOut, TableMdlConvItemsIn);
  XTable Tbl_Item_Dest=(XTable)PCore.subtituteBool(!IsItemOut, Tbl_ItemOut, Tbl_ItemIn);
  
  int insertpos;
  long[] ItemsId;
  long ConvId=(Long)TableMdlConv.Mdl.Rows.elementAt(ConvRow)[0];
  
  do{
   ItemsId=TableMdlItemSrc.getIds(0, ItemRows);
   if(!PMyShop.convertingMoveItems2(IsItemOut, IFV.Stm, ConvId, ItemsId)){break;}
   
   insertpos=convItemsAdd_GUI(!IsItemOut, ConvRow, ItemsId);
   if(insertpos!=-1){Tbl_Item_Dest.changeSelection(insertpos, 0, false, false);} onSelectedRowChangedConvItems(!IsItemOut, true);
   refreshConvItemsCount(!IsItemOut);
   
   TableMdlItemSrc.remove(ItemRows); onSelectedRowChangedConvItems(IsItemOut, true);
   refreshConvItemsCount(IsItemOut);
   
   ret=true;
  }while(false);
  
  return ret;
 }
 
  // TempList
 void updateTempListQuantity(){TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));}
 public void fillTempList(long[] ConvRules, boolean IsAdd){
  long[] AffectItems;
  
  if(ConvRules.length==0){return;}
  
  AffectItems=PCore.subArr(ConvRules, TempList.addElements(ConvRules, IsAdd));
  if(AffectItems.length==0){return;}
  
  updateTempListQuantity();
  fillSignItems(AffectItems, IsAdd);
 }
 public void clearTempList(){
  TempList.removeAll();
  updateTempListQuantity();
  
  clearSignItems();
 }
 void fillSignItems(long[] ConvRules, boolean SignValue){
  TableMdlConv.check(ConvRules, SignValue, 0);
  updateQueryTempListCount();
 }
 void clearSignItems(){
  TableMdlConv.checkAll(false);
  updateQueryTempListCount();
 }
 
  // Additional Filter
 void onSelectedAdditionalFilterChanged(JComboBox CmB, VInteger LastSelected){
  int selected=CmB.getSelectedIndex();
  
  if(LastSelected.Value==selected){return;}
  
  LastSelected.Value=selected;
  fillConv();
 }
 
 // methods of others
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, IFV.CurrentUserPrivDbPublic);
 }
 void initPrivGUIShow(){
  
 }
 void dialogWithFItem(boolean Enable){
  PGUI.setEnabled(Enable, Btn_QItemAdd, Btn_New, Btn_Edit, Btn_ItemOutAdd, Btn_ItemInAdd);
 }
 
 //
 void focusQueryResult(){
  focusConv(true);
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_QConvertingDirection = new javax.swing.ButtonGroup();
  jPanel1 = new javax.swing.JPanel();
  jPanel3 = new javax.swing.JPanel();
  Btn_New = new javax.swing.JButton();
  Btn_Edit = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  Btn_Report = new javax.swing.JButton();
  CmB_ReportType = new javax.swing.JComboBox<>();
  Btn_Cancel = new javax.swing.JButton();
  Btn_ConvertRuleTempListRemove = new javax.swing.JButton();
  Btn_ConvertRuleTempListAdd = new javax.swing.JButton();
  jLabel7 = new javax.swing.JLabel();
  jPanel4 = new javax.swing.JPanel();
  jPanel10 = new javax.swing.JPanel();
  jPanel6 = new javax.swing.JPanel();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBef = new javax.swing.JButton();
  TF_Find = new javax.swing.JTextField();
  CmB_Find = new javax.swing.JComboBox<>();
  CmB_OrderMode = new javax.swing.JComboBox<>();
  jLabel9 = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_Conv = new XTable();
  TF_ConvInfoName = new javax.swing.JTextField();
  jPanel11 = new javax.swing.JPanel();
  jPanel9 = new javax.swing.JPanel();
  jPanel14 = new javax.swing.JPanel();
  jLabel3 = new javax.swing.JLabel();
  TF_ItemInCount = new javax.swing.JTextField();
  Btn_ItemInRemove = new javax.swing.JButton();
  Btn_ItemInEdit = new javax.swing.JButton();
  Btn_ItemInAdd = new javax.swing.JButton();
  Btn_ItemInMove = new javax.swing.JButton();
  CB_ItemInViewCategorized = new javax.swing.JToggleButton();
  jPanel15 = new javax.swing.JPanel();
  Pnl_ItemInInfoPreview = new XImgBoxURL();
  jScrollPane5 = new javax.swing.JScrollPane();
  TA_ItemInInfoCategory = new javax.swing.JTextArea();
  jScrollPane6 = new javax.swing.JScrollPane();
  TA_ItemInInfoName = new javax.swing.JTextArea();
  jScrollPane7 = new javax.swing.JScrollPane();
  Tbl_ItemIn = new XTable();
  jPanel8 = new javax.swing.JPanel();
  jPanel5 = new javax.swing.JPanel();
  jLabel2 = new javax.swing.JLabel();
  TF_ItemOutCount = new javax.swing.JTextField();
  Btn_ItemOutRemove = new javax.swing.JButton();
  Btn_ItemOutEdit = new javax.swing.JButton();
  Btn_ItemOutAdd = new javax.swing.JButton();
  Btn_ItemOutMove = new javax.swing.JButton();
  CB_ItemOutViewCategorized = new javax.swing.JToggleButton();
  jPanel13 = new javax.swing.JPanel();
  Pnl_ItemOutInfoPreview = new XImgBoxURL();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_ItemOutInfoCategory = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  TA_ItemOutInfoName = new javax.swing.JTextArea();
  jScrollPane4 = new javax.swing.JScrollPane();
  Tbl_ItemOut = new XTable();
  jPanel2 = new javax.swing.JPanel();
  TF_QueryCount = new javax.swing.JTextField();
  TF_QueryTempListCount = new javax.swing.JTextField();
  CmB_ResultFilterSubset = new javax.swing.JComboBox<>();
  Btn_TempListClear = new javax.swing.JButton();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  Btn_QueryRefresh = new javax.swing.JButton();
  Pnl_Query = new javax.swing.JPanel();
  Btn_Query = new javax.swing.JButton();
  jLabel4 = new javax.swing.JLabel();
  TF_QConvRuleName = new javax.swing.JTextField();
  CB_QConvRuleName = new javax.swing.JCheckBox();
  CB_QConvertingReason = new javax.swing.JCheckBox();
  TF_QItemName = new javax.swing.JTextField();
  TF_QItemId = new javax.swing.JTextField();
  CB_QItemId = new javax.swing.JCheckBox();
  CB_QItemName = new javax.swing.JCheckBox();
  CmB_QItemId = new javax.swing.JComboBox<>();
  jScrollPane9 = new javax.swing.JScrollPane();
  Tbl_QItem = new XTable();
  CB_QItem = new javax.swing.JCheckBox();
  Lbl_QItemIdHelp = new javax.swing.JLabel();
  Lbl_QItemNameHelp = new javax.swing.JLabel();
  Lbl_ConvRuleNameHelp = new javax.swing.JLabel();
  Btn_QConvertingReasonAdd = new javax.swing.JButton();
  Btn_QConvertingReasonRemove = new javax.swing.JButton();
  Btn_QItemAdd = new javax.swing.JButton();
  Btn_QItemRemove = new javax.swing.JButton();
  CmB_QConvertingDateEndD = new javax.swing.JComboBox<>();
  CB_QConvertingDate = new javax.swing.JCheckBox();
  TF_QConvertingDateStartY = new javax.swing.JTextField();
  CmB_QConvertingDateStartM = new javax.swing.JComboBox<>();
  CmB_QConvertingDateStartD = new javax.swing.JComboBox<>();
  jLabel5 = new javax.swing.JLabel();
  TF_QConvertingDateEndY = new javax.swing.JTextField();
  CmB_QConvertingDateEndM = new javax.swing.JComboBox<>();
  CB_QConvertingReasonEmpty = new javax.swing.JCheckBox();
  CB_QConvertingDirection = new javax.swing.JCheckBox();
  RB_QConvertingDirectionForward = new javax.swing.JRadioButton();
  RB_QConvertingDirectionBackward = new javax.swing.JRadioButton();
  TF_QConvertingCount1 = new javax.swing.JTextField();
  CB_QConvertingCount = new javax.swing.JCheckBox();
  jLabel6 = new javax.swing.JLabel();
  TF_QConvertingCount2 = new javax.swing.JTextField();
  Btn_QConvRuleAdd = new javax.swing.JButton();
  Btn_QConvRuleRemove = new javax.swing.JButton();
  CB_QConvRule = new javax.swing.JCheckBox();
  SP_TblQConvRule = new javax.swing.JScrollPane();
  Tbl_QConvRule = new XTable();
  Lbl_ConvertingCountHelp = new javax.swing.JLabel();
  CmB_QCheck = new javax.swing.JComboBox<>();
  CB_QCheck = new javax.swing.JCheckBox();
  jScrollPane10 = new javax.swing.JScrollPane();
  List_QConvertingReason = new XList();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Btn_New.setText("Tambah {F1}");
  Btn_New.setToolTipText("tambah data konversi yg baru");
  Btn_New.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_New.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_NewActionPerformed(evt);
   }
  });

  Btn_Edit.setText("Ubah {F2}");
  Btn_Edit.setToolTipText("ubah data konversi yg dipilih pd tabel");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });

  Btn_Remove.setText("Hapus");
  Btn_Remove.setToolTipText("hapus data konversi yg dipilih pd tabel (tidak akan mengubah nilai stok dr barang yg bersangkutan)");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });

  Btn_Report.setText("Cetak");
  Btn_Report.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Report.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReportActionPerformed(evt);
   }
  });

  CmB_ReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laporan", "CSV" }));

  Btn_Cancel.setText("Batal {F3}");
  Btn_Cancel.setToolTipText("batalkan data konversi yg dipilih pd tabel (akan mengubah nilai stok dr barang yg bersangkutan)");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });

  Btn_ConvertRuleTempListRemove.setText("-");
  Btn_ConvertRuleTempListRemove.setToolTipText("kurangi aturan2 konversi yg dipilih dari 'DaftarKu' pd form Aturan Konversi");
  Btn_ConvertRuleTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ConvertRuleTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ConvertRuleTempListRemoveActionPerformed(evt);
   }
  });

  Btn_ConvertRuleTempListAdd.setText("+");
  Btn_ConvertRuleTempListAdd.setToolTipText("tambahkan aturan2 konversi yg dipilih ke 'DaftarKu' pd form Aturan Konversi");
  Btn_ConvertRuleTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ConvertRuleTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ConvertRuleTempListAddActionPerformed(evt);
   }
  });

  jLabel7.setText("*");

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(Btn_New)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Edit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Cancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Remove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Report)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel7)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ConvertRuleTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ConvertRuleTempListRemove))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_New)
    .addComponent(Btn_Edit)
    .addComponent(Btn_Remove)
    .addComponent(Btn_Report)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_Cancel)
    .addComponent(Btn_ConvertRuleTempListRemove)
    .addComponent(Btn_ConvertRuleTempListAdd)
    .addComponent(jLabel7))
  );

  jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_FindBef.setText("<");
  Btn_FindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBefActionPerformed(evt);
   }
  });

  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_FindFocusLost(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  CmB_Find.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aturan", "Alasan" }));

  CmB_OrderMode.setBackground(new java.awt.Color(204, 204, 0));
  CmB_OrderMode.setForeground(new java.awt.Color(102, 102, 0));
  CmB_OrderMode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tgl - Aturan - Alasan", "Tgl - Alasan - Aturan", "Aturan - Tgl - Alasan", "Aturan - Alasan - Tgl", "Alasan - Tgl - Aturan", "Alasan - Aturan - Tgl" }));
  CmB_OrderMode.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_OrderModeActionPerformed(evt);
   }
  });

  jLabel9.setText("Urut Berdasarkan");

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Find)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel9)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_OrderMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_FindBef)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_OrderMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel9))
  );

  Tbl_Conv.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Conv.setToolTipText("F9 - tambah ke DaftarKu ; F10 - hapus dr DaftarKu");
  Tbl_Conv.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Conv.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Conv.setRowHeight(18);
  Tbl_Conv.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ConvMouseReleased(evt);
   }
  });
  Tbl_Conv.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_ConvKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ConvKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_Conv);

  TF_ConvInfoName.setEditable(false);
  TF_ConvInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_ConvInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_ConvInfoName.setToolTipText("klik utk melihat keterangan aturan konversi");
  TF_ConvInfoName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_ConvInfoName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_ConvInfoNameMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jScrollPane1)
   .addComponent(TF_ConvInfoName)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(TF_ConvInfoName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel9.setBackground(new java.awt.Color(204, 255, 102));
  jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel14.setOpaque(false);

  jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel3.setText("Barang Masuk (Ke)");

  TF_ItemInCount.setEditable(false);
  TF_ItemInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_ItemInRemove.setText("H");
  Btn_ItemInRemove.setToolTipText("Batalkan data barang masuk yg dipilih pd tabel");
  Btn_ItemInRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInRemoveActionPerformed(evt);
   }
  });

  Btn_ItemInEdit.setText("U");
  Btn_ItemInEdit.setToolTipText("Ubah data barang masuk yg dipilih pd tabel");
  Btn_ItemInEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInEditActionPerformed(evt);
   }
  });

  Btn_ItemInAdd.setText("B");
  Btn_ItemInAdd.setToolTipText("Tambah data barang masuk");
  Btn_ItemInAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInAddActionPerformed(evt);
   }
  });

  Btn_ItemInMove.setText("<<");
  Btn_ItemInMove.setToolTipText("Pindahkan barang-barang masuk yg dipilih ke daftar barang keluar");
  Btn_ItemInMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemInMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemInMoveActionPerformed(evt);
   }
  });

  CB_ItemInViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemInViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemInViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemInViewCategorized.setText("K");
  CB_ItemInViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemInViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemInViewCategorized.setIconTextGap(0);
  CB_ItemInViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemInViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemInViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemInRemove))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(jLabel3)
    .addComponent(TF_ItemInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_ItemInRemove)
    .addComponent(Btn_ItemInEdit)
    .addComponent(Btn_ItemInAdd)
    .addComponent(Btn_ItemInMove)
    .addComponent(CB_ItemInViewCategorized))
  );

  Pnl_ItemInInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemInInfoCategory.setEditable(false);
  TA_ItemInInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoCategory.setColumns(20);
  TA_ItemInInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoCategory.setLineWrap(true);
  TA_ItemInInfoCategory.setRows(1);
  TA_ItemInInfoCategory.setWrapStyleWord(true);
  jScrollPane5.setViewportView(TA_ItemInInfoCategory);

  TA_ItemInInfoName.setEditable(false);
  TA_ItemInInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemInInfoName.setColumns(20);
  TA_ItemInInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemInInfoName.setLineWrap(true);
  TA_ItemInInfoName.setRows(1);
  TA_ItemInInfoName.setWrapStyleWord(true);
  jScrollPane6.setViewportView(TA_ItemInInfoName);

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createSequentialGroup()
    .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 342, Short.MAX_VALUE)
     .addComponent(jScrollPane6)))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemInInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel15Layout.createSequentialGroup()
    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemIn.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemIn.setRowHeight(17);
  Tbl_ItemIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemInMouseReleased(evt);
   }
  });
  Tbl_ItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemInKeyReleased(evt);
   }
  });
  jScrollPane7.setViewportView(Tbl_ItemIn);

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createSequentialGroup()
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  jPanel8.setBackground(new java.awt.Color(255, 204, 153));
  jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  jPanel5.setOpaque(false);

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel2.setText("Barang Keluar (Dari)");

  TF_ItemOutCount.setEditable(false);
  TF_ItemOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_ItemOutRemove.setText("H");
  Btn_ItemOutRemove.setToolTipText("Batalkan data barang keluar yg dipilih pd tabel");
  Btn_ItemOutRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutRemoveActionPerformed(evt);
   }
  });

  Btn_ItemOutEdit.setText("U");
  Btn_ItemOutEdit.setToolTipText("Ubah data barang keluar yg dipilih pd tabel");
  Btn_ItemOutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutEditActionPerformed(evt);
   }
  });

  Btn_ItemOutAdd.setText("B");
  Btn_ItemOutAdd.setToolTipText("Tambah data barang keluar");
  Btn_ItemOutAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutAddActionPerformed(evt);
   }
  });

  Btn_ItemOutMove.setText(">>");
  Btn_ItemOutMove.setToolTipText("Pindahkan barang-barang keluar yg dipilih ke daftar barang masuk");
  Btn_ItemOutMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_ItemOutMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ItemOutMoveActionPerformed(evt);
   }
  });

  CB_ItemOutViewCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutViewCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutViewCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutViewCategorized.setText("K");
  CB_ItemOutViewCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemOutViewCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutViewCategorized.setIconTextGap(0);
  CB_ItemOutViewCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutViewCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutViewCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutViewCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutMove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_ItemOutRemove))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(jLabel2)
    .addComponent(TF_ItemOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_ItemOutRemove)
    .addComponent(Btn_ItemOutEdit)
    .addComponent(Btn_ItemOutAdd)
    .addComponent(Btn_ItemOutMove)
    .addComponent(CB_ItemOutViewCategorized))
  );

  Pnl_ItemOutInfoPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutInfoPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutInfoPreviewMouseClicked(evt);
   }
  });

  TA_ItemOutInfoCategory.setEditable(false);
  TA_ItemOutInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoCategory.setColumns(20);
  TA_ItemOutInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoCategory.setLineWrap(true);
  TA_ItemOutInfoCategory.setRows(1);
  TA_ItemOutInfoCategory.setWrapStyleWord(true);
  jScrollPane2.setViewportView(TA_ItemOutInfoCategory);

  TA_ItemOutInfoName.setEditable(false);
  TA_ItemOutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_ItemOutInfoName.setColumns(20);
  TA_ItemOutInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_ItemOutInfoName.setLineWrap(true);
  TA_ItemOutInfoName.setRows(1);
  TA_ItemOutInfoName.setWrapStyleWord(true);
  jScrollPane3.setViewportView(TA_ItemOutInfoName);

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane2)
     .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_ItemOutInfoPreview, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addGroup(jPanel13Layout.createSequentialGroup()
    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
  );

  Tbl_ItemOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_ItemOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_ItemOut.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  Tbl_ItemOut.setRowHeight(17);
  Tbl_ItemOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_ItemOutMouseReleased(evt);
   }
  });
  Tbl_ItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_ItemOutKeyReleased(evt);
   }
  });
  jScrollPane4.setViewportView(Tbl_ItemOut);

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_QueryCount.setEditable(false);
  TF_QueryCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  TF_QueryTempListCount.setEditable(false);
  TF_QueryTempListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryTempListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  CmB_ResultFilterSubset.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "*Semua", "*DaftarKu", "*~DftarKu" }));
  CmB_ResultFilterSubset.setToolTipText("Filter \"DaftarKu\"");
  CmB_ResultFilterSubset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterSubsetActionPerformed(evt);
   }
  });

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi konversi2 yg dipilih dari 'DaftarKu'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan konversi2 yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu' (klik kiri - lihat DaftarKu ; klik kanan - lihat ~DaftarKu)");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TempListQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TempListQuantityMouseClicked(evt);
   }
  });

  jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel1.setText("*DaftarKu");

  Btn_QueryRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_QueryRefresh.setText("R");
  Btn_QueryRefresh.setToolTipText("klik 'R' untuk menyegarkan daftar konversi dlm tabel");
  Btn_QueryRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_QueryRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryRefreshActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_QueryRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel1)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListSave)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListLoad)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListClear))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_QueryCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_TempListClear)
    .addComponent(Btn_TempListLoad)
    .addComponent(Btn_TempListSave)
    .addComponent(Btn_TempListRemove)
    .addComponent(Btn_TempListAdd)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel1)
    .addComponent(Btn_QueryRefresh))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  Pnl_Query.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });
  Btn_Query.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QueryKeyPressed(evt);
   }
  });

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("-- Filter (kosongkan smua utk cari smua)");

  TF_QConvRuleName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvRuleNameFocusGained(evt);
   }
  });
  TF_QConvRuleName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvRuleNameKeyPressed(evt);
   }
  });

  CB_QConvRuleName.setText("Nm Atr");
  CB_QConvRuleName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvRuleName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvRuleNameKeyPressed(evt);
   }
  });

  CB_QConvertingReason.setText("Alasan");
  CB_QConvertingReason.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvertingReason.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvertingReasonKeyPressed(evt);
   }
  });

  TF_QItemName.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemNameFocusGained(evt);
   }
  });
  TF_QItemName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemNameKeyPressed(evt);
   }
  });

  TF_QItemId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemIdFocusGained(evt);
   }
  });
  TF_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemIdKeyPressed(evt);
   }
  });

  CB_QItemId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemIdKeyPressed(evt);
   }
  });

  CB_QItemName.setText("Nm Brg");
  CB_QItemName.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemName.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemNameKeyPressed(evt);
   }
  });

  CmB_QItemId.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Sub" }));
  CmB_QItemId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QItemIdKeyPressed(evt);
   }
  });

  Tbl_QItem.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_QItem.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_QItemKeyReleased(evt);
   }
  });
  jScrollPane9.setViewportView(Tbl_QItem);

  CB_QItem.setText("Barang");
  CB_QItem.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemKeyPressed(evt);
   }
  });

  Lbl_QItemIdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QItemIdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QItemIdHelp.setText("(?)");
  Lbl_QItemIdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QItemIdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QItemIdHelpMouseClicked(evt);
   }
  });

  Lbl_QItemNameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QItemNameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QItemNameHelp.setText("(?)");
  Lbl_QItemNameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QItemNameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QItemNameHelpMouseClicked(evt);
   }
  });

  Lbl_ConvRuleNameHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ConvRuleNameHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ConvRuleNameHelp.setText("(?)");
  Lbl_ConvRuleNameHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ConvRuleNameHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ConvRuleNameHelpMouseClicked(evt);
   }
  });

  Btn_QConvertingReasonAdd.setText("+");
  Btn_QConvertingReasonAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QConvertingReasonAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QConvertingReasonAddActionPerformed(evt);
   }
  });
  Btn_QConvertingReasonAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QConvertingReasonAddKeyPressed(evt);
   }
  });

  Btn_QConvertingReasonRemove.setText("-");
  Btn_QConvertingReasonRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QConvertingReasonRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QConvertingReasonRemoveActionPerformed(evt);
   }
  });
  Btn_QConvertingReasonRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QConvertingReasonRemoveKeyPressed(evt);
   }
  });

  Btn_QItemAdd.setText("+");
  Btn_QItemAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemAddActionPerformed(evt);
   }
  });
  Btn_QItemAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemAddKeyPressed(evt);
   }
  });

  Btn_QItemRemove.setText("-");
  Btn_QItemRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemRemoveActionPerformed(evt);
   }
  });
  Btn_QItemRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemRemoveKeyPressed(evt);
   }
  });

  CmB_QConvertingDateEndD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QConvertingDateEndD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvertingDateEndDKeyPressed(evt);
   }
  });

  CB_QConvertingDate.setText("Tgl");
  CB_QConvertingDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvertingDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvertingDateKeyPressed(evt);
   }
  });

  TF_QConvertingDateStartY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvertingDateStartYFocusGained(evt);
   }
  });
  TF_QConvertingDateStartY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvertingDateStartYKeyPressed(evt);
   }
  });

  CmB_QConvertingDateStartM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QConvertingDateStartM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvertingDateStartMKeyPressed(evt);
   }
  });

  CmB_QConvertingDateStartD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QConvertingDateStartD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvertingDateStartDKeyPressed(evt);
   }
  });

  jLabel5.setText("-");

  TF_QConvertingDateEndY.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvertingDateEndYFocusGained(evt);
   }
  });
  TF_QConvertingDateEndY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvertingDateEndYKeyPressed(evt);
   }
  });

  CmB_QConvertingDateEndM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QConvertingDateEndM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QConvertingDateEndMKeyPressed(evt);
   }
  });

  CB_QConvertingReasonEmpty.setText("ksg");
  CB_QConvertingReasonEmpty.setToolTipText("centang opsi ini utk mengikutsertakan konversi dgn alasan yg tdk didefenisikan");
  CB_QConvertingReasonEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvertingReasonEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvertingReasonEmptyKeyPressed(evt);
   }
  });

  CB_QConvertingDirection.setText("Arah");
  CB_QConvertingDirection.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvertingDirection.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvertingDirectionKeyPressed(evt);
   }
  });

  RG_QConvertingDirection.add(RB_QConvertingDirectionForward);
  RB_QConvertingDirectionForward.setText("A - B");
  RB_QConvertingDirectionForward.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_QConvertingDirectionForward.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_QConvertingDirectionForwardKeyPressed(evt);
   }
  });

  RG_QConvertingDirection.add(RB_QConvertingDirectionBackward);
  RB_QConvertingDirectionBackward.setText("B - A");
  RB_QConvertingDirectionBackward.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_QConvertingDirectionBackward.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_QConvertingDirectionBackwardKeyPressed(evt);
   }
  });

  TF_QConvertingCount1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvertingCount1FocusGained(evt);
   }
  });
  TF_QConvertingCount1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvertingCount1KeyPressed(evt);
   }
  });

  CB_QConvertingCount.setText("Jumlah");
  CB_QConvertingCount.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvertingCount.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvertingCountKeyPressed(evt);
   }
  });

  jLabel6.setText("-");

  TF_QConvertingCount2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QConvertingCount2FocusGained(evt);
   }
  });
  TF_QConvertingCount2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QConvertingCount2KeyPressed(evt);
   }
  });

  Btn_QConvRuleAdd.setText("+");
  Btn_QConvRuleAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QConvRuleAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QConvRuleAddActionPerformed(evt);
   }
  });
  Btn_QConvRuleAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QConvRuleAddKeyPressed(evt);
   }
  });

  Btn_QConvRuleRemove.setText("-");
  Btn_QConvRuleRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QConvRuleRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QConvRuleRemoveActionPerformed(evt);
   }
  });
  Btn_QConvRuleRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QConvRuleRemoveKeyPressed(evt);
   }
  });

  CB_QConvRule.setText("Aturan");
  CB_QConvRule.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QConvRule.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QConvRuleKeyPressed(evt);
   }
  });

  Tbl_QConvRule.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_QConvRule.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_QConvRule.setRowMargin(0);
  Tbl_QConvRule.setShowHorizontalLines(false);
  Tbl_QConvRule.setShowVerticalLines(false);
  Tbl_QConvRule.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_QConvRuleKeyReleased(evt);
   }
  });
  SP_TblQConvRule.setViewportView(Tbl_QConvRule);

  Lbl_ConvertingCountHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ConvertingCountHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ConvertingCountHelp.setText("(?)");
  Lbl_ConvertingCountHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ConvertingCountHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ConvertingCountHelpMouseClicked(evt);
   }
  });

  CmB_QCheck.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tanpa Barang di Sisi A atau Sisi B" }));
  CmB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCheckKeyPressed(evt);
   }
  });

  CB_QCheck.setText("Cek");
  CB_QCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCheckKeyPressed(evt);
   }
  });

  List_QConvertingReason.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QConvertingReasonKeyReleased(evt);
   }
  });
  jScrollPane10.setViewportView(List_QConvertingReason);

  javax.swing.GroupLayout Pnl_QueryLayout = new javax.swing.GroupLayout(Pnl_Query);
  Pnl_Query.setLayout(Pnl_QueryLayout);
  Pnl_QueryLayout.setHorizontalGroup(
   Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_QueryLayout.createSequentialGroup()
    .addComponent(jLabel4)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
   .addGroup(Pnl_QueryLayout.createSequentialGroup()
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QConvertingReason)
     .addComponent(CB_QItem)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItemName)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QItemNameHelp))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItemId)
      .addGap(0, 0, 0)
      .addComponent(CmB_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(1, 1, 1)
      .addComponent(Lbl_QItemIdHelp))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QConvRuleName)
      .addGap(2, 2, 2)
      .addComponent(Lbl_ConvRuleNameHelp))
     .addComponent(CB_QConvertingDate)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addComponent(CB_QConvertingReasonEmpty))
     .addComponent(CB_QConvertingDirection)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QConvertingCount)
      .addGap(2, 2, 2)
      .addComponent(Lbl_ConvertingCountHelp))
     .addComponent(CB_QConvRule)
     .addComponent(CB_QCheck))
    .addGap(4, 4, 4)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_QItemId)
     .addComponent(TF_QItemName)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane10)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QConvertingReasonAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QConvertingReasonRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QItemAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QItemRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addComponent(TF_QConvRuleName, javax.swing.GroupLayout.Alignment.TRAILING)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(TF_QConvertingDateStartY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(4, 4, 4)
      .addComponent(CmB_QConvertingDateStartM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(4, 4, 4)
      .addComponent(CmB_QConvertingDateStartD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(3, 3, 3)
      .addComponent(jLabel5)
      .addGap(3, 3, 3)
      .addComponent(TF_QConvertingDateEndY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(4, 4, 4)
      .addComponent(CmB_QConvertingDateEndM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(4, 4, 4)
      .addComponent(CmB_QConvertingDateEndD, 0, 73, Short.MAX_VALUE))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(TF_QConvertingCount1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel6)
      .addGap(2, 2, 2)
      .addComponent(TF_QConvertingCount2))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(SP_TblQConvRule, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QConvRuleAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QConvRuleRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addComponent(CmB_QCheck, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(RB_QConvertingDirectionForward)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(RB_QConvertingDirectionBackward)
      .addGap(0, 0, Short.MAX_VALUE))))
  );
  Pnl_QueryLayout.setVerticalGroup(
   Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Pnl_QueryLayout.createSequentialGroup()
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Query)
     .addComponent(jLabel4))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QConvertingDirection)
     .addComponent(RB_QConvertingDirectionForward)
     .addComponent(RB_QConvertingDirectionBackward))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_QCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QCheck))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QConvertingDateStartY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QConvertingDateStartM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QConvertingDateStartD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel5)
     .addComponent(TF_QConvertingDateEndY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QConvertingDateEndM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QConvertingDateEndD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QConvertingDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QItemId)
     .addComponent(CmB_QItemId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QItemIdHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QItemName)
     .addComponent(Lbl_QItemNameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QConvRuleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QConvRuleName)
     .addComponent(Lbl_ConvRuleNameHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QConvertingCount1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QConvertingCount)
     .addComponent(jLabel6)
     .addComponent(TF_QConvertingCount2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_ConvertingCountHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(CB_QConvertingReason)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QConvertingReasonEmpty))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QConvertingReasonAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QConvertingReasonRemove))
     .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QConvRuleAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QConvRuleRemove)
      .addGap(0, 0, Short.MAX_VALUE))
     .addGroup(Pnl_QueryLayout.createSequentialGroup()
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_QConvRule)
       .addComponent(SP_TblQConvRule, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Pnl_QueryLayout.createSequentialGroup()
        .addGroup(Pnl_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(CB_QItem)
         .addComponent(Btn_QItemAdd))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QItemRemove)
        .addContainerGap(121, Short.MAX_VALUE))
       .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(Pnl_Query, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Pnl_Query, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void TF_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemIdKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QItemId, TF_QItemId, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvertingDateStartY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QItemId)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QItemIdKeyPressed

 private void TF_QItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemNameKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QItemName, TF_QItemName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QConvRuleName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemName)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QItemNameKeyPressed

 private void TF_QConvRuleNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvRuleNameKeyPressed
  int consumed=PNav.onKey_Query_TF(this, CB_QConvRuleName, TF_QConvRuleName, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QConvertingCount1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvRuleName)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QConvRuleNameKeyPressed

 private void Btn_QConvertingReasonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QConvertingReasonAddActionPerformed
  int temp, temp_;
  
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblReasonOfConv;
  IFV.FDataIdName.wUseCustomTitle=false;
  
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult!=1){return;}
  
  temp_=0; temp=IFV.FDataIdName.DataId.length;
  do{
   ListMdlQConvertingReason.append(PCore.objArrVariant(
    (int)IFV.FDataIdName.DataId[temp_],
    IFV.FDataIdName.DataName[temp_]
   ));
   
   temp_=temp_+1;
  }while(temp_!=temp);
 }//GEN-LAST:event_Btn_QConvertingReasonAddActionPerformed

 private void Btn_QConvertingReasonRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QConvertingReasonRemoveActionPerformed
  ListMdlQConvertingReason.remove(List_QConvertingReason.getSelectedIndices());
 }//GEN-LAST:event_Btn_QConvertingReasonRemoveActionPerformed

 private void Btn_QItemAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemAddActionPerformed
  int count, temp;
  
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=true;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult!=1){return;}
  
  temp=0; count=IFV.FItem.ChoosedId.length;
  do{
   TableMdlQItem.append(PCore.objArrVariant(
    IFV.FItem.ChoosedId[temp],
    IFV.FItem.ChoosedName[temp]
   ));
   
   temp=temp+1;
  }while(temp!=count);
 }//GEN-LAST:event_Btn_QItemAddActionPerformed

 private void Btn_QItemRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveActionPerformed
  TableMdlQItem.remove(Tbl_QItem.getSelectedRows());
 }//GEN-LAST:event_Btn_QItemRemoveActionPerformed

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  runQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void Btn_QueryRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryRefreshActionPerformed
  fillConv();
 }//GEN-LAST:event_Btn_QueryRefreshActionPerformed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  PMyShop.tempListAdd(this, this, PGUI.getIdsFromSelectedRows(TableMdlConv, Tbl_Conv.getSelectedRows(), 0), true);
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  PMyShop.tempListAdd(this, this, PGUI.getIdsFromSelectedRows(TableMdlConv, Tbl_Conv.getSelectedRows(), 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  PMyShop.tempListSave(this, this, TempList, IFV.FileChooser, IFV.ReportFileFilter, IFV.FSplashScreen);
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  PMyShop.tempListLoad(this, this, TempList, IFV.FileChooser, IFV.ReportFileFilter, IFV.FSplashScreen);
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  PMyShop.tempListClear(this, this);
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Btn_FindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBefActionPerformed
  findInTableConv(2);
 }//GEN-LAST:event_Btn_FindBefActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findInTableConv(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Conv)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Find)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void Tbl_ConvKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ConvKeyReleased
  onSelectedRowChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Conv, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_LEFT: if(Tbl_Conv.OnKeyPress_PosCol<=0){focusQuery();} break;
  }
 }//GEN-LAST:event_Tbl_ConvKeyReleased

 private void Tbl_ConvMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ConvMouseReleased
  onSelectedRowChanged(false);
 }//GEN-LAST:event_Tbl_ConvMouseReleased

 private void Tbl_ItemOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemOutMouseReleased
  onSelectedRowChangedConvItems(true, false);
 }//GEN-LAST:event_Tbl_ItemOutMouseReleased

 private void Tbl_ItemOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemOutKeyReleased
  onSelectedRowChangedConvItems(true, false);
 }//GEN-LAST:event_Tbl_ItemOutKeyReleased

 private void Tbl_ItemInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ItemInKeyReleased
  onSelectedRowChangedConvItems(false, false);
 }//GEN-LAST:event_Tbl_ItemInKeyReleased

 private void Tbl_ItemInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_ItemInMouseReleased
  onSelectedRowChangedConvItems(false, false);
 }//GEN-LAST:event_Tbl_ItemInMouseReleased

 private void Btn_NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_NewActionPerformed
  addConv();
 }//GEN-LAST:event_Btn_NewActionPerformed

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  editConv();
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  removeConv(false);
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean ModeChoose;
  
  if(Activ){return;}
  
  Activ=true;
  ModeChoose=wMode!=0;
  
  setTitle(PText.getString(!ModeChoose, "Konversi", "Cari dan Pilih Konversi"));
  
  Tbl_Conv.setSelectionMode(PCore.subtBool_Int(!wAllowMultipleSelection, ListSelectionModel.SINGLE_SELECTION, ListSelectionModel.MULTIPLE_INTERVAL_SELECTION));
  
  dialogWithFItem(wDialogWithFItem);

  initPrivGUIShow();

  focusQuery();
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void CmB_ResultFilterSubsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterSubsetActionPerformed
  onSelectedAdditionalFilterChanged(CmB_ResultFilterSubset, LastResultFilterSubset);
 }//GEN-LAST:event_CmB_ResultFilterSubsetActionPerformed

 private void TF_TempListQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TempListQuantityMouseClicked
  int DynamicTempList=0;
  
  do{
   if(SwingUtilities.isLeftMouseButton(evt)){DynamicTempList=1; break;}
   if(SwingUtilities.isRightMouseButton(evt)){DynamicTempList=2; break;}
   DynamicTempList=-1;
  }while(false);
  if(DynamicTempList==-1){return;}
  
  setLastQuery(3, 0, "", "", false, "", false, DynamicTempList, false);
  fillConv();
 }//GEN-LAST:event_TF_TempListQuantityMouseClicked

 private void TF_QItemIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemIdFocusGained
  LastFocusedCmpSearch=TF_QItemId;
  PGUI.text_SelectAll(TF_QItemId);
 }//GEN-LAST:event_TF_QItemIdFocusGained

 private void Tbl_ConvKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_ConvKeyPressed
  boolean ChooseMode=wMode!=0;
  
  switch(evt.getKeyCode()){
			case KeyEvent.VK_ENTER:
    /*
    if(ChooseMode && !Tbl_Conv.isEditing()){
     if(Tbl_Conv.getSelectedRows().length!=0){evt.consume(); Btn_ChooseActionPerformed(null);}
    }
    */
    break;
  }
 }//GEN-LAST:event_Tbl_ConvKeyPressed

 private void TF_QItemNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemNameFocusGained
  LastFocusedCmpSearch=TF_QItemName;
  PGUI.text_SelectAll(TF_QItemName);
 }//GEN-LAST:event_TF_QItemNameFocusGained

 private void TF_QConvRuleNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvRuleNameFocusGained
  LastFocusedCmpSearch=TF_QConvRuleName;
  PGUI.text_SelectAll(TF_QConvRuleName);
 }//GEN-LAST:event_TF_QConvRuleNameFocusGained

 private void TF_QConvertingDateEndYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvertingDateEndYFocusGained
  LastFocusedCmpSearch=TF_QConvertingDateEndY;
  PGUI.text_SelectAll(TF_QConvertingDateEndY);
 }//GEN-LAST:event_TF_QConvertingDateEndYFocusGained

 private void TF_QConvertingDateStartYFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvertingDateStartYFocusGained
  LastFocusedCmpSearch=TF_QConvertingDateStartY;
  PGUI.text_SelectAll(TF_QConvertingDateStartY);
 }//GEN-LAST:event_TF_QConvertingDateStartYFocusGained

 private void Lbl_QItemIdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QItemIdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QItemIdHelpMouseClicked

 private void Lbl_QItemNameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QItemNameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QItemNameHelpMouseClicked

 private void Lbl_ConvRuleNameHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ConvRuleNameHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_ConvRuleNameHelpMouseClicked

 private void Pnl_ItemOutInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemOut, TableMdlConvItemsOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutInfoPreviewMouseClicked

 private void Pnl_ItemInInfoPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInInfoPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_ItemIn, TableMdlConvItemsIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInInfoPreviewMouseClicked

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOn);
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 private void TF_FindFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusLost
  TF_Find.setBackground(CGUI.Color_TextBox_FocusOff);
 }//GEN-LAST:event_TF_FindFocusLost

 private void Btn_ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReportActionPerformed
  switch(CmB_ReportType.getSelectedIndex()){
   case 0 : printReport(); break; // Report
   case 1 : printCSV(); break; // CSV Report
  }
 }//GEN-LAST:event_Btn_ReportActionPerformed

 private void Btn_ItemOutAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutAddActionPerformed
  convItemsAdd(true);
 }//GEN-LAST:event_Btn_ItemOutAddActionPerformed

 private void Btn_ItemOutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutEditActionPerformed
  convItemsEdit(true);
 }//GEN-LAST:event_Btn_ItemOutEditActionPerformed

 private void Btn_ItemOutRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutRemoveActionPerformed
  convItemsCancel(true);
 }//GEN-LAST:event_Btn_ItemOutRemoveActionPerformed

 private void Btn_ItemInAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInAddActionPerformed
  convItemsAdd(false);
 }//GEN-LAST:event_Btn_ItemInAddActionPerformed

 private void Btn_ItemInEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInEditActionPerformed
  convItemsEdit(false);
 }//GEN-LAST:event_Btn_ItemInEditActionPerformed

 private void Btn_ItemInRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInRemoveActionPerformed
  convItemsCancel(false);
 }//GEN-LAST:event_Btn_ItemInRemoveActionPerformed

 private void Btn_QConvRuleAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QConvRuleAddActionPerformed
  int count, temp;
  
  IFV.FConvertRule.wMode=1;
  IFV.FConvertRule.wAllowMultipleSelection=true;
  IFV.FConvertRule.wChooseActiveOnly=false;
  IFV.FConvertRule.wDialogWithFItem=true;
  
  if(IFV.FConvertRule.showForm()==false){return;}
  if(IFV.FConvertRule.DialogResult!=1){return;}
  
  temp=0; count=IFV.FConvertRule.ChoosedId.length;
  do{
   TableMdlQConvRule.append(PCore.objArrVariant(
    IFV.FConvertRule.ChoosedId[temp],
    IFV.FConvertRule.ChoosedName[temp]
   ));
   
   temp=temp+1;
  }while(temp!=count);
 }//GEN-LAST:event_Btn_QConvRuleAddActionPerformed

 private void Btn_QConvRuleRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QConvRuleRemoveActionPerformed
  TableMdlQConvRule.remove(Tbl_QConvRule.getSelectedRows());
 }//GEN-LAST:event_Btn_QConvRuleRemoveActionPerformed

 private void CmB_OrderModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_OrderModeActionPerformed
  onSelectedOrderModeChanged(false);
 }//GEN-LAST:event_CmB_OrderModeActionPerformed

 private void TF_QConvertingCount1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvertingCount1FocusGained
  LastFocusedCmpSearch=TF_QConvertingCount1;
  PGUI.text_SelectAll(TF_QConvertingCount1);
 }//GEN-LAST:event_TF_QConvertingCount1FocusGained

 private void TF_QConvertingCount2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QConvertingCount2FocusGained
  LastFocusedCmpSearch=TF_QConvertingCount2;
  PGUI.text_SelectAll(TF_QConvertingCount2);
 }//GEN-LAST:event_TF_QConvertingCount2FocusGained

 private void TF_QConvertingCount1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvertingCount1KeyPressed
  int consumed=PNav.onKey_Query_TF1(this, CB_QConvertingCount, TF_QConvertingCount1, TF_QConvertingCount2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvRuleName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QConvertingReasonAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvertingCount)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QConvertingCount1KeyPressed

 private void TF_QConvertingCount2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvertingCount2KeyPressed
  int consumed=PNav.onKey_Query_TF2(this, CB_QConvertingCount, TF_QConvertingCount1, TF_QConvertingCount2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvRuleName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QConvertingReasonAdd)));
  if(consumed==CNav.Ret_Consumed){return;}
 }//GEN-LAST:event_TF_QConvertingCount2KeyPressed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  removeConv(true);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Lbl_ConvertingCountHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ConvertingCountHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter2 >= Parameter1.\n"+PText.getInputInfo(false, CCore.CharsCount_Deci(), 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_ConvertingCountHelpMouseClicked

 private void TF_ConvInfoNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_ConvInfoNameMouseClicked
  PMyShop.viewFormInfo_SpecificConvertRule_FromTable(Tbl_Conv, TableMdlConv, 3, IFV.FConvertRulePreview, false);
 }//GEN-LAST:event_TF_ConvInfoNameMouseClicked

 private void Btn_ConvertRuleTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ConvertRuleTempListAddActionPerformed
  int[] rows=Tbl_Conv.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FConvertRule.fillTempList(TableMdlConv.getIds(3, rows), true);
 }//GEN-LAST:event_Btn_ConvertRuleTempListAddActionPerformed

 private void Btn_ConvertRuleTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ConvertRuleTempListRemoveActionPerformed
  int[] rows=Tbl_Conv.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FConvertRule.fillTempList(TableMdlConv.getIds(3, rows), false);
 }//GEN-LAST:event_Btn_ConvertRuleTempListRemoveActionPerformed

 private void Btn_ItemOutMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemOutMoveActionPerformed
  convItemsMove(true);
 }//GEN-LAST:event_Btn_ItemOutMoveActionPerformed

 private void Btn_ItemInMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ItemInMoveActionPerformed
  convItemsMove(false);
 }//GEN-LAST:event_Btn_ItemInMoveActionPerformed

 private void Btn_QueryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QueryKeyPressed
  PNav.onKey_Btn(this, Btn_Query, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvertingDirection)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QueryKeyPressed

 private void CB_QConvertingDirectionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvertingDirectionKeyPressed
  PNav.onKey_CB(this, CB_QConvertingDirection, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_QConvertingDirectionForward)));
 }//GEN-LAST:event_CB_QConvertingDirectionKeyPressed

 private void RB_QConvertingDirectionForwardKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_QConvertingDirectionForwardKeyPressed
  PNav.onKey_RB(this, RB_QConvertingDirectionForward, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvertingDirection)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_QConvertingDirectionBackward)));
 }//GEN-LAST:event_RB_QConvertingDirectionForwardKeyPressed

 private void RB_QConvertingDirectionBackwardKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_QConvertingDirectionBackwardKeyPressed
  PNav.onKey_RB(this, RB_QConvertingDirectionBackward, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_QConvertingDirectionForward)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_RB_QConvertingDirectionBackwardKeyPressed

 private void CB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCheckKeyPressed
  PNav.onKey_CB(this, CB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvertingDirection)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvertingDate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCheck)));
 }//GEN-LAST:event_CB_QCheckKeyPressed

 private void CmB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCheckKeyPressed
  PNav.onKey_CmB(this, CmB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCheck)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QCheckKeyPressed

 private void CB_QConvertingDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvertingDateKeyPressed
  PNav.onKey_CB(this, CB_QConvertingDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvertingDateStartY)));
 }//GEN-LAST:event_CB_QConvertingDateKeyPressed

 private void TF_QConvertingDateStartYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvertingDateStartYKeyPressed
  PNav.onKey_TF(this, TF_QConvertingDateStartY, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvertingDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvertingDateStartM)));
 }//GEN-LAST:event_TF_QConvertingDateStartYKeyPressed

 private void CmB_QConvertingDateStartMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvertingDateStartMKeyPressed
  PNav.onKey_CmB(this, CmB_QConvertingDateStartM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QConvertingDateStartY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvertingDateStartD)));
 }//GEN-LAST:event_CmB_QConvertingDateStartMKeyPressed

 private void CmB_QConvertingDateStartDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvertingDateStartDKeyPressed
  PNav.onKey_CmB(this, CmB_QConvertingDateStartD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QConvertingDateStartM)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvertingDateEndY)));
 }//GEN-LAST:event_CmB_QConvertingDateStartDKeyPressed

 private void TF_QConvertingDateEndYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QConvertingDateEndYKeyPressed
  PNav.onKey_TF(this, TF_QConvertingDateEndY, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QConvertingDateStartD)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvertingDateEndM)));
 }//GEN-LAST:event_TF_QConvertingDateEndYKeyPressed

 private void CmB_QConvertingDateEndMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvertingDateEndMKeyPressed
  PNav.onKey_CmB(this, CmB_QConvertingDateEndM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QConvertingDateEndY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QConvertingDateEndD)));
 }//GEN-LAST:event_CmB_QConvertingDateEndMKeyPressed

 private void CmB_QConvertingDateEndDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QConvertingDateEndDKeyPressed
  PNav.onKey_CmB(this, CmB_QConvertingDateEndD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QConvertingDateEndM)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QConvertingDateEndDKeyPressed

 private void CB_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemIdKeyPressed
  PNav.onKey_CB(this, CB_QItemId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvertingDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QItemId)));
 }//GEN-LAST:event_CB_QItemIdKeyPressed

 private void CmB_QItemIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QItemIdKeyPressed
  PNav.onKey_CmB(this, CmB_QItemId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemId)));
 }//GEN-LAST:event_CmB_QItemIdKeyPressed

 private void CB_QItemNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemNameKeyPressed
  PNav.onKey_CB(this, CB_QItemName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvRuleName)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemName)));
 }//GEN-LAST:event_CB_QItemNameKeyPressed

 private void CB_QConvRuleNameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvRuleNameKeyPressed
  PNav.onKey_CB(this, CB_QConvRuleName, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvertingCount)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvRuleName)));
 }//GEN-LAST:event_CB_QConvRuleNameKeyPressed

 private void CB_QConvertingCountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvertingCountKeyPressed
  PNav.onKey_CB(this, CB_QConvertingCount, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvRuleName)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvertingReason)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QConvertingCount1)));
 }//GEN-LAST:event_CB_QConvertingCountKeyPressed

 private void CB_QConvertingReasonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvertingReasonKeyPressed
  PNav.onKey_CB(this, CB_QConvertingReason, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvertingCount)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvertingReasonEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QConvertingReason)));
 }//GEN-LAST:event_CB_QConvertingReasonKeyPressed

 private void CB_QConvertingReasonEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvertingReasonEmptyKeyPressed
  PNav.onKey_CB(this, CB_QConvertingReasonEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvertingReason)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QConvRule)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QConvertingReason)));
 }//GEN-LAST:event_CB_QConvertingReasonEmptyKeyPressed

 private void Btn_QConvertingReasonAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QConvertingReasonAddKeyPressed
  PNav.onKey_Btn(this, Btn_QConvertingReasonAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvertingCount1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QConvertingReasonRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QConvertingReason)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QConvertingReasonAddKeyPressed

 private void Btn_QConvertingReasonRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QConvertingReasonRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QConvertingReasonRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QConvertingReasonAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QConvRuleAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QConvertingReason)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QConvertingReasonRemoveKeyPressed

 private void CB_QConvRuleKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QConvRuleKeyPressed
  PNav.onKey_CB(this, CB_QConvRule, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvertingReasonEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QConvRule)));
 }//GEN-LAST:event_CB_QConvRuleKeyPressed

 private void Btn_QConvRuleAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QConvRuleAddKeyPressed
  PNav.onKey_Btn(this, Btn_QConvRuleAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QConvertingReasonRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QConvRuleRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QConvRule)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QConvRuleAddKeyPressed

 private void Btn_QConvRuleRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QConvRuleRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QConvRuleRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QConvRuleAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QConvRule)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QConvRuleRemoveKeyPressed

 private void CB_QItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemKeyPressed
  PNav.onKey_CB(this, CB_QItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QConvRule)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QItem)));
 }//GEN-LAST:event_CB_QItemKeyPressed

 private void Btn_QItemAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemAddKeyPressed
  PNav.onKey_Btn(this, Btn_QItemAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QConvRuleRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemAddKeyPressed

 private void Btn_QItemRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QItemRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemRemoveKeyPressed

 private void List_QConvertingReasonKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QConvertingReasonKeyReleased
  PNav.onKey_List(this, List_QConvertingReason, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QConvertingCount1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QConvRuleAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvertingReason)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QConvertingReasonAdd)));
 }//GEN-LAST:event_List_QConvertingReasonKeyReleased

 private void Tbl_QConvRuleKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_QConvRuleKeyReleased
  PNav.onKey_Tbl(this, Tbl_QConvRule, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QConvertingReasonAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QConvRule)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QConvRuleAdd)));
 }//GEN-LAST:event_Tbl_QConvRuleKeyReleased

 private void Tbl_QItemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_QItemKeyReleased
  PNav.onKey_Tbl(this, Tbl_QItem, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QConvRuleAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QItemAdd)));
 }//GEN-LAST:event_Tbl_QItemKeyReleased

 private void CB_ItemOutViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutViewCategorizedActionPerformed
  changeConvItemsViewByCategorized(true);
 }//GEN-LAST:event_CB_ItemOutViewCategorizedActionPerformed

 private void CB_ItemInViewCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemInViewCategorizedActionPerformed
  changeConvItemsViewByCategorized(false);
 }//GEN-LAST:event_CB_ItemInViewCategorizedActionPerformed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_ConvertRuleTempListAdd;
 private javax.swing.JButton Btn_ConvertRuleTempListRemove;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FindBef;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_ItemInAdd;
 private javax.swing.JButton Btn_ItemInEdit;
 private javax.swing.JButton Btn_ItemInMove;
 private javax.swing.JButton Btn_ItemInRemove;
 private javax.swing.JButton Btn_ItemOutAdd;
 private javax.swing.JButton Btn_ItemOutEdit;
 private javax.swing.JButton Btn_ItemOutMove;
 private javax.swing.JButton Btn_ItemOutRemove;
 private javax.swing.JButton Btn_New;
 private javax.swing.JButton Btn_QConvRuleAdd;
 private javax.swing.JButton Btn_QConvRuleRemove;
 private javax.swing.JButton Btn_QConvertingReasonAdd;
 private javax.swing.JButton Btn_QConvertingReasonRemove;
 private javax.swing.JButton Btn_QItemAdd;
 private javax.swing.JButton Btn_QItemRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_QueryRefresh;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JButton Btn_Report;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JToggleButton CB_ItemInViewCategorized;
 private javax.swing.JToggleButton CB_ItemOutViewCategorized;
 private javax.swing.JCheckBox CB_QCheck;
 private javax.swing.JCheckBox CB_QConvRule;
 private javax.swing.JCheckBox CB_QConvRuleName;
 private javax.swing.JCheckBox CB_QConvertingCount;
 private javax.swing.JCheckBox CB_QConvertingDate;
 private javax.swing.JCheckBox CB_QConvertingDirection;
 private javax.swing.JCheckBox CB_QConvertingReason;
 private javax.swing.JCheckBox CB_QConvertingReasonEmpty;
 private javax.swing.JCheckBox CB_QItem;
 private javax.swing.JCheckBox CB_QItemId;
 private javax.swing.JCheckBox CB_QItemName;
 private javax.swing.JComboBox<String> CmB_Find;
 private javax.swing.JComboBox<String> CmB_OrderMode;
 private javax.swing.JComboBox<String> CmB_QCheck;
 private javax.swing.JComboBox<String> CmB_QConvertingDateEndD;
 private javax.swing.JComboBox<String> CmB_QConvertingDateEndM;
 private javax.swing.JComboBox<String> CmB_QConvertingDateStartD;
 private javax.swing.JComboBox<String> CmB_QConvertingDateStartM;
 private javax.swing.JComboBox<String> CmB_QItemId;
 private javax.swing.JComboBox<String> CmB_ReportType;
 private javax.swing.JComboBox<String> CmB_ResultFilterSubset;
 private javax.swing.JLabel Lbl_ConvRuleNameHelp;
 private javax.swing.JLabel Lbl_ConvertingCountHelp;
 private javax.swing.JLabel Lbl_QItemIdHelp;
 private javax.swing.JLabel Lbl_QItemNameHelp;
 private XList List_QConvertingReason;
 private XImgBoxURL Pnl_ItemInInfoPreview;
 private XImgBoxURL Pnl_ItemOutInfoPreview;
 private javax.swing.JPanel Pnl_Query;
 private javax.swing.JRadioButton RB_QConvertingDirectionBackward;
 private javax.swing.JRadioButton RB_QConvertingDirectionForward;
 private javax.swing.ButtonGroup RG_QConvertingDirection;
 private javax.swing.JScrollPane SP_TblQConvRule;
 private javax.swing.JTextArea TA_ItemInInfoCategory;
 private javax.swing.JTextArea TA_ItemInInfoName;
 private javax.swing.JTextArea TA_ItemOutInfoCategory;
 private javax.swing.JTextArea TA_ItemOutInfoName;
 private javax.swing.JTextField TF_ConvInfoName;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_ItemInCount;
 private javax.swing.JTextField TF_ItemOutCount;
 private javax.swing.JTextField TF_QConvRuleName;
 private javax.swing.JTextField TF_QConvertingCount1;
 private javax.swing.JTextField TF_QConvertingCount2;
 private javax.swing.JTextField TF_QConvertingDateEndY;
 private javax.swing.JTextField TF_QConvertingDateStartY;
 private javax.swing.JTextField TF_QItemId;
 private javax.swing.JTextField TF_QItemName;
 private javax.swing.JTextField TF_QueryCount;
 private javax.swing.JTextField TF_QueryTempListCount;
 private javax.swing.JTextField TF_TempListQuantity;
 private XTable Tbl_Conv;
 private XTable Tbl_ItemIn;
 private XTable Tbl_ItemOut;
 private XTable Tbl_QConvRule;
 private XTable Tbl_QItem;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane9;
 // End of variables declaration//GEN-END:variables
}