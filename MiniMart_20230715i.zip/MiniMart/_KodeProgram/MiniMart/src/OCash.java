public class OCash {
	double Saldo;

	public OCash(){init(0);}
	public OCash(double Saldo){init(Saldo);}
	
	void init(double Saldo){
		this.Saldo=Saldo;
	}
	
	void add(double Value){Saldo=Saldo+Value;}
	void min(double Value){Saldo=Saldo-Value;}
}