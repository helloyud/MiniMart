public class VDrawTable {

 ODrawTable Value;
 
 public VDrawTable(){}
 public VDrawTable(ODrawTable Value) {this.Value = Value;}
 
}