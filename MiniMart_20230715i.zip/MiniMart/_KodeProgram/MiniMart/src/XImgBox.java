import java.awt.image.BufferedImage;
import javax.swing.JScrollPane;
import java.awt.Dimension;

public abstract class XImgBox extends JScrollPane{
 
 private XImgPanel ImgPanel;

 private double ScaleFactor; // 0 ... 1
 
 public XImgBox(){
  super();
  
  ImgPanel=new XImgPanel();
  setViewportView(ImgPanel);
 }

 // abstract
 protected abstract boolean isImageSourceAvailable();
 protected abstract BufferedImage readImageSource();

 // public
 public double getScaleFactor(){return ScaleFactor;}
 public void setScaleFactor(double SclFactor){ScaleFactor=SclFactor;}
 public void updateImgSizeAndPosition(boolean AutoFit){
  double x, y, w, h;
  double width, height, iwidth, iheight, temp1, temp2;
  OCoordinate crd=null;
  Dimension dmn;
  
  x=0;
  y=0;
  w=0;
  h=0;
  width=getWidth()-4;
  height=getHeight()-4;
  if(ImgPanel.PaintImg && ImgPanel.MemImg!=null){
   iwidth=ImgPanel.MemImg.getWidth();
   iheight=ImgPanel.MemImg.getHeight();
   if(!AutoFit){
    iwidth=iwidth*ScaleFactor;
    iheight=iheight*ScaleFactor;
   }
   crd=PGraphics.calculateCoordinate(width, height, iwidth, iheight, 1, CGraph.Rotate_000Degree, AutoFit, false, null, false, false);
   
   x=crd.OffsetX; if(x<0){x=0;}
   y=crd.OffsetY; if(y<0){y=0;}
   w=crd.Width;
   h=crd.Height;
   if(AutoFit){ScaleFactor=crd.Width/iwidth;}
  }
  
  temp1=width;
  if(w>temp1){temp1=w;}
  temp2=height;
  if(h>temp2){temp2=h;}
  if(ImgPanel.getWidth()!=temp1 || ImgPanel.getHeight()!=temp2){
   dmn=new Dimension();
   dmn.setSize(temp1, temp2);
   ImgPanel.setSize(dmn);
   ImgPanel.setPreferredSize(ImgPanel.getSize());
  }
  if(ImgPanel.PaintImg && ImgPanel.MemImg!=null){ImgPanel.setPaintParameters(x, y, w, h);}
 }
 
 // protected
 protected void updateImageSource(){
  if(isImageSourceAvailable()){
   setImgPanelVar(true, readImageSource());
  }
  else{
   setImgPanelVar(false, null);
  }
 }

 // private
 private void setImgPanelVar(boolean PaintImage, BufferedImage MemImg){
  ImgPanel.PaintImg=PaintImage;
  ImgPanel.MemImg=MemImg;
 }
 
}