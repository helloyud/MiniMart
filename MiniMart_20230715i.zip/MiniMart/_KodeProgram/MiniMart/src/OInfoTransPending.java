public class OInfoTransPending extends OInfoTrans {
 long PendingId;
}