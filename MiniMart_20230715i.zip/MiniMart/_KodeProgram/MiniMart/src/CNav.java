public class CNav {
 
 // Action Key's Return
 public static int StateKey_Pressed   =  1;
 public static int StateKey_Released  =  2;
 public static int StateKey_Typed     =  3;
 public static int StateKey_Universal   =  1;
 
 public static int Ret_Unconsumed  =  0;
 public static int Ret_Consumed    =  1;
 
 // Static Variables
 
  // A - Focus Auto
 public static OActionKeyFocusAuto A_FcsAuto_Up = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto A_FcsAuto_Dw = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto A_FcsAuto_Lf = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto A_FcsAuto_Rg = new OActionKeyFocusAuto();
 
 public static OActionKeyFocusAuto A_FcsAuto_Et = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto A_FcsAuto_SE = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto A_FcsAuto_Sp = new OActionKeyFocusAuto();
 
  // A - Focus Custom
 public static OActionKeyFocusCustom A_FcsCstm_Up = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom A_FcsCstm_Dw = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom A_FcsCstm_Lf = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom A_FcsCstm_Rg = new OActionKeyFocusCustom();
 
 public static OActionKeyFocusCustom A_FcsCstm_Et = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom A_FcsCstm_SE = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom A_FcsCstm_Sp = new OActionKeyFocusCustom();
 
  // A - Focus Ordered
 public static OActionKeyFocusOrdered A_FcsOrdr_Up = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered A_FcsOrdr_Dw = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered A_FcsOrdr_Lf = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered A_FcsOrdr_Rg = new OActionKeyFocusOrdered();
 
 public static OActionKeyFocusOrdered A_FcsOrdr_Et = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered A_FcsOrdr_SE = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered A_FcsOrdr_Sp = new OActionKeyFocusOrdered();
 
  // A - Action Self
 public static OActionKeyActSelf A_ActSelf_Up = new OActionKeyActSelf();
 public static OActionKeyActSelf A_ActSelf_Dw = new OActionKeyActSelf();
 public static OActionKeyActSelf A_ActSelf_Lf = new OActionKeyActSelf();
 public static OActionKeyActSelf A_ActSelf_Rg = new OActionKeyActSelf();
 
 public static OActionKeyActSelf A_ActSelf_Et = new OActionKeyActSelf();
 public static OActionKeyActSelf A_ActSelf_SE = new OActionKeyActSelf();
 public static OActionKeyActSelf A_ActSelf_Sp = new OActionKeyActSelf();
 
  // A - Action Custom
 public static OActionKeyActCustom A_ActCstm_Up = new OActionKeyActCustom();
 public static OActionKeyActCustom A_ActCstm_Dw = new OActionKeyActCustom();
 public static OActionKeyActCustom A_ActCstm_Lf = new OActionKeyActCustom();
 public static OActionKeyActCustom A_ActCstm_Rg = new OActionKeyActCustom();
 
 public static OActionKeyActCustom A_ActCstm_Et = new OActionKeyActCustom();
 public static OActionKeyActCustom A_ActCstm_SE = new OActionKeyActCustom();
 public static OActionKeyActCustom A_ActCstm_Sp = new OActionKeyActCustom();
 
  // B - Focus Auto
 public static OActionKeyFocusAuto B_FcsAuto_Up = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto B_FcsAuto_Dw = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto B_FcsAuto_Lf = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto B_FcsAuto_Rg = new OActionKeyFocusAuto();
 
 public static OActionKeyFocusAuto B_FcsAuto_Et = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto B_FcsAuto_SE = new OActionKeyFocusAuto();
 public static OActionKeyFocusAuto B_FcsAuto_Sp = new OActionKeyFocusAuto();
 
  // B - Focus Custom
 public static OActionKeyFocusCustom B_FcsCstm_Up = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom B_FcsCstm_Dw = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom B_FcsCstm_Lf = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom B_FcsCstm_Rg = new OActionKeyFocusCustom();
 
 public static OActionKeyFocusCustom B_FcsCstm_Et = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom B_FcsCstm_SE = new OActionKeyFocusCustom();
 public static OActionKeyFocusCustom B_FcsCstm_Sp = new OActionKeyFocusCustom();
 
  // B - Focus Ordered
 public static OActionKeyFocusOrdered B_FcsOrdr_Up = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered B_FcsOrdr_Dw = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered B_FcsOrdr_Lf = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered B_FcsOrdr_Rg = new OActionKeyFocusOrdered();
 
 public static OActionKeyFocusOrdered B_FcsOrdr_Et = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered B_FcsOrdr_SE = new OActionKeyFocusOrdered();
 public static OActionKeyFocusOrdered B_FcsOrdr_Sp = new OActionKeyFocusOrdered();
 
  // B - Action Self
 public static OActionKeyActSelf B_ActSelf_Up = new OActionKeyActSelf();
 public static OActionKeyActSelf B_ActSelf_Dw = new OActionKeyActSelf();
 public static OActionKeyActSelf B_ActSelf_Lf = new OActionKeyActSelf();
 public static OActionKeyActSelf B_ActSelf_Rg = new OActionKeyActSelf();
 
 public static OActionKeyActSelf B_ActSelf_Et = new OActionKeyActSelf();
 public static OActionKeyActSelf B_ActSelf_SE = new OActionKeyActSelf();
 public static OActionKeyActSelf B_ActSelf_Sp = new OActionKeyActSelf();
 
  // B - Action Custom
 public static OActionKeyActCustom B_ActCstm_Up = new OActionKeyActCustom();
 public static OActionKeyActCustom B_ActCstm_Dw = new OActionKeyActCustom();
 public static OActionKeyActCustom B_ActCstm_Lf = new OActionKeyActCustom();
 public static OActionKeyActCustom B_ActCstm_Rg = new OActionKeyActCustom();
 
 public static OActionKeyActCustom B_ActCstm_Et = new OActionKeyActCustom();
 public static OActionKeyActCustom B_ActCstm_SE = new OActionKeyActCustom();
 public static OActionKeyActCustom B_ActCstm_Sp = new OActionKeyActCustom();

}