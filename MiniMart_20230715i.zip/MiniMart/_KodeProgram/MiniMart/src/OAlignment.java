public class OAlignment {
 
 public static final int VerticalTop=1;
 public static final int VerticalCenter=2;
 public static final int VerticalBottom=3;
 public static final int HorizontalLeft=4;
 public static final int HorizontalCenter=5;
 public static final int HorizontalRight=6;
 
 int AlignmentHorizontal;
 int AlignmentVertical;

 public OAlignment(int AlignmentHorizontal, int AlignmentVertical) {
  this.AlignmentHorizontal = AlignmentHorizontal;
  this.AlignmentVertical = AlignmentVertical;
 }
 
}
