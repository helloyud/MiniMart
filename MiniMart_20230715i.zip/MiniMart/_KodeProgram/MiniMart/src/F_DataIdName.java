import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;

public class F_DataIdName extends XFormDialog{

 OCustomListModel ListMdl;
 
 // set
 int wMode; // {Required} 0 Normal, 1 Choose
 boolean wAllowMultipleSelection; // {Required}
 boolean wByTableCode; int wTableCode; // {Required}
 boolean wUseCustomTitle; String wCustomTitle; // {Required}
 boolean wMasterDataIsEnable; // {Required}
 
 String wQuery; // {Required}
 String wTable; // {Required}
 String wTableText; // {Required}
 boolean wIdInteger; // {Required}
 boolean wCheckEmpty;
 int wCheckLength;
 int wCheckAll;
 int wCheckFirst;
 int wCheckLast;
 int wCheckOther;
 String wExample;
 int wExportSample;
 
 // get
 long[] DataId;
 String[] DataName;
 
 public F_DataIdName(MInterFormVariables IFV_) {
  int[] ColumnsType;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  ListMdl=new OCustomListModel(false);
  ColumnsType=new int[2];
  ColumnsType[1]=CCore.TypeString;
  ListMdl.setColumnsInfo(ColumnsType, 1);
  List_Data.setModel(ListMdl);
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_Find, Btn_FindBefore, Btn_FindNext,
    List_Data,
    Btn_New, Btn_Edit, Btn_Remove, Btn_Choose),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_NewActionPerformed(null);
    }
   });
  
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_EditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_RemoveActionPerformed(null);
    }
   });
  
  // f4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0, true), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     List_Data.requestFocusInWindow();
    }
   });
  
  // f5
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0, true), "f5");
  act.put("f5", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     TF_Find.requestFocusInWindow();
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_ChooseActionPerformed(null);
    }
   });
 }

 void clearComponents(){
  PGUI.clearText(TF_Find);
  ListMdl.removeAll();
 }
 void initFocus(){
  int datacount=ListMdl.Mdl.Rows.size();
  
  if(datacount!=0){List_Data.setSelectedIndex(0);}
  
  if(datacount<=CApp.InitFocusInTableIfCountLimit){PGUI.requestFocusInWindow(List_Data);}
  else{PGUI.requestFocusInWindow(TF_Find);}
 }
 
 void initVariablesByTableCode(){
  wTable=CApp.getTable(wTableCode);
  wTableText=CApp.getTableText(wTableCode);
  
  wQuery="select Id, Name from "+wTable+" order by Name asc";
  
  switch(wTableCode){
   case CApp.TblStockUnit           : setInputVariables(true, false, 30, 0, 1, 1, 0, "(meter, kg, rol, dos, buah, ...dll)"); break;
   case CApp.TblCategoryOfItem      : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Listrik, Kabel, Lampu, Pulpen, ...dll)"); break;
   case CApp.TblTagOfItem           : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Bergaransi, Pecah Belah, ...dll)"); break;
   case CApp.TblReasonOfRevisi      : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Opname Stok, Rusak, Pemakaian Pribadi, ...dll)"); break;
   case CApp.TblReasonOfConv        : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Pindah Satuan, Buat Parcel Lebaran, ...dll)"); break;
   case CApp.TblCategoryOfSubject   : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Pelanggan, Suplier, Teman, ...dll)"); break;
   case CApp.TblTagOfSubject        : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Beli Grosiran, Kawan Lama, Jual Kue, ...dll)"); break;
   case CApp.TblCity                : setInputVariables(true, false, 100, 0, 1, 1, 0, ""); break;
   case CApp.TblContactType         : setInputVariables(true, false, 100, 0, 1, 1, 0, "(HP, Telp, Email, Facebook, BBM, ...dll)"); break;
   case CApp.TblBankPlatform        : setInputVariables(true, false, 100, 0, 1, 1, 0, "(Bank Mandiri, Bank BRI, Bank BCA, OVO, ...dll)"); break;
   case CApp.TblTransType           : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Penjualan, Pembelian, Retur, ...dll)"); break;
   case CApp.TblCash                : setInputVariables(true, false, 150, 0, 1, 1, 0, "(Laci Kasir, Rekening Bank Danamon, ...dll)"); break;
  }
  
  wExportSample=wTableCode;
  wMasterDataIsEnable=true;
 }
 void setInputVariables(boolean wIdInteger,
  boolean wCheckEmpty, int wCheckLength, int wCheckAll, int wCheckFirst, int wCheckLast, int wCheckOther,
  String wExample){
  this.wIdInteger=wIdInteger;
  this.wCheckEmpty=wCheckEmpty;
  this.wCheckLength=wCheckLength;
  this.wCheckAll=wCheckAll;
  this.wCheckFirst=wCheckFirst;
  this.wCheckLast=wCheckLast;
  this.wCheckOther=wCheckOther;
  this.wExample=wExample;
 }
 
 void find(int FindMode){
  int Selected, FindIndex;
  String FindText=TF_Find.getText();
  if(FindText.length()!=0){
   if(ListMdl.Mdl.Rows.size()!=0){
    Selected=List_Data.getSelectedIndex();
    FindIndex=PGUI.searchInlist(ListMdl, FindText, Selected, FindMode);
    if(FindIndex!=-1){
     if(FindIndex!=Selected){
      List_Data.setSelectedIndex(FindIndex);
      List_Data.ensureIndexIsVisible(FindIndex);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di daftar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Daftar dalam keadaan kosong !");
   }
  }
 }
 void csvImportAdd(){
  F_DataIdNameImportAdd fm;
  Object[] OperationResult;
  
  fm=IFV.FDataIdNameImportAdd;
  fm.wTitle="Impor-Tambah Data "+CApp.getTableText(wExportSample);
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Mengimpor Data "+CApp.getTableText(wExportSample));
  OperationResult=PMyShop.dataIdNameImportAdd(IFV.FSplashScreen, fm.FileCsv, fm.NameByFieldIndex, IFV.Stm, CApp.getTable(wExportSample));
  IFV.FSplashScreen.disappear();
  
  refreshData();
  
  if(OperationResult==null){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengimpor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Berhasil mengimpor data !\n"+
   "Total data yg dibaca = "+PText.intToString((Long)OperationResult[0])+"\n"+
   "Total data yg diimpor = "+PText.intToString((Long)OperationResult[1]));
  */
 }
 void csvExportAll(){
  long OperationResult;
  File DestFile;
  F_CsvWriteOption fm=IFV.FCsvWriteOption;
  String[] Header;
  
  DestFile=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(DestFile==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Mengekspor Data "+CApp.getTableText(wExportSample));
  Header=CApp.getExportColumnsHeader(wExportSample, fm.FieldDelimiter);
  OperationResult=PEtc.csvExport(
   IFV.FSplashScreen,
   IFV.Stm, CApp.getExportQuery(wExportSample, null), CApp.getExportColumnsType(wExportSample), Header, PCore.newIntegerArrayInOrderedSequence(Header.length, 0, 1),
   DestFile, fm.FieldDelimiter, fm.FieldsSeparator, CCore.CsvDefaultRecordsSeparator);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengekspor data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Sukses mengekspor data !\n"+
   "Total data yg diekspor = "+PText.intToString(OperationResult));
  */
 }
 void csvExportSample(){
  long OperationResult;
  File DestFile;
  F_CsvWriteOption fm=IFV.FCsvWriteOption;
  String[] Header;
  
  DestFile=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(DestFile==null){return;}
  
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  IFV.FSplashScreen.appear(this, "Mengekspor Sampel Data "+wTableText);
  Header=CApp.getExportColumnsHeader(wExportSample, fm.FieldDelimiter);
  OperationResult=PEtc.csvExport(
   IFV.FSplashScreen,
   CApp.getExportSample(wExportSample), CApp.getExportColumnsType(wExportSample), Header, PCore.newIntegerArrayInOrderedSequence(Header.length, 0, 1),
   DestFile, fm.FieldDelimiter, fm.FieldsSeparator, CCore.CsvDefaultRecordsSeparator);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses mengekspor sampel data !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null, "Sukses mengekspor sampel data !\n"+
   "Total sampel data yg diekspor = "+PText.intToString(OperationResult));
  */
 }
 void clearData(){
  ListMdl.removeAll();
 }
 int fillData(){
  return PDatabase.queryToList(IFV.Stm, wQuery, ListMdl, false, null, -1, false, -1);
 }
 void refreshData(){
  clearData();
  fillData();
 }
 
 void choose(){
  int[] row=List_Data.getSelectedIndices();
  int temp, temp_;
  temp=row.length;
  if(temp!=0){
   DataId=new long[temp];
   DataName=new String[temp];
   temp_=0;
   do{
    if(wIdInteger==true){DataId[temp_]=((Integer)ListMdl.Mdl.Rows.elementAt(row[temp_])[0]).longValue();}
    else{DataId[temp_]=(Long)ListMdl.Mdl.Rows.elementAt(row[temp_])[0];}
    DataName[temp_]=ListMdl.getElementAt(row[temp_]);
    temp_=temp_+1;
   }while(temp_!=temp);
   clearComponents();
   DialogResult=1;
   Activ=false;
   setVisible(false);
  }
 }
 
 void importExport(){
  IFV.FCsvImportExport.setEnableImport(true, false);
  IFV.FCsvImportExport.wImportOption=1;
  IFV.FCsvImportExport.setEnableExport(true, false, true);
  IFV.FCsvImportExport.wExportOption=1;
  IFV.FCsvImportExport.wIsImport=true;
  
  if(IFV.FCsvImportExport.showForm()==false){return;}
  if(IFV.FCsvImportExport.DialogResult!=1){return;}
  
  if(IFV.FCsvImportExport.IsImport){
   switch(IFV.FCsvImportExport.ImportOption){
    case 1 : csvImportAdd(); break;
   }
   return;
  }
  else{
   switch(IFV.FCsvImportExport.ExportOption){
    case 1 : csvExportAll(); break;
    case 3 : csvExportSample(); break;
   }
   return;
  }
 }
 
 void edit(){
  int[] Rows;
  int result;
  boolean FetchDataOld;
  Object[] UpdateData;
  OInfoIdName InfoIdName;
  OEditIdName Edit;
  OFormInformProgress Progress;
  F_EditName fm1=IFV.FEditName;
  F_IdNameModifyMulti fm2=IFV.FIdNameModifyMulti;
  
  if(!PGUI.isEnabled(Btn_Edit)){return;}
  
  Rows=List_Data.getSelectedIndices(); if(Rows.length==0){return;}
  Edit=new OEditIdName();
  if(Rows.length==1){
   UpdateData=ListMdl.Mdl.Rows.elementAt(Rows[0]);
   fm1.wTitle="Ubah nilai "+wTableText;
   fm1.wCurrValue=PCore.objString(UpdateData[1], null);
   fm1.wCheckEmpty=wCheckEmpty;
   fm1.wCheckLength=wCheckLength;
   fm1.wCheckAll=wCheckAll;
   fm1.wCheckFirst=wCheckFirst;
   fm1.wCheckLast=wCheckLast;
   fm1.wCheckOther=wCheckOther;
   
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}
   
   FetchDataOld=true;
   InfoIdName=new OInfoIdName(wIdInteger, PCore.getValueIntLong(UpdateData[0], wIdInteger, -1), PCore.objString(UpdateData[1], null));
   Edit.init(true, false, null, fm1.UpdateValue);
   Progress=null;
  }
  else{
   fm2.wDataCount=Rows.length;
   
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   FetchDataOld=false;
   InfoIdName=null;
   Edit.init(true, true, fm2.NameFind, fm2.NameReplace);
   Progress=IFV.FSplashScreen;
  }
  
  result=edit(Rows, FetchDataOld, InfoIdName, Edit, Progress);
  if(result==-1){JOptionPane.showMessageDialog(null,
   "Terjadi error ketika melakukan operasi, mungkin dikarenakan :"+
   "\n- Nama sudah ada."+
   "\n- Nama melebihi batasan panjang kata yang diperbolehkan.");}
  else if(result==-2){JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : Nama sudah ada !");}
 }
 int edit(int[] Rows, boolean FetchDataOld, OInfoIdName DataOld, OEditIdName Edit, OFormInformProgress Progress){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Name has already exist
  int insertrow, idx, temp, count;
  
  Vector<OTableCellUpdater> Updater;
  OTableCellUpdater CellUpdater=null;
  
  long[] Ids;
  Object[] objs;
  String Name;
  
  Vector<Object[]> Edited_Data;
  
  int increase_n_times=0;
  long increase_every_n_records=0;
  double increase_size=0;
  
  if(Progress!=null){Progress.appear(this, "Mengubah Data");}
  if(Progress!=null){Progress.inform(0, "Harap menunggu ...", null);}
  do{
   // pre-processing
   count=Rows.length;
   
   Updater=new Vector();
   
   if(Edit.EditName){
    if(!Edit.ReplaceSubName){
     CellUpdater=new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedName, null, true));
    }
    else{
     CellUpdater=new OTableCellUpdaterBySubString(1, true, Edit.SubName, Edit.EditedName);
    }
    Updater.addElement(CellUpdater);
   }
   
   // process : update in database
   if(Progress!=null){Progress.setProgressIncreasePercentage(65);}
   
   Ids=ListMdl.getIds(0, Rows);
   if(!PDatabase.editRecordsIdName(IFV.Stm, wTable, Ids, Edit, Progress)){break;}
   
   if(Progress!=null){Progress.setProgressIncreasePercentage(100);}
   
   // process : update GUI
   if(Progress!=null){
    increase_n_times=10;
    increase_every_n_records=count/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=count;}
    increase_size=(100-Progress.getProgress())/increase_n_times;
   }
   
   PGUI.changeElements(ListMdl, Rows, Updater);
   
   Edited_Data=PTable.subData(ListMdl.getRows(), Rows, PCore.newIntegerArrayInOrderedSequence(ListMdl.getColumnsCount(), 0, 1));
   
   ListMdl.remove(Rows);
   
   temp=0;
   do{
    objs=Edited_Data.elementAt(temp);
    Name=PCore.objString(objs[1], null);
    
    insertrow=PGUI.findInsertPos(ListMdl, 1, Name, false, true, true);
    ListMdl.insert(insertrow, objs);
    
    temp=temp+1;
    if(Progress!=null){
     if(temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
    }
   }while(temp!=count);
   
   idx=insertrow;
   List_Data.setSelectedIndex(idx); List_Data.ensureIndexIsVisible(idx);
   
   //
   ret=0;
  }while(false);
  if(Progress!=null){Progress.disappear();}
  
  return ret;
 }
 
 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  Lbl_ListOf = new javax.swing.JLabel();
  Btn_Edit = new javax.swing.JButton();
  Btn_New = new javax.swing.JButton();
  Btn_Remove = new javax.swing.JButton();
  TF_Find = new javax.swing.JTextField();
  jLabel1 = new javax.swing.JLabel();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBefore = new javax.swing.JButton();
  Btn_Choose = new javax.swing.JButton();
  Lbl_MultipleSelection = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  List_Data = new XList();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Lbl_ListOf.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  Lbl_ListOf.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  Lbl_ListOf.setText("Daftar");
  Lbl_ListOf.setRequestFocusEnabled(false);

  Btn_Edit.setText("Ubah {F2}");
  Btn_Edit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Edit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_EditActionPerformed(evt);
   }
  });
  Btn_Edit.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_EditKeyPressed(evt);
   }
  });

  Btn_New.setText("Buat Baru {F1}");
  Btn_New.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_New.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_NewActionPerformed(evt);
   }
  });
  Btn_New.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_NewKeyPressed(evt);
   }
  });

  Btn_Remove.setText("Hapus {F3}");
  Btn_Remove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Remove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_RemoveActionPerformed(evt);
   }
  });
  Btn_Remove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_RemoveKeyPressed(evt);
   }
  });

  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  jLabel1.setText("{F5}");
  jLabel1.setRequestFocusEnabled(false);

  Btn_FindNext.setText(">");
  Btn_FindNext.setFocusTraversalPolicyProvider(true);
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });
  Btn_FindNext.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FindNextKeyPressed(evt);
   }
  });

  Btn_FindBefore.setText("<");
  Btn_FindBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBeforeActionPerformed(evt);
   }
  });
  Btn_FindBefore.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_FindBeforeKeyPressed(evt);
   }
  });

  Btn_Choose.setText("Choose {F11}");
  Btn_Choose.setToolTipText("");
  Btn_Choose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Choose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseActionPerformed(evt);
   }
  });
  Btn_Choose.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseKeyPressed(evt);
   }
  });

  Lbl_MultipleSelection.setText("{Boleh > 1}");

  List_Data.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    List_DataKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_DataKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(List_Data);

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane1)
     .addComponent(Lbl_ListOf, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addGroup(layout.createSequentialGroup()
      .addComponent(jLabel1)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_Find)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_FindBefore)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_FindNext))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(Btn_New)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Edit)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Remove)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
      .addComponent(Lbl_MultipleSelection)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Choose)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(Lbl_ListOf)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(jLabel1)
     .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_FindNext)
     .addComponent(Btn_FindBefore))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Remove)
     .addComponent(Btn_Edit)
     .addComponent(Btn_New)
     .addComponent(Btn_Choose)
     .addComponent(Lbl_MultipleSelection))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_NewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_NewActionPerformed
  int temp, insertrow;
  Object[] UpdateData;
  String Name;
  
  if(!PGUI.isEnabled(Btn_New)){return;}
  
  IFV.FInputName.wTitle="Tambah "+wTableText;
  IFV.FInputName.wText="Nama "+wTableText+" yg baru "+wExample+" :";
  IFV.FInputName.wInput="";
  IFV.FInputName.wCheckEmpty=wCheckEmpty;
  IFV.FInputName.wCheckLength=wCheckLength;
  IFV.FInputName.wCheckAll=wCheckAll;
  IFV.FInputName.wCheckFirst=wCheckFirst;
  IFV.FInputName.wCheckLast=wCheckLast;
  IFV.FInputName.wCheckOther=wCheckOther;
  
  if(IFV.FInputName.showForm()==false){return;}
  if(IFV.FInputName.DialogResult==1){
   Name=IFV.FInputName.Input;
   temp=PDatabase.addARecordIdName(IFV.Stm, wTable, Name, wIdInteger, IFV.Params);
   if(temp==0){
    UpdateData=new Object[2];
    UpdateData[0]=IFV.Params.Param[0];
    UpdateData[1]=Name;
    insertrow=PGUI.findInsertPos(ListMdl, 1, Name, false, true, true);
    ListMdl.insert(insertrow, UpdateData); List_Data.setSelectedIndex(insertrow); List_Data.ensureIndexIsVisible(insertrow);
   }
   else if(temp==1){
    JOptionPane.showMessageDialog(null, "Gagal menambah : "+wTableText+" sudah ada !");
   }
   else if(temp==-1){
    JOptionPane.showMessageDialog(null, "Gagal menambah : terjadi kesalahan ketika melakukan operasi !");
   }
  }
 }//GEN-LAST:event_Btn_NewActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean IsChooseMode=wMode==1;
  
  if(Activ==false){
   Activ=true;
   
   if(wByTableCode){initVariablesByTableCode();}
   
   setTitle(PText.getString(!IsChooseMode, wTableText.toUpperCase(), PText.getString(!wUseCustomTitle, "Pilih "+wTableText.toUpperCase(), wCustomTitle)));
   Lbl_ListOf.setText("Daftar "+wTableText+" {F4}");
   TF_Find.setText("");
   
   ListMdl.Mdl.ColumnsType[0]=PCore.subtBool_Int(wIdInteger, CCore.TypeInteger, CCore.TypeLong);
   List_Data.setSelectionMode(PCore.subtBool_Int(IsChooseMode && !wAllowMultipleSelection, ListSelectionModel.SINGLE_SELECTION, ListSelectionModel.MULTIPLE_INTERVAL_SELECTION));
   
   Btn_New.setVisible(wMasterDataIsEnable);
   Btn_Edit.setVisible(wMasterDataIsEnable);
   Btn_Remove.setVisible(wMasterDataIsEnable);
   Btn_Choose.setVisible(IsChooseMode || wMasterDataIsEnable);
   
   Lbl_MultipleSelection.setVisible(IsChooseMode && wAllowMultipleSelection);
   Btn_Choose.setText(PText.getString(!IsChooseMode, "Impor-Ekspor {F11}", "Pilih {F11}"));
   
   if(fillData()==-1){JOptionPane.showMessageDialog(null, "Gagal mengambil data dari database !");}
   
   initFocus();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  clearComponents();
  DialogResult=0;
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Btn_EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_EditActionPerformed
  edit();
 }//GEN-LAST:event_Btn_EditActionPerformed

 private void Btn_RemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_RemoveActionPerformed
  int[] rows;
  int temp, removcount;
  long id;
  boolean[] IsRemove;
  double progress_inc;
  
  if(!PGUI.isEnabled(Btn_Remove)){return;}
  
  rows=List_Data.getSelectedIndices();
  
  if(rows.length!=0){
   if(JOptionPane.showConfirmDialog(null, "Hapus "+PText.intToString(rows.length)+" data pada daftar ?",
    "Konfirmasi Penghapusan", JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
    
    IFV.FSplashScreen.appear(this, "Menghapus Data "+wTableText);
    
    IFV.FSplashScreen.inform(0, "Menghapus "+PText.intToString(rows.length)+" data, harap menunggu ...", "-");
    
    IsRemove=PCore.newBooleanArray(rows.length, false);
    removcount=0;
    temp=0;
    progress_inc=(double)100/(double)rows.length;
    do{
     // IFV.FSplashScreen.inform(0, null, "Menghapus data ke-"+PText.intToString(temp+1));
     
     if(wIdInteger==true){
      id=(Integer)ListMdl.Mdl.Rows.elementAt(rows[temp])[0];
     }
     else{
      id=(Long)ListMdl.Mdl.Rows.elementAt(rows[temp])[0];
     }
     if(PDatabase.removeARecord(IFV.Stm, wTable, id)==true){
      removcount=removcount+1;
      IsRemove[temp]=true;
     }
     temp=temp+1;
     
     IFV.FSplashScreen.inform(progress_inc, null, null);
    }while(temp!=rows.length);
    
    IFV.FSplashScreen.disappear();
    
    if(removcount!=0){
     ListMdl.remove(rows, IsRemove);
    }
    if(removcount!=rows.length){
     JOptionPane.showMessageDialog(null, "Gagal menghapus "+(rows.length-removcount)+" data !");
    }
   }
  }
 }//GEN-LAST:event_Btn_RemoveActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  find(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Data)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void Btn_FindBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBeforeActionPerformed
  find(2);
 }//GEN-LAST:event_Btn_FindBeforeActionPerformed

 private void Btn_ChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseActionPerformed
  boolean IsChooseMode=wMode==1;
  
  if(!PGUI.isEnabled(Btn_Choose)){return;}
  
  if(!IsChooseMode){importExport();}
  else{choose();}
 }//GEN-LAST:event_Btn_ChooseActionPerformed

 private void List_DataKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_DataKeyPressed
  boolean IsChooseMode=wMode==1;
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER :
   if(IsChooseMode){
    if(List_Data.getSelectedIndices().length!=0){evt.consume(); Btn_ChooseActionPerformed(null);}
   }
   break;
  }
 }//GEN-LAST:event_List_DataKeyPressed

 private void Btn_FindBeforeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FindBeforeKeyPressed
  PNav.onKey_Btn(this, Btn_FindBefore, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Data)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Find)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindNext)));
 }//GEN-LAST:event_Btn_FindBeforeKeyPressed

 private void Btn_FindNextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_FindNextKeyPressed
  PNav.onKey_Btn(this, Btn_FindNext, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(List_Data)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_FindBefore)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_FindNextKeyPressed

 private void List_DataKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_DataKeyReleased
  PNav.onKey_List(this, List_Data, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_New, Btn_Choose)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_List_DataKeyReleased

 private void Btn_NewKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_NewKeyPressed
  PNav.onKey_Btn(this, Btn_New, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Data)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Edit)));
 }//GEN-LAST:event_Btn_NewKeyPressed

 private void Btn_EditKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_EditKeyPressed
  PNav.onKey_Btn(this, Btn_Edit, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Data)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_New)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Remove)));
 }//GEN-LAST:event_Btn_EditKeyPressed

 private void Btn_RemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_RemoveKeyPressed
  PNav.onKey_Btn(this, Btn_Remove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Data)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Edit)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Choose)));
 }//GEN-LAST:event_Btn_RemoveKeyPressed

 private void Btn_ChooseKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseKeyPressed
  PNav.onKey_Btn(this, Btn_Choose, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(List_Data)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Remove)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseKeyPressed

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Choose;
 private javax.swing.JButton Btn_Edit;
 private javax.swing.JButton Btn_FindBefore;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_New;
 private javax.swing.JButton Btn_Remove;
 private javax.swing.JLabel Lbl_ListOf;
 private javax.swing.JLabel Lbl_MultipleSelection;
 private XList List_Data;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
