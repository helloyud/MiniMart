import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import javax.swing.JFrame;
import javax.swing.JDialog;
import java.awt.Point;
import java.awt.Window;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.swing.JOptionPane;

class PEtc{
 
 static OGregorianCalendar cal=new OGregorianCalendar();

 public static void getConfiguration(File Conf, OConfiguration Config){
  FileInputStream fis=null;
  BufferedInputStream bis=null;
  StringBuilder buf;
  int lastread;
  boolean loop;
  
  // user
  String str, param;
  int temp;
  int param1, value1, value2;
  URL dir;
  PrintService[] Printers=PrintServiceLookup.lookupPrintServices(null, null);
  OPaper opapr;
  
  int v_int;
  double v_dbl;
  boolean v_bool;
  boolean process;
  
  do{
   try{
    // check parameters
    if(Conf.exists()==false){break;}
    if(Conf.isFile()==false){break;}
    // read from file
    fis=new FileInputStream(Conf);
    bis=new BufferedInputStream(fis, 8192);
    do{
     // find first char that is non enter char
     do{
      lastread=bis.read();
     }while(lastread=='\n' || lastread=='\r');
     if(lastread!=-1){
      buf=new StringBuilder();
      buf.append((char)lastread);
      // read until get enter char or end of file
      loop=true;
      do{
       lastread=bis.read();
       if(lastread!='\n' && lastread!='\r' && lastread!=-1){
        buf.append((char)lastread);
       }
       else{loop=false;}
      }while(loop==true);
      // parse parameter
      do{
       str=buf.toString();
       temp=PText.findIndexChar(str, '=', 0, str.length()-1);
       if(temp<=0 || temp==str.length()-1){break;}
       param1=PText.findIndexNotChar(str, ' ', true, 0, temp-1);
       if(param1==-1){break;}
       value1=PText.findIndexNotChar(str, ' ', true, temp+1, str.length()-1);
       if(value1==-1){break;}
       value2=PText.findIndexNotChar(str, ' ', false, value1, str.length()-1);
       if(value1==value2 || str.charAt(value1)!='\"' || str.charAt(value2)!='\"'){break;}
       param=PText.subString(str, param1, PText.findIndexNotChar(str, ' ', false, param1, temp-1));
       do{
        if(PText.compare(param, "ALAMAT_IP_MYSQL", false)==true){
         if(!Config.HostDefined){
          if(value1!=value2-1){
           Config.Host=PText.subString(str, value1+1, value2-1);
           Config.HostDefined=true;
          }
         }
         break;
        }
        if(PText.compare(param, "PORT_MYSQL", false)==true){
         if(!Config.PortDefined){
          if(value1!=value2-1){
           v_int=-1;
           try{v_int=Integer.parseInt(PText.subString(str, value1+1, value2-1));}catch(Exception E_){v_int=-1;}
           if(v_int>=0){
            Config.Port=v_int;
            Config.PortDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "USERNAME_MYSQL", false)==true){
         if(!Config.UserDefined){
          if(value1!=value2-1){
           Config.User=PText.subString(str, value1+1, value2-1);
           Config.UserDefined=true;
          }
         }
         break;
        }
        if(PText.compare(param, "PASSWORD_MYSQL", false)==true){
         if(!Config.PasswordDefined){
          if(value1!=value2-1){Config.Password=PText.subString(str, value1+1, value2-1);}
          else{Config.Password="";}
          Config.PasswordDefined=true;
         }
         break;
        }
        if(PText.compare(param, "DATABASE_AWAL", false)==true){
         if(!Config.DefaultDatabaseDefined){
          if(value1!=value2-1){
           Config.DefaultDatabase=PText.subString(str, value1+1, value2-1);
           Config.DefaultDatabaseDefined=true;
          }
         }
         break;
        }
        if(PText.compare(param, "URL_DIREKTORI_GAMBAR_BARANG", false)==true){
         if(!Config.ImageDirItemDefined){
          // define a directory of images
          if(value1!=value2-1){
           dir=null;
           try{dir=new URL(PText.subString(str, value1+1, value2-1));}catch(Exception E_){}
           if(dir!=null){
            Config.ImageDirItem=PFile.toDirectory(dir.toString(), '/');
            Config.ImageDirItemDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "URL_DIREKTORI_GAMBAR_SUBJEK", false)==true){
         if(!Config.ImageDirSubjectDefined){
          // define a directory of images
          if(value1!=value2-1){
           dir=null;
           try{dir=new URL(PText.subString(str, value1+1, value2-1));}catch(Exception E_){}
           if(dir!=null){
            Config.ImageDirSubject=PFile.toDirectory(dir.toString(), '/');
            Config.ImageDirSubjectDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "JUDUL_APLIKASI", false)==true){
         if(!Config.ApplicationTitleDefined){
          if(value1!=value2-1){
           Config.ApplicationTitle=PText.subString(str, value1+1, value2-1);
           Config.ApplicationTitleDefined=true;
          }
         }
         break;
        }
        if(PText.compare(param, "KATEGORIKAN_BARANG", false)==true){
         if(!Config.ItemCategorizedDefined){
          if(value1!=value2-1){
           str=PText.subString(str, value1+1, value2-1);
           process=true; v_bool=Config.ItemCategorized;
           do{
            if(PText.compare(str, "TIDAK", false)){v_bool=false; break;}
            if(PText.compare(str, "YA", false)){v_bool=true; break;}
            process=false;
           }while(false);
           if(process){
            Config.ItemCategorized=v_bool;
            Config.ItemCategorizedDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_LAPORAN", false)==true){
         if(!Config.DefaultReportPaperDefined){
          if(value1!=value2-1){
           opapr=null;
           str=PText.subString(str, value1+1, value2-1);
           do{
            if(PText.compare(str, "A4", false)){opapr=CPrint.A4; break;}
            if(PText.compare(str, "A5", false)){opapr=CPrint.A5; break;}
           }while(false);
           if(opapr!=null){
            Config.DefaultReportPaper=opapr;
            Config.DefaultReportPaperDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "PRINTER_LAPORAN", false)==true){
         if(!Config.DefaultReportPrinterDefined){
          if(value1!=value2-1){
           v_int=PPrint.findIndex(Printers, PText.subString(str, value1+1, value2-1));
           if(v_int!=-1){
            Config.DefaultReportPrinter=Printers[v_int];
            Config.DefaultReportPrinterDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_NOTA", false)==true){
         if(!Config.DefaultReceiptPaperDefined){
          if(value1!=value2-1){
           opapr=null;
           str=PText.subString(str, value1+1, value2-1);
           do{
            if(PText.compare(str, "A5", false)){opapr=CPrint.A5; break;}
            if(PText.compare(str, "A6", false)){opapr=CPrint.A6; break;}
            
            if(PText.compare(str, "THERMAL57", false)){opapr=CPrint.Thermal57; break;}
            
            if(PText.compare(str, "THERMAL60", false)){opapr=CPrint.Thermal60; break;}
            if(PText.compare(str, "THERMAL62", false)){opapr=CPrint.Thermal62; break;}
            if(PText.compare(str, "THERMAL65", false)){opapr=CPrint.Thermal65; break;}
            if(PText.compare(str, "THERMAL67", false)){opapr=CPrint.Thermal67; break;}
            
            if(PText.compare(str, "THERMAL70", false)){opapr=CPrint.Thermal70; break;}
            if(PText.compare(str, "THERMAL72", false)){opapr=CPrint.Thermal72; break;}
            if(PText.compare(str, "THERMAL75", false)){opapr=CPrint.Thermal75; break;}
            if(PText.compare(str, "THERMAL77", false)){opapr=CPrint.Thermal77; break;}
            
            if(PText.compare(str, "THERMAL80", false)){opapr=CPrint.Thermal80; break;}
            
            if(PText.compare(str, "THERMAL100", false)){opapr=CPrint.Thermal100; break;}
            if(PText.compare(str, "THERMAL102", false)){opapr=CPrint.Thermal102; break;}
            if(PText.compare(str, "THERMAL105", false)){opapr=CPrint.Thermal105; break;}
            if(PText.compare(str, "THERMAL107", false)){opapr=CPrint.Thermal107; break;}
            
            if(PText.compare(str, "THERMAL110", false)){opapr=CPrint.Thermal110; break;}
            if(PText.compare(str, "THERMAL112", false)){opapr=CPrint.Thermal112; break;}
            if(PText.compare(str, "THERMAL115", false)){opapr=CPrint.Thermal115; break;}
            if(PText.compare(str, "THERMAL117", false)){opapr=CPrint.Thermal117; break;}
            
            if(PText.compare(str, "THERMAL120", false)){opapr=CPrint.Thermal120; break;}
           }while(false);
           if(opapr!=null){
            Config.DefaultReceiptPaper=opapr;
            Config.DefaultReceiptPaperDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "PRINTER_NOTA", false)==true){
         if(!Config.DefaultReceiptPrinterDefined){
          if(value1!=value2-1){
           v_int=PPrint.findIndex(Printers, PText.subString(str, value1+1, value2-1));
           if(v_int!=-1){
            Config.DefaultReceiptPrinter=Printers[v_int];
            Config.DefaultReceiptPrinterDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_STANDAR_MARGIN_MINIMAL_ATAS", false)==true){
         if(!Config.StandardPaperMarginTopDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.StandardPaperMarginTopMin && v_dbl<=CPrint.StandardPaperMarginTopMax){
            if(Config.StandardPaperMargin==null){Config.StandardPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.StandardPaperMargin.Top=v_dbl;
            Config.StandardPaperMarginTopDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_STANDAR_MARGIN_MINIMAL_KIRI", false)==true){
         if(!Config.StandardPaperMarginLeftDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.StandardPaperMarginLeftMin && v_dbl<=CPrint.StandardPaperMarginLeftMax){
            if(Config.StandardPaperMargin==null){Config.StandardPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.StandardPaperMargin.Left=v_dbl;
            Config.StandardPaperMarginLeftDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_STANDAR_MARGIN_MINIMAL_KANAN", false)==true){
         if(!Config.StandardPaperMarginRightDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.StandardPaperMarginRightMin && v_dbl<=CPrint.StandardPaperMarginRightMax){
            if(Config.StandardPaperMargin==null){Config.StandardPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.StandardPaperMargin.Right=v_dbl;
            Config.StandardPaperMarginRightDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_STANDAR_MARGIN_MINIMAL_BAWAH", false)==true){
         if(!Config.StandardPaperMarginBottomDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.StandardPaperMarginBottomMin && v_dbl<=CPrint.StandardPaperMarginBottomMax){
            if(Config.StandardPaperMargin==null){Config.StandardPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.StandardPaperMargin.Bottom=v_dbl;
            Config.StandardPaperMarginBottomDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_THERMAL_MARGIN_MINIMAL_ATAS", false)==true){
         if(!Config.ThermalPaperMarginTopDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.ThermalPaperMarginTopMin && v_dbl<=CPrint.ThermalPaperMarginTopMax){
            if(Config.ThermalPaperMargin==null){Config.ThermalPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.ThermalPaperMargin.Top=v_dbl;
            Config.ThermalPaperMarginTopDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_THERMAL_MARGIN_MINIMAL_KIRI", false)==true){
         if(!Config.ThermalPaperMarginLeftDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.ThermalPaperMarginLeftMin && v_dbl<=CPrint.ThermalPaperMarginLeftMax){
            if(Config.ThermalPaperMargin==null){Config.ThermalPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.ThermalPaperMargin.Left=v_dbl;
            Config.ThermalPaperMarginLeftDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_THERMAL_MARGIN_MINIMAL_KANAN", false)==true){
         if(!Config.ThermalPaperMarginRightDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.ThermalPaperMarginRightMin && v_dbl<=CPrint.ThermalPaperMarginRightMax){
            if(Config.ThermalPaperMargin==null){Config.ThermalPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.ThermalPaperMargin.Right=v_dbl;
            Config.ThermalPaperMarginRightDefined=true;
           }
          }
         }
         break;
        }
        if(PText.compare(param, "KERTAS_THERMAL_MARGIN_MINIMAL_BAWAH", false)==true){
         if(!Config.ThermalPaperMarginBottomDefined){
          if(value1!=value2-1){
           v_dbl=-1;
           try{v_dbl=OUnit.mm_to_pixel(Double.parseDouble(PText.subString(str, value1+1, value2-1)));}catch(Exception E_){v_dbl=-1;}
           if(v_dbl>=CPrint.ThermalPaperMarginBottomMin && v_dbl<=CPrint.ThermalPaperMarginBottomMax){
            if(Config.ThermalPaperMargin==null){Config.ThermalPaperMargin=new OPaperMargin(0, 0, 0, 0);}
            Config.ThermalPaperMargin.Bottom=v_dbl;
            Config.ThermalPaperMarginBottomDefined=true;
           }
          }
         }
         break;
        }
       }while(false);
      }while(false);
     }
    }while(lastread!=-1);
   }
   catch(Exception E_){}
  }while(false);
  // close
  if(bis!=null){try{bis.close();}catch(Exception E_){}}
  if(fis!=null){try{fis.close();}catch(Exception E_){}}
 }

 public static boolean saveIdToFile(long[] Id, File ToFile, boolean IsInteger,
  OFormInformProgress Progress, boolean InitProgress, Window InitProgress_FormBef, String InitProgress_Title){
  boolean ret=false;
  FileOutputStream fos=null;
  DataOutputStream dos=null;
  BufferedOutputStream bos=null;
  int count, temp;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  if(Progress!=null && InitProgress){Progress.appear(InitProgress_FormBef, InitProgress_Title);}
  
  do{
   try{
    //
    if(Progress!=null){Progress.inform(0, "Mempersiapkan penulisan ke file ...", "-");}
    
     // check if exists
    if(ToFile.exists()){
     if(!ToFile.isFile()){break;}
     if(!ToFile.delete()){break;}
    }
    
    fos=new FileOutputStream(ToFile);
    bos=new BufferedOutputStream(fos, 8192);
    dos=new DataOutputStream(bos);
    
    if(Progress!=null){Progress.inform(10, null, null);}
    
    //
    if(Progress!=null){Progress.inform(0, "Menulis ke file ...", "-");}
    
    count=Id.length;
    if(Progress!=null){
     increase_size=90;
     
     if(count!=0){
      increase_n_times=10;
      increase_every_n_records=count/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=count;}
      increase_size=increase_size/increase_n_times;
     }
    }
    
    dos.writeInt(count);
    
     // write data
    if(count==0){
     if(Progress!=null){Progress.inform(increase_size, null, null);}
    }
    else{
     temp=0;
     do{
      if(IsInteger){dos.writeInt((int)Id[temp]);}
      else{dos.writeLong(Id[temp]);}
      
      temp=temp+1;
      if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     }while(temp!=count);
    }
    
    dos.flush();
   }
   catch(Exception E_){break;}
   ret=true;
  }while(false);
  if(dos!=null){try{dos.close();}catch(Exception E_){}}
  if(bos!=null){try{bos.close();}catch(Exception E_){}}
  if(fos!=null){try{fos.close();}catch(Exception E_){}}
  
  if(Progress!=null && InitProgress){Progress.disappear();}
  
  return ret;
 }
 public static long[] loadIdFromFile(File FromFile, boolean IsInteger,
  OFormInformProgress Progress, boolean InitProgress, Window InitProgress_FormBef, String InitProgress_Title){
  long[] ret=null;
  long[] id=null;
  FileInputStream fis=null;
  DataInputStream dis=null;
  BufferedInputStream bis=null;
  int count, temp;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  if(Progress!=null && InitProgress){Progress.appear(InitProgress_FormBef, InitProgress_Title);}
  
  do{
   try{
    //
    if(Progress!=null){Progress.inform(0, "Mempersiapkan pembacaan dari file ...", "-");}
    
    if(!FromFile.isFile()){break;}
    
    fis=new FileInputStream(FromFile);
    bis=new BufferedInputStream(fis, 8192);
    dis=new DataInputStream(bis);
    
    if(Progress!=null){Progress.inform(10, null, null);}
    
    //
    if(Progress!=null){Progress.inform(0, "Membaca dari file ...", "-");}
    
    count=dis.readInt();
    if(Progress!=null){
     increase_size=90;
     
     if(count!=0){
      increase_n_times=10;
      increase_every_n_records=count/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=count;}
      increase_size=increase_size/increase_n_times;
     }
    }
    
    id=new long[count];
    
     // read data
    if(count==0){
     if(Progress!=null){Progress.inform(increase_size, null, null);}
    }
    else{
     temp=0;
     do{
      if(IsInteger){id[temp]=dis.readInt();}
      else{id[temp]=dis.readLong();}
      
      temp=temp+1;
      if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     }while(temp!=count);
    }
   }
   catch(Exception E_){break;}
   ret=id;
  }while(false);
  if(dis!=null){try{dis.close();}catch(Exception E_){}}
  if(bis!=null){try{bis.close();}catch(Exception E_){}}
  if(fis!=null){try{fis.close();}catch(Exception E_){}}
  
  if(Progress!=null && InitProgress){Progress.disappear();}
  
  return ret;
 }

 public static boolean saveModelToFile(OCustomModel FromModel, int[] CustomColumns, File ToFile,
  OFormInformProgress Progress, boolean InitProgress, Window InitProgress_FormBef, String InitProgress_Title){
  // save format : columns_count, columns_type..., rows_count, rows_data...
  boolean ret=false;
  FileOutputStream fos=null;
  DataOutputStream dos=null;
  BufferedOutputStream bos=null;
  int temp, temp2;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  int ColumnsCount;
  int[] ColumnsType, typetemp;
  Vector<Object[]> Rows;
  int RowsCount;
		
		Object Obj;
  
  if(Progress!=null && InitProgress){Progress.appear(InitProgress_FormBef, InitProgress_Title);}
          
  do{
   try{
    // check
    if(Progress!=null){Progress.inform(0, "Mempersiapkan penulisan ke file ...", "-");}
    
     // check columns type
    typetemp=FromModel.getColumnsType();
    ColumnsType=new int[CustomColumns.length];
    temp=0;
    do{
     ColumnsType[temp]=typetemp[CustomColumns[temp]];
     temp=temp+1;
    }while(temp!=CustomColumns.length);
    if(!canConvertColumnsTypeToAType(ColumnsType)){break;}
    
     // check if file exists
    if(ToFile.exists()){
     if(!ToFile.isFile()){break;}
     if(!ToFile.delete()){break;}
    }
    
    fos=new FileOutputStream(ToFile);
    bos=new BufferedOutputStream(fos, 8192);
    dos=new DataOutputStream(bos);
    
    if(Progress!=null){Progress.inform(5, null, null);}
    
    // write
    if(Progress!=null){Progress.inform(0, "Menulis ke file ...", "-");}
    
     // write columns identity (columns count & columns type)
    ColumnsCount=ColumnsType.length;
    dos.writeInt(ColumnsCount);
    temp=0;
    do{
     dos.writeInt(ColumnsType[temp]);
     temp=temp+1;
    }while(temp!=ColumnsCount);
    
     // write rows identity
    Rows=FromModel.getRows();
    RowsCount=Rows.size();
    if(Progress!=null){
     increase_size=95;
     
     if(RowsCount!=0){
      increase_n_times=10;
      increase_every_n_records=RowsCount/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=RowsCount;}
      increase_size=increase_size/increase_n_times;
     }
    }
    
    dos.writeInt(RowsCount);
    
     // write rows data
    if(RowsCount==0){
     if(Progress!=null){Progress.inform(increase_size, null, null);}
    }
    else{
     temp=0;
     do{
      
      temp2=0;
      do{
							Obj=Rows.elementAt(temp)[CustomColumns[temp2]];
							dos.writeBoolean(Obj!=null);
							if(Obj!=null){
							 switch(ColumnsType[temp2]){
									case CCore.TypeString: dos.writeUTF((String)Obj); break;
									case CCore.TypeInteger: dos.writeInt((Integer)Obj); break;
									case CCore.TypeLong: dos.writeLong((Long)Obj); break;
									case CCore.TypeDouble: dos.writeDouble((Double)Obj); break;
									case CCore.TypeBoolean: dos.writeBoolean((Boolean)Obj); break;
									case CCore.TypeDate: cal.setNewTime((Date)Obj); dos.writeLong(cal.getTimeInMillis()); break;
								}
							}
       
       temp2=temp2+1;
      }while(temp2!=ColumnsCount);
      
      temp=temp+1;
      if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     }while(temp!=RowsCount);
    }
    
    dos.flush();
   }
   catch(Exception E_){break;}
   ret=true;
  }while(false);
  if(dos!=null){try{dos.close();}catch(Exception E_){}}
  if(bos!=null){try{bos.close();}catch(Exception E_){}}
  if(fos!=null){try{fos.close();}catch(Exception E_){}}
  
  if(Progress!=null && InitProgress){Progress.disappear();}
  
  return ret;
 }
 public static Vector<Object[]> loadModelFromFile(File FromFile, OCustomModel ToModel, int[] CustomColumns,
  OFormInformProgress Progress, boolean InitProgress, Window InitProgress_FormBef, String InitProgress_Title){
  Vector<Object[]> ret=null;
  Vector<Object[]> rettemp=null;
  FileInputStream fis=null;
  DataInputStream dis=null;
  BufferedInputStream bis=null;
  int temp, temp2;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  Object[] objs;
  
  int ColumnsCount;
  int[] ColumnsType, typetemp;
  int RowsCount;
  
  if(Progress!=null && InitProgress){Progress.appear(InitProgress_FormBef, InitProgress_Title);}
  
  do{
   try{
    //
    if(Progress!=null){Progress.inform(0, "Mempersiapkan pembacaan dari file ...", "-");}
    
    typetemp=ToModel.getColumnsType();
    ColumnsType=new int[CustomColumns.length];
    temp=0;
    do{
     ColumnsType[temp]=typetemp[CustomColumns[temp]];
     temp=temp+1;
    }while(temp!=CustomColumns.length);
    if(!canConvertColumnsTypeToAType(ColumnsType)){break;}
    
    if(!FromFile.isFile()){break;}
    fis=new FileInputStream(FromFile);
    bis=new BufferedInputStream(fis, 8192);
    dis=new DataInputStream(bis);
    
    if(Progress!=null){Progress.inform(5, null, null);}
    
    //
    if(Progress!=null){Progress.inform(0, "Membaca dari file ...", "-");}
    
    ColumnsCount=ColumnsType.length;
    if(dis.readInt()!=ColumnsCount){break;}
    temp=0;
    do{
     if(dis.readInt()!=ColumnsType[temp]){break;}
     temp=temp+1;
    }while(temp!=ColumnsCount);
    if(temp!=ColumnsCount){break;}
    
    RowsCount=dis.readInt();
    if(Progress!=null){
     increase_size=95;
     
     if(RowsCount!=0){
      increase_n_times=10;
      increase_every_n_records=RowsCount/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=RowsCount;}
      increase_size=increase_size/increase_n_times;
     }
    }
    
    rettemp=new Vector();
    
     // read rows data
    if(RowsCount==0){
     if(Progress!=null){Progress.inform(increase_size, null, null);}
    }
    else{
     temp=0;
     do{
      
      objs=new Object[ColumnsCount];
      temp2=0;
      do{
							if(dis.readBoolean()){
								switch(ColumnsType[temp2]){
									case CCore.TypeString: objs[temp2]=dis.readUTF(); break;
									case CCore.TypeInteger: objs[temp2]=new Integer(dis.readInt()); break;
									case CCore.TypeLong: objs[temp2]=new Long(dis.readLong()); break;
									case CCore.TypeDouble: objs[temp2]=new Double(dis.readDouble()); break;
									case CCore.TypeBoolean: objs[temp2]=new Boolean(dis.readBoolean()); break;
									case CCore.TypeDate: cal.setNewTimeInMillis(dis.readLong()); objs[temp2]=cal.getTime(); break;
								}
							}
       temp2=temp2+1;
      }while(temp2!=ColumnsCount);
      rettemp.addElement(objs);
      
      temp=temp+1;
      if(Progress!=null && temp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     }while(temp!=RowsCount);
    }
   }
   catch(Exception E_){break;}
   ret=rettemp;
  }while(false);
  if(dis!=null){try{dis.close();}catch(Exception E_){}}
  if(bis!=null){try{bis.close();}catch(Exception E_){}}
  if(fis!=null){try{fis.close();}catch(Exception E_){}}
  
  if(Progress!=null && InitProgress){Progress.disappear();}
  
  return ret;
 }
 public static long csvExport(OFormInformProgress Progress,
  Vector<Object[]> Rows, int[] ColumnsType, String[] Header, int[] HeaderCols,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator){
  long ret=-1; // -1 error, >=0 export count
  long addcount;
  FileOutputStream fos=null;
  BufferedOutputStream bos=null;
  OCsvStreamWriter csw=null;
  int coltemp;
  long recordtemp, RecordsCount;
  Object[] ARecord;
  Object AField;
  double increase_size;
  int increase_n_times;
  long increase_every_n_records;
  boolean error, first;
  
  error=false;
  addcount=0;
  do{
   try{
    // prepare
    Progress.inform(0, "Mempersiapkan proses export ...", "-");
    
    if(ToFile.exists()){
     if(!ToFile.isFile()){error=true; break;}
     if(!ToFile.delete()){error=true; break;}
    }
    
    fos=new FileOutputStream(ToFile);
    bos=new BufferedOutputStream(fos);
    csw=new OCsvStreamWriter(bos, FieldDelimiter, FieldsSeparator, RecordsSeparator);
    
    Progress.inform(4, null, null);
    
    // write
    Progress.inform(0, "Menulis data ke file ...", "-");
    
     // write header
    Progress.inform(0, null, "Menulis header tabel ...");
    
    first=true;
    
    coltemp=0;
    do{
     if(first){first=false;}else{csw.writeFieldsSeparator();}
     csw.writeString(Header[coltemp]);
     coltemp=coltemp+1;
    }while(coltemp!=Header.length);
    
    Progress.inform(1, null, null);
    
     // write contents
    RecordsCount=Rows.size();
    if(RecordsCount==0){break;}
    
    Progress.inform(0, null, "Menulis isi data tabel ...");
    
    increase_n_times=10;
    increase_size=(double)95/(double)increase_n_times;
    increase_every_n_records=RecordsCount/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1;}
    recordtemp=0;
    do{
     csw.writeRecordsSeparator();
     
     first=true;
     
     ARecord=Rows.elementAt((int)recordtemp);
     
     coltemp=0;
     do{
      if(first){first=false;}else{csw.writeFieldsSeparator();}
      
      AField=ARecord[HeaderCols[coltemp]];
      
      csw.writeObject(AField, ColumnsType[HeaderCols[coltemp]]);
      
      coltemp=coltemp+1;
     }while(coltemp!=Header.length);
     addcount=addcount+1;
     
     recordtemp=recordtemp+1;
     if(recordtemp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
    }while(recordtemp!=RecordsCount);
   }
   catch(Exception E){error=true;}
  }while(false);
  if(!error){ret=addcount;}
  
  if(csw!=null){try{csw.close();}catch(Exception E){}}
  if(bos!=null){try{bos.close();}catch(Exception E){}}
  if(fos!=null){try{fos.close();}catch(Exception E){}}
  
  return ret;
 }
 public static long csvExport(OFormInformProgress Progress,
  Statement Stm, String Query, int[] ColumnsType, String[] Header, int[] HeaderCols,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator){
  return csvExport(Progress,
   Stm, Query, ColumnsType, Header, HeaderCols,
   null, null, null, null, null, null, null, false,
   ToFile, FieldDelimiter, FieldsSeparator, RecordsSeparator);
 }
 public static long csvExport(OFormInformProgress Progress,
  Statement Stm, String Query, int[] ColumnsType, String[] Header, int[] HeaderCols,
  Vector<String> List_SubQueryBeforeId, Vector<String[]> List_SubIdFromMainColsName, int[] SubIdFromMainCols, Vector<String> List_SubQueryAfterId,
   Vector<int[]> List_SubColumnsType, Vector<String[]> List_SubHeader, Vector<int[]> List_SubHeaderCols, boolean FillMainAlongWithSub,
  File ToFile, char FieldDelimiter, char FieldsSeparator, char RecordsSeparator){
  long ret=-1; // -1 error, >=0 export count
  long addcount;
  FileOutputStream fos=null;
  BufferedOutputStream bos=null;
  OCsvStreamWriter csw=null;
  int coltemp;
  long recordtemp, RecordsCount;
  ResultSet Rs;
  Object[] Fields;
  Object[] SubIdFields=null;
  double increase_size;
  int increase_n_times;
  long increase_every_n_records;
  boolean error;
  int subtemp, SubCount;
  Statement[] List_SubStm=null;
  ResultSet[] List_SubRs=null;
  boolean[] List_SubRsNext=null;
  Statement SubStm=null;
  ResultSet SubRs;
  
  int[] SubColumnsType, SubHeaderCols;
  String[] SubIdFromMainColsName, SubHeader;
  boolean first, subfirst, subnext;
  StringBuilder strb;
  
  SubCount=0; if(List_SubHeader!=null){SubCount=List_SubHeader.size();}
  
  error=false;
  addcount=0;
  do{
   try{
    // prepare
    Progress.inform(0, "Mempersiapkan proses export ...", "-");
    
    Progress.inform(0, null, null);
    
    if(ToFile.exists()){
     if(!ToFile.isFile()){error=true; break;}
     if(!ToFile.delete()){error=true; break;}
    }
    
    fos=new FileOutputStream(ToFile);
    bos=new BufferedOutputStream(fos);
    csw=new OCsvStreamWriter(bos, FieldDelimiter, FieldsSeparator, RecordsSeparator);
    
    Fields=new Object[Header.length];
    
    if(SubCount!=0){
     List_SubStm=new Statement[SubCount];
     List_SubRs=new ResultSet[SubCount];
     List_SubRsNext=new boolean[SubCount];
     
     subtemp=0;
     do{
      List_SubStm[subtemp]=Stm.getConnection().createStatement();
      subtemp=subtemp+1;
     }while(subtemp!=SubCount);
     
     SubIdFields=new Object[SubIdFromMainCols.length];
    }
    
    Progress.inform(4, null, null);
    
    // write
    Progress.inform(0, "Menulis data ke file ...", "-");
    
     // write header
    Progress.inform(0, null, "Menulis header tabel ...");
    
    first=true;
    
    coltemp=0;
    do{
     if(first){first=false;}else{csw.writeFieldsSeparator();}
     csw.writeString(Header[coltemp]);
     coltemp=coltemp+1;
    }while(coltemp!=Header.length);
    
    if(SubCount!=0){
     subtemp=0;
     do{
      SubHeader=List_SubHeader.elementAt(subtemp);
      
      coltemp=0;
      do{
       if(first){first=false;}else{csw.writeFieldsSeparator();}
       csw.writeString(SubHeader[coltemp]);
       coltemp=coltemp+1;
      }while(coltemp!=SubHeader.length);
      
      subtemp=subtemp+1;
     }while(subtemp!=SubCount);
    }
    
    Progress.inform(1, null, null);
    
     // write contents
    RecordsCount=(Long)PCore.replaceNullAs(PDatabase.getFirstRecord(Stm, "select count(*) from ("+
     PText.checkSide(Query, 2, ";", false, true, 3, "", 0, "", true)+") as QueryTbl;", 0, CCore.TypeLong), -1L);
    if(RecordsCount==-1){error=true; break;}
    if(RecordsCount==0){break;}
    
    Rs=Stm.executeQuery(Query);
    if(!Rs.next()){break;}
    
    Progress.inform(0, null, "Menulis isi data tabel ...");
    
    increase_n_times=10;
    increase_size=(double)95/(double)increase_n_times;
    increase_every_n_records=RecordsCount/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1;}
    recordtemp=0;
    do{
     // save main
     coltemp=0;
     do{
      Fields[coltemp]=PDatabase.getColumnFromResultSet(Rs, HeaderCols[coltemp], ColumnsType[HeaderCols[coltemp]]);
      coltemp=coltemp+1;
     }while(coltemp!=Header.length);
     
     // get sub-queries
     if(SubCount!=0){
      // save id from main-query
      coltemp=0;
      do{
       SubIdFields[coltemp]=PDatabase.getColumnFromResultSet(Rs, SubIdFromMainCols[coltemp], ColumnsType[SubIdFromMainCols[coltemp]]);
       coltemp=coltemp+1;
      }while(coltemp!=SubIdFromMainCols.length);
      
      // execute sub-queries's query
      subtemp=0;
      do{
       strb=new StringBuilder();
       
       strb.append(List_SubQueryBeforeId.elementAt(subtemp));
       
       strb.append(" where");
       SubIdFromMainColsName=List_SubIdFromMainColsName.elementAt(subtemp);
       coltemp=0; first=true;
       do{
        if(first){first=false;}else{strb.append(" and");}
        
        strb.append(" "+SubIdFromMainColsName[coltemp]+PText.getString(SubIdFields[coltemp]!=null, "=", " is ")+
         PDatabase.getSQLString(SubIdFields[coltemp], ColumnsType[SubIdFromMainCols[coltemp]], CCore.vNull, false));
        
        coltemp=coltemp+1;
       }while(coltemp!=SubIdFromMainCols.length);
       
       strb.append(" "+List_SubQueryAfterId.elementAt(subtemp));
       
       List_SubRs[subtemp]=List_SubStm[subtemp].executeQuery(strb.toString());
       List_SubRsNext[subtemp]=List_SubRs[subtemp].next();
       
       subtemp=subtemp+1;
      }while(subtemp!=SubCount);
     }
     
     subfirst=true;
     do{
      csw.writeRecordsSeparator();

      first=true;
      
      //
      coltemp=0;
      do{
       if(first){first=false;}else{csw.writeFieldsSeparator();}

       if(!subfirst && !FillMainAlongWithSub){csw.writeNull();}
       else{csw.writeObject(Fields[coltemp], ColumnsType[HeaderCols[coltemp]]);}

       coltemp=coltemp+1;
      }while(coltemp!=Header.length);
      
      //
      if(SubCount!=0){
       subtemp=0;
       do{
        SubColumnsType=List_SubColumnsType.elementAt(subtemp);
        SubHeader=List_SubHeader.elementAt(subtemp);
        SubHeaderCols=List_SubHeaderCols.elementAt(subtemp);
        SubRs=List_SubRs[subtemp];
        
        coltemp=0;
        do{
         if(first){first=false;}else{csw.writeFieldsSeparator();}

         if(!List_SubRsNext[subtemp]){csw.writeNull();}
         else{
          csw.writeObject(PDatabase.getColumnFromResultSet(SubRs, SubHeaderCols[coltemp], SubColumnsType[SubHeaderCols[coltemp]]),
           SubColumnsType[SubHeaderCols[coltemp]]);
         }

         coltemp=coltemp+1;
        }while(coltemp!=SubHeader.length);
        
        subtemp=subtemp+1;
       }while(subtemp!=SubCount);
      }
      
      subfirst=false;
      
      subnext=false;
      if(SubCount!=0){
       subtemp=0;
       do{
        if(List_SubRsNext[subtemp]){
         List_SubRsNext[subtemp]=List_SubRs[subtemp].next();
         if(List_SubRsNext[subtemp]){subnext=true;}
        }
        
        subtemp=subtemp+1;
       }while(subtemp!=SubCount);
      }
     }while(subnext);
     
     addcount=addcount+1;
     
     recordtemp=recordtemp+1;
     if(recordtemp%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
    }while(Rs.next());
   }
   catch(Exception E){System.out.println(E.toString()); error=true;}
  }while(false);
  if(!error){ret=addcount;}
  
  if(SubCount!=0){
   if(SubStm!=null){try{SubStm.close();}catch(Exception E){}}
   if(List_SubStm!=null){
    subtemp=0;
    do{
     SubStm=List_SubStm[subtemp];
     if(SubStm!=null){try{SubStm.close();}catch(Exception E){}}
     subtemp=subtemp+1;
    }while(subtemp!=List_SubStm.length);
   }
  }
  
  if(csw!=null){try{csw.close();}catch(Exception E){}}
  if(bos!=null){try{bos.close();}catch(Exception E){}}
  if(fos!=null){try{fos.close();}catch(Exception E){}}
  
  return ret;
 }
 public static Object[] csvImportAdd(
  OFormInformProgress Progress,
  OFileCsv FromFile,
  Statement Stm, String ToTable,
  Vector<String> PrimaryKeyColumns, OCsvImportValuesForInsert PrimaryKeyColumnsValue,
  Vector<String> NonPrimaryKeyColumns, OCsvImportValuesForInsert NonPrimaryKeyColumnsValue,
  boolean MultiInsert){
  Object[] ret=null; // null = error, { total_records, success_insert_records } = not error
  long addcount;
  long successcount;
  FileInputStream fis=null;
  BufferedInputStream bis=null;
  OCsvStreamReader csr=null;
  double increase_size;
  int increase_n_times;
  long increase_every_n_records;
  Vector<String> LastReadRecordFromFile;
  String insert_statement;
  StringBuilder strb;
  StringBuilder insert_records;
  int EachQueryAddMax;
  int curradd, insert_operation_count;
  boolean first;
  OGeneratedSQLValue GeneratedSQLColumnsValue;
  boolean error;
  
  if(!MultiInsert){EachQueryAddMax=1;}else{EachQueryAddMax=1000;}
  addcount=0;
  successcount=0;
  error=false;
  do{
   try{
    // prepare
    Progress.inform(0, "Mempersiapkan proses import ...", "-");
    
    Progress.inform(0, null, null);
    
    fis=new FileInputStream(FromFile);
    bis=new BufferedInputStream(fis);
    csr=new OCsvStreamReader(bis, FromFile.FieldDelimiter, FromFile.FieldsSeparators, FromFile.RecordsSeparators, FromFile.IncludeWhiteSpaceInField);
    
    Progress.inform(4, null, null);
    
    // read
    Progress.inform(0, "Membaca dan mengimpor data ...", "-");
    
     // skip header
    Progress.inform(0, null, "Membaca header tabel");
    
    do{
     csr.readNextRecord(false);
    }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile && csr.LastReadRecord_EmptyRecord);
    
    Progress.inform(1, null, null);
    
    if(csr.LastReadChar_CharType==csr.CharType_EndOfFile){break;}
    
     // read contents
    Progress.inform(0, null, "Membaca isi data tabel");
    
    strb=new StringBuilder();
    
    first=true;
    
    if(PrimaryKeyColumns!=null){
     if(first){first=false;}else{strb.append(",");}
     strb.append(PText.toString(PCore.refArr_VectStr(PrimaryKeyColumns), 0, PrimaryKeyColumns.size(), ","));
    }
    
    if(NonPrimaryKeyColumns!=null){
     if(first){first=false;}else{strb.append(",");}
     strb.append(PText.toString(PCore.refArr_VectStr(NonPrimaryKeyColumns), 0, NonPrimaryKeyColumns.size(), ","));
    }
    
    insert_statement="insert ignore into "+ToTable+"("+strb.toString()+") values ";
    
    increase_n_times=10;
    increase_size=(double)95/(double)increase_n_times;
    increase_every_n_records=FromFile.RecordsCount/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1;}
    
    do{
     
     insert_records=new StringBuilder();
     curradd=0;
     do{
      LastReadRecordFromFile=csr.readNextRecord(true);
      
      do{
       if(csr.LastReadRecord_EmptyRecord){break;}
       
       strb=new StringBuilder();

       first=true;

       if(PrimaryKeyColumnsValue!=null){
        PrimaryKeyColumnsValue.prepareGenerateSQLValue(LastReadRecordFromFile);
        GeneratedSQLColumnsValue=PrimaryKeyColumnsValue.generateSQLValue();
        if(!GeneratedSQLColumnsValue.isGenerated()){break;}
        if(first){first=false;}else{strb.append(',');}
        strb.append(GeneratedSQLColumnsValue.getGeneratedSQLValue());
       }

       if(NonPrimaryKeyColumnsValue!=null){
        NonPrimaryKeyColumnsValue.prepareGenerateSQLValue(LastReadRecordFromFile);
        GeneratedSQLColumnsValue=NonPrimaryKeyColumnsValue.generateSQLValue();
        if(!GeneratedSQLColumnsValue.isGenerated()){break;}
        if(first){first=false;}else{strb.append(',');}
        strb.append(GeneratedSQLColumnsValue.getGeneratedSQLValue());
       }
       
       if(curradd!=0){insert_records.append(',');}
       insert_records.append("("+strb.toString()+")");
       
       curradd=curradd+1;
       
       addcount=addcount+1;
       if(addcount%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
      }while(false);
      if(error){break;}

     }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile && curradd!=EachQueryAddMax);
     if(error){break;}
     
     if(curradd!=0){
      insert_operation_count=Stm.executeUpdate(insert_statement+insert_records.toString());
      if(insert_operation_count>0){successcount=successcount+insert_operation_count;}
     }
     
    }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile);
   }
   catch(Exception E){error=true;}
  }while(false);
  if(!error){ret=PCore.objArrVariant(addcount, successcount);}
  
  if(csr!=null){try{csr.close();}catch(Exception E){}}
  if(bis!=null){try{bis.close();}catch(Exception E){}}
  if(fis!=null){try{fis.close();}catch(Exception E){}}
  
  return ret;
 }
 public static Object[] csvImportUpdate(
  OFormInformProgress Progress,
  OFileCsv FromFile,
  Statement Stm, String ToTable,
  OCsvImportValuesForUpdateBody UpdateBody,
  OCsvImportValuesInColsAndValues UpdateCondition){
  Object[] ret=null; // null = error, { total_records, success_insert_records } = not error
  long updatecount;
  long successcount;
  FileInputStream fis=null;
  BufferedInputStream bis=null;
  OCsvStreamReader csr=null;
  double increase_size;
  int increase_n_times;
  long increase_every_n_records;
  Vector<String> LastReadRecordFromFile;
  int update_operation_count;
  OGeneratedSQLValue GeneratedSQLUpdateBody, GeneratedSQLUpdateCondition;
  boolean error;
  
  updatecount=0;
  successcount=0;
  error=false;
  do{
   try{
    // prepare
    Progress.inform(0, "Mempersiapkan proses import ...", "-");
    
    Progress.inform(0, null, null);
    
    fis=new FileInputStream(FromFile);
    bis=new BufferedInputStream(fis);
    csr=new OCsvStreamReader(bis, FromFile.FieldDelimiter, FromFile.FieldsSeparators, FromFile.RecordsSeparators, FromFile.IncludeWhiteSpaceInField);
    
    Progress.inform(4, null, null);
    
    // read
    Progress.inform(0, "Membaca dan mengimpor data ...", "-");
    
     // skip header
    Progress.inform(0, null, "Membaca header tabel");
    
    do{
     csr.readNextRecord(false);
    }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile && csr.LastReadRecord_EmptyRecord);
    
    Progress.inform(1, null, null);
    
    if(csr.LastReadChar_CharType==csr.CharType_EndOfFile){break;}
    
     // read contents
    Progress.inform(0, null, "Membaca isi data tabel");
    
    increase_n_times=10;
    increase_size=(double)95/(double)increase_n_times;
    increase_every_n_records=FromFile.RecordsCount/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1;}
    
    do{
     
     LastReadRecordFromFile=csr.readNextRecord(true);

     do{
      if(csr.LastReadRecord_EmptyRecord){break;}

      UpdateBody.prepareGenerateSQLValue(LastReadRecordFromFile);
      GeneratedSQLUpdateBody=UpdateBody.generateSQLValue();
      if(!GeneratedSQLUpdateBody.isGenerated()){break;}

      UpdateCondition.prepareGenerateSQLValue(LastReadRecordFromFile);
      GeneratedSQLUpdateCondition=UpdateCondition.generateSQLValue();
      if(!GeneratedSQLUpdateCondition.isGenerated()){break;}
      
      update_operation_count=Stm.executeUpdate("update ignore "+ToTable+" set "+GeneratedSQLUpdateBody.getGeneratedSQLValue()+" where "+GeneratedSQLUpdateCondition.getGeneratedSQLValue());
      updatecount=updatecount+1;
      if(update_operation_count>0){successcount=successcount+1;}
      if(updatecount%increase_every_n_records==0){Progress.inform(increase_size, null, null);}
     }while(false);
     if(error){break;}
     
    }while(csr.LastReadChar_CharType!=csr.CharType_EndOfFile);
   }
   catch(Exception E){error=true;}
  }while(false);
  if(!error){ret=PCore.objArrVariant(updatecount, successcount);}
  
  if(csr!=null){try{csr.close();}catch(Exception E){}}
  if(bis!=null){try{bis.close();}catch(Exception E){}}
  if(fis!=null){try{fis.close();}catch(Exception E){}}
  
  return ret;
 }

 public static void setDialogToCenter(JDialog FDialog, JFrame FCurrent){
  Point p;
  double Fx, Fy, Fw, Fh, FDw, FDh, OffsetX=0, OffsetY=0;
  
  p=FCurrent.getLocationOnScreen();
  Fx=p.getX(); Fy=p.getY();
  Fw=FCurrent.getWidth(); Fh=FCurrent.getHeight();
  FDw=FDialog.getWidth(); FDh=FDialog.getHeight();
  
  if(Fw>FDw){
   if(Fh>FDh){OffsetX=Fx+(Fw/2-FDw/2); OffsetY=Fy+(Fh/2-FDh/2);}
   else{OffsetX=Fx+(Fw/2-FDw/2); OffsetY=Fy-(FDh/2-Fh/2);}
  }
  else{
   if(Fh>FDh){OffsetX=Fx-(FDw/2-Fw/2); OffsetY=Fy+(Fh/2-FDh/2);}
   else{OffsetX=Fx-(FDw/2-Fw/2); OffsetY=Fy-(FDh/2-Fh/2);}
  }
  
  FDialog.setLocation((int)OffsetX, (int)OffsetY);
 }
 public static void setDialogToCenter(JDialog FDialog, JDialog FCurrent){
  Point p;
  double Fx, Fy, Fw, Fh, FDw, FDh, OffsetX=0, OffsetY=0;
  
  p=FCurrent.getLocationOnScreen();
  Fx=p.getX(); Fy=p.getY();
  Fw=FCurrent.getWidth(); Fh=FCurrent.getHeight();
  FDw=FDialog.getWidth(); FDh=FDialog.getHeight();
  
  if(Fw>FDw){
   if(Fh>FDh){OffsetX=Fx+(Fw/2-FDw/2); OffsetY=Fy+(Fh/2-FDh/2);}
   else{OffsetX=Fx+(Fw/2-FDw/2); OffsetY=Fy-(FDh/2-Fh/2);}
  }
  else{
   if(Fh>FDh){OffsetX=Fx-(FDw/2-Fw/2); OffsetY=Fy+(Fh/2-FDh/2);}
   else{OffsetX=Fx-(FDw/2-Fw/2); OffsetY=Fy-(FDh/2-Fh/2);}
  }
  
  FDialog.setLocation((int)OffsetX, (int)OffsetY);
 }
 public static void setDialogToCenter(JDialog FDialog){
  Point CenterPos;
  double OffsetX, OffsetY;
  
  CenterPos=GraphicsEnvironment.getLocalGraphicsEnvironment().getCenterPoint();
  OffsetX=CenterPos.getX()-((double)FDialog.getWidth()/(double)2);
  OffsetY=CenterPos.getY()-((double)FDialog.getHeight()/(double)2);
  
  FDialog.setLocation((int)OffsetX, (int)OffsetY);
 }
 
 public static boolean showDialog(int DialogType, int DialogAnswerType, int ShowCount, String FormTitle, String FormMessage){
  boolean ret=false;
  boolean IsRepeat, DoBreak;
  int temp, count, AnswerValue;
  StringBuilder Msg;
  
  do{
   IsRepeat=ShowCount>=2;
   count=ShowCount; if(count<=0){count=1;}
   
   temp=0;
   do{
    Msg=new StringBuilder();
    Msg.append(FormMessage);
    if(IsRepeat){Msg.append("\n\n{  Sisa Konfirmasi : "+(count-temp)+"  }\n\n");}
    
    DoBreak=false;
    do{
     if(DialogType==CGUI.DialogType_Message){JOptionPane.showMessageDialog(null, Msg); break;}
     
     if(DialogType==CGUI.DialogType_Confirm){
      do{
       if(DialogAnswerType==CGUI.DialogAnswerType_YesNo){
        AnswerValue=JOptionPane.showConfirmDialog(null, Msg, FormTitle, JOptionPane.YES_NO_OPTION);
        if(AnswerValue!=CGUI.DialogAnswerValue_Yes){DoBreak=true; break;}
        
        break;
       }
       if(DialogAnswerType==CGUI.DialogAnswerType_OkCancel){
        AnswerValue=JOptionPane.showConfirmDialog(null, Msg, FormTitle, JOptionPane.OK_CANCEL_OPTION);
        if(AnswerValue!=CGUI.DialogAnswerValue_Ok){DoBreak=true; break;}
        
        break;
       }
      }while(false);
      if(DoBreak){break;}
      
      break;
     }
    }while(false);
    if(DoBreak){break;}
    
    temp=temp+1;
   }while(temp!=count);
   if(temp!=count){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }

 private static boolean canConvertColumnsTypeToAType(int[] ColumnsType){
  boolean ret=true;
  int temp, coltype;
  
  temp=0;
  do{
   coltype=ColumnsType[temp];
   // ColumnsType must be a known data type, so the data in the column can be converted to a data type (cannot be CCore.TypeUnknown)
   if(coltype!=CCore.TypeString &&
      coltype!=CCore.TypeInteger && coltype!=CCore.TypeLong &&
      coltype!=CCore.TypeDouble &&
      coltype!=CCore.TypeBoolean &&
      coltype!=CCore.TypeDate){
    ret=false; break;
   }
   temp=temp+1;
  }while(temp!=ColumnsType.length);
  
  return ret;
 }

}