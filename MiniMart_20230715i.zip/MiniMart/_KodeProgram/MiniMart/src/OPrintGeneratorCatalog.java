public abstract class OPrintGeneratorCatalog extends OPrintGenerator {
 
 /*
  note :
   checkLastUsedLayout() just check PaperType, PaperOrientation, & Columnar, so child class of
   this PrintGeneratorCatalog must take attention to method checkLastUsedLayout()
   if the layout variables are not only depend on PaperType, PaperOrientation, & Columnar
 */ 

 int FramesCountHorizontal, FramesCountVertical;

 char[] TxtComment;

 // standard layout
  // Frame
 double FrameWidth, FrameHeight;
 double FrameAddLineSpacing, FrameAddLineSpacingHorizontal, FrameH;
 double FrameGapHorizontal, FrameGapVertical;
 
  // Image
 double BoxWidth, BoxHeight;
 
  // Image Text
 double CommentOffsetX; // OffsetX from Image Box
 double CommentAddLineSpacing;
 int CommentCharCount;

 // category
 double CategoryAddLineSpacing;

 public OPrintGeneratorCatalog(OFont FontStandard) {super(FontStandard);}

 protected void calculateLayoutVariablesOptional() throws Exception{
  double temp;
  ODimensionAbsolute FramesCount;
  
  FramesCount=getFramesCount();
  this.FramesCountHorizontal=FramesCount.ColumnsCount;
  this.FramesCountVertical=FramesCount.RowsCount;
  
  CategoryAddLineSpacing=getCategoryAddLineSpacing();
  FrameAddLineSpacing=4;
  temp=OrientedPaprImageableHeight;
  if(hasHeader()){temp=temp-HeaderHeight;}
  if(hasFooter()){temp=temp-FooterHeight;}
  FrameHeight=((temp-((FramesCountVertical-1)*CategoryAddLineSpacing))/FramesCountVertical)-NormalHeight-FrameAddLineSpacing;
  
  FrameAddLineSpacingHorizontal=2;
  FrameWidth=(ColumnarWidth-((FramesCountHorizontal-1)*FrameAddLineSpacingHorizontal))/FramesCountHorizontal;
  
  FrameH=FrameAddLineSpacing+FrameHeight;
  FrameGapHorizontal=7;
  FrameGapVertical=7;
  
  CommentAddLineSpacing=4;
  
  BoxWidth=FrameWidth-2*FrameGapHorizontal;
  BoxHeight=FrameHeight-2*FrameGapVertical-CommentAddLineSpacing-getCommentRowsCount()*NormalHeight;
  
  CommentCharCount=(int)(BoxWidth/FontWidth);
  if(CommentCharCount<getMinimalCommentCharCount()){throw  new Exception();}
  CommentOffsetX=(BoxWidth-(CommentCharCount*FontWidth))/2;
 }
 protected void initializePrintingVariablesOptional(){
  TxtComment=new char[CommentCharCount];
 }
 
 protected abstract int getMinimalCommentCharCount();
 protected abstract int getCommentRowsCount();
 protected abstract int getCategoryAddLineSpacing();
 protected abstract ODimensionAbsolute getFramesCount();
 
}