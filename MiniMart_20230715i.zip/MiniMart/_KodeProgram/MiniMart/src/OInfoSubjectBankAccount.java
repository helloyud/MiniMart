public class OInfoSubjectBankAccount {
 
 int Enumeration;
 String Acc;
 int BankPlatformId; String BankPlatformName;
 String Comment;

}