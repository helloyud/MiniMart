import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;

public class OActionKeyActSelf extends OActionKey {

 public OActionKeyActSelf(){}
 public OActionKeyActSelf(
  Window Form, Component Cmp, KeyEvent evt) {
  
  init(Form, Cmp, evt);
 
 }
 
 OActionKeyActSelf init(){
  return this;
 }
 OActionKeyActSelf init(
  Window Form, Component Cmp, KeyEvent evt){
  
  super.init(Form, Cmp, evt);
  
  return this;
 }
 
 public int doAction() {
  int ret=CNav.Ret_Unconsumed;
  
  //
  
  
  return ret;
 }
 
}