public class ODrawTableRow {
	
 double Height;
	ODrawTableCell[] Cells;

 public ODrawTableRow(double Height, int ColumnsCount) {
  init(Height, ColumnsCount);
 }
 public void init(double Height, int ColumnsCount){
  setHeight(Height);
  Cells = new ODrawTableCell[ColumnsCount];
 }
 
 public void setHeight(double Height){
  this.Height=Height;
 }
 public void setCell(int ColumnIndex, ODrawTableCell Cell){
  if(ColumnIndex<0 || ColumnIndex>=Cells.length){return;}
  Cells[ColumnIndex]=Cell;
 }
 public void clearAllCells(){
  int temp, length;
  
  length=Cells.length;
  
  temp=0;
  do{
   Cells[temp]=null;
   temp=temp+1;
  }while(temp!=length);
 }
 
 public boolean preGenerateCellsDrawContents(ODrawTable Table, int RowIndex){
  boolean ret=false;
  int temp, length;
  ODrawTableCell Cell;
  
  do{
   length=Cells.length;

   // pre-generate cells's draw contents
   temp=0;
   do{
    Cell=Cells[temp];
    
    if(Cell!=null){
     if(Cell.preGenerateDrawContents(Table, RowIndex, temp, this)==false){break;}
    }

    temp=temp+1;
   }while(temp!=length);
   if(temp!=length){break;}
   
   ret=true;
  }while(false);
   
  
  return ret;
 }
 public ODimension calculatePreGeneratedCellsDrawContentsDimension(ODrawTable Table, int RowIndex){
  ODimension ret=new ODimension(0, 0);
  int temp, length;
  ODrawTableCell Cell;
  double MaxWidth, MaxHeight;
  ODimension dim;
  
  length=Cells.length;

  // calculating cells's pre-generated draw contents's dimension
  MaxWidth=0; MaxHeight=0;
  temp=0;
  do{
   Cell=Cells[temp];

   if(Cell!=null){
    dim=Cell.calculatePreGeneratedDrawContentsDimension(Table, RowIndex, temp, this);
    if(MaxWidth<dim.getWidth()){MaxWidth=dim.getWidth();}
    if(MaxHeight<dim.getHeight()){MaxHeight=dim.getHeight();}
   }

   temp=temp+1;
  }while(temp!=length);
  ret.setSize(MaxWidth, MaxHeight);
  
  return ret;
 }
 public void generateCellsDrawContents(ODrawTable Table, int RowIndex){
  int temp, length;
  ODrawTableCell Cell;
  
  length=Cells.length;

  // generate cells's draw contents
  temp=0;
  do{
   Cell=Cells[temp];

   if(Cell!=null){
    Cell.generateDrawContents(Table, RowIndex, temp, this);
   }

   temp=temp+1;
  }while(temp!=length);
 }
 
 public ODrawTableRow createNewRow(){
  return new ODrawTableRow(Height, Cells.length);
 }
 
}