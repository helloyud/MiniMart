import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;

public class OActionKeyActCustom extends OActionKey {

 AbstractAction Act;
 
 public OActionKeyActCustom(){}
 public OActionKeyActCustom(AbstractAction Act) {
  init(Act);
 }
 public OActionKeyActCustom(
  Window Form, Component Cmp, KeyEvent evt,
  AbstractAction Act) {
  
  init(Form, Cmp, evt, Act);
 
 }
 
 OActionKeyActCustom init(AbstractAction Act){
  this.Act = Act;
  return this;
 }
 OActionKeyActCustom init(
  Window Form, Component Cmp, KeyEvent evt,
  AbstractAction Act){
  
  init(Form, Cmp, evt);
  init(Act);
  
  return this;
 }
 
 public int doAction() {
  int ret=CNav.Ret_Unconsumed;
  int KeyCode=evt.getKeyCode();
  
  if(PNav.executeAbstractAction(Cmp, Act)){ret=CNav.Ret_Consumed;}
  
  return ret;
 }
 
}