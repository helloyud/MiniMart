import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.Book;
import java.io.File;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.LinkedList;
import java.util.Vector;
import javax.print.PrintService;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableColumnModel;

public class F_TransView extends XFormDialog {
 
 // set
 private boolean wIsPreTrans;
 boolean wIsViewMode; // true = view mode, false = choose mode
 boolean wAllowMultipleSelection;
 
 // get
 Long[] ChoosedId;
 
 //
 String DbTable;
 String DbAppLock;
 String TransName;
 
 // table trans
 OCustomTableModel TableMdlTrans;
	String[] TableMdlTransColsName;
	int[] TableMdlTransColsType, TableMdlTransColsShowOption, TableMdlTransColsVisible, TableTransColsWidth;
	boolean[] TableMdlTransColsEditable;
 boolean[] SumColumn;
 double[] SumResult;
 int LastSelectedRowTrans;
 
 final int ColTransPriceItemIn=16;
 final int ColTransPriceItemOut=17;
 final int ColTransPriceItemOutBasic=18;
 final int ColTransPricePayOut=19;
 final int ColTransPricePayIn=20;
 
 boolean LastQueryDefined;
 int LQ_Limit;
 // Static Filter
	String LQ_StaticSourceTable, LQ_StaticCondition, LQ_StaticPostCondition;
 boolean LQ_StaticConditionDefined, LQ_StaticPostConditionDefined;
 // Dynamic Filter
 int LQ_DynamicTempList; // 0 ignore, 1 templist, 2 ~templist
 // Additional Filter
 boolean LQ_WithAdditionalFilter;
 
 String LastQueryOrderBy;
 String QHavingTbl;
 
 int LastResultFilterSubset;
 
 int LastViewMode;
 
 double ItemInPriceSum, PaymentOutSum, ItemOutPriceSum, ItemOutPriceBasicSum, PaymentInSum;
 
 // tab search
 OCustomListModel ListMdlQType;
 OCustomListModel ListMdlQCash;
 OCustomListModel ListMdlQSubject;
 OCustomListModel ListMdlQSalesman;
 OCustomTableModel TableMdlQItem;
 Component LastFocusedCmpSearch;
 
 // index
 boolean TIRequeryAll;
 
 // tab detail
 boolean TIDet;
 boolean TIDetClear;
 
 // tab item in & out
 OCustomTableModel TableMdlIn;
	String[] TableMdlItemInColsName;
	int[] TableMdlItemInColsType, TableMdlItemInColsShowOption, TableMdlItemInColsVisible, TableItemInColsWidth;
	boolean[] TableMdlItemInColsEditable;
 String QueryItemInOrderBy, QueryItemInTbHaving;
 boolean TIIn; // table re-query sign
 boolean TIInClear; // table-content cleared sign
 int LastSelectedRowIn;
 boolean InfoInClear; // panel-info cleared sign
 
 OCustomTableModel TableMdlOut;
	String[] TableMdlItemOutColsName;
	int[] TableMdlItemOutColsType, TableMdlItemOutColsShowOption, TableMdlItemOutColsVisible, TableItemOutColsWidth;
	boolean[] TableMdlItemOutColsEditable;
 String QueryItemOutOrderBy, QueryItemOutTbHaving;
 boolean TIOut; // table re-query sign
 boolean TIOutClear; // table-content cleared sign
 int LastSelectedRowOut;
 boolean InfoOutClear; // panel-info cleared sign
 
 // tab payment out & in
 OCustomTableModel TableMdlPaymentOut;
 boolean TIPayOut; // table re-query sign
 boolean TIPayOutClear; // table-content cleared sign
 int LastSelectedRowPayOut;
 boolean InfoPayOutClear; // panel-info cleared sign
 
 OCustomTableModel TableMdlPaymentIn;
 boolean TIPayIn; // table re-query sign
 boolean TIPayInClear; // table-content cleared sign
 int LastSelectedRowPayIn;
 boolean InfoPayInClear; // panel-info cleared sign
 
 //
 OQuickListOfLong TempList;
 
 // tab Order
 OCustomTableModel TableMdlOrd;
	String[] TableMdlOrdColsName;
	int[] TableMdlOrdColsType, TableMdlOrdColsShowOption, TableMdlOrdColsVisible, TableOrdColsWidth;
	boolean[] TableMdlOrdColsEditable;
 String QueryOrdOrderBy, QueryOrdTbHaving;
 boolean ListOrdFilled;
 int LastSelectedRowOrd;
 boolean InfoOrdClear;
 boolean[] OrdSumColumn;
 double[] OrdSumResult;
 VDouble OrdPriceEst;
 
 //
 AbstractAction AbstFocusQueryResult;
 
 /**
  * Creates new form F_TransView
  */
 public F_TransView(MInterFormVariables IFV_, boolean IsPreTrans_) {
  String[] ColName;
  int[] ColType;
  int[] ColVisible;
  int[] Editable;
  TableColumnModel ColMdl;
		Date dt;
  
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  
  onKeyPress();
  
  //
  wIsPreTrans=IsPreTrans_;
  
  if(!wIsPreTrans){
   Btn_TransCancel.setText("Batalkan {F3}");
   Btn_TransCancel.setToolTipText("Operasi pembatalan akan menghapus transaksi yang dipilih dan mengubah stok barang yang berkaitan");

   DbTable="Trans";
   DbAppLock=IFV.TransLock;
   TransName="Transaksi";
  }
  else{
   Btn_TransCancel.setText("Transaksikan {F3}");
   Btn_TransCancel.setToolTipText("Konversi pra-transaksi yang dipilih menjadi transaksi");

   DbTable="PreTrans";
   DbAppLock=IFV.PreTransLock;
   TransName="Pra-Transaksi";
  }
  
  // tab search
  ListMdlQType=new OCustomListModel(false);
  ColType=new int[2];
  ColType[0]=2;
  ColType[1]=1;
  ListMdlQType.setColumnsInfo(ColType, 1);
  List_QTransType.setModel(ListMdlQType);
  
  ListMdlQCash=new OCustomListModel(false);
  ColType=new int[2];
  ColType[0]=2;
  ColType[1]=1;
  ListMdlQCash.setColumnsInfo(ColType, 1);
  List_QCash.setModel(ListMdlQCash);
  
  ListMdlQSubject=new OCustomListModel(false);
  ColType=new int[2];
  ColType[0]=3;
  ColType[1]=1;
  ListMdlQSubject.setColumnsInfo(ColType, 1);
  List_QSubject.setModel(ListMdlQSubject);
  
  ListMdlQSalesman=new OCustomListModel(false);
  ColType=new int[2];
  ColType[0]=3;
  ColType[1]=1;
  ListMdlQSalesman.setColumnsInfo(ColType, 1);
  List_QSalesman.setModel(ListMdlQSalesman);
  
  TableMdlQItem=new OCustomTableModel();
  ColName=new String[2];
  ColName[0]="Id";
  ColName[1]="Nama";
  ColType=new int[2];
  ColType[0]=3;
  ColType[1]=1;
  ColVisible=new int[2];
  ColVisible[0]=0;
  ColVisible[1]=1;
  TableMdlQItem.setColumnsInfo(ColName, ColType,
   PCore.changeValue(PCore.newIntegerArray(ColName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject)), ColVisible);
  Tbl_QItem.setModel(TableMdlQItem);
  Tbl_QItem.moveColumn(1, 0);
  ColMdl=Tbl_QItem.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(260);
  ColMdl.getColumn(1).setPreferredWidth(95);
  
  RB_QImportantYes.setSelected(true);
   
		dt=new Date();
		PGUI.setDateComponent(dt, TF_QDateStartYear, ComboBox_QDateStartMonth, ComboBox_QDateStartDay);
		PGUI.setDateComponent(dt, TF_QDateEndYear, ComboBox_QDateEndMonth, ComboBox_QDateEndDay);
		PGUI.setDateComponent(dt, TF_QRepayPeriodStartYear, CmB_QRepayPeriodStartMonth, CmB_QRepayPeriodStartDay);
		PGUI.setDateComponent(dt, TF_QRepayPeriodEndYear, CmB_QRepayPeriodEndMonth, CmB_QRepayPeriodEndDay);
		PGUI.setDateComponent(dt, TF_QBillDateStartYear, CmB_QBillDateStartMonth, CmB_QBillDateStartDay);
		PGUI.setDateComponent(dt, TF_QBillDateEndYear, CmB_QBillDateEndMonth, CmB_QBillDateEndDay);
  
  // index
  TIRequeryAll=true;
  TIDet=false; TIDetClear=true;
  TIIn=false; TIInClear=true;
  TIOut=false; TIOutClear=true;
  TIPayOut=false; TIPayOutClear=true;
  TIPayIn=false; TIPayInClear=true;
  
  // table trans
  TableMdlTrans=new OCustomTableModel(true, false, true);
		Tbl_Trans.setModel(TableMdlTrans);
		TableMdlTransColsName=PCore.refArr("Id", "{Id-Ext}", "Penting", "Jenis", "Tgl Trans", "Tgl Tagih", "Cicil Awal", "Cicil Akhir",
			"Id Subjek", "Subjek", "Id Sales", "Sales", "Kas Keluar", "Ket. Kas Keluar", "Kas Masuk", "Ket. Kas Masuk", "Brg Masuk", "Brg Keluar", "HPP", "{ Byr Klr }", "{ Byr Msk }");
		TableMdlTransColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeBoolean, CCore.TypeString, CCore.TypeDate, CCore.TypeDate, CCore.TypeDate, CCore.TypeDate,
			CCore.TypeLong, CCore.TypeString, CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeString, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeDouble);
  TableMdlTransColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableMdlTransColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(0), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=new int[0];
	 TableMdlTransColsEditable=PCore.changeValue(PCore.newBooleanArray(TableMdlTransColsName.length, false), Editable, PCore.newBooleanArray(Editable.length, true));
  SumColumn=PCore.primArr(false, false, false, false, false, false, false, false,
   false, false, false, false, false, false, false, false, true, true, true, true, true);
  SumResult=new double[SumColumn.length];
  
  LastSelectedRowTrans=-1;
  
  QHavingTbl="tb7";
  
  Tbl_Trans.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableTrans();}
   };
  
  refreshQueryCount();
  clearLastQuery();
  
  LastResultFilterSubset=CmB_ResultFilterSubset.getSelectedIndex();
  
  clearTransAdditionalInfo();
  
  CB_ItemOutBasicSum.setSelected(false); CB_ItemOutBasicSumActionPerformed(null);
  
  // tab detail

  // tab item in & out
  TableMdlIn=new OCustomTableModel(true, CApp.Default_TransItem_Checked, true);
  Tbl_In.setModel(TableMdlIn);
  TableMdlItemInColsName=PCore.refArr("Id Brg", "Nm Brg", "Nama Brg", "Qty", "Satuan", "Hrg Total", "Hrg Sat.", "Komentar",
   "File Gambar", "Kategori");
	 TableMdlItemInColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeString, CCore.TypeString);
  TableMdlItemInColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableMdlItemInColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(3, 5, 6);
  if(!wIsPreTrans){
   TableMdlItemInColsEditable=PCore.newBooleanArray(TableMdlItemInColsName.length, false);
  }
  else{
   TableMdlItemInColsEditable=PCore.changeValue(PCore.newBooleanArray(TableMdlItemInColsName.length, false),
    Editable, PCore.newBooleanArray(Editable.length, true));
  }
  QueryItemInTbHaving="tb4";
  LastSelectedRowIn=-1;
  InfoInClear=true;
  CB_ItemInCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableItemInViewStructure(true, true);
  updateTableItemInView(false);
  
  refreshItemCount(TF_InCount, TableMdlIn);
  CmB_FindItemIn.setSelectedIndex(1);
  
  Tbl_In.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem(true);}
   };
  
  Pnl_ItemInPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  TableMdlOut=new OCustomTableModel(true, CApp.Default_TransItem_Checked, true);
  Tbl_Out.setModel(TableMdlOut);
  TableMdlItemOutColsName=PCore.refArr("Id Brg", "Nm Brg", "Nama Brg", "Qty", "Satuan", "Hrg Total", "Hrg Sat.", "Komentar",
   "File Gambar", "Kategori", "H-Beli Sat.", "HPP");
  TableMdlItemOutColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeDouble);
  TableMdlItemOutColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableMdlItemOutColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  Editable=PCore.primArr(3, 5, 6);
  if(!wIsPreTrans){
   TableMdlItemOutColsEditable=PCore.newBooleanArray(TableMdlItemOutColsName.length, false);
  }
  else{
   TableMdlItemOutColsEditable=PCore.changeValue(PCore.newBooleanArray(TableMdlItemOutColsName.length, false),
    Editable, PCore.newBooleanArray(Editable.length, true));
  }
  QueryItemOutTbHaving="tb4";
  LastSelectedRowOut=-1;
  InfoOutClear=true;
  CB_ItemOutCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableItemOutViewStructure(true, true);
  updateTableItemOutView(false);
  
  refreshItemCount(TF_OutCount, TableMdlOut);
  CmB_FindItemOut.setSelectedIndex(1);
  
  Tbl_Out.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableItem(false);}
   };
  
  Pnl_ItemOutPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // tab payment out & in
  TableMdlPaymentOut=new OCustomTableModel();
  ColName=new String[6];
  ColName[0]="Enumerasi";
  ColName[1]="Tanggal";
  ColName[2]="KasId";
  ColName[3]="Kas Kredit";
  ColName[4]="Jumlah";
  ColName[5]="Keterangan";
  ColType=new int[6];
  ColType[0]=2;
  ColType[1]=6;
  ColType[2]=2;
  ColType[3]=1;
  ColType[4]=4;
  ColType[5]=1;
  ColVisible=new int[4];
  ColVisible[0]=1;
  ColVisible[1]=3;
  ColVisible[2]=4;
  ColVisible[3]=5;
  TableMdlPaymentOut.setColumnsInfo(ColName, ColType, ColVisible);
  Tbl_PaymentOut.setModel(TableMdlPaymentOut);
  refreshPaymentCount(TF_PayOutCount, TableMdlPaymentOut);
  ColMdl=Tbl_PaymentOut.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(90);
  ColMdl.getColumn(1).setPreferredWidth(135);
  ColMdl.getColumn(2).setPreferredWidth(105);
  ColMdl.getColumn(3).setPreferredWidth(190);
  
  LastSelectedRowPayOut=-1;
  InfoPayOutClear=true;
  
  TableMdlPaymentIn=new OCustomTableModel();
  ColName=new String[6];
  ColName[0]="Enumerasi";
  ColName[1]="Tanggal";
  ColName[2]="KasId";
  ColName[3]="Kas Kredit";
  ColName[4]="Jumlah";
  ColName[5]="Keterangan";
  ColType=new int[6];
  ColType[0]=2;
  ColType[1]=6;
  ColType[2]=2;
  ColType[3]=1;
  ColType[4]=4;
  ColType[5]=1;
  ColVisible=new int[4];
  ColVisible[0]=1;
  ColVisible[1]=3;
  ColVisible[2]=4;
  ColVisible[3]=5;
  TableMdlPaymentIn.setColumnsInfo(ColName, ColType, ColVisible);
  Tbl_PaymentIn.setModel(TableMdlPaymentIn);
  refreshPaymentCount(TF_PayInCount, TableMdlPaymentIn);
  ColMdl=Tbl_PaymentIn.getColumnModel();
  ColMdl.getColumn(0).setPreferredWidth(90);
  ColMdl.getColumn(1).setPreferredWidth(135);
  ColMdl.getColumn(2).setPreferredWidth(105);
  ColMdl.getColumn(3).setPreferredWidth(190);
  
  LastSelectedRowPayIn=-1;
  InfoPayInClear=true;
  
  // tab Order
  TableMdlOrd=new OCustomTableModel();
  TableMdlOrdColsName=PCore.refArr("Id Brg", "Nama Brg", "Kategori", "Qty", "Satuan",
   "H-Beli Sat.", "Kis. H-Order", "File Gambar");
  TableMdlOrdColsType=PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeString, CCore.TypeDouble, CCore.TypeString,
   CCore.TypeDouble, CCore.TypeDouble, CCore.TypeString);
  TableMdlOrdColsShowOption=PCore.changeValue(PCore.newIntegerArray(TableMdlOrdColsName.length, OCustomTableModel.ShowOptionNormal),
   PCore.primArr(-1), PCore.primArr(OCustomTableModel.ShowOptionObject));
  TableMdlOrdColsEditable=PCore.changeValue(PCore.newBooleanArray(TableMdlOrdColsName.length, false),
   PCore.primArr(3), PCore.primArr(true));
  Tbl_Ord.setModel(TableMdlOrd);
  LastSelectedRowOrd=-1;
  ListOrdFilled=false;
  InfoOrdClear=true;
  QueryOrdTbHaving="tb4";
  OrdSumColumn=PCore.newBooleanArray(TableMdlOrdColsName.length, false); OrdSumColumn[6]=true;
  OrdSumResult=new double[TableMdlOrdColsName.length];
  Tbl_Ord.Editing_Action=new AbstractAction(){
    public void actionPerformed(ActionEvent e) {onEditingTableOrd();}
   };
  OrdPriceEst=new VDouble(0);
  refreshOrdCount(); refreshOrdPriceEst();
  CB_OrdCategorized.setSelected(IFV.Conf.ItemCategorized);
  buildTableOrdViewStructure(true, true);
  updateTableOrdView(false);
  
  CmB_OrdFind.setSelectedIndex(1);
  
  Pnl_OrdPreview.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  
  // TabbedPane
  TabbedPane.addChangeListener(new ChangeListener(){
    public void stateChanged(ChangeEvent e) {onTabbedPaneChanged();}
   });
  TabbedPane.setSelectedIndex(0);
  
  //
  TempList=new OQuickListOfLong(1024, 1024, true, true);
  clearTempList();
  
  PGUI.setSelected(true, CB_ViewDate, CB_ViewDateBill, CB_ViewSubject, CB_ViewId, CB_ViewIsImportant, CB_ViewItemIn, CB_ViewItemOut);
  LastViewMode=-1; CmB_ViewMode.setSelectedIndex(0); onSelectedRowViewModeChanged();
  
  //
  AbstFocusQueryResult=new AbstractAction(){public void actionPerformed(ActionEvent e){focusQueryResult();}};
  Btn_Query.setToolTipText("hasil pencarian terbatas hingga "+PText.intToString(CApp.FormQueryLimit)+" data");
 }
 
 private void onKeyPress(){
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    Btn_Query,
    CB_QImportant, RB_QImportantYes, RB_QImportantNo,
    CB_QCheck, CmB_QCheck,
    CB_QDate, TF_QDateStartYear, ComboBox_QDateStartMonth, ComboBox_QDateStartDay, TF_QDateEndYear, ComboBox_QDateEndMonth, ComboBox_QDateEndDay,
    CB_QBillDate, TF_QBillDateStartYear, CmB_QBillDateStartMonth, CmB_QBillDateStartDay, TF_QBillDateEndYear, CmB_QBillDateEndMonth, CmB_QBillDateEndDay,
    CB_QRepayPeriod, TF_QRepayPeriodStartYear, CmB_QRepayPeriodStartMonth, CmB_QRepayPeriodStartDay, TF_QRepayPeriodEndYear, CmB_QRepayPeriodEndMonth, CmB_QRepayPeriodEndDay,
    CB_QId, TF_QId,
    CB_QComment, TF_QComment,
    CB_QCashComment, CmB_QCashComment, TF_QCashComment,
    CB_QItemPrice, CmB_QItemPrice, TF_QItemPrice1, TF_QItemPrice2,
    CB_QPaymentPrice, CmB_QPaymentPrice, TF_QPaymentPrice1, TF_QPaymentPrice2,
    CB_QTransType, CB_QTransTypeEmpty, List_QTransType, Btn_QTransTypeAdd, Btn_QTransTypeRemove,
    CB_QSubject, CB_QSubjectEmpty, List_QSubject, Btn_QSubjectAdd, Btn_QSubjectRemove,
    CB_QSalesman, CB_QSalesmanEmpty, List_QSalesman, Btn_QSalesmanAdd, Btn_QSalesmanRemove,
    CB_QCash, CmB_QCash, CB_QCashEmpty, List_QCash, Btn_QCashAdd, Btn_QCashRemove,
    CB_QItem, CmB_QItem, CB_QItemNon, Tbl_QItem, Btn_QItemAdd, Btn_QItemRemove,
    
    TF_Find, Tbl_Trans,
    
    TF_FindItemIn, Tbl_In,
    
    TF_FindItemOut, Tbl_Out,
    
    TF_OrdFind, Tbl_Ord),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     formWindowClosing(null);
     setVisible(false);
    }
   });
  
  // f1
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, true), "f1");
  act.put("f1", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_TransNewActionPerformed(null);
    }
   });
  
  // f2
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, true), "f2");
  act.put("f2", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_TransEditActionPerformed(null);
    }
   });
  
  // f3
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, true), "f3");
  act.put("f3", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_TransCancelActionPerformed(null);
    }
   });
  
  // f4
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0, true), "f4");
  act.put("f4", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 2 : break;
      case 4 : break;
      case 6 : break;
     }
    }
   });
  
  // f5
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0, true), "f5");
  act.put("f5", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 6 : Btn_OrdMoveActionPerformed(null); break;
     }
    }
   });
  
  // f6
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0, true), "f6");
  act.put("f6", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 0 : Btn_QueryActionPerformed(null); break;
      case 2 : Btn_InAddActionPerformed(null); break;
      case 3 : Btn_PaymentOutAddActionPerformed(null); break;
      case 4 : Btn_OutAddActionPerformed(null); break;
      case 5 : Btn_PaymentInAddActionPerformed(null); break;
      case 6 : Btn_OrdAddActionPerformed(null); break;
     }
    }
   });
  
  // f7
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F7, 0, true), "f7");
  act.put("f7", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 2 : Btn_InEditActionPerformed(null); break;
      case 3 : Btn_PaymentOutEditActionPerformed(null); break;
      case 4 : Btn_OutEditActionPerformed(null); break;
      case 5 : Btn_PaymentInEditActionPerformed(null); break;
      case 6 : Btn_OrdEditActionPerformed(null); break;
     }
    }
   });
  
  // f8
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F8, 0, true), "f8");
  act.put("f8", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     switch(TabbedPane.getSelectedIndex()){
      case 2 : Btn_InCancelActionPerformed(null); break;
      case 3 : Btn_PaymentOutCancelActionPerformed(null); break;
      case 4 : Btn_OutCancelActionPerformed(null); break;
      case 5 : Btn_PaymentInCancelActionPerformed(null); break;
      case 6 : Btn_OrdRemoveActionPerformed(null); break;
     }
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_TransChooseActionPerformed(null);
    }
   });
 }
 
 void clearComponents(){
  // cancel table editing
  Tbl_Trans.editingCanceled(null);
  Tbl_Ord.editingCanceled(null);
  Tbl_Out.editingCanceled(null);
  Tbl_In.editingCanceled(null);
 
  // tab search
  CB_QId.setSelected(false); TF_QId.setText("");
  CB_QImportant.setSelected(false);
		CB_QCheck.setSelected(false);
  CB_QDate.setSelected(false); // TF_QDateStartYear.setText(""); TF_QDateEndYear.setText("");
  CB_QRepayPeriod.setSelected(false); // TF_QRepayPeriodStartYear.setText(""); TF_QRepayPeriodEndYear.setText("");
  CB_QBillDate.setSelected(false); // TF_QBillDateStartYear.setText(""); TF_QBillDateEndYear.setText("");
  CB_QComment.setSelected(false); TF_QComment.setText("");
  CB_QCashComment.setSelected(false); TF_QCashComment.setText("");
  CB_QItemPrice.setSelected(false); TF_QItemPrice1.setText(""); TF_QItemPrice2.setText("");
  CB_QPaymentPrice.setSelected(false); TF_QPaymentPrice1.setText(""); TF_QPaymentPrice2.setText("");
  CB_QTransType.setSelected(false); CB_QTransTypeEmpty.setSelected(false); ListMdlQType.removeAll();
  CB_QSubject.setSelected(false); CB_QSubjectEmpty.setSelected(false); ListMdlQSubject.removeAll();
  CB_QSalesman.setSelected(false); CB_QSalesmanEmpty.setSelected(false); ListMdlQSalesman.removeAll();
  CB_QCash.setSelected(false); CB_QCashEmpty.setSelected(false); ListMdlQCash.removeAll();
  CB_QItem.setSelected(false); CB_QItemNon.setSelected(false); TableMdlQItem.removeAll();
  
  // table trans
  clearTableTrans(); PGUI.clearText(TF_Find);
  clearLastQuery();
  
  // tab detail, item in, item out, payment out, payment in
  clearDet();
  clearIn(); PGUI.clearText(TF_FindItemIn);
  clearOut(); PGUI.clearText(TF_FindItemOut);
  clearPaymentOut();
  clearPaymentIn();
  
  // tab Order
  clearListOrd(); PGUI.clearText(TF_OrdFind);
  
  // tabbed pane
  TabbedPane.setSelectedIndex(0);
 }
 
 //
 void updateTableTransView(boolean Requery){
  TableMdlTrans.updateColumnsInfo(TableMdlTransColsName, TableMdlTransColsType, TableMdlTransColsShowOption, TableMdlTransColsVisible, TableMdlTransColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Trans, TableTransColsWidth);
  if(!Requery){onSelectedRowTransChanged(false);}else{fillTableTrans();}
 }
 void buildTableTransViewColumnsByNormalMode(){
  Vector<Integer> ColsVisible=new Vector();
  Vector<Integer> ColsWidth=new Vector();
  
  // Check Sign Of TempList
  ColsWidth.addElement(25);
  
  // TransType
  ColsVisible.addElement(3); ColsWidth.addElement(CGUI.ColTextSml-35);
  
  // TransDate
  if(CB_ViewDate.isSelected()){ColsVisible.addElement(4); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_ViewDateBill.isSelected()){ColsVisible.addElement(5); ColsWidth.addElement(CGUI.ColDate);}
  if(CB_ViewDateRepayment.isSelected()){
   ColsVisible.addElement(6); ColsWidth.addElement(CGUI.ColDate);
   ColsVisible.addElement(7); ColsWidth.addElement(CGUI.ColDate);
  }
  
  // Subject
  if(CB_ViewSubject.isSelected()){ColsVisible.addElement(9); ColsWidth.addElement(CGUI.ColTextSml-35);}
  if(CB_ViewSalesman.isSelected()){ColsVisible.addElement(11); ColsWidth.addElement(CGUI.ColTextSml-35);}
  
  // Cash
  if(CB_ViewCashOut.isSelected()){ColsVisible.addElement(12); ColsWidth.addElement(CGUI.ColTextSml-35);}
  if(CB_ViewCashOutComment.isSelected()){ColsVisible.addElement(13); ColsWidth.addElement(CGUI.ColTextSml-35);}
  if(CB_ViewCashIn.isSelected()){ColsVisible.addElement(14); ColsWidth.addElement(CGUI.ColTextSml-35);}
  if(CB_ViewCashInComment.isSelected()){ColsVisible.addElement(15); ColsWidth.addElement(CGUI.ColTextSml-35);}
  
  // Id
  if(CB_ViewId.isSelected()){ColsVisible.addElement(0); ColsWidth.addElement(CGUI.ColNum16+35);}
  if(CB_ViewIdExternal.isSelected()){ColsVisible.addElement(1); ColsWidth.addElement(CGUI.ColNum16+35);}
  if(CB_ViewIsImportant.isSelected()){ColsVisible.addElement(2); ColsWidth.addElement(25);}
  
  // Item In & Item Out
  if(CB_ViewItemIn.isSelected()){
   ColsVisible.addElement(ColTransPriceItemIn); ColsWidth.addElement(CGUI.ColCur09_02-10);
   ColsVisible.addElement(ColTransPricePayOut); ColsWidth.addElement(CGUI.ColCur09_02-10);
  }
  if(CB_ViewItemOut.isSelected()){ColsVisible.addElement(ColTransPriceItemOut); ColsWidth.addElement(CGUI.ColCur09_02-10);}
  if(CB_ViewItemOutBasicPrice.isSelected()){ColsVisible.addElement(ColTransPriceItemOutBasic); ColsWidth.addElement(CGUI.ColCur09_02-10);}
  if(CB_ViewItemOut.isSelected()){ColsVisible.addElement(ColTransPricePayIn); ColsWidth.addElement(CGUI.ColCur09_02-10);}
  
  TableMdlTransColsVisible=PCore.primArr_VectInt(ColsVisible);
  TableTransColsWidth=PCore.primArr_VectInt(ColsWidth);
 }
 void buildTableTransColumns(){
  switch(CmB_ViewMode.getSelectedIndex()){
   case 0 :
    buildTableTransViewColumnsByNormalMode();
    break;
   case 1 :
    TableMdlTransColsVisible=PCore.primArr(3, 5, 6, 7, 0, 2, ColTransPriceItemIn, ColTransPricePayOut, ColTransPriceItemOut, ColTransPricePayIn);
    TableTransColsWidth=PCore.primArr(CGUI.ColCheck, CGUI.ColTextSml-20, CGUI.ColDate, CGUI.ColDate, CGUI.ColDate,
     CGUI.ColNum16+20, CGUI.ColCheck, CGUI.ColCur09_02, CGUI.ColCur09_02, CGUI.ColCur09_02, CGUI.ColCur09_02);
    break;
  }
 }
 void buildTableTransOrderBy(){
  switch(CmB_ViewMode.getSelectedIndex()){
   case 0 :
    LastQueryOrderBy=" order by "+QHavingTbl+".TransTypeName asc, "+QHavingTbl+".TransDate desc, "+QHavingTbl+".SubjectName asc, "+QHavingTbl+".BillDate asc, "+QHavingTbl+".Id desc";
    break;
   case 1 :
    LastQueryOrderBy=" order by "+QHavingTbl+".TransTypeName asc, "+QHavingTbl+".BillDate asc, "+QHavingTbl+".RepaymentPeriodStart asc, "+QHavingTbl+".RepaymentPeriodEnd asc, "+QHavingTbl+".Id asc";
    break;
  }
 }
 void buildTableTransViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableTransColumns();}
  if(RebuildOrderBy){buildTableTransOrderBy();}
 }
 void changeTableTransViewByNormalMode(){
  buildTableTransViewStructure(true, false);
  updateTableTransView(false);
 }
 void changeTableTransViewMode(){
  // change table view structure
  buildTableTransViewStructure(true, true);
  updateTableTransView(true);
  
  // change other GUI
  changeTableTransViewModeGUI();
 }
 void changeTableTransViewModeGUI(){
  boolean IsNormalMode=CmB_ViewMode.getSelectedIndex()==0;
  
  CB_ViewDate.setEnabled(IsNormalMode);
  CB_ViewDateBill.setEnabled(IsNormalMode);
  CB_ViewDateRepayment.setEnabled(IsNormalMode);
  
  CB_ViewSubject.setEnabled(IsNormalMode);
  CB_ViewSalesman.setEnabled(IsNormalMode);
  
  CB_ViewCashOut.setEnabled(IsNormalMode);
  CB_ViewCashOutComment.setEnabled(IsNormalMode);
  CB_ViewCashIn.setEnabled(IsNormalMode);
  CB_ViewCashInComment.setEnabled(IsNormalMode);
  
  CB_ViewId.setEnabled(IsNormalMode);
  CB_ViewIdExternal.setEnabled(IsNormalMode);
  CB_ViewIsImportant.setEnabled(IsNormalMode);
  
  CB_ViewItemIn.setEnabled(IsNormalMode);
  CB_ViewItemOut.setEnabled(IsNormalMode);
  CB_ViewItemOutBasicPrice.setEnabled(IsNormalMode);
 }
 
 void updateTableItemInView(boolean Requery){
  int RowTrans=Tbl_Trans.getSelectedRow();
  long Id;
  
  TableMdlIn.updateColumnsInfo(TableMdlItemInColsName, TableMdlItemInColsType, TableMdlItemInColsShowOption,
   TableMdlItemInColsVisible, TableMdlItemInColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_In, TableItemInColsWidth);
  if(!Requery){onSelectedRowInChanged(false);}
  else{
   RowTrans=Tbl_Trans.getSelectedRow();
   Id=-1; if(RowTrans!=-1){Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(RowTrans)[0];}
   fillIn(Id);
  }
 }
 void buildTableItemInColumns(){
  boolean IsCategorized=CB_ItemInCategorized.isSelected();
  TableMdlItemInColsVisible=PCore.primArr(2, 3, 6, 5);
  TableItemInColsWidth=PCore.primArr(25, 260, 40, 75, 85);
  if(!IsCategorized){
   TableMdlItemInColsVisible=PCore.insert(TableMdlItemInColsVisible, TableMdlItemInColsVisible.length, 0);
   TableItemInColsWidth=PCore.insert(TableItemInColsWidth, TableItemInColsWidth.length, 95);
  }
  else{
   TableMdlItemInColsVisible=PCore.insert(TableMdlItemInColsVisible, 0, 9);
   TableItemInColsWidth=PCore.insert(TableItemInColsWidth, 1, 130);
  }
 }
 void buildTableItemInOrderBy(){
  boolean IsCategorized=CB_ItemInCategorized.isSelected();
  QueryItemInOrderBy=PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }
 void buildTableItemInViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableItemInColumns();}
  if(RebuildOrderBy){buildTableItemInOrderBy();}
 }
 void changeItemInViewByCategorized(){
  buildTableItemInViewStructure(true, true);
  updateTableItemInView(true);
 }
 
 void updateTableItemOutView(boolean Requery){
  int RowTrans=Tbl_Trans.getSelectedRow();
  long Id;
  
  TableMdlOut.updateColumnsInfo(TableMdlItemOutColsName, TableMdlItemOutColsType, TableMdlItemOutColsShowOption,
   TableMdlItemOutColsVisible, TableMdlItemOutColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Out, TableItemOutColsWidth);
  if(!Requery){onSelectedRowOutChanged(false);}
  else{
   RowTrans=Tbl_Trans.getSelectedRow();
   Id=-1; if(RowTrans!=-1){Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(RowTrans)[0];}
   fillOut(Id);
  }
 }
 void buildTableItemOutColumns(){
  boolean IsCategorized=CB_ItemOutCategorized.isSelected();
  boolean IsShowBasicPrice=CB_ItemOutShowBasicPrice.isSelected();
  if(!IsShowBasicPrice){
   TableMdlItemOutColsVisible=PCore.primArr(2, 3, 6, 5);
   TableItemOutColsWidth=PCore.primArr(25, 260, 40, 75, 85);
  }
  else{
   TableMdlItemOutColsVisible=PCore.primArr(2, 3, 5, 11);
   TableItemOutColsWidth=PCore.primArr(25, 260, 40, 85, 85);
  }
  if(!IsCategorized){
   TableMdlItemOutColsVisible=PCore.insert(TableMdlItemOutColsVisible, TableMdlItemOutColsVisible.length, 0);
   TableItemOutColsWidth=PCore.insert(TableItemOutColsWidth, TableItemOutColsWidth.length, 95);
  }
  else{
   TableMdlItemOutColsVisible=PCore.insert(TableMdlItemOutColsVisible, 0, 9);
   TableItemOutColsWidth=PCore.insert(TableItemOutColsWidth, 1, 130);
  }
 }
 void buildTableItemOutOrderBy(){
  boolean IsCategorized=CB_ItemOutCategorized.isSelected();
  QueryItemOutOrderBy=PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryOfItem.Name asc, ItemName asc");
 }
 void buildTableItemOutViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableItemOutColumns();}
  if(RebuildOrderBy){buildTableItemOutOrderBy();}
 }
 void changeItemOutViewByHPP(){
  buildTableItemOutViewStructure(true, false);
  updateTableItemOutView(false);
 }
 void changeItemOutViewByCategorized(){
  buildTableItemOutViewStructure(true, true);
  updateTableItemOutView(true);
 }
 
 void updateTableOrdView(boolean Requery){
  TableMdlOrd.updateColumnsInfo(TableMdlOrdColsName, TableMdlOrdColsType, TableMdlOrdColsShowOption,
   TableMdlOrdColsVisible, TableMdlOrdColsEditable, Requery);
  PGUI.resizeTableColumn(Tbl_Ord, TableOrdColsWidth);
  if(!Requery){onSelectedRowOrdChanged(false);}else{fillListOrd(0);}
 }
 void buildTableOrdColumns(){
  boolean IsCategorized=CB_OrdCategorized.isSelected();
  
  TableMdlOrdColsVisible=PCore.primArr(1, 3, 6);
  TableOrdColsWidth=PCore.primArr(260, 40, 85);
  
  if(!IsCategorized){
   TableMdlOrdColsVisible=PCore.insert(TableMdlOrdColsVisible, TableMdlOrdColsVisible.length, 0);
   TableOrdColsWidth=PCore.insert(TableOrdColsWidth, TableOrdColsWidth.length, 95);
  }
  else{
   TableMdlOrdColsVisible=PCore.insert(TableMdlOrdColsVisible, 0, 2);
   TableOrdColsWidth=PCore.insert(TableOrdColsWidth, 0, 130);
  }
 }
 void buildTableOrdOrderBy(){
  boolean IsCategorized=CB_OrdCategorized.isSelected();
  QueryOrdOrderBy=PText.getString(!IsCategorized, " order by ItemName asc", " order by CategoryName asc, ItemName asc");
 }
 void buildTableOrdViewStructure(boolean RebuildColumns, boolean RebuildOrderBy){
  if(RebuildColumns){buildTableOrdColumns();}
  if(RebuildOrderBy){buildTableOrdOrderBy();}
 }
 void changeOrdViewByCategorized(){
  buildTableOrdViewStructure(true, true);
  updateTableOrdView(true);
 }
 void changeOrdViewByPriceEst(){
  buildTableOrdViewStructure(true, false);
  updateTableOrdView(false);
 }
 
 //
	void setLastQuery(int Limit,
  String StaticSourceTable, String StaticCondition, boolean StaticConditionDefined, String StaticPostCondition, boolean StaticPostConditionDefined,
  int DynamicTempList,
  boolean WithAdditionalFilter){
  LQ_Limit=Limit;
		
  LQ_StaticSourceTable=StaticSourceTable;
		LQ_StaticCondition=StaticCondition; LQ_StaticConditionDefined=StaticConditionDefined;
		LQ_StaticPostCondition=StaticPostCondition; LQ_StaticPostConditionDefined=StaticPostConditionDefined;
  
  LQ_DynamicTempList=DynamicTempList;
  
  LQ_WithAdditionalFilter=WithAdditionalFilter;
  
  LastQueryDefined=true;
 }
 void clearLastQuery(){
  LastQueryDefined=false;
 }
 
 // on event
 void onSelectedRowViewModeChanged(){
  if(CmB_ViewMode.getSelectedIndex()==LastViewMode){return;}
  
  LastViewMode=CmB_ViewMode.getSelectedIndex();
  
  changeTableTransViewMode();
 }
 void onTabbedPaneChanged(){
  int CurrTab=TabbedPane.getSelectedIndex();
  int row;
  do{
   if(CurrTab==0){focusQuery(); break;}
   if(CurrTab==6){fillListOrd(1); break;}
   
   row=Tbl_Trans.getSelectedRow();
   if(row!=-1){fillAnActiveTab(CurrTab, (Long)TableMdlTrans.Mdl.Rows.elementAt(row)[0]);}
   else{clearAnActiveTab(CurrTab);}
  }while(false);
 }
 void onSelectedRowTransChanged(boolean UpdateAnyway){
  int row=Tbl_Trans.getSelectedRow();
  int tab;
  if(row!=LastSelectedRowTrans || UpdateAnyway){
   LastSelectedRowTrans=row;
   clearRequeryIndex();
   tab=TabbedPane.getSelectedIndex();
   if(tab!=0 && tab!=6){
    if(row!=-1){fillAnActiveTab(tab, (Long)TableMdlTrans.Mdl.Rows.elementAt(row)[0]);}
    else{clearAnActiveTab(tab);}
   }
  }
 }
 void onSelectedRowInChanged(boolean UpdateAnyway){
  int row=Tbl_In.getSelectedRow();
  if(LastSelectedRowIn!=row || UpdateAnyway){
   LastSelectedRowIn=row;
   if(row!=-1){fillInfoIn(row);}
   else{clearInfoIn();}
  }
 }
 void onSelectedRowOutChanged(boolean UpdateAnyway){
  int row=Tbl_Out.getSelectedRow();
  if(LastSelectedRowOut!=row || UpdateAnyway){
   LastSelectedRowOut=row;
   if(row!=-1){fillInfoOut(row);}
   else{clearInfoOut();}
  }
 }
 void onSelectedRowPaymentOutChanged(boolean UpdateAnyway){
  int row=Tbl_PaymentOut.getSelectedRow();
  if(LastSelectedRowPayOut!=row || UpdateAnyway){
   LastSelectedRowPayOut=row;
   if(row!=-1){fillInfoPaymentOut(row);}
   else{clearInfoPaymentOut();}
  }
 }
 void onSelectedRowPaymentInChanged(boolean UpdateAnyway){
  int row=Tbl_PaymentIn.getSelectedRow();
  if(LastSelectedRowPayIn!=row || UpdateAnyway){
   LastSelectedRowPayIn=row;
   if(row!=-1){fillInfoPaymentIn(row);}
   else{clearInfoPaymentIn();}
  }
 }
 void onSelectedRowOrdChanged(boolean UpdateAnyway){
  int row=Tbl_Ord.getSelectedRow();
  if(LastSelectedRowOrd!=row || UpdateAnyway){
   LastSelectedRowOrd=row;
   if(row!=-1){fillInfoOrd(row);}
   else{clearInfoOrd();}
  }
 }
 void onEditingTableOrd(){
  int Row, Col;
  boolean IsSame, valid;
  double OrderQty=0;
  
  Row=Tbl_Ord.Editing_Row;
  Col=TableMdlOrd.convertColumnIndexFromViewToModel(Tbl_Ord.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdlOrd.Mdl.ColumnsType[Col], null, Tbl_Ord.Editing_ValueOld, true, null, Tbl_Ord.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  valid=true;
  switch(Col){
   case 3 :
    OrderQty=PCore.objDouble(Tbl_Ord.Editing_ValueNew, -1D);
    if(OrderQty<=0){valid=false;}
    break;
  }
  if(!valid){
   JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");
   return;
  }
  
  editOrders(PCore.primArr(Row), OrderQty);
 }
 void onEditingTableTrans(){
  int Row, Col, result;
  boolean IsSame;
  
  Row=Tbl_Trans.Editing_Row;
  Col=TableMdlTrans.convertColumnIndexFromViewToModel(Tbl_Trans.Editing_Col);
  
  if(Col!=-1){
   IsSame=PCore.grading(TableMdlTrans.Mdl.ColumnsType[Col], null, Tbl_Trans.Editing_ValueOld, true, null, Tbl_Trans.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(Col==-1){result=onEditingTableTrans_Check(Row); break;}
   result=onEditingTableTrans_Trans(Row, Col); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut "+TransName+" !");}
 }
 int onEditingTableTrans_Check(int Row){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  fillTempList(PGUI.getIdsFromSelectedRows(TableMdlTrans, PCore.primArr(Row), 0), PCore.objBoolean(Tbl_Trans.Editing_ValueNew, false));
   
  return ret;
 }
 int onEditingTableTrans_Trans(int Row, int Col){
  int ret=0; // 0 success, -1 error, -2 invalid input
  
  // not implemented yet
  
  return ret;
 }
 void onEditingTableItem(boolean IsItemIn){
  int ItemRow, ItemCol;
  int result=0;
  boolean IsSame;
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  OCustomTableModel TableMdl=(OCustomTableModel)PCore.subtituteBool(IsItemIn, TableMdlIn, TableMdlOut);
  int TransRow;
  
  TransRow=Tbl_Trans.getSelectedRow();
  ItemRow=Tbl.Editing_Row;
  ItemCol=TableMdl.convertColumnIndexFromViewToModel(Tbl.Editing_Col);
  
  if(TransRow==-1){return;}
  
  if(ItemCol!=-1){
   IsSame=PCore.grading(TableMdl.Mdl.ColumnsType[ItemCol], null, Tbl.Editing_ValueOld, true, null, Tbl.Editing_ValueNew, true, null)==0;
   if(IsSame){return;}
  }
  
  do{
   if(ItemCol==-1){result=onEditingTableItem_Check(IsItemIn, TransRow, ItemRow); break;}
   result=onEditingTableItem_Item(IsItemIn, TransRow, ItemRow, ItemCol); break;
  }while(false);
  if(result==-2){JOptionPane.showMessageDialog(null, "Inputan data di dalam cell belum benar !");}
  else if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengubah nilai atribut barang !");}
 }
 int onEditingTableItem_Check(boolean IsItemIn, int TransRow, int ItemRow){
  int ret=0;
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  
  checkItems(IsItemIn, PCore.primArr(ItemRow), PCore.objBoolean(Tbl.Editing_ValueNew, false));
  
  return ret;
 }
 int onEditingTableItem_Item(boolean IsItemIn, int TransRow, int ItemRow, int ItemCol){
  int ret=0;
  boolean valid;
  OEditTransItem Edit;
  XTable Tbl=(XTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  
  do{
   Edit=new OEditTransItem();
   valid=true;
   switch(ItemCol){
    // double not null, positive only, >0
    case 3 : Edit.EditQuantity=true; Edit.EditedQuantity=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedQuantity<=0){valid=false;} break;

    // double not null, positive only, >=0
    case 5 : Edit.EditPriceTotal=true; Edit.EditedPriceTotal=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedPriceTotal<0){valid=false;} break;
    case 6 : Edit.EditPriceUnit=true; Edit.EditedPriceUnit=PCore.objDouble(Tbl.Editing_ValueNew, -1D); if(Edit.EditedPriceUnit<0){valid=false;} break;
   }
   if(!valid){ret=-2; break;}

   editItems(IsItemIn, TransRow, PCore.primArr(ItemRow), Edit);
  }while(false);
  
  return ret;
 }
 
 // fill-clear
 void clearRequeryIndex(){
  if(!TIRequeryAll){
   TIDet=false;
   TIIn=false;
   TIOut=false;
   TIPayOut=false;
   TIPayIn=false;
   TIRequeryAll=true;
  }
 }
 void updateTempListQuantity(){TF_TempListQuantity.setText(PText.intToString(TempList.ElementsCount));}
 void fillTempList(long[] Data, boolean IsAdd){
  long[] AffectItems;
  
  if(Data.length==0){return;}
  
  AffectItems=PCore.subArr(Data, TempList.addElements(Data, IsAdd));
  if(AffectItems.length==0){return;}
  
  updateTempListQuantity();
  fillSignData(AffectItems, IsAdd);
 }
 void clearTempList(){
  TempList.removeAll();
  updateTempListQuantity();
  
  clearSignData();
 }
 void refreshQueryCount(){TF_ListCount.setText(PText.intToString(TableMdlTrans.getRowCount()));}
 void fillTableTrans(){
  String Query, Limit;
  long[] tlist;
  StringBuilder DynamicSourceTable, DynamicCondition, DynamicPostCondition;
  StringBuilder AdditionalSourceTable, AdditionalCondition, AdditionalPostCondition;
  boolean con_defined, conpost_defined;
  
  clearTableTrans();
  
  if(!LastQueryDefined){return;}
  
  Query=null;
  do{
   // build query
   con_defined=LQ_StaticConditionDefined; conpost_defined=LQ_StaticPostConditionDefined;
   
    // build dynamic filter
   DynamicSourceTable=new StringBuilder(); DynamicCondition=new StringBuilder(); DynamicPostCondition=new StringBuilder();
   if(LQ_DynamicTempList!=0){
    if(TempList.ElementsCount==0){if(LQ_DynamicTempList==1){break;}}
    else{
     if(!con_defined){con_defined=true; DynamicCondition.append(" where");}else{DynamicCondition.append(" and");}
     tlist=TempList.getElements();
     DynamicCondition.append(" "+DbTable+".Id"+PText.getString(LQ_DynamicTempList, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
    }
   }
   
    // build additional filter
   AdditionalSourceTable=new StringBuilder(); AdditionalCondition=new StringBuilder(); AdditionalPostCondition=new StringBuilder();
   if(LQ_WithAdditionalFilter){
    if(LastResultFilterSubset!=0){
     if(LastResultFilterSubset!=LQ_DynamicTempList){
      if(LQ_DynamicTempList!=0){break;}
      if(TempList.ElementsCount==0){if(LastResultFilterSubset==1){break;}}
      else{
       if(!con_defined){con_defined=true; AdditionalCondition.append(" where");}else{AdditionalCondition.append(" and");}
       tlist=TempList.getElements();
       AdditionalCondition.append(" "+DbTable+".Id"+PText.getString(LastResultFilterSubset, 1, 2, " in", " not in", null)+
      "("+PText.toString(tlist, 0, tlist.length, ",")+")");
      }
     }
    }
   }
   
   Limit=PText.getString(LQ_Limit, 0, " limit "+LQ_Limit, "");
   
   /*
    the operation of select that have changeable conditions should assign the name of its static columns accompanied by its static tables,
    because there can be ambiguous column name, if other additional tables have the same column name as static tables
    
    for example :
    "select StaticColumn_Id, StaticColumn_Name, StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...> ,
    ~ should be changed into
    "select StaticTable.StaticColumn_Id, StaticTable.StaticColumn_Name, StaticTable.StaticColumn_Active" from StaticTable <, AdditionalTable...> <where conditions...>
    ~ to prevent ambiguous interpretation of column name between static table & additional table
   */
   
   Query=
				"select tb7.*, Sum("+DbTable+"XPaymentIn.Price) as 'PricePaymentIn' from "+
    "(select tb6.*, Sum("+DbTable+"XPayment.Price) as 'PricePaymentOut' from "+
     "(select tb5.Id, tb5.InfoIdExternal, tb5.IsImportant, tb5.TransTypeName, "+
       "tb5.TransDate, tb5.BillDate, tb5.RepaymentPeriodStart, tb5.RepaymentPeriodEnd, "+
       "tb5.Subject, tb5.SubjectName, tb5.Salesman, tb5.SalesmanName, tb5.CashOutName, tb5.CashOutComment, tb5.CashInName, tb5.CashInComment, "+
       "PriceItemIn, Sum(tb5.ItemOut_Price) as 'PriceItemOut', Sum(tb5.ItemOut_Stock*BuyPriceEstimation) as 'BasicPriceItemOut' from "+
      "(select tb4.*, "+DbTable+"XItemOut.Item as 'ItemOut_Item', "+DbTable+"XItemOut.Stock as 'ItemOut_Stock', "+DbTable+"XItemOut.Price as 'ItemOut_Price' from "+
        "(select tb3.*, Sum("+DbTable+"XItemIn.Price) as 'PriceItemIn' from "+
         "(select tb2.*, Subject.Name as 'SalesmanName', Cash.Name as 'CashInName' from "+
          "(select tb1.*, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName', Cash.Name as 'CashOutName' from "+
            "(select "+DbTable+".*, "+
             "if("+DbTable+".CreditDays is "+CCore.vNull+", "+CCore.vNull+", Date_Add("+DbTable+".TransDate, Interval ifnull("+DbTable+".CreditDays, 0) Day)) as 'BillDate' "+
            "from "+DbTable+LQ_StaticSourceTable+DynamicSourceTable.toString()+AdditionalSourceTable.toString()+
             LQ_StaticCondition+DynamicCondition.toString()+AdditionalCondition.toString()+") as tb1 "+
          "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id left join Cash on tb1.Cash=Cash.Id) as tb2 "+
         "left join Subject on tb2.Salesman=Subject.Id left join Cash on tb2.CashIn=Cash.Id) as tb3 "+
        "left join "+DbTable+"XItemIn on tb3.Id="+DbTable+"XItemIn."+DbTable+" group by tb3.Id) as tb4 "+
      "left join "+DbTable+"XItemOut on tb4.Id="+DbTable+"XItemOut."+DbTable+") as tb5 "+
     "left join Item on tb5.ItemOut_Item=Item.Id group by tb5.Id) as tb6 "+
    "left join "+DbTable+"XPayment on tb6.Id="+DbTable+"XPayment."+DbTable+" group by tb6.Id) as tb7 "+
   "left join "+DbTable+"XPaymentIn on tb7.Id="+DbTable+"XPaymentIn."+DbTable+" group by tb7.Id "+
   LQ_StaticPostCondition+DynamicPostCondition.toString()+AdditionalPostCondition.toString()+
   LastQueryOrderBy+Limit;
  }while(false);
  
  if(Query==null){return;}
  if(PDatabase.queryToTableWithSum(IFV.Stm, Query, TableMdlTrans, SumColumn, SumResult, false, true, TempList, 0, false, -1)==-1){
   JOptionPane.showMessageDialog(null, "Gagal mengambil data dari database !");
  }
  refreshQueryCount();
  updateItemInSum(SumResult[ColTransPriceItemIn], true);
  updateItemOutSum(SumResult[ColTransPriceItemOut], true);
  updateItemOutBasicSum(SumResult[ColTransPriceItemOutBasic], true);
  updatePaymentOutSum(SumResult[ColTransPricePayOut], true);
  updatePaymentInSum(SumResult[ColTransPricePayIn], true);

  updateQueryTempListCount();
 }
 void clearTableTrans(){
  TableMdlTrans.removeAll();
  refreshQueryCount();
  clearTransAdditionalInfo();
  
  clearSignData();
  
  onSelectedRowTransChanged(true);
 }
 void clearTransAdditionalInfo(){
  ItemInPriceSum=0; TF_ItemInSum.setText("0");
  ItemOutPriceSum=0; TF_ItemOutSum.setText("0");
  ItemOutPriceBasicSum=0; refreshItemOutBasicSum();
  PaymentOutSum=0; TF_PaymentOutSum.setText("0");
  PaymentInSum=0; TF_PaymentInSum.setText("0");
 }
 void updateQueryTempListCount(){TF_QueryTempListCount.setText("( "+PText.intToString(TableMdlTrans.getCheckedCount())+" )");}
 void refreshItemOutBasicSum(){TF_ItemOutBasicSum.setText(PText.getString(CB_ItemOutBasicSum.isSelected(), PText.priceToString(ItemOutPriceBasicSum), ""));}
 void fillSignData(long[] Data, boolean SignValue){
  TableMdlTrans.check(Data, SignValue, 0);
  updateQueryTempListCount();
 }
 void clearSignData(){
  TableMdlTrans.checkAll(false);
  updateQueryTempListCount();
 }
 void updateItemInSum(double Price, boolean IsAdd){
  if(IsAdd){ItemInPriceSum=ItemInPriceSum+Price;}else{ItemInPriceSum=ItemInPriceSum-Price;}
  TF_ItemInSum.setText(PText.priceToString(ItemInPriceSum));
 }
 void updateItemOutSum(double Price, boolean IsAdd){
  if(IsAdd){ItemOutPriceSum=ItemOutPriceSum+Price;}else{ItemOutPriceSum=ItemOutPriceSum-Price;}
  TF_ItemOutSum.setText(PText.priceToString(ItemOutPriceSum));
 }
 void updateItemOutBasicSum(double Price, boolean IsAdd){
  if(IsAdd){ItemOutPriceBasicSum=ItemOutPriceBasicSum+Price;}else{ItemOutPriceBasicSum=ItemOutPriceBasicSum-Price;}
  refreshItemOutBasicSum();
 }
 void updatePaymentOutSum(double Price, boolean IsAdd){
  if(IsAdd){PaymentOutSum=PaymentOutSum+Price;}else{PaymentOutSum=PaymentOutSum-Price;}
  TF_PaymentOutSum.setText(PText.priceToString(PaymentOutSum));
 }
 void updatePaymentInSum(double Price, boolean IsAdd){
  if(IsAdd){PaymentInSum=PaymentInSum+Price;}else{PaymentInSum=PaymentInSum-Price;}
  TF_PaymentInSum.setText(PText.priceToString(PaymentInSum));
 }
 void updateTransItemInPrice(int TransRow, boolean Null, double Price, boolean IsAdd){
  Object[] UpdateRow; Double dbl; int col=ColTransPriceItemIn;
  UpdateRow=TableMdlTrans.Mdl.Rows.elementAt(TransRow);
  if(Null){dbl=null;}else{dbl=PCore.objDouble(UpdateRow[col], 0D); if(IsAdd){dbl=dbl+Price;}else{dbl=dbl-Price;}}
		UpdateRow[col]=dbl;
  TableMdlTrans.changeValue(TransRow, UpdateRow);
  
  updateItemInSum(Price, IsAdd);
 }
 void updateTransItemOutPrice(int TransRow, boolean Null, double Price, boolean IsAdd){
  Object[] UpdateRow; Double dbl; int col=ColTransPriceItemOut;
  UpdateRow=TableMdlTrans.Mdl.Rows.elementAt(TransRow);
  if(Null){dbl=null;}else{dbl=PCore.objDouble(UpdateRow[col], 0D); if(IsAdd){dbl=dbl+Price;}else{dbl=dbl-Price;}}
		UpdateRow[col]=dbl;
  TableMdlTrans.changeValue(TransRow, UpdateRow);
  
  updateItemOutSum(Price, IsAdd);
 }
 void updateTransItemOutBasicPrice(int TransRow, boolean Null, double Price, boolean IsAdd){
  Object[] UpdateRow; Double dbl; int col=ColTransPriceItemOutBasic;
  UpdateRow=TableMdlTrans.Mdl.Rows.elementAt(TransRow);
  if(Null){dbl=null;}else{dbl=PCore.objDouble(UpdateRow[col], 0D); if(IsAdd){dbl=dbl+Price;}else{dbl=dbl-Price;}}
		UpdateRow[col]=dbl;
  TableMdlTrans.changeValue(TransRow, UpdateRow);
  
  updateItemOutBasicSum(Price, IsAdd);
 }
 void updateTransPaymentOutPrice(int TransRow, boolean Null, double Price, boolean IsAdd){
  Object[] UpdateRow; Double dbl; int col=ColTransPricePayOut;
  UpdateRow=TableMdlTrans.Mdl.Rows.elementAt(TransRow);
  if(Null){dbl=null;}else{dbl=PCore.objDouble(UpdateRow[col], 0D); if(IsAdd){dbl=dbl+Price;}else{dbl=dbl-Price;}}
		UpdateRow[col]=dbl;
  TableMdlTrans.changeValue(TransRow, UpdateRow);
  
  updatePaymentOutSum(Price, IsAdd);
 }
 void updateTransPaymentInPrice(int TransRow, boolean Null, double Price, boolean IsAdd){
  Object[] UpdateRow; Double dbl; int col=ColTransPricePayIn;
  UpdateRow=TableMdlTrans.Mdl.Rows.elementAt(TransRow);
  if(Null){dbl=null;}else{dbl=PCore.objDouble(UpdateRow[col], 0D); if(IsAdd){dbl=dbl+Price;}else{dbl=dbl-Price;}}
		UpdateRow[col]=dbl;
  TableMdlTrans.changeValue(TransRow, UpdateRow);
  
  updatePaymentInSum(Price, IsAdd);
 }
 String getStringOfCash(int CashId, String CashName, String CashComment){
  StringBuilder ret;
  boolean first;
  
  ret=new StringBuilder(); first=true;
  if(CashId!=-1){
   if(first){first=false;}else{ret.append("\n");} ret.append(CashName);
  }
  if(!PText.isEmptyString(CashComment, false, true)){
   if(first){first=false;}else{ret.append("\n");} ret.append("{ "+CashComment+" }");
  }
  
  return ret.toString();
 }
 void fillDet(long TransId){
  OInfoTrans InfoTrans;
  
  if(TransId==-1){clearDet(); return;}
  
  InfoTrans=PMyShop.getTransInfo(IFV.Stm, wIsPreTrans, TransId);
  if(InfoTrans!=null){
   TF_DetId.setText(PText.separate(String.valueOf(TransId), " - ", PCore.primArr(4, 2, 2, 4, 4)));
   CB_DetImportant.setSelected(InfoTrans.Important);
   TF_DetIdExternal.setText(PText.getString(InfoTrans.InfoIdExternal, "", true));
   TF_DetDate.setText(PText.dateToString(InfoTrans.Dt, 2));
   if(InfoTrans.TypeId==-1){TF_DetTransType.setText("");}else{TF_DetTransType.setText(InfoTrans.TypeName);}
   TF_DetCashIn.setText(getStringOfCash(InfoTrans.CashInId, InfoTrans.CashInName, InfoTrans.CashInComment));
   TF_DetCashOut.setText(getStringOfCash(InfoTrans.CashOutId, InfoTrans.CashOutName, InfoTrans.CashOutComment));
   if(InfoTrans.SubjectId==-1){TF_DetSubject.setText("");}else{TF_DetSubject.setText(InfoTrans.SubjectName);}
   if(InfoTrans.SalesmanId==-1){TF_DetSalesman.setText("");}else{TF_DetSalesman.setText(InfoTrans.SalesmanName);}
   if(InfoTrans.CreditDays==-1){TF_DetCreditDays.setText("");}else{TF_DetCreditDays.setText(InfoTrans.CreditDays+" hari ("+
				PText.dateToString(PDate.calculateDateByDay(InfoTrans.Dt, InfoTrans.CreditDays, 1), 2)+")");}
			TF_DetRepaymentPeriod.setText(PText.getString(InfoTrans.RepaymentPeriodStart==null || InfoTrans.RepaymentPeriodEnd==null, "",
				PText.dateToString(InfoTrans.RepaymentPeriodStart, 2)+" - "+PText.dateToString(InfoTrans.RepaymentPeriodEnd, 2)));
   if(InfoTrans.Comment==null){TA_DetComment.setText("");}else{TA_DetComment.setText(InfoTrans.Comment);}
   TIDet=true;
   TIDetClear=false;
   if(TIRequeryAll){TIRequeryAll=false;}
  }
  else{
   JOptionPane.showMessageDialog(null, "Gagal mengambil keterangan "+TransName+" dari database !");
   clearDet();
  }
 }
 void clearDet(){
  if(TIDetClear==false){
   TF_DetId.setText("");
   CB_DetImportant.setSelected(false);
   TF_DetIdExternal.setText("");
   TF_DetDate.setText("");
   TF_DetTransType.setText("");
   TF_DetCashIn.setText("");
   TF_DetCashOut.setText("");
   TF_DetSubject.setText("");
   TF_DetSalesman.setText("");
   TF_DetCreditDays.setText("");
			TF_DetRepaymentPeriod.setText("");
   TA_DetComment.setText("");
   TIDetClear=true;
  }
 }
 void refreshItemCount(JTextField TF_ItemCount, OCustomTableModel TableMdlItem){
  TF_ItemCount.setText(PText.intToString(TableMdlItem.getRowCount())+"  ( "+PText.intToString(TableMdlItem.getCheckedCount())+" )");
 }
 String queryOfItemIn(long TransId, long[] ItemsId){
  String con=""; if(ItemsId!=null){con=" and Item in("+PText.toString(ItemsId, 0, ItemsId.length, ",")+")";}
  return
   "select TransItem, ItemName, ItemNm, TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, PictureFile, Min(CategoryOfItem.Name) as 'CategoryName', TransItemChecked from "+
    "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
     "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
      "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit from "+
       "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
       "from "+DbTable+"XItemIn where "+DbTable+"="+TransId+con+") as tb1 "+
      "left join Item on tb1.TransItem=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
    "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem) as tb4 "+
   "left join ItemXCategory on tb4.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.TransItem"+
   QueryItemInOrderBy;
 }
 void fillIn(long TransId){
  int datacount;
  
  clearIn(); if(TransId==-1){return;}
  
  // fetch list data
  datacount=PDatabase.queryToTable(IFV.Stm, queryOfItemIn(TransId, null), TableMdlIn, false, false, null, -1, true, 10);
  TIInClear=false;
  if(datacount!=-1){
   TIIn=true;
   if(TIRequeryAll==true){TIRequeryAll=false;}
   refreshItemCount(TF_InCount, TableMdlIn);
   if(datacount>0){
    Tbl_In.changeSelection(0, 0, false, false);
    onSelectedRowInChanged(false);
   }
   else{
    clearInfoIn();
   }
  }
  else{
   clearIn();
   JOptionPane.showMessageDialog(null, "Gagal mengambil 'daftar barang masuk' dari database !");
  }
 }
 void clearIn(){
  if(TIInClear==false){
   TableMdlIn.removeAll();
   refreshItemCount(TF_InCount, TableMdlIn);
   LastSelectedRowIn=-1;
   clearInfoIn();
   TIInClear=true;
  }
 }
 void fillInfoIn(int row){
  Object[] objs=TableMdlIn.Mdl.Rows.elementAt(row);
  TF_InInfoCategory.setText(PCore.objString(objs[9], ""));
  TF_InInfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemInPreview, IFV.Conf.ImageDirItem, objs[8]);
  InfoInClear=false;
 }
 void clearInfoIn(){
  if(InfoInClear==false){
   TF_InInfoCategory.setText("");
   TF_InInfoName.setText("");
   PGUI.fillPanelPictureURL(Pnl_ItemInPreview, IFV.Conf.ImageDirItem, null);
   InfoInClear=true;
  }
 }
 void addReplaceItemIn(int TransRow, Vector<Object[]> NewData){
  String TbTransItemIn=DbTable+"XItemIn";
  int length, temp;
  double PriceOld, PriceNew;
  Object[] objs_old;
  Object[] objs_new=null;
  int foundindex;
  long ItemId;
  String ItemName;
  double PriceAdd;
  long TransId;
  boolean ProcessedInTab=TIIn || TabbedPane.getSelectedIndex()==2;
  boolean PriceNewNull;
  String FindName=null;
  int FindColumn=0;
  boolean IsCategorized=CB_ItemInCategorized.isSelected();
  
  length=NewData.size();
  if(length==0){return;}
  
  PriceOld=0; PriceNew=0; PriceNewNull=false;
  
  if(ProcessedInTab){
   temp=0; if(!IsCategorized){FindColumn=1;}else{FindColumn=9;}
   do{
    objs_new=NewData.elementAt(temp);

    ItemId=(Long)objs_new[0];
    foundindex=PTable.findNumber(TableMdlIn.Mdl.Rows, ItemId, 0, false, 0, TableMdlIn.Mdl.Rows.size());
    if(foundindex!=-1){
     objs_old=TableMdlIn.Mdl.Rows.elementAt(foundindex);
     PriceOld=PriceOld+(Double)objs_old[5];
     TableMdlIn.changeValue(foundindex, objs_new);
    }
    else{
     FindName=PCore.objString(objs_new[FindColumn], null);
     foundindex=PGUI.findInsertPos(TableMdlIn, FindColumn, FindName, false, true, true);
     TableMdlIn.insert(foundindex, objs_new);
    }
    PriceNew=PriceNew+(Double)objs_new[5];

    temp=temp+1;
   }while(temp!=length);
   TIIn=true; TIInClear=false; TIRequeryAll=false;
   onSelectedRowInChanged(true);
   refreshItemCount(TF_InCount, TableMdlIn);
  }
  
  if(!ProcessedInTab){
   objs_old=TableMdlTrans.Mdl.Rows.elementAt(TransRow);
   PriceOld=PCore.objDouble(objs_old[ColTransPriceItemIn], 0D);
   try{
    TransId=(Long)objs_old[0];
    objs_new=PDatabase.getFirstRecords(IFV.Stm,
     "select sum(Price) from "+TbTransItemIn+" where "+DbTable+"="+TransId,
     PCore.primArr(0), PCore.primArr(CCore.TypeDouble));
    
    PriceNewNull=true;
    if(objs_new!=null){if(objs_new[0]!=null){PriceNew=(Double)objs_new[0]; PriceNewNull=false;}}
   }
   catch(Exception E){
    PriceNew=PriceOld;
    PriceNewNull=objs_old[ColTransPriceItemIn]==null;
   }
  }
  PriceAdd=PriceNew-PriceOld;
  updateTransItemInPrice(TransRow, PriceNewNull, PriceAdd, true);
 }
 String queryOfItemOut(long TransId, long[] ItemsId){
  String con=""; if(ItemsId!=null){con=" and Item in("+PText.toString(ItemsId, 0, ItemsId.length, ",")+")";}
  return
   "select TransItem, ItemName, ItemNm, TransItemQty, ItemStockUnitName, TransItemPriceTotal, TransItemPriceUnit, TransItemComment, PictureFile, Min(CategoryOfItem.Name) as 'CategoryName', BuyPriceEstimation, TransItemPriceTotalBasic, TransItemChecked from "+
    "(select tb3.*, Min(ItemXPicture.FileName) as 'PictureFile' from "+
     "(select tb2.*, StockUnit.Name as 'ItemStockUnitName' from "+
      "(select tb1.*, Item.Name as 'ItemName', "+PMyShop.genTransItemNameDbCol("ItemNm", "Item.Name", "TransItemComment")+", StockUnit, BuyPriceEstimation, TransItemQty*BuyPriceEstimation as 'TransItemPriceTotalBasic' from "+
       "(select Item as 'TransItem', Stock as 'TransItemQty', Price as 'TransItemPriceTotal', Price/Stock as 'TransItemPriceUnit', Comment as 'TransItemComment', Checked as 'TransItemChecked' "+
       "from "+DbTable+"XItemOut where "+DbTable+"="+TransId+con+") as tb1 "+
      "left join Item on tb1.TransItem=Item.Id) as tb2 "+
     "left join StockUnit on tb2.StockUnit=StockUnit.Id) as tb3 "+
    "left join ItemXPicture on tb3.TransItem=ItemXPicture.Item group by tb3.TransItem) as tb4 "+
   "left join ItemXCategory on tb4.TransItem=ItemXCategory.Item left join CategoryOfItem on ItemXCategory.CategoryOfItem=CategoryOfItem.Id group by tb4.TransItem"+
   QueryItemOutOrderBy;
 }
 void fillOut(long TransId){
  int datacount;
  
  clearOut(); if(TransId==-1){return;}
  
  // fetch list data
  datacount=PDatabase.queryToTable(IFV.Stm, queryOfItemOut(TransId, null), TableMdlOut, false, false, null, -1, true, 12);
  TIOutClear=false;
  if(datacount!=-1){
   TIOut=true;
   if(TIRequeryAll==true){TIRequeryAll=false;}
   refreshItemCount(TF_OutCount, TableMdlOut);
   if(datacount>0){
    Tbl_Out.changeSelection(0, 0, false, false);
    onSelectedRowOutChanged(false);
   }
   else{
    clearInfoOut();
   }
  }
  else{
   clearOut();
   JOptionPane.showMessageDialog(null, "Gagal mengambil 'daftar barang keluar' dari database !");
  }
 }
 void clearOut(){
  if(TIOutClear==false){
   TableMdlOut.removeAll();
   refreshItemCount(TF_OutCount, TableMdlOut);
   LastSelectedRowOut=-1;
   clearInfoOut();
   TIOutClear=true;
  }
 }
 void fillInfoOut(int row){
  Object[] objs=TableMdlOut.Mdl.Rows.elementAt(row);
  TF_OutInfoCategory.setText(PCore.objString(objs[9], ""));
  TF_OutInfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[2]);
  PGUI.fillPanelPictureURL(Pnl_ItemOutPreview, IFV.Conf.ImageDirItem, objs[8]);
  InfoOutClear=false;
 }
 void clearInfoOut(){
  if(InfoOutClear==false){
   TF_OutInfoCategory.setText("");
   TF_OutInfoName.setText("");
   PGUI.fillPanelPictureURL(Pnl_ItemOutPreview, IFV.Conf.ImageDirItem, null);
   InfoOutClear=true;
  }
 }
 void refreshPaymentCount(JTextField TF_PaymentCount, OCustomTableModel TableMdlPayment){
  TF_PaymentCount.setText(PText.intToString(TableMdlPayment.getRowCount()));
 }
 void fillPaymentOut(long TransId){
  int datacount;
  // clear list and list index, but not other components and index
  if(TIPayOutClear==false){
   TableMdlPaymentOut.removeAll();
   LastSelectedRowPayOut=-1;
  }
  // fetch list data
  datacount=PDatabase.queryToTable(IFV.Stm,
   "select Enumeration, PaymentDate, Cash, Cash.Name as 'CashName', Price, Comment from "+
    "(select * from "+DbTable+"XPayment where "+DbTable+"="+TransId+") as tb1 "+
   "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, Cash.Name asc;",
   TableMdlPaymentOut, false, false, null, -1, false, -1);
  TIPayOutClear=false;
  if(datacount!=-1){
   TIPayOut=true;
   if(TIRequeryAll){TIRequeryAll=false;}
   refreshPaymentCount(TF_PayOutCount, TableMdlPaymentOut);
   if(datacount>0){
    Tbl_PaymentOut.changeSelection(0, 0, false, false);
    onSelectedRowPaymentOutChanged(false);
   }
   else{
    clearInfoPaymentOut();
   }
  }
  else{
   clearPaymentOut();
   JOptionPane.showMessageDialog(null, "Gagal mengambil 'daftar pembayaran keluar' dari database !");
  }
 }
 void clearPaymentOut(){
  if(TIPayOutClear==false){
   TableMdlPaymentOut.removeAll();
   refreshPaymentCount(TF_PayOutCount, TableMdlPaymentOut);
   LastSelectedRowPayOut=-1;
   clearInfoPaymentOut();
   TIPayOutClear=true;
  }
 }
 void fillInfoPaymentOut(int row){
  TF_PaymentOutDate.setText(PText.dateToString((Date)TableMdlPaymentOut.Mdl.Rows.elementAt(row)[1], 2));
  TF_PaymentOutCash.setText(PText.getStringObj(TableMdlPaymentOut.Mdl.Rows.elementAt(row)[3], "", false));
  TF_PaymentOutPrice.setText(PText.priceToString((Double)TableMdlPaymentOut.Mdl.Rows.elementAt(row)[4]));
  TA_PaymentOutComment.setText(PText.getStringObj(TableMdlPaymentOut.Mdl.Rows.elementAt(row)[5], "", false));
  InfoPayOutClear=false;
 }
 void clearInfoPaymentOut(){
  if(InfoPayOutClear==false){
   TF_PaymentOutDate.setText("");
   TF_PaymentOutCash.setText("");
   TF_PaymentOutPrice.setText("");
   TA_PaymentOutComment.setText("");
   InfoPayOutClear=true;
  }
 }
 void fillPaymentIn(long TransId){
  int datacount;
  // clear list and list index, but not other components and index
  if(TIPayInClear==false){
   TableMdlPaymentIn.removeAll();
   LastSelectedRowPayIn=-1;
  }
  // fetch list data
  datacount=PDatabase.queryToTable(IFV.Stm,
   "select Enumeration, PaymentDate, Cash, Cash.Name as 'CashName', Price, Comment from "+
    "(select * from "+DbTable+"XPaymentIn where "+DbTable+"="+TransId+") as tb1 "+
   "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, Cash.Name asc;", TableMdlPaymentIn, false, false, null, -1, false, -1);
  TIPayInClear=false;
  if(datacount!=-1){
   TIPayIn=true;
   if(TIRequeryAll){TIRequeryAll=false;}
   refreshPaymentCount(TF_PayInCount, TableMdlPaymentIn);
   if(datacount>0){
    Tbl_PaymentIn.changeSelection(0, 0, false, false);
    onSelectedRowPaymentInChanged(false);
   }
   else{
    clearInfoPaymentIn();
   }
  }
  else{
   clearPaymentIn();
   JOptionPane.showMessageDialog(null, "Gagal mengambil 'daftar pembayaran masuk' dari database !");
  }
 }
 void clearPaymentIn(){
  if(TIPayInClear==false){
   TableMdlPaymentIn.removeAll();
   refreshPaymentCount(TF_PayInCount, TableMdlPaymentIn);
   LastSelectedRowPayIn=-1;
   clearInfoPaymentIn();
   TIPayInClear=true;
  }
 }
 void fillInfoPaymentIn(int row){
  TF_PaymentInDate.setText(PText.dateToString((Date)TableMdlPaymentIn.Mdl.Rows.elementAt(row)[1], 2));
  TF_PaymentInCash.setText(PText.getStringObj(TableMdlPaymentIn.Mdl.Rows.elementAt(row)[3], "", false));
  TF_PaymentInPrice.setText(PText.priceToString((Double)TableMdlPaymentIn.Mdl.Rows.elementAt(row)[4]));
  TA_PaymentInComment.setText(PText.getStringObj(TableMdlPaymentIn.Mdl.Rows.elementAt(row)[5], "", false));
  InfoPayInClear=false;
 }
 void clearInfoPaymentIn(){
  if(InfoPayInClear==false){
   TF_PaymentInDate.setText("");
   TF_PaymentInCash.setText("");
   TF_PaymentInPrice.setText("");
   TA_PaymentInComment.setText("");
   InfoPayInClear=true;
  }
 }
 void refreshOrdCount(){TF_OrdCount.setText(PText.intToString(TableMdlOrd.getRowCount()));}
 void refreshOrdPriceEst(){TF_OrdPriceEst.setText(PText.priceToString(OrdPriceEst.Value));}
 String queryOfOrd(long[] ItemsId){
  String con=""; if(ItemsId!=null){con=" and Id in("+PText.toString(ItemsId, 0, ItemsId.length, ",")+")";}
  return
   "select tb4.*, min(FileName) as 'PictureFile' from "+
    "(select ItemId, ItemName, min(CategoryOfItem.Name) as 'CategoryName', OrderQuantity, StockUnitName, BuyPriceEstimation, OrderPriceEstimation from "+
     "(select tb2.*, CategoryOfItem from "+
      "(select tb1.*, StockUnit.Name as 'StockUnitName' from "+
       "(select *, Id as 'ItemId', Name as 'ItemName', ifnull(OrderQuantity,0)*BuyPriceEstimation as 'OrderPriceEstimation' from Item "+
       "where OrderQuantity is not "+CCore.vNull+" and ifnull(OrderQuantity,0)>0"+con+") as tb1 "+
      "left join StockUnit on tb1.StockUnit=StockUnit.Id) as tb2 "+
     "left join ItemXCategory on tb2.ItemId=ItemXCategory.Item) as tb3 "+
    "left join CategoryOfItem on tb3.CategoryOfItem=CategoryOfItem.Id group by ItemId) as tb4 "+
   "left join ItemXPicture on tb4.ItemId=ItemXPicture.Item group by ItemId"+
   QueryOrdOrderBy;
 }
 void fillListOrd(int FillMode){
  int result;
  
  // FillMode : 1 check FirstTime, ? otherwise fill anyway
  switch(FillMode){
   case 1  : if(ListOrdFilled){return;} break;
  }
  
  clearListOrd();
  
  result=PDatabase.queryToTableWithSum(IFV.Stm, queryOfOrd(null), TableMdlOrd, OrdSumColumn, OrdSumResult, false, false, null, -1, false, -1);
  if(result==-1){JOptionPane.showMessageDialog(null, "Gagal mengambil data order dari database !");}
  
  OrdPriceEst.Value=OrdSumResult[6]; refreshOrdCount(); refreshOrdPriceEst();
  
  ListOrdFilled=true;
 }
 void clearListOrd(){
  if(!ListOrdFilled){return;}
  
  TableMdlOrd.removeAll(); LastSelectedRowOrd=-1; onSelectedRowOrdChanged(true);
  OrdPriceEst.Value=0; refreshOrdCount(); refreshOrdPriceEst();
  
  ListOrdFilled=false;
 }
 void fillInfoOrd(int row){
  Object[] objs=TableMdlOrd.Mdl.Rows.elementAt(row);
  
  PGUI.fillPanelPictureURL(Pnl_OrdPreview, IFV.Conf.ImageDirItem, objs[7]);
  TA_OrdInfoCategory.setText(PText.getStringObj(objs[2], "", false));
  TA_OrdInfoName.setText("("+PText.separate(objs[0].toString(), " - ", 5)+") "+(String)objs[1]);
  
  InfoOrdClear=false;
 }
 void clearInfoOrd(){
  if(InfoOrdClear){return;}
  
  PGUI.fillPanelPictureURL(Pnl_OrdPreview, IFV.Conf.ImageDirItem, null);
  TA_OrdInfoCategory.setText("");
  TA_OrdInfoName.setText("");
  
  InfoOrdClear=true;
 }
 void addReplaceOrd(Vector<Object[]> NewData){
  int length, temp;
  double PriceOld, PriceNew;
  Object[] objs_old;
  Object[] objs_new;
  int foundindex;
  long ItemId;
  boolean ProcessedInTab=ListOrdFilled || TabbedPane.getSelectedIndex()==6;
  String FindName=null;
  int FindColumn=0;
  boolean IsCategorized=CB_OrdCategorized.isSelected();
  
  length=NewData.size();
  if(length==0){return;}
  
  PriceOld=0; PriceNew=0;
  
  if(ProcessedInTab){
   temp=0; if(!IsCategorized){FindColumn=1;}else{FindColumn=2;}
   do{
    objs_new=NewData.elementAt(temp);

    ItemId=(Long)objs_new[0];
    foundindex=PTable.findNumber(TableMdlOrd.Mdl.Rows, ItemId, 0, false, 0, TableMdlOrd.Mdl.Rows.size());
    if(foundindex!=-1){
     objs_old=TableMdlOrd.Mdl.Rows.elementAt(foundindex);
     PriceOld=PriceOld+(Double)objs_old[6];
     TableMdlOrd.changeValue(foundindex, objs_new);
    }
    else{
     FindName=PCore.objString(objs_new[FindColumn], null);
     foundindex=PGUI.findInsertPos(TableMdlOrd, FindColumn, FindName, true, false, true);
     TableMdlOrd.insert(foundindex, objs_new);
    }
    PriceNew=PriceNew+(Double)objs_new[6];

    temp=temp+1;
   }while(temp!=length);
   ListOrdFilled=true;
   onSelectedRowOrdChanged(true);
   refreshOrdCount(); updateOrdPriceEst(PriceNew-PriceOld, true);
  }
 }
 void updateOrdPriceEst(double Price, boolean IsAdd){
  if(IsAdd){OrdPriceEst.Value=OrdPriceEst.Value+Price;}else{OrdPriceEst.Value=OrdPriceEst.Value-Price;}
  refreshOrdPriceEst();
 }
 
 void fillAnActiveTab(int tab, long TransId){
  switch(tab){
   case 1 : // tab det
    if(TIDet==false){fillDet(TransId);}
    break;
   case 2 : // tab item in
    if(TIIn==false){fillIn(TransId);}
    break;
   case 3 : // tab payment out
    if(TIPayOut==false){fillPaymentOut(TransId);}
    break;
   case 4 : // tab item out
    if(TIOut==false){fillOut(TransId);}
    break;
   case 5 : // tab payment in
    if(TIPayIn==false){fillPaymentIn(TransId);}
    break;
  }
 }
 void clearAnActiveTab(int tab){
  switch(tab){
   case 1 : clearDet(); break; // tab det
   case 2 : clearIn(); break; // tab item in
   case 3 : clearPaymentOut(); break; // tab payment out
   case 4 : clearOut(); break; // tab item out
   case 5 : clearPaymentIn(); break; // tab payment in
  }
 }
 
 void runQuery(){
  String str=null;
  String str1=null;
  String str2=null;
  boolean list_defined, isempty1, isempty2, confirst, isconpost;
  boolean input_valid;
  Date StartDate, EndDate;
  int temp, idx;
  Double dbl1, dbl2;
  Date dt1, dt2;
  StringBuilder strb;
  VBoolean Con_Defined;
  StringBuilder StcCon;
  
  StringBuilder StcSourceTable;
  StringBuilder StcCondition;
  StringBuilder StcPostOperation;
  
  boolean query_defined;
  VBoolean stc_con_defined;
  VBoolean stc_conpost_defined;
  
  Vector<String[]> join;
  
  // validate input
  input_valid=false;
  do{
   // text & other
   if(CB_QId.isSelected()){
    if(PText.checkInput(TF_QId.getText(), false, 0, 0, 0, 0, 0)==false){break;}
   }
   if(CB_QComment.isSelected()){
    if(PText.checkInput(TF_QComment.getText(), false, 0, 0, 0, 0, 0)==false){break;}
   }
   if(CB_QCashComment.isSelected()){
    if(PText.checkInput(TF_QCashComment.getText(), false, 0, 0, 0, 0, 0)==false){break;}
   }

   // date
   if(CB_QDate.isSelected()){
    StartDate=PGUI.valueOfDateComponent(TF_QDateStartYear, ComboBox_QDateStartMonth, ComboBox_QDateStartDay);
    EndDate=PGUI.valueOfDateComponent(TF_QDateEndYear, ComboBox_QDateEndMonth, ComboBox_QDateEndDay);
    if(StartDate==null && EndDate==null){break;}
   }
   if(CB_QBillDate.isSelected()){
    StartDate=PGUI.valueOfDateComponent(TF_QBillDateStartYear, CmB_QBillDateStartMonth, CmB_QBillDateStartDay);
    EndDate=PGUI.valueOfDateComponent(TF_QBillDateEndYear, CmB_QBillDateEndMonth, CmB_QBillDateEndDay);
    if(StartDate==null && EndDate==null){break;}
   }
   if(CB_QRepayPeriod.isSelected()){
    StartDate=PGUI.valueOfDateComponent(TF_QRepayPeriodStartYear, CmB_QRepayPeriodStartMonth, CmB_QRepayPeriodStartDay);
    EndDate=PGUI.valueOfDateComponent(TF_QRepayPeriodEndYear, CmB_QRepayPeriodEndMonth, CmB_QRepayPeriodEndDay);
    if(StartDate==null && EndDate==null){break;}
   }
   
   // double
   if(CB_QItemPrice.isSelected()){
    str1=TF_QItemPrice1.getText(); str2=TF_QItemPrice2.getText();
    isempty1=PText.isEmptyString(str1, true, true); dbl1=PText.parseDouble(str1, null, null, true, true, false, 0, 0); if(!isempty1 && dbl1==null){break;}
    isempty2=PText.isEmptyString(str2, true, true); dbl2=PText.parseDouble(str2, null, null, true, true, false, 0, 0); if(!isempty2 && dbl2==null){break;}
    if(isempty1 && isempty2){break;}
   }
   if(CB_QPaymentPrice.isSelected()){
    str1=TF_QPaymentPrice1.getText(); str2=TF_QPaymentPrice2.getText();
    isempty1=PText.isEmptyString(str1, true, true); dbl1=PText.parseDouble(str1, null, null, true, true, false, 0, 0); if(!isempty1 && dbl1==null){break;}
    isempty2=PText.isEmptyString(str2, true, true); dbl2=PText.parseDouble(str2, null, null, true, true, false, 0, 0); if(!isempty2 && dbl2==null){break;}
    if(isempty1 && isempty2){break;}
   }

   // list
   if(CB_QTransType.isSelected()){
    if(ListMdlQType.Mdl.Rows.size()==0 && !CB_QTransTypeEmpty.isSelected()){break;}
   }
   if(CB_QCash.isSelected()){
    if(ListMdlQCash.Mdl.Rows.size()==0 && !CB_QCashEmpty.isSelected()){break;}
   }
   if(CB_QSubject.isSelected()){
    if(ListMdlQSubject.Mdl.Rows.size()==0 && !CB_QSubjectEmpty.isSelected()){break;}
   }
   if(CB_QSalesman.isSelected()){
    if(ListMdlQSalesman.Mdl.Rows.size()==0 && !CB_QSalesmanEmpty.isSelected()){break;}
   }
   if(CB_QItem.isSelected()){
    if(TableMdlQItem.Mdl.Rows.size()==0 && !CB_QItemNon.isSelected()){break;}
   }

   input_valid=true;
  }while(false);
  if(!input_valid){
   JOptionPane.showMessageDialog(null, "Tidak dapat mencari : masukan belum benar atau belum lengkap !"); return;
  }
  
  // build query
  query_defined=true;
  stc_con_defined=new VBoolean(false);
  stc_conpost_defined=new VBoolean(false);
  
  StcSourceTable=new StringBuilder("");
  StcCondition=new StringBuilder("");
  StcPostOperation=new StringBuilder("");

   // Important
  if(CB_QImportant.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" "+DbTable+".IsImportant="+PText.getString(RB_QImportantYes.isSelected(), CCore.vTrue, CCore.vFalse));
  }
		
		 // Check
		if(CB_QCheck.isSelected()){
			switch(CmB_QCheck.getSelectedIndex()){
				case 0 :
					if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostOperation.append(" having");}else{StcPostOperation.append(" and");}
					StcPostOperation.append(" ifnull(PriceItemOut,0)+ifnull(PricePaymentOut,0)>ifnull(PriceItemIn,0)+ifnull(PricePaymentIn,0)");
					break;
				case 1 :
					if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostOperation.append(" having");}else{StcPostOperation.append(" and");}
					StcPostOperation.append(" ifnull(PriceItemOut,0)+ifnull(PricePaymentOut,0)<=ifnull(PriceItemIn,0)+ifnull(PricePaymentIn,0)");
					break;
				case 2 :
					if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostOperation.append(" having");}else{StcPostOperation.append(" and");}
					StcPostOperation.append(" ifnull(PriceItemIn,0)+ifnull(PricePaymentIn,0)>ifnull(PriceItemOut,0)+ifnull(PricePaymentOut,0)");
					break;
				case 3 :
					if(!stc_conpost_defined.Value){stc_conpost_defined.Value=true; StcPostOperation.append(" having");}else{StcPostOperation.append(" and");}
					StcPostOperation.append(" ifnull(PriceItemIn,0)+ifnull(PricePaymentIn,0)<=ifnull(PriceItemOut,0)+ifnull(PricePaymentOut,0)");
					break;
				case 4 :
					StcSourceTable.append(", (select "+DbTable+"Id from "+DbTable+"Pend group by "+DbTable+"Id) as pend");
					if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
					StcCondition.append(" "+DbTable+".Id=pend."+DbTable+"Id");
					break;
				case 5 :
					StcSourceTable.append(", (select Id from "+DbTable+" left join (select "+DbTable+"Id from "+DbTable+"Pend group by "+DbTable+"Id) as pend "+
      "on "+DbTable+".Id=pend."+DbTable+"Id where pend."+DbTable+"Id is "+CCore.vNull+") as not_pend");
					if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
					StcCondition.append(" "+DbTable+".Id=not_pend.Id");
					break;
			}
		}

   // Date
  if(CB_QDate.isSelected()){
   isconpost=false;
   str1=DbTable+".TransDate";
   dt1=PGUI.valueOfDateComponent(TF_QDateStartYear, ComboBox_QDateStartMonth, ComboBox_QDateStartDay);
   dt2=PGUI.valueOfDateComponent(TF_QDateEndYear, ComboBox_QDateEndMonth, ComboBox_QDateEndDay);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostOperation);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   StcCon.append(")");
  }

   // BillDate
  if(CB_QBillDate.isSelected()){
   isconpost=false;
   str1="Date_Add("+DbTable+".TransDate, interval ifnull("+DbTable+".CreditDays, 0) Day)";
   str2=" and "+DbTable+".CreditDays is not "+CCore.vNull;
   dt1=PGUI.valueOfDateComponent(TF_QBillDateStartYear, CmB_QBillDateStartMonth, CmB_QBillDateStartDay);
   dt2=PGUI.valueOfDateComponent(TF_QBillDateEndYear, CmB_QBillDateEndMonth, CmB_QBillDateEndDay);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostOperation);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   StcCon.append(str2);
   StcCon.append(")");
  }
		
   // RepayPeriod
  if(CB_QRepayPeriod.isSelected()){
   isconpost=false;
   dt1=PGUI.valueOfDateComponent(TF_QRepayPeriodStartYear, CmB_QRepayPeriodStartMonth, CmB_QRepayPeriodStartDay);
   dt2=PGUI.valueOfDateComponent(TF_QRepayPeriodEndYear, CmB_QRepayPeriodEndMonth, CmB_QRepayPeriodEndDay);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostOperation);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dt1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+DbTable+".RepaymentPeriodEnd>=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, true), false)+" as Date)");
   }
   if(dt2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+DbTable+".RepaymentPeriodStart<=cast("+PDatabase.dateToSQLStringFormat(PDate.getMinMaxDate(dt1, dt2, false), true)+" as Date)");
   }
   StcCon.append(")");
  }
  
   // Id
  if(CB_QId.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   str=TF_QId.getText();
   StcCondition.append(" ("+PSql.genCheckWord("cast("+DbTable+".Id as char(16))", str, true, true)+" or "+
    PSql.genCheckWord(DbTable+".InfoIdExternal", str, true, true)+")");
  }

   // Comment
  if(CB_QComment.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" "+PSql.genCheckWord(DbTable+".Comment", TF_QComment.getText(), true, true));
  }

   // Cash Comment
  if(CB_QCashComment.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   
   idx=CmB_QCashComment.getSelectedIndex();
   
   StcSourceTable.append(", (");
   
   if(idx==1 || idx==4 || (idx==0 || idx==3)){
    if(idx==1 || idx==0){str="CashInComment";}else{str="CashOutComment";}
    StcSourceTable.append("(select Id as 'Ids' from "+DbTable+" where "+PSql.genCheckWord(str, TF_QCashComment.getText(), true, true)+")");
   }

   if(idx==0 || idx==3){StcSourceTable.append(" union distinct ");}
   
   if(idx==2 || idx==5 || (idx==0 || idx==3)){
    if(idx==2 || idx==0){str=DbTable+"XPaymentIn";}else{str=DbTable+"XPayment";}
    StcSourceTable.append("(select "+DbTable+" as 'Ids' from "+str+" where "+PSql.genCheckWord("Comment", TF_QCashComment.getText(), true, true)+" group by "+DbTable+")");
   }
   
   StcSourceTable.append(") as CashCreditComment");
   
   StcCondition.append(" "+DbTable+".Id=CashCreditComment.Ids");
  }
  
   // Item Price
  if(CB_QItemPrice.isSelected()){
   isconpost=false;
   switch(CmB_QItemPrice.getSelectedIndex()){
    case 0 : str1="ifnull(PriceItemIn,0)"; isconpost=true; break;
    case 1 : str1="ifnull(PriceItemOut,0)"; isconpost=true; break;
   }
   dbl1=PText.parseDouble(TF_QItemPrice1.getText(), null, null); dbl2=PText.parseDouble(TF_QItemPrice2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostOperation);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCon.append(")");
  }
  
   // Payment Price
  if(CB_QPaymentPrice.isSelected()){
   isconpost=false;
   switch(CmB_QPaymentPrice.getSelectedIndex()){
    case 0 : str1="ifnull(PricePaymentOut,0)"; isconpost=true; break;
    case 1 : str1="ifnull(PricePaymentIn,0)"; isconpost=true; break;
   }
   dbl1=PText.parseDouble(TF_QPaymentPrice1.getText(), null, null); dbl2=PText.parseDouble(TF_QPaymentPrice2.getText(), null, null);
   
   Con_Defined=(VBoolean)PCore.subtituteBool(!isconpost, stc_con_defined, stc_conpost_defined);
   StcCon=(StringBuilder)PCore.subtituteBool(!isconpost, StcCondition, StcPostOperation);
   if(!Con_Defined.Value){Con_Defined.Value=true; StcCon.append(PText.getString(!isconpost, " where", " having"));}else{StcCon.append(" and");}
   StcCon.append(" ("); confirst=true;
   if(dbl1!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+">="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, true), false));
   }
   if(dbl2!=null){
    if(confirst){confirst=false;}else{StcCon.append(" and");}
    StcCon.append(" "+str1+"<="+PText.doubleToString(PMath.getMinMaxDouble(dbl1, dbl2, false), false));
   }
   StcCon.append(")");
  }
  
   // Item
  if(CB_QItem.isSelected()){
   join=new Vector();
   temp=CmB_QItem.getSelectedIndex();
   
   // item in
   if(temp!=1){
    str=DbTable+"XItemIn";
    strb=new StringBuilder();
    list_defined=false;
    if(TableMdlQItem.getRowCount()!=0){
     strb.append(" Item in ("+PGUI.getElementList(TableMdlQItem.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
    }
    if(CB_QItemNon.isSelected()){
     if(list_defined){strb.append(" or");} strb.append(" "+str+"."+DbTable+" is "+CCore.vNull);
    }
    join.addElement(PCore.refArr(str, DbTable, strb.toString(), " group by Id"));
   }
   
   // item out
   if(temp!=0){
    str=DbTable+"XItemOut";
    strb=new StringBuilder();
    list_defined=false;
    if(TableMdlQItem.getRowCount()!=0){
     strb.append(" Item in ("+PGUI.getElementList(TableMdlQItem.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
    }
    if(CB_QItemNon.isSelected()){
     if(list_defined){strb.append(" or");} strb.append(" "+str+"."+DbTable+" is "+CCore.vNull);
    }
    join.addElement(PCore.refArr(str, DbTable, strb.toString(), " group by Id"));
   }
   
   StcSourceTable.append(", ("+PDatabase.buildJoinSingleSourceKey("Id", DbTable, "Id", join)+") as y1");
   
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" "+DbTable+".Id=y1.Id");
  }

   // TransType
  if(CB_QTransType.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" (");
   list_defined=false;
   if(ListMdlQType.Mdl.Rows.size()!=0){
    StcCondition.append(" "+DbTable+".TransType in ("+PGUI.getElementList(ListMdlQType.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QTransTypeEmpty.isSelected()){
    if(list_defined){StcCondition.append(" or");} StcCondition.append(" "+DbTable+".TransType is "+CCore.vNull);
   }
   StcCondition.append(")");
  }

   // Cash
  if(CB_QCash.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   
   StcCondition.append(" (");
   
   idx=CmB_QCash.getSelectedIndex();

   if(idx==1 || idx==4 || (idx==0 || idx==3)){
    if(idx==1 || idx==0){str="CashIn";}else{str="Cash";}
    StcCondition.append(" (");
    list_defined=false;
    if(ListMdlQCash.Mdl.Rows.size()!=0){
     StcCondition.append(" "+DbTable+"."+str+" in ("+PGUI.getElementList(ListMdlQCash.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
    }
    if(CB_QCashEmpty.isSelected()){
     if(list_defined){StcCondition.append(" or");} StcCondition.append(" "+DbTable+"."+str+" is "+CCore.vNull);
    }
    StcCondition.append(")");
   }
   
   if(idx==0 || idx==3){StcCondition.append(" or");}

   if(idx==2 || idx==5 || (idx==0 || idx==3)){
    if(idx==2 || idx==0){str=DbTable+"XPaymentIn";}else{str=DbTable+"XPayment";}
    StcSourceTable.append(", (select "+DbTable+" from "+str+" where");
    list_defined=false;
    if(ListMdlQCash.Mdl.Rows.size()!=0){
     StcSourceTable.append(" Cash in ("+PGUI.getElementList(ListMdlQCash.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
    }
    if(CB_QCashEmpty.isSelected()){
     if(list_defined){StcSourceTable.append(" or");} StcSourceTable.append(" Cash is "+CCore.vNull);
    }
    StcSourceTable.append(" group by "+DbTable+") as y2");

    StcCondition.append(" "+DbTable+".Id=y2."+DbTable);
   }
   
   StcCondition.append(")");
  }

   // Subject
  if(CB_QSubject.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" (");
   list_defined=false;
   if(ListMdlQSubject.Mdl.Rows.size()!=0){
    StcCondition.append(" "+DbTable+".Subject in ("+PGUI.getElementList(ListMdlQSubject.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QSubjectEmpty.isSelected()){
    if(list_defined){StcCondition.append(" or");} StcCondition.append(" "+DbTable+".Subject is "+CCore.vNull);
   }
   StcCondition.append(")");
  }

   // Salesman
  if(CB_QSalesman.isSelected()){
   if(!stc_con_defined.Value){stc_con_defined.Value=true; StcCondition.append(" where");}else{StcCondition.append(" and");}
   StcCondition.append(" (");
   list_defined=false;
   if(ListMdlQSalesman.Mdl.Rows.size()!=0){
    StcCondition.append(" "+DbTable+".Salesman in ("+PGUI.getElementList(ListMdlQSalesman.Mdl.Rows, 0, ",", "", false)+")"); list_defined=true;
   }
   if(CB_QSalesmanEmpty.isSelected()){
    if(list_defined){StcCondition.append(" or");} StcCondition.append(" "+DbTable+".Salesman is "+CCore.vNull);
   }
   StcCondition.append(")");
  }
  
  if(query_defined){
   setLastQuery(CApp.FormQueryLimit,
    StcSourceTable.toString(), StcCondition.toString(), stc_con_defined.Value, StcPostOperation.toString(), stc_conpost_defined.Value,
    0, true);
  }
  else{
   clearLastQuery();
  }
  fillTableTrans();
 }
 void findTransInTable(int Mode){
  int Selected, FindIndex;
  int Column, ColumnType;
  String str=TF_Find.getText();
  if(str.length()!=0){
   if(TableMdlTrans.Mdl.Rows.size()!=0){
    switch(CmB_Find.getSelectedIndex()){
     case 1 : Column=1;  break;
     case 2 : Column=3;  break;
     case 3 : Column=9;  break;
     case 4 : Column=11;  break;
     case 5 : Column=12;  break;
     case 6 : Column=13;  break;
     case 7 : Column=14;  break;
     case 8 : Column=15;  break;
     default : Column=0; break;
    }
    ColumnType=TableMdlTrans.getColumnsType()[Column];
    Selected=Tbl_Trans.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlTrans, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_Trans.changeSelection(FindIndex, 0, false, false);
      onSelectedRowTransChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel dalam keadaan kosong !");
   }
  }
 }
 void findItemIn(int Mode){
  int Selected, FindIndex;
  int Column=0;
  int ColumnType;
  String str=TF_FindItemIn.getText();
  if(str.length()!=0){
   if(TableMdlIn.Mdl.Rows.size()!=0){
    switch(CmB_FindItemIn.getSelectedIndex()){
     case 1 : Column=2; break;
     case 2 : Column=9; break;
     default : Column=0; break;
    }
    ColumnType=TableMdlIn.getColumnsType()[Column];
    Selected=Tbl_In.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlIn, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_In.changeSelection(FindIndex, 0, false, false);
      onSelectedRowInChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang masuk !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang masuk dalam keadaan kosong !");
   }
  }
 }
 void findItemOut(int Mode){
  int Selected, FindIndex;
  int Column=0;
  int ColumnType;
  String str=TF_FindItemOut.getText();
  if(str.length()!=0){
   if(TableMdlOut.Mdl.Rows.size()!=0){
    switch(CmB_FindItemOut.getSelectedIndex()){
     case 1 : Column=2; break;
     case 2 : Column=9; break;
     default : Column=0; break;
    }
    ColumnType=TableMdlOut.getColumnsType()[Column];
    Selected=Tbl_Out.getSelectedRow();
    FindIndex=PGUI.searchInTable(TableMdlOut, Column, ColumnType, str, Selected, Mode);
    if(FindIndex!=-1){
     if(Selected!=FindIndex){
      Tbl_Out.changeSelection(FindIndex, 0, false, false);
      onSelectedRowOutChanged(false);
     }
    }
    else{
     JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel barang keluar !");
    }
   }
   else{
    JOptionPane.showMessageDialog(null, "Tabel barang keluar dalam keadaan kosong !");
   }
  }
 }
 void findOrd(int Mode){
  int Selected, FindIndex, Column, ColumnType;
  String str;
  
  str=TF_OrdFind.getText(); if(str.length()==0){return;}
  if(TableMdlOrd.Mdl.Rows.size()==0){JOptionPane.showMessageDialog(null, "Tabel order dalam keadaan kosong !"); return;}
  
  switch(CmB_OrdFind.getSelectedIndex()){
   case 0 : Column=0; break;
   case 1 : Column=1; break;
   case 2 : Column=2; break;
   default : Column=0; break;
  }
  ColumnType=TableMdlOrd.getColumnsType()[Column];
  Selected=Tbl_Ord.getSelectedRow();
  FindIndex=PGUI.searchInTable(TableMdlOrd, Column, ColumnType, str, Selected, Mode);
  if(FindIndex==-1){JOptionPane.showMessageDialog(null, "Tidak ditemukan data yang cocok di tabel order !"); return;}
  
  if(Selected==FindIndex){return;}
  Tbl_Ord.changeSelection(FindIndex, 0, false, false);
  onSelectedRowOrdChanged(false);
 }
 void transConvert(){
  int[] rows;
  int temp;
  int removedcount;
  double PriceTotIn, PriceTotOut, PriceTotOutBasic, PaymentOutTot, PaymentInTot, dbl;
  boolean[] IsRemove;
  boolean bool;
  
  Connection AdminCon;
  Statement AdminStm;
  boolean ForceFinish;
  boolean UseExternalStm;
  boolean error;
  
  String Source, Dest;
  
  rows=Tbl_Trans.getSelectedRows();
  if(rows.length==0){return;}

  Source=PText.getString(wIsPreTrans, "Pra-Transaksi", "Transaksi");
  Dest=PText.getString(wIsPreTrans, "Transaksi", "Pra-Transaksi");
  
  if(JOptionPane.showConfirmDialog(null, "Konversi "+rows.length+" "+Source+" yg dipilih menjadi "+Dest+" ?",
   "Konfirmasi Konversi "+Source+" Menjadi "+Dest, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}

  IsRemove=PCore.newBooleanArray(rows.length, false);
  removedcount=0;
  PriceTotIn=0;
  PriceTotOut=0;
  PriceTotOutBasic=0;
  PaymentOutTot=0;
  PaymentInTot=0;
  ForceFinish=false;
  AdminCon=null;
  AdminStm=null; UseExternalStm=false;

  bool=true;
  do{
   temp=0;
   do{
    if(IsRemove[temp]==false){
     if(PMyShop.convertTrans(IFV.Stm, (Long)TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[0], wIsPreTrans,
      PText.getString(IFV.CurrentDatabase, "", false)+IFV.PreTransLock, 10, PText.getString(IFV.CurrentDatabase, "", false)+IFV.TransLock, 10,
      true, ForceFinish, AdminStm)){
      removedcount=removedcount+1;
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPriceItemIn], 0D);
      if(dbl>0){PriceTotIn=PriceTotIn+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPriceItemOut], 0D);
      if(dbl>0){PriceTotOut=PriceTotOut+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPriceItemOutBasic], 0D);
      if(dbl>0){PriceTotOutBasic=PriceTotOutBasic+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPricePayOut], 0D);
      if(dbl>0){PaymentOutTot=PaymentOutTot+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPricePayIn], 0D);
      if(dbl>0){PaymentInTot=PaymentInTot+dbl;}
      IsRemove[temp]=true;
     }
    }
    temp=temp+1;
   }while(temp!=rows.length);
   
   if(AdminStm!=null && UseExternalStm){try{AdminStm.close(); AdminStm=null;}catch(Exception E){}}
   if(AdminCon!=null){try{AdminCon.close(); AdminCon=null;}catch(Exception E){}}
   
   if(removedcount==rows.length){break;}
   
   IFV.FMessage.showMessage("Gagal mengkonversi "+(rows.length-removedcount)+" "+Source+" menjadi "+Dest+" "+
    "(mungkin dikarenakan terdapat operasi pengubahan stok yang mengakibatkan stok akhir bernilai minus) :\n"+
    PText.toStringWithQuote(TableMdlTrans.Mdl.Rows, PGUI.getPickedRows(rows, IsRemove, false), "\n",
    PCore.primArr(0), PCore.primArr(false), "> ", ".", ", ", "", "", false), PCore.vectObj(
    "Lanjut selesaikan konversi (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan konversi (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){break;}
   
   ForceFinish=true;
   AdminCon=null;
   AdminStm=IFV.Stm; UseExternalStm=false;
   if(IFV.FMessage.Resolution==1){
    AdminCon=IFV.FLogin.loginTemporary("Login Sementara Sbg User Lain Utk Menandai 'Mismatch Stok'");
    if(AdminCon==null){break;}
    error=true;
    do{
     try{
      AdminStm=AdminCon.createStatement(); UseExternalStm=true;
      if(!IFV.useDb(AdminStm, IFV.CurrentDatabase)){break;}
     }catch(Exception E){break;}
     error=false;
    }while(false);
    if(error){
     JOptionPane.showMessageDialog(null,
      "Tdk dapat melanjutkan operasi, terjadi error\n"+
      "ketika mencoba login sementara sebagai User Lain.");
     break;
    }
   }
  }while(bool);
  
  if(AdminStm!=null && UseExternalStm){try{AdminStm.close();}catch(Exception E){}}
  if(AdminCon!=null){try{AdminCon.close();}catch(Exception E){}}

  if(removedcount!=0){
   TableMdlTrans.remove(rows, IsRemove);
   onSelectedRowTransChanged(true);
   refreshQueryCount();
   updateQueryTempListCount();
   updateItemInSum(PriceTotIn, false);
   updateItemOutSum(PriceTotOut, false);
   updateItemOutBasicSum(PriceTotOutBasic, false);
   updatePaymentOutSum(PaymentOutTot, false);
   updatePaymentInSum(PaymentInTot, false);
  }
 }
 void transCancel(){
  int[] rows;
  int temp;
  int removedcount;
  double PriceTotIn, PriceTotOut, PriceTotOutBasic, PaymentOutTot, PaymentInTot, dbl;
  boolean[] IsRemove;
  boolean bool;
  
  Connection AdminCon;
  Statement AdminStm;
  boolean ForceFinish;
  boolean UseExternalStm;
  boolean error;
  
  rows=Tbl_Trans.getSelectedRows();
  if(rows.length==0){return;}

  if(JOptionPane.showConfirmDialog(null, "Batalkan "+rows.length+" "+TransName+" yg dipilih ?",
   "Konfirmasi Pembatalan "+TransName, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}

  IsRemove=PCore.newBooleanArray(rows.length, false);
  removedcount=0;
  PriceTotIn=0;
  PriceTotOut=0;
  PriceTotOutBasic=0;
  PaymentOutTot=0;
  PaymentInTot=0;
  ForceFinish=false;
  AdminCon=null;
  AdminStm=null; UseExternalStm=false;

  bool=true;
  do{
   temp=0;
   do{
    if(IsRemove[temp]==false){
     if(PMyShop.cancelTransaction(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+DbAppLock, 10,
      wIsPreTrans, (Long)TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[0], ForceFinish, AdminStm)){
      removedcount=removedcount+1;
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPriceItemIn], 0D);
      if(dbl>0){PriceTotIn=PriceTotIn+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPriceItemOut], 0D);
      if(dbl>0){PriceTotOut=PriceTotOut+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPriceItemOutBasic], 0D);
      if(dbl>0){PriceTotOutBasic=PriceTotOutBasic+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPricePayOut], 0D);
      if(dbl>0){PaymentOutTot=PaymentOutTot+dbl;}
      dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[ColTransPricePayIn], 0D);
      if(dbl>0){PaymentInTot=PaymentInTot+dbl;}
      IsRemove[temp]=true;
     }
    }
    temp=temp+1;
   }while(temp!=rows.length);
   
   if(AdminStm!=null && UseExternalStm){try{AdminStm.close(); AdminStm=null;}catch(Exception E){}}
   if(AdminCon!=null){try{AdminCon.close(); AdminCon=null;}catch(Exception E){}}
   
   if(removedcount==rows.length){break;}
   
   IFV.FMessage.showMessage("Gagal membatalkan "+(rows.length-removedcount)+" "+TransName+" "+
    "(mungkin dikarenakan terdapat operasi pengubahan stok yang mengakibatkan stok akhir bernilai minus) :\n"+
    PText.toStringWithQuote(TableMdlTrans.Mdl.Rows, PGUI.getPickedRows(rows, IsRemove, false), "\n",
    PCore.primArr(0), PCore.primArr(false), "> ", ".", ", ", "", "", false), PCore.vectObj(
    "Lanjut selesaikan pembatalan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan pembatalan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){break;}
   
   ForceFinish=true;
   AdminCon=null;
   AdminStm=IFV.Stm; UseExternalStm=false;
   if(IFV.FMessage.Resolution==1){
    AdminCon=IFV.FLogin.loginTemporary("Login Sementara Sbg User Lain Utk Menandai 'Mismatch Stok'");
    if(AdminCon==null){break;}
    error=true;
    do{
     try{
      AdminStm=AdminCon.createStatement(); UseExternalStm=true;
      if(!IFV.useDb(AdminStm, IFV.CurrentDatabase)){break;}
     }catch(Exception E){break;}
     error=false;
    }while(false);
    if(error){
     JOptionPane.showMessageDialog(null,
      "Tdk dapat melanjutkan operasi, terjadi error\n"+
      "ketika mencoba login sementara sebagai User Lain.");
     break;
    }
   }
  }while(bool);
   
  if(AdminStm!=null && UseExternalStm){try{AdminStm.close();}catch(Exception E){}}
  if(AdminCon!=null){try{AdminCon.close();}catch(Exception E){}}
  
  if(removedcount!=0){
   TableMdlTrans.remove(rows, IsRemove);
   onSelectedRowTransChanged(true);
   refreshQueryCount();
   updateQueryTempListCount();
   updateItemInSum(PriceTotIn, false);
   updateItemOutSum(PriceTotOut, false);
   updateItemOutBasicSum(PriceTotOutBasic, false);
   updatePaymentOutSum(PaymentOutTot, false);
   updatePaymentInSum(PaymentInTot, false);
  }
 }
 void transRemove(){
  int[] rows;
  long[] Id;
  int temp, count, currrow;
  double PriceTotIn, PriceTotOut, PriceTotOutBasic, PaymentOutTot, PaymentInTot, dbl;
  boolean success;
  
  rows=Tbl_Trans.getSelectedRows();
  count=rows.length;
  if(count==0){return;}

  if(JOptionPane.showConfirmDialog(null, "Hapus "+PText.intToString(count)+" "+TransName+" yg dipilih ?"+
   "\nPerhatian: operasi ini akan menghapus data secara permanen di database !",
   "Konfirmasi Penghapusan "+TransName, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}

  IFV.FSplashScreen.appear(this, "Menghapus Data "+TransName);
  
  IFV.FSplashScreen.inform(0, "Menghapus "+PText.intToString(count)+" data "+TransName+", harap menunggu ...", null);
  
  // collecting transactions's Id
  Id=new long[count];
  PriceTotIn=0;
  PriceTotOut=0;
  PriceTotOutBasic=0;
  PaymentOutTot=0;
  PaymentInTot=0;
  temp=0;
  do{
   currrow=rows[temp];
   Id[temp]=(Long)TableMdlTrans.Mdl.Rows.elementAt(currrow)[0];
   dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(currrow)[ColTransPriceItemIn], 0D);
   if(dbl>0){PriceTotIn=PriceTotIn+dbl;}
   dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(currrow)[ColTransPriceItemOut], 0D);
   if(dbl>0){PriceTotOut=PriceTotOut+dbl;}
   dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(currrow)[ColTransPriceItemOutBasic], 0D);
   if(dbl>0){PriceTotOutBasic=PriceTotOutBasic+dbl;}
   dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(currrow)[ColTransPricePayOut], 0D);
   if(dbl>0){PaymentOutTot=PaymentOutTot+dbl;}
   dbl=PCore.objDouble(TableMdlTrans.Mdl.Rows.elementAt(currrow)[ColTransPricePayIn], 0D);
   if(dbl>0){PaymentInTot=PaymentInTot+dbl;}
   temp=temp+1;
  }while(temp!=count);

  // delete transactions
  success=PMyShop.removeTransactions(IFV.FSplashScreen, IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+DbAppLock, 10, wIsPreTrans, Id);
  
  IFV.FSplashScreen.disappear();
  
  if(!success){
   JOptionPane.showMessageDialog(null, "Gagal menghapus "+TransName+", tidak ada "+TransName+" yang dihapus !");
   return;
  }

  TableMdlTrans.remove(rows);
  onSelectedRowTransChanged(true);
  refreshQueryCount();
  updateQueryTempListCount();
  updateItemInSum(PriceTotIn, false);
  updateItemOutSum(PriceTotOut, false);
  updateItemOutBasicSum(PriceTotOutBasic, false);
  updatePaymentOutSum(PaymentOutTot, false);
  updatePaymentInSum(PaymentInTot, false);
 }
 void transChoose(){
  int[] rows=Tbl_Trans.getSelectedRows();
  int temp, temp2;
  Object[] objs;
  
  temp=rows.length;
  if(temp==0){
   JOptionPane.showMessageDialog(null, "Belum ada data "+TransName+" yang dipilih !");
   return;
  }
  
  ChoosedId=new Long[temp];
  temp2=0;
  do{
   objs=TableMdlTrans.Mdl.Rows.elementAt(rows[temp2]);
   ChoosedId[temp2]=(Long)objs[0];
   temp2=temp2+1;
  }while(temp2!=temp);
  
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }
 void printReceipt(){
  int[] rows;
  Vector<Book> books;
  Book bk;
  OPaper PaperType;
  PrintService Printer;
  long TransId;
  F_PrintTransReceipt fm=IFV.FPrintTransReceipt;
  int temp;
  int increase_n_times;
  long increase_every_n_records=0;
  double increase_size=0;
  
  rows=Tbl_Trans.getSelectedRows();
  if(rows.length==0){
   JOptionPane.showMessageDialog(null, "Silahkan pilih minimal 1 data "+TransName+" pada tabel untuk mencetak nota !");
   return;
  }

  fm.wUseIdExternal=0;

  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}

  IFV.FPrintDialog.wPaperType=IFV.CurrentReceiptPaper;
  IFV.FPrintDialog.wPrinter=IFV.CurrentReceiptPrinter;
  IFV.FPrintDialog.wPrintSettingMode=3;
  IFV.FPrintDialog.wEnableOption=false;

  if(IFV.FPrintDialog.showForm()==false){return;}
  if(IFV.FPrintDialog.DialogResult!=1){return;}
  PaperType=IFV.FPrintDialog.PaperType;
  Printer=IFV.FPrintDialog.Printer;
  
  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  
  increase_n_times=10;
  increase_every_n_records=rows.length/increase_n_times; if(increase_every_n_records==0){increase_every_n_records=1; increase_n_times=rows.length;}
  increase_size=(100-IFV.FSplashScreen.getProgress())/increase_n_times;
  
  temp=0; books=new Vector();
  do{
   TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(rows[temp])[0];
   IFV.PrintGenReceipt.setPrintVariables(PaperType, IFV.FontPrintReceipt, IFV.FontPrintReceiptThermal,
    IFV.Stm, TransId, wIsPreTrans,
    (IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemIn, IFV.PrivGUIShowPreTransItemIn)),
    (IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemOut, IFV.PrivGUIShowPreTransItemOut)),
    fm.UseIdExternal);
   bk=IFV.PrintGenReceipt.generateBook(null);
   if(bk==null){break;}
   books.addElement(bk);
   
   temp=temp+1;
   if(temp%increase_every_n_records==0){IFV.FSplashScreen.inform(increase_size, null, null);}
  }while(temp!=rows.length);
  
  IFV.FSplashScreen.disappear();
  
  if(temp!=rows.length){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
   return;
  }
  
  bk=PPrint.combineBooks(books);

  if(IFV.FPrintDialog.ChoosePage){
   IFV.FPrintPage.wBook=bk;

   if(IFV.FPrintPage.showForm()==false){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
  }

  if(!PPrint.print(bk, Printer, "Nota"+TransName+"_"+TransId+"_"+PText.dateToString(new Date(), 101), false)){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
   return;
  }
 }
 void printReport(){
  int temp, temp_;
  LinkedList<Long> TransId;
  Book bk;
  Vector<Object[]> TempRows;
  OPaper PaperType;
  PrintService Printer;
  F_PrintTransReport fm=IFV.FPrintTransReport;
  
  do{
   temp=TableMdlTrans.Mdl.Rows.size();
   if(temp==0){break;}
   
   fm.wOptMain_IdExternal=0;
   
   if(fm.showForm()==false){return;}
   if(fm.DialogResult!=1){break;}
   
   IFV.FPrintDialog.wPaperType=IFV.CurrentReportPaper;
   IFV.FPrintDialog.wPrinter=IFV.CurrentReportPrinter;
   IFV.FPrintDialog.wPrintSettingMode=2;
   IFV.FPrintDialog.wEnableOption=false;
   
   if(IFV.FPrintDialog.showForm()==false){return;}
   if(IFV.FPrintDialog.DialogResult!=1){break;}
   PaperType=IFV.FPrintDialog.PaperType;
   Printer=IFV.FPrintDialog.Printer;
   
   TempRows=TableMdlTrans.Mdl.Rows;
   TransId=new LinkedList();
   temp_=0;
   do{
    TransId.addLast((Long)TempRows.elementAt(temp_)[0]);
    temp_=temp_+1;
   }while(temp_!=temp);

   IFV.PrintGenTrans.setPrintVariables(PaperType, IFV.FontPrint, IFV.Stm, TransId, wIsPreTrans,
    fm.OptMain_IdExternal,
    fm.OptInfo_IdInternal, fm.OptInfo_IdExternal,
    fm.OptInfo_Important, fm.OptInfo_Comment, fm.OptInfo_TransType,
    fm.OptInfo_Date, fm.OptInfo_CreditDays, fm.OptInfo_DateBill, fm.OptInfo_DateRepayment,
    fm.OptInfo_CashOut, fm.OptInfo_CashOutComment, fm.OptInfo_CashIn, fm.OptInfo_CashInComment,
    fm.OptInfo_Subject, fm.OptInfo_Salesman,
    fm.OptList_ItemIn, fm.OptList_ItemOut,
    fm.OptList_PaymentOut, fm.OptList_PaymentIn,
    fm.OptList_ItemCategorized,
    IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemIn, IFV.PrivGUIShowPreTransItemIn),
    IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemOut, IFV.PrivGUIShowPreTransItemOut));
   
   IFV.FSplashScreen.appear(this, "Membuat Data Print");
   bk=IFV.PrintGenTrans.generateBook(IFV.FSplashScreen);
   IFV.FSplashScreen.disappear();
   if(bk==null){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
    break;
   }
   
   if(IFV.FPrintDialog.ChoosePage){
    IFV.FPrintPage.wBook=bk;
    
    if(IFV.FPrintPage.showForm()==false){return;}
    if(IFV.FPrintPage.DialogResult!=1){break;}
    if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
   }

   if(!PPrint.print(bk, Printer, "LapTrans_"+PText.dateToString(new Date(), 101), false)){
    JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
    break;
   }
  }while(false);
 }
 void printCSV(){
  F_PrintTransCSV fm1=IFV.FPrintTransCSV;
  F_CsvWriteOption fm2=IFV.FCsvWriteOption;
  File f;
  long OperationResult;
  long[] Ids;
  
  if(TableMdlTrans.Mdl.Rows.size()==0){return;}
  
  fm1.wIsPreTrans=wIsPreTrans;
  if(fm1.showForm()==false){return;}
  if(fm1.DialogResult!=1){return;}
  
  f=PGUI.showSaveDialog(IFV.FileChooser, IFV.CsvFileFilter, "csv");
  if(f==null){return;}
  
  if(fm2.showForm()==false){return;}
  if(fm2.DialogResult!=1){return;}
  
  Ids=TableMdlTrans.getIds(0, PCore.newIntegerArrayInOrderedSequence(TableMdlTrans.Mdl.Rows.size(), 0, 1));
  
  IFV.FSplashScreen.appear(this, "Print Data Ke File CSV");
  OperationResult=PMyShop.printTransCSV(
   IFV.FSplashScreen, IFV.Stm, f, fm2.FieldDelimiter, fm2.FieldsSeparator, CCore.CsvDefaultRecordsSeparator, Ids, wIsPreTrans,
   
   fm1.OptComment,
   fm1.OptTransDate, fm1.OptCreditDays, fm1.OptBillDate, fm1.OptRepaymentPeriod,
   fm1.OptSubject, fm1.OptSalesman, fm1.OptCashOut, fm1.OptCashOutComment, fm1.OptCashIn, fm1.OptCashInComment,
   fm1.OptId, fm1.OptIdExt, fm1.OptImportant,
   fm1.OptItemIn, fm1.OptPayOut, fm1.OptItemOut, fm1.OptPayIn, fm1.OptItemOutBasicPrice,

   fm1.OptListItemIn, fm1.OptListPayOut, fm1.OptListItemOut, fm1.OptListPayIn, fm1.OptListItemOutBasicPrice,
   fm1.OptListItemCategorized,
   
   IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemIn, IFV.PrivGUIShowPreTransItemIn),
   IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemOut, IFV.PrivGUIShowPreTransItemOut),
   IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice);
  IFV.FSplashScreen.disappear();
  
  if(OperationResult==-1){
   JOptionPane.showMessageDialog(null, "Terjadi kegagalan dalam proses print data ke file CSV !"+"\n"+PMyShop.getCSVErrorMessage());
   return;
  }
  
  /*
  JOptionPane.showMessageDialog(null,
   "Operasi berhasil !\n"+
   "Total data yg di-print ke file CSV = "+PText.intToString(OperationResult));
  */
 }
 void printPayment(boolean IsPaymentIn){
  JTable Tbl_Payment;
  OCustomTableModel TableMdlPayment;
  int[] SelectedRowsPayment;
  int SelectedRowTrans;
  long TransId;
  long[] PaymentsEnumeration;
  OPaper PaperType;
  PrintService Printer;
  Book bk;
  
  Tbl_Payment=(JTable)PCore.subtituteBool(IsPaymentIn, Tbl_PaymentIn, Tbl_PaymentOut);
  TableMdlPayment=(OCustomTableModel)PCore.subtituteBool(IsPaymentIn, TableMdlPaymentIn, TableMdlPaymentOut);
  SelectedRowsPayment=Tbl_Payment.getSelectedRows();
  SelectedRowTrans=Tbl_Trans.getSelectedRow();
  if(SelectedRowTrans==-1 || SelectedRowsPayment.length==0){return;}
  
  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(SelectedRowTrans)[0];
  PaymentsEnumeration=TableMdlPayment.getIds(0, SelectedRowsPayment);
  
  IFV.FPrintDialog.wPaperType=IFV.CurrentReceiptPaper;
  IFV.FPrintDialog.wPrinter=IFV.CurrentReceiptPrinter;
  IFV.FPrintDialog.wPrintSettingMode=3;
  IFV.FPrintDialog.wEnableOption=false;
  
  if(IFV.FPrintDialog.showForm()==false){return;}
  if(IFV.FPrintDialog.DialogResult!=1){return;}
  PaperType=IFV.FPrintDialog.PaperType;
  Printer=IFV.FPrintDialog.Printer;

  IFV.PrintGenTransPayment.setPrintVariables(PaperType, IFV.FontPrintReceipt, IFV.FontPrintReceiptThermal,
   IFV.Stm, TransId, PaymentsEnumeration, wIsPreTrans, IsPaymentIn);
  IFV.FSplashScreen.appear(this, "Membuat Data Print");
  bk=IFV.PrintGenTransPayment.generateBook(IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
  if(bk==null){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : tidak dapat menyelesaikan pembuatan data print !");
   return;
  }

  if(IFV.FPrintDialog.ChoosePage){
   IFV.FPrintPage.wBook=bk;
   
   if(IFV.FPrintPage.showForm()==false){return;}
   if(IFV.FPrintPage.DialogResult!=1){return;}
   if(!IFV.FPrintPage.PrintAll){bk=PPrint.subPage(bk, IFV.FPrintPage.PrintPages);}
  }

  if(!PPrint.print(bk, Printer, "BuktiPembayaran"+TransName+"_"+TransId+"_"+PText.dateToString(new Date(), 101), false)){
   JOptionPane.showMessageDialog(null, "Gagal mencetak : terjadi kesalahan ketika mulai mencetak !");
   return;
  }
 }
 int editTrans(int[] Rows, boolean FetchDataOld, OInfoTrans DataOld, OEditTrans Edit, boolean WithSplashScreen){
  int ret=-1; // 0 success, -1 unknown error, -2 Edited-Id has already exist
  long Id=0;
  OInfoTrans InfoTrans=null;
  boolean first, error, started;
  Object[] RowData;
  StringBuilder col;
  int Row, count, MaxList, curridx, currlistcount;
  String columns;
  Vector<OTableCellUpdater> Values, PostValues;
  
  long[] ids;
  boolean op_query;
  double progress_inc=0;
  int progress_inc_times;
  boolean IsCheckWithOldValue;
  
  do{
   count=Rows.length;
   op_query=false;

   if(count==1){
    RowData=TableMdlTrans.Mdl.Rows.elementAt(Rows[0]);
    Id=(Long)RowData[0];
    InfoTrans=DataOld; if(InfoTrans==null && FetchDataOld){InfoTrans=PMyShop.getTransInfo(IFV.Stm, wIsPreTrans, Id);}
   }
   IsCheckWithOldValue=(count==1 && InfoTrans!=null);

   Values=new Vector(); PostValues=new Vector();
   col=new StringBuilder();
   first=true;

   if(Edit.EditTransImportant){
    if(first){first=false;}else{col.append(',');}
    col.append("IsImportant="+PText.getString(Edit.EditedTransImportant, CCore.vTrue, CCore.vFalse));
    Values.addElement(new OTableCellUpdaterByObject(2, Edit.EditedTransImportant));
    op_query=true;
   }
   if(Edit.EditTransType){
    if(first){first=false;}else{col.append(',');}
    col.append("TransType="+PText.getString(Edit.EditedTransTypeId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(3, PText.getString(Edit.EditedTransTypeId, -1, Edit.EditedTransTypeName, null)));
    op_query=true;
   }
   if(Edit.EditCashIn){
    if(first){first=false;}else{col.append(',');}
    col.append("CashIn="+PText.getString(Edit.EditedCashInId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(14, PText.getString(Edit.EditedCashInId, -1, Edit.EditedCashInName, null)));
    op_query=true;
   }
   if(Edit.EditCashOut){
    if(first){first=false;}else{col.append(',');}
    col.append("Cash="+PText.getString(Edit.EditedCashOutId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(12, PText.getString(Edit.EditedCashOutId, -1, Edit.EditedCashOutName, null)));
    op_query=true;
   }
   if(Edit.EditTransSubject){
    if(first){first=false;}else{col.append(',');}
    col.append("Subject="+PText.getString(Edit.EditedTransSubjectId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(8, PCore.subtituteLong(Edit.EditedTransSubjectId, -1, Edit.EditedTransSubjectId, null)));
    Values.addElement(new OTableCellUpdaterByObject(9, PText.getString(Edit.EditedTransSubjectId, -1, Edit.EditedTransSubjectName, null)));
    op_query=true;
   }
   if(Edit.EditTransSalesman){
    if(first){first=false;}else{col.append(',');}
    col.append("Salesman="+PText.getString(Edit.EditedTransSalesmanId, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(10, PCore.subtituteLong(Edit.EditedTransSalesmanId, -1, Edit.EditedTransSalesmanId, null)));
    Values.addElement(new OTableCellUpdaterByObject(11, PText.getString(Edit.EditedTransSalesmanId, -1, Edit.EditedTransSalesmanName, null)));
    op_query=true;
   }
   if(Edit.EditTransComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubTransComment){
     col.append("Comment="+PText.getStringWithQuote(PSql.norm(Edit.EditedTransComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(-1, PText.getString(Edit.EditedTransComment, null, true)));
    }
    else{
     col.append("Comment=replace(Comment, '"+PSql.norm(Edit.SubTransComment)+"', '"+PSql.norm(Edit.EditedTransComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(-1, true, Edit.SubTransComment, Edit.EditedTransComment));
    }
    op_query=true;
   }
   if(Edit.EditTransInfoIdExternal){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubTransInfoIdExternal){
     col.append("InfoIdExternal="+PText.getStringWithQuote(PSql.norm(Edit.EditedTransInfoIdExternal), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(1, PText.getString(Edit.EditedTransInfoIdExternal, null, true)));
    }
    else{
     col.append("InfoIdExternal=replace(InfoIdExternal, '"+PSql.norm(Edit.SubTransInfoIdExternal)+"', '"+PSql.norm(Edit.EditedTransInfoIdExternal)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(1, true, Edit.SubTransInfoIdExternal, Edit.EditedTransInfoIdExternal));
    }
    op_query=true;
   }
   if(Edit.EditCashOutComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubCashOutComment){
     col.append("CashOutComment="+PText.getStringWithQuote(PSql.norm(Edit.EditedCashOutComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(13, PText.getString(Edit.EditedCashOutComment, null, true)));
    }
    else{
     col.append("CashOutComment=replace(CashOutComment, '"+PSql.norm(Edit.SubCashOutComment)+"', '"+PSql.norm(Edit.EditedCashOutComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(13, true, Edit.SubCashOutComment, Edit.EditedCashOutComment));
    }
    op_query=true;
   }
   if(Edit.EditCashInComment){
    if(first){first=false;}else{col.append(',');}
    if(!Edit.ReplaceSubCashInComment){
     col.append("CashInComment="+PText.getStringWithQuote(PSql.norm(Edit.EditedCashInComment), CCore.vNull, '\'', true));
     Values.addElement(new OTableCellUpdaterByObject(15, PText.getString(Edit.EditedCashInComment, null, true)));
    }
    else{
     col.append("CashInComment=replace(CashInComment, '"+PSql.norm(Edit.SubCashInComment)+"', '"+PSql.norm(Edit.EditedCashInComment)+"')");
     Values.addElement(new OTableCellUpdaterBySubString(15, true, Edit.SubCashInComment, Edit.EditedCashInComment));
    }
    op_query=true;
   }
   if(Edit.EditTransDate){
    if(first){first=false;}else{col.append(',');}
    col.append("TransDate="+PDatabase.dateToSQLStringFormat(Edit.EditedTransDate));
    Values.addElement(new OTableCellUpdaterByObject(4, Edit.EditedTransDate));
    op_query=true;
   }
   if(Edit.EditTransCreditDays){
    if(first){first=false;}else{col.append(',');}
    col.append("CreditDays="+PText.getString(Edit.EditedTransCreditDays, CCore.vNull, -1, false));
    Values.addElement(new OTableCellUpdaterByObject(5,
     PCore.subtituteLong(Edit.EditedTransCreditDays, -1, PDate.calculateDateByDay(Edit.EditedTransDate, Edit.EditedTransCreditDays, 1), null)));
    op_query=true;
   }
   if(Edit.EditTransRepayPeriod){
    if(first){first=false;}else{col.append(',');}
    col.append("RepaymentPeriodStart="+PDatabase.dateToSQLStringFormat(Edit.EditedTransRepayPeriodStart));
    Values.addElement(new OTableCellUpdaterByObject(6, Edit.EditedTransRepayPeriodStart));
    
    if(first){first=false;}else{col.append(',');}
    col.append("RepaymentPeriodEnd="+PDatabase.dateToSQLStringFormat(Edit.EditedTransRepayPeriodEnd));
    Values.addElement(new OTableCellUpdaterByObject(7, Edit.EditedTransRepayPeriodEnd));
    
    op_query=true;
   }

   // here is the place for table's columns that its value is depend on other columns's value (PostValues)

   // update
   if(WithSplashScreen){IFV.FSplashScreen.appear(this, "Mengubah Data "+TransName);}
   
   if(WithSplashScreen){IFV.FSplashScreen.inform(0, "Mengubah "+PText.intToString(count)+" data "+TransName+", harap menunggu ...", null);}
   
   error=false;
   MaxList=1000;
   do{
    if(WithSplashScreen){
     IFV.FSplashScreen.setProgressIncreasePercentage(75);
     progress_inc_times=PMath.round((double)count/(double)MaxList, 1); if(progress_inc_times==0){progress_inc_times=1;}
     progress_inc=(double)100/(double)progress_inc_times;
    }
    
    columns=col.toString();
    
    curridx=0;
    started=false;
    do{
     try{
      IFV.Stm.executeUpdate("start transaction;");
      started=true;

      do{
       currlistcount=MaxList;
       if(curridx+currlistcount>count){currlistcount=count-curridx;}
       ids=TableMdlTrans.getIds(0, PCore.subArr(Rows, curridx, currlistcount));

       if(op_query){
        IFV.Stm.executeUpdate("update "+DbTable+" set "+columns+" where Id in("+PText.toString(ids, 0, ids.length, ",")+");");
       }
       
       if(WithSplashScreen){IFV.FSplashScreen.inform(progress_inc, null, null);}

       curridx=curridx+currlistcount;
      }while(curridx!=count);
      if(error){break;}

      IFV.Stm.executeUpdate("commit;");
     }
     catch(Exception E){error=true; break;}
    }while(false);
    if(error){
     if(started){try{IFV.Stm.executeUpdate("rollback;");}catch(Exception E){}}
     break;
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.setProgressIncreasePercentage(100);}

    // post-update

     // update table
    PGUI.changeElements(TableMdlTrans, Rows, Values);
    PGUI.changeElements(TableMdlTrans, Rows, PostValues);
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(20, null, null);}

     // update detail
    Id=-1; Row=Tbl_Trans.getSelectedRow(); if(Row!=-1){Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(Row)[0];}

    if(TabbedPane.getSelectedIndex()==1 || TIDet==true){
     fillDet(Id);
    }
    
    if(WithSplashScreen){IFV.FSplashScreen.inform(5, null, null);}
   }while(false);
   if(WithSplashScreen){IFV.FSplashScreen.disappear();}
   
   if(error){break;}
   
   ret=0;
  }while(false);
  
  return ret;
 }
 void editSingle(int Row){
  long Id;
  OInfoTrans InfoTrans;
  F_TransModify fm=IFV.FTransModify;
  OEditTrans Edit;
  int result;
  
  Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(Row)[0];
  InfoTrans=PMyShop.getTransInfo(IFV.Stm, wIsPreTrans, Id);
  if(InfoTrans==null){
   JOptionPane.showMessageDialog(null, "Tidak dapat mengubah : terjadi kesalahan ketika mengambil keterangan "+TransName+" dari database !");
   return;
  }
  fm.wMode=2;
  fm.wTransId=Id;
  fm.wInfoTrans=InfoTrans;
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}

  Edit=new OEditTrans();
  Edit.init(
   true, false, null, fm.TransInfoIdExternal,
   true, fm.TransImportant,
   true, fm.TransDate,
   true, fm.TransCreditDays,
   true, fm.TransRepayPeriodStart, fm.TransRepayPeriodEnd,
   true, fm.TransTypeId, fm.TransTypeName,
   true, fm.CashOutId, fm.CashOutName,
   true, false, null, fm.CashOutComment,
   true, fm.CashInId, fm.CashInName,
   true, false, null, fm.CashInComment,
   true, fm.TransSubjectId, fm.TransSubjectName,
   true, fm.TransSalesmanId, fm.TransSalesmanName,
   true, false, null, fm.TransComment);

  result=editTrans(PCore.primArr(Row), false, InfoTrans, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
  else if(result==-2){}
 }
 void editMultiple(int[] Rows){
  int count=Rows.length;
  F_TransModifyMulti fm;
  OEditTrans Edit;
  int result;
  
  fm=IFV.FTransModifyMulti;
  fm.wDataCount=count;
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  Edit=new OEditTrans();
  Edit.init(
   fm.ChangeInfoIdExternal, fm.ChangeInfoIdExternalSub, fm.TransInfoIdExternalSub, fm.TransInfoIdExternal,
   fm.ChangeImportant, fm.TransImportant,
   false, null,
   false, -1,
   false, null, null,
   fm.ChangeType, fm.TransTypeId, fm.TransTypeName,
   fm.ChangeCashOut, fm.CashOutId, fm.CashOutName,
   fm.ChangeCashOutComment, fm.ChangeCashOutCommentSub, fm.TransCashOutCommentSub, fm.TransCashOutComment,
   fm.ChangeCashIn, fm.CashInId, fm.CashInName,
   fm.ChangeCashInComment, fm.ChangeCashInCommentSub, fm.TransCashInCommentSub, fm.TransCashInComment,
   fm.ChangeSubject, fm.TransSubjectId, fm.TransSubjectName,
   fm.ChangeSalesman, fm.TransSalesmanId, fm.TransSalesmanName,
   fm.ChangeComment, fm.ChangeCommentSub, fm.TransCommentSub, fm.TransComment);
  
  result=editTrans(Rows, false, null, Edit, true);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
  else if(result==-2){}
 }
 boolean signItemsWithMissmatch(int Resolution,
  Vector<Object[]> TransItems, int IndexOfItemId, int[] ChangeIndex){
  boolean ret=false;
  Connection AdminCon;
  Statement AdminStm;
  boolean UseExternalStm;
  boolean adminstm_setup;
  
  AdminCon=null;
  AdminStm=IFV.Stm; UseExternalStm=false;
  do{
   try{
    if(Resolution==1){
     AdminCon=IFV.FLogin.loginTemporary("Login Sementara Sbg User Lain Utk Menandai 'Mismatch Stok'");
     if(AdminCon==null){break;}
     adminstm_setup=false;
     do{
      try{
       AdminStm=AdminCon.createStatement(); UseExternalStm=true;
       if(!IFV.useDb(AdminStm, IFV.CurrentDatabase)){break;}
      }catch(Exception E){break;}
      adminstm_setup=true;
     }while(false);
     if(!adminstm_setup){
      JOptionPane.showMessageDialog(null, "Tdk dapat melanjutkan operasi, terjadi error\n"+
       "ketika mencoba login sementara sebagai User Lain.");
      break;
     }
    }

    if(!PMyShop.assignItemsWithMismatchStock(AdminStm, TransItems, IndexOfItemId, ChangeIndex)){
     JOptionPane.showMessageDialog(null, "Tdk dapat melanjutkan operasi :\n"+
      "gagal menandai barang dgn 'Mismatch Stok' !");
     break;
    }
   }
   catch(Exception E){break;}
   ret=true;
  }while(false);

  if(AdminStm!=null && UseExternalStm){try{AdminStm.close(); AdminStm=null;}catch(Exception E){}}
  if(AdminCon!=null){try{AdminCon.close(); AdminCon=null;}catch(Exception E){}}
  
  return ret;
 }
 void labelAdd(OCustomTableModel TableMdl, int[] SelectedRows, int ColId, int ColQty){
  Vector<Object[]> AddData;
  int temp, length, LabelCount;
  Object[] CurrRow;
  
  length=SelectedRows.length;
  if(length==0){return;}
  
  AddData=new Vector();
  
  temp=0;
  do{
   CurrRow=TableMdl.Mdl.Rows.elementAt(SelectedRows[temp]);
   
   LabelCount=PMath.round((Double)CurrRow[ColQty], 1); if(LabelCount<=0){LabelCount=1;}
   if(LabelCount>=1){
    AddData.addElement(PCore.objArrVariant(CurrRow[ColId], LabelCount, ""));
   }
   
   temp=temp+1;
  }while(temp!=length);
  
  IFV.FSplashScreen.appear(this, "Menambahkan Data Label");
  IFV.FItemLabel.addLabelFromExternal(AddData, IFV.FSplashScreen);
  IFV.FSplashScreen.disappear();
 }
 void changeItemPrice(boolean IsBuyPrice, OCustomTableModel TableMdl, int[] SelectedRows, int ColId, int ColPriceUnit, boolean OnlyPriceNonZero){
  String[] UpdateCols=null;
  Vector<Object[]> ListData;
  Date LastUpdate;
  int temp, length;
  Object[] CurrRow;
  boolean success;
  Double PriceUnit;
  
  length=SelectedRows.length;
  if(length==0){return;}
  
  ListData=new Vector();
  LastUpdate=new Date();
  temp=0;
  do{
   CurrRow=TableMdl.Mdl.Rows.elementAt(SelectedRows[temp]);
   
   PriceUnit=PCore.objDouble(CurrRow[ColPriceUnit], null);
   if(!OnlyPriceNonZero || (OnlyPriceNonZero && PCore.objDouble(PriceUnit, -1D)>0)){
    ListData.addElement(PCore.objArrVariant(CurrRow[ColId], PriceUnit, LastUpdate));
   }
   
   temp=temp+1;
  }while(temp!=length);
  
  success=PDatabase.update_MultiRecords_EachRecordDifferentValues_ValuesFromList(IFV.Stm, "Item",
   (String[])PCore.subtituteBool(IsBuyPrice, PCore.refArr("BuyPriceEstimation", "BuyUpdate"), PCore.refArr("SellPrice", "SellUpdate")), PCore.refArr("Id"),
   ListData, PCore.primArr(CCore.TypeLong, CCore.TypeDouble, CCore.TypeDate), PCore.newIntegerArrayInOrderedSequence(ListData.size(), 0, 1),
   PCore.primArr(1, 2), PCore.primArr(0));
  
  if(!success){
   JOptionPane.showMessageDialog(null, "Gagal memperbaharui "+PText.getString(IsBuyPrice, "Harga Beli", "Harga Jual")+" barang !");
  }
 }
 void addOrdItems(boolean IsItemIn, boolean AlsoRemoveTransItems){
  JTable Tbl_Item=(JTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemIn, TableMdlIn, TableMdlOut);
  JTextField TF_ItemCount=(JTextField)PCore.subtituteBool(IsItemIn, TF_InCount, TF_OutCount);
  String TbTransItem=DbTable+"XItem"+PText.getString(IsItemIn, "In", "Out");
  int[] SelectedRowsItem;
  int SelectedRowTrans;
  long TransId;
  boolean error;
  String Query;
  long[] ItemsId;
  String StrItems;
  Vector<Object[]> GeneratedData;
  double TotalPriceOld;
  double TotalPriceBasicOld;
  
  SelectedRowTrans=Tbl_Trans.getSelectedRow();
  SelectedRowsItem=Tbl_Item.getSelectedRows();
  
  if(SelectedRowsItem.length==0){return;}
  if(SelectedRowTrans==-1){JOptionPane.showMessageDialog(null, "Pilih 1 data "+TransName+" pada tabel "+TransName+" !"); return;}
  
  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(SelectedRowTrans)[0];
  ItemsId=TableMdlItem.getIds(0, SelectedRowsItem);
  StrItems=PText.toString(ItemsId, 0, ItemsId.length, ",");
  
  if(JOptionPane.showConfirmDialog(null,
   "Tambahkan "+PText.intToString(SelectedRowsItem.length)+" data barang ke daftar order ?"+
    PText.getString(AlsoRemoveTransItems, "\n(juga batalkan data barang pd "+TransName+" yg bersangkutan)", ""),
   "Konfirmasi Penambahan Data Barang Ke Daftar Order", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
   return;
  }
  
  IFV.FSplashScreen.appear(this, "Menambah Data Order");
  do{
   
   error=false;
   do{
    
    IFV.FSplashScreen.inform(0, "Mempersiapkan operasi ...", "-");
    
    // generate items order that will be added to item's order quantity
    GeneratedData=new Vector();
    Query="select Item, Stock from "+TbTransItem+" where "+DbTable+"="+TransId+" and Item in("+StrItems+")";
    if(PDatabase.queryToRows(IFV.Stm, Query, GeneratedData, PCore.primArr(CCore.TypeLong, CCore.TypeDouble))==-1){error=true; break;}
    
    IFV.FSplashScreen.inform(15, null, null);
    
    // add generated items order to item's order quantity
    IFV.FSplashScreen.inform(0, "Menambah qty order pd brg ...", "-");
    
    if(addOrdItems(IFV.FSplashScreen, GeneratedData, AlsoRemoveTransItems, TransId, wIsPreTrans, IsItemIn, ItemsId)==false){error=true; break;}
    
   }while(false);
   if(error){break;}

   // update gui
   IFV.FSplashScreen.inform(0, "Memperbaharui tampilan form ...", "-");

   if(AlsoRemoveTransItems){
    IFV.FSplashScreen.inform(0, null, "Menghapus daftar brg pd "+TransName);
    
    TotalPriceOld=(Double)PGUI.sumColumns(TableMdlItem, PCore.primArr(5), SelectedRowsItem)[0];
    if(IsItemIn){
     updateTransItemInPrice(SelectedRowTrans, TableMdlItem.Mdl.Rows.size()==SelectedRowsItem.length, TotalPriceOld, false);
    }
    else{
     TotalPriceBasicOld=(Double)PGUI.sumColumns(TableMdlItem, PCore.primArr(11), SelectedRowsItem)[0];
     updateTransItemOutPrice(SelectedRowTrans, TableMdlItem.Mdl.Rows.size()==SelectedRowsItem.length, TotalPriceOld, false);
     updateTransItemOutBasicPrice(SelectedRowTrans, TableMdlItem.Mdl.Rows.size()==SelectedRowsItem.length, TotalPriceBasicOld, false);
    }
    TableMdlItem.remove(SelectedRowsItem);
    if(IsItemIn){onSelectedRowInChanged(true);}else{onSelectedRowOutChanged(true);}
    refreshItemCount(TF_ItemCount, TableMdlItem);
   }
   
   IFV.FSplashScreen.inform(10, null, null);
   
  }while(false);
  IFV.FSplashScreen.disappear();
  
  if(error){JOptionPane.showMessageDialog(null, "Gagal melakukan operasi : Terjadi error ketika melakukan operasi !");}
 }
 boolean addOrdItems(OFormInformProgress Progress,
  Vector<Object[]> NewOrdItems, boolean AlsoRemoveTransItems, long TransId, boolean IsPreTrans, boolean IsItemIn,
  long[] ItemsId){
  // this procedure takes 75% of Progress
  boolean ret=true;
  String Query;
  Vector<Object[]> UpdateData;
  
  // add generated items order to item's order quantity
  if(Progress!=null){Progress.inform(0, null, "Memperbarui order pd database");}
  do{

   if(NewOrdItems.size()==0){
    if(Progress!=null){Progress.inform(65, null, null);}
    break;
   }

   if(Progress!=null){Progress.progressInformExternalMode(true, 65);}
   if(!PMyShop.addItemsOrder(Progress, IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.OrderLock, 10,
    NewOrdItems, 0, 1, AlsoRemoveTransItems, TransId, IsPreTrans, IsItemIn)){ret=false; break;}
   if(Progress!=null){Progress.progressInformExternalMode(false, 100);}

  }while(false);
  if(ret==false){return ret;}

  // update gui
  if(Progress!=null){Progress.inform(0, null, "Memperbarui order pd form");}
  do{

   UpdateData=new Vector();
   Query=queryOfOrd(ItemsId);
   if(PDatabase.queryToRows(IFV.Stm, Query, UpdateData, TableMdlOrd.getColumnsType())==-1){break;}
   addReplaceOrd(UpdateData);

  }while(false); 
  if(Progress!=null){Progress.inform(10, null, null);}
  
  return ret;
 }
 void ordMove(){
  int[] RowsItem=Tbl_Ord.getSelectedRows();
  int[] RowsTrans=Tbl_Trans.getSelectedRows();
  Vector<Object[]> GeneratedData=null;
  Vector<Object[]> UpdateData;
  String Query, QueryItem, QueryTrans, QuerySelf;
  long TransId;
  long[] Items;
  boolean error;
  double TotalPriceOld;
  String StrItems;
  String TbItemIn;
  OInfoTrans TransInfo;
  double ToleranceTop, ToleranceDown;
  
  if(RowsItem.length==0){return;}
  if(RowsTrans.length==0){JOptionPane.showMessageDialog(null, "Pilih 1 data "+TransName+" pada tabel "+TransName+" !"); return;}
  if(RowsTrans.length>1){JOptionPane.showMessageDialog(null, "Tidak boleh memilih >1 data "+TransName+" pada tabel "+TransName+" !"); return;}
  
  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(RowsTrans[0])[0];
  Items=TableMdlOrd.getIds(0, RowsItem);
  StrItems=PText.toString(Items, 0, Items.length, ",");
  TbItemIn=DbTable+"XItemIn";
  ToleranceTop=(100+CApp.TransPriceAndPriceEstTolerance)/100;
  ToleranceDown=(100-CApp.TransPriceAndPriceEstTolerance)/100;
  
  if(!wIsPreTrans){
   if(JOptionPane.showConfirmDialog(null,
    "Tambahkan "+PText.intToString(RowsItem.length)+" data order ke dalam '"+TransName+" : "+TransId+"' ?",
    "Konfirmasi Penambahan Data Order Ke "+TransName, JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
    return;
   }
  }
  
  error=false;
  
  IFV.FSplashScreen.appear(this, "Memasukkan Data Order");
  do{
   
   do{
    
    IFV.FSplashScreen.inform(0, "Mempersiapkan operasi ...", "-");
    
    // generate trans items that will be inserted to trans
    GeneratedData=new Vector();

    QueryItem=
     "select Id as 'I_Item', BuyPriceEstimation as 'I_ItemPrice', OrderQuantity from Item "+
      "where Id in("+StrItems+") and OrderQuantity is not "+CCore.vNull+" and ifnull(OrderQuantity,0)>0";
    
    QuerySelf=
     "select Item as 'S_Item', Price/Stock as 'S_ItemPrice' from "+TbItemIn+" where "+DbTable+"="+TransId+" and Item in("+StrItems+")";

    QueryTrans="select null as 'T_Item', null as 'T_ItemPrice'";
    TransInfo=PMyShop.getTransInfo(IFV.Stm, wIsPreTrans, TransId);
    if(TransInfo==null){error=true; break;}
    if(TransInfo.SubjectId!=-1){
     QueryTrans=
      "select T_Item, T_ItemPrice, max(T_Date) from "+
       "(select t_3.*, max(T_Id) from "+
        "(select t_2.* from "+
         "(select t_1.*, Item as 'T_Item', Price/Stock as 'T_ItemPrice' from "+
          "(select Id as 'T_Id', TransDate as 'T_Date' from Trans where Subject="+TransInfo.SubjectId+") as t_1 "+
         "cross join TransXItemIn on t_1.T_Id=TransXItemIn.Trans where Item in("+StrItems+") and Price>0) as t_2 "+
        "cross join Item on t_2.T_Item=Item.Id where T_ItemPrice>="+PText.doubleToString(ToleranceDown, false)+"*BuyPriceEstimation and T_ItemPrice<="+PText.doubleToString(ToleranceTop, false)+"*BuyPriceEstimation) as t_3 "+
       "group by T_Item, T_Date) as t_4 "+
      "group by T_Item";
    }
     
    Query=
     "select I_Item, OrderQuantity, OrderQuantity*"+
      "if(S_ItemPrice is not "+CCore.vNull+", "+
       "S_ItemPrice, "+
       "if(T_ItemPrice is not "+CCore.vNull+", "+
        "T_ItemPrice, "+
        "I_ItemPrice"+
       ")"+
      ") "+
     "from "+
      "(select q1.*, S_ItemPrice from "+
       "("+QueryItem+") as q1 "+
      "left join ("+QuerySelf+") as q2 on q1.I_Item=q2.S_Item) as q3 "+
     "left join ("+QueryTrans+") as q4 on q3.I_Item=q4.T_Item";

    if(PDatabase.queryToRows(IFV.Stm, Query, GeneratedData, PCore.primArr(CCore.TypeLong, CCore.TypeDouble, CCore.TypeDouble))==-1){error=true; break;}
    
    IFV.FSplashScreen.inform(10, null, null);
    
    // insert generated trans items to trans
    IFV.FSplashScreen.inform(0, "Memasukkan order ke "+TransName+" ...", "-");
    do{
     
     if(GeneratedData.size()==0){IFV.FSplashScreen.inform(75, null, null); break;}
     
     IFV.FSplashScreen.progressInformExternalMode(true, 75);
     if(!PMyShop.addTransactionItems(IFV.FSplashScreen, IFV.Stm, wIsPreTrans, true, true, TransId, GeneratedData, 0, 1, 2,
      true, PText.getString(IFV.CurrentDatabase, "", false)+IFV.OrderLock, 10)){error=true; break;}
     IFV.FSplashScreen.progressInformExternalMode(false, 100);
    
    }while(false);
    if(error){break;}
    
   }while(false);
   if(error){break;}

   // update gui
   IFV.FSplashScreen.inform(0, "Memperbaharui tampilan form ...", "-");

   IFV.FSplashScreen.inform(0, null, "Menghapus daftar order");
   
   TotalPriceOld=(Double)PGUI.sumColumns(TableMdlOrd, PCore.primArr(6), RowsItem)[0];
   TableMdlOrd.remove(RowsItem); onSelectedRowOrdChanged(true);
   refreshOrdCount(); updateOrdPriceEst(TotalPriceOld, false);
   
   IFV.FSplashScreen.inform(5, null, null);

   IFV.FSplashScreen.inform(0, null, "Menambah daftar barang masuk");
   do{
    
    UpdateData=new Vector();
    Query=queryOfItemIn(TransId, Items);
    if(PDatabase.queryToRows(IFV.Stm, Query, UpdateData, TableMdlIn.getColumnsType())==-1){break;}
    addReplaceItemIn(RowsTrans[0], UpdateData);
    
   }while(false);
   IFV.FSplashScreen.inform(10, null, null);
  
  }while(false);
  IFV.FSplashScreen.disappear();
  
  if(error){JOptionPane.showMessageDialog(null, "Gagal melakukan operasi : Terjadi error ketika melakukan operasi !");}
 }
 
 void queryOnKeyPressed_Text(KeyEvent evt, JCheckBox QCB, JTextField QTF){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF.getCaretPosition()==QTF.getDocument().getLength()){
     focusQueryResult();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange1(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF1.getCaretPosition()==QTF1.getDocument().getLength()){
     QTF2.requestFocusInWindow();
    }
    break;
  }
 }
 void queryOnKeyPressed_TextRange2(KeyEvent evt, JCheckBox QCB, JTextField QTF1, JTextField QTF2){
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    QCB.setSelected(true);
    Btn_QueryActionPerformed(null);
    break;
   case KeyEvent.VK_LEFT:
    if(QTF2.getCaretPosition()==0){
     QTF1.requestFocusInWindow();
    }
    break;
   case KeyEvent.VK_RIGHT:
    if(QTF2.getCaretPosition()==QTF2.getDocument().getLength()){
     focusQueryResult();
    }
    break;
  }
 }
 
 void checkItems(boolean IsItemIn, boolean IsAdd){
  JTable Tbl_Item=(JTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  checkItems(IsItemIn, Tbl_Item.getSelectedRows(), IsAdd);
 }
 void checkItems(boolean IsItemIn, int[] RowsItem, boolean IsAdd){
  OCustomTableModel TableMdlItem=null;
  String DbTableItem=null;
  JTextField TF_ItemCount=null;
  int RowTrans;
  long IdTrans;
  long[] IdItems;
  boolean error;
  
  if(IsItemIn){
   TableMdlItem=TableMdlIn;
   DbTableItem=DbTable+"XItemIn";
   TF_ItemCount=TF_InCount;
  }
  else{
   TableMdlItem=TableMdlOut;
   DbTableItem=DbTable+"XItemOut";
   TF_ItemCount=TF_OutCount;
  }
  
  RowTrans=Tbl_Trans.getSelectedRow();
  if(RowTrans==-1 || RowsItem.length==0){return;}
  
  IdTrans=(Long)TableMdlTrans.Mdl.Rows.elementAt(RowTrans)[0];
  IdItems=TableMdlItem.getIds(0, RowsItem);
  
  error=false;
  try{
   IFV.Stm.execute("update "+DbTableItem+" set Checked="+PText.getString(IsAdd, CCore.vTrue, CCore.vFalse)+
    " where "+DbTable+"="+IdTrans+" and Item in("+PText.toString(IdItems, 0, IdItems.length, ",")+")");
  }
  catch(Exception E){error=true;}
  if(error){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !"); return;}
  
  TableMdlItem.setChecked(RowsItem, IsAdd);
  refreshItemCount(TF_ItemCount, TableMdlItem);
 }
 
 void editOrders(int[] RowsOrd, double OrderQty){
  long[] Ids;
  Vector<OTableCellUpdater> TableUpdaters, PostTableUpdaters;
  double PriceOld, PriceNew;
  
  Ids=TableMdlOrd.getIds(0, RowsOrd);
  
  if(!PMyShop.updateOrder(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.OrderLock, 10, Ids, true, 0, OrderQty)){
   JOptionPane.showMessageDialog(null, "Gagal mengubah data order : Terjadi error ketika melakukan operasi !");
   return;
  }
  
  PriceOld=(Double)PGUI.sumColumns(TableMdlOrd, PCore.primArr(6), RowsOrd)[0];
  
  TableUpdaters=new Vector();
  TableUpdaters.addElement(new OTableCellUpdaterByObject(3, OrderQty));
  
  PostTableUpdaters=new Vector();
  PostTableUpdaters.addElement(
   new OTableCellUpdaterByCalculation(6,
    new OCalculationOperandTableCell(TableMdlOrd, 5, 0, -1, 0, -1, 0, 0),
    new OCalculation(
     new OCalculationOperandTableCell(TableMdlOrd, 3, 0, -1, 0, -1, 0, 0),
     CMath.Times, true, 0))
  );
  
  PGUI.changeElements(TableMdlOrd, RowsOrd, TableUpdaters);
  PGUI.changeElements(TableMdlOrd, RowsOrd, PostTableUpdaters);
  
  PriceNew=(Double)PGUI.sumColumns(TableMdlOrd, PCore.primArr(6), RowsOrd)[0];
  
  updateOrdPriceEst(PriceNew-PriceOld, true);
  onSelectedRowOrdChanged(true);
 }
 
 void editItems(boolean IsItemIn){
  JTable Tbl_Item=(JTable)PCore.subtituteBool(IsItemIn, Tbl_In, Tbl_Out);
  OCustomTableModel TableMdlItem=(OCustomTableModel)PCore.subtituteBool(IsItemIn, TableMdlIn, TableMdlOut);
  int rowTrans=Tbl_Trans.getSelectedRow();
  int[] rows=Tbl_Item.getSelectedRows();
  OEditTransItem Edit=new OEditTransItem();
  F_TransItemModify fm1=IFV.FTransItemModify;
  F_TransItemModifyMulti fm2=IFV.FTransItemModifyMulti;
  Object[] Objs;
  
  if(rowTrans==-1 || rows.length==0){return;}

  if(rows.length==1){
   Objs=TableMdlItem.Mdl.Rows.elementAt(rows[0]);
   fm1.wMode=1;
   fm1.wItemId=(Long)Objs[0];
   fm1.wQuantity=(Double)Objs[3];
   fm1.wPriceTotal=(Double)Objs[5];
   fm1.wTransItemComment=PCore.objString(Objs[7], null);
   
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}

   Edit.init(
    true, fm1.Qty,
    false, -1,
    true, fm1.PriceTotal,
    true, false, null, fm1.TransItemComment);
  }
  else{
   fm2.wDataCount=rows.length;
   
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    fm2.ChangeQuantity, fm2.Quantity,
    fm2.ChangePriceUnit, fm2.PriceUnit,
    fm2.ChangePriceTotal, fm2.PriceTotal,
    fm2.ChangeTransItemComment, fm2.ChangeTransItemCommentSubString, fm2.TransItemCommentFind, fm2.TransItemComment);
  }
  
  editItems(IsItemIn, rowTrans, rows, Edit);
 }
 void editItems(boolean IsItemIn, int TransRow, int[] ItemRows, OEditTransItem Edit){
  if(IsItemIn){editItemsIn(TransRow, ItemRows, Edit);}
  else{editItemsOut(TransRow, ItemRows, Edit);}
 }
 void editItemsIn(int TransRow, int[] ItemRows, OEditTransItem Edit){
  boolean[] IsChanged;
  int temp, ChangedCount;
  long TransId, ItemId;
  double SumPriceOld, SumPriceNew;
  int[] ChangedRows;
  Vector<OTableCellUpdater> ChangeValues;
  OTableCellUpdaterByCalculation UpdaterPrice;
  boolean bool;
  
  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(TransRow)[0];
  IsChanged=PCore.newBooleanArray(ItemRows.length, false);
  ChangedCount=0;

  bool=true;
  do{
   temp=0;
   do{
    if(IsChanged[temp]==false){
     ItemId=(Long)TableMdlIn.Mdl.Rows.elementAt(ItemRows[temp])[0];
     if(PMyShop.editATransactionItem(IFV.Stm, wIsPreTrans, true, TransId, ItemId, Edit)){
      IsChanged[temp]=true;
      ChangedCount=ChangedCount+1;
     }
    }
    temp=temp+1;
   }while(temp!=ItemRows.length);

   if(ChangedCount==ItemRows.length){break;}

   IFV.FMessage.showMessage("Gagal mengubah "+(ItemRows.length-ChangedCount)+" data :\n"+
    PText.toStringWithQuote(TableMdlIn.Mdl.Rows, PGUI.getPickedRows(ItemRows, IsChanged, false), "\n",
    PCore.primArr(1, 0), PCore.primArr(false, false), "> ", ".", ", ", "", "", false), PCore.vectObj(
    "Lanjut selesaikan pengubahan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan pengubahan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){break;}

   if(!signItemsWithMissmatch(IFV.FMessage.Resolution, TableMdlIn.Mdl.Rows, 0, PGUI.getPickedRows(ItemRows, IsChanged, false))){break;}
  }while(bool);

  if(ChangedCount!=0){
   ChangedRows=PGUI.getPickedRows(ItemRows, IsChanged, true);

   SumPriceOld=(Double)PGUI.sumColumns(TableMdlIn, PCore.primArr(5), ChangedRows)[0];

   ChangeValues=new Vector();
   if(Edit.EditQuantity){
    ChangeValues.addElement(new OTableCellUpdaterByObject(3, Edit.EditedQuantity));
   }
   if(Edit.EditPriceTotal){
    ChangeValues.addElement(new OTableCellUpdaterByObject(5, Edit.EditedPriceTotal));
   }
   if(Edit.EditPriceUnit){
    ChangeValues.addElement(new OTableCellUpdaterByObject(6, Edit.EditedPriceUnit));
   }
   if(Edit.EditComment){
    if(!Edit.ReplaceSubComment){
     ChangeValues.addElement(new OTableCellUpdaterByObject(7, PText.getString(Edit.EditedComment, null, true)));
    }
    else{
     ChangeValues.addElement(new OTableCellUpdaterBySubString(7, true, Edit.SubComment, Edit.EditedComment));
    }
   }
   PGUI.changeElements(TableMdlIn, ChangedRows, ChangeValues);

   ChangeValues=new Vector();
   if(Edit.EditComment){
    ChangeValues.addElement(new OTableCellUpdaterByAppTransItemName(2, 1, 7));
   }
   if(Edit.EditQuantity || Edit.EditPriceTotal || Edit.EditPriceUnit){
    // change Price Unit or Price Total
    if(Edit.EditPriceTotal){
     UpdaterPrice=new OTableCellUpdaterByCalculation(6,
      new OCalculationOperandTableCell(TableMdlIn, 5, 0, 0, 0, 0, 0, 0),
      new OCalculation(new OCalculationOperandTableCell(TableMdlIn, 3, 0, 0, 0, 0, 0, 0), CMath.Divide, false, 0));
    }
    else{
     UpdaterPrice=new OTableCellUpdaterByCalculation(5,
      new OCalculationOperandTableCell(TableMdlIn, 3, 0, 0, 0, 0, 0, 0),
      new OCalculation(new OCalculationOperandTableCell(TableMdlIn, 6, 0, 0, 0, 0, 0, 0), CMath.Times, false, 0));
    }
    ChangeValues.addElement(UpdaterPrice);
   }
   PGUI.changeElements(TableMdlIn, ChangedRows, ChangeValues);

   SumPriceNew=(Double)PGUI.sumColumns(TableMdlIn, PCore.primArr(5), ChangedRows)[0];
   updateTransItemInPrice(TransRow, false, SumPriceNew-SumPriceOld, true);

   if(Tbl_In.getSelectedRow()==ItemRows[0]){fillInfoIn(ItemRows[0]);}
  }
 }
 void editItemsOut(int TransRow, int[] ItemRows, OEditTransItem Edit){
  boolean[] IsChanged;
  int temp, ChangedCount;
  long TransId, ItemId;
  double SumPriceOld, SumPriceNew, SumBasicPriceOld, SumBasicPriceNew;
  int[] ChangedRows;
  Vector<OTableCellUpdater> ChangeValues;
  OTableCellUpdaterByCalculation UpdaterPrice;
  boolean bool;
  
  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(TransRow)[0];
  IsChanged=PCore.newBooleanArray(ItemRows.length, false);
  ChangedCount=0;

  bool=true;
  do{
   temp=0;
   do{
    if(IsChanged[temp]==false){
     ItemId=(Long)TableMdlOut.Mdl.Rows.elementAt(ItemRows[temp])[0];
     if(PMyShop.editATransactionItem(IFV.Stm, wIsPreTrans, false, TransId, ItemId, Edit)){
      IsChanged[temp]=true;
      ChangedCount=ChangedCount+1;
     }
    }
    temp=temp+1;
   }while(temp!=ItemRows.length);

   if(ChangedCount==ItemRows.length){break;}

   IFV.FMessage.showMessage("Gagal mengubah "+(ItemRows.length-ChangedCount)+" data :\n"+
    PText.toStringWithQuote(TableMdlOut.Mdl.Rows, PGUI.getPickedRows(ItemRows, IsChanged, false), "\n",
    PCore.primArr(1, 0), PCore.primArr(false, false), "> ", ".", ", ", "", "", false), PCore.vectObj(
    "Lanjut selesaikan pengubahan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan pengubahan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){break;}

   if(!signItemsWithMissmatch(IFV.FMessage.Resolution, TableMdlOut.Mdl.Rows, 0, PGUI.getPickedRows(ItemRows, IsChanged, false))){break;}
  }while(bool);

  if(ChangedCount!=0){
   ChangedRows=PGUI.getPickedRows(ItemRows, IsChanged, true);

   SumPriceOld=(Double)PGUI.sumColumns(TableMdlOut, PCore.primArr(5), ChangedRows)[0];
   SumBasicPriceOld=(Double)PGUI.sumColumns(TableMdlOut, PCore.primArr(11), ChangedRows)[0];

   ChangeValues=new Vector();
   if(Edit.EditQuantity){
    ChangeValues.addElement(new OTableCellUpdaterByObject(3, Edit.EditedQuantity));
   }
   if(Edit.EditPriceTotal){
    ChangeValues.addElement(new OTableCellUpdaterByObject(5, Edit.EditedPriceTotal));
   }
   if(Edit.EditPriceUnit){
    ChangeValues.addElement(new OTableCellUpdaterByObject(6, Edit.EditedPriceUnit));
   }
   if(Edit.EditComment){
    if(!Edit.ReplaceSubComment){
     ChangeValues.addElement(new OTableCellUpdaterByObject(7, PText.getString(Edit.EditedComment, null, true)));
    }
    else{
     ChangeValues.addElement(new OTableCellUpdaterBySubString(7, true, Edit.SubComment, Edit.EditedComment));
    }
   }
   PGUI.changeElements(TableMdlOut, ChangedRows, ChangeValues);

   ChangeValues=new Vector();
   if(Edit.EditComment){
    ChangeValues.addElement(new OTableCellUpdaterByAppTransItemName(2, 1, 7));
   }
   if(Edit.EditQuantity || Edit.EditPriceTotal || Edit.EditPriceUnit){
    // change Price Unit or Price Total
    if(Edit.EditPriceTotal){
     UpdaterPrice=new OTableCellUpdaterByCalculation(6,
      new OCalculationOperandTableCell(TableMdlOut, 5, 0, 0, 0, 0, 0, 0),
      new OCalculation(new OCalculationOperandTableCell(TableMdlOut, 3, 0, 0, 0, 0, 0, 0), CMath.Divide, false, 0));
    }
    else{
     UpdaterPrice=new OTableCellUpdaterByCalculation(5,
      new OCalculationOperandTableCell(TableMdlOut, 3, 0, 0, 0, 0, 0, 0),
      new OCalculation(new OCalculationOperandTableCell(TableMdlOut, 6, 0, 0, 0, 0, 0, 0), CMath.Times, false, 0));
    }
    ChangeValues.addElement(UpdaterPrice);
    // change Basic Price Total
    UpdaterPrice=new OTableCellUpdaterByCalculation(11,
     new OCalculationOperandTableCell(TableMdlOut, 3, 0, 0, 0, 0, 0, 0),
     new OCalculation(new OCalculationOperandTableCell(TableMdlOut, 10, 0, 0, 0, 0, 0, 0), CMath.Times, false, 0));
    ChangeValues.addElement(UpdaterPrice);
   }
   PGUI.changeElements(TableMdlOut, ChangedRows, ChangeValues);

   SumPriceNew=(Double)PGUI.sumColumns(TableMdlOut, PCore.primArr(5), ChangedRows)[0];
   SumBasicPriceNew=(Double)PGUI.sumColumns(TableMdlOut, PCore.primArr(11), ChangedRows)[0];
   updateTransItemOutPrice(TransRow, false, SumPriceNew-SumPriceOld, true);
   updateTransItemOutBasicPrice(TransRow, false, SumBasicPriceNew-SumBasicPriceOld, true);

   if(Tbl_Out.getSelectedRow()==ItemRows[0]){fillInfoOut(ItemRows[0]);}
  }
 }
 void editPayments(boolean IsPaymentIn){
  JTable Tbl_Payment=(JTable)PCore.subtituteBool(IsPaymentIn, Tbl_PaymentIn, Tbl_PaymentOut);
  OCustomTableModel TableMdlPayment=(OCustomTableModel)PCore.subtituteBool(IsPaymentIn, TableMdlPaymentIn, TableMdlPaymentOut);
  int rowTrans=Tbl_Trans.getSelectedRow();
  int[] rows=Tbl_Payment.getSelectedRows();
  OEditTransPayment Edit=new OEditTransPayment();
  F_TransPaymentModify fm1=IFV.FTransPaymentModify;
  F_TransPaymentModifyMulti fm2=IFV.FTransPaymentModifyMulti;
  
  if(rowTrans==-1 || rows.length==0){return;}

  if(rows.length==1){
   fm1.wMode=1;
   fm1.wPayDate=(Date)TableMdlPayment.Mdl.Rows.elementAt(rows[0])[1];
   fm1.wCashId=PCore.objInteger(TableMdlPayment.Mdl.Rows.elementAt(rows[0])[2], -1);
   fm1.wCashName=PCore.objString(TableMdlPayment.Mdl.Rows.elementAt(rows[0])[3], "");
   fm1.wPrice=(Double)TableMdlPayment.Mdl.Rows.elementAt(rows[0])[4];
   fm1.wComment=PCore.objString(TableMdlPayment.Mdl.Rows.elementAt(rows[0])[5], "");
   
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}

   Edit.init(
    true, fm1.PayDate,
    true, fm1.CashId, fm1.CashName,
    true, fm1.Price,
    true, false, null, fm1.Comment);
  }
  else{
   fm2.wDataCount=rows.length;
   
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   Edit.init(
    fm2.ChangeDate, fm2.PayDate,
    fm2.ChangeCash, fm2.CashId, fm2.CashName,
    fm2.ChangePrice, fm2.Price,
    fm2.ChangeComment, fm2.ChangeCommentSub, fm2.CommentSub, fm2.Comment);
  }
  
  editPayments(IsPaymentIn, rowTrans, rows, Edit);
 }
 void updateTransPaymentPrice(boolean IsPaymentIn, int TransRow, boolean Null, double Price, boolean IsAdd){
  if(IsPaymentIn){updateTransPaymentInPrice(TransRow, Null, Price, IsAdd);}
  else{updateTransPaymentOutPrice(TransRow, Null, Price, IsAdd);}
 }
 void fillInfoPayment(boolean IsPaymentIn, int row){
  if(IsPaymentIn){fillInfoPaymentIn(row);}
  else{fillInfoPaymentOut(row);}
 }
 void editPayments(boolean IsPaymentIn, int TransRow, int[] PaymentRows, OEditTransPayment Edit){
  boolean[] IsChanged;
  int temp, ChangedCount;
  long TransId;
  int PayEnum;
  double SumPriceOld, SumPriceNew;
  int[] ChangedRows;
  Vector<OTableCellUpdater> ChangeValues;
  OCustomTableModel TableMdlPayment=(OCustomTableModel)PCore.subtituteBool(IsPaymentIn, TableMdlPaymentIn, TableMdlPaymentOut);
  JTable Tbl_Payment=(JTable)PCore.subtituteBool(IsPaymentIn, Tbl_PaymentIn, Tbl_PaymentOut);
  
  SumPriceOld=0;
  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(TransRow)[0];
  
  IsChanged=PCore.newBooleanArray(PaymentRows.length, false);
  ChangedCount=0;
  temp=0;
  do{
   PayEnum=(Integer)TableMdlPayment.Mdl.Rows.elementAt(PaymentRows[temp])[0];
   if(PMyShop.editATransactionPayment(IFV.Stm, wIsPreTrans, IsPaymentIn, TransId, PayEnum,
    Edit.EditPayDate, Edit.EditedPayDate, Edit.EditCash, Edit.EditedCashId, Edit.EditPrice, Edit.EditedPrice,
    Edit.EditComment, Edit.ReplaceSubComment, Edit.SubComment, Edit.EditedComment)){
    IsChanged[temp]=true;
    ChangedCount=ChangedCount+1;
   }
   temp=temp+1;
  }while(temp!=PaymentRows.length);

  if(ChangedCount!=0){
   ChangedRows=PGUI.getPickedRows(PaymentRows, IsChanged, true);
   ChangeValues=new Vector();
   if(Edit.EditPayDate){
    ChangeValues.addElement(new OTableCellUpdaterByObject(1, Edit.EditedPayDate));
   }
   if(Edit.EditCash){
    ChangeValues.addElement(new OTableCellUpdaterByObject(2, PCore.subtituteLong(Edit.EditedCashId, -1, Edit.EditedCashId, null)));
    ChangeValues.addElement(new OTableCellUpdaterByObject(3, PCore.subtituteLong(Edit.EditedCashId, -1, Edit.EditedCashName, null)));
   }
   if(Edit.EditPrice){
    ChangeValues.addElement(new OTableCellUpdaterByObject(4, Edit.EditedPrice));
    SumPriceOld=(Double)PGUI.sumColumns(TableMdlPayment, PCore.primArr(4), ChangedRows)[0];
   }
   if(Edit.EditComment){
    if(!Edit.ReplaceSubComment){ChangeValues.addElement(new OTableCellUpdaterByObject(5, PText.getString(Edit.EditedComment, null, true)));}
    else{ChangeValues.addElement(new OTableCellUpdaterBySubString(5, true, Edit.SubComment, Edit.EditedComment));}
   }
   PGUI.changeElements(TableMdlPayment, ChangedRows, ChangeValues);
   if(Edit.EditPrice){
    SumPriceNew=Edit.EditedPrice*ChangedRows.length;
    updateTransPaymentPrice(IsPaymentIn, TransRow, false, SumPriceNew-SumPriceOld, true);
   }
   if(Tbl_Payment.getSelectedRow()==PaymentRows[0]){fillInfoPayment(IsPaymentIn, PaymentRows[0]);}
  }
  if(ChangedCount!=PaymentRows.length){
   JOptionPane.showMessageDialog(null, "Gagal mengubah "+(PaymentRows.length-ChangedCount)+" data !");
   return;
  }
 }
 
 void setTransImportant(boolean ImportantValue){
  int[] Rows=Tbl_Trans.getSelectedRows();
  OEditTrans Edit;
  int result;
  
  if(Rows.length==0){return;}
  
  Edit=new OEditTrans();
  Edit.EditTransImportant=true; Edit.EditedTransImportant=ImportantValue;
  
  result=editTrans(Rows, false, null, Edit, false);
  if(result==-1){JOptionPane.showMessageDialog(null, "Terjadi error ketika melakukan operasi !");}
 }
 
 void initPrivGUIShow(){
  boolean ShowData;
  int tab;
  
  // Buy Price
  ShowData=IFV.CurrentUserIsAdmin || IFV.PrivGUIShowBuyPrice;
  
  PGUI.setEnabled(ShowData, CmB_ViewMode);
  if(!ShowData && CmB_ViewMode.getSelectedIndex()!=0){CmB_ViewMode.setSelectedIndex(0); CmB_ViewModeActionPerformed(null);}
  
  if(CmB_ViewMode.getSelectedIndex()==0){PGUI.setEnabled(ShowData, CB_ViewItemOutBasicPrice);}
  if(!ShowData && CB_ViewItemOutBasicPrice.isSelected()){CB_ViewItemOutBasicPrice.setSelected(false); changeTableTransViewByNormalMode();}

  PGUI.setEnabled(ShowData, CB_ItemOutBasicSum);
  if(!ShowData && CB_ItemOutBasicSum.isSelected()){CB_ItemOutBasicSum.setSelected(false); CB_ItemOutBasicSumActionPerformed(null);}
  
  PGUI.setEnabled(ShowData, CB_ItemOutShowBasicPrice);
  if(!ShowData && CB_ItemOutShowBasicPrice.isSelected()){CB_ItemOutShowBasicPrice.setSelected(false); CB_ItemOutShowBasicPriceActionPerformed(null);}
 
  // Item In
  ShowData=IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemIn, IFV.PrivGUIShowPreTransItemIn);
  
  tab=2;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
  
  // Item Out
  ShowData=IFV.CurrentUserIsAdmin || (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemOut, IFV.PrivGUIShowPreTransItemOut);
  
  tab=4;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
  
  // Order
  ShowData=IFV.CurrentUserIsAdmin ||
   (IFV.PrivGUIShowBuyPrice && (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransItemIn, IFV.PrivGUIShowPreTransItemIn));
  
  tab=6;
  TabbedPane.setEnabledAt(tab, ShowData);
  if(!ShowData && TabbedPane.getSelectedIndex()==tab){TabbedPane.setSelectedIndex(0); onTabbedPaneChanged();}
 }
 
 public boolean canShowForm(boolean ShowMessage){
  return IFV.canAccessGUI(1, ShowMessage, (Boolean)PCore.subtituteBool(!wIsPreTrans, IFV.PrivGUIShowTransList, IFV.PrivGUIShowPreTransList));
 }
 
 //
 void focusQueryResult(){
  if(!TableMdlTrans.Mdl.Rows.isEmpty()){
   if(Tbl_Trans.getSelectedRow()==-1){Tbl_Trans.changeSelection(0, 0, false, false); onSelectedRowTransChanged(false);}
   Tbl_Trans.requestFocusInWindow();
  }
 }
 void focusQuery(){
  if(LastFocusedCmpSearch==null){LastFocusedCmpSearch=TF_QId;}
  LastFocusedCmpSearch.requestFocusInWindow();
 }

 /**
  * This method is called from within the constructor to initialize the form.
  * WARNING: Do NOT modify this code. The content of this method is always
  * regenerated by the Form Editor.
  */
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Query = new javax.swing.ButtonGroup();
  RG_QImportant = new javax.swing.ButtonGroup();
  RG_QItem = new javax.swing.ButtonGroup();
  BG_FindItemOut = new javax.swing.ButtonGroup();
  BG_FindItemIn = new javax.swing.ButtonGroup();
  TabbedPane = new javax.swing.JTabbedPane();
  Panel_Query = new javax.swing.JPanel();
  Btn_Query = new javax.swing.JButton();
  TF_QId = new javax.swing.JTextField();
  CB_QDate = new javax.swing.JCheckBox();
  CB_QTransType = new javax.swing.JCheckBox();
  CB_QSubject = new javax.swing.JCheckBox();
  CB_QImportant = new javax.swing.JCheckBox();
  RB_QImportantYes = new javax.swing.JRadioButton();
  RB_QImportantNo = new javax.swing.JRadioButton();
  CB_QItem = new javax.swing.JCheckBox();
  Btn_QTransTypeAdd = new javax.swing.JButton();
  Btn_QTransTypeRemove = new javax.swing.JButton();
  Btn_QItemRemove = new javax.swing.JButton();
  Btn_QItemAdd = new javax.swing.JButton();
  Btn_QSubjectAdd = new javax.swing.JButton();
  Btn_QSubjectRemove = new javax.swing.JButton();
  CB_QTransTypeEmpty = new javax.swing.JCheckBox();
  CB_QSubjectEmpty = new javax.swing.JCheckBox();
  CB_QComment = new javax.swing.JCheckBox();
  TF_QComment = new javax.swing.JTextField();
  Lbl_QCommentHelp = new javax.swing.JLabel();
  CB_QSalesman = new javax.swing.JCheckBox();
  CB_QSalesmanEmpty = new javax.swing.JCheckBox();
  Btn_QSalesmanAdd = new javax.swing.JButton();
  Btn_QSalesmanRemove = new javax.swing.JButton();
  CB_QCash = new javax.swing.JCheckBox();
  CB_QCashEmpty = new javax.swing.JCheckBox();
  Btn_QCashAdd = new javax.swing.JButton();
  Btn_QCashRemove = new javax.swing.JButton();
  CmB_QCash = new javax.swing.JComboBox<>();
  CmB_QItem = new javax.swing.JComboBox<>();
  CB_QId = new javax.swing.JCheckBox();
  jLabel5 = new javax.swing.JLabel();
  CB_QItemNon = new javax.swing.JCheckBox();
  CmB_QCheck = new javax.swing.JComboBox<>();
  CB_QCheck = new javax.swing.JCheckBox();
  CB_QRepayPeriod = new javax.swing.JCheckBox();
  CB_QBillDate = new javax.swing.JCheckBox();
  TF_QItemPrice2 = new javax.swing.JTextField();
  TF_QItemPrice1 = new javax.swing.JTextField();
  jLabel8 = new javax.swing.JLabel();
  CB_QItemPrice = new javax.swing.JCheckBox();
  CmB_QItemPrice = new javax.swing.JComboBox<>();
  Lbl_QItemPriceHelp = new javax.swing.JLabel();
  Lbl_QIdHelp = new javax.swing.JLabel();
  TF_QPaymentPrice1 = new javax.swing.JTextField();
  jLabel9 = new javax.swing.JLabel();
  TF_QPaymentPrice2 = new javax.swing.JTextField();
  CB_QPaymentPrice = new javax.swing.JCheckBox();
  CmB_QPaymentPrice = new javax.swing.JComboBox<>();
  Lbl_QPaymentPriceHelp = new javax.swing.JLabel();
  TF_QCashComment = new javax.swing.JTextField();
  CB_QCashComment = new javax.swing.JCheckBox();
  CmB_QCashComment = new javax.swing.JComboBox<>();
  Lbl_QCashCommentHelp = new javax.swing.JLabel();
  TF_QDateStartYear = new javax.swing.JTextField();
  ComboBox_QDateStartMonth = new javax.swing.JComboBox();
  ComboBox_QDateStartDay = new javax.swing.JComboBox();
  jLabel1 = new javax.swing.JLabel();
  TF_QDateEndYear = new javax.swing.JTextField();
  ComboBox_QDateEndMonth = new javax.swing.JComboBox();
  ComboBox_QDateEndDay = new javax.swing.JComboBox();
  TF_QBillDateStartYear = new javax.swing.JTextField();
  CmB_QBillDateStartMonth = new javax.swing.JComboBox<>();
  CmB_QBillDateStartDay = new javax.swing.JComboBox<>();
  jLabel3 = new javax.swing.JLabel();
  TF_QBillDateEndYear = new javax.swing.JTextField();
  CmB_QBillDateEndMonth = new javax.swing.JComboBox<>();
  CmB_QBillDateEndDay = new javax.swing.JComboBox<>();
  TF_QRepayPeriodStartYear = new javax.swing.JTextField();
  CmB_QRepayPeriodStartMonth = new javax.swing.JComboBox<>();
  CmB_QRepayPeriodStartDay = new javax.swing.JComboBox<>();
  jLabel6 = new javax.swing.JLabel();
  TF_QRepayPeriodEndYear = new javax.swing.JTextField();
  CmB_QRepayPeriodEndMonth = new javax.swing.JComboBox<>();
  CmB_QRepayPeriodEndDay = new javax.swing.JComboBox<>();
  jScrollPane14 = new javax.swing.JScrollPane();
  Tbl_QItem = new XTable();
  jScrollPane11 = new javax.swing.JScrollPane();
  List_QTransType = new XList();
  jScrollPane5 = new javax.swing.JScrollPane();
  List_QSubject = new XList();
  jScrollPane6 = new javax.swing.JScrollPane();
  List_QSalesman = new XList();
  jScrollPane10 = new javax.swing.JScrollPane();
  List_QCash = new XList();
  Panel_Detail = new javax.swing.JPanel();
  Lbl_DetId = new javax.swing.JLabel();
  TF_DetId = new javax.swing.JTextField();
  TF_DetDate = new javax.swing.JTextField();
  TF_DetTransType = new javax.swing.JTextField();
  TF_DetSubject = new javax.swing.JTextField();
  CB_DetImportant = new javax.swing.JCheckBox();
  Lbl_DetComment = new javax.swing.JLabel();
  Lbl_DetDate = new javax.swing.JLabel();
  Lbl_DetTransType = new javax.swing.JLabel();
  Lbl_DetSubject = new javax.swing.JLabel();
  jScrollPane4 = new javax.swing.JScrollPane();
  TA_DetComment = new javax.swing.JTextArea();
  TF_DetSalesman = new javax.swing.JTextField();
  TF_DetCreditDays = new javax.swing.JTextField();
  Lbl_DetSalesman = new javax.swing.JLabel();
  Lbl_DetCreditDays = new javax.swing.JLabel();
  Lbl_DetCashOut = new javax.swing.JLabel();
  Lbl_DetCashIn = new javax.swing.JLabel();
  TF_DetRepaymentPeriod = new javax.swing.JTextField();
  Lbl_DetRepaymentPeriod = new javax.swing.JLabel();
  TF_DetIdExternal = new javax.swing.JTextField();
  Lbl_DetIdExternal = new javax.swing.JLabel();
  jScrollPane17 = new javax.swing.JScrollPane();
  TF_DetCashIn = new javax.swing.JTextArea();
  jScrollPane23 = new javax.swing.JScrollPane();
  TF_DetCashOut = new javax.swing.JTextArea();
  jSeparator1 = new javax.swing.JSeparator();
  jSeparator2 = new javax.swing.JSeparator();
  jSeparator3 = new javax.swing.JSeparator();
  jSeparator4 = new javax.swing.JSeparator();
  Panel_In = new javax.swing.JPanel();
  jScrollPane15 = new javax.swing.JScrollPane();
  TF_InInfoName = new javax.swing.JTextArea();
  Pnl_ItemInPreview = new XImgBoxURL();
  jPanel5 = new javax.swing.JPanel();
  TF_InCount = new javax.swing.JTextField();
  Btn_InOtherOperation = new javax.swing.JButton();
  Btn_InCancel = new javax.swing.JButton();
  Btn_InEdit = new javax.swing.JButton();
  Btn_InAdd = new javax.swing.JButton();
  CB_ItemInCategorized = new javax.swing.JToggleButton();
  jPanel6 = new javax.swing.JPanel();
  Btn_InTempListRemove = new javax.swing.JButton();
  Btn_InTempListAdd = new javax.swing.JButton();
  jLabel4 = new javax.swing.JLabel();
  Btn_InCheckRemove = new javax.swing.JButton();
  Btn_InCheckAdd = new javax.swing.JButton();
  jLabel10 = new javax.swing.JLabel();
  CmB_FindItemIn = new javax.swing.JComboBox<>();
  TF_FindItemIn = new javax.swing.JTextField();
  Btn_FindItemInBef = new javax.swing.JButton();
  Btn_FindItemInNext = new javax.swing.JButton();
  jScrollPane20 = new javax.swing.JScrollPane();
  TF_InInfoCategory = new javax.swing.JTextArea();
  jScrollPane3 = new javax.swing.JScrollPane();
  Tbl_In = new XTable();
  Panel_PaymentOut = new javax.swing.JPanel();
  jPanel8 = new javax.swing.JPanel();
  Btn_PaymentOutPrint = new javax.swing.JButton();
  Btn_PaymentOutCancel = new javax.swing.JButton();
  Btn_PaymentOutEdit = new javax.swing.JButton();
  Btn_PaymentOutAdd = new javax.swing.JButton();
  TF_PayOutCount = new javax.swing.JTextField();
  jPanel10 = new javax.swing.JPanel();
  TF_PaymentOutDate = new javax.swing.JTextField();
  Lbl_PaymentOutDate = new javax.swing.JLabel();
  TF_PaymentOutCash = new javax.swing.JTextField();
  Lbl_PaymentOutCash = new javax.swing.JLabel();
  TF_PaymentOutPrice = new javax.swing.JTextField();
  Lbl_PaymentOutPrice = new javax.swing.JLabel();
  jScrollPane9 = new javax.swing.JScrollPane();
  TA_PaymentOutComment = new javax.swing.JTextArea();
  Lbl_PaymentOutComment = new javax.swing.JLabel();
  jScrollPane7 = new javax.swing.JScrollPane();
  Tbl_PaymentOut = new XTable();
  Panel_Out = new javax.swing.JPanel();
  jScrollPane16 = new javax.swing.JScrollPane();
  TF_OutInfoName = new javax.swing.JTextArea();
  Pnl_ItemOutPreview = new XImgBoxURL();
  jPanel4 = new javax.swing.JPanel();
  Btn_OutTempListRemove = new javax.swing.JButton();
  Btn_OutTempListAdd = new javax.swing.JButton();
  jLabel7 = new javax.swing.JLabel();
  Btn_OutCheckRemove = new javax.swing.JButton();
  Btn_OutCheckAdd = new javax.swing.JButton();
  jLabel11 = new javax.swing.JLabel();
  CmB_FindItemOut = new javax.swing.JComboBox<>();
  TF_FindItemOut = new javax.swing.JTextField();
  Btn_FindItemOutNext = new javax.swing.JButton();
  Btn_FindItemOutBef = new javax.swing.JButton();
  jPanel7 = new javax.swing.JPanel();
  TF_OutCount = new javax.swing.JTextField();
  Btn_OutOtherOperation = new javax.swing.JButton();
  Btn_OutCancel = new javax.swing.JButton();
  Btn_OutEdit = new javax.swing.JButton();
  Btn_OutAdd = new javax.swing.JButton();
  CB_ItemOutCategorized = new javax.swing.JToggleButton();
  CB_ItemOutShowBasicPrice = new javax.swing.JToggleButton();
  jScrollPane21 = new javax.swing.JScrollPane();
  TF_OutInfoCategory = new javax.swing.JTextArea();
  jScrollPane2 = new javax.swing.JScrollPane();
  Tbl_Out = new XTable();
  Panel_PaymentIn = new javax.swing.JPanel();
  jPanel11 = new javax.swing.JPanel();
  TF_PayInCount = new javax.swing.JTextField();
  Btn_PaymentInPrint = new javax.swing.JButton();
  Btn_PaymentInCancel = new javax.swing.JButton();
  Btn_PaymentInEdit = new javax.swing.JButton();
  Btn_PaymentInAdd = new javax.swing.JButton();
  jPanel12 = new javax.swing.JPanel();
  TF_PaymentInDate = new javax.swing.JTextField();
  Lbl_PaymentInDate = new javax.swing.JLabel();
  TF_PaymentInCash = new javax.swing.JTextField();
  Lbl_PaymentInCash = new javax.swing.JLabel();
  TF_PaymentInPrice = new javax.swing.JTextField();
  jScrollPane12 = new javax.swing.JScrollPane();
  TA_PaymentInComment = new javax.swing.JTextArea();
  Lbl_PaymentInPrice = new javax.swing.JLabel();
  Lbl_PaymentInComment = new javax.swing.JLabel();
  jScrollPane8 = new javax.swing.JScrollPane();
  Tbl_PaymentIn = new XTable();
  Panel_Order = new javax.swing.JPanel();
  jPanel13 = new javax.swing.JPanel();
  TF_OrdCount = new javax.swing.JTextField();
  Btn_OrdRefresh = new javax.swing.JButton();
  Btn_OrdRemove = new javax.swing.JButton();
  Btn_OrdEdit = new javax.swing.JButton();
  Btn_OrdAdd = new javax.swing.JButton();
  TF_OrdPriceEst = new javax.swing.JTextField();
  CB_OrdCategorized = new javax.swing.JToggleButton();
  jPanel14 = new javax.swing.JPanel();
  CmB_OrdFind = new javax.swing.JComboBox<>();
  Btn_OrdFindNext = new javax.swing.JButton();
  Btn_OrdFindBef = new javax.swing.JButton();
  TF_OrdFind = new javax.swing.JTextField();
  Btn_OrdTempListRemove = new javax.swing.JButton();
  Btn_OrdTempListAdd = new javax.swing.JButton();
  jLabel12 = new javax.swing.JLabel();
  Btn_OrdMove = new javax.swing.JButton();
  Pnl_OrdPreview = new XImgBoxURL();
  jScrollPane18 = new javax.swing.JScrollPane();
  TA_OrdInfoCategory = new javax.swing.JTextArea();
  jScrollPane19 = new javax.swing.JScrollPane();
  TA_OrdInfoName = new javax.swing.JTextArea();
  jScrollPane22 = new javax.swing.JScrollPane();
  Tbl_Ord = new XTable();
  jPanel1 = new javax.swing.JPanel();
  Pnl_TransSummary = new javax.swing.JPanel();
  Lbl_PaymentOutSum = new javax.swing.JLabel();
  Lbl_ItemOutSum = new javax.swing.JLabel();
  Lbl_PaymentInSum = new javax.swing.JLabel();
  Lbl_ItemInSum = new javax.swing.JLabel();
  TF_ItemInSum = new javax.swing.JTextField();
  TF_ItemOutBasicSum = new javax.swing.JTextField();
  TF_PaymentOutSum = new javax.swing.JTextField();
  TF_ItemOutSum = new javax.swing.JTextField();
  TF_PaymentInSum = new javax.swing.JTextField();
  CB_ItemOutBasicSum = new javax.swing.JCheckBox();
  TF_ListCount = new javax.swing.JTextField();
  TF_QueryTempListCount = new javax.swing.JTextField();
  Btn_QueryRefresh = new javax.swing.JButton();
  CmB_ResultFilterSubset = new javax.swing.JComboBox<>();
  jPanel2 = new javax.swing.JPanel();
  Btn_TransEdit = new javax.swing.JButton();
  Btn_TransCancel = new javax.swing.JButton();
  Btn_TransRemove = new javax.swing.JButton();
  Btn_Report = new javax.swing.JButton();
  CmB_ReportType = new javax.swing.JComboBox<>();
  Btn_TransChoose = new javax.swing.JButton();
  Lbl_MultipleSelection = new javax.swing.JLabel();
  Btn_TransNew = new javax.swing.JButton();
  jPanel3 = new javax.swing.JPanel();
  Btn_TempListLoad = new javax.swing.JButton();
  Btn_TempListSave = new javax.swing.JButton();
  Btn_TempListRemove = new javax.swing.JButton();
  Btn_TempListAdd = new javax.swing.JButton();
  TF_TempListQuantity = new javax.swing.JTextField();
  jLabel2 = new javax.swing.JLabel();
  CmB_Find = new javax.swing.JComboBox<>();
  Btn_FindNext = new javax.swing.JButton();
  Btn_FindBefore = new javax.swing.JButton();
  TF_Find = new javax.swing.JTextField();
  Btn_TempListClear = new javax.swing.JButton();
  Pnl_View = new javax.swing.JPanel();
  CmB_ViewMode = new javax.swing.JComboBox<>();
  jPanel9 = new javax.swing.JPanel();
  CB_ViewDate = new javax.swing.JToggleButton();
  CB_ViewDateBill = new javax.swing.JToggleButton();
  CB_ViewDateRepayment = new javax.swing.JToggleButton();
  CB_ViewSubject = new javax.swing.JToggleButton();
  CB_ViewSalesman = new javax.swing.JToggleButton();
  CB_ViewCashOut = new javax.swing.JToggleButton();
  CB_ViewCashOutComment = new javax.swing.JToggleButton();
  CB_ViewCashIn = new javax.swing.JToggleButton();
  CB_ViewCashInComment = new javax.swing.JToggleButton();
  CB_ViewId = new javax.swing.JToggleButton();
  CB_ViewIdExternal = new javax.swing.JToggleButton();
  CB_ViewIsImportant = new javax.swing.JToggleButton();
  CB_ViewItemIn = new javax.swing.JToggleButton();
  CB_ViewItemOut = new javax.swing.JToggleButton();
  CB_ViewItemOutBasicPrice = new javax.swing.JToggleButton();
  jScrollPane1 = new javax.swing.JScrollPane();
  Tbl_Trans = new XTable();
  jPanel15 = new javax.swing.JPanel();
  Btn_TransSalesmanTempListRemove = new javax.swing.JButton();
  jLabel14 = new javax.swing.JLabel();
  Btn_TransSalesmanTempListAdd = new javax.swing.JButton();
  Btn_TransSalesmanInfo = new javax.swing.JButton();
  Btn_TransSubjectInfo = new javax.swing.JButton();
  Btn_TransSubjectTempListRemove = new javax.swing.JButton();
  Btn_TransSubjectTempListAdd = new javax.swing.JButton();
  jLabel15 = new javax.swing.JLabel();
  Btn_MultipleTransImportantRemove = new javax.swing.JButton();
  Btn_MultipleTransImportantAdd = new javax.swing.JButton();
  jLabel13 = new javax.swing.JLabel();

  setTitle("Lihat Transaksi ( {Esc} Utk Keluar )");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Btn_Query.setText("Cari {F6}");
  Btn_Query.setToolTipText("");
  Btn_Query.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Query.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryActionPerformed(evt);
   }
  });
  Btn_Query.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QueryKeyPressed(evt);
   }
  });

  TF_QId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QIdFocusGained(evt);
   }
  });
  TF_QId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QIdKeyPressed(evt);
   }
  });

  CB_QDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QDate.setText("Rentang");
  CB_QDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QDateKeyPressed(evt);
   }
  });

  CB_QTransType.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QTransType.setText("Jns Trans...");
  CB_QTransType.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QTransType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QTransTypeKeyPressed(evt);
   }
  });

  CB_QSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QSubject.setText("Subjek...");
  CB_QSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSubjectKeyPressed(evt);
   }
  });

  CB_QImportant.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QImportant.setText("Penting");
  CB_QImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QImportant.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QImportantKeyPressed(evt);
   }
  });

  RG_QImportant.add(RB_QImportantYes);
  RB_QImportantYes.setText("Ya");
  RB_QImportantYes.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_QImportantYes.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_QImportantYesKeyPressed(evt);
   }
  });

  RG_QImportant.add(RB_QImportantNo);
  RB_QImportantNo.setText("Tidak");
  RB_QImportantNo.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_QImportantNo.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_QImportantNoKeyPressed(evt);
   }
  });

  CB_QItem.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QItem.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemKeyPressed(evt);
   }
  });

  Btn_QTransTypeAdd.setText("+");
  Btn_QTransTypeAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QTransTypeAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QTransTypeAddActionPerformed(evt);
   }
  });
  Btn_QTransTypeAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QTransTypeAddKeyPressed(evt);
   }
  });

  Btn_QTransTypeRemove.setText("-");
  Btn_QTransTypeRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QTransTypeRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QTransTypeRemoveActionPerformed(evt);
   }
  });
  Btn_QTransTypeRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QTransTypeRemoveKeyPressed(evt);
   }
  });

  Btn_QItemRemove.setText("-");
  Btn_QItemRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemRemoveActionPerformed(evt);
   }
  });
  Btn_QItemRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemRemoveKeyPressed(evt);
   }
  });

  Btn_QItemAdd.setText("+");
  Btn_QItemAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QItemAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QItemAddActionPerformed(evt);
   }
  });
  Btn_QItemAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QItemAddKeyPressed(evt);
   }
  });

  Btn_QSubjectAdd.setText("+");
  Btn_QSubjectAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSubjectAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSubjectAddActionPerformed(evt);
   }
  });
  Btn_QSubjectAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSubjectAddKeyPressed(evt);
   }
  });

  Btn_QSubjectRemove.setText("-");
  Btn_QSubjectRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSubjectRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSubjectRemoveActionPerformed(evt);
   }
  });
  Btn_QSubjectRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSubjectRemoveKeyPressed(evt);
   }
  });

  CB_QTransTypeEmpty.setText("Kosong");
  CB_QTransTypeEmpty.setToolTipText("centang opsi ini utk mengikutsertakan transaksi dgn jenis transaksi yg tdk didefenisikan");
  CB_QTransTypeEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QTransTypeEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QTransTypeEmptyKeyPressed(evt);
   }
  });

  CB_QSubjectEmpty.setText("Kosong");
  CB_QSubjectEmpty.setToolTipText("centang opsi ini utk mengikutsertakan transaksi dgn subjek yg tdk didefenisikan");
  CB_QSubjectEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSubjectEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSubjectEmptyKeyPressed(evt);
   }
  });

  CB_QComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QComment.setText("Ket.");
  CB_QComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCommentKeyPressed(evt);
   }
  });

  TF_QComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QCommentFocusGained(evt);
   }
  });
  TF_QComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QCommentKeyPressed(evt);
   }
  });

  Lbl_QCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QCommentHelp.setText("(?)");
  Lbl_QCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QCommentHelpMouseClicked(evt);
   }
  });

  CB_QSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QSalesman.setText("Salesmn...");
  CB_QSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSalesmanKeyPressed(evt);
   }
  });

  CB_QSalesmanEmpty.setText("Kosong");
  CB_QSalesmanEmpty.setToolTipText("centang opsi ini utk mengikutsertakan transaksi dgn salesman yg tdk didefenisikan");
  CB_QSalesmanEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QSalesmanEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QSalesmanEmptyKeyPressed(evt);
   }
  });

  Btn_QSalesmanAdd.setText("+");
  Btn_QSalesmanAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSalesmanAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSalesmanAddActionPerformed(evt);
   }
  });
  Btn_QSalesmanAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSalesmanAddKeyPressed(evt);
   }
  });

  Btn_QSalesmanRemove.setText("-");
  Btn_QSalesmanRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QSalesmanRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QSalesmanRemoveActionPerformed(evt);
   }
  });
  Btn_QSalesmanRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QSalesmanRemoveKeyPressed(evt);
   }
  });

  CB_QCash.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QCash.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCashKeyPressed(evt);
   }
  });

  CB_QCashEmpty.setText("Kosong");
  CB_QCashEmpty.setToolTipText("centang opsi ini utk mengikutsertakan transaksi dgn kas tunai yg tdk didefenisikan");
  CB_QCashEmpty.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCashEmpty.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCashEmptyKeyPressed(evt);
   }
  });

  Btn_QCashAdd.setText("+");
  Btn_QCashAdd.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCashAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCashAddActionPerformed(evt);
   }
  });
  Btn_QCashAdd.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCashAddKeyPressed(evt);
   }
  });

  Btn_QCashRemove.setText("-");
  Btn_QCashRemove.setMargin(new java.awt.Insets(0, 2, 0, 2));
  Btn_QCashRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QCashRemoveActionPerformed(evt);
   }
  });
  Btn_QCashRemove.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_QCashRemoveKeyPressed(evt);
   }
  });

  CmB_QCash.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Kas Msk", "Msk Tun", "Msk Krd", "Kas Klr", "Klr Tun", "Klr Krd" }));
  CmB_QCash.setToolTipText("Pilih Kas");
  CmB_QCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCashKeyPressed(evt);
   }
  });

  CmB_QItem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Brg Msk", "Brg Klr", "Msk & Klr" }));
  CmB_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QItemKeyPressed(evt);
   }
  });

  CB_QId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QId.setText("Id & {Ext}");
  CB_QId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QIdKeyPressed(evt);
   }
  });

  jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel5.setText("-- Filter (kosongkan smua utk cari smua)");

  CB_QItemNon.setText("Non");
  CB_QItemNon.setToolTipText("centang opsi ini utk mengikutsertakan transaksi yg tdk memiliki daftar barang");
  CB_QItemNon.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemNon.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemNonKeyPressed(evt);
   }
  });

  CmB_QCheck.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Piutang ~Lunas ( Brg Klr + Byr Klr > Brg Msk + Byr Msk )", "Piutang Lunas ( Brg Klr + Byr Klr <= Brg Msk + Byr Msk )", "Utang ~Lunas ( Brg Msk + Byr Msk > Brg Klr + Byr Klr )", "Utang Lunas ( Brg Msk + Byr Msk <= Brg Klr + Byr Klr )", "Pending", "~Pending" }));
  CmB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCheckKeyPressed(evt);
   }
  });

  CB_QCheck.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QCheck.setText("Cek");
  CB_QCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCheck.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCheckKeyPressed(evt);
   }
  });

  CB_QRepayPeriod.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QRepayPeriod.setText("Periode Cicil");
  CB_QRepayPeriod.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QRepayPeriod.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QRepayPeriodKeyPressed(evt);
   }
  });

  CB_QBillDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_QBillDate.setText("Tgl Tagih");
  CB_QBillDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QBillDate.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QBillDateKeyPressed(evt);
   }
  });

  TF_QItemPrice2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemPrice2FocusGained(evt);
   }
  });
  TF_QItemPrice2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemPrice2KeyPressed(evt);
   }
  });

  TF_QItemPrice1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QItemPrice1FocusGained(evt);
   }
  });
  TF_QItemPrice1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QItemPrice1KeyPressed(evt);
   }
  });

  jLabel8.setText("-");

  CB_QItemPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QItemPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QItemPriceKeyPressed(evt);
   }
  });

  CmB_QItemPrice.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Brg Msk", "Brg Klr" }));
  CmB_QItemPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QItemPriceKeyPressed(evt);
   }
  });

  Lbl_QItemPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QItemPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QItemPriceHelp.setText("(?)");
  Lbl_QItemPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QItemPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QItemPriceHelpMouseClicked(evt);
   }
  });

  Lbl_QIdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QIdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QIdHelp.setText("(?)");
  Lbl_QIdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QIdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QIdHelpMouseClicked(evt);
   }
  });

  TF_QPaymentPrice1.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QPaymentPrice1FocusGained(evt);
   }
  });
  TF_QPaymentPrice1.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QPaymentPrice1KeyPressed(evt);
   }
  });

  jLabel9.setText("-");

  TF_QPaymentPrice2.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QPaymentPrice2FocusGained(evt);
   }
  });
  TF_QPaymentPrice2.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QPaymentPrice2KeyPressed(evt);
   }
  });

  CB_QPaymentPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QPaymentPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QPaymentPriceKeyPressed(evt);
   }
  });

  CmB_QPaymentPrice.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Byr Klr", "Byr Msk" }));
  CmB_QPaymentPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QPaymentPriceKeyPressed(evt);
   }
  });

  Lbl_QPaymentPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QPaymentPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QPaymentPriceHelp.setText("(?)");
  Lbl_QPaymentPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QPaymentPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QPaymentPriceHelpMouseClicked(evt);
   }
  });

  TF_QCashComment.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QCashCommentFocusGained(evt);
   }
  });
  TF_QCashComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QCashCommentKeyPressed(evt);
   }
  });

  CB_QCashComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_QCashComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_QCashCommentKeyPressed(evt);
   }
  });

  CmB_QCashComment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "K-Kas Msk", "Msk Tun", "Msk Krd", "K-Kas Klr", "Klr Tun", "Klr Krd" }));
  CmB_QCashComment.setToolTipText("Pilih Keterangan Kas");
  CmB_QCashComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QCashCommentKeyPressed(evt);
   }
  });

  Lbl_QCashCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_QCashCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_QCashCommentHelp.setText("(?)");
  Lbl_QCashCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_QCashCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_QCashCommentHelpMouseClicked(evt);
   }
  });

  TF_QDateStartYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QDateStartYearFocusGained(evt);
   }
  });
  TF_QDateStartYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QDateStartYearKeyPressed(evt);
   }
  });

  ComboBox_QDateStartMonth.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  ComboBox_QDateStartMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_QDateStartMonthKeyPressed(evt);
   }
  });

  ComboBox_QDateStartDay.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_QDateStartDay.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
  ComboBox_QDateStartDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_QDateStartDayKeyPressed(evt);
   }
  });

  jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
  jLabel1.setText("-");

  TF_QDateEndYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QDateEndYearFocusGained(evt);
   }
  });
  TF_QDateEndYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QDateEndYearKeyPressed(evt);
   }
  });

  ComboBox_QDateEndMonth.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  ComboBox_QDateEndMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_QDateEndMonthKeyPressed(evt);
   }
  });

  ComboBox_QDateEndDay.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_QDateEndDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_QDateEndDayKeyPressed(evt);
   }
  });

  TF_QBillDateStartYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QBillDateStartYearFocusGained(evt);
   }
  });
  TF_QBillDateStartYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QBillDateStartYearKeyPressed(evt);
   }
  });

  CmB_QBillDateStartMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QBillDateStartMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBillDateStartMonthKeyPressed(evt);
   }
  });

  CmB_QBillDateStartDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QBillDateStartDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBillDateStartDayKeyPressed(evt);
   }
  });

  jLabel3.setText("-");

  TF_QBillDateEndYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QBillDateEndYearFocusGained(evt);
   }
  });
  TF_QBillDateEndYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QBillDateEndYearKeyPressed(evt);
   }
  });

  CmB_QBillDateEndMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QBillDateEndMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBillDateEndMonthKeyPressed(evt);
   }
  });

  CmB_QBillDateEndDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QBillDateEndDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QBillDateEndDayKeyPressed(evt);
   }
  });

  TF_QRepayPeriodStartYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QRepayPeriodStartYearFocusGained(evt);
   }
  });
  TF_QRepayPeriodStartYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QRepayPeriodStartYearKeyPressed(evt);
   }
  });

  CmB_QRepayPeriodStartMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QRepayPeriodStartMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRepayPeriodStartMonthKeyPressed(evt);
   }
  });

  CmB_QRepayPeriodStartDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QRepayPeriodStartDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRepayPeriodStartDayKeyPressed(evt);
   }
  });

  jLabel6.setText("-");

  TF_QRepayPeriodEndYear.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_QRepayPeriodEndYearFocusGained(evt);
   }
  });
  TF_QRepayPeriodEndYear.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_QRepayPeriodEndYearKeyPressed(evt);
   }
  });

  CmB_QRepayPeriodEndMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nop", "Des" }));
  CmB_QRepayPeriodEndMonth.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRepayPeriodEndMonthKeyPressed(evt);
   }
  });

  CmB_QRepayPeriodEndDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_QRepayPeriodEndDay.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_QRepayPeriodEndDayKeyPressed(evt);
   }
  });

  Tbl_QItem.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_QItem.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_QItem.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_QItemKeyReleased(evt);
   }
  });
  jScrollPane14.setViewportView(Tbl_QItem);

  List_QTransType.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QTransTypeKeyReleased(evt);
   }
  });
  jScrollPane11.setViewportView(List_QTransType);

  List_QSubject.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QSubjectKeyReleased(evt);
   }
  });
  jScrollPane5.setViewportView(List_QSubject);

  List_QSalesman.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QSalesmanKeyReleased(evt);
   }
  });
  jScrollPane6.setViewportView(List_QSalesman);

  List_QCash.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    List_QCashKeyReleased(evt);
   }
  });
  jScrollPane10.setViewportView(List_QCash);

  javax.swing.GroupLayout Panel_QueryLayout = new javax.swing.GroupLayout(Panel_Query);
  Panel_Query.setLayout(Panel_QueryLayout);
  Panel_QueryLayout.setHorizontalGroup(
   Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addComponent(jLabel5)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_Query))
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QTransType)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QCommentHelp))
     .addComponent(CB_QImportant)
     .addComponent(CB_QDate)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QCash)
      .addGap(0, 0, 0)
      .addComponent(CmB_QCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(CB_QSubject)
     .addComponent(CB_QSalesman)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItem)
      .addGap(0, 0, 0)
      .addComponent(CmB_QItem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QId)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_QIdHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGap(19, 19, 19)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_QCashEmpty)
       .addComponent(CB_QTransTypeEmpty)
       .addComponent(CB_QSubjectEmpty)
       .addComponent(CB_QSalesmanEmpty)
       .addComponent(CB_QItemNon)))
     .addComponent(CB_QCheck)
     .addComponent(CB_QRepayPeriod)
     .addComponent(CB_QBillDate)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QItemPrice)
      .addGap(0, 0, 0)
      .addComponent(CmB_QItemPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QItemPriceHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QPaymentPrice)
      .addGap(0, 0, 0)
      .addComponent(CmB_QPaymentPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QPaymentPriceHelp))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QCashComment)
      .addGap(0, 0, 0)
      .addComponent(CmB_QCashComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(Lbl_QCashCommentHelp)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane10)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Btn_QCashRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addComponent(Btn_QCashAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane11)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QTransTypeRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Btn_QTransTypeAdd, javax.swing.GroupLayout.Alignment.TRAILING)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane5)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QSubjectAdd, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Btn_QSubjectRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane6)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QSalesmanAdd, javax.swing.GroupLayout.Alignment.TRAILING)
       .addComponent(Btn_QSalesmanRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
     .addComponent(TF_QComment)
     .addComponent(TF_QId)
     .addComponent(CmB_QCheck, 0, 372, Short.MAX_VALUE)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
       .addComponent(TF_QPaymentPrice1, javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_QItemPrice1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
      .addGap(2, 2, 2)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(jLabel8)
       .addComponent(jLabel9))
      .addGap(2, 2, 2)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_QPaymentPrice2)
       .addComponent(TF_QItemPrice2)))
     .addComponent(TF_QCashComment)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(TF_QDateStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_QDateStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_QDateStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel1)
      .addGap(2, 2, 2)
      .addComponent(TF_QDateEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_QDateEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_QDateEndDay, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(TF_QBillDateStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBillDateStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBillDateStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel3)
      .addGap(2, 2, 2)
      .addComponent(TF_QBillDateEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBillDateEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QBillDateEndDay, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(RB_QImportantYes)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(RB_QImportantNo)
      .addGap(0, 0, Short.MAX_VALUE))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(TF_QRepayPeriodStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRepayPeriodStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRepayPeriodStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(2, 2, 2)
      .addComponent(jLabel6)
      .addGap(2, 2, 2)
      .addComponent(TF_QRepayPeriodEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRepayPeriodEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CmB_QRepayPeriodEndDay, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_QueryLayout.createSequentialGroup()
      .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(Btn_QItemRemove, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
       .addComponent(Btn_QItemAdd, javax.swing.GroupLayout.Alignment.TRAILING)))))
  );
  Panel_QueryLayout.setVerticalGroup(
   Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_QueryLayout.createSequentialGroup()
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Query)
     .addComponent(jLabel5))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(RB_QImportantYes)
     .addComponent(RB_QImportantNo)
     .addComponent(CB_QImportant))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CmB_QCheck, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QCheck))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QDate)
     .addComponent(TF_QDateStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_QDateStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_QDateStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel1)
     .addComponent(TF_QDateEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_QDateEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_QDateEndDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QBillDate)
     .addComponent(TF_QBillDateStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBillDateStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBillDateStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel3)
     .addComponent(TF_QBillDateEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBillDateEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QBillDateEndDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_QRepayPeriod)
     .addComponent(TF_QRepayPeriodStartYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRepayPeriodStartMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRepayPeriodStartDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel6)
     .addComponent(TF_QRepayPeriodEndYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRepayPeriodEndMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_QRepayPeriodEndDay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QId)
     .addComponent(Lbl_QIdHelp))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_QCommentHelp)
     .addComponent(TF_QComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_QComment))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_QCashComment, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_QCashComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_QCashComment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_QCashCommentHelp)))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_QItemPrice2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_QItemPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(jLabel8)
     .addComponent(CmB_QItemPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_QItemPriceHelp)
     .addComponent(CB_QItemPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(TF_QPaymentPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(jLabel9)
      .addComponent(TF_QPaymentPrice2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(CmB_QPaymentPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Lbl_QPaymentPriceHelp))
     .addComponent(CB_QPaymentPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QTransType)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QTransTypeEmpty))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QTransTypeAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QTransTypeRemove))
     .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QSubjectAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QSubjectRemove))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QSubject)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QSubjectEmpty))
     .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QSalesmanAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QSalesmanRemove))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(CB_QSalesman)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QSalesmanEmpty))
     .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addComponent(Btn_QCashAdd)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QCashRemove))
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(CmB_QCash)
       .addComponent(CB_QCash, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_QCashEmpty))
     .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addGap(3, 3, 3)
    .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_QueryLayout.createSequentialGroup()
      .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addGroup(Panel_QueryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
         .addComponent(CB_QItem, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
         .addComponent(CmB_QItem, javax.swing.GroupLayout.Alignment.LEADING))
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_QItemNon))
       .addGroup(Panel_QueryLayout.createSequentialGroup()
        .addComponent(Btn_QItemAdd)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_QItemRemove)))
      .addContainerGap(54, Short.MAX_VALUE))
     .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
  );

  TabbedPane.addTab("Cari", Panel_Query);

  Lbl_DetId.setText("Id");

  TF_DetId.setEditable(false);
  TF_DetId.setBackground(new java.awt.Color(204, 255, 204));

  TF_DetDate.setEditable(false);
  TF_DetDate.setBackground(new java.awt.Color(204, 255, 204));

  TF_DetTransType.setEditable(false);
  TF_DetTransType.setBackground(new java.awt.Color(204, 255, 204));

  TF_DetSubject.setEditable(false);
  TF_DetSubject.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetSubject.setToolTipText("klik utk melihat keterangan subjek");
  TF_DetSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_DetSubject.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_DetSubjectMouseClicked(evt);
   }
  });

  CB_DetImportant.setText("Penting");
  CB_DetImportant.setEnabled(false);
  CB_DetImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));

  Lbl_DetComment.setText("Keterangan");

  Lbl_DetDate.setText("Tanggal");

  Lbl_DetTransType.setText("Jenis");

  Lbl_DetSubject.setText("Subjek");

  TA_DetComment.setEditable(false);
  TA_DetComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_DetComment.setColumns(20);
  TA_DetComment.setLineWrap(true);
  TA_DetComment.setRows(5);
  TA_DetComment.setWrapStyleWord(true);
  jScrollPane4.setViewportView(TA_DetComment);

  TF_DetSalesman.setEditable(false);
  TF_DetSalesman.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetSalesman.setToolTipText("klik utk melihat keterangan sales");
  TF_DetSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_DetSalesman.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_DetSalesmanMouseClicked(evt);
   }
  });

  TF_DetCreditDays.setEditable(false);
  TF_DetCreditDays.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_DetSalesman.setText("Salesman");

  Lbl_DetCreditDays.setText("Lama Kredit");

  Lbl_DetCashOut.setText("Kas Keluar Tunai");

  Lbl_DetCashIn.setText("Kas Masuk Tunai");

  TF_DetRepaymentPeriod.setEditable(false);
  TF_DetRepaymentPeriod.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_DetRepaymentPeriod.setText("Periode Cicil");

  TF_DetIdExternal.setEditable(false);
  TF_DetIdExternal.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_DetIdExternal.setText("{ Id External }");

  TF_DetCashIn.setEditable(false);
  TF_DetCashIn.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetCashIn.setColumns(20);
  TF_DetCashIn.setLineWrap(true);
  TF_DetCashIn.setWrapStyleWord(true);
  jScrollPane17.setViewportView(TF_DetCashIn);

  TF_DetCashOut.setEditable(false);
  TF_DetCashOut.setBackground(new java.awt.Color(204, 255, 204));
  TF_DetCashOut.setColumns(20);
  TF_DetCashOut.setLineWrap(true);
  TF_DetCashOut.setWrapStyleWord(true);
  jScrollPane23.setViewportView(TF_DetCashOut);

  javax.swing.GroupLayout Panel_DetailLayout = new javax.swing.GroupLayout(Panel_Detail);
  Panel_Detail.setLayout(Panel_DetailLayout);
  Panel_DetailLayout.setHorizontalGroup(
   Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DetailLayout.createSequentialGroup()
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_DetId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetIdExternal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetTransType, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetCreditDays, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetRepaymentPeriod, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetSubject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetSalesman, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetCashIn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetCashOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
     .addComponent(Lbl_DetComment, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_DetailLayout.createSequentialGroup()
      .addComponent(TF_DetId)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(CB_DetImportant))
     .addComponent(TF_DetIdExternal)
     .addComponent(TF_DetTransType, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_DetDate, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_DetCreditDays)
     .addComponent(TF_DetRepaymentPeriod, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jScrollPane17, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
     .addComponent(jScrollPane23, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_DetSubject)
     .addComponent(TF_DetSalesman)))
   .addComponent(jSeparator1)
   .addComponent(jSeparator2)
   .addComponent(jSeparator3)
   .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.TRAILING)
  );
  Panel_DetailLayout.setVerticalGroup(
   Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_DetailLayout.createSequentialGroup()
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_DetImportant)
     .addComponent(Lbl_DetId))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetIdExternal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetIdExternal))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetTransType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetTransType))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_DetCreditDays)
     .addComponent(TF_DetCreditDays, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetRepaymentPeriod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetRepaymentPeriod))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetSubject, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetSubject))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_DetSalesman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_DetSalesman))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_DetCashIn)
     .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_DetCashOut)
     .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(Panel_DetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Panel_DetailLayout.createSequentialGroup()
      .addComponent(Lbl_DetComment)
      .addContainerGap(220, Short.MAX_VALUE))
     .addComponent(jScrollPane4)))
  );

  TabbedPane.addTab("Ket", Panel_Detail);

  TF_InInfoName.setEditable(false);
  TF_InInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_InInfoName.setColumns(20);
  TF_InInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_InInfoName.setLineWrap(true);
  TF_InInfoName.setWrapStyleWord(true);
  jScrollPane15.setViewportView(TF_InInfoName);

  Pnl_ItemInPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemInPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemInPreviewMouseClicked(evt);
   }
  });

  TF_InCount.setEditable(false);
  TF_InCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_InCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_InOtherOperation.setText("...");
  Btn_InOtherOperation.setToolTipText("opsi lanjutan terhadap barang2 yg dipilih");
  Btn_InOtherOperation.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InOtherOperation.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InOtherOperationActionPerformed(evt);
   }
  });

  Btn_InCancel.setText("Btl {F8}");
  Btn_InCancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InCancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InCancelActionPerformed(evt);
   }
  });

  Btn_InEdit.setText("Ubh {F7}");
  Btn_InEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InEditActionPerformed(evt);
   }
  });

  Btn_InAdd.setText("Tbh {F6}");
  Btn_InAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InAddActionPerformed(evt);
   }
  });

  CB_ItemInCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemInCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemInCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemInCategorized.setText("K");
  CB_ItemInCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemInCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemInCategorized.setIconTextGap(0);
  CB_ItemInCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemInCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemInCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
  jPanel5.setLayout(jPanel5Layout);
  jPanel5Layout.setHorizontalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addComponent(TF_InCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemInCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_InAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InCancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InOtherOperation))
  );
  jPanel5Layout.setVerticalGroup(
   jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel5Layout.createSequentialGroup()
    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_InCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_InOtherOperation)
     .addComponent(Btn_InCancel)
     .addComponent(Btn_InEdit)
     .addComponent(Btn_InAdd)
     .addComponent(CB_ItemInCategorized))
    .addGap(0, 0, Short.MAX_VALUE))
  );

  jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_InTempListRemove.setText("-");
  Btn_InTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_InTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InTempListRemoveActionPerformed(evt);
   }
  });

  Btn_InTempListAdd.setText("+");
  Btn_InTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_InTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InTempListAddActionPerformed(evt);
   }
  });

  jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel4.setText("*");

  Btn_InCheckRemove.setText("-");
  Btn_InCheckRemove.setToolTipText("hapus centang dari barang-barang yg dipilih pd tabel");
  Btn_InCheckRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InCheckRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InCheckRemoveActionPerformed(evt);
   }
  });

  Btn_InCheckAdd.setText("+");
  Btn_InCheckAdd.setToolTipText("centang barang-barang yg dipilih pd tabel");
  Btn_InCheckAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_InCheckAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_InCheckAddActionPerformed(evt);
   }
  });

  jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel10.setText("Ck");

  CmB_FindItemIn.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nama Brg", "Kategori" }));

  TF_FindItemIn.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindItemInFocusGained(evt);
   }
  });
  TF_FindItemIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindItemInKeyPressed(evt);
   }
  });

  Btn_FindItemInBef.setText("<");
  Btn_FindItemInBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemInBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemInBefActionPerformed(evt);
   }
  });

  Btn_FindItemInNext.setText(">");
  Btn_FindItemInNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemInNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemInNextActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
  jPanel6.setLayout(jPanel6Layout);
  jPanel6Layout.setHorizontalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
    .addComponent(CmB_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FindItemIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemInBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemInNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel4)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel10)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InCheckAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_InCheckRemove))
  );
  jPanel6Layout.setVerticalGroup(
   jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_InTempListRemove)
    .addComponent(Btn_InTempListAdd)
    .addComponent(jLabel4)
    .addComponent(Btn_InCheckRemove)
    .addComponent(Btn_InCheckAdd)
    .addComponent(jLabel10)
    .addComponent(CmB_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_FindItemIn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_FindItemInBef)
    .addComponent(Btn_FindItemInNext))
  );

  TF_InInfoCategory.setEditable(false);
  TF_InInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TF_InInfoCategory.setColumns(20);
  TF_InInfoCategory.setLineWrap(true);
  TF_InInfoCategory.setWrapStyleWord(true);
  jScrollPane20.setViewportView(TF_InInfoCategory);

  Tbl_In.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_In.setToolTipText("F9 - Cek ; F10 - Hapus Cek");
  Tbl_In.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_In.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_In.setRowHeight(18);
  Tbl_In.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_InMouseReleased(evt);
   }
  });
  Tbl_In.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_InKeyReleased(evt);
   }
  });
  jScrollPane3.setViewportView(Tbl_In);

  javax.swing.GroupLayout Panel_InLayout = new javax.swing.GroupLayout(Panel_In);
  Panel_In.setLayout(Panel_InLayout);
  Panel_InLayout.setHorizontalGroup(
   Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_InLayout.createSequentialGroup()
    .addComponent(Pnl_ItemInPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane20)
     .addComponent(jScrollPane15)))
   .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
  );
  Panel_InLayout.setVerticalGroup(
   Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_InLayout.createSequentialGroup()
    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_InLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel_InLayout.createSequentialGroup()
      .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane15))
     .addComponent(Pnl_ItemInPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  TabbedPane.addTab("Brg Msk", null, Panel_In, "");

  Btn_PaymentOutPrint.setText("Ctak Tnda Trima");
  Btn_PaymentOutPrint.setToolTipText("cetak tanda terima pembayaran dari data-data pembayaran yg dipilih pada tabel");
  Btn_PaymentOutPrint.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentOutPrint.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentOutPrintActionPerformed(evt);
   }
  });

  Btn_PaymentOutCancel.setText("Btal {F8}");
  Btn_PaymentOutCancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentOutCancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentOutCancelActionPerformed(evt);
   }
  });

  Btn_PaymentOutEdit.setText("Ubah {F7}");
  Btn_PaymentOutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentOutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentOutEditActionPerformed(evt);
   }
  });

  Btn_PaymentOutAdd.setText("Tbah {F6}");
  Btn_PaymentOutAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentOutAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentOutAddActionPerformed(evt);
   }
  });

  TF_PayOutCount.setEditable(false);
  TF_PayOutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_PayOutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
  jPanel8.setLayout(jPanel8Layout);
  jPanel8Layout.setHorizontalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
    .addComponent(TF_PayOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE)
    .addComponent(Btn_PaymentOutAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PaymentOutEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PaymentOutCancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PaymentOutPrint))
  );
  jPanel8Layout.setVerticalGroup(
   jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_PaymentOutPrint)
    .addComponent(Btn_PaymentOutCancel)
    .addComponent(Btn_PaymentOutEdit)
    .addComponent(Btn_PaymentOutAdd)
    .addComponent(TF_PayOutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_PaymentOutDate.setEditable(false);
  TF_PaymentOutDate.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PaymentOutDate.setText("Tanggal");

  TF_PaymentOutCash.setEditable(false);
  TF_PaymentOutCash.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PaymentOutCash.setText("Kas Kredit");

  TF_PaymentOutPrice.setEditable(false);
  TF_PaymentOutPrice.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PaymentOutPrice.setText("Jumlah");

  TA_PaymentOutComment.setEditable(false);
  TA_PaymentOutComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_PaymentOutComment.setColumns(20);
  TA_PaymentOutComment.setLineWrap(true);
  TA_PaymentOutComment.setWrapStyleWord(true);
  jScrollPane9.setViewportView(TA_PaymentOutComment);

  Lbl_PaymentOutComment.setText("Keterangan");

  javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
  jPanel10.setLayout(jPanel10Layout);
  jPanel10Layout.setHorizontalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_PaymentOutCash)
     .addComponent(Lbl_PaymentOutDate)
     .addComponent(Lbl_PaymentOutPrice)
     .addComponent(Lbl_PaymentOutComment))
    .addGap(18, 18, 18)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane9, javax.swing.GroupLayout.Alignment.TRAILING)
     .addComponent(TF_PaymentOutPrice)
     .addComponent(TF_PaymentOutDate)
     .addComponent(TF_PaymentOutCash)))
  );
  jPanel10Layout.setVerticalGroup(
   jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel10Layout.createSequentialGroup()
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentOutDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentOutDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentOutCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentOutCash))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentOutPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentOutPrice))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
     .addGroup(jPanel10Layout.createSequentialGroup()
      .addComponent(Lbl_PaymentOutComment)
      .addGap(0, 0, Short.MAX_VALUE))))
  );

  Tbl_PaymentOut.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_PaymentOut.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_PaymentOut.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_PaymentOut.setRowHeight(18);
  Tbl_PaymentOut.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_PaymentOutMouseReleased(evt);
   }
  });
  Tbl_PaymentOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_PaymentOutKeyReleased(evt);
   }
  });
  jScrollPane7.setViewportView(Tbl_PaymentOut);

  javax.swing.GroupLayout Panel_PaymentOutLayout = new javax.swing.GroupLayout(Panel_PaymentOut);
  Panel_PaymentOut.setLayout(Panel_PaymentOutLayout);
  Panel_PaymentOutLayout.setHorizontalGroup(
   Panel_PaymentOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane7)
  );
  Panel_PaymentOutLayout.setVerticalGroup(
   Panel_PaymentOutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_PaymentOutLayout.createSequentialGroup()
    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 419, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("{ Byr Klr }", Panel_PaymentOut);

  TF_OutInfoName.setEditable(false);
  TF_OutInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutInfoName.setColumns(20);
  TF_OutInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TF_OutInfoName.setLineWrap(true);
  TF_OutInfoName.setWrapStyleWord(true);
  jScrollPane16.setViewportView(TF_OutInfoName);

  Pnl_ItemOutPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_ItemOutPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_ItemOutPreviewMouseClicked(evt);
   }
  });

  jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_OutTempListRemove.setText("-");
  Btn_OutTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_OutTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutTempListRemoveActionPerformed(evt);
   }
  });

  Btn_OutTempListAdd.setText("+");
  Btn_OutTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_OutTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutTempListAddActionPerformed(evt);
   }
  });

  jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel7.setText("*");

  Btn_OutCheckRemove.setText("-");
  Btn_OutCheckRemove.setToolTipText("hapus centang dari barang-barang yg dipilih pd tabel");
  Btn_OutCheckRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutCheckRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutCheckRemoveActionPerformed(evt);
   }
  });

  Btn_OutCheckAdd.setText("+");
  Btn_OutCheckAdd.setToolTipText("centang barang-barang yg dipilih pd tabel");
  Btn_OutCheckAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutCheckAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutCheckAddActionPerformed(evt);
   }
  });

  jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel11.setText("Ck");

  CmB_FindItemOut.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nama Brg", "Kategori" }));

  TF_FindItemOut.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindItemOutFocusGained(evt);
   }
  });
  TF_FindItemOut.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindItemOutKeyPressed(evt);
   }
  });

  Btn_FindItemOutNext.setText(">");
  Btn_FindItemOutNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemOutNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemOutNextActionPerformed(evt);
   }
  });

  Btn_FindItemOutBef.setText("<");
  Btn_FindItemOutBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindItemOutBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindItemOutBefActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
  jPanel4.setLayout(jPanel4Layout);
  jPanel4Layout.setHorizontalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createSequentialGroup()
    .addComponent(CmB_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_FindItemOut)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemOutBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindItemOutNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel7)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jLabel11)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutCheckAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutCheckRemove))
  );
  jPanel4Layout.setVerticalGroup(
   jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_OutTempListRemove)
    .addComponent(Btn_OutTempListAdd)
    .addComponent(jLabel7)
    .addComponent(Btn_OutCheckRemove)
    .addComponent(Btn_OutCheckAdd)
    .addComponent(jLabel11)
    .addComponent(CmB_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(TF_FindItemOut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_FindItemOutNext)
    .addComponent(Btn_FindItemOutBef))
  );

  TF_OutCount.setEditable(false);
  TF_OutCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_OutOtherOperation.setText("...");
  Btn_OutOtherOperation.setToolTipText("opsi lanjutan terhadap barang2 yg dipilih");
  Btn_OutOtherOperation.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutOtherOperation.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutOtherOperationActionPerformed(evt);
   }
  });

  Btn_OutCancel.setText("Btl {F8}");
  Btn_OutCancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutCancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutCancelActionPerformed(evt);
   }
  });

  Btn_OutEdit.setText("Ubh {F7}");
  Btn_OutEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutEditActionPerformed(evt);
   }
  });

  Btn_OutAdd.setText("Tbh {F6}");
  Btn_OutAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OutAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OutAddActionPerformed(evt);
   }
  });

  CB_ItemOutCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutCategorized.setText("K");
  CB_ItemOutCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_ItemOutCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutCategorized.setIconTextGap(0);
  CB_ItemOutCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutCategorizedActionPerformed(evt);
   }
  });

  CB_ItemOutShowBasicPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_ItemOutShowBasicPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ItemOutShowBasicPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_ItemOutShowBasicPrice.setText("HPP");
  CB_ItemOutShowBasicPrice.setToolTipText("tekan tombol 'HPP' utk menampilkan Harga Pokok Penjualan (HPP)");
  CB_ItemOutShowBasicPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ItemOutShowBasicPrice.setIconTextGap(0);
  CB_ItemOutShowBasicPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutShowBasicPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutShowBasicPriceActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
  jPanel7.setLayout(jPanel7Layout);
  jPanel7Layout.setHorizontalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
    .addComponent(TF_OutCount, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ItemOutShowBasicPrice)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_OutAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutCancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OutOtherOperation))
  );
  jPanel7Layout.setVerticalGroup(
   jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_OutCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_OutOtherOperation)
    .addComponent(Btn_OutCancel)
    .addComponent(Btn_OutEdit)
    .addComponent(Btn_OutAdd)
    .addComponent(CB_ItemOutCategorized)
    .addComponent(CB_ItemOutShowBasicPrice))
  );

  TF_OutInfoCategory.setEditable(false);
  TF_OutInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TF_OutInfoCategory.setColumns(20);
  TF_OutInfoCategory.setLineWrap(true);
  TF_OutInfoCategory.setWrapStyleWord(true);
  jScrollPane21.setViewportView(TF_OutInfoCategory);

  Tbl_Out.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Out.setToolTipText("F9 - Cek ; F10 - Hapus Cek");
  Tbl_Out.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Out.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Out.setRowHeight(18);
  Tbl_Out.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_OutMouseReleased(evt);
   }
  });
  Tbl_Out.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_OutKeyReleased(evt);
   }
  });
  jScrollPane2.setViewportView(Tbl_Out);

  javax.swing.GroupLayout Panel_OutLayout = new javax.swing.GroupLayout(Panel_Out);
  Panel_Out.setLayout(Panel_OutLayout);
  Panel_OutLayout.setHorizontalGroup(
   Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_OutLayout.createSequentialGroup()
    .addComponent(Pnl_ItemOutPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane21)
     .addComponent(jScrollPane16)))
   .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
  );
  Panel_OutLayout.setVerticalGroup(
   Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_OutLayout.createSequentialGroup()
    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_OutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel_OutLayout.createSequentialGroup()
      .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane16))
     .addComponent(Pnl_ItemOutPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  TabbedPane.addTab("Brg Klr", Panel_Out);

  TF_PayInCount.setEditable(false);
  TF_PayInCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_PayInCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

  Btn_PaymentInPrint.setText("Ctak Tnda Trima");
  Btn_PaymentInPrint.setToolTipText("cetak tanda terima pembayaran dari data-data pembayaran yg dipilih pada tabel");
  Btn_PaymentInPrint.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentInPrint.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentInPrintActionPerformed(evt);
   }
  });

  Btn_PaymentInCancel.setText("Btal {F8}");
  Btn_PaymentInCancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentInCancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentInCancelActionPerformed(evt);
   }
  });

  Btn_PaymentInEdit.setText("Ubah {F7}");
  Btn_PaymentInEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentInEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentInEditActionPerformed(evt);
   }
  });

  Btn_PaymentInAdd.setText("Tbah {F6}");
  Btn_PaymentInAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PaymentInAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PaymentInAddActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
  jPanel11.setLayout(jPanel11Layout);
  jPanel11Layout.setHorizontalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
    .addComponent(TF_PayInCount, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE)
    .addComponent(Btn_PaymentInAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PaymentInEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PaymentInCancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_PaymentInPrint))
  );
  jPanel11Layout.setVerticalGroup(
   jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_PaymentInPrint)
    .addComponent(Btn_PaymentInCancel)
    .addComponent(Btn_PaymentInEdit)
    .addComponent(Btn_PaymentInAdd)
    .addComponent(TF_PayInCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TF_PaymentInDate.setEditable(false);
  TF_PaymentInDate.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PaymentInDate.setText("Tanggal");

  TF_PaymentInCash.setEditable(false);
  TF_PaymentInCash.setBackground(new java.awt.Color(204, 255, 204));

  Lbl_PaymentInCash.setText("Kas Kredit");

  TF_PaymentInPrice.setEditable(false);
  TF_PaymentInPrice.setBackground(new java.awt.Color(204, 255, 204));

  TA_PaymentInComment.setEditable(false);
  TA_PaymentInComment.setBackground(new java.awt.Color(204, 255, 204));
  TA_PaymentInComment.setColumns(20);
  TA_PaymentInComment.setLineWrap(true);
  TA_PaymentInComment.setWrapStyleWord(true);
  jScrollPane12.setViewportView(TA_PaymentInComment);

  Lbl_PaymentInPrice.setText("Jumlah");

  Lbl_PaymentInComment.setText("Keterangan");

  javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
  jPanel12.setLayout(jPanel12Layout);
  jPanel12Layout.setHorizontalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(Lbl_PaymentInDate)
     .addComponent(Lbl_PaymentInCash)
     .addComponent(Lbl_PaymentInPrice)
     .addComponent(Lbl_PaymentInComment))
    .addGap(18, 18, 18)
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane12)
     .addComponent(TF_PaymentInPrice)
     .addComponent(TF_PaymentInCash)
     .addComponent(TF_PaymentInDate)))
  );
  jPanel12Layout.setVerticalGroup(
   jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel12Layout.createSequentialGroup()
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentInDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentInDate))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentInCash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentInCash))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentInPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_PaymentInPrice))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
     .addGroup(jPanel12Layout.createSequentialGroup()
      .addComponent(Lbl_PaymentInComment)
      .addGap(0, 0, Short.MAX_VALUE))))
  );

  Tbl_PaymentIn.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_PaymentIn.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_PaymentIn.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_PaymentIn.setRowHeight(18);
  Tbl_PaymentIn.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_PaymentInMouseReleased(evt);
   }
  });
  Tbl_PaymentIn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_PaymentInKeyReleased(evt);
   }
  });
  jScrollPane8.setViewportView(Tbl_PaymentIn);

  javax.swing.GroupLayout Panel_PaymentInLayout = new javax.swing.GroupLayout(Panel_PaymentIn);
  Panel_PaymentIn.setLayout(Panel_PaymentInLayout);
  Panel_PaymentInLayout.setHorizontalGroup(
   Panel_PaymentInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane8)
  );
  Panel_PaymentInLayout.setVerticalGroup(
   Panel_PaymentInLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_PaymentInLayout.createSequentialGroup()
    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 419, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  TabbedPane.addTab("{ Byr Msk }", Panel_PaymentIn);

  TF_OrdCount.setEditable(false);
  TF_OrdCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_OrdCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_OrdCount.setToolTipText("Jumlah data order");

  Btn_OrdRefresh.setText("R");
  Btn_OrdRefresh.setToolTipText("klik 'R' utk menyegarkan daftar order dlm tabel");
  Btn_OrdRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdRefreshActionPerformed(evt);
   }
  });

  Btn_OrdRemove.setText("H {F8}");
  Btn_OrdRemove.setToolTipText("Hapus data-data order yg dipilih pd tabel");
  Btn_OrdRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdRemoveActionPerformed(evt);
   }
  });

  Btn_OrdEdit.setText("U {F7}");
  Btn_OrdEdit.setToolTipText("Ubah data-data order yg dipilih pd tabel");
  Btn_OrdEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdEditActionPerformed(evt);
   }
  });

  Btn_OrdAdd.setText("B {F6}");
  Btn_OrdAdd.setToolTipText("Tambah sebuah data order");
  Btn_OrdAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdAddActionPerformed(evt);
   }
  });

  TF_OrdPriceEst.setEditable(false);
  TF_OrdPriceEst.setBackground(new java.awt.Color(204, 255, 204));
  TF_OrdPriceEst.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_OrdPriceEst.setToolTipText("Kisaran total harga order");

  CB_OrdCategorized.setBackground(new java.awt.Color(204, 204, 204));
  CB_OrdCategorized.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_OrdCategorized.setForeground(new java.awt.Color(102, 102, 0));
  CB_OrdCategorized.setText("K");
  CB_OrdCategorized.setToolTipText("tekan tombol 'K' untuk menampilkan daftar barang di dalam tabel secara terkategori");
  CB_OrdCategorized.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_OrdCategorized.setIconTextGap(0);
  CB_OrdCategorized.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_OrdCategorized.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_OrdCategorizedActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
  jPanel13.setLayout(jPanel13Layout);
  jPanel13Layout.setHorizontalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
    .addComponent(TF_OrdCount, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_OrdPriceEst, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdRefresh)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_OrdCategorized)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Btn_OrdAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdRemove))
  );
  jPanel13Layout.setVerticalGroup(
   jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(TF_OrdCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_OrdRefresh)
    .addComponent(Btn_OrdRemove)
    .addComponent(Btn_OrdEdit)
    .addComponent(Btn_OrdAdd)
    .addComponent(TF_OrdPriceEst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(CB_OrdCategorized))
  );

  jPanel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CmB_OrdFind.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Brg", "Nm Brg", "Kategori" }));

  Btn_OrdFindNext.setText(">");
  Btn_OrdFindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdFindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdFindNextActionPerformed(evt);
   }
  });

  Btn_OrdFindBef.setText("<");
  Btn_OrdFindBef.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdFindBef.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdFindBefActionPerformed(evt);
   }
  });

  TF_OrdFind.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_OrdFindFocusGained(evt);
   }
  });
  TF_OrdFind.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_OrdFindKeyPressed(evt);
   }
  });

  Btn_OrdTempListRemove.setText("-");
  Btn_OrdTempListRemove.setToolTipText("kurangi barang2 yg dipilih dari 'DaftarKu' pd form Barang");
  Btn_OrdTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdTempListRemoveActionPerformed(evt);
   }
  });

  Btn_OrdTempListAdd.setText("+");
  Btn_OrdTempListAdd.setToolTipText("tambahkan barang2 yg dipilih ke 'DaftarKu' pd form Barang");
  Btn_OrdTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdTempListAddActionPerformed(evt);
   }
  });

  jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel12.setText("*");

  Btn_OrdMove.setText("> {F5}");
  Btn_OrdMove.setToolTipText("Masukkan data-data order yg dipilih ke dlm transaksi yg dipilih pd tabel transaksi");
  Btn_OrdMove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_OrdMove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OrdMoveActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
  jPanel14.setLayout(jPanel14Layout);
  jPanel14Layout.setHorizontalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createSequentialGroup()
    .addComponent(CmB_OrdFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_OrdFind)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdFindBef)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdFindNext)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jLabel12)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_OrdTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(Btn_OrdMove))
  );
  jPanel14Layout.setVerticalGroup(
   jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CmB_OrdFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_OrdFindNext)
    .addComponent(Btn_OrdFindBef)
    .addComponent(TF_OrdFind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_OrdTempListRemove)
    .addComponent(Btn_OrdTempListAdd)
    .addComponent(jLabel12)
    .addComponent(Btn_OrdMove))
  );

  Pnl_OrdPreview.setToolTipText("klik utk melihat keterangan barang");
  Pnl_OrdPreview.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Pnl_OrdPreviewMouseClicked(evt);
   }
  });

  TA_OrdInfoCategory.setEditable(false);
  TA_OrdInfoCategory.setBackground(new java.awt.Color(204, 255, 204));
  TA_OrdInfoCategory.setColumns(20);
  TA_OrdInfoCategory.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_OrdInfoCategory.setLineWrap(true);
  TA_OrdInfoCategory.setWrapStyleWord(true);
  jScrollPane18.setViewportView(TA_OrdInfoCategory);

  TA_OrdInfoName.setEditable(false);
  TA_OrdInfoName.setBackground(new java.awt.Color(204, 255, 204));
  TA_OrdInfoName.setColumns(20);
  TA_OrdInfoName.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_OrdInfoName.setLineWrap(true);
  TA_OrdInfoName.setWrapStyleWord(true);
  jScrollPane19.setViewportView(TA_OrdInfoName);

  Tbl_Ord.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Ord.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Ord.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Ord.setRowHeight(18);
  Tbl_Ord.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_OrdMouseReleased(evt);
   }
  });
  Tbl_Ord.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_OrdKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_OrdKeyReleased(evt);
   }
  });
  jScrollPane22.setViewportView(Tbl_Ord);

  javax.swing.GroupLayout Panel_OrderLayout = new javax.swing.GroupLayout(Panel_Order);
  Panel_Order.setLayout(Panel_OrderLayout);
  Panel_OrderLayout.setHorizontalGroup(
   Panel_OrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel_OrderLayout.createSequentialGroup()
    .addComponent(Pnl_OrdPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addGroup(Panel_OrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(jScrollPane18)
     .addComponent(jScrollPane19)))
   .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
  );
  Panel_OrderLayout.setVerticalGroup(
   Panel_OrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(Panel_OrderLayout.createSequentialGroup()
    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
    .addGap(0, 0, 0)
    .addGroup(Panel_OrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
     .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel_OrderLayout.createSequentialGroup()
      .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addGap(0, 0, 0)
      .addComponent(jScrollPane19))
     .addComponent(Pnl_OrdPreview, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  TabbedPane.addTab("Order", Panel_Order);

  Lbl_PaymentOutSum.setText("{ Bayar Keluar }");

  Lbl_ItemOutSum.setText("Barang Keluar");

  Lbl_PaymentInSum.setText("{ Bayar Masuk }");

  Lbl_ItemInSum.setText("Barang Masuk");

  TF_ItemInSum.setEditable(false);
  TF_ItemInSum.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemInSum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_ItemInSum.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_ItemInSum.setToolTipText("Akumulasi harga barang masuk");

  TF_ItemOutBasicSum.setEditable(false);
  TF_ItemOutBasicSum.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutBasicSum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_ItemOutBasicSum.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_ItemOutBasicSum.setToolTipText("Akumulasi Harga Pokok Penjualan (HPP)");

  TF_PaymentOutSum.setEditable(false);
  TF_PaymentOutSum.setBackground(new java.awt.Color(204, 255, 204));
  TF_PaymentOutSum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_PaymentOutSum.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_PaymentOutSum.setToolTipText("Akumulasi pembayaran keluar (diasumsikan utk transaksi yg berjenis kredit)");

  TF_ItemOutSum.setEditable(false);
  TF_ItemOutSum.setBackground(new java.awt.Color(204, 255, 204));
  TF_ItemOutSum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_ItemOutSum.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_ItemOutSum.setToolTipText("Akumulasi harga barang keluar");

  TF_PaymentInSum.setEditable(false);
  TF_PaymentInSum.setBackground(new java.awt.Color(204, 255, 204));
  TF_PaymentInSum.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
  TF_PaymentInSum.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
  TF_PaymentInSum.setToolTipText("Akumulasi pembayaran masuk (diasumsikan utk transaksi yg berjenis kredit)");

  CB_ItemOutBasicSum.setText("{ HPP }");
  CB_ItemOutBasicSum.setToolTipText("centang utk melihat nilai Harga Pokok Penjualan (HPP)");
  CB_ItemOutBasicSum.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
  CB_ItemOutBasicSum.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ItemOutBasicSum.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ItemOutBasicSumActionPerformed(evt);
   }
  });

  TF_ListCount.setEditable(false);
  TF_ListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_ListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_ListCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_ListCount.setToolTipText("Jumlah data transaksi di daftar");

  TF_QueryTempListCount.setEditable(false);
  TF_QueryTempListCount.setBackground(new java.awt.Color(204, 255, 204));
  TF_QueryTempListCount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_QueryTempListCount.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_QueryTempListCount.setToolTipText("Jumlah data 'DaftarKu' di daftar");

  Btn_QueryRefresh.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Btn_QueryRefresh.setText("R");
  Btn_QueryRefresh.setToolTipText("klik 'R' utk menyegarkan daftar transaksi dlm tabel");
  Btn_QueryRefresh.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_QueryRefresh.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_QueryRefreshActionPerformed(evt);
   }
  });

  CmB_ResultFilterSubset.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "*Semua", "*DaftarKu", "*~DftarKu" }));
  CmB_ResultFilterSubset.setToolTipText("Filter \"DaftarKu\"");
  CmB_ResultFilterSubset.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ResultFilterSubsetActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout Pnl_TransSummaryLayout = new javax.swing.GroupLayout(Pnl_TransSummary);
  Pnl_TransSummary.setLayout(Pnl_TransSummaryLayout);
  Pnl_TransSummaryLayout.setHorizontalGroup(
   Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_TransSummaryLayout.createSequentialGroup()
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(Pnl_TransSummaryLayout.createSequentialGroup()
      .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_QueryRefresh))
     .addGroup(Pnl_TransSummaryLayout.createSequentialGroup()
      .addComponent(TF_ListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(Lbl_ItemInSum, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
     .addComponent(TF_ItemInSum))
    .addGap(6, 6, 6)
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_PaymentOutSum)
     .addComponent(Lbl_PaymentOutSum, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addGap(6, 6, 6)
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_ItemOutSum)
     .addComponent(Lbl_ItemOutSum, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addGap(6, 6, 6)
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_ItemOutBasicSum)
     .addComponent(CB_ItemOutBasicSum, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addGap(6, 6, 6)
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(TF_PaymentInSum)
     .addComponent(Lbl_PaymentInSum, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)))
  );
  Pnl_TransSummaryLayout.setVerticalGroup(
   Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_TransSummaryLayout.createSequentialGroup()
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_PaymentInSum)
     .addComponent(Lbl_ItemInSum)
     .addComponent(Lbl_ItemOutSum)
     .addComponent(Lbl_PaymentOutSum)
     .addComponent(CB_ItemOutBasicSum)
     .addComponent(CmB_ResultFilterSubset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_QueryRefresh))
    .addGap(3, 3, 3)
    .addGroup(Pnl_TransSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_PaymentInSum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ItemOutSum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_PaymentOutSum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ItemInSum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ItemOutBasicSum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_ListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_QueryTempListCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
  );

  Btn_TransEdit.setText("Ubah {F2}");
  Btn_TransEdit.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransEdit.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransEditActionPerformed(evt);
   }
  });

  Btn_TransCancel.setText("Batalkan / Transaksikan {F3}");
  Btn_TransCancel.setToolTipText("");
  Btn_TransCancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransCancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransCancelActionPerformed(evt);
   }
  });

  Btn_TransRemove.setText("Hapus");
  Btn_TransRemove.setToolTipText("Operasi penghapusan akan menghapus transaksi yang dipilih, tetapi tidak mengubah stok barang yang berkaitan");
  Btn_TransRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransRemoveActionPerformed(evt);
   }
  });

  Btn_Report.setText("Cetak");
  Btn_Report.setToolTipText("");
  Btn_Report.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Report.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ReportActionPerformed(evt);
   }
  });

  CmB_ReportType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Laporan", "Nota", "File CSV" }));

  Btn_TransChoose.setText("Pilih {F11}");
  Btn_TransChoose.setToolTipText("Operasi penghapusan akan menghapus transaksi tanpa mengubah stok barang yang berkaitan");
  Btn_TransChoose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransChoose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransChooseActionPerformed(evt);
   }
  });

  Lbl_MultipleSelection.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_MultipleSelection.setText("{Boleh >1}");

  Btn_TransNew.setText("Buat Baru {F1}");
  Btn_TransNew.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransNew.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransNewActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
  jPanel2.setLayout(jPanel2Layout);
  jPanel2Layout.setHorizontalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel2Layout.createSequentialGroup()
    .addComponent(Btn_TransNew)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransEdit)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransCancel)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_Report)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(Lbl_MultipleSelection)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransChoose))
  );
  jPanel2Layout.setVerticalGroup(
   jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
    .addGap(0, 0, Short.MAX_VALUE)
    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_TransEdit)
     .addComponent(Btn_TransCancel)
     .addComponent(Btn_TransRemove)
     .addComponent(Btn_Report)
     .addComponent(CmB_ReportType, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_TransChoose)
     .addComponent(Lbl_MultipleSelection)
     .addComponent(Btn_TransNew)))
  );

  jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TempListLoad.setText("P");
  Btn_TempListLoad.setToolTipText("pulihkan data 'DaftarKu' dari suatu file");
  Btn_TempListLoad.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListLoad.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListLoadActionPerformed(evt);
   }
  });

  Btn_TempListSave.setText("S");
  Btn_TempListSave.setToolTipText("simpan data 'DaftarKu' ke suatu file");
  Btn_TempListSave.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListSave.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListSaveActionPerformed(evt);
   }
  });

  Btn_TempListRemove.setText("-");
  Btn_TempListRemove.setToolTipText("mengurangi transaksi2 yg dipilih dari 'DaftarKu'");
  Btn_TempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListRemoveActionPerformed(evt);
   }
  });

  Btn_TempListAdd.setText("+");
  Btn_TempListAdd.setToolTipText("menambahkan transaksi2 yg dipilih ke 'DaftarKu'");
  Btn_TempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListAddActionPerformed(evt);
   }
  });

  TF_TempListQuantity.setEditable(false);
  TF_TempListQuantity.setBackground(new java.awt.Color(204, 255, 204));
  TF_TempListQuantity.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
  TF_TempListQuantity.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_TempListQuantity.setToolTipText("jumlah data di dalam 'DaftarKu' (klik kiri - lihat DaftarKu ; klik kanan - lihat ~DaftarKu)");
  TF_TempListQuantity.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_TempListQuantity.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_TempListQuantityMouseClicked(evt);
   }
  });

  jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel2.setText("*DaftarKu");

  CmB_Find.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Id Trans", "Id External", "Jenis Trans", "Subjek", "Salesman", "Kas Keluar", "Ket. Kas Keluar", "Kas Masuk", "Ket. Kas Masuk" }));

  Btn_FindNext.setText(">");
  Btn_FindNext.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindNext.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindNextActionPerformed(evt);
   }
  });

  Btn_FindBefore.setText("<");
  Btn_FindBefore.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_FindBefore.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_FindBeforeActionPerformed(evt);
   }
  });

  TF_Find.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_FindFocusGained(evt);
   }
  });
  TF_Find.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_FindKeyPressed(evt);
   }
  });

  Btn_TempListClear.setText("X");
  Btn_TempListClear.setToolTipText("kosongkan data di dalam 'DaftarKu'");
  Btn_TempListClear.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TempListClear.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TempListClearActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
  jPanel3.setLayout(jPanel3Layout);
  jPanel3Layout.setHorizontalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createSequentialGroup()
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_Find)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindBefore)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_FindNext)
    .addGap(18, 18, 18)
    .addComponent(jLabel2)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListSave)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListLoad)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TempListClear))
  );
  jPanel3Layout.setVerticalGroup(
   jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TempListLoad)
    .addComponent(Btn_TempListSave)
    .addComponent(Btn_TempListRemove)
    .addComponent(Btn_TempListAdd)
    .addComponent(TF_TempListQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(jLabel2)
    .addComponent(CmB_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_FindNext)
    .addComponent(Btn_FindBefore)
    .addComponent(TF_Find, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addComponent(Btn_TempListClear))
  );

  Pnl_View.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  CmB_ViewMode.setBackground(new java.awt.Color(255, 220, 209));
  CmB_ViewMode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "- Normal -", "Cicilan" }));
  CmB_ViewMode.setToolTipText("Pilih mode tampilan daftar transaksi di tabel");
  CmB_ViewMode.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CmB_ViewModeActionPerformed(evt);
   }
  });

  CB_ViewDate.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewDate.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewDate.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewDate.setText("Tg");
  CB_ViewDate.setToolTipText("Tanggal Transaksi");
  CB_ViewDate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewDate.setIconTextGap(0);
  CB_ViewDate.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewDate.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewDateActionPerformed(evt);
   }
  });

  CB_ViewDateBill.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewDateBill.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewDateBill.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewDateBill.setText("Th");
  CB_ViewDateBill.setToolTipText("Tanggal Tagih");
  CB_ViewDateBill.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewDateBill.setIconTextGap(0);
  CB_ViewDateBill.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewDateBill.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewDateBillActionPerformed(evt);
   }
  });

  CB_ViewDateRepayment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewDateRepayment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewDateRepayment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewDateRepayment.setText("Cl");
  CB_ViewDateRepayment.setToolTipText("Periode Cicil");
  CB_ViewDateRepayment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewDateRepayment.setIconTextGap(0);
  CB_ViewDateRepayment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewDateRepayment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewDateRepaymentActionPerformed(evt);
   }
  });

  CB_ViewSubject.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSubject.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSubject.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSubject.setText("Sb");
  CB_ViewSubject.setToolTipText("Subjek");
  CB_ViewSubject.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSubject.setIconTextGap(0);
  CB_ViewSubject.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSubject.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSubjectActionPerformed(evt);
   }
  });

  CB_ViewSalesman.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewSalesman.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewSalesman.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewSalesman.setText("Sl");
  CB_ViewSalesman.setToolTipText("Salesman");
  CB_ViewSalesman.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewSalesman.setIconTextGap(0);
  CB_ViewSalesman.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewSalesman.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewSalesmanActionPerformed(evt);
   }
  });

  CB_ViewCashOut.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashOut.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashOut.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashOut.setText("Ks K");
  CB_ViewCashOut.setToolTipText("Kas Keluar");
  CB_ViewCashOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashOut.setIconTextGap(0);
  CB_ViewCashOut.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashOut.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashOutActionPerformed(evt);
   }
  });

  CB_ViewCashOutComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashOutComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashOutComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashOutComment.setText("{C}");
  CB_ViewCashOutComment.setToolTipText("Keterangan Kas Keluar");
  CB_ViewCashOutComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashOutComment.setIconTextGap(0);
  CB_ViewCashOutComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashOutComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashOutCommentActionPerformed(evt);
   }
  });

  CB_ViewCashIn.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashIn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashIn.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashIn.setText("M");
  CB_ViewCashIn.setToolTipText("Kas Masuk");
  CB_ViewCashIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashIn.setIconTextGap(0);
  CB_ViewCashIn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashIn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashInActionPerformed(evt);
   }
  });

  CB_ViewCashInComment.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewCashInComment.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewCashInComment.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewCashInComment.setText("{C}");
  CB_ViewCashInComment.setToolTipText("Keterangan Kas Masuk");
  CB_ViewCashInComment.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewCashInComment.setIconTextGap(0);
  CB_ViewCashInComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewCashInComment.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewCashInCommentActionPerformed(evt);
   }
  });

  CB_ViewId.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewId.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewId.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewId.setText("Id");
  CB_ViewId.setToolTipText("Id Transaksi");
  CB_ViewId.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewId.setIconTextGap(0);
  CB_ViewId.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewId.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIdActionPerformed(evt);
   }
  });

  CB_ViewIdExternal.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewIdExternal.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewIdExternal.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewIdExternal.setText("{E}");
  CB_ViewIdExternal.setToolTipText("{ Id External }");
  CB_ViewIdExternal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewIdExternal.setIconTextGap(0);
  CB_ViewIdExternal.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewIdExternal.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIdExternalActionPerformed(evt);
   }
  });

  CB_ViewIsImportant.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewIsImportant.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewIsImportant.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewIsImportant.setText("P");
  CB_ViewIsImportant.setToolTipText("Penting");
  CB_ViewIsImportant.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewIsImportant.setIconTextGap(0);
  CB_ViewIsImportant.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewIsImportant.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewIsImportantActionPerformed(evt);
   }
  });

  CB_ViewItemIn.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewItemIn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewItemIn.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewItemIn.setText("Br M");
  CB_ViewItemIn.setToolTipText("Total Harga Barang Masuk & Bayar Keluar");
  CB_ViewItemIn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewItemIn.setIconTextGap(0);
  CB_ViewItemIn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewItemIn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewItemInActionPerformed(evt);
   }
  });

  CB_ViewItemOut.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewItemOut.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewItemOut.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewItemOut.setText("K");
  CB_ViewItemOut.setToolTipText("Total Harga Barang Keluar & Bayar Masuk");
  CB_ViewItemOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewItemOut.setIconTextGap(0);
  CB_ViewItemOut.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewItemOut.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewItemOutActionPerformed(evt);
   }
  });

  CB_ViewItemOutBasicPrice.setBackground(new java.awt.Color(204, 204, 204));
  CB_ViewItemOutBasicPrice.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  CB_ViewItemOutBasicPrice.setForeground(new java.awt.Color(102, 102, 0));
  CB_ViewItemOutBasicPrice.setText("Hpp");
  CB_ViewItemOutBasicPrice.setToolTipText("Total Harga Pokok Penjualan Dari Barang Keluar");
  CB_ViewItemOutBasicPrice.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  CB_ViewItemOutBasicPrice.setIconTextGap(0);
  CB_ViewItemOutBasicPrice.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_ViewItemOutBasicPrice.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_ViewItemOutBasicPriceActionPerformed(evt);
   }
  });

  javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
  jPanel9.setLayout(jPanel9Layout);
  jPanel9Layout.setHorizontalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
    .addComponent(CB_ViewDate)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewDateBill)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewDateRepayment)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewSubject)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewSalesman)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewCashOut)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCashOutComment)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCashIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewCashInComment)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewId)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewIdExternal)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewIsImportant)
    .addGap(18, 18, 18)
    .addComponent(CB_ViewItemIn)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewItemOut)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(CB_ViewItemOutBasicPrice))
  );
  jPanel9Layout.setVerticalGroup(
   jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(CB_ViewDate)
    .addComponent(CB_ViewDateBill)
    .addComponent(CB_ViewDateRepayment)
    .addComponent(CB_ViewSubject)
    .addComponent(CB_ViewSalesman)
    .addComponent(CB_ViewCashOut)
    .addComponent(CB_ViewCashOutComment)
    .addComponent(CB_ViewCashIn)
    .addComponent(CB_ViewCashInComment)
    .addComponent(CB_ViewId)
    .addComponent(CB_ViewIdExternal)
    .addComponent(CB_ViewIsImportant)
    .addComponent(CB_ViewItemIn)
    .addComponent(CB_ViewItemOut)
    .addComponent(CB_ViewItemOutBasicPrice))
  );

  javax.swing.GroupLayout Pnl_ViewLayout = new javax.swing.GroupLayout(Pnl_View);
  Pnl_View.setLayout(Pnl_ViewLayout);
  Pnl_ViewLayout.setHorizontalGroup(
   Pnl_ViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pnl_ViewLayout.createSequentialGroup()
    .addComponent(CmB_ViewMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );
  Pnl_ViewLayout.setVerticalGroup(
   Pnl_ViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
   .addComponent(CmB_ViewMode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
  );

  Tbl_Trans.setModel(new javax.swing.table.DefaultTableModel(
   new Object [][] {
    {},
    {},
    {},
    {}
   },
   new String [] {

   }
  ));
  Tbl_Trans.setToolTipText("'F9' utk tambah ke \"Daftarku\"; 'F10' utk hapus dari \"Daftarku\"");
  Tbl_Trans.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN);
  Tbl_Trans.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  Tbl_Trans.setRowHeight(18);
  Tbl_Trans.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseReleased(java.awt.event.MouseEvent evt) {
    Tbl_TransMouseReleased(evt);
   }
  });
  Tbl_Trans.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Tbl_TransKeyPressed(evt);
   }
   public void keyReleased(java.awt.event.KeyEvent evt) {
    Tbl_TransKeyReleased(evt);
   }
  });
  jScrollPane1.setViewportView(Tbl_Trans);

  jPanel15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

  Btn_TransSalesmanTempListRemove.setText("-");
  Btn_TransSalesmanTempListRemove.setToolTipText("kurangi salesman pd transaksi2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransSalesmanTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSalesmanTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSalesmanTempListRemoveActionPerformed(evt);
   }
  });

  jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel14.setText("Sales*");

  Btn_TransSalesmanTempListAdd.setText("+");
  Btn_TransSalesmanTempListAdd.setToolTipText("tambahkan salesman pd transaksi2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransSalesmanTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSalesmanTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSalesmanTempListAddActionPerformed(evt);
   }
  });

  Btn_TransSalesmanInfo.setText("i");
  Btn_TransSalesmanInfo.setToolTipText("lihat keterangan salesman pd transaksi yg dipilih pd daftar");
  Btn_TransSalesmanInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSalesmanInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSalesmanInfoActionPerformed(evt);
   }
  });

  Btn_TransSubjectInfo.setText("i");
  Btn_TransSubjectInfo.setToolTipText("lihat keterangan subjek pd transaksi yg dipilih pd daftar");
  Btn_TransSubjectInfo.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSubjectInfo.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSubjectInfoActionPerformed(evt);
   }
  });

  Btn_TransSubjectTempListRemove.setText("-");
  Btn_TransSubjectTempListRemove.setToolTipText("kurangi subjek pd transaksi2 yg dipilih dari 'DaftarKu' pd form Subjek");
  Btn_TransSubjectTempListRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSubjectTempListRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSubjectTempListRemoveActionPerformed(evt);
   }
  });

  Btn_TransSubjectTempListAdd.setText("+");
  Btn_TransSubjectTempListAdd.setToolTipText("tambahkan subjek pd transaksi2 yg dipilih ke 'DaftarKu' pd form Subjek");
  Btn_TransSubjectTempListAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_TransSubjectTempListAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TransSubjectTempListAddActionPerformed(evt);
   }
  });

  jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel15.setText("Subjek*");

  Btn_MultipleTransImportantRemove.setText("-");
  Btn_MultipleTransImportantRemove.setToolTipText("menghilangkan tanda atribut penting pada transaksi-transaksi yg dipilih di dlm daftar");
  Btn_MultipleTransImportantRemove.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_MultipleTransImportantRemove.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleTransImportantRemoveActionPerformed(evt);
   }
  });

  Btn_MultipleTransImportantAdd.setText("+");
  Btn_MultipleTransImportantAdd.setToolTipText("menandai atribut penting pada transaksi-transaksi yg dipilih di dlm daftar");
  Btn_MultipleTransImportantAdd.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_MultipleTransImportantAdd.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_MultipleTransImportantAddActionPerformed(evt);
   }
  });

  jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  jLabel13.setText("Penting");

  javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
  jPanel15.setLayout(jPanel15Layout);
  jPanel15Layout.setHorizontalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addComponent(jLabel13)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleTransImportantAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_MultipleTransImportantRemove)
    .addGap(18, 18, 18)
    .addComponent(jLabel15)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransSubjectTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransSubjectTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransSubjectInfo)
    .addGap(18, 18, 18)
    .addComponent(jLabel14)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransSalesmanTempListAdd)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransSalesmanTempListRemove)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Btn_TransSalesmanInfo))
  );
  jPanel15Layout.setVerticalGroup(
   jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
    .addComponent(Btn_TransSalesmanTempListRemove)
    .addComponent(jLabel14)
    .addComponent(Btn_TransSalesmanTempListAdd)
    .addComponent(Btn_TransSalesmanInfo)
    .addComponent(Btn_TransSubjectInfo)
    .addComponent(Btn_TransSubjectTempListRemove)
    .addComponent(Btn_TransSubjectTempListAdd)
    .addComponent(jLabel15)
    .addComponent(Btn_MultipleTransImportantRemove)
    .addComponent(Btn_MultipleTransImportantAdd)
    .addComponent(jLabel13))
  );

  javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
  jPanel1.setLayout(jPanel1Layout);
  jPanel1Layout.setHorizontalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addComponent(Pnl_TransSummary, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(Pnl_View, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
   .addComponent(jScrollPane1)
   .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
  );
  jPanel1Layout.setVerticalGroup(
   jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(jPanel1Layout.createSequentialGroup()
    .addComponent(Pnl_TransSummary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(jScrollPane1)
    .addGap(0, 0, 0)
    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addGap(0, 0, 0)
    .addComponent(Pnl_View, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
  );

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TabbedPane)
     .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void Btn_TransEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransEditActionPerformed
  int[] rows=Tbl_Trans.getSelectedRows();
  if(!PGUI.isEnabled(Btn_TransEdit)){return;}
  if(rows.length==0){return;}
  if(rows.length==1){editSingle(rows[0]); return;}
  if(rows.length>1){editMultiple(rows); return;}
 }//GEN-LAST:event_Btn_TransEditActionPerformed

 private void TF_QIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QIdKeyPressed
  PNav.onKey_Query_TF(this, CB_QId, TF_QId, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QRepayPeriodStartYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QId)));
 }//GEN-LAST:event_TF_QIdKeyPressed

 private void Btn_QueryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryActionPerformed
  runQuery();
 }//GEN-LAST:event_Btn_QueryActionPerformed

 private void Btn_QTransTypeAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QTransTypeAddActionPerformed
  Object[] NewRow;
  int count, temp;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblTransType;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   count=IFV.FDataIdName.DataId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=(int)IFV.FDataIdName.DataId[temp];
    NewRow[1]=IFV.FDataIdName.DataName[temp];
    ListMdlQType.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QTransTypeAddActionPerformed

 private void Btn_QTransTypeRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QTransTypeRemoveActionPerformed
  ListMdlQType.remove(List_QTransType.getSelectedIndices());
 }//GEN-LAST:event_Btn_QTransTypeRemoveActionPerformed

 private void Btn_QSubjectAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSubjectAddActionPerformed
  Object[] NewRow;
  int count, temp;
  
  
  IFV.FSubject.wMode=1;
  IFV.FSubject.wDialogWithFItem=false;
  IFV.FSubject.wAllowMultipleSelection=true;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   count=IFV.FSubject.ChoosedId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=IFV.FSubject.ChoosedId[temp];
    NewRow[1]=IFV.FSubject.ChoosedName[temp];
    ListMdlQSubject.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QSubjectAddActionPerformed

 private void Btn_QSubjectRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSubjectRemoveActionPerformed
  ListMdlQSubject.remove(List_QSubject.getSelectedIndices());
 }//GEN-LAST:event_Btn_QSubjectRemoveActionPerformed

 private void Btn_QItemAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemAddActionPerformed
  Object[] NewRow;
  int count, temp;
  IFV.FItem.wMode=1;
  IFV.FItem.wDialogWithFSubject=false;
  IFV.FItem.wAllowMultipleSelection=true;
  
  if(IFV.FItem.showForm()==false){return;}
  if(IFV.FItem.DialogResult==1){
   count=IFV.FItem.ChoosedId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=IFV.FItem.ChoosedId[temp];
    NewRow[1]=IFV.FItem.ChoosedName[temp];
    TableMdlQItem.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QItemAddActionPerformed

 private void Btn_QItemRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveActionPerformed
  TableMdlQItem.remove(Tbl_QItem.getSelectedRows());
 }//GEN-LAST:event_Btn_QItemRemoveActionPerformed

 private void Btn_TransCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransCancelActionPerformed
  if(!PGUI.isEnabled(Btn_TransCancel)){return;}
  if(!wIsPreTrans){transCancel();}
  else{transConvert();}
 }//GEN-LAST:event_Btn_TransCancelActionPerformed

 private void Btn_TransRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransRemoveActionPerformed
  transRemove();
 }//GEN-LAST:event_Btn_TransRemoveActionPerformed

 private void Btn_TransChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransChooseActionPerformed
  if(!PGUI.isEnabled(Btn_TransChoose)){return;}
  transChoose();
 }//GEN-LAST:event_Btn_TransChooseActionPerformed

 private void Btn_InAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InAddActionPerformed
  int row;
  Object[] NewRow;
  int insertpos;
  long TransId, ItemId;
  String FindName=null;
  int FindColumn=0;
  boolean IsCategorized=CB_ItemInCategorized.isSelected();
  
  do{
   row=Tbl_Trans.getSelectedRow();
   if(row==-1){break;}
   
   IFV.FTransItemModify.wMode=0;
   
   if(IFV.FTransItemModify.showForm()==false){return;}
   if(IFV.FTransItemModify.DialogResult!=1){break;}
   
   TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(row)[0];
   ItemId=IFV.FTransItemModify.ItemInfo.PrimaryId;
   
   if(PMyShop.addATransactionItem(IFV.Stm, wIsPreTrans, true, TransId,
    ItemId, IFV.FTransItemModify.Qty, IFV.FTransItemModify.PriceTotal, IFV.FTransItemModify.TransItemComment)==false){
    JOptionPane.showMessageDialog(null, "Gagal menambah, mungkin dikarenakan"+
     "\ndata barang sudah ada di dalam daftar barang masuk.");
    break;
   }
   
   NewRow=new Object[TableMdlItemInColsName.length];
   NewRow[0]=ItemId;
   NewRow[1]=IFV.FTransItemModify.ItemInfo.Name;
   NewRow[2]=PMyShop.genTransItemName(IFV.FTransItemModify.ItemInfo.Name, IFV.FTransItemModify.TransItemComment);
   NewRow[3]=IFV.FTransItemModify.Qty;
   NewRow[4]=IFV.FTransItemModify.ItemInfo.StockUnitName;
   NewRow[5]=IFV.FTransItemModify.PriceTotal;
   NewRow[6]=IFV.FTransItemModify.PriceTotal/IFV.FTransItemModify.Qty;
   NewRow[7]=IFV.FTransItemModify.TransItemComment;
   NewRow[8]=IFV.FTransItemModify.ItemInfo.PictureFile;
   NewRow[9]=IFV.FTransItemModify.ItemInfo.CategoryName;
   
   if(!IsCategorized){FindColumn=1;}else{FindColumn=9;}
   FindName=PCore.objString(NewRow[FindColumn], null);
   insertpos=PGUI.findInsertPos(TableMdlIn, FindColumn, FindName, false, true, true);
   TableMdlIn.insert(insertpos, NewRow); Tbl_In.changeSelection(insertpos, 0, false, false); onSelectedRowInChanged(true);
   refreshItemCount(TF_InCount, TableMdlIn);
   TIIn=true; TIInClear=false; TIRequeryAll=false;
   
   updateTransItemInPrice(row, false, IFV.FTransItemModify.PriceTotal, true);
  }while(false);
 }//GEN-LAST:event_Btn_InAddActionPerformed

 private void Btn_InEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InEditActionPerformed
  editItems(true);
 }//GEN-LAST:event_Btn_InEditActionPerformed

 private void Btn_InCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InCancelActionPerformed
  int[] rows=Tbl_In.getSelectedRows();
  int rowTrans=Tbl_Trans.getSelectedRow();
  int temp;
  long Id;
  int removedcount;
  double PriceTot;
  boolean[] IsRemove;
  double dbl;
  
  boolean bool;
  
  if(rowTrans==-1 || rows.length==0){return;}

  if(JOptionPane.showConfirmDialog(null, "Batalkan "+rows.length+" barang yang dipilih ?",
   "Konfirmasi Pembatalan Barang Masuk", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}

  Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(rowTrans)[0];
  IsRemove=PCore.newBooleanArray(rows.length, false);
  removedcount=0;
  PriceTot=0;
  
  bool=true;
  do{
   temp=0;
   do{
    if(IsRemove[temp]==false){
     if(PMyShop.cancelATransactionItem(IFV.Stm, wIsPreTrans, true, Id, (Long)TableMdlIn.Mdl.Rows.elementAt(rows[temp])[0])){
      removedcount=removedcount+1;
      dbl=(Double)TableMdlIn.Mdl.Rows.elementAt(rows[temp])[5];
      if(dbl>0){PriceTot=PriceTot+dbl;}
      IsRemove[temp]=true;
     }
    }
    temp=temp+1;
   }while(temp!=rows.length);
   
   if(removedcount==rows.length){break;}
   
   IFV.FMessage.showMessage("Gagal membatalkan "+(rows.length-removedcount)+" data :\n"+
    PText.toStringWithQuote(TableMdlIn.Mdl.Rows, PGUI.getPickedRows(rows, IsRemove, false), "\n",
    PCore.primArr(1, 0), PCore.primArr(false, false), "> ", ".", ", ", "", "", false), PCore.vectObj(
    "Lanjut selesaikan pembatalan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan pembatalan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){break;}
   
   if(!signItemsWithMissmatch(IFV.FMessage.Resolution, TableMdlIn.Mdl.Rows, 0, PGUI.getPickedRows(rows, IsRemove, false))){break;}
  }while(bool);
  
  if(removedcount!=0){
   if(TableMdlIn.Mdl.Rows.size()==removedcount){
    updateTransItemInPrice(rowTrans, true, PriceTot, false);
   }
   else{
    updateTransItemInPrice(rowTrans, false, PriceTot, false);
   }
   TableMdlIn.remove(rows, IsRemove);
   onSelectedRowInChanged(true);
   refreshItemCount(TF_InCount, TableMdlIn);
  }
 }//GEN-LAST:event_Btn_InCancelActionPerformed

 private void Btn_OutAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutAddActionPerformed
  int row;
  Object[] NewRow;
  long ItemId;
  long TransId;
  
  boolean bool;
  boolean success;
  int insertpos;
  
  double BasicPriceTotal;
  
  String FindName=null;
  int FindColumn=0;
  boolean IsCategorized=CB_ItemOutCategorized.isSelected();
  
  row=Tbl_Trans.getSelectedRow();
  if(row==-1){return;}

  IFV.FTransItemModify.wMode=0;
  
  if(IFV.FTransItemModify.showForm()==false){return;}
  if(IFV.FTransItemModify.DialogResult!=1){return;}

  TransId=(Long)TableMdlTrans.Mdl.Rows.elementAt(row)[0];
  ItemId=IFV.FTransItemModify.ItemInfo.PrimaryId;
  success=true;
  
  bool=true;
  do{
   success=PMyShop.addATransactionItem(IFV.Stm, wIsPreTrans, false, TransId,
    ItemId, IFV.FTransItemModify.Qty, IFV.FTransItemModify.PriceTotal, IFV.FTransItemModify.TransItemComment);
   
   if(success){break;}
   
   // check if item has exist in transaction's item out
   if(PDatabase.isQueryEmpty(IFV.Stm, "select * from "+DbTable+"XItemOut where "+
    DbTable+"="+TransId+" and Item="+ItemId+";", true)==1){
    JOptionPane.showMessageDialog(null, "Gagal menambah !"+
     "\nData barang sudah ada di dalam daftar barang keluar !");
    break;
   }
   
   IFV.FMessage.showMessage("Gagal menambah (mungkin dikarenakan inputan "+
    "kuantitas barang menghasilkan stok akhir yang bernilai minus).", PCore.vectObj(
    "Lanjut selesaikan penambahan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user saat ini)",
    "Lanjut selesaikan penambahan (brg yg error ditandai 'Mismatch Stok' dgn otoritas user lain)"
    ), 0);
   if(IFV.FMessage.DialogResult==0){break;}
   
   if(!signItemsWithMissmatch(IFV.FMessage.Resolution, PCore.toMultiRows(ItemId), 0, PCore.primArr(0))){break;}
  }while(bool);
  
  if(success){
   NewRow=new Object[TableMdlItemOutColsName.length];
   NewRow[0]=ItemId;
   NewRow[1]=IFV.FTransItemModify.ItemInfo.Name;
   NewRow[2]=PMyShop.genTransItemName(IFV.FTransItemModify.ItemInfo.Name, IFV.FTransItemModify.TransItemComment);
   NewRow[3]=IFV.FTransItemModify.Qty;
   NewRow[4]=IFV.FTransItemModify.ItemInfo.StockUnitName;
   NewRow[5]=IFV.FTransItemModify.PriceTotal;
   NewRow[6]=IFV.FTransItemModify.PriceTotal/IFV.FTransItemModify.Qty;
   NewRow[7]=IFV.FTransItemModify.TransItemComment;
   NewRow[8]=IFV.FTransItemModify.ItemInfo.PictureFile;
   NewRow[9]=IFV.FTransItemModify.ItemInfo.CategoryName;
   NewRow[10]=IFV.FTransItemModify.ItemInfo.BuyPriceEstimation;
   BasicPriceTotal=IFV.FTransItemModify.Qty*IFV.FTransItemModify.ItemInfo.BuyPriceEstimation;
   NewRow[11]=BasicPriceTotal;
   
   if(!IsCategorized){FindColumn=1;}else{FindColumn=9;}
   FindName=PCore.objString(NewRow[FindColumn], null);
   insertpos=PGUI.findInsertPos(TableMdlOut, FindColumn, FindName, false, true, true);
   TableMdlOut.insert(insertpos, NewRow); Tbl_Out.changeSelection(insertpos, 0, false, false); onSelectedRowOutChanged(true);
   refreshItemCount(TF_OutCount, TableMdlOut);
   TIOut=true; TIOutClear=false; TIRequeryAll=false;

   updateTransItemOutPrice(row, false, IFV.FTransItemModify.PriceTotal, true);
   updateTransItemOutBasicPrice(row, false, BasicPriceTotal, true);
  }
 }//GEN-LAST:event_Btn_OutAddActionPerformed

 private void Btn_OutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutEditActionPerformed
  editItems(false);
 }//GEN-LAST:event_Btn_OutEditActionPerformed

 private void Btn_OutCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutCancelActionPerformed
  int[] rows=Tbl_Out.getSelectedRows();
  int rowTrans=Tbl_Trans.getSelectedRow();
  int temp;
  long Id;
  int removedcount;
  double PriceTot, BasicPriceTot;
  boolean[] IsRemove;
  double dbl;
  String msg=null;
  do{
   if(rowTrans==-1 || rows.length==0){break;}
   
   if(JOptionPane.showConfirmDialog(null, "Batalkan "+rows.length+" barang yang dipilih ?",
    "Konfirmasi Pembatalan Barang Keluar", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){break;}
   
   IsRemove=PCore.newBooleanArray(rows.length, false);
   temp=0;
   Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(rowTrans)[0];
   removedcount=0;
   PriceTot=0;
   BasicPriceTot=0;
   do{
    if(PMyShop.cancelATransactionItem(IFV.Stm, wIsPreTrans, false, Id,
     (Long)TableMdlOut.Mdl.Rows.elementAt(rows[temp])[0])==true){
     removedcount=removedcount+1;
     dbl=(Double)TableMdlOut.Mdl.Rows.elementAt(rows[temp])[5];
     if(dbl>0){PriceTot=PriceTot+dbl;}
     dbl=(Double)TableMdlOut.Mdl.Rows.elementAt(rows[temp])[11];
     if(dbl>0){BasicPriceTot=BasicPriceTot+dbl;}
     IsRemove[temp]=true;
    }

    temp=temp+1;
   }while(temp!=rows.length);
   
   if(removedcount!=rows.length){
    msg="Gagal membatalkan "+(rows.length-removedcount)+" data :\n"+
     PText.toStringWithQuote(TableMdlOut.Mdl.Rows, PGUI.getPickedRows(rows, IsRemove, false), "\n",
     PCore.primArr(1, 0), PCore.primArr(false, false), "> ", ".", ", ", "", "", false);
   }
   if(removedcount!=0){
    updateTransItemOutPrice(rowTrans, TableMdlOut.Mdl.Rows.size()==removedcount, PriceTot, false);
    updateTransItemOutBasicPrice(rowTrans, TableMdlOut.Mdl.Rows.size()==removedcount, BasicPriceTot, false);
    TableMdlOut.remove(rows, IsRemove);
    onSelectedRowOutChanged(true);
    refreshItemCount(TF_OutCount, TableMdlOut);
   }
   if(msg!=null){IFV.FMessage.showMessage(msg);}
  }while(false);
 }//GEN-LAST:event_Btn_OutCancelActionPerformed

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   
   Btn_Report.setVisible(wIsViewMode);
   CmB_ReportType.setVisible(wIsViewMode);
   Btn_TransChoose.setVisible(!wIsViewMode);
   Lbl_MultipleSelection.setVisible(!wIsViewMode && wAllowMultipleSelection);
   
   if(!wAllowMultipleSelection){Tbl_Trans.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);}
   else{Tbl_Trans.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);}
   
   if(wIsViewMode){setTitle("Lihat "+TransName+" ( {Esc} Utk Keluar )");}
   else{setTitle("Pilih "+TransName+" ( {Esc} Utk Keluar )");}
   
   initPrivGUIShow();
   
   onTabbedPaneChanged();
   
   TF_QId.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  if(!wIsViewMode){DialogResult=0;}
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_QIdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QIdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QIdHelpMouseClicked

 private void Btn_ReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ReportActionPerformed
  switch(CmB_ReportType.getSelectedIndex()){
   case 0 : printReport(); break;
   case 1 : printReceipt(); break;
   case 2 : printCSV(); break;
  }
 }//GEN-LAST:event_Btn_ReportActionPerformed

 private void Btn_FindItemOutBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemOutBefActionPerformed
  findItemOut(2);
 }//GEN-LAST:event_Btn_FindItemOutBefActionPerformed

 private void Btn_FindItemOutNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemOutNextActionPerformed
  findItemOut(1);
 }//GEN-LAST:event_Btn_FindItemOutNextActionPerformed

 private void Btn_FindItemInBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemInBefActionPerformed
  findItemIn(2);
 }//GEN-LAST:event_Btn_FindItemInBefActionPerformed

 private void Btn_FindItemInNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindItemInNextActionPerformed
  findItemIn(1);
 }//GEN-LAST:event_Btn_FindItemInNextActionPerformed

 private void TF_FindItemInKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindItemInKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FindItemIn, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_In)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_FindItemIn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemInBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindItemInNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindItemInKeyPressed

 private void TF_FindItemOutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindItemOutKeyPressed
  int consumed=PNav.onKey_TF(this, TF_FindItemOut, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Out)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_FindItemOut)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindItemOutBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: Btn_FindItemOutNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindItemOutKeyPressed

 private void Btn_TempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListAddActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(TableMdlTrans, Tbl_Trans.getSelectedRows(), 0), true);
 }//GEN-LAST:event_Btn_TempListAddActionPerformed

 private void Btn_TempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListRemoveActionPerformed
  fillTempList(PGUI.getIdsFromSelectedRows(TableMdlTrans, Tbl_Trans.getSelectedRows(), 0), false);
 }//GEN-LAST:event_Btn_TempListRemoveActionPerformed

 private void Btn_TempListSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListSaveActionPerformed
  File f;
  String fstr;
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION){return;}
   
  f=IFV.FileChooser.getSelectedFile();
  if(PText.checkInput(f.getName(), false, 0, 42, 4, 4, 0)==false){
   JOptionPane.showMessageDialog(null, "Masukan nama file belum benar !\n"+PText.getInputInfo(false, 0, 42, 4, 4, 0, false));
   return;
  }
  try{
   fstr=f.getCanonicalPath();
   if(PFile.compareIgnoreCaseExtension(fstr, "report")==false){
    f=new File(fstr+".report");
   }
  }
  catch(Exception E){
   JOptionPane.showMessageDialog(null, "Gagal memperoleh Canonical File Path !");
   return;
  }
  if(PEtc.saveIdToFile(TempList.getElements(), f, false,
   IFV.FSplashScreen, true, this, "Menulis Data DaftarKu")==false){
   JOptionPane.showMessageDialog(null, "Gagal menyimpan data report ke file !");
  }
 }//GEN-LAST:event_Btn_TempListSaveActionPerformed

 private void Btn_TempListLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListLoadActionPerformed
  File f;
  long[] tlist;
  IFV.FileChooser.setFileFilter(IFV.ReportFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showDialog(this, "Load")!=JFileChooser.APPROVE_OPTION){return;}
  f=IFV.FileChooser.getSelectedFile();
  if(PFile.compareIgnoreCaseExtension(f.getName(), "report")==false){
   JOptionPane.showMessageDialog(null, "Tidak dapat melanjutkan operasi!\n"+
    "Ekstensi file harus '.report'.");
   return;
  }
  tlist=PEtc.loadIdFromFile(f, false,
   IFV.FSplashScreen, true, this, "Membaca Data DaftarKu");
  if(tlist==null){
   JOptionPane.showMessageDialog(null, "Gagal membaca data report dari file !");
   return;
  }
  clearTempList();
  fillTempList(tlist, true);
 }//GEN-LAST:event_Btn_TempListLoadActionPerformed

 private void Lbl_QCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QCommentHelpMouseClicked

 private void TF_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QCommentKeyPressed
  PNav.onKey_Query_TF(this, CB_QComment, TF_QComment, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QCashComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QComment)));
 }//GEN-LAST:event_TF_QCommentKeyPressed

 private void Btn_QSalesmanAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSalesmanAddActionPerformed
  Object[] NewRow;
  int count, temp;
  
  
  IFV.FSubject.wMode=1;
  IFV.FSubject.wDialogWithFItem=false;
  IFV.FSubject.wAllowMultipleSelection=true;
  
  if(IFV.FSubject.showForm()==false){return;}
  if(IFV.FSubject.DialogResult==1){
   count=IFV.FSubject.ChoosedId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=IFV.FSubject.ChoosedId[temp];
    NewRow[1]=IFV.FSubject.ChoosedName[temp];
    ListMdlQSalesman.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QSalesmanAddActionPerformed

 private void Btn_QSalesmanRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QSalesmanRemoveActionPerformed
  ListMdlQSalesman.remove(List_QSalesman.getSelectedIndices());
 }//GEN-LAST:event_Btn_QSalesmanRemoveActionPerformed

 private void Btn_PaymentOutAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentOutAddActionPerformed
  int row;
  Object[] NewRow;
  int Enumeration;
  int insertpos;
  do{
   row=Tbl_Trans.getSelectedRow();
   if(row==-1){break;}
   
   IFV.FTransPaymentModify.wMode=0;
   
   if(IFV.FTransPaymentModify.showForm()==false){return;}
   if(IFV.FTransPaymentModify.DialogResult!=1){break;}
   
   Enumeration=PMyShop.addATransactionPayment(IFV.Stm, wIsPreTrans, false, (Long)TableMdlTrans.Mdl.Rows.elementAt(row)[0],
    IFV.FTransPaymentModify.PayDate, IFV.FTransPaymentModify.CashId, IFV.FTransPaymentModify.Price, IFV.FTransPaymentModify.Comment);
   if(Enumeration==-1){
    JOptionPane.showMessageDialog(null, "Gagal menambah data pembayaran keluar !");
    break;
   }
   
   NewRow=new Object[6];
   NewRow[0]=Enumeration;
   NewRow[1]=IFV.FTransPaymentModify.PayDate;
   NewRow[2]=PCore.subtituteLong(IFV.FTransPaymentModify.CashId, -1, IFV.FTransPaymentModify.CashId, null);
   NewRow[3]=PCore.subtituteLong(IFV.FTransPaymentModify.CashId, -1, IFV.FTransPaymentModify.CashName, null);
   NewRow[4]=IFV.FTransPaymentModify.Price;
   NewRow[5]=PText.getString(IFV.FTransPaymentModify.Comment, null, true);
   insertpos=TableMdlPaymentOut.Mdl.Rows.size();
   TableMdlPaymentOut.insert(insertpos, NewRow); Tbl_PaymentOut.changeSelection(insertpos, 0, false, false); onSelectedRowPaymentOutChanged(true);
   refreshPaymentCount(TF_PayOutCount, TableMdlPaymentOut);
   TIPayOut=true; TIPayOutClear=false; TIRequeryAll=false;
   
   updateTransPaymentOutPrice(row, false, IFV.FTransPaymentModify.Price, true);
  }while(false);
 }//GEN-LAST:event_Btn_PaymentOutAddActionPerformed

 private void Btn_PaymentOutEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentOutEditActionPerformed
  editPayments(false);
 }//GEN-LAST:event_Btn_PaymentOutEditActionPerformed

 private void Btn_PaymentOutCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentOutCancelActionPerformed
  int[] rows=Tbl_PaymentOut.getSelectedRows();
  int rowTrans=Tbl_Trans.getSelectedRow();
  int temp;
  long Id;
  int removedcount;
  double PriceTot;
  boolean[] IsRemove;
  double dbl;
  do{
   if(rowTrans==-1 || rows.length==0){break;}
   
   if(JOptionPane.showConfirmDialog(null, "Batalkan "+rows.length+" data pembayaran keluar yang dipilih ?",
    "Konfirmasi Pembatalan Data Pembayaran Keluar", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){break;}
   
   IsRemove=PCore.newBooleanArray(rows.length, false);
   temp=0;
   Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(rowTrans)[0];
   removedcount=0;
   PriceTot=0;
   do{
    if(PMyShop.cancelATransactionPayment(IFV.Stm, wIsPreTrans, false, Id,
     (Integer)TableMdlPaymentOut.Mdl.Rows.elementAt(rows[temp])[0])==true){
     removedcount=removedcount+1;
     dbl=(Double)TableMdlPaymentOut.Mdl.Rows.elementAt(rows[temp])[4];
     if(dbl>0){PriceTot=PriceTot+dbl;}
     IsRemove[temp]=true;
    }

    temp=temp+1;
   }while(temp!=rows.length);
   
   if(removedcount!=rows.length){
    JOptionPane.showMessageDialog(null, "Gagal membatalkan "+(rows.length-removedcount)+" data !");
   } 
   if(removedcount!=0){
    updateTransPaymentOutPrice(rowTrans, TableMdlPaymentOut.Mdl.Rows.size()==removedcount, PriceTot, false);
    TableMdlPaymentOut.remove(rows, IsRemove);
    onSelectedRowPaymentOutChanged(true);
    refreshPaymentCount(TF_PayOutCount, TableMdlPaymentOut);
   }
  }while(false);
 }//GEN-LAST:event_Btn_PaymentOutCancelActionPerformed

 private void Btn_PaymentInAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentInAddActionPerformed
  int row;
  Object[] NewRow;
  int Enumeration;
  int insertpos;
  do{
   row=Tbl_Trans.getSelectedRow();
   if(row==-1){break;}
   
   IFV.FTransPaymentModify.wMode=0;
   
   if(IFV.FTransPaymentModify.showForm()==false){return;}
   if(IFV.FTransPaymentModify.DialogResult!=1){break;}
   
   Enumeration=PMyShop.addATransactionPayment(IFV.Stm, wIsPreTrans, true, (Long)TableMdlTrans.Mdl.Rows.elementAt(row)[0],
    IFV.FTransPaymentModify.PayDate, IFV.FTransPaymentModify.CashId, IFV.FTransPaymentModify.Price, IFV.FTransPaymentModify.Comment);
   if(Enumeration==-1){
    JOptionPane.showMessageDialog(null, "Gagal menambah data pembayaran masuk !");
    break;
   }
   
   NewRow=new Object[6];
   NewRow[0]=Enumeration;
   NewRow[1]=IFV.FTransPaymentModify.PayDate;
   NewRow[2]=PCore.subtituteLong(IFV.FTransPaymentModify.CashId, -1, IFV.FTransPaymentModify.CashId, null);
   NewRow[3]=PCore.subtituteLong(IFV.FTransPaymentModify.CashId, -1, IFV.FTransPaymentModify.CashName, null);
   NewRow[4]=IFV.FTransPaymentModify.Price;
   NewRow[5]=PText.getString(IFV.FTransPaymentModify.Comment, null, true);
   insertpos=TableMdlPaymentIn.Mdl.Rows.size();
   TableMdlPaymentIn.insert(insertpos, NewRow); Tbl_PaymentIn.changeSelection(insertpos, 0, false, false); onSelectedRowPaymentInChanged(true);
   refreshPaymentCount(TF_PayInCount, TableMdlPaymentIn);
   TIPayIn=true; TIPayInClear=false; TIRequeryAll=false;
   
   updateTransPaymentInPrice(row, false, IFV.FTransPaymentModify.Price, true);
  }while(false);
 }//GEN-LAST:event_Btn_PaymentInAddActionPerformed

 private void Btn_PaymentInCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentInCancelActionPerformed
  int[] rows=Tbl_PaymentIn.getSelectedRows();
  int rowTrans=Tbl_Trans.getSelectedRow();
  int temp;
  long Id;
  int removedcount;
  double PriceTot;
  boolean[] IsRemove;
  double dbl;
  do{
   if(rowTrans==-1 || rows.length==0){break;}
   
   if(JOptionPane.showConfirmDialog(null, "Batalkan "+rows.length+" data pembayaran masuk yang dipilih ?",
    "Konfirmasi Pembatalan Data Pembayaran Masuk", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){break;}
   
   IsRemove=PCore.newBooleanArray(rows.length, false);
   temp=0;
   Id=(Long)TableMdlTrans.Mdl.Rows.elementAt(rowTrans)[0];
   removedcount=0;
   PriceTot=0;
   do{
    if(PMyShop.cancelATransactionPayment(IFV.Stm, wIsPreTrans, true, Id,
     (Integer)TableMdlPaymentIn.Mdl.Rows.elementAt(rows[temp])[0])==true){
     removedcount=removedcount+1;
     dbl=(Double)TableMdlPaymentIn.Mdl.Rows.elementAt(rows[temp])[4];
     if(dbl>0){PriceTot=PriceTot+dbl;}
     IsRemove[temp]=true;
    }

    temp=temp+1;
   }while(temp!=rows.length);
   
   if(removedcount!=rows.length){
    JOptionPane.showMessageDialog(null, "Gagal membatalkan "+(rows.length-removedcount)+" data !");
   } 
   if(removedcount!=0){
    updateTransPaymentInPrice(rowTrans, TableMdlPaymentIn.Mdl.Rows.size()==removedcount, PriceTot, false);
    TableMdlPaymentIn.remove(rows, IsRemove);
    onSelectedRowPaymentInChanged(true);
    refreshPaymentCount(TF_PayInCount, TableMdlPaymentIn);
   }
  }while(false);
 }//GEN-LAST:event_Btn_PaymentInCancelActionPerformed

 private void Btn_PaymentInEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentInEditActionPerformed
  editPayments(true);
 }//GEN-LAST:event_Btn_PaymentInEditActionPerformed

 private void Btn_QCashAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCashAddActionPerformed
  Object[] NewRow;
  int count, temp;
  IFV.FDataIdName.wMode=1;
  IFV.FDataIdName.wAllowMultipleSelection=true;
  IFV.FDataIdName.wByTableCode=true;
  IFV.FDataIdName.wTableCode=CApp.TblCash;
  IFV.FDataIdName.wUseCustomTitle=false;
  ;
  if(IFV.FDataIdName.showForm()==false){return;}
  if(IFV.FDataIdName.DialogResult==1){
   count=IFV.FDataIdName.DataId.length;
   temp=0;
   do{
    NewRow=new Object[2];
    NewRow[0]=(int)IFV.FDataIdName.DataId[temp];
    NewRow[1]=IFV.FDataIdName.DataName[temp];
    ListMdlQCash.append(NewRow);
    temp=temp+1;
   }while(temp!=count);
  }
 }//GEN-LAST:event_Btn_QCashAddActionPerformed

 private void Btn_QCashRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QCashRemoveActionPerformed
  ListMdlQCash.remove(List_QCash.getSelectedIndices());
 }//GEN-LAST:event_Btn_QCashRemoveActionPerformed

 private void TF_QIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QIdFocusGained
  LastFocusedCmpSearch=TF_QId;
  PGUI.text_SelectAll(TF_QId);
 }//GEN-LAST:event_TF_QIdFocusGained

 private void TF_QCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QCommentFocusGained
  LastFocusedCmpSearch=TF_QComment;
  PGUI.text_SelectAll(TF_QComment);
 }//GEN-LAST:event_TF_QCommentFocusGained

 private void Btn_FindBeforeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindBeforeActionPerformed
  findTransInTable(2);
 }//GEN-LAST:event_Btn_FindBeforeActionPerformed

 private void Btn_FindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_FindNextActionPerformed
  findTransInTable(1);
 }//GEN-LAST:event_Btn_FindNextActionPerformed

 private void TF_FindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_FindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_Find, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Trans)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_Find)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_FindBefore)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER : Btn_FindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_FindKeyPressed

 private void TF_TempListQuantityMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_TempListQuantityMouseClicked
  int DynamicTempList=0;
  
  do{
   if(SwingUtilities.isLeftMouseButton(evt)){DynamicTempList=1; break;}
   if(SwingUtilities.isRightMouseButton(evt)){DynamicTempList=2; break;}
   DynamicTempList=-1;
  }while(false);
  if(DynamicTempList==-1){return;}
  
  setLastQuery(0, "", "", false, "", false, DynamicTempList, false);
  fillTableTrans();
 }//GEN-LAST:event_TF_TempListQuantityMouseClicked

 private void CmB_ResultFilterSubsetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ResultFilterSubsetActionPerformed
  int temp=CmB_ResultFilterSubset.getSelectedIndex();
  if(LastResultFilterSubset==temp){return;}
  LastResultFilterSubset=temp;
  fillTableTrans();
 }//GEN-LAST:event_CmB_ResultFilterSubsetActionPerformed

 private void Btn_QueryRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_QueryRefreshActionPerformed
  fillTableTrans();
 }//GEN-LAST:event_Btn_QueryRefreshActionPerformed

 private void CB_ItemOutBasicSumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutBasicSumActionPerformed
  refreshItemOutBasicSum();
 }//GEN-LAST:event_CB_ItemOutBasicSumActionPerformed

 private void CmB_ViewModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CmB_ViewModeActionPerformed
  onSelectedRowViewModeChanged();
 }//GEN-LAST:event_CmB_ViewModeActionPerformed

 private void Btn_TempListClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TempListClearActionPerformed
  if(JOptionPane.showConfirmDialog(null, "Kosongkan data pada 'Daftarku' ?", "Konfirmasi Pengosongan Data Pada 'Daftarku'",
   JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){return;}
  clearTempList();
 }//GEN-LAST:event_Btn_TempListClearActionPerformed

 private void Btn_OutOtherOperationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutOtherOperationActionPerformed
  int[] rows=Tbl_Out.getSelectedRows();
  
  if(rows.length==0){return;}
  
  
  if(IFV.FTransItemOutOperation.showForm()==false){return;}
  if(IFV.FTransItemOutOperation.DialogResult!=1){return;}
  
  switch(IFV.FTransItemOutOperation.Operation){
   case 1 : changeItemPrice(false, TableMdlOut, rows, 0, 6, true); break;
   case 2 : labelAdd(TableMdlOut, rows, 0, 3); break;
   case 3 : addOrdItems(false, IFV.FTransItemOutOperation.OrderAddAlsoRemoveTransItems); break;
  }
 }//GEN-LAST:event_Btn_OutOtherOperationActionPerformed

 private void Btn_InOtherOperationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InOtherOperationActionPerformed
  int[] rows=Tbl_In.getSelectedRows();
  
  if(rows.length==0){return;}
  
  
  if(IFV.FTransItemInOperation.showForm()==false){return;}
  if(IFV.FTransItemInOperation.DialogResult!=1){return;}
  
  switch(IFV.FTransItemInOperation.Operation){
   case 1 : changeItemPrice(true, TableMdlIn, rows, 0, 6, true); break;
   case 2 : labelAdd(TableMdlIn, rows, 0, 3); break;
   case 3 : addOrdItems(true, IFV.FTransItemInOperation.OrderAddAlsoRemoveTransItems); break;
  }
 }//GEN-LAST:event_Btn_InOtherOperationActionPerformed

 private void Btn_InTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InTempListAddActionPerformed
  int[] rows=Tbl_In.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlIn.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_InTempListAddActionPerformed

 private void Btn_InTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InTempListRemoveActionPerformed
  int[] rows=Tbl_In.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlIn.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_InTempListRemoveActionPerformed

 private void Btn_OutTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutTempListAddActionPerformed
  int[] rows=Tbl_Out.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlOut.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_OutTempListAddActionPerformed

 private void Btn_OutTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutTempListRemoveActionPerformed
  int[] rows=Tbl_Out.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlOut.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_OutTempListRemoveActionPerformed

 private void Lbl_QItemPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QItemPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter2 >= Parameter1.\n"+PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_QItemPriceHelpMouseClicked

 private void Lbl_QPaymentPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QPaymentPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, "- Parameter2 >= Parameter1.\n"+PText.getInputInfo(false, 12, 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_QPaymentPriceHelpMouseClicked

 private void TF_QItemPrice1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemPrice1FocusGained
  LastFocusedCmpSearch=TF_QItemPrice1;
  PGUI.text_SelectAll(TF_QItemPrice1);
 }//GEN-LAST:event_TF_QItemPrice1FocusGained

 private void TF_QItemPrice2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QItemPrice2FocusGained
  LastFocusedCmpSearch=TF_QItemPrice2;
  PGUI.text_SelectAll(TF_QItemPrice2);
 }//GEN-LAST:event_TF_QItemPrice2FocusGained

 private void TF_QPaymentPrice1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QPaymentPrice1FocusGained
  LastFocusedCmpSearch=TF_QPaymentPrice1;
  PGUI.text_SelectAll(TF_QPaymentPrice1);
 }//GEN-LAST:event_TF_QPaymentPrice1FocusGained

 private void TF_QPaymentPrice2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QPaymentPrice2FocusGained
  LastFocusedCmpSearch=TF_QPaymentPrice2;
  PGUI.text_SelectAll(TF_QPaymentPrice2);
 }//GEN-LAST:event_TF_QPaymentPrice2FocusGained

 private void TF_QItemPrice1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemPrice1KeyPressed
  PNav.onKey_Query_TF1(this, CB_QItemPrice, TF_QItemPrice1, TF_QItemPrice2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QCashComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QPaymentPrice1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QItemPrice)));
 }//GEN-LAST:event_TF_QItemPrice1KeyPressed

 private void TF_QItemPrice2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QItemPrice2KeyPressed
  PNav.onKey_Query_TF2(this, CB_QItemPrice, TF_QItemPrice1, TF_QItemPrice2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QCashComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QPaymentPrice2)));
 }//GEN-LAST:event_TF_QItemPrice2KeyPressed

 private void TF_QPaymentPrice1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QPaymentPrice1KeyPressed
  PNav.onKey_Query_TF1(this, CB_QPaymentPrice, TF_QPaymentPrice1, TF_QPaymentPrice2, Btn_Query, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemPrice1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTransTypeAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QPaymentPrice)));
 }//GEN-LAST:event_TF_QPaymentPrice1KeyPressed

 private void TF_QPaymentPrice2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QPaymentPrice2KeyPressed
  PNav.onKey_Query_TF2(this, CB_QPaymentPrice, TF_QPaymentPrice1, TF_QPaymentPrice2, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QItemPrice2)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTransTypeAdd)));
 }//GEN-LAST:event_TF_QPaymentPrice2KeyPressed

 private void Btn_PaymentInPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentInPrintActionPerformed
  printPayment(true);
 }//GEN-LAST:event_Btn_PaymentInPrintActionPerformed

 private void Btn_PaymentOutPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PaymentOutPrintActionPerformed
  printPayment(false);
 }//GEN-LAST:event_Btn_PaymentOutPrintActionPerformed

 private void Btn_InCheckAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InCheckAddActionPerformed
  checkItems(true, true);
 }//GEN-LAST:event_Btn_InCheckAddActionPerformed

 private void Btn_InCheckRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_InCheckRemoveActionPerformed
  checkItems(true, false);
 }//GEN-LAST:event_Btn_InCheckRemoveActionPerformed

 private void Btn_OutCheckAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutCheckAddActionPerformed
  checkItems(false, true);
 }//GEN-LAST:event_Btn_OutCheckAddActionPerformed

 private void Btn_OutCheckRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OutCheckRemoveActionPerformed
  checkItems(false, false);
 }//GEN-LAST:event_Btn_OutCheckRemoveActionPerformed

 private void TF_OrdFindKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_OrdFindKeyPressed
  int consumed=PNav.onKey_TF(this, TF_OrdFind, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Tbl_Ord)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_OrdFind)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_OrdFindBef)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER: Btn_OrdFindNextActionPerformed(null); break;
  }
 }//GEN-LAST:event_TF_OrdFindKeyPressed

 private void Btn_OrdRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdRefreshActionPerformed
  fillListOrd(0);
 }//GEN-LAST:event_Btn_OrdRefreshActionPerformed

 private void Btn_OrdAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdAddActionPerformed
  F_OrderModify fm=IFV.FOrderModify;
  Vector<Object[]> DataOrd;
  long ItemId;
  
  fm.wMode=0;
  if(fm.showForm()==false){return;}
  if(fm.DialogResult!=1){return;}
  
  ItemId=fm.ItemInfo.PrimaryId;
  DataOrd=new Vector(); DataOrd.addElement(PCore.objArrVariant(ItemId, fm.Qty));
  if(addOrdItems(null, DataOrd, false, -1, false, false, PCore.primArr(ItemId))==false){
   JOptionPane.showMessageDialog(null, "Gagal menambah data order : Terjadi error ketika melakukan operasi !");
   return;
  }
 }//GEN-LAST:event_Btn_OrdAddActionPerformed

 private void Btn_OrdEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdEditActionPerformed
  F_OrderModify fm1=IFV.FOrderModify;
  F_OrderModifyMulti fm2=IFV.FOrderModifyMulti;
  int[] RowsOrd=Tbl_Ord.getSelectedRows();
  long[] Ids;
  double OrderQty=0;
  
  if(RowsOrd.length==0){return;}
  
  Ids=TableMdlOrd.getIds(0, RowsOrd);
  
  if(RowsOrd.length==1){
   fm1.wMode=1;
   fm1.wItemId=Ids[0];
   if(fm1.showForm()==false){return;}
   if(fm1.DialogResult!=1){return;}
   
   OrderQty=fm1.Qty;
  }
  else{
   fm2.wDataCount=Ids.length;
   if(fm2.showForm()==false){return;}
   if(fm2.DialogResult!=1){return;}
   
   OrderQty=fm2.Quantity;
  }
  
  editOrders(RowsOrd, OrderQty);
 }//GEN-LAST:event_Btn_OrdEditActionPerformed

 private void Btn_OrdRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdRemoveActionPerformed
  int[] RowsOrd=Tbl_Ord.getSelectedRows();
  long[] Ids;
  double PriceOld;
  
  if(RowsOrd.length==0){return;}
  
  if(JOptionPane.showConfirmDialog(null, "Hapus "+RowsOrd.length+" data order yg dipilih pd tabel ?",
   "Konfirmasi Penghapusan Data Order", JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION){
   return;
  }
  
  Ids=TableMdlOrd.getIds(0, RowsOrd);
  
  if(!PMyShop.updateOrder(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", false)+IFV.OrderLock, 10, Ids, true, 1, -1)){
   JOptionPane.showMessageDialog(null, "Gagal menambah data order : Terjadi error ketika melakukan operasi !");
   return;
  }
  
  PriceOld=(Double)PGUI.sumColumns(TableMdlOrd, PCore.primArr(6), RowsOrd)[0];
  
  TableMdlOrd.remove(RowsOrd);
  
  refreshOrdCount(); updateOrdPriceEst(PriceOld, false);
  onSelectedRowOrdChanged(true);
 }//GEN-LAST:event_Btn_OrdRemoveActionPerformed

 private void Btn_OrdFindBefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdFindBefActionPerformed
  findOrd(2);
 }//GEN-LAST:event_Btn_OrdFindBefActionPerformed

 private void Btn_OrdFindNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdFindNextActionPerformed
  findOrd(1);
 }//GEN-LAST:event_Btn_OrdFindNextActionPerformed

 private void Btn_OrdTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdTempListAddActionPerformed
  int[] rows=Tbl_Ord.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlOrd.getIds(0, rows), true);
 }//GEN-LAST:event_Btn_OrdTempListAddActionPerformed

 private void Btn_OrdTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdTempListRemoveActionPerformed
  int[] rows=Tbl_Ord.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FItem.fillTempList(TableMdlOrd.getIds(0, rows), false);
 }//GEN-LAST:event_Btn_OrdTempListRemoveActionPerformed

 private void Btn_OrdMoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OrdMoveActionPerformed
  ordMove();
 }//GEN-LAST:event_Btn_OrdMoveActionPerformed

 private void Btn_TransNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransNewActionPerformed
  F_TransModify fm=IFV.FTransModify;
  boolean success;
  Object[] objs;
  int insertpos;
  boolean found;
  
  if(!PGUI.isEnabled(Btn_TransNew)){return;}
  
  fm.wMode=1;
  fm.wIsPreTrans=wIsPreTrans;
  if(!fm.showForm()){return;}
  if(fm.DialogResult!=1){return;}
  
  success=true;
  try{
   IFV.Stm.executeUpdate("call "+DbTable+"EditNotImportant("+
    fm.TransId+", "+PDatabase.dateToSQLStringFormat(fm.TransDate)+", "+
    PText.getString(fm.TransTypeId, CCore.vNull, -1, false)+", "+
    PText.getString(fm.CashOutId, CCore.vNull, -1, false)+", "+PText.getString(fm.CashInId, CCore.vNull, -1, false)+", "+
    PText.getString(fm.TransSubjectId, CCore.vNull, -1, false)+", "+PText.getString(fm.TransSalesmanId, CCore.vNull, -1, false)+", "+
    PText.getString(fm.TransCreditDays, CCore.vNull, -1, false)+", "+
    PDatabase.dateToSQLStringFormat(fm.TransRepayPeriodStart)+", "+PDatabase.dateToSQLStringFormat(fm.TransRepayPeriodEnd)+", "+
    PText.getString(fm.TransImportant, CCore.vTrue, CCore.vFalse)+", "+
    PText.getStringWithQuote(PSql.norm(fm.TransComment), CCore.vNull, '\'', true)+", "+
    PText.getStringWithQuote(PSql.norm(fm.TransInfoIdExternal), CCore.vNull, '\'', true)+", "+
    PText.getStringWithQuote(PSql.norm(fm.CashOutComment), CCore.vNull, '\'', true)+", "+
    PText.getStringWithQuote(PSql.norm(fm.CashInComment), CCore.vNull, '\'', true)+");");
  }
  catch(Exception E){success=false;}
  if(!success){
   JOptionPane.showMessageDialog(null, "Gagal menambah data "+TransName+" !");
   if(PDatabase.removeTransactionId(IFV.Stm, PText.getString(IFV.CurrentDatabase, "", true)+DbAppLock, 10, wIsPreTrans, fm.TransId, true)!=0){
    JOptionPane.showMessageDialog(null, "Gagal menghapus Id "+TransName+" baru !"+
     "\nSilahkan menghapus Id "+TransName+" tersebut secara manual !");
   }
   return;
  }
  
  objs=new Object[21];
  objs[0]=fm.TransId;
  objs[1]=PText.getString(fm.TransInfoIdExternal, null, true);
  objs[2]=fm.TransImportant;
  objs[3]=PText.getString(fm.TransTypeId, -1, fm.TransTypeName, null);
  objs[4]=fm.TransDate;
  objs[5]=PCore.subtituteLong(fm.TransCreditDays, -1, PDate.calculateDateByDay(fm.TransDate, fm.TransCreditDays, 1), null); 
  objs[6]=fm.TransRepayPeriodStart;
  objs[7]=fm.TransRepayPeriodEnd;
  objs[8]=PCore.subtituteLong(fm.TransSubjectId, -1, fm.TransSubjectId, null);
  objs[9]=PText.getString(fm.TransSubjectId, -1, fm.TransSubjectName, null);
  objs[10]=PCore.subtituteLong(fm.TransSalesmanId, -1, fm.TransSalesmanId, null);
  objs[11]=PText.getString(fm.TransSalesmanId, -1, fm.TransSalesmanName, null);
  objs[12]=PText.getString(fm.CashOutId, -1, fm.CashOutName, null);
  objs[13]=PText.getString(fm.CashOutComment, null, true);
  objs[14]=PText.getString(fm.CashInId, -1, fm.CashInName, null);
  objs[15]=PText.getString(fm.CashInComment, null, true);
  objs[ColTransPriceItemIn]=null;
  objs[ColTransPriceItemOut]=null;
  objs[ColTransPriceItemOutBasic]=null;
  objs[ColTransPricePayOut]=null;
  objs[ColTransPricePayIn]=null;
  
  insertpos=TableMdlTrans.Mdl.Rows.size();
  TableMdlTrans.insert(insertpos, objs); refreshQueryCount();
  found=TempList.checkElement(fm.TransId)>=0;
  TableMdlTrans.setChecked(insertpos, found); updateQueryTempListCount();
  
  updateItemInSum(PCore.objDouble(objs[ColTransPriceItemIn], 0D), true);
  updateItemOutSum(PCore.objDouble(objs[ColTransPriceItemOut], 0D), true);
  updateItemOutBasicSum(PCore.objDouble(objs[ColTransPriceItemOutBasic], 0D), true);
  updatePaymentOutSum(PCore.objDouble(objs[ColTransPricePayOut], 0D), true);
  updatePaymentInSum(PCore.objDouble(objs[ColTransPricePayIn], 0D), true);
  
  Tbl_Trans.changeSelection(insertpos, 0, false, false); onSelectedRowTransChanged(true);
 }//GEN-LAST:event_Btn_TransNewActionPerformed

 private void Tbl_OrdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_OrdKeyPressed
  switch(evt.getKeyCode()){
   
  }
 }//GEN-LAST:event_Tbl_OrdKeyPressed

 private void Tbl_OrdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_OrdKeyReleased
  onSelectedRowOrdChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Ord, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_OrdFind)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_RIGHT:
    if(Tbl_Ord.OnKeyPress_PosCol>=Tbl_Ord.getColumnCount()-1){
     if(!TableMdlTrans.Mdl.Rows.isEmpty()){
      if(Tbl_Trans.getSelectedRow()==-1){Tbl_Trans.changeSelection(0, 0, false, false); onSelectedRowTransChanged(false);}
      Tbl_Trans.requestFocusInWindow();
     }
    }
    break;
  }
 }//GEN-LAST:event_Tbl_OrdKeyReleased

 private void Tbl_OrdMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_OrdMouseReleased
  onSelectedRowOrdChanged(false);
 }//GEN-LAST:event_Tbl_OrdMouseReleased

 private void Lbl_QCashCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_QCashCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 0, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_QCashCommentHelpMouseClicked

 private void TF_QCashCommentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QCashCommentFocusGained
  LastFocusedCmpSearch=TF_QCashComment;
  PGUI.text_SelectAll(TF_QCashComment);
 }//GEN-LAST:event_TF_QCashCommentFocusGained

 private void TF_QCashCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QCashCommentKeyPressed
  PNav.onKey_Query_TF(this, CB_QCashComment, TF_QCashComment, Btn_Query, AbstFocusQueryResult, true, true, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QItemPrice1)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QCashComment)));
 }//GEN-LAST:event_TF_QCashCommentKeyPressed

 private void Tbl_InKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_InKeyReleased
  onSelectedRowInChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_In, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FindItemIn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_InCheckAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_InCheckRemoveActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_Tbl_InKeyReleased

 private void Tbl_InMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_InMouseReleased
  onSelectedRowInChanged(false);
 }//GEN-LAST:event_Tbl_InMouseReleased

 private void Tbl_OutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_OutKeyReleased
  onSelectedRowOutChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Out, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_FindItemOut)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_OutCheckAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_OutCheckRemoveActionPerformed(null); evt.consume(); break;
  }
 }//GEN-LAST:event_Tbl_OutKeyReleased

 private void Tbl_OutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_OutMouseReleased
  onSelectedRowOutChanged(false);
 }//GEN-LAST:event_Tbl_OutMouseReleased

 private void Tbl_TransMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_TransMouseReleased
  onSelectedRowTransChanged(false);
 }//GEN-LAST:event_Tbl_TransMouseReleased

 private void Tbl_TransKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransKeyReleased
  onSelectedRowTransChanged(false);
  
  int consumed=PNav.onKey_Tbl(this, Tbl_Trans, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Find)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
  if(consumed==CNav.Ret_Consumed){return;}
  
  switch(evt.getKeyCode()){
   case KeyEvent.VK_F9 : Btn_TempListAddActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_F10 : Btn_TempListRemoveActionPerformed(null); evt.consume(); break;
   case KeyEvent.VK_LEFT:
    if(Tbl_Trans.OnKeyPress_PosCol<=0){
     switch(TabbedPane.getSelectedIndex()){
      case 0 : focusQuery(); break;
      case 6 :
       if(!TableMdlOrd.Mdl.Rows.isEmpty()){
        if(Tbl_Ord.getSelectedRow()==-1){Tbl_Ord.changeSelection(0, Tbl_Ord.getColumnCount()-1, false, false); onSelectedRowOrdChanged(false);}
        Tbl_Ord.requestFocusInWindow();
       }
       break;
     }
    }
    break;
  }
 }//GEN-LAST:event_Tbl_TransKeyReleased

 private void Tbl_TransKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_TransKeyPressed
  switch(evt.getKeyCode()){
   case KeyEvent.VK_ENTER:
    if(!wIsViewMode && !Tbl_Trans.isEditing()){
     if(Tbl_Trans.getSelectedRows().length!=0){evt.consume(); Btn_TransChooseActionPerformed(null);}
    }
    break;
  }
 }//GEN-LAST:event_Tbl_TransKeyPressed

 private void Btn_MultipleTransImportantAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleTransImportantAddActionPerformed
  setTransImportant(true);
 }//GEN-LAST:event_Btn_MultipleTransImportantAddActionPerformed

 private void Btn_MultipleTransImportantRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_MultipleTransImportantRemoveActionPerformed
  setTransImportant(false);
 }//GEN-LAST:event_Btn_MultipleTransImportantRemoveActionPerformed

 private void Pnl_OrdPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_OrdPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Ord, TableMdlOrd, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_OrdPreviewMouseClicked

 private void Pnl_ItemOutPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemOutPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Out, TableMdlOut, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemOutPreviewMouseClicked

 private void Pnl_ItemInPreviewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Pnl_ItemInPreviewMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_In, TableMdlIn, 0, IFV.FItemPreview);
 }//GEN-LAST:event_Pnl_ItemInPreviewMouseClicked

 private void TF_DetSubjectMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_DetSubjectMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Trans, TableMdlTrans, 8, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_DetSubjectMouseClicked

 private void TF_DetSalesmanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_DetSalesmanMouseClicked
  PMyShop.viewFormInfo_FromTable(Tbl_Trans, TableMdlTrans, 10, IFV.FSubjectPreview);
 }//GEN-LAST:event_TF_DetSalesmanMouseClicked

 private void Btn_TransSubjectTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSubjectTempListAddActionPerformed
  int[] rows=Tbl_Trans.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTrans.getIds(8, rows), true);
 }//GEN-LAST:event_Btn_TransSubjectTempListAddActionPerformed

 private void Btn_TransSubjectTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSubjectTempListRemoveActionPerformed
  int[] rows=Tbl_Trans.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTrans.getIds(8, rows), false);
 }//GEN-LAST:event_Btn_TransSubjectTempListRemoveActionPerformed

 private void Btn_TransSubjectInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSubjectInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_Trans, TableMdlTrans, 8, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransSubjectInfoActionPerformed

 private void Btn_TransSalesmanTempListAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSalesmanTempListAddActionPerformed
  int[] rows=Tbl_Trans.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTrans.getIds(10, rows), true);
 }//GEN-LAST:event_Btn_TransSalesmanTempListAddActionPerformed

 private void Btn_TransSalesmanTempListRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSalesmanTempListRemoveActionPerformed
  int[] rows=Tbl_Trans.getSelectedRows();
  
  if(rows.length==0){return;}
  
  IFV.FSubject.fillTempList(TableMdlTrans.getIds(10, rows), false);
 }//GEN-LAST:event_Btn_TransSalesmanTempListRemoveActionPerformed

 private void Btn_TransSalesmanInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TransSalesmanInfoActionPerformed
  PMyShop.viewFormInfo_FromTable(Tbl_Trans, TableMdlTrans, 10, IFV.FSubjectPreview);
 }//GEN-LAST:event_Btn_TransSalesmanInfoActionPerformed

 private void Tbl_PaymentOutKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_PaymentOutKeyReleased
  onSelectedRowPaymentOutChanged(false);
 }//GEN-LAST:event_Tbl_PaymentOutKeyReleased

 private void Tbl_PaymentOutMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_PaymentOutMouseReleased
  onSelectedRowPaymentOutChanged(false);
 }//GEN-LAST:event_Tbl_PaymentOutMouseReleased

 private void Tbl_PaymentInKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_PaymentInKeyReleased
  onSelectedRowPaymentInChanged(false);
 }//GEN-LAST:event_Tbl_PaymentInKeyReleased

 private void Tbl_PaymentInMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tbl_PaymentInMouseReleased
  onSelectedRowPaymentInChanged(false);
 }//GEN-LAST:event_Tbl_PaymentInMouseReleased

 private void Btn_QueryKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QueryKeyPressed
  PNav.onKey_Btn(this, Btn_Query, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QImportant)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QueryKeyPressed

 private void CB_QImportantKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QImportantKeyPressed
  PNav.onKey_CB(this, CB_QImportant, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_QImportantYes)));
 }//GEN-LAST:event_CB_QImportantKeyPressed

 private void RB_QImportantYesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_QImportantYesKeyPressed
  PNav.onKey_RB(this, RB_QImportantYes, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QImportant)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_QImportantNo)));
 }//GEN-LAST:event_RB_QImportantYesKeyPressed

 private void RB_QImportantNoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_QImportantNoKeyPressed
  PNav.onKey_RB(this, RB_QImportantNo, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_Query)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CmB_QCheck)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_QImportantYes)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_RB_QImportantNoKeyPressed

 private void CB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCheckKeyPressed
  PNav.onKey_CB(this, CB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QImportant)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QDate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCheck)));
 }//GEN-LAST:event_CB_QCheckKeyPressed

 private void CmB_QCheckKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCheckKeyPressed
  PNav.onKey_CmB(this, CmB_QCheck, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCheck)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QCheckKeyPressed

 private void CB_QDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QDateKeyPressed
  PNav.onKey_CB(this, CB_QDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QBillDate)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QDateStartYear)));
 }//GEN-LAST:event_CB_QDateKeyPressed

 private void TF_QDateStartYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QDateStartYearKeyPressed
  PNav.onKey_TF(this, TF_QDateStartYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QBillDateStartYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_QDateStartMonth)));
 }//GEN-LAST:event_TF_QDateStartYearKeyPressed

 private void ComboBox_QDateStartMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_QDateStartMonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_QDateStartMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QDateStartYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_QDateStartDay)));
 }//GEN-LAST:event_ComboBox_QDateStartMonthKeyPressed

 private void ComboBox_QDateStartDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_QDateStartDayKeyPressed
  PNav.onKey_CmB(this, ComboBox_QDateStartDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_QDateStartMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QDateEndYear)));
 }//GEN-LAST:event_ComboBox_QDateStartDayKeyPressed

 private void TF_QDateEndYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QDateEndYearKeyPressed
  PNav.onKey_TF(this, TF_QDateEndYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CmB_QCheck)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QBillDateEndYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_QDateStartDay)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_QDateEndMonth)));
 }//GEN-LAST:event_TF_QDateEndYearKeyPressed

 private void ComboBox_QDateEndMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_QDateEndMonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_QDateEndMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QDateEndYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_QDateEndDay)));
 }//GEN-LAST:event_ComboBox_QDateEndMonthKeyPressed

 private void ComboBox_QDateEndDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_QDateEndDayKeyPressed
  PNav.onKey_CmB(this, ComboBox_QDateEndDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_QDateEndMonth)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_ComboBox_QDateEndDayKeyPressed

 private void CB_QBillDateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QBillDateKeyPressed
  PNav.onKey_CB(this, CB_QBillDate, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QRepayPeriod)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QBillDateStartYear)));
 }//GEN-LAST:event_CB_QBillDateKeyPressed

 private void TF_QBillDateStartYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QBillDateStartYearKeyPressed
  PNav.onKey_TF(this, TF_QBillDateStartYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QDateStartYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QRepayPeriodStartYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QBillDate)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBillDateStartMonth)));
 }//GEN-LAST:event_TF_QBillDateStartYearKeyPressed

 private void CmB_QBillDateStartMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBillDateStartMonthKeyPressed
  PNav.onKey_CmB(this, CmB_QBillDateStartMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QBillDateStartYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBillDateStartDay)));
 }//GEN-LAST:event_CmB_QBillDateStartMonthKeyPressed

 private void CmB_QBillDateStartDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBillDateStartDayKeyPressed
  PNav.onKey_CmB(this, CmB_QBillDateStartDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QBillDateStartMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QBillDateEndYear)));
 }//GEN-LAST:event_CmB_QBillDateStartDayKeyPressed

 private void TF_QBillDateEndYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QBillDateEndYearKeyPressed
  PNav.onKey_TF(this, TF_QBillDateEndYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QDateEndYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QRepayPeriodEndYear)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QBillDateStartDay)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBillDateEndMonth)));
 }//GEN-LAST:event_TF_QBillDateEndYearKeyPressed

 private void CmB_QBillDateEndMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBillDateEndMonthKeyPressed
  PNav.onKey_CmB(this, CmB_QBillDateEndMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QBillDateEndYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QBillDateEndDay)));
 }//GEN-LAST:event_CmB_QBillDateEndMonthKeyPressed

 private void CmB_QBillDateEndDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QBillDateEndDayKeyPressed
  PNav.onKey_CmB(this, CmB_QBillDateEndDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QBillDateEndMonth)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QBillDateEndDayKeyPressed

 private void CB_QRepayPeriodKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QRepayPeriodKeyPressed
  PNav.onKey_CB(this, CB_QRepayPeriod, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QBillDate)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QRepayPeriodStartYear)));
 }//GEN-LAST:event_CB_QRepayPeriodKeyPressed

 private void TF_QRepayPeriodStartYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QRepayPeriodStartYearKeyPressed
  PNav.onKey_TF(this, TF_QRepayPeriodStartYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QBillDateStartYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QRepayPeriod)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRepayPeriodStartMonth)));
 }//GEN-LAST:event_TF_QRepayPeriodStartYearKeyPressed

 private void CmB_QRepayPeriodStartMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRepayPeriodStartMonthKeyPressed
  PNav.onKey_CmB(this, CmB_QRepayPeriodStartMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QRepayPeriodStartYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRepayPeriodStartDay)));
 }//GEN-LAST:event_CmB_QRepayPeriodStartMonthKeyPressed

 private void CmB_QRepayPeriodStartDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRepayPeriodStartDayKeyPressed
  PNav.onKey_CmB(this, CmB_QRepayPeriodStartDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QRepayPeriodStartMonth)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QRepayPeriodEndYear)));
 }//GEN-LAST:event_CmB_QRepayPeriodStartDayKeyPressed

 private void TF_QRepayPeriodEndYearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_QRepayPeriodEndYearKeyPressed
  PNav.onKey_TF(this, TF_QRepayPeriodEndYear, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QBillDateEndYear)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_QId)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QRepayPeriodStartDay)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRepayPeriodEndMonth)));
 }//GEN-LAST:event_TF_QRepayPeriodEndYearKeyPressed

 private void CmB_QRepayPeriodEndMonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRepayPeriodEndMonthKeyPressed
  PNav.onKey_CmB(this, CmB_QRepayPeriodEndMonth, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_QRepayPeriodEndYear)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QRepayPeriodEndDay)));
 }//GEN-LAST:event_CmB_QRepayPeriodEndMonthKeyPressed

 private void CmB_QRepayPeriodEndDayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QRepayPeriodEndDayKeyPressed
  PNav.onKey_CmB(this, CmB_QRepayPeriodEndDay, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QRepayPeriodEndMonth)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_CmB_QRepayPeriodEndDayKeyPressed

 private void CB_QIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QIdKeyPressed
  PNav.onKey_CB(this, CB_QId, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QRepayPeriod)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QId)));
 }//GEN-LAST:event_CB_QIdKeyPressed

 private void CB_QCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCommentKeyPressed
  PNav.onKey_CB(this, CB_QComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QId)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCashComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QComment)));
 }//GEN-LAST:event_CB_QCommentKeyPressed

 private void CB_QCashCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCashCommentKeyPressed
  PNav.onKey_CB(this, CB_QCashComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCashComment)));
 }//GEN-LAST:event_CB_QCashCommentKeyPressed

 private void CmB_QCashCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCashCommentKeyPressed
  PNav.onKey_CmB(this, CmB_QCashComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCashComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QCashComment)));
 }//GEN-LAST:event_CmB_QCashCommentKeyPressed

 private void CB_QItemPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemPriceKeyPressed
  PNav.onKey_CB(this, CB_QItemPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCashComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QPaymentPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QItemPrice)));
 }//GEN-LAST:event_CB_QItemPriceKeyPressed

 private void CmB_QItemPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QItemPriceKeyPressed
  PNav.onKey_CmB(this, CmB_QItemPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItemPrice)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QItemPrice1)));
 }//GEN-LAST:event_CmB_QItemPriceKeyPressed

 private void CB_QPaymentPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QPaymentPriceKeyPressed
  PNav.onKey_CB(this, CB_QPaymentPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItemPrice)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QTransType)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QPaymentPrice)));
 }//GEN-LAST:event_CB_QPaymentPriceKeyPressed

 private void CmB_QPaymentPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QPaymentPriceKeyPressed
  PNav.onKey_CmB(this, CmB_QPaymentPrice, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QPaymentPrice)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_QPaymentPrice1)));
 }//GEN-LAST:event_CmB_QPaymentPriceKeyPressed

 private void CB_QTransTypeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QTransTypeKeyPressed
  PNav.onKey_CB(this, CB_QTransType, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QPaymentPrice)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QTransTypeEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QTransType)));
 }//GEN-LAST:event_CB_QTransTypeKeyPressed

 private void CB_QTransTypeEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QTransTypeEmptyKeyPressed
  PNav.onKey_CB(this, CB_QTransTypeEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QTransType)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSubject)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QTransType)));
 }//GEN-LAST:event_CB_QTransTypeEmptyKeyPressed

 private void List_QTransTypeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QTransTypeKeyReleased
  PNav.onKey_List(this, List_QTransType, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QPaymentPrice1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSubjectAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QTransType)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QTransTypeAdd)));
 }//GEN-LAST:event_List_QTransTypeKeyReleased

 private void Btn_QTransTypeAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QTransTypeAddKeyPressed
  PNav.onKey_Btn(this, Btn_QTransTypeAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_QPaymentPrice1)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QTransTypeRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QTransType)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QTransTypeAddKeyPressed

 private void Btn_QTransTypeRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QTransTypeRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QTransTypeRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTransTypeAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSubjectAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QTransType)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QTransTypeRemoveKeyPressed

 private void CB_QSubjectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSubjectKeyPressed
  PNav.onKey_CB(this, CB_QSubject, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QTransTypeEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSubjectEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QSubject)));
 }//GEN-LAST:event_CB_QSubjectKeyPressed

 private void CB_QSubjectEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSubjectEmptyKeyPressed
  PNav.onKey_CB(this, CB_QSubjectEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QSubject)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSalesman)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QSubject)));
 }//GEN-LAST:event_CB_QSubjectEmptyKeyPressed

 private void List_QSubjectKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QSubjectKeyReleased
  PNav.onKey_List(this, List_QSubject, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTransTypeAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSalesmanAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QSubject)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QSubjectAdd)));
 }//GEN-LAST:event_List_QSubjectKeyReleased

 private void Btn_QSubjectAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSubjectAddKeyPressed
  PNav.onKey_Btn(this, Btn_QSubjectAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QTransTypeRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSubjectRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QSubject)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSubjectAddKeyPressed

 private void Btn_QSubjectRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSubjectRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QSubjectRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSubjectAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSalesmanAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QSubject)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSubjectRemoveKeyPressed

 private void CB_QSalesmanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSalesmanKeyPressed
  PNav.onKey_CB(this, CB_QSalesman, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QSubjectEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QSalesmanEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QSalesman)));
 }//GEN-LAST:event_CB_QSalesmanKeyPressed

 private void CB_QSalesmanEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QSalesmanEmptyKeyPressed
  PNav.onKey_CB(this, CB_QSalesmanEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QSalesman)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCash)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QSalesman)));
 }//GEN-LAST:event_CB_QSalesmanEmptyKeyPressed

 private void List_QSalesmanKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QSalesmanKeyReleased
  PNav.onKey_List(this, List_QSalesman, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSubjectAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCashAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QSalesman)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QSalesmanAdd)));
 }//GEN-LAST:event_List_QSalesmanKeyReleased

 private void Btn_QSalesmanAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSalesmanAddKeyPressed
  PNav.onKey_Btn(this, Btn_QSalesmanAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSubjectRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QSalesmanRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QSalesman)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSalesmanAddKeyPressed

 private void Btn_QSalesmanRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QSalesmanRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QSalesmanRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSalesmanAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCashAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QSalesman)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QSalesmanRemoveKeyPressed

 private void CB_QCashKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCashKeyPressed
  PNav.onKey_CB(this, CB_QCash, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QSalesmanEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QCashEmpty)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QCash)));
 }//GEN-LAST:event_CB_QCashKeyPressed

 private void CmB_QCashKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QCashKeyPressed
  PNav.onKey_CmB(this, CmB_QCash, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QCash)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCash)));
 }//GEN-LAST:event_CmB_QCashKeyPressed

 private void CB_QCashEmptyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QCashEmptyKeyPressed
  PNav.onKey_CB(this, CB_QCashEmpty, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCash)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItem)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(List_QCash)));
 }//GEN-LAST:event_CB_QCashEmptyKeyPressed

 private void List_QCashKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_List_QCashKeyReleased
  PNav.onKey_List(this, List_QCash, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSalesmanAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QCash)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QCashAdd)));
 }//GEN-LAST:event_List_QCashKeyReleased

 private void Btn_QCashAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCashAddKeyPressed
  PNav.onKey_Btn(this, Btn_QCashAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QSalesmanRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QCashRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCash)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCashAddKeyPressed

 private void Btn_QCashRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QCashRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QCashRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCashAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(List_QCash)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QCashRemoveKeyPressed

 private void CB_QItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemKeyPressed
  PNav.onKey_CB(this, CB_QItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QCashEmpty)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_QItemNon)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_QItem)));
 }//GEN-LAST:event_CB_QItemKeyPressed

 private void CmB_QItemKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_QItemKeyPressed
  PNav.onKey_CmB(this, CmB_QItem, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_QItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QItem)));
 }//GEN-LAST:event_CmB_QItemKeyPressed

 private void CB_QItemNonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_QItemNonKeyPressed
  PNav.onKey_CB(this, CB_QItemNon, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_QItem)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Tbl_QItem)));
 }//GEN-LAST:event_CB_QItemNonKeyPressed

 private void Tbl_QItemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Tbl_QItemKeyReleased
  PNav.onKey_Tbl(this, Tbl_QItem, true, true, false, false, CNav.StateKey_Released, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCashAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_QItem)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_QItemAdd)));
 }//GEN-LAST:event_Tbl_QItemKeyReleased

 private void Btn_QItemAddKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemAddKeyPressed
  PNav.onKey_Btn(this, Btn_QItemAdd, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QCashRemove)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_QItemRemove)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemAddKeyPressed

 private void Btn_QItemRemoveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_QItemRemoveKeyPressed
  PNav.onKey_Btn(this, Btn_QItemRemove, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_QItemAdd)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Tbl_QItem)),
   /* Right */  CNav.B_ActCstm_Rg.init(AbstFocusQueryResult));
 }//GEN-LAST:event_Btn_QItemRemoveKeyPressed

 private void CB_ItemInCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemInCategorizedActionPerformed
  changeItemInViewByCategorized();
 }//GEN-LAST:event_CB_ItemInCategorizedActionPerformed

 private void CB_ItemOutCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutCategorizedActionPerformed
  changeItemOutViewByCategorized();
 }//GEN-LAST:event_CB_ItemOutCategorizedActionPerformed

 private void CB_ItemOutShowBasicPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ItemOutShowBasicPriceActionPerformed
  changeItemOutViewByHPP();
 }//GEN-LAST:event_CB_ItemOutShowBasicPriceActionPerformed

 private void CB_OrdCategorizedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_OrdCategorizedActionPerformed
  changeOrdViewByCategorized();
 }//GEN-LAST:event_CB_OrdCategorizedActionPerformed

 private void CB_ViewDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewDateActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewDateActionPerformed

 private void CB_ViewDateBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewDateBillActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewDateBillActionPerformed

 private void CB_ViewDateRepaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewDateRepaymentActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewDateRepaymentActionPerformed

 private void CB_ViewSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSubjectActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewSubjectActionPerformed

 private void CB_ViewSalesmanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewSalesmanActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewSalesmanActionPerformed

 private void CB_ViewCashOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashOutActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewCashOutActionPerformed

 private void CB_ViewCashOutCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashOutCommentActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewCashOutCommentActionPerformed

 private void CB_ViewCashInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashInActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewCashInActionPerformed

 private void CB_ViewCashInCommentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewCashInCommentActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewCashInCommentActionPerformed

 private void CB_ViewIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIdActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewIdActionPerformed

 private void CB_ViewIdExternalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIdExternalActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewIdExternalActionPerformed

 private void CB_ViewIsImportantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewIsImportantActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewIsImportantActionPerformed

 private void CB_ViewItemInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewItemInActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewItemInActionPerformed

 private void CB_ViewItemOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewItemOutActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewItemOutActionPerformed

 private void CB_ViewItemOutBasicPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_ViewItemOutBasicPriceActionPerformed
  changeTableTransViewByNormalMode();
 }//GEN-LAST:event_CB_ViewItemOutBasicPriceActionPerformed

 private void TF_QDateStartYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QDateStartYearFocusGained
  PGUI.text_SelectAll(TF_QDateStartYear);
 }//GEN-LAST:event_TF_QDateStartYearFocusGained

 private void TF_QDateEndYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QDateEndYearFocusGained
  PGUI.text_SelectAll(TF_QDateEndYear);
 }//GEN-LAST:event_TF_QDateEndYearFocusGained

 private void TF_QBillDateStartYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QBillDateStartYearFocusGained
  PGUI.text_SelectAll(TF_QBillDateStartYear);
 }//GEN-LAST:event_TF_QBillDateStartYearFocusGained

 private void TF_QBillDateEndYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QBillDateEndYearFocusGained
  PGUI.text_SelectAll(TF_QBillDateEndYear);
 }//GEN-LAST:event_TF_QBillDateEndYearFocusGained

 private void TF_QRepayPeriodStartYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QRepayPeriodStartYearFocusGained
  PGUI.text_SelectAll(TF_QRepayPeriodStartYear);
 }//GEN-LAST:event_TF_QRepayPeriodStartYearFocusGained

 private void TF_QRepayPeriodEndYearFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_QRepayPeriodEndYearFocusGained
  PGUI.text_SelectAll(TF_QRepayPeriodEndYear);
 }//GEN-LAST:event_TF_QRepayPeriodEndYearFocusGained

 private void TF_FindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindFocusGained
  PGUI.text_SelectAll(TF_Find);
 }//GEN-LAST:event_TF_FindFocusGained

 private void TF_FindItemInFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemInFocusGained
  PGUI.text_SelectAll(TF_FindItemIn);
 }//GEN-LAST:event_TF_FindItemInFocusGained

 private void TF_FindItemOutFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_FindItemOutFocusGained
  PGUI.text_SelectAll(TF_FindItemOut);
 }//GEN-LAST:event_TF_FindItemOutFocusGained

 private void TF_OrdFindFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_OrdFindFocusGained
  PGUI.text_SelectAll(TF_OrdFind);
 }//GEN-LAST:event_TF_OrdFindFocusGained

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.ButtonGroup BG_FindItemIn;
 private javax.swing.ButtonGroup BG_FindItemOut;
 private javax.swing.JButton Btn_FindBefore;
 private javax.swing.JButton Btn_FindItemInBef;
 private javax.swing.JButton Btn_FindItemInNext;
 private javax.swing.JButton Btn_FindItemOutBef;
 private javax.swing.JButton Btn_FindItemOutNext;
 private javax.swing.JButton Btn_FindNext;
 private javax.swing.JButton Btn_InAdd;
 private javax.swing.JButton Btn_InCancel;
 private javax.swing.JButton Btn_InCheckAdd;
 private javax.swing.JButton Btn_InCheckRemove;
 private javax.swing.JButton Btn_InEdit;
 private javax.swing.JButton Btn_InOtherOperation;
 private javax.swing.JButton Btn_InTempListAdd;
 private javax.swing.JButton Btn_InTempListRemove;
 private javax.swing.JButton Btn_MultipleTransImportantAdd;
 private javax.swing.JButton Btn_MultipleTransImportantRemove;
 private javax.swing.JButton Btn_OrdAdd;
 private javax.swing.JButton Btn_OrdEdit;
 private javax.swing.JButton Btn_OrdFindBef;
 private javax.swing.JButton Btn_OrdFindNext;
 private javax.swing.JButton Btn_OrdMove;
 private javax.swing.JButton Btn_OrdRefresh;
 private javax.swing.JButton Btn_OrdRemove;
 private javax.swing.JButton Btn_OrdTempListAdd;
 private javax.swing.JButton Btn_OrdTempListRemove;
 private javax.swing.JButton Btn_OutAdd;
 private javax.swing.JButton Btn_OutCancel;
 private javax.swing.JButton Btn_OutCheckAdd;
 private javax.swing.JButton Btn_OutCheckRemove;
 private javax.swing.JButton Btn_OutEdit;
 private javax.swing.JButton Btn_OutOtherOperation;
 private javax.swing.JButton Btn_OutTempListAdd;
 private javax.swing.JButton Btn_OutTempListRemove;
 private javax.swing.JButton Btn_PaymentInAdd;
 private javax.swing.JButton Btn_PaymentInCancel;
 private javax.swing.JButton Btn_PaymentInEdit;
 private javax.swing.JButton Btn_PaymentInPrint;
 private javax.swing.JButton Btn_PaymentOutAdd;
 private javax.swing.JButton Btn_PaymentOutCancel;
 private javax.swing.JButton Btn_PaymentOutEdit;
 private javax.swing.JButton Btn_PaymentOutPrint;
 private javax.swing.JButton Btn_QCashAdd;
 private javax.swing.JButton Btn_QCashRemove;
 private javax.swing.JButton Btn_QItemAdd;
 private javax.swing.JButton Btn_QItemRemove;
 private javax.swing.JButton Btn_QSalesmanAdd;
 private javax.swing.JButton Btn_QSalesmanRemove;
 private javax.swing.JButton Btn_QSubjectAdd;
 private javax.swing.JButton Btn_QSubjectRemove;
 private javax.swing.JButton Btn_QTransTypeAdd;
 private javax.swing.JButton Btn_QTransTypeRemove;
 private javax.swing.JButton Btn_Query;
 private javax.swing.JButton Btn_QueryRefresh;
 private javax.swing.JButton Btn_Report;
 private javax.swing.JButton Btn_TempListAdd;
 private javax.swing.JButton Btn_TempListClear;
 private javax.swing.JButton Btn_TempListLoad;
 private javax.swing.JButton Btn_TempListRemove;
 private javax.swing.JButton Btn_TempListSave;
 private javax.swing.JButton Btn_TransCancel;
 private javax.swing.JButton Btn_TransChoose;
 private javax.swing.JButton Btn_TransEdit;
 private javax.swing.JButton Btn_TransNew;
 private javax.swing.JButton Btn_TransRemove;
 private javax.swing.JButton Btn_TransSalesmanInfo;
 private javax.swing.JButton Btn_TransSalesmanTempListAdd;
 private javax.swing.JButton Btn_TransSalesmanTempListRemove;
 private javax.swing.JButton Btn_TransSubjectInfo;
 private javax.swing.JButton Btn_TransSubjectTempListAdd;
 private javax.swing.JButton Btn_TransSubjectTempListRemove;
 private javax.swing.JCheckBox CB_DetImportant;
 private javax.swing.JToggleButton CB_ItemInCategorized;
 private javax.swing.JCheckBox CB_ItemOutBasicSum;
 private javax.swing.JToggleButton CB_ItemOutCategorized;
 private javax.swing.JToggleButton CB_ItemOutShowBasicPrice;
 private javax.swing.JToggleButton CB_OrdCategorized;
 private javax.swing.JCheckBox CB_QBillDate;
 private javax.swing.JCheckBox CB_QCash;
 private javax.swing.JCheckBox CB_QCashComment;
 private javax.swing.JCheckBox CB_QCashEmpty;
 private javax.swing.JCheckBox CB_QCheck;
 private javax.swing.JCheckBox CB_QComment;
 private javax.swing.JCheckBox CB_QDate;
 private javax.swing.JCheckBox CB_QId;
 private javax.swing.JCheckBox CB_QImportant;
 private javax.swing.JCheckBox CB_QItem;
 private javax.swing.JCheckBox CB_QItemNon;
 private javax.swing.JCheckBox CB_QItemPrice;
 private javax.swing.JCheckBox CB_QPaymentPrice;
 private javax.swing.JCheckBox CB_QRepayPeriod;
 private javax.swing.JCheckBox CB_QSalesman;
 private javax.swing.JCheckBox CB_QSalesmanEmpty;
 private javax.swing.JCheckBox CB_QSubject;
 private javax.swing.JCheckBox CB_QSubjectEmpty;
 private javax.swing.JCheckBox CB_QTransType;
 private javax.swing.JCheckBox CB_QTransTypeEmpty;
 private javax.swing.JToggleButton CB_ViewCashIn;
 private javax.swing.JToggleButton CB_ViewCashInComment;
 private javax.swing.JToggleButton CB_ViewCashOut;
 private javax.swing.JToggleButton CB_ViewCashOutComment;
 private javax.swing.JToggleButton CB_ViewDate;
 private javax.swing.JToggleButton CB_ViewDateBill;
 private javax.swing.JToggleButton CB_ViewDateRepayment;
 private javax.swing.JToggleButton CB_ViewId;
 private javax.swing.JToggleButton CB_ViewIdExternal;
 private javax.swing.JToggleButton CB_ViewIsImportant;
 private javax.swing.JToggleButton CB_ViewItemIn;
 private javax.swing.JToggleButton CB_ViewItemOut;
 private javax.swing.JToggleButton CB_ViewItemOutBasicPrice;
 private javax.swing.JToggleButton CB_ViewSalesman;
 private javax.swing.JToggleButton CB_ViewSubject;
 private javax.swing.JComboBox<String> CmB_Find;
 private javax.swing.JComboBox<String> CmB_FindItemIn;
 private javax.swing.JComboBox<String> CmB_FindItemOut;
 private javax.swing.JComboBox<String> CmB_OrdFind;
 private javax.swing.JComboBox<String> CmB_QBillDateEndDay;
 private javax.swing.JComboBox<String> CmB_QBillDateEndMonth;
 private javax.swing.JComboBox<String> CmB_QBillDateStartDay;
 private javax.swing.JComboBox<String> CmB_QBillDateStartMonth;
 private javax.swing.JComboBox<String> CmB_QCash;
 private javax.swing.JComboBox<String> CmB_QCashComment;
 private javax.swing.JComboBox<String> CmB_QCheck;
 private javax.swing.JComboBox<String> CmB_QItem;
 private javax.swing.JComboBox<String> CmB_QItemPrice;
 private javax.swing.JComboBox<String> CmB_QPaymentPrice;
 private javax.swing.JComboBox<String> CmB_QRepayPeriodEndDay;
 private javax.swing.JComboBox<String> CmB_QRepayPeriodEndMonth;
 private javax.swing.JComboBox<String> CmB_QRepayPeriodStartDay;
 private javax.swing.JComboBox<String> CmB_QRepayPeriodStartMonth;
 private javax.swing.JComboBox<String> CmB_ReportType;
 private javax.swing.JComboBox<String> CmB_ResultFilterSubset;
 private javax.swing.JComboBox<String> CmB_ViewMode;
 private javax.swing.JComboBox ComboBox_QDateEndDay;
 private javax.swing.JComboBox ComboBox_QDateEndMonth;
 private javax.swing.JComboBox ComboBox_QDateStartDay;
 private javax.swing.JComboBox ComboBox_QDateStartMonth;
 private javax.swing.JLabel Lbl_DetCashIn;
 private javax.swing.JLabel Lbl_DetCashOut;
 private javax.swing.JLabel Lbl_DetComment;
 private javax.swing.JLabel Lbl_DetCreditDays;
 private javax.swing.JLabel Lbl_DetDate;
 private javax.swing.JLabel Lbl_DetId;
 private javax.swing.JLabel Lbl_DetIdExternal;
 private javax.swing.JLabel Lbl_DetRepaymentPeriod;
 private javax.swing.JLabel Lbl_DetSalesman;
 private javax.swing.JLabel Lbl_DetSubject;
 private javax.swing.JLabel Lbl_DetTransType;
 private javax.swing.JLabel Lbl_ItemInSum;
 private javax.swing.JLabel Lbl_ItemOutSum;
 private javax.swing.JLabel Lbl_MultipleSelection;
 private javax.swing.JLabel Lbl_PaymentInCash;
 private javax.swing.JLabel Lbl_PaymentInComment;
 private javax.swing.JLabel Lbl_PaymentInDate;
 private javax.swing.JLabel Lbl_PaymentInPrice;
 private javax.swing.JLabel Lbl_PaymentInSum;
 private javax.swing.JLabel Lbl_PaymentOutCash;
 private javax.swing.JLabel Lbl_PaymentOutComment;
 private javax.swing.JLabel Lbl_PaymentOutDate;
 private javax.swing.JLabel Lbl_PaymentOutPrice;
 private javax.swing.JLabel Lbl_PaymentOutSum;
 private javax.swing.JLabel Lbl_QCashCommentHelp;
 private javax.swing.JLabel Lbl_QCommentHelp;
 private javax.swing.JLabel Lbl_QIdHelp;
 private javax.swing.JLabel Lbl_QItemPriceHelp;
 private javax.swing.JLabel Lbl_QPaymentPriceHelp;
 private XList List_QCash;
 private XList List_QSalesman;
 private XList List_QSubject;
 private XList List_QTransType;
 private javax.swing.JPanel Panel_Detail;
 private javax.swing.JPanel Panel_In;
 private javax.swing.JPanel Panel_Order;
 private javax.swing.JPanel Panel_Out;
 private javax.swing.JPanel Panel_PaymentIn;
 private javax.swing.JPanel Panel_PaymentOut;
 private javax.swing.JPanel Panel_Query;
 private XImgBoxURL Pnl_ItemInPreview;
 private XImgBoxURL Pnl_ItemOutPreview;
 private XImgBoxURL Pnl_OrdPreview;
 private javax.swing.JPanel Pnl_TransSummary;
 private javax.swing.JPanel Pnl_View;
 private javax.swing.JRadioButton RB_QImportantNo;
 private javax.swing.JRadioButton RB_QImportantYes;
 private javax.swing.ButtonGroup RG_QImportant;
 private javax.swing.ButtonGroup RG_QItem;
 private javax.swing.ButtonGroup RG_Query;
 private javax.swing.JTextArea TA_DetComment;
 private javax.swing.JTextArea TA_OrdInfoCategory;
 private javax.swing.JTextArea TA_OrdInfoName;
 private javax.swing.JTextArea TA_PaymentInComment;
 private javax.swing.JTextArea TA_PaymentOutComment;
 private javax.swing.JTextArea TF_DetCashIn;
 private javax.swing.JTextArea TF_DetCashOut;
 private javax.swing.JTextField TF_DetCreditDays;
 private javax.swing.JTextField TF_DetDate;
 private javax.swing.JTextField TF_DetId;
 private javax.swing.JTextField TF_DetIdExternal;
 private javax.swing.JTextField TF_DetRepaymentPeriod;
 private javax.swing.JTextField TF_DetSalesman;
 private javax.swing.JTextField TF_DetSubject;
 private javax.swing.JTextField TF_DetTransType;
 private javax.swing.JTextField TF_Find;
 private javax.swing.JTextField TF_FindItemIn;
 private javax.swing.JTextField TF_FindItemOut;
 private javax.swing.JTextField TF_InCount;
 private javax.swing.JTextArea TF_InInfoCategory;
 private javax.swing.JTextArea TF_InInfoName;
 private javax.swing.JTextField TF_ItemInSum;
 private javax.swing.JTextField TF_ItemOutBasicSum;
 private javax.swing.JTextField TF_ItemOutSum;
 private javax.swing.JTextField TF_ListCount;
 private javax.swing.JTextField TF_OrdCount;
 private javax.swing.JTextField TF_OrdFind;
 private javax.swing.JTextField TF_OrdPriceEst;
 private javax.swing.JTextField TF_OutCount;
 private javax.swing.JTextArea TF_OutInfoCategory;
 private javax.swing.JTextArea TF_OutInfoName;
 private javax.swing.JTextField TF_PayInCount;
 private javax.swing.JTextField TF_PayOutCount;
 private javax.swing.JTextField TF_PaymentInCash;
 private javax.swing.JTextField TF_PaymentInDate;
 private javax.swing.JTextField TF_PaymentInPrice;
 private javax.swing.JTextField TF_PaymentInSum;
 private javax.swing.JTextField TF_PaymentOutCash;
 private javax.swing.JTextField TF_PaymentOutDate;
 private javax.swing.JTextField TF_PaymentOutPrice;
 private javax.swing.JTextField TF_PaymentOutSum;
 private javax.swing.JTextField TF_QBillDateEndYear;
 private javax.swing.JTextField TF_QBillDateStartYear;
 private javax.swing.JTextField TF_QCashComment;
 private javax.swing.JTextField TF_QComment;
 private javax.swing.JTextField TF_QDateEndYear;
 private javax.swing.JTextField TF_QDateStartYear;
 private javax.swing.JTextField TF_QId;
 private javax.swing.JTextField TF_QItemPrice1;
 private javax.swing.JTextField TF_QItemPrice2;
 private javax.swing.JTextField TF_QPaymentPrice1;
 private javax.swing.JTextField TF_QPaymentPrice2;
 private javax.swing.JTextField TF_QRepayPeriodEndYear;
 private javax.swing.JTextField TF_QRepayPeriodStartYear;
 private javax.swing.JTextField TF_QueryTempListCount;
 private javax.swing.JTextField TF_TempListQuantity;
 private javax.swing.JTabbedPane TabbedPane;
 private XTable Tbl_In;
 private XTable Tbl_Ord;
 private XTable Tbl_Out;
 private XTable Tbl_PaymentIn;
 private XTable Tbl_PaymentOut;
 private XTable Tbl_QItem;
 private XTable Tbl_Trans;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel12;
 private javax.swing.JLabel jLabel13;
 private javax.swing.JLabel jLabel14;
 private javax.swing.JLabel jLabel15;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JPanel jPanel10;
 private javax.swing.JPanel jPanel11;
 private javax.swing.JPanel jPanel12;
 private javax.swing.JPanel jPanel13;
 private javax.swing.JPanel jPanel14;
 private javax.swing.JPanel jPanel15;
 private javax.swing.JPanel jPanel2;
 private javax.swing.JPanel jPanel3;
 private javax.swing.JPanel jPanel4;
 private javax.swing.JPanel jPanel5;
 private javax.swing.JPanel jPanel6;
 private javax.swing.JPanel jPanel7;
 private javax.swing.JPanel jPanel8;
 private javax.swing.JPanel jPanel9;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane10;
 private javax.swing.JScrollPane jScrollPane11;
 private javax.swing.JScrollPane jScrollPane12;
 private javax.swing.JScrollPane jScrollPane14;
 private javax.swing.JScrollPane jScrollPane15;
 private javax.swing.JScrollPane jScrollPane16;
 private javax.swing.JScrollPane jScrollPane17;
 private javax.swing.JScrollPane jScrollPane18;
 private javax.swing.JScrollPane jScrollPane19;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JScrollPane jScrollPane20;
 private javax.swing.JScrollPane jScrollPane21;
 private javax.swing.JScrollPane jScrollPane22;
 private javax.swing.JScrollPane jScrollPane23;
 private javax.swing.JScrollPane jScrollPane3;
 private javax.swing.JScrollPane jScrollPane4;
 private javax.swing.JScrollPane jScrollPane5;
 private javax.swing.JScrollPane jScrollPane6;
 private javax.swing.JScrollPane jScrollPane7;
 private javax.swing.JScrollPane jScrollPane8;
 private javax.swing.JScrollPane jScrollPane9;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 // End of variables declaration//GEN-END:variables
}
