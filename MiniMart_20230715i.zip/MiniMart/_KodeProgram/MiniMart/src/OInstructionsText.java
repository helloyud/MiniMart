import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTextArea;

public class OInstructionsText extends OInstructions{

 public final static int InstructionsType=1;
 public int getInstructionsType(){return InstructionsType;}

 /* Instructions code:
    1 write ForeText.
    2 write PreviousData.
    61 query from SqlQuery
    71 write FirstNRecordsCount from ResultSet (A Column or Multi Columns)
 */
 
 public String SqlQuery;
	public int[] SqlQueryColumnsType;
 public boolean FetchDataFromCustomColumns;
 public int[] FetchCustomColumns; // custom columns's index start with 0
 public int NFirstRecords;
 
 public String ForeText;

 public OInstructionsText() {
  super();
 }

 void clearProcessedDataAdditional() {}
 void processing(OFormSupportsInstructions Form) throws Exception {
  JTextArea TA=Form.getText();
  Statement Stm=Form.getStatement();
  
  int insttemp;
  ResultSet Rs=null;
  
  insttemp=0;
  do{
   switch(Instructions[insttemp]){
    case 1: TA.append(ForeText); break;
    case 2: writePreviousData(TA); break;
    case 61: Rs=Stm.executeQuery(SqlQuery); break;
    case 71: writeFirstNRecords(TA, Rs); break;
   }
   insttemp=insttemp+1;
  }while(insttemp!=Instructions.length);
  
  Form.getTextResultSign().setSelected(true);
 }
 void writePreviousData(JTextArea TA){
  int temp, temp_;
  temp=PreviousData.size();
  if(temp==0){return;}
  TA.append("\n"+PreviousData.elementAt(0).toString());
  if(temp==1){return;}
  
  temp_=1;
  do{
   TA.append(", "+PreviousData.elementAt(temp_).toString());
   temp_=temp_+1;
  }while(temp_!=temp);
 }
 void writeFirstNRecords(JTextArea TA, ResultSet Rs) throws Exception{
  int temp, colcount, coltemp;
  int[] col;
  
  if(!Rs.next()){return;}
  
  if(FetchDataFromCustomColumns){col=FetchCustomColumns;}
  else{
   colcount=Rs.getMetaData().getColumnCount();
   col=new int[colcount];
   temp=0;
   do{
    col[temp]=temp+1;
    temp=temp+1;
   }while(temp!=colcount);
  }
  
  colcount=col.length;
  temp=0;
  do{
   TA.append("\n");
   
   coltemp=0;
   do{
    if(coltemp!=0){TA.append(", ");}
    TA.append(PText.getString(Rs, col[coltemp], SqlQueryColumnsType[col[coltemp]], "-", true));
    coltemp=coltemp+1;
   }while(coltemp!=colcount);
   
   temp=temp+1;
   if(temp==NFirstRecords){break;}
  }while(Rs.next());
 }

}