public class OGetStringByNormal extends OGetString {
 
 public String getString(String Word){
  return PText.getString(Word, "", false);
 }

}