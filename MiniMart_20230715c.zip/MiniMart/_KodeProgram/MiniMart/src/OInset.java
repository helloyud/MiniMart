public class OInset {
 
 double InsetTop, InsetBottom;
 double InsetLeft, InsetRight;
 
 static OInset DefaultInset=new OInset(OUnit.mm_to_pixel(1.1),
  OUnit.mm_to_pixel(1.1), OUnit.mm_to_pixel(1.1), OUnit.mm_to_pixel(1.1));
 static OInset EmptyInset=new OInset(0, 0, 0, 0);

 public OInset(double InsetTop, double InsetBottom, double InsetLeft, double InsetRight) {
  this.InsetTop = InsetTop;
  this.InsetBottom = InsetBottom;
  this.InsetLeft = InsetLeft;
  this.InsetRight = InsetRight;
 }
 
}