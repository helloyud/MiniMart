import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Vector;

public class OPrintGeneratorConvertRule extends OPrintGenerator{

 // additional printing properties
 LinkedList<Long> Id;
 boolean Opt_IsActive, Opt_LastUpdate;
 boolean OptList_Item;
 boolean OptList_ItemCategorized;
 
 //
 /*
    CurrOperation :

    21 rule main,
    31 rule item-in's header, 32 rule item-in's category header, 33 rule item-in's list,
    41 rule item-out's header, 42 rule item-out's category header, 43 rule item-out's list
 */
 final int Op_Main=21;
 final int Op_ItemIn_Header=31; final int Op_ItemIn_CategoryHeader=32; final int Op_ItemIn_List=33;
 final int Op_ItemOut_Header=41; final int Op_ItemOut_CategoryHeader=42; final int Op_ItemOut_List=43;
 
 String DbItemIn, DbItemOut;
 String IdQ;
 int CurrOperation;
 ODrawTableRow TableNewRow, TableNewRow2, TableNewRow3;
 Statement Stm2; ResultSet Rs2;
 OQuickListOfLong PrintedItems;
 boolean IsEndPrinting;
 
 // Main Header
 VDrawTable Table_MainHeader;
 
 // Main List
 VDrawTable Table_Main;
 
 final int PointOfMainCharCount=2;
 final String PointOfMain="*";
 
 // Main Info
 long CurrMain_Id;
 OInfoConvertRule CurrMain_Info;
 int CurrMain_InfoItemInCount;
 int CurrMain_InfoItemOutCount;
 
 // List Items
 VDrawTable Table_ListItem, Table_ListItemCategoryHeader;
 
 int ItemIdsCount;
 String ItemIdsStr;
 
 Vector<OIdName> ItemCategories;
 int ItemCurrCategory;
 
 Vector<Object[]> ItemList;
 int ItemListItemCount;
 int ItemListCurrItem;
 
 //
 final int PointOfListCharCount=2;
 final String PointOfListItemOut=">";
 final String PointOfListItemIn="<";
 final String PointOfListCategory="+";
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 final int ColSizeDate=11;
 final int ColSizeQty=7;
 final int ColSizeStockUnit=10;
 final int ColSizeTextMin=10;
 final int ColSizeTextMed=20;
 final int ColSizeTextMax=30;
 double PostTextAddLineSpacing, ItemCategoryAddLineSpacing;
 double MainToDetailAddLineSpacing;
 double TableListXIndent;
 int MaxCharList;
 double CellAreaMinHeight;
 boolean EnablePreAddLineSpacing, EnablePostAddLineSpacing;
 
 OPrintGeneratorConvertRule(OFont FontStandard) {
  super(FontStandard);
  
  Table_Main=new VDrawTable(); Table_MainHeader=new VDrawTable();
  Table_ListItem=new VDrawTable(); Table_ListItemCategoryHeader=new VDrawTable();
  
  CurrMain_Info=new OInfoConvertRule();
 }
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> Id,
  
  boolean Opt_IsActive, boolean Opt_LastUpdate,
  
  boolean OptList_Item,
  boolean OptList_ItemCategorized){
  
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.Stm=Stm;
  this.Id=Id;
  
  this.Opt_IsActive=Opt_IsActive;
  this.Opt_LastUpdate=Opt_LastUpdate;
  
  this.OptList_Item=OptList_Item;
  this.OptList_ItemCategorized=OptList_ItemCategorized;
 }
 
 // standard private methods
	protected boolean hasHeader(){return false;}
 protected boolean hasFooter(){return true;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.5f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(7.5f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  ODrawTableColumnMetadata[] Columns;
  OInset Inset;
  double TableListWidth;
  double temp_d;
  ODrawTable tbl;
  
  CellAreaMinHeight=NormalHeight;
  Inset=new OInset(0.2*FontHeight, 0.2*FontHeight, 0.7*FontWidth, 0.7*FontWidth);
  PostTextAddLineSpacing=0.2*FontHeight;
  ItemCategoryAddLineSpacing=0.6*FontHeight;
  
  // Main
  Columns=new ODrawTableColumnMetadata[1+1];
  Columns[0]=new ODrawTableColumnMetadata(null, PointOfMainCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[1]=new ODrawTableColumnMetadata("Nama", 0);
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)+temp_d>ColumnarWidth){throw new Exception();}
  Columns[1].Width=ColumnarWidth-temp_d;
  
  Table_Main.Value=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillEmpty);
  
  Table_MainHeader.Value=Table_Main.Value.createNewTable();
  Table_MainHeader.Value.insertARow(0, Table_MainHeader.Value.getRowHeader(FontType, LineSpacing,
   new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalCenter), false, 1, true, 0, true, 1.0, 1, '~'));
  
  // Main Detail
  MainToDetailAddLineSpacing=0.3*FontHeight;
  
  TableListXIndent=Table_Main.Value.Columns[0].Width;
  TableListWidth=ColumnarWidth-TableListXIndent;
  MaxCharList=(int)(TableListWidth/FontWidth);
  
   // List Item Out - In
  Columns=new ODrawTableColumnMetadata[3+1];
  Columns[0]=new ODrawTableColumnMetadata(null, PointOfListCharCount*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[1]=new ODrawTableColumnMetadata("Barang", 0);
  Columns[2]=new ODrawTableColumnMetadata("Qty", ColSizeQty*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  Columns[3]=new ODrawTableColumnMetadata("Satuan", ColSizeStockUnit*FontWidth+(Inset.InsetLeft+Inset.InsetRight));
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  if(ColSizeTextMin*FontWidth+(Inset.InsetLeft+Inset.InsetRight)+temp_d>TableListWidth){throw new Exception();}
  Columns[1].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillAll);
  Table_ListItem.Value=tbl.createNewTable();
  
  Columns=new ODrawTableColumnMetadata[1];
  Columns[0]=new ODrawTableColumnMetadata("Kategori", 0);
  temp_d=PGUI.sumDrawTableColumnWidth(PCore.newIntegerArrayInOrderedSequence(Columns.length, 0, 1), Columns);
  Columns[0].Width=TableListWidth-temp_d;
  
  tbl=new ODrawTable(Columns, Inset, ODrawTableBorder.DefaultFillEmpty);
  Table_ListItemCategoryHeader.Value=tbl.createNewTable();
 }
 protected void prepareFirstPageData() throws Exception{
  DbItemOut="RuleOfConvXSideA";
  DbItemIn="RuleOfConvXSideB";
  
  Stm2=Stm.getConnection().createStatement();
  
  saveId();
  IsEndPrinting=false;
  
  // doing the first operation
  preInitLayoutVarDefault();
  queryMain(); if(!getNextMain()){throw new Exception();}
  CurrOperation=Op_Main;
  postInitLayoutVarDefault();
 }
 protected void addHeader() throws Exception{
  
 }
 protected boolean addColumnar() throws Exception{
  VBoolean KeepPrinting=new VBoolean(true);
  VBoolean CloseTable=new VBoolean();
  VDrawTable CurrTable=null;
  boolean processed;
  double PreAddLineSpacing, PostAddLineSpacing;
  Vector<String> Words=null;
  double Pos_X=0;
  double Pos_Y=0;
  double WordsBox_Width=0;
  double WordsBox_Height=0;
  OAlignment WordsBox_Alignment=null;
  OAlignment WordsBox_AlignmentDefault=new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop);
  
  do{
   
   do{
    // Operation without check
    PreAddLineSpacing=0; PostAddLineSpacing=PostTextAddLineSpacing;
    Pos_X=BaseX;
    WordsBox_Alignment=WordsBox_AlignmentDefault;
    
    processed=true;
    do{
     if(CurrOperation==Op_ItemOut_Header){
      PreAddLineSpacing=MainToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Sisi A { Jumlah : "+PText.intToString(CurrMain_InfoItemOutCount)+" }",
       MaxCharList, true, MaxCharList-1, 1, '~'));
      WordsBox_Width=Table_ListItem.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     if(CurrOperation==Op_ItemIn_Header){
      PreAddLineSpacing=MainToDetailAddLineSpacing;
      Words=PCore.vect(PText.fitString("Sisi B { Jumlah : "+PText.intToString(CurrMain_InfoItemInCount)+" }",
       MaxCharList, true, MaxCharList-1, 1, '~'));
      WordsBox_Width=Table_ListItem.Value.Width;
      Pos_X=Pos_X+TableListXIndent;
      break;
     }
     
     processed=false;
    }while(false);
    if(processed){
     if(IsANewColumnar){IsANewColumnar=false;}
     else{if(EnablePreAddLineSpacing){CurrY=CurrY+PreAddLineSpacing;}}
     
     Pos_Y=BaseY+CurrY;
     WordsBox_Height=Words.size()*NormalHeight;
     
     DrawComponents.add(new ODrawComponentText(Pos_X, Pos_Y, FontType, Words, WordsBox_Width, WordsBox_Height, LineSpacing, WordsBox_Alignment));

     CurrY=CurrY+WordsBox_Height; if(EnablePostAddLineSpacing){CurrY=CurrY+PostAddLineSpacing;}
     
     processNextOperation(KeepPrinting, CloseTable, 0);
     
     break;
    }
    
    // Operation with check
    PreAddLineSpacing=0; PostAddLineSpacing=0;
    Pos_X=BaseX;
    
    processed=true;
    do{
     if(CurrOperation==Op_Main){CurrTable=Table_Main; break;}
     
     if(CurrOperation==Op_ItemIn_CategoryHeader){CurrTable=Table_ListItemCategoryHeader; Pos_X=Pos_X+TableListXIndent; PreAddLineSpacing=ItemCategoryAddLineSpacing; break;}
     if(CurrOperation==Op_ItemIn_List){CurrTable=Table_ListItem; Pos_X=Pos_X+TableListXIndent; break;}
     
     if(CurrOperation==Op_ItemOut_CategoryHeader){CurrTable=Table_ListItemCategoryHeader; Pos_X=Pos_X+TableListXIndent; PreAddLineSpacing=ItemCategoryAddLineSpacing; break;}
     if(CurrOperation==Op_ItemOut_List){CurrTable=Table_ListItem; Pos_X=Pos_X+TableListXIndent; break;}
     
     processed=false;
    }while(false);
    if(processed){
     if(IsANewColumnar){IsANewColumnar=false;}
     else{if(EnablePreAddLineSpacing){CurrY=CurrY+PreAddLineSpacing;}}
     
     Pos_Y=BaseY+CurrY;
     
     CurrTable.Value.insertARow(CurrTable.Value.Rows.size(), TableNewRow);
     
     processNextOperation(KeepPrinting, CloseTable, CurrTable.Value.Height);
     
     if(CloseTable.Value){
      DrawComponents.addElement(new ODrawComponentTable(Pos_X, Pos_Y, CurrTable.Value));
      CurrY=CurrY+CurrTable.Value.Height; if(EnablePostAddLineSpacing){CurrY=CurrY+PostAddLineSpacing;}
      CurrTable.Value=CurrTable.Value.createNewTable();
     }
     
     break;
    }
   }while(false);
   
   if(!KeepPrinting.Value){break;}
   
  }while(KeepPrinting.Value);
		return false;
 }
 void preInitLayoutVarDefault(){
  EnablePreAddLineSpacing=true;
  EnablePostAddLineSpacing=true;
 }
 void postInitLayoutVarDefault(){
  if(TableNewRow==null){TableNewRow=TableNewRow2;}
 }
 void processNextOperation(VBoolean KeepPrinting, VBoolean CloseTable, double CurrDrawComponentHeight) throws Exception{
  double NextDrawComponentHeight;
  int BefOp;
  
  NextDrawComponentHeight=0;
  BefOp=CurrOperation;
  CloseTable.Value=false;
  TableNewRow=null;
  
  preInitLayoutVarDefault();
  
  do{
   
   // List Items Out
   if(OptList_Item){
    // from ... next to 'list_item_out_header'
    if(CurrOperation==Op_Main){
     preparePrintItem(true);
     if(OptList_ItemCategorized){
      prepareItemCategorized(true);
      if(getItemNextCategory(true)){
       CurrOperation=Op_ItemOut_Header; EnablePostAddLineSpacing=false;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
     else{
      queryItem(true);
      if(getNextItem(true)){
       CurrOperation=Op_ItemOut_Header;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
       break;
      }
     }
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_out_header' next to 'list_item_out_category_header'
     if(CurrOperation==Op_ItemOut_Header){CurrOperation=Op_ItemOut_CategoryHeader; TableNewRow=TableNewRow3; break;}
    }
    
    // from ... next to 'list_item_out_data'
    if(CurrOperation==Op_ItemOut_Header || CurrOperation==Op_ItemOut_CategoryHeader){
     CurrOperation=Op_ItemOut_List; break;
    }

    // from 'list_item_out_data' next to 'list_item_out_data'
    if(CurrOperation==Op_ItemOut_List){
     if(getNextItem(true)){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_out_category_summary' next to 'list_item_out_category_header'
     if(CurrOperation==Op_ItemOut_List){
      if(getItemNextCategory(true)){
       CurrOperation=Op_ItemOut_CategoryHeader; TableNewRow=TableNewRow3;
       NextDrawComponentHeight=ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
    }
   }
   
   // List Items In
   if(OptList_Item){
    // from ... next to 'list_item_in_header'
    if(CurrOperation==Op_Main || CurrOperation==Op_ItemOut_List){
     preparePrintItem(false);
     if(OptList_ItemCategorized){
      prepareItemCategorized(false);
      if(getItemNextCategory(false)){
       CurrOperation=Op_ItemIn_Header; EnablePostAddLineSpacing=false;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
     else{
      queryItem(false);
      if(getNextItem(false)){
       CurrOperation=Op_ItemIn_Header;
       NextDrawComponentHeight=MainToDetailAddLineSpacing+NormalHeight+PostTextAddLineSpacing+TableNewRow2.Height;
       break;
      }
     }
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_in_header' next to 'list_item_in_category_header'
     if(CurrOperation==Op_ItemIn_Header){CurrOperation=Op_ItemIn_CategoryHeader; TableNewRow=TableNewRow3; break;}
    }
    
    // from ... next to 'list_item_in_data'
    if(CurrOperation==Op_ItemIn_Header || CurrOperation==Op_ItemIn_CategoryHeader){CurrOperation=Op_ItemIn_List; break;}

    // from 'list_item_in_data' next to 'list_item_in_data'
    if(CurrOperation==Op_ItemIn_List){
     if(getNextItem(false)){NextDrawComponentHeight=TableNewRow2.Height; break;}
    }
    
    if(OptList_ItemCategorized){
     // from 'list_item_in_category_summary' next to 'list_item_in_category_header'
     if(CurrOperation==Op_ItemIn_List){
      if(getItemNextCategory(false)){
       CurrOperation=Op_ItemIn_CategoryHeader; TableNewRow=TableNewRow3;
       NextDrawComponentHeight=ItemCategoryAddLineSpacing+TableNewRow3.Height+TableNewRow2.Height;
       break;
      }
     }
    }
   }
   
   // from ... next to 'main'
   if(CurrOperation==Op_Main || CurrOperation==Op_ItemOut_List || CurrOperation==Op_ItemIn_List){
    if(!getNextMain()){KeepPrinting.Value=false; break;}
    CurrOperation=Op_Main;
    NextDrawComponentHeight=TableNewRow2.Height;
    break;
   }
  }while(false);
  
  postInitLayoutVarDefault();
  
  if(checkOverColumnarHeight(CurrDrawComponentHeight+NextDrawComponentHeight)){KeepPrinting.Value=false;}
  if(CurrOperation!=BefOp || KeepPrinting.Value==false){CloseTable.Value=true;}
 }
 protected void addFooter() throws Exception{
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  PText.fillStringToChars(TxtPage, "~", PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  if(IsEndPrinting){return false;}
  return true;
 }
 protected void clearVar(){
  Id=null;
  IdQ=null;
  ItemCategories=null;
  ItemIdsStr=null;
  ItemList=null;
  PrintedItems=null;
  TableNewRow=null;
  TableNewRow2=null;
  TableNewRow3=null;
  try{Rs2.close();}catch(Exception E){} Rs2=null;
  try{Stm2.close();}catch(Exception E){} Stm2=null;
 }
 
 // additional private methods
 
 // Main
 void saveId(){
  StringBuilder strb=new StringBuilder();
  strb=strb.append(Id.pop().toString());
  if(!Id.isEmpty()){
   do{
    strb=strb.append(","+Id.pop().toString());
   }while(!Id.isEmpty());
  }
  IdQ=strb.toString();
 }
 private void queryMain() throws Exception{
  String con;
  
  con=" where Id in("+IdQ+")";
  
  Rs=Stm.executeQuery(
   "select tb2.*, Count(RuleOfConvXSideB.RuleOfConv) as 'SideB_ItemsCount' from "+
    "(select tb1.*, Count(RuleOfConvXSideA.RuleOfConv) as 'SideA_ItemsCount' from "+
     "(select Id, Name, IsActive, LastUpdate from RuleOfConv"+con+") as tb1 "+
    "left join RuleOfConvXSideA on tb1.Id=RuleOfConvXSideA.RuleOfConv group by tb1.Id) as tb2 "+
   "left join RuleOfConvXSideB on tb2.Id=RuleOfConvXSideB.RuleOfConv group by tb2.Id "+
   "order by Name asc");
 }
 private boolean getNextMain() throws Exception{
  int insertpos;
  ODimension dim;
  
  if(!Rs.next()){IsEndPrinting=true; return false;}
  
  CurrMain_Id=Rs.getLong(1);
  CurrMain_Info.Name=Rs.getString(2);
  CurrMain_Info.IsActive=Rs.getBoolean(3);
  CurrMain_Info.LastUpdate=Rs.getDate(4);
  CurrMain_InfoItemOutCount=Rs.getInt(5);
  CurrMain_InfoItemInCount=Rs.getInt(6);
  
  generateMainDescription();
  
  TableNewRow2=new ODrawTableRow(0, Table_Main.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PointOfMain,
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  TableNewRow2.setCell(1, new ODrawTableCellText(generateMainDescription(),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop), false, 1, true, 0, true, 1.0, 1, '~'));
  
  insertpos=Table_Main.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_Main.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_Main.Value.Inset.InsetTop+Table_Main.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_Main.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_Main.Value.Inset.InsetTop+Table_Main.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_Main.Value, insertpos);
  }
  
  return true;
 }
 String generateMainDescription(){
  String ret;
  StringBuilder strb1, strb2;
  boolean first;
  
  strb1=new StringBuilder();
  strb1.append(CurrMain_Info.Name);
  
  strb2=new StringBuilder(); first=true;
  if(Opt_IsActive){
   if(first){first=false;}else{strb2.append(", ");}
   strb2.append(PText.getString(CurrMain_Info.IsActive, "A", "-"));
  }
  if(Opt_LastUpdate){
   if(first){first=false;}else{strb2.append(", ");}
   strb2.append(PText.getString(CurrMain_Info.LastUpdate!=null, PText.dateToString(CurrMain_Info.LastUpdate, 1), "-"));
  }
  
  ret=strb1.toString()+PText.getString(strb2.length()!=0, " {"+strb2.toString()+"}", "");
  return ret;
 }
 
 // Item
 private void preparePrintItem(boolean IsItemOut){
  PrintedItems=new OQuickListOfLong(1024, 1024, true, false);
 }
 private void getItemIds(boolean IsItemOut) throws Exception{
  StringBuilder strb;
  long ItemId;
  String DbItem=PText.getString(IsItemOut, DbItemOut, DbItemIn);
  
  ItemIdsCount=0;
  ItemIdsStr=null;
  
  Rs2=Stm2.executeQuery("select Item from "+DbItem+" where RuleOfConv="+CurrMain_Id);
  
  if(!Rs2.next()){return;}
  
  strb=new StringBuilder();
  do{
   if(ItemIdsCount!=0){strb.append(",");}

   ItemId=Rs2.getLong(1);
   strb.append(ItemId);

   ItemIdsCount=ItemIdsCount+1;
  }while(Rs2.next());
  ItemIdsStr=strb.toString();
 }
 private void getItemCategories(boolean IsItemOut) throws Exception{
  OIdName CategoryOfItem;
  boolean ThereIsNull;
  
  ItemCategories=new Vector();
  ItemCurrCategory=-1;
  
  if(ItemIdsCount==0){return;}
  
  Rs2=Stm2.executeQuery(
   "select CategoryOfItem, Name from "+
    "(select CategoryOfItem from "+
     "(select Id as 'ItemId' from Item where Id in("+ItemIdsStr+")) as tb1 "+
    "left join ItemXCategory on tb1.ItemId=ItemXCategory.Item group by CategoryOfItem) as tb2 "+
   "left join CategoryOfItem on tb2.CategoryOfItem=CategoryOfItem.Id order by Name asc");
  
  if(!Rs2.next()){throw new Exception();}
  
  ThereIsNull=false;
  do{
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=Rs2.getLong(1);
   CategoryOfItem.Name=Rs2.getString(2);
   if(Rs2.wasNull()){ThereIsNull=true;}
   else{ItemCategories.addElement(CategoryOfItem);}
  }while(Rs2.next());
  if(ThereIsNull){
   CategoryOfItem=new OIdName();
   CategoryOfItem.Id=-1;
   CategoryOfItem.Name="Tidak didefenisikan";
   ItemCategories.addElement(CategoryOfItem);
  }
 }
 private void prepareItemCategorized(boolean IsItemOut) throws Exception{
  getItemIds(IsItemOut);
  getItemCategories(IsItemOut);
 }
 private void fillItemCategorySummary(boolean IsItemOut, int Count){
  ItemListItemCount=Count;
 }
 private void clearItemCategorySummary(boolean IsItemOut){
  ItemListItemCount=0;
 }
 private boolean getItemNextCategory(boolean IsItemOut) throws Exception{
  boolean ThereIs;
  
  ThereIs=false;
  do{
   
   if(ItemCurrCategory<ItemCategories.size()){
    ItemCurrCategory=ItemCurrCategory+1;
    clearItemCategorySummary(IsItemOut);
   }
   
   if(ItemCurrCategory==ItemCategories.size()){break;}
   
   queryItem(IsItemOut);
   if(getNextItem(IsItemOut)){ThereIs=true; break;}
   
  }while(!ThereIs);
  if(!ThereIs){return false;}
  
  getItemCategoryHeader(IsItemOut);
  return true;
 }
 private void getItemCategoryHeader(boolean IsItemOut){
  int insertpos;
  ODimension dim;
  
  TableNewRow3=new ODrawTableRow(0, Table_ListItemCategoryHeader.Value.ColumnsCount);
  TableNewRow3.setCell(0, new ODrawTableCellText(ItemCategories.elementAt(ItemCurrCategory).Name+" ( "+PText.intToString(ItemListItemCount)+" )",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItemCategoryHeader.Value.Rows.size();
  if(!TableNewRow3.preGenerateCellsDrawContents(Table_ListItemCategoryHeader.Value, insertpos)){
   TableNewRow3.clearAllCells();
   TableNewRow3.setHeight(CellAreaMinHeight+(Table_ListItemCategoryHeader.Value.Inset.InsetTop+Table_ListItemCategoryHeader.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow3.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItemCategoryHeader.Value, insertpos);
   TableNewRow3.setHeight(dim.getHeight()+(Table_ListItemCategoryHeader.Value.Inset.InsetTop+Table_ListItemCategoryHeader.Value.Inset.InsetBottom));
   TableNewRow3.generateCellsDrawContents(Table_ListItemCategoryHeader.Value, insertpos);
  }
 }
 private void queryItem(boolean IsItemOut) throws Exception{
  String Query;
  String con=null;
  String DbItem=PText.getString(IsItemOut, DbItemOut, DbItemIn);
  
  ItemList=new Vector();
  ItemListCurrItem=-1;
  
  // Item-Id, Item-Name, Qty, Stock-Unit
  Query=
   "select Item, ItemName, ItemQty, StockUnit.Name as 'ItemStockUnitName' from "+
    "(select tb1.*, Item.Name as 'ItemName', StockUnit from "+
     "(select Item as 'Item', Stock as 'ItemQty' from "+DbItem+" where RuleOfConv="+CurrMain_Id+") as tb1 "+
    "left join Item on tb1.Item=Item.Id) as tb2 "+
   "left join StockUnit on tb2.StockUnit=StockUnit.Id "+
   "order by ItemName asc";
  
  if(OptList_ItemCategorized){
   if(ItemCategories.elementAt(ItemCurrCategory).Id==-1){con=" is "+CCore.vNull;}
   else{con="="+ItemCategories.elementAt(ItemCurrCategory).Id;}
   Query=
    "select c1.*, CategoryOfItem from "+
     "("+Query+") as c1 "+
    "left join ItemXCategory on c1.Item=ItemXCategory.Item where CategoryOfItem"+con+" "+
    "order by ItemName asc";
  }
  
  if(PDatabase.queryToRows(Stm2, Query, ItemList,
   PCore.primArr(CCore.TypeLong, CCore.TypeString, CCore.TypeDouble, CCore.TypeString),
   null, false, null, null, false, false, null, -1, false, -1, true, true, false, PrintedItems, 0)==-1){throw new Exception();}
  
  fillItemCategorySummary(IsItemOut, ItemList.size());
 }
 private boolean getNextItem(boolean IsItemOut) throws Exception{
  int insertpos;
  ODimension dim;
  Object[] objs;
  long ItemId; String ItemName; double ItemQty; String ItemStockUnit;
  
  if(ItemListCurrItem<ItemList.size()){ItemListCurrItem=ItemListCurrItem+1;;}
  
  if(ItemListCurrItem==ItemList.size()){return false;}
  
  objs=ItemList.elementAt(ItemListCurrItem);
  ItemId=PCore.objLong(objs[0], -1L);
  ItemName=PCore.objString(objs[1], null);
  ItemQty=PCore.objDouble(objs[2], 0D);
  ItemStockUnit=PCore.objString(objs[3], null);
  
  TableNewRow2=new ODrawTableRow(0, Table_ListItem.Value.ColumnsCount);
  TableNewRow2.setCell(0, new ODrawTableCellText(PText.getString(IsItemOut, PointOfListItemOut, PointOfListItemIn),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(1, new ODrawTableCellText(ItemName+" ("+ItemId+")",
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  TableNewRow2.setCell(2, new ODrawTableCellText(PText.priceToString(ItemQty),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  TableNewRow2.setCell(3, new ODrawTableCellText(PText.getString(ItemStockUnit, "", false),
   FontType, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  
  insertpos=Table_ListItem.Value.Rows.size();
  if(!TableNewRow2.preGenerateCellsDrawContents(Table_ListItem.Value, insertpos)){
   TableNewRow2.clearAllCells();
   TableNewRow2.setHeight(CellAreaMinHeight+(Table_ListItem.Value.Inset.InsetTop+Table_ListItem.Value.Inset.InsetBottom));
  }
  else{
   dim=TableNewRow2.calculatePreGeneratedCellsDrawContentsDimension(Table_ListItem.Value, insertpos);
   TableNewRow2.setHeight(dim.getHeight()+(Table_ListItem.Value.Inset.InsetTop+Table_ListItem.Value.Inset.InsetBottom));
   TableNewRow2.generateCellsDrawContents(Table_ListItem.Value, insertpos);
  }
  
  return true;
 }

}