import java.util.Vector;

public class VVectorOfObjects {

 Vector<Object[]> Value;
 
 public VVectorOfObjects(){}
 public VVectorOfObjects(Vector<Object[]> Value) {this.Value = Value;}
 
}