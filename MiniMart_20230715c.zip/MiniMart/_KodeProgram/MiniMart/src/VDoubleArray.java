public class VDoubleArray {
 
 double[] Value;
 
 public VDoubleArray(){}
 public VDoubleArray(double[] Value){this.Value=Value;}
 
}