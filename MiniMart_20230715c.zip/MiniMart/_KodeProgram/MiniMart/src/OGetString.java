public abstract class OGetString {
 
 public abstract String getString(String Word);
 
}