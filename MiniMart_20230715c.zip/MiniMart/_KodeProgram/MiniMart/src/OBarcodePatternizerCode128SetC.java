public class OBarcodePatternizerCode128SetC extends OBarcodePatternizer {
 
 /*
  Code128 Set C
  
  meaning - value - pattern index (follow value index)
  
  ( full list )
  
       00 -     0 -       0
  ....
       94 -    94 -      94
       95 -    95 -      95
  ....
  Stop    -   106 -     106
  
  ( important "meaning" )
  
       00 -     0 -       0
  ....
       94 -    94 -      94
       95 -    95 -      95
  ....
       99 -    99 -      99
  Start-C -   105 -     105
  Stop    -   106 -     106
  
  note :
  + Each Value has fixed Barcode Pattern, for example :
    - Value 0 = Barcode Pattern 1011001001.
    - Value 1 = Barcode Pattern 1111001001.
  
 */
 
 public OBarcodePatternizerCode128SetC(){
  Patterns=new OBarcodePatterns(OBarcodePatternsCode128.getStandardPatterns(), OBarcodePatternsCode128.getStandardSpecification());
 }
 
 protected OBarcodePatterns patternizing(){
  // max digit of Number <= 18, MinimalDigitCount >=1 && <=18
  String[] ret;
  String word;
  long sum;
  int temp, value;
  
  // build string from number
  temp=String.valueOf(Number).length();
  if(temp<MinimalDigitCount){temp=MinimalDigitCount;}
  if(temp%2!=0){temp=temp+1;}
  word=PText.paddingNumber(Number, temp);
  
  // create return
  ret=new String[(word.length()/2)+3]; // 3 = start + checksum + stop
  
  // fill patterns
   // start-c
  ret[0]=Patterns.Patterns[valueToPatternIndex(105)];
  sum=105;
  
   // data
  temp=0;
  do{
   value=meaningToValue(word, temp*2);
   ret[1+temp]=Patterns.Patterns[valueToPatternIndex(value)];
   
   sum=sum+value*(temp+1);
   
   temp=temp+1;
  }while(temp*2!=word.length());
  
   // checksum
  ret[1+temp]=Patterns.Patterns[valueToPatternIndex((int)(sum%103))];
  temp=temp+1;
  
   // stop
  ret[1+temp]=Patterns.Patterns[valueToPatternIndex(106)];
  
  return new OBarcodePatterns(ret, OBarcodePatternsCode128.getStandardSpecification());
 }
 
 private int meaningToValue(String Word, int WordIndex){
  // translate from meaning (a pair of number) to pattern index
  return (Word.charAt(WordIndex)-48)*10 + (Word.charAt(WordIndex+1)-48);
 }
 private int valueToPatternIndex(int Value){return Value;}

}