import java.awt.Component;
import java.awt.HeadlessException;
import java.io.File;
import javax.swing.JFileChooser;

public class XFormFileChooser extends JFileChooser {

 public XFormFileChooser(){super();}
 
 public int showDialog(Component parent, String approveButtonText) throws HeadlessException{
  // clear the file selection, both in List & in TextBox
  File file=new File("");
  File[] files={file};
  setSelectedFile(file);
  setSelectedFiles(files);
  
  //
  return super.showDialog(parent, approveButtonText);
 }

}