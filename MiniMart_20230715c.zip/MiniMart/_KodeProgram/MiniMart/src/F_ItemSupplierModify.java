import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class F_ItemSupplierModify extends XFormDialog
 implements OFormSupportsComponentShortcut{
 
 // set
 int wMode; // 0 item-new supplier, 1 item-modify supplier, 2 supplier-new item, 3 supplier-modify item
 long wId;
 String wName;
 long wChooseId;
 String wChooseName;
 Date wUpdate;
 double wBuyPrc;
 String wBuyPriceComment;
 boolean wActive;
 
 // get
 long ChooseIdTyped;
 long ChooseId;
 String ChooseName;
 OGregorianCalendar Update;
 double BuyPrc;
 String BuyPriceComment;
 boolean Active;
 
 int[] TF_ChooseId_ShortcutKeys;

 /**
  * Creates new form F_ItemSupplierModify
  */
 public F_ItemSupplierModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  TF_ChooseId_ShortcutKeys=PCore.primArr(KeyEvent.VK_SPACE);
  
  clearComponents();
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_ChooseId, Btn_Choose,
    CB_Active,
    CB_UpdateOn, TF_Year, ComboBox_Month, ComboBox_Day, Btn_Today,
    TF_BuyPrc,
    TA_BuyPriceComment,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  Lbl_UpdateOn.setForeground(CGUI.Color_Label_InputRight);
  CB_UpdateOn.setSelected(false); enableInputDate(CB_UpdateOn.isSelected());
  TF_Year.setText(""); ComboBox_Month.setSelectedIndex(0); ComboBox_Day.setSelectedIndex(0);
  TF_Id.setText(""); TF_Name.setText("");
  Lbl_Choose.setForeground(CGUI.Color_Label_InputRight); TF_ChooseId.setText(""); TF_ChooseName.setText("");
  Lbl_BuyPrc.setForeground(CGUI.Color_Label_InputRight); TF_BuyPrc.setText(PText.doubleToString(0, true));
  Lbl_BuyPriceComment.setForeground(CGUI.Color_Label_InputRight); TA_BuyPriceComment.setText("");
  CB_Active.setSelected(CApp.Default_ItemSupplier_Active);
  clearSetVariables();
 }
 void clearSetVariables(){
  wName=null;
  wChooseName=null;
  wBuyPriceComment=null;
  wUpdate=null;
 }

 private void enableInputDate(boolean Enabled){
  TF_Year.setEnabled(Enabled);
  ComboBox_Month.setEnabled(Enabled);
  ComboBox_Day.setEnabled(Enabled);
 }
 void changeChooseId(){
  long Id;
  OInfoItem ItemInfo;
  
  try{
   Id=Long.parseLong(TF_ChooseId.getText());
   if(Id!=ChooseIdTyped){
    ChooseIdTyped=Id;
    if(wMode==0 || wMode==1){ChooseName=PDatabase.getNameFromId(IFV.Stm, "Subject", Id);}
    else{
     ItemInfo=PMyShop.getItemInfo(IFV.Stm, ChooseIdTyped, false);
     ChooseName=null;
     if(ItemInfo!=null){ChooseName=ItemInfo.Name; Id=ItemInfo.PrimaryId;}
    }
    if(ChooseName!=null){
     ChooseId=Id;
     TF_ChooseName.setText(ChooseName);
    }
    else{
     ChooseId=-1;
     TF_ChooseName.setText("");
    }
   }
  }
  catch(Exception E){
   ChooseId=-1;
   ChooseIdTyped=ChooseId;
   TF_ChooseName.setText("");
  }
 }
 public void fireKeyAction(Component Cmp, KeyEvent e){
  if(Cmp==TF_ChooseId){TF_ChooseIdKeyPressed(e);}
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  Lbl_Choose = new javax.swing.JLabel();
  TF_ChooseId = new javax.swing.JTextField();
  TF_Year = new javax.swing.JTextField();
  ComboBox_Month = new javax.swing.JComboBox();
  ComboBox_Day = new javax.swing.JComboBox();
  Lbl_BuyPriceComment = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_BuyPriceComment = new javax.swing.JTextArea();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Btn_Choose = new javax.swing.JButton();
  CB_UpdateOn = new javax.swing.JCheckBox();
  TF_Id = new javax.swing.JTextField();
  Lbl_ = new javax.swing.JLabel();
  Btn_Today = new javax.swing.JButton();
  TF_ChooseName = new javax.swing.JTextField();
  TF_Name = new javax.swing.JTextField();
  Lbl_ChooseIdHelp = new javax.swing.JLabel();
  Lbl_BuyPriceCommentHelp = new javax.swing.JLabel();
  Lbl_UpdateOn = new javax.swing.JLabel();
  CB_Active = new javax.swing.JCheckBox();
  Lbl_Active = new javax.swing.JLabel();
  TF_BuyPrc = new javax.swing.JTextField();
  Lbl_BuyPrc = new javax.swing.JLabel();
  Lbl_BuyPrcHelp = new javax.swing.JLabel();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  Lbl_Choose.setText("Pilih Brg / Sup");
  Lbl_Choose.setRequestFocusEnabled(false);

  TF_ChooseId.setToolTipText("{Spasi} cari data");
  TF_ChooseId.addFocusListener(new java.awt.event.FocusAdapter() {
   public void focusGained(java.awt.event.FocusEvent evt) {
    TF_ChooseIdFocusGained(evt);
   }
   public void focusLost(java.awt.event.FocusEvent evt) {
    TF_ChooseIdFocusLost(evt);
   }
  });
  TF_ChooseId.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_ChooseIdKeyPressed(evt);
   }
  });

  TF_Year.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_YearKeyPressed(evt);
   }
  });

  ComboBox_Month.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  ComboBox_Month.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_MonthKeyPressed(evt);
   }
  });

  ComboBox_Day.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_Day.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_DayKeyPressed(evt);
   }
  });

  Lbl_BuyPriceComment.setText("Ket. Beli (Ops)");
  Lbl_BuyPriceComment.setToolTipText("");
  Lbl_BuyPriceComment.setRequestFocusEnabled(false);

  TA_BuyPriceComment.setColumns(20);
  TA_BuyPriceComment.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_BuyPriceComment.setLineWrap(true);
  TA_BuyPriceComment.setRows(5);
  TA_BuyPriceComment.setWrapStyleWord(true);
  TA_BuyPriceComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyPriceCommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_BuyPriceComment);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Btn_Choose.setText("...");
  Btn_Choose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Choose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_ChooseActionPerformed(evt);
   }
  });
  Btn_Choose.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_ChooseKeyPressed(evt);
   }
  });

  CB_UpdateOn.setToolTipText("centang opsi ini utk mengatur tanggal pembaruan");
  CB_UpdateOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_UpdateOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_UpdateOnActionPerformed(evt);
   }
  });
  CB_UpdateOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpdateOnKeyPressed(evt);
   }
  });

  TF_Id.setEditable(false);
  TF_Id.setBackground(new java.awt.Color(204, 255, 204));
  TF_Id.setHorizontalAlignment(javax.swing.JTextField.LEFT);

  Lbl_.setText("Barang / Suplier");
  Lbl_.setRequestFocusEnabled(false);

  Btn_Today.setText("Hari Ini");
  Btn_Today.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Today.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TodayActionPerformed(evt);
   }
  });
  Btn_Today.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TodayKeyPressed(evt);
   }
  });

  TF_ChooseName.setEditable(false);
  TF_ChooseName.setBackground(new java.awt.Color(204, 255, 204));
  TF_ChooseName.setHorizontalAlignment(javax.swing.JTextField.LEFT);
  TF_ChooseName.setToolTipText("");
  TF_ChooseName.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  TF_ChooseName.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    TF_ChooseNameMouseClicked(evt);
   }
  });

  TF_Name.setEditable(false);
  TF_Name.setBackground(new java.awt.Color(204, 255, 204));
  TF_Name.setHorizontalAlignment(javax.swing.JTextField.LEFT);

  Lbl_ChooseIdHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_ChooseIdHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_ChooseIdHelp.setText("(?)");
  Lbl_ChooseIdHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_ChooseIdHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_ChooseIdHelpMouseClicked(evt);
   }
  });

  Lbl_BuyPriceCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceCommentHelp.setText("(?)");
  Lbl_BuyPriceCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceCommentHelpMouseClicked(evt);
   }
  });

  Lbl_UpdateOn.setText("Tgl Pembaruan (Ops)");
  Lbl_UpdateOn.setRequestFocusEnabled(false);

  CB_Active.setText(" ");
  CB_Active.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Active.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ActiveKeyPressed(evt);
   }
  });

  Lbl_Active.setText("Aktif");

  TF_BuyPrc.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPrcKeyPressed(evt);
   }
  });

  Lbl_BuyPrc.setText("Harga Beli");

  Lbl_BuyPrcHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPrcHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPrcHelp.setText("(?)");
  Lbl_BuyPrcHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPrcHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPrcHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_Choose)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_ChooseIdHelp))
     .addComponent(Lbl_UpdateOn)
     .addComponent(Lbl_)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_BuyPriceComment)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPriceCommentHelp))
     .addComponent(Lbl_Active)
     .addGroup(layout.createSequentialGroup()
      .addComponent(Lbl_BuyPrc)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Lbl_BuyPrcHelp)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(TF_BuyPrc)
     .addGroup(layout.createSequentialGroup()
      .addComponent(CB_Active)
      .addGap(0, 0, Short.MAX_VALUE))
     .addComponent(jScrollPane1)
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addComponent(CB_UpdateOn)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(TF_Year, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_Month, 0, 311, Short.MAX_VALUE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(ComboBox_Day, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Today))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_Name)
       .addComponent(TF_ChooseName))
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_ChooseId)
        .addGap(0, 0, 0)
        .addComponent(Btn_Choose))
       .addComponent(TF_Id, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_)
     .addComponent(TF_Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(TF_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_Choose)
     .addComponent(TF_ChooseId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_Choose)
     .addComponent(Lbl_ChooseIdHelp)
     .addComponent(TF_ChooseName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Active)
     .addComponent(Lbl_Active))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addComponent(CB_UpdateOn, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_UpdateOn)
      .addComponent(TF_Year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(ComboBox_Month, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(ComboBox_Day, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
      .addComponent(Btn_Today)))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_BuyPrc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_BuyPrc)
     .addComponent(Lbl_BuyPrcHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_BuyPriceCommentHelp)
      .addComponent(Lbl_BuyPriceComment, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
     .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   switch(wMode){
    case 0 :
     // set title
     setTitle("Tambah Suplier Pada Barang");
     // set label id-name and components
     Lbl_.setText("Barang");
     TF_Id.setText(PText.separate(String.valueOf(wId), " - ", 5));
     TF_Name.setText(wName);
     // set label choose id-name and components
     TF_ChooseName.setToolTipText("klik utk melihat keterangan suplier");
     
     Lbl_Choose.setText("Pilih Suplier");
     ChooseId=-1;
     ChooseIdTyped=ChooseId;
     TF_ChooseId.setEnabled(false);
     
     PGUI.setDateComponent(new Date(), TF_Year, ComboBox_Month, ComboBox_Day);
     
     Btn_Choose.requestFocusInWindow();
     break;
    case 1 :
     // set title
     setTitle("Ubah Suplier Pada Barang");
     // set UpdateDate
     if(wUpdate!=null){
      CB_UpdateOn.setSelected(true);
      enableInputDate(CB_UpdateOn.isSelected());
      IFV.Cal.setNewTime(wUpdate);
      TF_Year.setText(String.valueOf(IFV.Cal.get(Calendar.YEAR)));
      ComboBox_Month.setSelectedIndex(IFV.Cal.get(Calendar.MONTH));
      ComboBox_Day.setSelectedIndex(IFV.Cal.get(Calendar.DAY_OF_MONTH)-1);
     }
     // set label id-name and components
     Lbl_.setText("Barang");
     TF_Id.setText(PText.separate(String.valueOf(wId), " - ", 5));
     TF_Name.setText(wName);
     // set label choose id-name and components
     TF_ChooseName.setToolTipText("klik utk melihat keterangan suplier");
     
     Lbl_Choose.setText("Pilih Suplier");
     ChooseId=wChooseId;
     ChooseName=wChooseName;
     ChooseIdTyped=ChooseId;
     TF_ChooseId.setEnabled(false);
     TF_ChooseName.setText(ChooseName);
     // set BuyPrice
     TF_BuyPrc.setText(PText.doubleToString(wBuyPrc, true));
     if(wBuyPriceComment!=null){TA_BuyPriceComment.setText(wBuyPriceComment);}
     // set Active
     CB_Active.setSelected(wActive);
     
     TA_BuyPriceComment.requestFocusInWindow();
     break;
    case 2 :
     // set title
     setTitle("Tambah Barang Pada Suplier");
     // set label id-name and components
     Lbl_.setText("Suplier");
     TF_Name.setText(wName);
     // set label choose id-name and components
     TF_ChooseName.setToolTipText("klik utk melihat keterangan barang");
     
     Lbl_Choose.setText("Pilih Barang");
     ChooseId=-1;
     ChooseIdTyped=ChooseId;
     TF_ChooseId.setEnabled(true);
     
     PGUI.setDateComponent(new Date(), TF_Year, ComboBox_Month, ComboBox_Day);
     
     Btn_Choose.requestFocusInWindow();
     break;
    case 3 :
     // set title
     setTitle("Ubah Barang Pada Suplier");
     // set UpdateDate
     if(wUpdate!=null){
      CB_UpdateOn.setSelected(true);
      enableInputDate(CB_UpdateOn.isSelected());
      IFV.Cal.setNewTime(wUpdate);
      TF_Year.setText(String.valueOf(IFV.Cal.get(Calendar.YEAR)));
      ComboBox_Month.setSelectedIndex(IFV.Cal.get(Calendar.MONTH));
      ComboBox_Day.setSelectedIndex(IFV.Cal.get(Calendar.DAY_OF_MONTH)-1);
     }
     // set label id-name and components
     Lbl_.setText("Suplier");
     TF_Name.setText(wName);
     // set label choose id-name and components
     TF_ChooseName.setToolTipText("klik utk melihat keterangan barang");
     
     Lbl_Choose.setText("Pilih Barang");
     ChooseId=wChooseId;
     ChooseName=wChooseName;
     ChooseIdTyped=ChooseId;
     TF_ChooseId.setEnabled(true);
     TF_ChooseId.setText(String.valueOf(ChooseIdTyped));
     TF_ChooseName.setText(ChooseName);
     // set BuyPrice
     TF_BuyPrc.setText(PText.doubleToString(wBuyPrc, true));
     if(wBuyPriceComment!=null){TA_BuyPriceComment.setText(wBuyPriceComment);}
     // set Active
     CB_Active.setSelected(wActive);
     
     TA_BuyPriceComment.requestFocusInWindow();
     break;
   }
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void CB_UpdateOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_UpdateOnActionPerformed
  enableInputDate(CB_UpdateOn.isSelected());
 }//GEN-LAST:event_CB_UpdateOnActionPerformed

 private void Btn_TodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_UpdateOn, TF_Year, ComboBox_Month, ComboBox_Day, false);
 }//GEN-LAST:event_Btn_TodayActionPerformed

 private void Lbl_ChooseIdHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_ChooseIdHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 18, 2, 0, 0, 0, false));
 }//GEN-LAST:event_Lbl_ChooseIdHelpMouseClicked

 private void Lbl_BuyPriceCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true));
 }//GEN-LAST:event_Lbl_BuyPriceCommentHelpMouseClicked

 private void Btn_ChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_ChooseActionPerformed
  // choose dialog to show
  if(wMode==0 || wMode==1){
   
   IFV.FSubject.wMode=1;
   IFV.FSubject.wDialogWithFItem=false;
   IFV.FSubject.wAllowMultipleSelection=false;
   
   if(IFV.FSubject.showForm()==false){return;}
   // get choosed parameter from dialog and fill components
   if(IFV.FSubject.DialogResult==1){
    ChooseId=IFV.FSubject.ChoosedId[0];
    ChooseName=IFV.FSubject.ChoosedName[0];
    ChooseIdTyped=ChooseId;
    TF_ChooseName.setText(ChooseName);
   }
  }
  else{
   IFV.FItem.wMode=1;
   IFV.FItem.wDialogWithFSubject=false;
   IFV.FItem.wAllowMultipleSelection=false;
   
   if(IFV.FItem.showForm()==false){return;}
   // get choosed parameter from dialog and fill components
   if(IFV.FItem.DialogResult==1){
    ChooseId=IFV.FItem.ChoosedId[0];
    ChooseName=IFV.FItem.ChoosedName[0];
    ChooseIdTyped=ChooseId;
    TF_ChooseId.setText(String.valueOf(ChooseIdTyped));
    TF_ChooseName.setText(ChooseName);
   }
  }
 }//GEN-LAST:event_Btn_ChooseActionPerformed

 private void TF_ChooseIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_ChooseIdKeyPressed
  int consumed=PNav.onKey_TF(this, TF_ChooseId, false, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Active)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Choose)));
  if(consumed==CNav.Ret_Consumed){return;}
  
  int key=evt.getKeyCode();
  if(key==KeyEvent.VK_ENTER){changeChooseId(); return;}
  if(key==KeyEvent.VK_SPACE){evt.consume(); Btn_ChooseActionPerformed(null); return;}
 }//GEN-LAST:event_TF_ChooseIdKeyPressed

 private void TF_ChooseIdFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ChooseIdFocusLost
  IFV.KeyboardManager.disableComponentShortcut();
  
  changeChooseId();
 }//GEN-LAST:event_TF_ChooseIdFocusLost

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  DialogResult=0;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean bool=true;
  String str;
  // check Inputs
  if(CB_UpdateOn.isSelected()){
   do{
    str=TF_Year.getText();
    if(PText.checkInput(str, false, 6, 2, 7, 0, 0)==false){bool=false; break;}
    if(IFV.Cal.setNewTime(Integer.parseInt(str), ComboBox_Month.getSelectedIndex(),
     ComboBox_Day.getSelectedIndex()+1)==false){bool=false; break;};
   }while(false);
   if(bool==true){Lbl_UpdateOn.setForeground(CGUI.Color_Label_InputRight);}
   else{Lbl_UpdateOn.setForeground(CGUI.Color_Label_InputWrong);}
  }
  if(ChooseId!=-1){Lbl_Choose.setForeground(CGUI.Color_Label_InputRight);}
  else{
   bool=false;
   Lbl_Choose.setForeground(CGUI.Color_Label_InputWrong);
  }
  if(PText.checkInput(TF_BuyPrc.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6)){
   Lbl_BuyPrc.setForeground(CGUI.Color_Label_InputRight);
  }
  else{
   bool=false;
   Lbl_BuyPrc.setForeground(CGUI.Color_Label_InputWrong);
  }
  str=TA_BuyPriceComment.getText();
  if(PText.checkInput(str, true, CApp.DbVarcharMaxSize, 0, 1, 1, 0)==true){
   Lbl_BuyPriceComment.setForeground(CGUI.Color_Label_InputRight);
  }
  else{
   bool=false;
   Lbl_BuyPriceComment.setForeground(CGUI.Color_Label_InputWrong);
  }
  // set get Variables
  if(bool==true){
   if(!CB_UpdateOn.isSelected()){Update=null;}else{Update=IFV.Cal;}
   BuyPrc=PText.parseDouble(TF_BuyPrc.getText(), 0D, 0D);
   if(str.length()!=0){BuyPriceComment=str;}else{BuyPriceComment=null;}
   Active=CB_Active.isSelected();
   DialogResult=1;
   clearComponents();
   Activ=false;
   setVisible(false);
  }
  else{
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !"+
    "\nSilahkan perbaiki masukan pada label berwarna merah !");
  }
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void TF_ChooseIdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TF_ChooseIdFocusGained
  IFV.KeyboardManager.enableComponentShortcut(this, TF_ChooseId, TF_ChooseId_ShortcutKeys);
 }//GEN-LAST:event_TF_ChooseIdFocusGained

 private void TF_ChooseNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TF_ChooseNameMouseClicked
  if(ChooseId==-1){return;}
  
  if(wMode==0 || wMode==1){
   PMyShop.viewFormInfo(ChooseId, IFV.FSubjectPreview);
  }
  else{
   PMyShop.viewFormInfo(ChooseId, IFV.FItemPreview);
  }
 }//GEN-LAST:event_TF_ChooseNameMouseClicked

 private void Lbl_BuyPrcHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPrcHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, CCore.CharsCount_Deci(), 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPrcHelpMouseClicked

 private void Btn_ChooseKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_ChooseKeyPressed
  PNav.onKey_Btn(this, Btn_Choose, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Active)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_ChooseId)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_ChooseKeyPressed

 private void CB_ActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ActiveKeyPressed
  PNav.onKey_CB(this, CB_Active, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_ChooseId, Btn_Choose)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_ActiveKeyPressed

 private void CB_UpdateOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpdateOnKeyPressed
  PNav.onKey_CB(this, CB_UpdateOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Active)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Year, Btn_Today)));
 }//GEN-LAST:event_CB_UpdateOnKeyPressed

 private void TF_YearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_YearKeyPressed
  PNav.onKey_TF(this, TF_Year, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Active)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_Month, Btn_Today)));
 }//GEN-LAST:event_TF_YearKeyPressed

 private void ComboBox_MonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_MonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_Month, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Year, CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_Day, Btn_Today)));
 }//GEN-LAST:event_ComboBox_MonthKeyPressed

 private void ComboBox_DayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_DayKeyPressed
  PNav.onKey_CmB(this, ComboBox_Day, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_Month, CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Today)));
 }//GEN-LAST:event_ComboBox_DayKeyPressed

 private void Btn_TodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TodayKeyPressed
  PNav.onKey_Btn(this, Btn_Today, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Active)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_Day, CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_TodayKeyPressed

 private void TF_BuyPrcKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPrcKeyPressed
  PNav.onKey_TF(this, TF_BuyPrc, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyPriceComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPrcKeyPressed

 private void TA_BuyPriceCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyPriceCommentKeyPressed
  PNav.onKey_TA(this, TA_BuyPriceComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyPriceCommentKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyPriceComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyPriceComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Choose;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_Today;
 private javax.swing.JCheckBox CB_Active;
 private javax.swing.JCheckBox CB_UpdateOn;
 private javax.swing.JComboBox ComboBox_Day;
 private javax.swing.JComboBox ComboBox_Month;
 private javax.swing.JLabel Lbl_;
 private javax.swing.JLabel Lbl_Active;
 private javax.swing.JLabel Lbl_BuyPrc;
 private javax.swing.JLabel Lbl_BuyPrcHelp;
 private javax.swing.JLabel Lbl_BuyPriceComment;
 private javax.swing.JLabel Lbl_BuyPriceCommentHelp;
 private javax.swing.JLabel Lbl_Choose;
 private javax.swing.JLabel Lbl_ChooseIdHelp;
 private javax.swing.JLabel Lbl_UpdateOn;
 private javax.swing.JTextArea TA_BuyPriceComment;
 private javax.swing.JTextField TF_BuyPrc;
 private javax.swing.JTextField TF_ChooseId;
 private javax.swing.JTextField TF_ChooseName;
 private javax.swing.JTextField TF_Id;
 private javax.swing.JTextField TF_Name;
 private javax.swing.JTextField TF_Year;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
