public class ODatabaseProcedure {
 
 String Name;
 boolean IsProcedure;
 ODatabaseVersion SinceVersion;

 public ODatabaseProcedure(String Name, boolean IsProcedure, ODatabaseVersion SinceVersion) {
  this.Name = Name;
  this.IsProcedure = IsProcedure;
  this.SinceVersion = SinceVersion;
 }
 
}