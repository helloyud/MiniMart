import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Vector;

public class OCsvStreamReader extends InputStreamReader {
 
 /*
  - Compatible with RFC-4180
  - Field Delimiter & Fields Separator must be a non white character
  - Records Separator is line break character ('\n', '\r')
  - Charset = UTF-8
  - Can read csv file with following format :
    
    a_field = [white_space][field_delimiter][field_content][field_delimiter][white_space]
    a_record = a_field[field_separator]a_field[field_separator] ... next fields
    
    a_record[records_separator/line_break]
    a_record[records_separator/line_break]
    ... next records [end_of_file]
 */
 
 static final String EmptyFieldValue=null;
 
 boolean IncludeWhiteSpaceInField;
 
 char FieldDelimiter;
 char[] FieldsSeparators;
 char[] RecordsSeparators;
 
 char LastReadChar;
 int LastReadChar_CharType;
 final int CharType_EndOfFile=1;
 final int CharType_RecordsSeparator=2;
 final int CharType_FieldsSeparator=3;
 final int CharType_FieldDelimiter=4;
 final int CharType_OtherWhiteSpace=5;
 final int CharType_OtherNonWhiteSpace=6;
 
 VBoolean IsBufferedLastReadFromFile;
 VInteger BufferedLastReadFromFile;
 
 StringBuilder Field;
 int FieldStart;
 int FieldEnd;
 boolean LastReadField_EmptyField;
 
 int LastReadRecord_FieldsCount;
 boolean LastReadRecord_EmptyRecord;
 StringBuilder LastReadRecord_TrackReading;
 
 //
 public OCsvStreamReader(InputStream is,
  char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators,
  boolean IncludeWhiteSpaceInField) throws UnsupportedEncodingException{
  super(is, CCore.CsvDefaultCharset);
  
  setSeparatorChar(FieldDelimiter, FieldsSeparators, RecordsSeparators);
  this.IncludeWhiteSpaceInField=IncludeWhiteSpaceInField;
  
  IsBufferedLastReadFromFile=new VBoolean(false); BufferedLastReadFromFile=new VInteger(0);
 }
 
 //
 public void setSeparatorChar(char FieldDelimiter, char[] FieldsSeparators, char[] RecordsSeparators){
  this.FieldDelimiter=FieldDelimiter;
  this.FieldsSeparators=FieldsSeparators;
  this.RecordsSeparators=RecordsSeparators;
 }
 
 //
 public Vector<String> readNextRecord(boolean WithResult) throws IOException{
  Vector<String> ret=null;
  
  if(WithResult){ret=new Vector();}
  LastReadRecord_FieldsCount=0;
  LastReadRecord_TrackReading=new StringBuilder();
  do{
   if(!readNextField(LastReadRecord_TrackReading)){throw new IOException();}
   if(WithResult){ret.addElement(processField());}
   LastReadRecord_FieldsCount=LastReadRecord_FieldsCount+1;
  }while(LastReadChar_CharType!=CharType_EndOfFile && LastReadChar_CharType!=CharType_RecordsSeparator);
  LastReadRecord_EmptyRecord=LastReadRecord_FieldsCount==1 && LastReadField_EmptyField;
  
  return ret;
 }
 public boolean readNextField(StringBuilder TrackReading) throws IOException{
  boolean ret=true;
  boolean loop;
  
  boolean with_delimiter;
  int delimiter_counter;
  
  Field=new StringBuilder();
  FieldStart=0; FieldEnd=0;

  do{
   // read white space
   loop=true;
   do{
    readNextChar(TrackReading);
    do{
     if(lastReadIsStopSign()){loop=false; break;}
     if(LastReadChar_CharType!=CharType_OtherWhiteSpace){loop=false;}
     Field.append(LastReadChar);
     FieldEnd=FieldEnd+1;
    }while(false);
   }while(loop);
   
   if(lastReadIsStopSign()){
    if(!IncludeWhiteSpaceInField){FieldStart=FieldEnd;}
    break;
   }
   
   // read opening delimiter
   with_delimiter=LastReadChar_CharType==CharType_FieldDelimiter;
   delimiter_counter=0;
   
   // without delimiter
   if(!with_delimiter){
    // trim field's trailing space
    if(!IncludeWhiteSpaceInField){FieldStart=FieldEnd-1;}
    
    // read field
    loop=true;
    do{
     readNextChar(TrackReading);
     do{
      if(lastReadIsStopSign()){loop=false; break;}
      /*
       If there is a FieldDelimiter character in a field, then the field must be surrounded by FieldDelimiter.
       So in this case (case without delimiter), there shouldn't be any FieldDelimiter character in the field.
       But here, i just create this code / step to anticipate if there are some wrong inputs from the user.
      */
      if(LastReadChar_CharType!=CharType_FieldDelimiter){
       if(delimiter_counter==1){loop=false; break;}
      }
      else{
       if(delimiter_counter==0){delimiter_counter=1; break;}else{delimiter_counter=0;}
      }
      Field.append(LastReadChar);
      FieldEnd=FieldEnd+1;
     }while(false);
    }while(loop);

    if(delimiter_counter==1){ret=false; break;}
    
    // trim field's tailing space
    if(!IncludeWhiteSpaceInField){
     if(PText.isWhiteSpace(Field.charAt(FieldEnd-1))){
      do{
       FieldEnd=FieldEnd-1;
      }while(PText.isWhiteSpace(Field.charAt(FieldEnd-1)));
     }
    }
    
    break;
   }

   // with delimiter
   FieldStart=FieldEnd;
   
   loop=true;
   do{
    readNextChar(TrackReading);
    do{
     if(LastReadChar_CharType==CharType_EndOfFile){loop=false; break;}
     if(LastReadChar_CharType!=CharType_FieldDelimiter){
      if(delimiter_counter==1){loop=false; break;}
     }
     else{
      if(delimiter_counter==0){delimiter_counter=1; break;}else{delimiter_counter=0;}
     }
     Field.append(LastReadChar);
     FieldEnd=FieldEnd+1;
    }while(false);
   }while(loop);
   
   if(delimiter_counter==0){ret=false; break;}
   
   if(LastReadChar_CharType==CharType_OtherWhiteSpace){
    do{
     readNextChar(TrackReading);
    }while(LastReadChar_CharType==CharType_OtherWhiteSpace);
   }
   
   if(!lastReadIsStopSign()){ret=false; break;}
  }while(false);
  if(ret){LastReadField_EmptyField=FieldStart==FieldEnd;}
  
  return ret;
 }
 
 private void readNextChar(StringBuilder TrackReading) throws IOException{
  int ch;
  
  ch=PFile.readFromInputStream(this, IsBufferedLastReadFromFile, BufferedLastReadFromFile);
  LastReadChar=(char)ch;
  
  do{
   if(ch==-1){LastReadChar_CharType=CharType_EndOfFile; break;}
   if(TrackReading!=null){TrackReading.append(LastReadChar);}
   if(PText.findElement(RecordsSeparators, LastReadChar)!=-1){LastReadChar_CharType=CharType_RecordsSeparator; break;}
   if(PText.findElement(FieldsSeparators, LastReadChar)!=-1){LastReadChar_CharType=CharType_FieldsSeparator; break;}
   if(LastReadChar==FieldDelimiter){LastReadChar_CharType=CharType_FieldDelimiter; break;}
   if(PText.isWhiteSpace(LastReadChar)){LastReadChar_CharType=CharType_OtherWhiteSpace; break;}
   LastReadChar_CharType=CharType_OtherNonWhiteSpace;
  }while(false);
 }
 private boolean lastReadIsStopSign(){
  return LastReadChar_CharType==CharType_EndOfFile || LastReadChar_CharType==CharType_RecordsSeparator || LastReadChar_CharType==CharType_FieldsSeparator;
 }
 private String processField(){
  String ret=EmptyFieldValue;
  
  if(FieldStart!=FieldEnd){ret=Field.substring(FieldStart, FieldEnd);}
  
  return ret;
 }
 
 // decode file csv's text content that has been written by OCSVStreamWriter
 public static OValue readBoolean(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   if(PText.compare(Field, CCore.vTrueIndonesia, false)){ret.setDefinedNoError(true); break;}
   if(PText.compare(Field, CCore.vFalseIndonesia, false)){ret.setDefinedNoError(false); break;}
  }while(false);
  
  return ret;
 }
 public static OValue readInt(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  int it;
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   try{it=Integer.parseInt(Field);}catch(Exception E){break;}
   ret.setDefinedNoError(it);
  }while(false);
  
  return ret;
 }
 public static OValue readLong(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  long lg;
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   try{lg=Long.parseLong(Field);}catch(Exception E){break;}
   ret.setDefinedNoError(lg);
  }while(false);
  
  return ret;
 }
 public static OValue readDouble(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  double dbl;
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   try{dbl=Double.parseDouble(Field);}catch(Exception E){break;}
   ret.setDefinedNoError(dbl);
  }while(false);
  
  return ret;
 }
 public static OValue readChar(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   if(Field.length()!=1){break;}
   ret.setDefinedNoError(Field.charAt(0));
  }while(false);
  
  return ret;
 }
 public static OValue readString(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   ret.setDefinedNoError(Field);
  }while(false);
  
  return ret;
 }
 public static OValue readDate(String Field){
  OValue ret=new OValue(null, OValue.StateDefinedError);
  Date dt;
  
  do{
   if(Field==null){ret.setDefinedNull(null); break;}
   if(Field.length()==0){ret.setDefinedNull(null); break;}
   dt=PDate.parseDate(Field); if(dt==null){break;}
   ret.setDefinedNoError(dt);
  }while(false);
  
  return ret;
 }
 public static OValue getFieldValue(String Field, int Type){
  OValue ret=null;
  switch(Type){
   case CCore.TypeBoolean : ret=readBoolean(Field); break;
   case CCore.TypeInteger : ret=readInt(Field); break;
   case CCore.TypeLong : ret=readLong(Field); break;
   case CCore.TypeDouble : ret=readDouble(Field); break;
   case CCore.TypeChar : ret=readChar(Field); break;
   case CCore.TypeString : ret=readString(Field); break;
   case CCore.TypeDate : ret=readDate(Field); break;
  }
  return ret;
 }
 
}