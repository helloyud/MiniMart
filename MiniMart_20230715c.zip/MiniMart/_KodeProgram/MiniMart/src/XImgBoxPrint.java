import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;

public class XImgBoxPrint extends XImgBox{

 OAPage Pg;
 PageFormat PgFormat;
 
 int Dpi;
 
 public XImgBoxPrint(){
  super();
  setImageSource(null, null);
 }
 public void setDpi(int Dpi){this.Dpi=Dpi;}
 public int getDpi(){return Dpi;}
 public void setImageSource(OAPage Pg, PageFormat PgFormat){
  this.Pg=Pg;
  this.PgFormat=PgFormat;
  
  updateImageSource();
  updateImgSizeAndPosition(true);
 }
 protected boolean isImageSourceAvailable(){
  return (Pg!=null && PgFormat!=null);
 }
 protected BufferedImage readImageSource(){
  BufferedImage ret=null;
  Graphics2D graphics;
  double scalefactor=(double)Dpi/(double)72;
  
  try{
   ret=new BufferedImage((int)(scalefactor*PgFormat.getWidth()), (int)(scalefactor*PgFormat.getHeight()), BufferedImage.TYPE_INT_RGB);
   graphics=ret.createGraphics();
   graphics.setBackground(CGUI.White);
   graphics.clearRect(0, 0, ret.getWidth(), ret.getHeight());
   graphics.setColor(CGUI.Black);
   
   Pg.print2(graphics, PgFormat, false, scalefactor);
  }
  catch(Exception E){}
  
  return ret;
 }
 
}
