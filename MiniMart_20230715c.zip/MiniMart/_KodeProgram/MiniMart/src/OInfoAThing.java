public abstract class OInfoAThing
 implements Cloneable{
 
 OGetString GetNameMode;
 
 public abstract long[] getId();
 
 public void setGetNameMode(OGetString GetNameMode){this.GetNameMode=GetNameMode;}
 
}