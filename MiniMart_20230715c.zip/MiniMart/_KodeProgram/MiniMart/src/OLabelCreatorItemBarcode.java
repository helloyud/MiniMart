import java.awt.Graphics2D;
import java.util.Vector;

public class OLabelCreatorItemBarcode extends OLabelCreatorItem {
 
 
 
 
 
 // Ideal label size (in pixel)
 public static final double IdealLabelWidth_8   = OUnit.mm_to_pixel(25);
 public static final double IdealLabelWidth_13  = OUnit.mm_to_pixel(32.5);
 public static final double IdealLabelWidth_18  = OUnit.mm_to_pixel(35);
 
 public static final double IdealLabelHeight_s = OUnit.mm_to_pixel(13);
 public static final double IdealLabelHeight_m = OUnit.mm_to_pixel(15);
 public static final double IdealLabelHeight_l = OUnit.mm_to_pixel(17);
 
 final double SpaceFontToBarcode=OUnit.mm_to_pixel(0.3); // 0.4 mm
 
 int ItemCommentLineCount;
 final int MinItemCommentLineCount=2;
 final int MaxItemCommentLineCount=5;
 int ItemCommentFitFixedRight, ItemCommentFitFixedTop;
 double ItemCommentY;
 double ItemCommentAreaHeight;
 double BarcodeBoxY,
        BarcodeBoxHeight;

 
 
 
 
 public OLabelCreatorItemBarcode(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  BoxWidthMin=2*MarginHorizontal+CGraph.BarcodeWidthMin;
  BoxHeightMin=
   2*MarginVertical+
   CGraph.BarcodeHeightMin+
   SpaceFontToBarcode+
   MinItemCommentLineCount*TextHeight+(MinItemCommentLineCount-1)*TextLineSpacing;
 }
 protected void initDrawComponentsVariables(){
  super.initDrawComponentsVariables();
  
  ColumnsCountMax=55;
 }
 protected String getName(){return "ID) Barcode (EAN-8/13, Code-128)";}
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  OPaper papr;
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {8-s}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_8, IdealLabelHeight_s, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {13-s}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_13, IdealLabelHeight_s, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {18-s}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_18, IdealLabelHeight_s, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {8-m}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_8, IdealLabelHeight_m, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {13-m}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_13, IdealLabelHeight_m, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {18-m}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_18, IdealLabelHeight_m, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {8-l}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_8, IdealLabelHeight_l, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {13-l}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_13, IdealLabelHeight_l, 0, 0, 0, true, true, true, true, false));
  
  papr=CPrint.A4Half.cloneWithMargin(MgSt);
  papr.Description=papr.Description+" {18-l}";
  ret.addElement(new OPaperLabel(papr, IdealLabelWidth_18, IdealLabelHeight_l, 0, 0, 0, true, true, true, true, false));
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 5-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return false;}
 protected boolean isLabelRotatedInternalPaper(){return false;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 public boolean genLayoutVariables(){
  boolean ret=true;
  double dbl;

  dbl=MinItemCommentLineCount*TextHeight+(MinItemCommentLineCount-1)*TextLineSpacing;
  BarcodeBoxHeight=LabelHeight-(2*MarginVertical+SpaceFontToBarcode+dbl);
  if(BarcodeBoxHeight<CGraph.BarcodeHeightMin){return false;}
  if(BarcodeBoxHeight>CGraph.BarcodeHeightMax){BarcodeBoxHeight=CGraph.BarcodeHeightMax;}
  
  dbl=LabelHeight-(
   2*MarginVertical+
   BarcodeBoxHeight+
   SpaceFontToBarcode+
   MinItemCommentLineCount*TextHeight+(MinItemCommentLineCount-1)*TextLineSpacing);
  ItemCommentLineCount=MinItemCommentLineCount+(int)(dbl/(TextLineSpacing+TextHeight));
  if(ItemCommentLineCount>MaxItemCommentLineCount){ItemCommentLineCount=MaxItemCommentLineCount;}
  
  ColumnsCount=(int)((LabelWidth-2*MarginHorizontal)/TextWidth);
  if(ColumnsCount>ColumnsCountMax){ColumnsCount=ColumnsCountMax;}
  
  BarcodeBoxY=MarginVertical;
  
  ItemCommentY=BarcodeBoxY+BarcodeBoxHeight+SpaceFontToBarcode;
  ItemCommentAreaHeight=ItemCommentLineCount*TextHeight+(ItemCommentLineCount-1)*TextLineSpacing;
  ItemCommentFitFixedRight=(int)(0.5*ColumnsCount);
  ItemCommentFitFixedTop=(int)(0.5*ItemCommentLineCount); if(ItemCommentFitFixedTop<1){ItemCommentFitFixedTop=1;}
  
  BoxWidth=2*MarginHorizontal+ColumnsCount*TextWidth;
  BoxHeight=
   2*MarginVertical+
   BarcodeBoxHeight+
   SpaceFontToBarcode+
   ItemCommentAreaHeight;
  
  return ret;
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  OLabelDataItem Data;
  OBarcodePatterns patt;
  String Comment, str;
  Vector<String> CommentVect=null;
  int temp, count;
  double curr_y;
  
  g.setFont(Fon);
  
  Data=(OLabelDataItem)LabelData;
  
  patt=PMyShop.patternize(Data.ItemId);
  if(patt!=null){
   PGraphics.paintImageInBox(g, Scaled_BoxX+AreaX, Scaled_BoxY+BarcodeBoxY,
    PGraphics.cropHeightBarcode(true, patt.getBufferedImage(BarcodeBoxHeight, Scaling*AlreadyScaled), AreaWidth*Scaling*AlreadyScaled, BarcodeBoxHeight*Scaling*AlreadyScaled),
    true, null, 1, CGraph.Rotate_000Degree, AreaWidth, BarcodeBoxHeight, null, false);
  }
  
  Comment=Data.ItemName+" ("+Data.ItemId+")";
  if(ItemCommentLineCount==1){
   CommentVect=PCore.vect(PText.fitString(Comment, ColumnsCount, false, ItemCommentFitFixedRight, 1, '~'));
  }
  else{
   CommentVect=PText.fitMultiLine(
    PText.multiLine(Comment, ColumnsCount), ItemCommentLineCount, true, ItemCommentFitFixedTop,
    ColumnsCount, false, ColumnsCount-1, 1, '~');
  }
  
  count=CommentVect.size();
  curr_y=ItemCommentY+PGraphics.getInsetY(ItemCommentAreaHeight, Fon, count, TextLineSpacing, OAlignment.VerticalTop);
  temp=0;
  do{
   if(temp!=0){curr_y=curr_y+TextLineSpacing;}

   str=CommentVect.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+AreaX+PGraphics.getInsetX(AreaWidth, Fon, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+curr_y+TextAscent));
   curr_y=curr_y+TextHeight;

   temp=temp+1;
  }while(temp!=count);
 }
 
 
 
 
 
}