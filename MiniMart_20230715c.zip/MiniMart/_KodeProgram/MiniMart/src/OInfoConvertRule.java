import java.util.Date;
import java.util.Vector;

public class OInfoConvertRule {

 long Id;
 String Name;
 boolean IsActive;
 Date LastUpdate;
 
 Vector<Object[]> ListItemA;
 Vector<Object[]> ListItemB;
 
 void fillValuesFrom(OInfoConvertRule Other){
  if(Other==null){return;}
  
  Id=Other.Id;
  Name=Other.Name;
  IsActive=Other.IsActive;
  LastUpdate=Other.LastUpdate;
  
  ListItemA=Other.ListItemA;
  ListItemB=Other.ListItemB;
 }
 
 boolean compare(OInfoConvertRule Other, boolean CompareHeader, boolean CompareListItemA, boolean CompareListItemB){
  boolean ret=false;
  int[] CompareCols;
  
  do{
   if(Other==null){break;}
   
   if(CompareHeader){
    if(!PText.compare(Name, Other.Name, false)){break;}
    if(IsActive!=Other.IsActive){break;}
    if(PDate.grading(LastUpdate, Other.LastUpdate, 0)!=0){break;}
   }
   
   CompareCols=PCore.primArr(2);
   if(CompareListItemA){
    if(!PTable.compare(PMyShop.getConvertItems_ColumnsType(), ListItemA, Other.ListItemA, CompareCols, 3, 0)){break;}
   }
   if(CompareListItemB){
    if(!PTable.compare(PMyShop.getConvertItems_ColumnsType(), ListItemB, Other.ListItemB, CompareCols, 3, 0)){break;}
   }
   
   ret=true;
  }while(false);
  
  return ret;
 }
 
 void generateListItemsFromConverting(
  boolean ConvertingDirection, double ConvertingCount,
  Vector<Object[]> ListItemsOut, Vector<Object[]> ListItemsIn){
  ListItemA=generateListItemsFromConverting(true, ConvertingDirection, ConvertingCount, ListItemsOut, ListItemsIn);
  ListItemB=generateListItemsFromConverting(false, ConvertingDirection, ConvertingCount, ListItemsOut, ListItemsIn);
 }
 Vector<Object[]> generateListItemsFromConverting(
  boolean IsItemOut,
  boolean ConvRuleDirection, double ConvRuleCount,
  Vector<Object[]> ListItemsOut, Vector<Object[]> ListItemsIn){
  Vector<Object[]> ret;
  boolean ConvRuleDir;
  Vector<Object[]> Side;
  Vector<OTableCellUpdater> Updater;
  int[] ColumnsType=PMyShop.getConvertItems_ColumnsType();
  
  ConvRuleDir=ConvRuleDirection; if(!IsItemOut){ConvRuleDir=!ConvRuleDir;}
  Side=(Vector<Object[]>)PCore.subtituteBool(ConvRuleDir, ListItemsOut, ListItemsIn);
  
  ret=PCore.clone(Side);
  
  Updater=new Vector();
  Updater.addElement(
   new OTableCellUpdaterByCalculation(
    2,
    new OCalculationOperandTableCell(null, ret, ColumnsType, 2, 0, 0, 0, 0, 0, 0),
    new OCalculation(new OCalculationOperandConstanta(ConvRuleCount), CMath.Divide, false, 0))
  );
  PGUI.changeElements(ret, ColumnsType, PCore.newIntegerArrayInOrderedSequence(ret.size(), 0, 1), Updater);
  
  return ret;
 }
 Vector<Object[]> generateListItemsToConverting(
  boolean IsItemOut,
  boolean ConvRuleDirection, double ConvRuleCount){
  Vector<Object[]> ret;
  boolean ConvRuleDir;
  Vector<Object[]> Side;
  Vector<OTableCellUpdater> Updater;
  int[] ColumnsType=PMyShop.getConvertItems_ColumnsType();
  
  ConvRuleDir=ConvRuleDirection; if(!IsItemOut){ConvRuleDir=!ConvRuleDir;}
  Side=(Vector<Object[]>)PCore.subtituteBool(ConvRuleDir, ListItemA, ListItemB);
  
  ret=PCore.clone(Side);
  
  Updater=new Vector();
  Updater.addElement(
   new OTableCellUpdaterByCalculation(
    2,
    new OCalculationOperandTableCell(null, ret, ColumnsType, 2, 0, 0, 0, 0, 0, 0),
    new OCalculation(new OCalculationOperandConstanta(ConvRuleCount), CMath.Times, false, 0))
  );
  PGUI.changeElements(ret, ColumnsType, PCore.newIntegerArrayInOrderedSequence(ret.size(), 0, 1), Updater);
  
  return ret;
 }
 
}