import java.awt.event.ActionEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class F_ItemSupplierModifyMulti extends XFormDialog{
 
 // set
 int wDataCount;
 
 // get
 boolean ChangeUpdate; Date Update;
 boolean ChangeBuyPrc; double BuyPrc;
 boolean ChangeBuyPriceComment; boolean ChangeBuyPriceCommentSub; String BuyPriceCommentSub; String BuyPriceComment;
 boolean ChangeActive; boolean Active;

 /**
  * Creates new form F_ItemSupplierModify
  */
 public F_ItemSupplierModifyMulti(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  PGUI.selectRadioButton(CApp.Default_ItemSupplier_Active, RB_ActiveY, RB_ActiveN);
  CB_BuyPriceCommentSubActionPerformed(null);
  CB_UpdateOn.setSelected(true); CB_UpdateOnActionPerformed(null);
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    CB_Active, RB_ActiveY, RB_ActiveN,
    CB_Update, CB_UpdateOn, TF_Year, ComboBox_Month, ComboBox_Day, Btn_Today,
    CB_BuyPrc, TF_BuyPrc,
    CB_BuyPriceComment, TF_BuyPriceCommentSub, CB_BuyPriceCommentSub, TA_BuyPriceComment,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 void clearComponents(){
  CB_Update.setSelected(false); CB_Update.setForeground(CGUI.Color_Label_InputRight); TF_Year.setText(""); ComboBox_Month.setSelectedIndex(0); ComboBox_Day.setSelectedIndex(0);
  CB_BuyPrc.setSelected(false); CB_BuyPrc.setForeground(CGUI.Color_Label_InputRight); TF_BuyPrc.setText("");
  CB_BuyPriceComment.setSelected(false); CB_BuyPriceComment.setForeground(CGUI.Color_Label_InputRight); TF_BuyPriceCommentSub.setText(""); TA_BuyPriceComment.setText("");
  CB_Active.setSelected(false);
  clearSetVariables();
 }
 void clearSetVariables(){
  
 }
 
 void enableInputInTextField(boolean Enable, JTextField TF){
  TF.setEnabled(Enable);
  if(!TF.isEnabled()){TF.setText("");}
 }

 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  RG_Active = new javax.swing.ButtonGroup();
  TF_Year = new javax.swing.JTextField();
  ComboBox_Month = new javax.swing.JComboBox();
  ComboBox_Day = new javax.swing.JComboBox();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_BuyPriceComment = new javax.swing.JTextArea();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_BuyPriceCommentHelp = new javax.swing.JLabel();
  CB_Update = new javax.swing.JCheckBox();
  CB_BuyPriceComment = new javax.swing.JCheckBox();
  Lbl_DataCount = new javax.swing.JLabel();
  CB_BuyPriceCommentSub = new javax.swing.JCheckBox();
  TF_BuyPriceCommentSub = new javax.swing.JTextField();
  Btn_Today = new javax.swing.JButton();
  CB_UpdateOn = new javax.swing.JCheckBox();
  CB_Active = new javax.swing.JCheckBox();
  RB_ActiveY = new javax.swing.JRadioButton();
  RB_ActiveN = new javax.swing.JRadioButton();
  TF_BuyPrc = new javax.swing.JTextField();
  CB_BuyPrc = new javax.swing.JCheckBox();
  Lbl_BuyPrcHelp = new javax.swing.JLabel();

  setTitle("Ubah Data Dari Beberapa Barang-Supplier");
  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_Year.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_YearKeyPressed(evt);
   }
  });

  ComboBox_Month.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  ComboBox_Month.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_MonthKeyPressed(evt);
   }
  });

  ComboBox_Day.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  ComboBox_Day.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    ComboBox_DayKeyPressed(evt);
   }
  });

  TA_BuyPriceComment.setColumns(20);
  TA_BuyPriceComment.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
  TA_BuyPriceComment.setLineWrap(true);
  TA_BuyPriceComment.setRows(5);
  TA_BuyPriceComment.setWrapStyleWord(true);
  TA_BuyPriceComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyPriceCommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_BuyPriceComment);

  Btn_Cancel.setText("Batal {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_BuyPriceCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceCommentHelp.setText("(?)");
  Lbl_BuyPriceCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceCommentHelpMouseClicked(evt);
   }
  });

  CB_Update.setText("Tgl Pembaruan");
  CB_Update.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Update.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpdateKeyPressed(evt);
   }
  });

  CB_BuyPriceComment.setText("Ket. Beli");
  CB_BuyPriceComment.setToolTipText("");
  CB_BuyPriceComment.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyPriceComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyPriceCommentKeyPressed(evt);
   }
  });

  Lbl_DataCount.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_DataCount.setText("Mengubah <n> Data");

  CB_BuyPriceCommentSub.setText("Ganti Sub-Kata");
  CB_BuyPriceCommentSub.setToolTipText("centang opsi ini utk mengganti sub-kata");
  CB_BuyPriceCommentSub.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyPriceCommentSub.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyPriceCommentSubActionPerformed(evt);
   }
  });
  CB_BuyPriceCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyPriceCommentSubKeyPressed(evt);
   }
  });

  TF_BuyPriceCommentSub.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceCommentSubKeyPressed(evt);
   }
  });

  Btn_Today.setText("Hari Ini");
  Btn_Today.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Today.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_TodayActionPerformed(evt);
   }
  });
  Btn_Today.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_TodayKeyPressed(evt);
   }
  });

  CB_UpdateOn.setText(" ");
  CB_UpdateOn.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_UpdateOn.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_UpdateOnActionPerformed(evt);
   }
  });
  CB_UpdateOn.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_UpdateOnKeyPressed(evt);
   }
  });

  CB_Active.setText("Aktif");
  CB_Active.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_Active.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_ActiveKeyPressed(evt);
   }
  });

  RG_Active.add(RB_ActiveY);
  RB_ActiveY.setText("Ya");
  RB_ActiveY.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ActiveY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ActiveYKeyPressed(evt);
   }
  });

  RG_Active.add(RB_ActiveN);
  RB_ActiveN.setText("Tidak");
  RB_ActiveN.setMargin(new java.awt.Insets(0, 0, 0, 0));
  RB_ActiveN.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    RB_ActiveNKeyPressed(evt);
   }
  });

  TF_BuyPrc.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPrcKeyPressed(evt);
   }
  });

  CB_BuyPrc.setText("Harga Beli");
  CB_BuyPrc.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyPrc.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyPrcKeyPressed(evt);
   }
  });

  Lbl_BuyPrcHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPrcHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPrcHelp.setText("(?)");
  Lbl_BuyPrcHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPrcHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPrcHelpMouseClicked(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Lbl_DataCount)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel))
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(CB_Update)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_BuyPriceComment)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_BuyPriceCommentHelp))
       .addComponent(CB_Active)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_BuyPrc)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_BuyPrcHelp)))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_BuyPrc)
       .addGroup(layout.createSequentialGroup()
        .addComponent(RB_ActiveY)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(RB_ActiveN)
        .addGap(0, 0, Short.MAX_VALUE))
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_BuyPriceCommentSub)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CB_BuyPriceCommentSub))
       .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_UpdateOn)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_Year, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(ComboBox_Month, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(ComboBox_Day, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_Today)))))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Active)
     .addComponent(RB_ActiveY)
     .addComponent(RB_ActiveN))
    .addGap(9, 9, 9)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_Update)
     .addComponent(TF_Year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_Month, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(ComboBox_Day, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_Today)
     .addComponent(CB_UpdateOn))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_BuyPrc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyPrc)
     .addComponent(Lbl_BuyPrcHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BuyPriceComment)
     .addComponent(Lbl_BuyPriceCommentHelp)
     .addComponent(TF_BuyPriceCommentSub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CB_BuyPriceCommentSub))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok)
     .addComponent(Lbl_DataCount))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  if(Activ==false){
   Activ=true;
   PGUI.setDateComponent(new Date(), TF_Year, ComboBox_Month, ComboBox_Day);
   Lbl_DataCount.setText("Mengubah "+PText.intToString(wDataCount)+" Data");
   TA_BuyPriceComment.requestFocusInWindow();
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  DialogResult=0;
  clearComponents();
  Activ=false;
 }//GEN-LAST:event_formWindowClosing

 private void Lbl_BuyPriceCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null,
   PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 1, 1, 0, true)+"\n"+
   "- Dalam mode 'Ganti Sub-Kata', inputan 'Ganti Sub-Kata' harus diisi,\n"+
   "  sedangkan inputan 'Ket Hrg Beli' boleh diisi atau dikosongkan.\n"+
   "- Pengecekan 'Sub-Kata' yg akan diganti bersifat case-sensitive.");
 }//GEN-LAST:event_Lbl_BuyPriceCommentHelpMouseClicked

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  DialogResult=0;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  boolean IsValid;
  boolean CurrCheck=false;
  
  ChangeActive=CB_Active.isSelected();
  ChangeUpdate=CB_Update.isSelected();
  ChangeBuyPrc=CB_BuyPrc.isSelected();
  ChangeBuyPriceComment=CB_BuyPriceComment.isSelected();
  if(!ChangeActive && !ChangeUpdate && !ChangeBuyPrc && !ChangeBuyPriceComment){
   JOptionPane.showMessageDialog(null, "Belum ada parameter pengubahan yang dipilih !");
   return;
  }
  
  // check inputs validity
  IsValid=true;
  
  if(ChangeActive){
   Active=RB_ActiveY.isSelected();
  }
  
  if(ChangeUpdate){
   CurrCheck=true;
   Update=null;
   if(CB_UpdateOn.isSelected()){
    Update=PGUI.valueOfDateComponent(TF_Year, ComboBox_Month, ComboBox_Day);
    if(Update==null){CurrCheck=false;}
   }
   if(!CurrCheck){IsValid=false; CB_Update.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_Update.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeBuyPrc){
   CurrCheck=PText.checkInput(TF_BuyPrc.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6);
   if(CurrCheck){BuyPrc=PText.parseDouble(TF_BuyPrc.getText(), 0D, 0D);}
   if(!CurrCheck){IsValid=false; CB_BuyPrc.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_BuyPrc.setForeground(CGUI.Color_Label_InputRight);}
  }
  
  if(ChangeBuyPriceComment){
   BuyPriceComment=TA_BuyPriceComment.getText();
   ChangeBuyPriceCommentSub=CB_BuyPriceCommentSub.isSelected();
   if(!ChangeBuyPriceCommentSub){CurrCheck=PText.checkInput(BuyPriceComment, true, CApp.DbVarcharMaxSize, 0, 1, 1, 0);}
   else{
    BuyPriceCommentSub=TF_BuyPriceCommentSub.getText();
    CurrCheck=BuyPriceCommentSub.length()!=0;
   }
   if(!CurrCheck){IsValid=false; CB_BuyPriceComment.setForeground(CGUI.Color_Label_InputWrong);}
   else{CB_BuyPriceComment.setForeground(CGUI.Color_Label_InputRight);}
  }
   
  // set get Variables
  if(!IsValid){
   JOptionPane.showMessageDialog(null, "Terdapat masukan yang salah !"+
    "\nSilahkan perbaiki masukan pada label berwarna merah !");
   return;
  }
  
  DialogResult=1;
  clearComponents();
  Activ=false;
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void CB_BuyPriceCommentSubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyPriceCommentSubActionPerformed
  enableInputInTextField(CB_BuyPriceCommentSub.isSelected(), TF_BuyPriceCommentSub);
 }//GEN-LAST:event_CB_BuyPriceCommentSubActionPerformed

 private void Btn_TodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_TodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_UpdateOn, TF_Year, ComboBox_Month, ComboBox_Day, false);
 }//GEN-LAST:event_Btn_TodayActionPerformed

 private void CB_UpdateOnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_UpdateOnActionPerformed
  PGUI.enableInput(CB_UpdateOn.isSelected(), TF_Year, ComboBox_Month, ComboBox_Day, false);
 }//GEN-LAST:event_CB_UpdateOnActionPerformed

 private void Lbl_BuyPrcHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPrcHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, CCore.CharsCount_Deci(), 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPrcHelpMouseClicked

 private void CB_ActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_ActiveKeyPressed
  PNav.onKey_CB(this, CB_Active, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_Update)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ActiveY)));
 }//GEN-LAST:event_CB_ActiveKeyPressed

 private void RB_ActiveYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ActiveYKeyPressed
  PNav.onKey_RB(this, RB_ActiveY, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Active)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(RB_ActiveN)));
 }//GEN-LAST:event_RB_ActiveYKeyPressed

 private void RB_ActiveNKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RB_ActiveNKeyPressed
  PNav.onKey_RB(this, RB_ActiveN, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(RB_ActiveY)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_RB_ActiveNKeyPressed

 private void CB_UpdateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpdateKeyPressed
  PNav.onKey_CB(this, CB_Update, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Active)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_UpdateOn)));
 }//GEN-LAST:event_CB_UpdateKeyPressed

 private void CB_UpdateOnKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_UpdateOnKeyPressed
  PNav.onKey_CB(this, CB_UpdateOn, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ActiveY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_Update)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_Year, Btn_Today)));
 }//GEN-LAST:event_CB_UpdateOnKeyPressed

 private void TF_YearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_YearKeyPressed
  PNav.onKey_TF(this, TF_Year, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ActiveY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_Month, Btn_Today)));
 }//GEN-LAST:event_TF_YearKeyPressed

 private void ComboBox_MonthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_MonthKeyPressed
  PNav.onKey_CmB(this, ComboBox_Month, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_Year, CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(ComboBox_Day, Btn_Today)));
 }//GEN-LAST:event_ComboBox_MonthKeyPressed

 private void ComboBox_DayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ComboBox_DayKeyPressed
  PNav.onKey_CmB(this, ComboBox_Day, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_Month, CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Today)));
 }//GEN-LAST:event_ComboBox_DayKeyPressed

 private void Btn_TodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_TodayKeyPressed
  PNav.onKey_Btn(this, Btn_Today, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(RB_ActiveY)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(ComboBox_Day, CB_UpdateOn)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_TodayKeyPressed

 private void CB_BuyPrcKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyPrcKeyPressed
  PNav.onKey_CB(this, CB_BuyPrc, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_Update)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyPriceComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPrc)));
 }//GEN-LAST:event_CB_BuyPrcKeyPressed

 private void TF_BuyPrcKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPrcKeyPressed
  PNav.onKey_TF(this, TF_BuyPrc, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_UpdateOn)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPriceCommentSub, CB_BuyPriceCommentSub)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyPrc)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPrcKeyPressed

 private void CB_BuyPriceCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyPriceCommentKeyPressed
  PNav.onKey_CB(this, CB_BuyPriceComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyPrc)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyPriceCommentSub, CB_BuyPriceCommentSub)));
 }//GEN-LAST:event_CB_BuyPriceCommentKeyPressed

 private void TF_BuyPriceCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceCommentSubKeyPressed
  PNav.onKey_TF(this, TF_BuyPriceCommentSub, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyPriceComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyPriceComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CB_BuyPriceCommentSub)));
 }//GEN-LAST:event_TF_BuyPriceCommentSubKeyPressed

 private void CB_BuyPriceCommentSubKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyPriceCommentSubKeyPressed
  PNav.onKey_CB(this, CB_BuyPriceCommentSub, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPrc)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyPriceComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyPriceCommentSub, CB_BuyPriceComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_BuyPriceCommentSubKeyPressed

 private void TA_BuyPriceCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyPriceCommentKeyPressed
  PNav.onKey_TA(this, TA_BuyPriceComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPriceCommentSub, CB_BuyPriceCommentSub)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyPriceComment)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyPriceCommentKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyPriceComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyPriceComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_Today;
 private javax.swing.JCheckBox CB_Active;
 private javax.swing.JCheckBox CB_BuyPrc;
 private javax.swing.JCheckBox CB_BuyPriceComment;
 private javax.swing.JCheckBox CB_BuyPriceCommentSub;
 private javax.swing.JCheckBox CB_Update;
 private javax.swing.JCheckBox CB_UpdateOn;
 private javax.swing.JComboBox ComboBox_Day;
 private javax.swing.JComboBox ComboBox_Month;
 private javax.swing.JLabel Lbl_BuyPrcHelp;
 private javax.swing.JLabel Lbl_BuyPriceCommentHelp;
 private javax.swing.JLabel Lbl_DataCount;
 private javax.swing.JRadioButton RB_ActiveN;
 private javax.swing.JRadioButton RB_ActiveY;
 private javax.swing.ButtonGroup RG_Active;
 private javax.swing.JTextArea TA_BuyPriceComment;
 private javax.swing.JTextField TF_BuyPrc;
 private javax.swing.JTextField TF_BuyPriceCommentSub;
 private javax.swing.JTextField TF_Year;
 private javax.swing.JScrollPane jScrollPane1;
 // End of variables declaration//GEN-END:variables
}
