public interface OFormAnimation {
 public void animate();
}