import java.awt.Graphics2D;

public class ODrawComponentLine extends ODrawComponent {

 double DestinationX, DestinationY;

 public ODrawComponentLine(double OffsetX, double OffsetY, double DestinationX, double DestinationY) {
  this.OffsetX = OffsetX;
  this.OffsetY = OffsetY;
  this.DestinationX = DestinationX;
  this.DestinationY = DestinationY;
 }
 
 public void draw(Graphics2D graphics, OGraphicsProperties Prop){
  graphics.fillRect(PMath.round(OffsetX, 0), PMath.round(OffsetY, 0), PMath.round(DestinationX-OffsetX, 0), PMath.round(DestinationY-OffsetY, 0));
 }
 
 public ODimension calcDrawDimension(){
  ODimension ret=new ODimension();
  double width, height;
  
  width=DestinationX-OffsetX;
  height=DestinationY-OffsetY;
  ret.setSize(width, height);
  
  return ret;
 }
 
}