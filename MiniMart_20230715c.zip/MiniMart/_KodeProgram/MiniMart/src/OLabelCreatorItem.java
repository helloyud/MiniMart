public abstract class OLabelCreatorItem extends OLabelCreator {

 public OLabelCreatorItem(){}
 public void init(
  OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
 }

}