import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

public class OBarcodePatterns {
 
 /*
  source :
  - https://internationalbarcodes.com/ean-13-specifications/
  - http://www.adams1.com/128code.html
  - http://www.barcodemaking.com/barm_barcode_resolution_size_mils.html
  - http://www.zebex.com/Product/documents/Z-3220/Z-3220_DataSheet.pdf
  
 
  X-Dimension = minimal module width (in mm)
 
  Each barcode type has different X-Dimension specification, for example:
      Code 128 has minimal 7.5 mil (0.1905 mm ; 1 mil = 0.001 inch)
      EAN has minimal 10.4 mil and maximal 26 mil (magnification 80% - 200% ; 13 mil at 100%)
  
  The barcode scanner product has different minimal X-Dimension read ability
  (or "Scanner Optical Resolution" or "Depth of Scan Field" or "SymbolDensity"), for example:
      Scanner "A" can read at minimal X-Dimension 5 mil
      Scanner "B" can read at minimal X-Dimension 10 mil
 
  Most of current barcode scanner products can read at minimal X-Dimension 5 mil (some 7 mil or 10 mil)
 
  So, the conclusion is:
      the X-Dimension for a Barcode-Type is specified by "common Scanner Product's Resolution" and then "minimal Barcode-Type X-Dimension"
 */
 
 String[] Patterns;
 OBarcodePatternsSpecification Specification;
 
 public OBarcodePatterns(){}
 public OBarcodePatterns(String[] Patterns, OBarcodePatternsSpecification Specification){
  this.Patterns=Patterns;
  this.Specification=Specification;
 }
 
 public void setVariables(String[] Patterns, OBarcodePatternsSpecification Specification){
  this.Patterns=Patterns;
  this.Specification=Specification;
 }
 
 public BufferedImage getBufferedImage(double BarcodeHeight, double ScaleFactor){
  // BarcodeHeight is assumed in ScaleFactor 1
  BufferedImage ret;
  int temp, temp2, PatternLength, height;
  int x;
  Graphics2D g;
  String CurrPattern;
  double RatioToOriginal;
  int AddImageWidthTolerance=0; // add n pixel for image width tolerance (optional)
  
  // create image
  temp2=0;
  temp=0;
  do{
   temp2=temp2+Patterns[temp].length();
   temp=temp+1;
  }while(temp!=Patterns.length);
  
  RatioToOriginal=Specification.ModuleWidth/1;
  
  ret=new BufferedImage(
   PMath.round(((Specification.QuietZoneLeftModuleCount+temp2*Specification.ModulePixelCount+Specification.QuietZoneRightModuleCount+AddImageWidthTolerance)*RatioToOriginal)*ScaleFactor, 1),
   PMath.roundCustom(BarcodeHeight*ScaleFactor, 0.3),
   BufferedImage.TYPE_INT_RGB);
  
  g=ret.createGraphics();
  g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
  g.setBackground(CGUI.White);
  g.setColor(CGUI.Black);
  g.clearRect(0, 0, ret.getWidth(), ret.getHeight());
  g.scale(RatioToOriginal*ScaleFactor, 1);
  
  // draw on image
  x=0;
  
   // quiet zone
  x=x+Specification.QuietZoneLeftModuleCount;
  
   // barcode
  height=ret.getHeight();
  
  temp=0;
  do{
   
   CurrPattern=Patterns[temp];
   PatternLength=CurrPattern.length();
   temp2=0;
   do{
    
    if(CurrPattern.charAt(temp2)=='1'){
     g.fillRect(x, 0, Specification.ModulePixelCount, height);
    }
    x=x+Specification.ModulePixelCount;
    
    temp2=temp2+1;
   }while(temp2!=PatternLength);
   
   temp=temp+1;
  }while(temp!=Patterns.length);
  
    // quiet zone
  x=x+Specification.QuietZoneRightModuleCount;
  
  return ret;
 }

}