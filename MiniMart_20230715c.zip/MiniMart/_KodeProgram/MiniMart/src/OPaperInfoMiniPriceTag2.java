public class OPaperInfoMiniPriceTag2 {

 int RowsCount;
 int ColumnsCount;
 boolean IsRotated;

 OPaperInfoMiniPriceTag2(int RowsCount, int ColumnsCount, boolean IsRotated){
  this.RowsCount=RowsCount;
  this.ColumnsCount=ColumnsCount;
  this.IsRotated=IsRotated;
 }

}