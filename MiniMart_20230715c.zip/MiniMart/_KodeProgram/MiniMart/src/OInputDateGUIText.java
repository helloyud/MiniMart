import javax.swing.JTextField;

public class OInputDateGUIText extends OInput {

 JTextField GUI_Text;
 boolean AcceptEmptyInput;
 
 VDate Value;

 public OInputDateGUIText(JTextField GUI_Text, boolean AcceptEmptyInput) {
  this.GUI_Text = GUI_Text;
  this.AcceptEmptyInput = AcceptEmptyInput;
  
  Value=new VDate();
 }
 
 public boolean isValid(){return PGUI.checkInputDate(GUI_Text, Value, AcceptEmptyInput);}
 public Object getValue(){return Value.Value;}

}