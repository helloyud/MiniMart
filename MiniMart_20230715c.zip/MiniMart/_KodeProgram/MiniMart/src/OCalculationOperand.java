public abstract class OCalculationOperand {
 
 // variables & methods for dynamic value
 int TableRowIndex;
 
 public void setTableRowIndex(int TableRowIndex){
  this.TableRowIndex=TableRowIndex;
 }
 
 //
 public abstract double getOperand();

}