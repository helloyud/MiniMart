import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTextField;


public class OInputDateGUICombination extends OInput {

 JCheckBox GUI_Enable;
 JTextField GUI_Year;
 JComboBox GUI_Month;
 JComboBox GUI_Day;
 
 VDate Value;

 public OInputDateGUICombination(JCheckBox GUI_Enable, JTextField GUI_Year, JComboBox GUI_Month, JComboBox GUI_Day) {
  this.GUI_Enable = GUI_Enable;
  this.GUI_Year = GUI_Year;
  this.GUI_Month = GUI_Month;
  this.GUI_Day = GUI_Day;
  Value = new VDate();
 }

 
 
 public boolean isValid(){return PGUI.checkInputDate(GUI_Enable, GUI_Year, GUI_Month, GUI_Day, Value);}
 public Object getValue(){return Value.Value;}

}