import java.sql.Statement;
import java.util.LinkedList;
import java.util.Vector;

public class OPrintGeneratorItemCatalog extends OPrintGeneratorCatalog {

 // additional printing properties
 LinkedList<Long> ItemsId;
 String ImageDir;
 boolean ByCategory;
 boolean ByCategoryPagination;
 boolean AllowRedundant;
 LinkedList<OIdName> ItemsCategory;
 String ItemsIdQ;
 Vector<OImageFrame> Items; // save current result set's item id & file name order by item name asc
 
 int CategoryCount;
 OIdName CurrCategory;
 boolean CurrCategoryHeaderPrint;
 int CurrItem;
 OQuickListOfLong PrintedId;
 
 OIdName BefCategory;
	
	String QueryCondition;
 String QueryAdditionalTable;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit

 
 OPrintGeneratorItemCatalog(OFont FontStandard) {super(FontStandard);}
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom,
  Statement Stm, LinkedList<Long> ItemsId, String ImageDir, boolean ByCategory, boolean ByCategoryPagination, boolean AllowRedundant){
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  
  this.Stm=Stm;
  this.ItemsId=ItemsId;
  this.ImageDir=ImageDir;
  this.ByCategory=ByCategory;
  this.ByCategoryPagination=ByCategoryPagination;
  this.AllowRedundant=AllowRedundant;
 }
 
 // standard private methods
	protected boolean hasHeader(){return false;}
 protected boolean hasFooter(){return true;}
 protected int getMinimalColumnarColumnCount(){return 60;}
 protected int getMinimalCommentCharCount(){return 17;}
 protected int getCommentRowsCount(){return 1;}
 protected int getCategoryAddLineSpacing(){return 7;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.A4.RealWidth){ret=new OFontLayout(8.5f, false, false); break;}
   if(PaprWidth>=CPrint.A5.RealWidth){ret=new OFontLayout(7.5f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected ODimensionAbsolute getFramesCount(){
  ODimensionAbsolute ret=new ODimensionAbsolute(1, 1);
  
  do{
   if(PaperType.Id==CPrint.A4.Id){ret.setSize(4, 4); break;}
   if(PaperType.Id==CPrint.A5.Id){ret.setSize(3, 3); break;}
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{}
 protected void prepareFirstPageData() throws Exception{
  if(!AllowRedundant){PrintedId=new OQuickListOfLong(1024, 1024, true, true);}
  CurrCategoryHeaderPrint=false;
  if(!saveItemsId()){throw new Exception();}
  if(!ByCategory){
			QueryAdditionalTable=""; QueryCondition="Id in ("+ItemsIdQ+")";
   Rs=Stm.executeQuery(getQuery());
   processResultSetToItems();
   if(!getNextItem()){throw new Exception();}
  }
  else{
   saveItemsCategory();
   if(!getNextCategory()){throw new Exception();}
   if(!getItemsFromCurrCategory()){throw new Exception();}
  }
 }
 protected void addHeader() throws Exception{}
 protected boolean addColumnar() throws Exception{
  boolean KeepPrinting=true;
  int framecounth;
  double temp_d;
  OImageFrame obj;
  boolean ThereIs;
  
  if(ByCategory){BefCategory=CurrCategory;}
  do{
   // print curr item
   if(CurrCategoryHeaderPrint){
    if(IsANewColumnar){IsANewColumnar=false;}else{CurrY=CurrY+CategoryAddLineSpacing;}
    PText.refillChars(Txt, ' ');
    PText.fillStringToChars(Txt, "+", 0, 1);
    PText.fillStringToChars(Txt, PText.fitString(CurrCategory.Name, ColumnarColumnCount-3+1, true, (ColumnarColumnCount-3+1)-1, 1, '~'), 3-1, 1);
    DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
    CurrY=CurrY+NormalHeight;
    
    CurrCategoryHeaderPrint=false;
   }
   
   // print a row
   if(IsANewColumnar){IsANewColumnar=false;}else{CurrY=CurrY+FrameAddLineSpacing;}
   framecounth=0;
   CurrX=0;
   do{
    temp_d=CurrY;
    if(CurrX!=0){CurrX=CurrX+FrameAddLineSpacingHorizontal;}
    obj=Items.elementAt(CurrItem);
    
    // draw image in box
    temp_d=temp_d+FrameGapVertical;
    DrawComponents.add(new ODrawComponentImage(BaseX+CurrX+FrameGapHorizontal, BaseY+temp_d, BoxWidth, BoxHeight, null, ImageDir, obj.FileName));
    temp_d=temp_d+BoxHeight;
    
    // draw comment
    temp_d=temp_d+CommentAddLineSpacing;
    PText.refillChars(TxtComment, ' ');
    PText.fillStringToChars(TxtComment, PText.fitString(obj.Comment.toString(), CommentCharCount, false, CommentCharCount-1, 1, '~'),
     (int)(CommentCharCount/2)-1, 2);
    DrawComponents.add(new ODrawComponentText(BaseX+CurrX+FrameGapHorizontal+CommentOffsetX, BaseY+temp_d+BaselineHeight, FontType,
     new String(TxtComment)));
    CurrX=CurrX+FrameWidth;
    
    // get next item
    if(!getNextItem()){
     // fetch next items
     do{
      if(!ByCategory){CurrItem=-1; break;}
      ThereIs=true;
      do{
       if(!getNextCategory()){ThereIs=false; break;}
       if(getItemsFromCurrCategory()){break;}
      }while(ThereIs);
      if(!ThereIs){CurrItem=-1; break;}
      if(ByCategoryPagination){KeepPrinting=false;}
     }while(false);
     
     // stop print this row
     break;
    }
    
    framecounth=framecounth+1;
   }while(framecounth!=FramesCountHorizontal);
   CurrY=CurrY+FrameHeight;
   
   if(CurrItem==-1 || !KeepPrinting){break;}

   temp_d=FrameH;
   if(CurrCategoryHeaderPrint){temp_d=temp_d+CategoryAddLineSpacing+NormalHeight;}
   if(checkOverColumnarHeight(temp_d)){break;}
  }while(KeepPrinting);
		return false;
 }
 protected void addFooter() throws Exception{
  String FooterStr=null;
  CurrY=OrientedPaprImageableHeight-FooterHeight+FooterAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  PText.refillChars(TxtPage, ' ');
  if(!ByCategory || !ByCategoryPagination){FooterStr="~";}else{FooterStr=BefCategory.Name;}
  PText.fillStringToChars(TxtPage, FooterStr, PageColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(0, CurrY+BaselineHeight, FontType, new String(TxtPage)));
 }
 protected boolean isCurrentPaperIsRollPaper(){return false;}
 protected double getCurrentRollPaperHeight(){return OrientedPaprHeight;}
 protected double getCurrentRollPaperImageableHeight(){return OrientedPaprImageableHeight;}
 protected boolean prepareNextPage() throws Exception{
  boolean ret=true;
  do{
   // prepare print data for next page
   if(CurrItem==-1){ret=false; break;}
  }while(false);
  return ret;
 }
 protected void clearVar(){
  ItemsId=null;
  ItemsCategory=null;
  Items=null;
  CurrCategory=null;
  ItemsIdQ=null;
  PrintedId=null;
 }
 
 // additional private methods
	String getQuery(){
		return
			"select tb1.Id, ItemXPicture.FileName from "+
    "(select Item.Id, Item.Name from Item"+QueryAdditionalTable+" where "+QueryCondition+") as tb1, "+
   "ItemXPicture where tb1.Id=ItemXPicture.Item order by tb1.Name asc, ItemXPicture.FileName asc;";
	}
 boolean saveItemsId() throws Exception{
  boolean ret=false;
  StringBuilder strb=new StringBuilder();
  strb=strb.append(ItemsId.pop().toString());
  if(!ItemsId.isEmpty()){
   do{
    strb.append(","+ItemsId.pop().toString());
   }while(!ItemsId.isEmpty());
  }
  Rs=Stm.executeQuery("select Item from ItemXPicture where Item in ("+strb.toString()+") group by Item;");
  if(Rs.next()){
   strb=new StringBuilder();
   strb.append(Rs.getLong(1));
   if(Rs.next()){
    do{
     strb.append(","+Rs.getLong(1));
    }while(Rs.next());
   }
   ItemsIdQ=strb.toString();
   ret=true;
  }
  return ret;
 }
 void saveItemsCategory() throws Exception{
  OIdName data;
  int temp;
  boolean IsNull;
  ItemsCategory=new LinkedList();
  Rs=Stm.executeQuery(
   "select Id, Name from "+
    "(select CategoryOfItem from "+
     "(select Id from Item where Id in ("+ItemsIdQ+")) as i "+
    "left join ItemXCategory on i.Id=ItemXCategory.Item group by CategoryOfItem) as tb1 "+
   "left join CategoryOfItem on tb1.CategoryOfItem=CategoryOfItem.Id "+
   "order by Name asc;");
  if(Rs.next()){
   IsNull=false;
   do{
    temp=Rs.getInt(1);
    if(Rs.wasNull()){IsNull=true;}
    else{
     data=new OIdName();
     data.Id=temp;
     data.Name=Rs.getString(2);
     ItemsCategory.addLast(data);
    }
   }while(Rs.next());
   if(IsNull){
    data=new OIdName();
    data.Id=-1;
    data.Name="~ Belum Terkategori ~";
    ItemsCategory.addLast(data);
   }
   CategoryCount=ItemsCategory.size();
  }
 }
 private boolean getNextCategory(){
  if(ItemsCategory.isEmpty()){return false;}
  CurrCategory=ItemsCategory.pop();
  return true;
 }
 private boolean getItemsFromCurrCategory() throws Exception{
  QueryAdditionalTable="";
  if(CurrCategory.Id!=-1){
   QueryAdditionalTable=", ItemXCategory";
   QueryCondition="Item.Id=ItemXCategory.Item and Item.Id in ("+ItemsIdQ+") and ItemXCategory.CategoryOfItem="+CurrCategory.Id;
  }
  else{
   if(CategoryCount==1){QueryCondition="Item.Id in ("+ItemsIdQ+")";}
   else{
    QueryAdditionalTable=" left join ItemXCategory on Item.Id=ItemXCategory.Item";
    QueryCondition="Item.Id in ("+ItemsIdQ+") and ItemXCategory.Item is null";
   }
  }
  Rs=Stm.executeQuery(getQuery());
  processResultSetToItems();
  if(!getNextItem()){return false;}
  if(!ByCategoryPagination){CurrCategoryHeaderPrint=true;}
  return true;
 }
 private boolean getNextItem() throws Exception{
  CurrItem=CurrItem+1;
  if(CurrItem==Items.size()){return false;}
  return true;
 }
 private void processResultSetToItems() throws Exception{
  long Id;
  int temp, temp2, redundantcount;
  OImageFrame obj;
  String FileName;
  OQuickListOfLong ResultSetIds=null;
  
  Items=new Vector();
  CurrItem=-1;
  
  // save Rs to Items
  if(Rs.next()){
   ResultSetIds=new OQuickListOfLong(1024, 1024, true, true);
   
   // fill Rs to Items
   do{
    Id=Rs.getLong(1);
    
    do{
     if(!AllowRedundant){if(PrintedId.addElement(Id)!=-1){break;}}
     ResultSetIds.addElement(Id);
    }while(false);
    
    if(ResultSetIds.checkElement(Id)>=0){
     obj=new OImageFrame();
     obj.Comment=new StringBuilder();
     obj.Comment.append(Id);
     obj.FileName=Rs.getString(2);
     Items.addElement(obj);
    }
   }while(Rs.next());
   
   // Items : eliminate redundant image
   if(Items.size()>1){
    temp=0;
    do{
     obj=Items.get(temp);
     FileName=obj.FileName;
     redundantcount=0;
     temp2=temp+1;
     do{
      if(PText.compare(FileName, Items.get(temp2).FileName, false)){
       redundantcount=redundantcount+1;
       Items.removeElementAt(temp2);
      }
      else{temp2=temp2+1;}
     }while(temp2<Items.size());
     if(redundantcount!=0){obj.Comment.append(" *"+redundantcount);}
     temp=temp+1;
    }while(temp<Items.size()-1);
   }
  }
 }
 
}