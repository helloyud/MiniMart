import java.sql.Statement;
import java.util.Date;
import java.util.Vector;

public class OPrintGeneratorTransPayment extends OPrintGenerator {
 
  // additional printing properties
 long TransId;
 long[] PaymentsEnumeration;
 boolean IsPreTrans;
 boolean IsPaymentIn;
 
 //
 Vector<String> Intro;
 Vector<String> PaymentGiver;
 String TransInfo_Param;
 Vector<String> TransInfo_Value;
 String PaymentReceiver;
 Vector<Object[]> Payments;
 int PaymentsCount;
 double PaymentsPrice;
 int CurrOperation; // 1 Intro, 2 Payment Giver, 3 Trans Info, 4 Payments Summary, 5 A Payment List, 6 Signature, 7 End
 Vector<String> CurrPayment;
 int CurrPaymentList;
 
 // additional printing layout variables : component's addlinespacing, height, pos, fit
 final double MinimalThermalPaperHeightCut=OUnit.mm_to_pixel(60);
 final double PostHeaderAddLineSpacing=OUnit.mm_to_pixel(2.5);
 final double DetailAddLineSpacing=OUnit.mm_to_pixel(1.5);
 final int Detail_ParamCharCount=8;
 double Detail_ColonX;
 double Detail_ValueX;
 int Detail_ValueCharCount;
 final double SubDetailAddLineSpacing=OUnit.mm_to_pixel(1.25);
 final double TabSpace=OUnit.mm_to_pixel(1.75);
 double SubDetail_ValueX;
 int SubDetail_ValueCharCount;
 final double SignatureAddLineSpacing=OUnit.mm_to_pixel(5);
 final double SignaturePicHeight=OUnit.mm_to_pixel(27.5);
 final double ContinueAddLineSpacing=OUnit.mm_to_pixel(2.5);
 
 OPrintGeneratorTransPayment(OFont FontStandard) {super(FontStandard);}
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom, OFont FontCustomThermal,
  Statement Stm, long TransId, long[] PaymentsEnumeration, boolean IsPreTrans, boolean IsPaymentIn){
  this.PaperType=PaperType;
  this.FontCustom=FontCustom;
  this.FontCustomThermal=FontCustomThermal;
  this.Stm=Stm;
  this.TransId=TransId;
  this.PaymentsEnumeration=PaymentsEnumeration;
  this.IsPreTrans=IsPreTrans;
  this.IsPaymentIn=IsPaymentIn;
 }
 
 // standard private methods
	protected boolean hasHeader(){return true;}
 protected boolean hasFooter(){return false;}
 protected int getMinimalColumnarColumnCount(){return 0;}
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.Thermal100.RealWidth){ret=new OFontLayout(9.0f, false, false); break;}
   if(PaprWidth>=CPrint.Thermal70.RealWidth){ret=new OFontLayout(8.35f, false, false); break;}
   if(PaprWidth>=CPrint.Thermal57.RealWidth){ret=new OFontLayout(7.75f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  Detail_ColonX=Detail_ParamCharCount*FontWidth+TabSpace;
  Detail_ValueX=Detail_ColonX+FontWidth+TabSpace;
  Detail_ValueCharCount=(int)((ColumnarWidth-Detail_ValueX)/FontWidth);
  SubDetail_ValueX=FontWidth+TabSpace;
  SubDetail_ValueCharCount=(int)((ColumnarWidth-SubDetail_ValueX)/FontWidth);
 }
 protected void prepareFirstPageData() throws Exception{
  String TransIdExternal;
  Date TransDate;
  String TransType;
		String TransSubject;
  String ShopName;
  String TblTrans;
  String TblTransPayment;
  OParameterValueGroup ShopInfo;
  double[] Sum;
  
  TblTrans=(String)PCore.subtituteBool(!IsPreTrans, "Trans", "PreTrans");
  
  Rs=Stm.executeQuery(
   "select InfoIdExternal, TransDate, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName' from "+
    "(select * from "+TblTrans+" where Id="+TransId+") as tb1 "+
   "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id;");
  if(!Rs.next()){throw new Exception();}
  
  TransIdExternal=Rs.getString(1);
  TransDate=Rs.getDate(2);
  TransType=Rs.getString(3);
  TransSubject=Rs.getString(4);
  
  TblTransPayment=(String)PCore.subtituteBool(IsPaymentIn, TblTrans+"XPaymentIn", TblTrans+"XPayment");
  Payments=new Vector();
  Sum=new double[5];
  PaymentsCount=PDatabase.queryToRows(Stm,
   "select Enumeration, PaymentDate, Cash.Name as 'CashName', Price, Comment from "+
    "(select * from "+TblTransPayment+" where "+TblTrans+"="+TransId+" and Enumeration in ("+PText.toString(PaymentsEnumeration, 0, PaymentsEnumeration.length, ",")+")) as tb1 "+
   "left join Cash on tb1.Cash=Cash.Id order by PaymentDate asc, CashName asc, Enumeration asc;",
   Payments, PCore.primArr(CCore.TypeInteger, CCore.TypeDate, CCore.TypeString, CCore.TypeDouble, CCore.TypeString), null, true,
   PCore.primArr(false, false, false, true, false), Sum, false, false, null, 0, false, -1, false, false, false, null, -1);
  if(PaymentsCount<1){throw new Exception();}
  PaymentsPrice=Sum[3];
  CurrPaymentList=-1;
  
  ShopInfo=new OParameterValueGroup();
  ShopInfo.addElement(new OParameterValue(CApp.ParamShopName, CCore.TypeString, null, null, false, false));
  ShopInfo=PDatabase.parameterValueGet(Stm, null, "ApplicationInfo", ShopInfo);
  ShopName=PText.getStringObj(ShopInfo.getValue(CApp.ParamShopName, false, 0), null, true);
  
  Intro=PText.multiLine("Melalui surat ini, saya menyatakan telah menerima pembayaran :", ColumnarColumnCount);
  PaymentGiver=PText.multiLine(PText.getString(PText.getString(IsPaymentIn, TransSubject, ShopName), "....", true), Detail_ValueCharCount);
  TransInfo_Param=(String)PCore.subtituteBool(!IsPreTrans, "Trans", "PraTrans");
  TransInfo_Value=PText.multiLine(
   TransId+PText.getString(TransIdExternal, "", " {"+TransIdExternal+"}", true)+
   " ("+PText.dateToString(TransDate, 2)+PText.getString(TransType, "", ", "+TransType, true)+")",
   Detail_ValueCharCount);
  PaymentReceiver=PText.fitString(PText.getString(PText.getString(IsPaymentIn, ShopName, TransSubject), "....", true), ColumnarColumnCount, true, ColumnarColumnCount-1, 1, '~');
  
  CurrOperation=1;
 }
 protected void addHeader() throws Exception{
  DrawComponents.add(new ODrawComponentText(0, CurrY+LineSpacing, FontType, "Tanda Terima Pembayaran",
   ColumnarWidth, NormalHeight, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  DrawComponents.add(new ODrawComponentText(0, CurrY+LineSpacing, FontType, "Hal. "+CurrPage,
   ColumnarWidth, NormalHeight, LineSpacing, new OAlignment(OAlignment.HorizontalRight, OAlignment.VerticalTop)));
  CurrY=CurrY+NormalHeight;
  
  DrawComponents.add(new ODrawComponentLine(0, CurrY+DrawLineSpacing, OrientedPaprImageableWidth, CurrY+DrawLineSpacing+DrawLineWidth));
  CurrY=CurrY+DrawLineHeight;
  
  CurrY=CurrY+HeaderAddLineSpacing;
 }
 protected boolean addColumnar() throws Exception{
  boolean ret=false;
		boolean KeepPrinting=true;
  double temp_d;
  boolean next_payment;
  do{
   if(CurrOperation==1){
    printIntro(); CurrOperation=CurrOperation+1;
    temp_d=(DetailAddLineSpacing+PaymentGiver.size()*NormalHeight)+(ContinueAddLineSpacing+NormalHeight)+OrientedPaprMarginBottomAddLineSpacing;
    if(checkOverColumnarHeight(temp_d)){break;}
    continue;
   }
   if(CurrOperation==2){
    printPaymentGiver(); CurrOperation=CurrOperation+1;
    temp_d=(DetailAddLineSpacing+TransInfo_Value.size()*NormalHeight)+(ContinueAddLineSpacing+NormalHeight)+OrientedPaprMarginBottomAddLineSpacing;
    if(checkOverColumnarHeight(temp_d)){break;}
    continue;
   }
   if(CurrOperation==3){
    printTransInfo(); CurrOperation=CurrOperation+1;
    temp_d=(DetailAddLineSpacing+NormalHeight)+(ContinueAddLineSpacing+NormalHeight)+OrientedPaprMarginBottomAddLineSpacing;
    if(checkOverColumnarHeight(temp_d)){break;}
    continue;
   }
   if(CurrOperation==4){
    printPaymentsSummary(); CurrOperation=CurrOperation+1;
    next_payment=getNextPayment();
    if(next_payment){
     temp_d=(SubDetailAddLineSpacing+CurrPayment.size()*NormalHeight)+(ContinueAddLineSpacing+NormalHeight)+OrientedPaprMarginBottomAddLineSpacing;
    }
    else{
     CurrOperation=CurrOperation+1;
     temp_d=SignatureAddLineSpacing+SignaturePicHeight+NormalHeight+OrientedPaprMarginBottomAddLineSpacing;
    }
    if(checkOverColumnarHeight(temp_d)){break;}
    continue;
   }
   if(CurrOperation==5){
    printAPaymentList();
    next_payment=getNextPayment();
    if(next_payment){
     temp_d=(SubDetailAddLineSpacing+CurrPayment.size()*NormalHeight)+(ContinueAddLineSpacing+NormalHeight)+OrientedPaprMarginBottomAddLineSpacing;
    }
    else{
     CurrOperation=CurrOperation+1;
     temp_d=SignatureAddLineSpacing+SignaturePicHeight+NormalHeight+OrientedPaprMarginBottomAddLineSpacing;
    }
    if(checkOverColumnarHeight(temp_d)){break;}
    continue;
   }
   if(CurrOperation==6){
    printSignature(); CurrOperation=CurrOperation+1; break;
   }
  }while(KeepPrinting);
  
  printContinue();
		
  return ret;
 }
 protected void addFooter() throws Exception{}
 protected boolean isCurrentPaperIsRollPaper(){return PaperType.IsRollPaper;}
 protected double getCurrentRollPaperHeight(){
  double ret=OrientedPaprImageableY+BaseY+CurrY+OrientedPaprMarginBottom;
  if(ret<MinimalThermalPaperHeightCut){ret=MinimalThermalPaperHeightCut;}
  return ret;
 }
 protected double getCurrentRollPaperImageableHeight(){return BaseY+CurrY;}
 protected boolean prepareNextPage() throws Exception{
  boolean ret=true;
  do{
   // prepare print data for next page
   if(CurrOperation==7){ret=false; break;}
  }while(false);
  return ret;
 }
 protected void clearVar(){
  Payments=null;
  PaymentsEnumeration=null;
 }
 
 // additional private methods
 void printContinue(){
  if(CurrOperation==7){return;}
  
  CurrY=CurrY+ContinueAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+LineSpacing, FontType, "* Lanjut ... *",
   ColumnarWidth, NormalHeight, LineSpacing, new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalTop)));
  CurrY=CurrY+NormalHeight;
  
  CurrY=CurrY+OrientedPaprMarginBottomAddLineSpacing;
 }
 void printIntro(){
  IsANewColumnar=false;
  
  CurrY=CurrY+PostHeaderAddLineSpacing;
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+LineSpacing, FontType, Intro,
   Double.MAX_VALUE, Double.MAX_VALUE, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  CurrY=CurrY+(Intro.size()*NormalHeight);
 }
 void printPaymentGiver(){
  if(IsANewColumnar){IsANewColumnar=false;}
  else{CurrY=CurrY+DetailAddLineSpacing;}
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, "Dari"));
  DrawComponents.add(new ODrawComponentText(BaseX+Detail_ColonX, BaseY+CurrY+BaselineHeight, FontType, ":"));
  DrawComponents.add(new ODrawComponentText(BaseX+Detail_ValueX, BaseY+CurrY+LineSpacing, FontType, PaymentGiver,
   Double.MAX_VALUE, Double.MAX_VALUE, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  CurrY=CurrY+(PaymentGiver.size()*NormalHeight);
 }
 void printTransInfo(){
  if(IsANewColumnar){IsANewColumnar=false;}
  else{CurrY=CurrY+DetailAddLineSpacing;}
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, TransInfo_Param));
  DrawComponents.add(new ODrawComponentText(BaseX+Detail_ColonX, BaseY+CurrY+BaselineHeight, FontType, ":"));
  DrawComponents.add(new ODrawComponentText(BaseX+Detail_ValueX, BaseY+CurrY+LineSpacing, FontType, TransInfo_Value,
   Double.MAX_VALUE, Double.MAX_VALUE, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  CurrY=CurrY+(TransInfo_Value.size()*NormalHeight);
 }
 void printPaymentsSummary(){
  if(IsANewColumnar){IsANewColumnar=false;}
  else{CurrY=CurrY+DetailAddLineSpacing;}
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, "Total"));
  DrawComponents.add(new ODrawComponentText(BaseX+Detail_ColonX, BaseY+CurrY+BaselineHeight, FontType, ":"));
  DrawComponents.add(new ODrawComponentText(BaseX+Detail_ValueX, BaseY+CurrY+BaselineHeight, FontType,
   "("+PText.intToString(PaymentsCount)+") "+PText.priceToString(PaymentsPrice)));
  CurrY=CurrY+NormalHeight;
 }
 void printAPaymentList(){
  if(IsANewColumnar){IsANewColumnar=false;}
  else{CurrY=CurrY+SubDetailAddLineSpacing;}
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, "*"));
  DrawComponents.add(new ODrawComponentText(BaseX+SubDetail_ValueX, BaseY+CurrY+LineSpacing, FontType, CurrPayment,
   Double.MAX_VALUE, Double.MAX_VALUE, LineSpacing, new OAlignment(OAlignment.HorizontalLeft, OAlignment.VerticalTop)));
  CurrY=CurrY+(CurrPayment.size()*NormalHeight);
 }
 void printSignature(){
  if(IsANewColumnar){IsANewColumnar=false;}
  else{CurrY=CurrY+SignatureAddLineSpacing;}
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+LineSpacing, FontType, "Tertanda Saya,",
   ColumnarWidth, NormalHeight, LineSpacing, new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalTop)));
  CurrY=CurrY+NormalHeight;
  
  CurrY=CurrY+SignaturePicHeight;
  
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+LineSpacing, FontType, PaymentReceiver,
   ColumnarWidth, NormalHeight, LineSpacing, new OAlignment(OAlignment.HorizontalCenter, OAlignment.VerticalTop)));
  CurrY=CurrY+NormalHeight;
  
  CurrY=CurrY+OrientedPaprMarginBottomAddLineSpacing;
 }
 
 boolean getNextPayment(){
  Object[] Objs;
  int PaymentEnumeration;
  Date PaymentDate;
  String PaymentCash;
  double PaymentPrice;
  String PaymentComment;
  StringBuilder strb;
  boolean first;
  
  if(CurrPaymentList>=PaymentsCount-1){return false;}
  
  CurrPaymentList=CurrPaymentList+1;
  
  Objs=Payments.elementAt(CurrPaymentList);
  PaymentEnumeration=PCore.objInteger(Objs[0], -1);
  PaymentDate=PCore.objDate(Objs[1], null);
  PaymentCash=PCore.objString(Objs[2], null);
  PaymentPrice=PCore.objDouble(Objs[3], -1D);
  PaymentComment=PCore.objString(Objs[4], null);
  
  strb=new StringBuilder();
  strb.append(PText.dateToString(PaymentDate, 2)+" - "+PText.priceToString(PaymentPrice));
  if(!PText.isEmptyString(PaymentCash, true, true) || !PText.isEmptyString(PaymentComment, true, true)){
   strb.append(" (");
   first=true;
   if(!PText.isEmptyString(PaymentCash, true, true)){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PaymentCash);
   }
   if(!PText.isEmptyString(PaymentComment, true, true)){
    if(first){first=false;}else{strb.append(", ");}
    strb.append(PText.singleLine(PaymentComment, '~'));
   }
   strb.append(")");
  }
  
  CurrPayment=PText.multiLine(strb.toString(), SubDetail_ValueCharCount);
  
  return true;
 }
 
}