import javax.swing.JTextField;

public class OInputLongGUIText extends OInput {

 JTextField GUI_Text;
 boolean AcceptEmptyInput;
 boolean AcceptZero;
 boolean PositiveOnly;
 boolean WithinRange;
 long Range1, Range2;
 
 VLong Value;

 public OInputLongGUIText(JTextField GUI_Text, boolean AcceptEmptyInput, boolean AcceptZero, boolean PositiveOnly, boolean WithinRange, long Range1, long Range2) {
  this.GUI_Text = GUI_Text;
  this.AcceptEmptyInput = AcceptEmptyInput;
  this.AcceptZero = AcceptZero;
  this.PositiveOnly = PositiveOnly;
  this.WithinRange=WithinRange;
  this.Range1=Range1;
  this.Range2=Range2;
  
  Value=new VLong();
 }
 
 public boolean isValid(){return PGUI.checkInputLong(GUI_Text, Value, AcceptEmptyInput, AcceptZero, PositiveOnly, WithinRange, Range1, Range2);}
 public Object getValue(){return Value.Value;}

}