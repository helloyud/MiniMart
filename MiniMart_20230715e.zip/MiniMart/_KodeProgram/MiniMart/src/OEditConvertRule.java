import java.util.Date;

public class OEditConvertRule {

 boolean EditName; boolean ReplaceSubName; String SubName; String EditedName;
 boolean EditIsActive; Boolean EditedIsActive;
 boolean EditLastUpdate; Date EditedLastUpdate;
 
 boolean EditComplete; OInfoConvertRule InfoConvertRule;

 public OEditConvertRule(){clearAll();}
 
 OEditConvertRule clearAll(){
  init(
   false, false, null, null,
   false, false,
   false, null,
   
   false, null);
  
  return this;
 }
 
 OEditConvertRule init(
  boolean EditName, boolean ReplaceSubName, String SubName, String EditedName,
  boolean EditIsActive, boolean EditedIsActive,
  boolean EditLastUpdate, Date EditedLastUpdate,
  
  boolean EditComplete, OInfoConvertRule InfoConvertRule) {
  
  this.EditName = EditName; this.ReplaceSubName = ReplaceSubName; this.SubName = SubName; this.EditedName = EditedName;
  this.EditIsActive = EditIsActive; this.EditedIsActive = EditedIsActive;
  this.EditLastUpdate = EditLastUpdate; this.EditedLastUpdate = EditedLastUpdate;
  
  this.EditComplete = EditComplete; this.InfoConvertRule = InfoConvertRule;
 
  return this;
 }

}