public interface XForm{
 
 public void preInitComponents();
 public void postInitComponents();

}