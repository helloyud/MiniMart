public class OTableCellReference {

 int GetColMode, GetCol;
	int GetRowMode, GetRow;

 public OTableCellReference(int GetColMode, int GetCol, int GetRowMode, int GetRow) {
  this.GetColMode = GetColMode;
  this.GetCol = GetCol;
  this.GetRowMode = GetRowMode;
  this.GetRow = GetRow;
 }

}