import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class OCsvImportValueDbLookup extends OCsvImportValueCheckable {
 
 Statement Stm;
 String QuerySelectExcludeCondition;
 OCsvImportValuesInColsAndValues QuerySelectCondition;
 int ResultSetFirstColumnType;

 public OCsvImportValueDbLookup(boolean GetValidFromThisClass,
  Statement Stm, String QuerySelectExcludeCondition, OCsvImportValuesInColsAndValues QuerySelectCondition, int ResultSetFirstColumnType) {
  super(GetValidFromThisClass);
  initVariables(Stm, QuerySelectExcludeCondition, QuerySelectCondition, ResultSetFirstColumnType);
 }
 
 public void initVariables(Statement Stm, String QuerySelectExcludeCondition, OCsvImportValuesInColsAndValues QuerySelectCondition, int ResultSetFirstColumnType){
  this.Stm = Stm;
  this.QuerySelectExcludeCondition = QuerySelectExcludeCondition;
  this.QuerySelectCondition = QuerySelectCondition;
  this.ResultSetFirstColumnType = ResultSetFirstColumnType;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  super.prepareGenerateSQLValue(LastReadRecordFromFile);
  QuerySelectCondition.prepareGenerateSQLValue(LastReadRecordFromFile);
 }
 
 public int checkAndGenSQLValue(){
  int ret=OCsvImportValueCheckable.CheckError;
  OGeneratedSQLValue GeneratedQuerySelectCondition;
  ResultSet Rs;
  Object DataFromResultSet;
  
  do{
   try{
    GeneratedQuerySelectCondition=QuerySelectCondition.generateSQLValue();
    if(!GeneratedQuerySelectCondition.isGenerated()){break;}
    Rs=Stm.executeQuery(QuerySelectExcludeCondition+" "+GeneratedQuerySelectCondition.getGeneratedSQLValue());
    if(!Rs.next()){ret=OCsvImportValueCheckable.CheckEmpty; break;}
    DataFromResultSet=PDatabase.getColumnFromResultSet(Rs, 0, ResultSetFirstColumnType);
    GeneratedSQLValue.setGeneratedSQLValue(PDatabase.getSQLString(DataFromResultSet, ResultSetFirstColumnType, CCore.vNull, false));
    ret=OCsvImportValueCheckable.CheckValid;
   }
   catch(Exception E){}
  }while(false);
  
  return ret;
 }

}