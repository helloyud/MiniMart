public class OBarcodePatternsEAN13 extends OBarcodePatternsEAN {
 
 /*
  In this appication, the EAN-13 use the following specification:
  - X-Dimension 10.4 mil (magnification 80%)
  - width = 113 module (1175.2 mil or 29.85 mm)
            start quiet zone (11 module) +
            start (3 module) +
            6 numbers (2nd .. 7th) (42 module; @ 7 module / data) +
            middle (5 module) +
            5 numbers (8th .. 12th) (35 module; @ 7 module / data) +
            1 number as check digit (13th) (7 module) +
            stop (3 module) +
            end quiet zone (7 module)
  - height = 18.28 mm (magnification 80%)
 */
 
 public static final double EAN13IdealModuleWidth=OUnit.inch_to_pixel(0.0104);
 public static final double EAN13IdealModuleHeight=OUnit.mm_to_pixel(18.5);
 
 public static OBarcodePatternsSpecification getStandardSpecification(){
  return new OBarcodePatternsSpecification(EAN13IdealModuleWidth, EAN13IdealModuleHeight, 1, 11, 7);
 }
 
 public static String[] getLeftPatternsRuleFromFirstDigit(){
  String[] ret=new String[10]; // 0 - 9
  
  ret[  0] = "AAAAAA";
  ret[  1] = "AABABB";
  ret[  2] = "AABBAB";
  ret[  3] = "AABBBA";
  ret[  4] = "ABAABB";
  ret[  5] = "ABBAAB";
  ret[  6] = "ABBBAA";
  ret[  7] = "ABABAB";
  ret[  8] = "ABABBA";
  ret[  9] = "ABBABA";
  
  return ret;
 }
 public static String[] getLeftPatternsB(){
  String[] ret=new String[10]; // 0 - 9
  
  ret[  0] = "0100111";
  ret[  1] = "0110011";
  ret[  2] = "0011011";
  ret[  3] = "0100001";
  ret[  4] = "0011101";
  ret[  5] = "0111001";
  ret[  6] = "0000101";
  ret[  7] = "0010001";
  ret[  8] = "0001001";
  ret[  9] = "0010111";
  
  return ret;
 }
 
 
}