import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class F_ItemVariantModify extends XFormDialog {

 // set
 int wMode; // 1 Add, 2 Edit
 OInfoItemVariant wInfo;
 
 // get
 OInfoItemVariant Info;
 
 //
 String I_PictureFile; // input picture file
 
 public F_ItemVariantModify(MInterFormVariables IFV_) {
  preInitComponents();
  initComponents();
  postInitComponents();
  
  IFV=IFV_;
  Activ=false;
  onKeyPress();
  
  Info=new OInfoItemVariant();
  
  CB_BuyUpdateIsSetActionPerformed(null);
  
  clearComponents();
 }

 private void onKeyPress() {
  InputMap inp=getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
  ActionMap act=getRootPane().getActionMap();
  
  // common navigation characters
  PNav.registerCommonNavigationCharacters(this, inp, act,
   PCore.objArrVariant(
    TF_Variant,
    CB_IsActive,
    TA_Comment,
    CB_BuyUpdateIsSet, TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD, Btn_BuyUpdateSetToday,
    TF_BuyPrice,
    TA_BuyComment,
    Btn_PictureFileChoose, Btn_PictureFileSetNull,
    
    Btn_Ok, Btn_Cancel),
   PCore.objArrVariant());
  
  // esc
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), "esc");
  act.put("esc", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_CancelActionPerformed(null);
    }
   });
  
  // f11
  inp.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0, true), "f11");
  act.put("f11", new AbstractAction(){
    public void actionPerformed(ActionEvent e) {
     Btn_OkActionPerformed(null);
    }
   });
 }
 
 void clearComponents(){
  Lbl_Variant.setForeground(CGUI.Color_Label_InputRight); TF_Variant.setText("");
  CB_IsActive.setSelected(true);
  Lbl_Comment.setForeground(CGUI.Color_Label_InputRight); TA_Comment.setText("");
  
  Lbl_BuyPrice.setForeground(CGUI.Color_Label_InputRight); TF_BuyPrice.setText(PText.doubleToString(0, true));
  Lbl_BuyComment.setForeground(CGUI.Color_Label_InputRight); TA_BuyComment.setText("");
  Lbl_BuyUpdate.setForeground(CGUI.Color_Label_InputRight); CB_BuyUpdateIsSet.setSelected(false); CB_BuyUpdateIsSetActionPerformed(null);
  
  setPictureFile(null);
 }
 
 void fillComponentsWithSetVariables(){
  TF_Variant.setText(wInfo.Variant);
  CB_IsActive.setSelected(wInfo.IsActive);
  TA_Comment.setText(PText.getString(wInfo.Comment, "", false));
  
  TF_BuyPrice.setText(PText.doubleToString(wInfo.BuyPrice, true));
  TA_BuyComment.setText(PText.getString(wInfo.BuyComment, "", false));
  PGUI.setDateComponent(wInfo.BuyUpdate, CB_BuyUpdateIsSet, TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD, false);
  
  setPictureFile(wInfo.PictureFile);
 }
 void setPictureFile(String PictureFile){
  I_PictureFile=PText.getString(PictureFile, null, true);
  
  TF_PictureFile.setText(PText.getString(I_PictureFile, "", true));
  PGUI.fillPanelPictureURL(Pnl_PictureFile, IFV.Conf.ImageDirItem, I_PictureFile);
 }
 
 @SuppressWarnings("unchecked")
 // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

  TF_Variant = new javax.swing.JTextField();
  Lbl_Variant = new javax.swing.JLabel();
  Lbl_VariantHelp = new javax.swing.JLabel();
  CB_IsActive = new javax.swing.JCheckBox();
  Lbl_IsActive = new javax.swing.JLabel();
  CB_BuyUpdateIsSet = new javax.swing.JCheckBox();
  Lbl_BuyUpdate = new javax.swing.JLabel();
  TF_BuyUpdateY = new javax.swing.JTextField();
  CmB_BuyUpdateM = new javax.swing.JComboBox<>();
  CmB_BuyUpdateD = new javax.swing.JComboBox<>();
  TF_BuyPrice = new javax.swing.JTextField();
  Lbl_BuyPrice = new javax.swing.JLabel();
  jScrollPane1 = new javax.swing.JScrollPane();
  TA_BuyComment = new javax.swing.JTextArea();
  Lbl_BuyComment = new javax.swing.JLabel();
  jScrollPane2 = new javax.swing.JScrollPane();
  TA_Comment = new javax.swing.JTextArea();
  Lbl_Comment = new javax.swing.JLabel();
  jSeparator1 = new javax.swing.JSeparator();
  jSeparator2 = new javax.swing.JSeparator();
  jSeparator3 = new javax.swing.JSeparator();
  jSeparator4 = new javax.swing.JSeparator();
  Lbl_PictureFile = new javax.swing.JLabel();
  jSeparator5 = new javax.swing.JSeparator();
  jSeparator6 = new javax.swing.JSeparator();
  Btn_Cancel = new javax.swing.JButton();
  Btn_Ok = new javax.swing.JButton();
  Lbl_CommentHelp = new javax.swing.JLabel();
  Lbl_BuyPriceHelp = new javax.swing.JLabel();
  Lbl_BuyCommentHelp = new javax.swing.JLabel();
  TF_PictureFile = new javax.swing.JTextField();
  Btn_PictureFileSetNull = new javax.swing.JButton();
  Btn_PictureFileChoose = new javax.swing.JButton();
  Pnl_PictureFile = new XImgBoxURL();
  Btn_BuyUpdateSetToday = new javax.swing.JButton();

  setModal(true);
  setResizable(false);
  addWindowListener(new java.awt.event.WindowAdapter() {
   public void windowActivated(java.awt.event.WindowEvent evt) {
    formWindowActivated(evt);
   }
   public void windowClosing(java.awt.event.WindowEvent evt) {
    formWindowClosing(evt);
   }
  });

  TF_Variant.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_VariantKeyPressed(evt);
   }
  });

  Lbl_Variant.setText("Varian");

  Lbl_VariantHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_VariantHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_VariantHelp.setText("(?)");
  Lbl_VariantHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_VariantHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_VariantHelpMouseClicked(evt);
   }
  });

  CB_IsActive.setText(" ");
  CB_IsActive.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_IsActive.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_IsActiveKeyPressed(evt);
   }
  });

  Lbl_IsActive.setText("Aktif");

  CB_BuyUpdateIsSet.setText(" ");
  CB_BuyUpdateIsSet.setIconTextGap(0);
  CB_BuyUpdateIsSet.setMargin(new java.awt.Insets(0, 0, 0, 0));
  CB_BuyUpdateIsSet.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    CB_BuyUpdateIsSetActionPerformed(evt);
   }
  });
  CB_BuyUpdateIsSet.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CB_BuyUpdateIsSetKeyPressed(evt);
   }
  });

  Lbl_BuyUpdate.setText("Tgl Pembaruan");

  TF_BuyUpdateY.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyUpdateYKeyPressed(evt);
   }
  });

  CmB_BuyUpdateM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01 - Januari", "02 - Februari", "03 - Maret", "04 - April", "05 - Mei", "06 - Juni", "07 - Juli", "08 - Agustus", "09 - September", "10 - Oktober", "11 - Nopember", "12 - Desember" }));
  CmB_BuyUpdateM.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateMKeyPressed(evt);
   }
  });

  CmB_BuyUpdateD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
  CmB_BuyUpdateD.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    CmB_BuyUpdateDKeyPressed(evt);
   }
  });

  TF_BuyPrice.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TF_BuyPriceKeyPressed(evt);
   }
  });

  Lbl_BuyPrice.setText("Harga Beli");

  TA_BuyComment.setColumns(20);
  TA_BuyComment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_BuyCommentKeyPressed(evt);
   }
  });
  jScrollPane1.setViewportView(TA_BuyComment);

  Lbl_BuyComment.setText("Ket. Harga Beli");

  TA_Comment.setColumns(20);
  TA_Comment.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    TA_CommentKeyPressed(evt);
   }
  });
  jScrollPane2.setViewportView(TA_Comment);

  Lbl_Comment.setText("Keterangan");

  Lbl_PictureFile.setText("Gambar");

  Btn_Cancel.setText("Cancel {Esc}");
  Btn_Cancel.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Cancel.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_CancelActionPerformed(evt);
   }
  });
  Btn_Cancel.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_CancelKeyPressed(evt);
   }
  });

  Btn_Ok.setText("Ok {F11}");
  Btn_Ok.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_Ok.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_OkActionPerformed(evt);
   }
  });
  Btn_Ok.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_OkKeyPressed(evt);
   }
  });

  Lbl_CommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_CommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_CommentHelp.setText("(?)");
  Lbl_CommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_CommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_CommentHelpMouseClicked(evt);
   }
  });

  Lbl_BuyPriceHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyPriceHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyPriceHelp.setText("(?)");
  Lbl_BuyPriceHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyPriceHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyPriceHelpMouseClicked(evt);
   }
  });

  Lbl_BuyCommentHelp.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
  Lbl_BuyCommentHelp.setForeground(new java.awt.Color(0, 130, 102));
  Lbl_BuyCommentHelp.setText("(?)");
  Lbl_BuyCommentHelp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
  Lbl_BuyCommentHelp.addMouseListener(new java.awt.event.MouseAdapter() {
   public void mouseClicked(java.awt.event.MouseEvent evt) {
    Lbl_BuyCommentHelpMouseClicked(evt);
   }
  });

  TF_PictureFile.setEditable(false);
  TF_PictureFile.setBackground(new java.awt.Color(204, 255, 204));

  Btn_PictureFileSetNull.setText("-");
  Btn_PictureFileSetNull.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PictureFileSetNull.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PictureFileSetNullActionPerformed(evt);
   }
  });
  Btn_PictureFileSetNull.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PictureFileSetNullKeyPressed(evt);
   }
  });

  Btn_PictureFileChoose.setText("...");
  Btn_PictureFileChoose.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_PictureFileChoose.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_PictureFileChooseActionPerformed(evt);
   }
  });
  Btn_PictureFileChoose.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_PictureFileChooseKeyPressed(evt);
   }
  });

  Btn_BuyUpdateSetToday.setText("Hari Ini");
  Btn_BuyUpdateSetToday.setMargin(new java.awt.Insets(1, 3, 1, 3));
  Btn_BuyUpdateSetToday.addActionListener(new java.awt.event.ActionListener() {
   public void actionPerformed(java.awt.event.ActionEvent evt) {
    Btn_BuyUpdateSetTodayActionPerformed(evt);
   }
  });
  Btn_BuyUpdateSetToday.addKeyListener(new java.awt.event.KeyAdapter() {
   public void keyPressed(java.awt.event.KeyEvent evt) {
    Btn_BuyUpdateSetTodayKeyPressed(evt);
   }
  });

  javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
  getContentPane().setLayout(layout);
  layout.setHorizontalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createSequentialGroup()
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
       .addComponent(Lbl_IsActive, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
       .addGroup(layout.createSequentialGroup()
        .addComponent(Lbl_Variant)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_VariantHelp))
       .addComponent(Lbl_BuyUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
       .addGroup(layout.createSequentialGroup()
        .addComponent(Lbl_BuyPrice)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_BuyPriceHelp))
       .addGroup(layout.createSequentialGroup()
        .addComponent(Lbl_BuyComment)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_BuyCommentHelp))
       .addGroup(layout.createSequentialGroup()
        .addComponent(Lbl_Comment)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Lbl_CommentHelp))
       .addComponent(jSeparator2)
       .addComponent(jSeparator4)
       .addComponent(jSeparator6)
       .addComponent(Lbl_PictureFile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
      .addGap(18, 18, 18)
      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
       .addComponent(TF_Variant)
       .addComponent(TF_BuyPrice)
       .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 372, Short.MAX_VALUE)
       .addComponent(jScrollPane2)
       .addComponent(jSeparator1)
       .addComponent(jSeparator3)
       .addComponent(jSeparator5)
       .addGroup(layout.createSequentialGroup()
        .addComponent(TF_PictureFile)
        .addGap(0, 0, 0)
        .addComponent(Btn_PictureFileChoose)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_PictureFileSetNull))
       .addGroup(layout.createSequentialGroup()
        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addComponent(CB_IsActive)
         .addComponent(Pnl_PictureFile, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
        .addGap(0, 0, Short.MAX_VALUE))
       .addGroup(layout.createSequentialGroup()
        .addComponent(CB_BuyUpdateIsSet)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(TF_BuyUpdateY, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BuyUpdateM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(CmB_BuyUpdateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
        .addComponent(Btn_BuyUpdateSetToday))))
     .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addGap(0, 0, Short.MAX_VALUE)
      .addComponent(Btn_Ok)
      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(Btn_Cancel)))
    .addContainerGap())
  );
  layout.setVerticalGroup(
   layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
   .addGroup(layout.createSequentialGroup()
    .addContainerGap()
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_Variant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_Variant)
     .addComponent(Lbl_VariantHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_IsActive)
     .addComponent(Lbl_IsActive))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_Comment)
      .addComponent(Lbl_CommentHelp))
     .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator1)
     .addComponent(jSeparator2))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(CB_BuyUpdateIsSet)
     .addComponent(Lbl_BuyUpdate)
     .addComponent(TF_BuyUpdateY, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(CmB_BuyUpdateD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_BuyUpdateSetToday))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(TF_BuyPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Lbl_BuyPrice)
     .addComponent(Lbl_BuyPriceHelp))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
     .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
      .addComponent(Lbl_BuyComment)
      .addComponent(Lbl_BuyCommentHelp))
     .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator3)
     .addComponent(jSeparator4))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Lbl_PictureFile)
     .addComponent(TF_PictureFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
     .addComponent(Btn_PictureFileSetNull)
     .addComponent(Btn_PictureFileChoose))
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
    .addComponent(Pnl_PictureFile, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
     .addComponent(jSeparator5)
     .addComponent(jSeparator6))
    .addGap(18, 18, 18)
    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
     .addComponent(Btn_Cancel)
     .addComponent(Btn_Ok))
    .addContainerGap())
  );

  pack();
 }// </editor-fold>//GEN-END:initComponents

 private void CB_BuyUpdateIsSetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CB_BuyUpdateIsSetActionPerformed
  PGUI.enableInput(CB_BuyUpdateIsSet.isSelected(), TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD, false);
 }//GEN-LAST:event_CB_BuyUpdateIsSetActionPerformed

 private void Btn_PictureFileChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PictureFileChooseActionPerformed
  IFV.FileChooser.setFileFilter(IFV.ImageFileFilter);
  IFV.FileChooser.setMultiSelectionEnabled(false);
  if(IFV.FileChooser.showDialog(null, "Pilih")!=JFileChooser.APPROVE_OPTION){return;}
  
  setPictureFile(IFV.FileChooser.getSelectedFile().getName());
 }//GEN-LAST:event_Btn_PictureFileChooseActionPerformed

 private void Btn_PictureFileSetNullActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_PictureFileSetNullActionPerformed
  setPictureFile(null);
 }//GEN-LAST:event_Btn_PictureFileSetNullActionPerformed

 private void Btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_OkActionPerformed
  OValidation Valid;
  boolean CurrCheck;
  
  Valid=new OValidation(true);
  
  CurrCheck=PText.checkInput(TF_Variant.getText(), false, 150, 0, 0, 0, 0);
  Lbl_Variant.setForeground((Color)PCore.subtituteBool(CurrCheck, CGUI.Color_Label_InputRight, CGUI.Color_Label_InputWrong));
  if(!CurrCheck){Valid.addError("\n- Varian belum benar.");}
  Info.Variant=TF_Variant.getText();
  
  Info.IsActive=CB_IsActive.isSelected();
  
  CurrCheck=PText.checkInput(TA_Comment.getText(), true, CApp.DbVarcharMaxSize, 0, 0, 0, 0);
  Lbl_Comment.setForeground((Color)PCore.subtituteBool(CurrCheck, CGUI.Color_Label_InputRight, CGUI.Color_Label_InputWrong));
  if(!CurrCheck){Valid.addError("\n- Keterangan belum benar.");}
  Info.Comment=PText.getString(TA_Comment.getText(), null, true);
  
  CurrCheck=PText.checkInput(TF_BuyPrice.getText(), false, CCore.CharsCount_Deci(), 6, 6, 6, 6);
  Lbl_BuyPrice.setForeground((Color)PCore.subtituteBool(CurrCheck, CGUI.Color_Label_InputRight, CGUI.Color_Label_InputWrong));
  if(!CurrCheck){Valid.addError("\n- Harga Beli belum benar.");}
  Info.BuyPrice=PText.parseDouble(TF_BuyPrice.getText(), 0D, 0D);
  
  CurrCheck=PText.checkInput(TA_BuyComment.getText(), true, CApp.DbVarcharMaxSize, 0, 0, 0, 0);
  Lbl_BuyComment.setForeground((Color)PCore.subtituteBool(CurrCheck, CGUI.Color_Label_InputRight, CGUI.Color_Label_InputWrong));
  if(!CurrCheck){Valid.addError("\n- Keterangan Harga Beli belum benar.");}
  Info.BuyComment=PText.getString(TA_BuyComment.getText(), null, true);
  
  CurrCheck=true; if(CB_BuyUpdateIsSet.isSelected()){CurrCheck=PGUI.valueOfDateComponent(TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD)!=null;}
  Lbl_BuyUpdate.setForeground((Color)PCore.subtituteBool(CurrCheck, CGUI.Color_Label_InputRight, CGUI.Color_Label_InputWrong));
  if(!CurrCheck){Valid.addError("\n- Tanggal Pembaruan belum benar.");}
  Info.BuyUpdate=null; if(CB_BuyUpdateIsSet.isSelected()){Info.BuyUpdate=PGUI.valueOfDateComponent(TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD);}
  
  Info.PictureFile=I_PictureFile;
  
  if(!Valid.getValid()){JOptionPane.showMessageDialog(null, "Terdapat masukan yg masih salah (berwarna merah) :\n"+Valid.getError()); return;}
  
  closingForm(1);
  setVisible(false);
 }//GEN-LAST:event_Btn_OkActionPerformed

 private void Btn_CancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_CancelActionPerformed
  formWindowClosing(null);
  setVisible(false);
 }//GEN-LAST:event_Btn_CancelActionPerformed

 private void Lbl_VariantHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_VariantHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, 150, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_VariantHelpMouseClicked

 private void Lbl_CommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_CommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_CommentHelpMouseClicked

 private void Lbl_BuyPriceHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyPriceHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(false, CCore.CharsCount_Deci(), 6, 6, 6, 6, false));
 }//GEN-LAST:event_Lbl_BuyPriceHelpMouseClicked

 private void Lbl_BuyCommentHelpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Lbl_BuyCommentHelpMouseClicked
  JOptionPane.showMessageDialog(null, PText.getInputInfo(true, CApp.DbVarcharMaxSize, 0, 0, 0, 0, true));
 }//GEN-LAST:event_Lbl_BuyCommentHelpMouseClicked

 private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
  boolean ModeAdd=wMode==1;
  
  if(Activ){return;}
  
  Activ=true;
  
  setTitle(PText.getString(ModeAdd, "Tambah Varian Pada Barang", "Ubah Varian Pada Barang"));
  
  PGUI.setDateComponent(new Date(), CB_BuyUpdateIsSet, TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD, false);
  
  if(ModeAdd){
   PGUI.requestFocusInWindow(TF_Variant);
  }
  else{
   fillComponentsWithSetVariables();
   
   PGUI.requestFocusInWindow(TF_BuyPrice);
  }
 }//GEN-LAST:event_formWindowActivated

 private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
  closingForm(0);
 }//GEN-LAST:event_formWindowClosing

 private void TF_VariantKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_VariantKeyPressed
  PNav.onKey_TF(this, TF_Variant, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant()),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_IsActive)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_VariantKeyPressed

 private void CB_IsActiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_IsActiveKeyPressed
  PNav.onKey_CB(this, CB_IsActive, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_Variant)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_Comment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_CB_IsActiveKeyPressed

 private void TA_CommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_CommentKeyPressed
  PNav.onKey_TA(this, TA_Comment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_IsActive)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(CB_BuyUpdateIsSet)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_CommentKeyPressed

 private void CB_BuyUpdateIsSetKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CB_BuyUpdateIsSetKeyPressed
  PNav.onKey_CB(this, CB_BuyUpdateIsSet, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(TF_BuyUpdateY, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CB_BuyUpdateIsSetKeyPressed

 private void TF_BuyUpdateYKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyUpdateYKeyPressed
  PNav.onKey_TF(this, TF_BuyUpdateY, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CB_BuyUpdateIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateM, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_TF_BuyUpdateYKeyPressed

 private void CmB_BuyUpdateMKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateMKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateM, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(TF_BuyUpdateY, CB_BuyUpdateIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(CmB_BuyUpdateD, Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CmB_BuyUpdateMKeyPressed

 private void CmB_BuyUpdateDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CmB_BuyUpdateDKeyPressed
  PNav.onKey_CmB(this, CmB_BuyUpdateD, true, false, false, CNav.StateKey_Pressed, evt,
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateM, CB_BuyUpdateIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_BuyUpdateSetToday)));
 }//GEN-LAST:event_CmB_BuyUpdateDKeyPressed

 private void TF_BuyPriceKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TF_BuyPriceKeyPressed
  PNav.onKey_TF(this, TF_BuyPrice, true, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(CB_BuyUpdateIsSet)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TA_BuyComment)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TF_BuyPriceKeyPressed

 private void TA_BuyCommentKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TA_BuyCommentKeyPressed
  PNav.onKey_TA(this, TA_BuyComment, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TF_BuyPrice)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_PictureFileChoose)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_TA_BuyCommentKeyPressed

 private void Btn_PictureFileChooseKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PictureFileChooseKeyPressed
  PNav.onKey_Btn(this, Btn_PictureFileChoose, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_PictureFileSetNull)));
 }//GEN-LAST:event_Btn_PictureFileChooseKeyPressed

 private void Btn_PictureFileSetNullKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_PictureFileSetNullKeyPressed
  PNav.onKey_Btn(this, Btn_PictureFileSetNull, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_BuyComment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(Btn_Ok)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_PictureFileChoose)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_PictureFileSetNullKeyPressed

 private void Btn_OkKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_OkKeyPressed
  PNav.onKey_Btn(this, Btn_Ok, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PictureFileChoose)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant()),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant(Btn_Cancel)));
 }//GEN-LAST:event_Btn_OkKeyPressed

 private void Btn_CancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_CancelKeyPressed
  PNav.onKey_Btn(this, Btn_Cancel, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(Btn_PictureFileChoose)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant()),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(Btn_Ok)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_CancelKeyPressed

 private void Btn_BuyUpdateSetTodayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Btn_BuyUpdateSetTodayActionPerformed
  PGUI.setDateComponent(new Date(), CB_BuyUpdateIsSet, TF_BuyUpdateY, CmB_BuyUpdateM, CmB_BuyUpdateD, false);
 }//GEN-LAST:event_Btn_BuyUpdateSetTodayActionPerformed

 private void Btn_BuyUpdateSetTodayKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Btn_BuyUpdateSetTodayKeyPressed
  PNav.onKey_Btn(this, Btn_BuyUpdateSetToday, true, false, false, CNav.StateKey_Pressed, evt,
   /* Up    */  CNav.B_FcsCstm_Up.init(PCore.objArrVariant(TA_Comment)),
   /* Down  */  CNav.B_FcsCstm_Dw.init(PCore.objArrVariant(TF_BuyPrice)),
   /* Left  */  CNav.B_FcsCstm_Lf.init(PCore.objArrVariant(CmB_BuyUpdateD, CB_BuyUpdateIsSet)),
   /* Right */  CNav.B_FcsCstm_Rg.init(PCore.objArrVariant()));
 }//GEN-LAST:event_Btn_BuyUpdateSetTodayKeyPressed

 // Variables declaration - do not modify//GEN-BEGIN:variables
 private javax.swing.JButton Btn_BuyUpdateSetToday;
 private javax.swing.JButton Btn_Cancel;
 private javax.swing.JButton Btn_Ok;
 private javax.swing.JButton Btn_PictureFileChoose;
 private javax.swing.JButton Btn_PictureFileSetNull;
 private javax.swing.JCheckBox CB_BuyUpdateIsSet;
 private javax.swing.JCheckBox CB_IsActive;
 private javax.swing.JComboBox<String> CmB_BuyUpdateD;
 private javax.swing.JComboBox<String> CmB_BuyUpdateM;
 private javax.swing.JLabel Lbl_BuyComment;
 private javax.swing.JLabel Lbl_BuyCommentHelp;
 private javax.swing.JLabel Lbl_BuyPrice;
 private javax.swing.JLabel Lbl_BuyPriceHelp;
 private javax.swing.JLabel Lbl_BuyUpdate;
 private javax.swing.JLabel Lbl_Comment;
 private javax.swing.JLabel Lbl_CommentHelp;
 private javax.swing.JLabel Lbl_IsActive;
 private javax.swing.JLabel Lbl_PictureFile;
 private javax.swing.JLabel Lbl_Variant;
 private javax.swing.JLabel Lbl_VariantHelp;
 private XImgBoxURL Pnl_PictureFile;
 private javax.swing.JTextArea TA_BuyComment;
 private javax.swing.JTextArea TA_Comment;
 private javax.swing.JTextField TF_BuyPrice;
 private javax.swing.JTextField TF_BuyUpdateY;
 private javax.swing.JTextField TF_PictureFile;
 private javax.swing.JTextField TF_Variant;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JScrollPane jScrollPane2;
 private javax.swing.JSeparator jSeparator1;
 private javax.swing.JSeparator jSeparator2;
 private javax.swing.JSeparator jSeparator3;
 private javax.swing.JSeparator jSeparator4;
 private javax.swing.JSeparator jSeparator5;
 private javax.swing.JSeparator jSeparator6;
 // End of variables declaration//GEN-END:variables
}
