import java.util.Date;

public class OEditTransPayment {
 
 boolean EditPayDate; Date EditedPayDate;
 boolean EditCash; Integer EditedCashId; String EditedCashName;
 boolean EditPrice; Double EditedPrice;
 boolean EditComment; boolean ReplaceSubComment; String SubComment; String EditedComment;

 public OEditTransPayment(){clearAll();}
 
 OEditTransPayment clearAll(){
  init(
   false, null,
   false, -1, null,
   false, -1,
   false, false, null, null);
  
  return this;
 }
 OEditTransPayment init(
  boolean EditPayDate, Date EditedPayDate,
  boolean EditCash, int EditedCashId, String EditedCashName,
  boolean EditPrice, double EditedPrice,
  boolean EditComment, boolean ReplaceSubComment, String SubComment, String EditedComment) {
  
  this.EditPayDate = EditPayDate; this.EditedPayDate = EditedPayDate;
  this.EditCash = EditCash; this.EditedCashId = EditedCashId; this.EditedCashName = EditedCashName;
  this.EditPrice = EditPrice; this.EditedPrice = EditedPrice;
  this.EditComment = EditComment; this.ReplaceSubComment = ReplaceSubComment; this.SubComment = SubComment; this.EditedComment = EditedComment;
  
  return this;
 }
 
}