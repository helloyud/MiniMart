public abstract class XFormPreview extends XFormDialog {
 
 public abstract boolean proceed(Object AKey);
 public abstract String getName();
 
}