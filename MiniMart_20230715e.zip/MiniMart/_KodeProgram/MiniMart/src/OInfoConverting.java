import java.util.Date;
import java.util.Vector;

public class OInfoConverting {
 
 long Id;
 Date ConvDate;
 int ReasonOfConvId; String ReasonOfConvName;
 
 OInfoConvertRule ConvRule;
 boolean ConvRuleDirection;
 double ConvRuleCount;
 
 Vector<Object[]> ListItemOut;
 Vector<Object[]> ListItemIn;
 
}