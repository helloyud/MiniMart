import java.awt.Font;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;

class OPrintGeneratorReceipt extends OPrintGenerator{

 long TransId;
 boolean IsPreTrans;
 boolean ShowItemIn;
 boolean ShowItemOut;
 boolean UseIdExternal;
 
 String DbTable;

 OParameterValueGroup ShopInfo;
 String ShopName, ShopDescription, ShopAddress, ShopContact, ShopWorkingHour;
 String TransIdExternal;
 Date TransDate;
 String TransType;
 String TransSubject;
 int TotalItem;
 double TotalPrice;
 
 boolean IsHeader;
 boolean IsEnd;
 
 int BodyOp; // ItemIn : 1 Header, 2 List, 3 Summary, ItemOut : 4 Header, 5 List, 6 Summary
 
 long CurrItemId;
 String CurrItemName;
 double CurrItemQty;
 double CurrItemPriceTotal;
 double CurrItemPriceUnit;
 String CurrItemComment;
 Vector<String> CurrItemDescription;
 
 // layout variables
  // paper
 double MinimalThermalPaperHeightCut;
  // header
 Font FntShop;
 int ShopColumnCount;
 double ShopLineSpacing, ShopBaselineHeight, ShopHeight;
 final int TransIdCount=18+3;
 final int TransDateCount=11;
 int SubjectFit, TransTypeFit;
  // item
 double ItemHeaderAddLineSpacing;
 double ItemAddLineSpacing;
 int ItemQuantityPos;
 final int MiddleWordMinimalSpaceBetween=1;
 final int MiddleWordMinimalFit=2;
 double TotalPriceAddLineSpacing;
  // sum of item header, item list, item total price, & footer
 double ItemHeaderHeight, ItemHeight, TotalPriceHeight;
 
 OPrintGeneratorReceipt(OFont FontStandard) {
  super(FontStandard);
  ShopInfo=new OParameterValueGroup();
  ShopInfo.addElement(new OParameterValue(CApp.ParamShopName, CCore.TypeString, null, null, false, false));
  ShopInfo.addElement(new OParameterValue(CApp.ParamShopDescription, CCore.TypeString, null, null, false, false));
  ShopInfo.addElement(new OParameterValue(CApp.ParamShopAddress, CCore.TypeString, null, null, false, false));
  ShopInfo.addElement(new OParameterValue(CApp.ParamShopContact, CCore.TypeString, null, null, false, false));
  ShopInfo.addElement(new OParameterValue(CApp.ParamShopWorkingHour, CCore.TypeString, null, null, false, false));
 }
 
 public void setPrintVariables(OPaper PaperType, OFont FontCustom, OFont FontCustomThermal,
  Statement Stm, long TransId, boolean IsPreTrans, boolean ShowItemIn, boolean ShowItemOut, boolean UseIdExternal){
  this.PaperType=PaperType;
  this.Stm=Stm;
  this.TransId=TransId;
  this.IsPreTrans=IsPreTrans;
  this.ShowItemIn=ShowItemIn;
  this.ShowItemOut=ShowItemOut;
  this.UseIdExternal=UseIdExternal;
  this.FontCustom=FontCustom;
  this.FontCustomThermal=FontCustomThermal;
 }
 
	protected boolean hasHeader(){return false;}
 protected boolean hasFooter(){return false;}
 protected int getMinimalColumnarColumnCount(){return 30;}
 protected boolean isFooterWithLine(){return false;}
 protected OFont getCurrentFontCustom(){
  if(!PaperType.IsRollPaper){return FontCustom;}
  else{return FontCustomThermal;}
 }
 protected OFontLayout getFontStandardLayout(){
  OFontLayout ret=null;
  
  do{
   if(PaprWidth>=CPrint.Thermal100.RealWidth){ret=new OFontLayout(9.0f, false, false); break;}
   if(PaprWidth>=CPrint.Thermal70.RealWidth){ret=new OFontLayout(8.35f, false, false); break;}
   if(PaprWidth>=CPrint.Thermal57.RealWidth){ret=new OFontLayout(7.75f, false, false); break;}
   ret=new OFontLayout(4, false, false);
  }while(false);
  
  return ret;
 }
 protected void calculateLayoutVar() throws Exception{
  ODrawInfoString FntShopMetrics;
  
  MinimalThermalPaperHeightCut=170;
  
  ItemHeaderAddLineSpacing=11;
  ItemAddLineSpacing=4;
  TotalPriceAddLineSpacing=7;
  
  // header
  FntShop=PFont.getFont(FontType.getFamily(), (float)(FontType.getSize2D()*0.95), false, false);
  FntShopMetrics=PGraphics.getDrawInfoString(FntShop);
  ShopColumnCount=(int)(ColumnarWidth/FntShopMetrics.SingleCharWidth);
  Txt2=new char[ShopColumnCount];
  ShopLineSpacing=1;
  ShopBaselineHeight=ShopLineSpacing+FntShopMetrics.LineAscent;
  ShopHeight=ShopLineSpacing+FntShopMetrics.LineHeight;
  
  SubjectFit=PageColumnCount-(TransIdCount+2);
  TransTypeFit=PageColumnCount-(TransDateCount+2);

  // item
  ItemQuantityPos=2;

  ItemHeaderHeight=ItemHeaderAddLineSpacing+NormalHeight;
  TotalPriceHeight=TotalPriceAddLineSpacing+NormalHeight;
 }
 protected void prepareFirstPageData() throws Exception{
  if(!IsPreTrans){DbTable="Trans";}
  else{DbTable="PreTrans";}
  
  // get transaction's info
  Rs=Stm.executeQuery(
   "select InfoIdExternal, TransDate, TransType.Name as 'TransTypeName', Subject.Name as 'SubjectName' from "+
     "(select "+DbTable+".* from "+DbTable+" where Id="+TransId+") as tb1 "+
    "left join TransType on tb1.TransType=TransType.Id left join Subject on tb1.Subject=Subject.Id;"
  );
  if(!Rs.next()){throw new Exception();}
  TransIdExternal=Rs.getString(1);
  TransDate=Rs.getDate(2);
  TransType=Rs.getString(3); if(TransType==null){TransType="~";}
  TransSubject=Rs.getString(4); if(TransSubject==null){TransSubject="~";}
  
  // get shop's info (optional)
  ShopInfo=PDatabase.parameterValueGet(Stm, null, "ApplicationInfo", ShopInfo);
  ShopName=PText.getStringObj(ShopInfo.getValue(CApp.ParamShopName, false, 0), "~NamaToko~", false);
  ShopDescription=PText.getStringObj(ShopInfo.getValue(CApp.ParamShopDescription, false, 0), "~DeskripsiToko~", false);
  ShopAddress=PText.getStringObj(ShopInfo.getValue(CApp.ParamShopAddress, false, 0), "~Alamat~", false);
  ShopContact=PText.getStringObj(ShopInfo.getValue(CApp.ParamShopContact, false, 0), "~Kontak~", false);
  ShopWorkingHour=PText.getStringObj(ShopInfo.getValue(CApp.ParamShopWorkingHour, false, 0), "~Hari&JamKerja~", false);
  
  IsHeader=true;
  IsEnd=false;
 }
 protected void addHeader() throws Exception{}
 protected boolean addColumnar() throws Exception{
		boolean KeepPrinting=true;
  double temp_d;
		
		addReceiptHeader();
		
  do{
   // Item Header
   if(BodyOp==1 || BodyOp==4){
    addItemHeader(BodyOp==1);
    BodyOp=BodyOp+1;
    continue;
   }
   // Item List
   if(BodyOp==2 || BodyOp==5){
    addAnItemList((BodyOp==2 && ShowItemIn) || (BodyOp==5 && ShowItemOut));
    temp_d=FooterHeight+OrientedPaprMarginBottomAddLineSpacing;
    if(getCurrItemData()){temp_d=temp_d+ItemHeight;}
    else{
     temp_d=temp_d+TotalPriceHeight;
     BodyOp=BodyOp+1;
    }
    if(checkOverColumnarHeight(temp_d)){break;}
    continue;
   }
   // Item Summary
   if(BodyOp==3 || BodyOp==6){
    addItemsTotalPrice();
    if(BodyOp==6){IsEnd=true; break;}
    if(!getItemList(false)){IsEnd=true; break;}
    BodyOp=BodyOp+1;
    if(checkOverColumnarHeight(ItemHeaderHeight+ItemHeight+FooterHeight+OrientedPaprMarginBottomAddLineSpacing)){break;}
    continue;
   }
   break;
  }while(KeepPrinting);
		
		addReceiptFooter();
		
		return false;
 }
 protected void addFooter() throws Exception{}
 protected boolean isCurrentPaperIsRollPaper(){return PaperType.IsRollPaper;}
 protected double getCurrentRollPaperHeight(){
  double ret=OrientedPaprImageableY+BaseY+CurrY+OrientedPaprMarginBottom;
  if(ret<MinimalThermalPaperHeightCut){ret=MinimalThermalPaperHeightCut;}
  return ret;
 }
 protected double getCurrentRollPaperImageableHeight(){return BaseY+CurrY;}
 protected boolean prepareNextPage(){
  return !IsEnd;
 }
 protected void clearVar(){
  
 }
 
 // 
	private void addReceiptHeader() throws Exception{
  int temp, count;
		String strid, stridvalue;
  Vector<String> strv;
		
		if(!IsHeader){return;}
		
		// draw shop info
			// shop name
		PText.refillChars(Txt2, ' ');
		PText.fillStringToChars(Txt2, PText.fitString(ShopName, ShopColumnCount, true, ShopColumnCount-1, 1, '~'), (ShopColumnCount/2)-1, 2);
		DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+ShopBaselineHeight, FntShop, new String(Txt2)));
		CurrY=CurrY+ShopHeight;
  
			// shop description
  strv=PText.multiLine(ShopDescription, ShopColumnCount);
		count=strv.size();
		temp=0;
		do{
			PText.refillChars(Txt2, ' ');
			PText.fillStringToChars(Txt2, strv.elementAt(temp), (ShopColumnCount/2)-1, 2);
			DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+ShopBaselineHeight, FntShop, new String(Txt2)));
			CurrY=CurrY+ShopHeight;
			temp=temp+1;
		}while(temp!=count);

			// shop address
		strv=PText.multiLine(ShopAddress, ShopColumnCount);
		count=strv.size();
		temp=0;
		do{
			PText.refillChars(Txt2, ' ');
			PText.fillStringToChars(Txt2, strv.elementAt(temp), (ShopColumnCount/2)-1, 2);
			DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+ShopBaselineHeight, FntShop, new String(Txt2)));
			CurrY=CurrY+ShopHeight;
			temp=temp+1;
		}while(temp!=count);

			// shop contact
		strv=PText.multiLine(ShopContact, ShopColumnCount);
		count=strv.size();
		temp=0;
		do{
			PText.refillChars(Txt2, ' ');
			PText.fillStringToChars(Txt2, strv.elementAt(temp), (ShopColumnCount/2)-1, 2);
			DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+ShopBaselineHeight, FntShop, new String(Txt2)));
			CurrY=CurrY+ShopHeight;
			temp=temp+1;
		}while(temp!=count);

			// shop working hour
		strv=PText.multiLine(ShopWorkingHour, ShopColumnCount);
		count=strv.size();
		temp=0;
		do{
			PText.refillChars(Txt2, ' ');
			PText.fillStringToChars(Txt2, strv.elementAt(temp), (ShopColumnCount/2)-1, 2);
			DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+ShopBaselineHeight, FntShop, new String(Txt2)));
			CurrY=CurrY+ShopHeight;
			temp=temp+1;
		}while(temp!=count);

		CurrY=CurrY+NormalHeight;

		PText.refillChars(TxtPage, ' ');
		PText.fillStringToChars(TxtPage, PText.fitString(TransType, TransTypeFit, true, TransTypeFit-1, 1, '~'), 0, 1);
		PText.fillStringToChars(TxtPage, PText.dateToString(TransDate, 2), PageColumnCount-1, 3);
		DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(TxtPage)));
		CurrY=CurrY+NormalHeight;

		PText.refillChars(TxtPage, ' ');
		strid="ID:"; if(IsPreTrans){strid="PR:";}
  stridvalue=String.valueOf(TransId);
  if(UseIdExternal){
   if(!PText.isEmptyString(TransIdExternal, true, true)){
    stridvalue="{"+PText.fitString(TransIdExternal, TransIdCount-strid.length()-2, false, (TransIdCount-strid.length()-2)-1, 1, '~')+"}";
   }
  }
  strid=strid+stridvalue;
		PText.fillStringToChars(TxtPage, strid, 0, 1);
  SubjectFit=PageColumnCount-(strid.length()+2);
		PText.fillStringToChars(TxtPage, PText.fitString(TransSubject, SubjectFit, true, SubjectFit-1, 1, '~'), PageColumnCount-1, 3);
		DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(TxtPage)));
		CurrY=CurrY+NormalHeight;

		DrawComponents.add(new ODrawComponentLine(BaseX, BaseY+CurrY+DrawLineSpacing, BaseX+ColumnarWidth, BaseY+CurrY+DrawLineSpacing+DrawLineWidth));
		CurrY=CurrY+DrawLineHeight;

		IsANewColumnar=false;

		IsHeader=false;

		do{
			if(getItemList(true)){BodyOp=1; break;}
			if(getItemList(false)){BodyOp=4; break;}
			BodyOp=0; IsEnd=true;
		}while(false);
	}
	private void addReceiptFooter() throws Exception{
  CurrY=CurrY+FooterAddLineSpacing;
  
  PText.refillChars(TxtPage, ' ');
  if(!IsEnd){
   PText.fillStringToChars(TxtPage, "* "+CurrPage+" - Lanjut *", (int)(PageColumnCount/2)-1, 2);
  }
  else{
   PText.fillStringToChars(TxtPage, "* "+CurrPage+" - Selesai *", (int)(PageColumnCount/2)-1, 2);
  }
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(TxtPage)));
  CurrY=CurrY+NormalHeight;
  
  CurrY=CurrY+OrientedPaprMarginBottomAddLineSpacing;
	}
 private void addItemHeader(boolean IsItemIn){
  if(!IsANewColumnar){CurrY=CurrY+ItemHeaderAddLineSpacing;}
  else{IsANewColumnar=false;}
  
  PText.refillChars(Txt, ' ');
  if(IsItemIn){
   PText.fillStringToChars(Txt, "--- Brg Masuk  ---", (int)(ColumnarColumnCount/2)-1, 2);
  }
  else{
   PText.fillStringToChars(Txt, "--- Brg Keluar ---", (int)(ColumnarColumnCount/2)-1, 2);
  }
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
  CurrY=CurrY+NormalHeight;
 }
 private void addAnItemList(boolean ShowPrice) throws Exception{
  int length_qty, length_price, space_left, fit_middleword, temp, length;
  
  if(!IsANewColumnar){CurrY=CurrY+ItemAddLineSpacing;}
  else{IsANewColumnar=false;}
  
  TotalItem=TotalItem+1;
  
  length=CurrItemDescription.size();
  temp=0;
  do{
   DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, CurrItemDescription.elementAt(temp)));
   CurrY=CurrY+NormalHeight;
   temp=temp+1;
  }while(temp!=length);
  
  PText.refillChars(Txt, ' ');
  str=PText.priceToString(CurrItemQty); length_qty=str.length();
  PText.fillStringToChars(Txt, str, ItemQuantityPos-1, 1);
  TotalPrice=TotalPrice+CurrItemPriceTotal;
  str=PText.getString(ShowPrice, PText.priceToString(CurrItemPriceTotal), "~~~"); length_price=str.length();
  PText.fillStringToChars(Txt, str, ColumnarColumnCount-1, 3);
  str=PText.getString(ShowPrice, "@"+PText.priceToString(CurrItemPriceUnit), "~~~");
  space_left=ColumnarColumnCount-((ItemQuantityPos-1)+length_qty+length_price);
  fit_middleword=space_left-(2*MiddleWordMinimalSpaceBetween);
  if(fit_middleword>=MiddleWordMinimalFit){
   PText.fillStringToChars(Txt, PText.fitString(str, fit_middleword, true, fit_middleword-1, 1, '~'), (ItemQuantityPos+length_qty+(int)(space_left/2)-1)-1, 2);
  }
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
  CurrY=CurrY+NormalHeight;
 }
 private void addItemsTotalPrice(){
  if(!IsANewColumnar){CurrY=CurrY+TotalPriceAddLineSpacing;}
  else{IsANewColumnar=false;}
  
  PText.refillChars(Txt, ' ');
  PText.fillStringToChars(Txt, "("+PText.intToString(TotalItem)+") Total", 0, 1);
  PText.fillStringToChars(Txt, PText.priceToString(TotalPrice), ColumnarColumnCount-1, 3);
  DrawComponents.add(new ODrawComponentText(BaseX, BaseY+CurrY+BaselineHeight, FontType, new String(Txt)));
  CurrY=CurrY+NormalHeight;
 }
 private boolean getItemList(boolean IsItemIn) throws Exception{
  boolean ret=false;
  String Tbl=null;
  if(!IsPreTrans){
   if(IsItemIn){Tbl="TransXItemIn";}else{Tbl="TransXItemOut";}
  }
  else{
   if(IsItemIn){Tbl="PreTransXItemIn";}else{Tbl="PreTransXItemOut";}
  }
   
  Rs=Stm.executeQuery("select tb1.Item, Item.Name, tb1.Stock, tb1.Price, tb1.Comment from "+
   "(select Item, Stock, Price, Comment from "+Tbl+" where "+DbTable+"="+TransId+") as tb1 left join Item on tb1.Item=Item.Id order by Item.Name;");
  if(getCurrItemData()){
   TotalItem=0;
   TotalPrice=0;
   ret=true;
  }
  return ret;
 }
 private boolean getCurrItemData() throws Exception{
  String ItemDescription;
  
  if(!Rs.next()){return false;}
  
  CurrItemId=Rs.getLong(1);
  CurrItemName=Rs.getString(2);
  CurrItemQty=Rs.getDouble(3);
  CurrItemPriceTotal=Rs.getDouble(4);
  CurrItemPriceUnit=CurrItemPriceTotal/CurrItemQty;
  CurrItemComment=Rs.getString(5);
  
  ItemDescription=
   CurrItemName+" ("+CurrItemId+")"+
   PText.getString(CurrItemComment, "", " {"+CurrItemComment+"}", true);
  
  CurrItemDescription=PText.multiLine(ItemDescription, ColumnarColumnCount);
  
  ItemHeight=ItemAddLineSpacing+CurrItemDescription.size()*NormalHeight+NormalHeight;
  
  return true;
 }
 
}