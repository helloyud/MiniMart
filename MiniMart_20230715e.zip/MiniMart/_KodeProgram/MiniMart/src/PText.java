import java.sql.ResultSet;
import java.util.Date;
import java.util.Calendar;
import java.util.Vector;

public class PText{
 
 static OGregorianCalendar Cal=new OGregorianCalendar();

 // check/validate input
 /* Parameters Info
    MaxLength :
    0  = don't check
    >0 = check
    
    CheckAll :
    0  = don't check
    1  = +(alphabet)
    2  = +(number)
    3  = +(alphabet, number)
    4  = +(alphabet, number, '_')
    6  = +(number, '.') <with dotcount, dotfirstpos, & zeroall>
    7  = +(number, '-') <with mincount, minfirstpos, & zeroall>
    8  = +(number, '-', '.') <with mincount, minfirstpos, dotcount, dotfirstpos, & zeroall>
    41 = -(space)
    42 = -('\', '/', ':', '*', '?', '"', '<', '>', '|')
    
    CheckFirst :
    0  = don't check
    1  = -(space)
    2  = -(number)
    3  = -(zero {except if characters count is 1})
    4  = -(space, '.')
    6  = -('.', zero {except if characters count is 1 or 2nd character is '.'})
    7  = -(zero)
    
    CheckLast :
    0  = don't check
    1  = -(space)
    4  = -(space, '.')
    6  = -('.')
    7  = -('-')
    8  = -('.', '-')
    
    OtherOption :
    0  = don't check
    6  = if '-' exist, then max count of '-' is 1, position of character '-' is 1
         if '.' not exist, then max length is "NumberDigit"
         if '.' exist, then max count of '.' is 1, max position of character '.' is "NumberDigit+1"
    7  = must have at least 1 number character beside number character '0'
         if '-' exist, then max count of '-' is 1, position of character '-' is 1
         if '.' not exist, then max length is "NumberDigit"
         if '.' exist, then max count of '.' is 1, max position of character '.' is "NumberDigit+1"
 */
 public static boolean checkInput(String Input, boolean AcceptEmpty, int MaxLength,
  int CheckAll, int CheckFirst, int CheckLast, int OtherOption){
  boolean ret=true;
  int length;
  int temp, pos, ch;
  int MaxDigitCountBeforeFraction=CCore.NumberDigit;
  int MaxDigitCountAfterFraction=CCore.FractionDigit;
  // indicator
   // etc
  boolean zeroall;
   // fraction indicator
  int dotcount, dotfirstpos;
   // min indicator
  int mincount, minfirstpos;
  
  length=Input.length();
  
  zeroall=true;
  dotcount=0; dotfirstpos=0;
  mincount=0; minfirstpos=0;
  
  do{
   
   // Validating Empty
   if(length==0){
    if(!AcceptEmpty){ret=false; break;}
    break;
   }
   
   // Validating MaxLength
   if(MaxLength>0 && length>MaxLength){ret=false; break;}
   
   // Validating CheckAll
   if(CheckAll!=0){
    temp=0;
    do{
     ch=(int)Input.charAt(temp);
     
     do{
      if(CheckAll==1){ // +(alphabet)
       if(!( (ch>='a' && ch<='z') || (ch>='A' && ch<='Z') )){ret=false; break;}
       break;
      }
      if(CheckAll==2){ // +(number)
       if(!( ch>='0' && ch<='9' )){ret=false; break;}
       break;
      }
      if(CheckAll==3){ // +(alphabet, number)
       if(!( (ch>='a' && ch<='z') || (ch>='A' && ch<='Z') || (ch>='0' && ch<='9') )){ret=false; break;}
       break;
      }
      if(CheckAll==4){ // +(alphabet, number, '_')
       if(!( (ch>='a' && ch<='z') || (ch>='A' && ch<='Z') || (ch>='0' && ch<='9') || ch=='_' )){ret=false; break;}
       break;
      }
      if(CheckAll==6){ // +(number, '.')
       if(!( (ch>='0' && ch<='9') || ch=='.' )){ret=false; break;}
       if(ch=='.'){
        if(dotcount==0){dotfirstpos=temp;}
        dotcount=dotcount+1;
       }
       if(zeroall){
        if(ch>='1' && ch<='9'){zeroall=false;}
       }
       break;
      }
      if(CheckAll==7){ // +(number, '-')
       if(!( (ch>='0' && ch<='9') || ch=='-' )){ret=false; break;}
       if(ch=='-'){
        if(mincount==0){minfirstpos=temp;}
        mincount=mincount+1;
       }
       if(zeroall){
        if(ch>='1' && ch<='9'){zeroall=false;}
       }
       break;
      }
      if(CheckAll==8){ // +(number, '-', '.')
       if(!( (ch>='0' && ch<='9') || ch=='-' || ch=='.' )){ret=false; break;}
       if(ch=='.'){
        if(dotcount==0){dotfirstpos=temp;}
        dotcount=dotcount+1;
       }
       if(ch=='-'){
        if(mincount==0){minfirstpos=temp;}
        mincount=mincount+1;
       }
       if(zeroall){
        if(ch>='1' && ch<='9'){zeroall=false;}
       }
       break;
      }
      if(CheckAll==41){ // -(' ')
       if(ch==' '){ret=false; break;}
       break;
      }
      if(CheckAll==42){ // -('\', '/', ':', '*', '?', '"', '<', '>', '|')
       if(ch=='\\' || ch=='/' || ch==':' || ch=='*' || ch=='?' || ch=='"' ||
        ch=='<' || ch=='>' || ch=='|'){ret=false; break;}
       break;
      }
     }while(false);
     if(!ret){break;}
     
     temp=temp+1;
    }while(temp!=length);
    if(!ret){break;}
   }
   
   // Validating CheckFirst
   if(CheckFirst!=0){
    pos=0; ch=(int)Input.charAt(pos); 
    
    do{
     if(CheckFirst==1){ // -(space)
      if(ch==' '){ret=false; break;}
      break;
     }
     if(CheckFirst==2){ // -(number)
      if(ch>='0' && ch<='9'){ret=false; break;}
      break;
     }
     if(CheckFirst==3){ // -(zero)
      if(ch=='-'){
       pos=pos+1; if(pos==length){break;}
       ch=(int)Input.charAt(pos);
      }
      if(ch=='0' && length>pos+1){ret=false; break;}
      break;
     }
     if(CheckFirst==4){ // -(space, '.')
      if(ch==' ' || ch=='.'){ret=false; break;}
      break;
     }
     if(CheckFirst==6){ // -('.')
      if(ch=='-'){
       pos=pos+1; if(pos==length){break;}
       ch=(int)Input.charAt(pos);
      }
      if(ch=='.'){ret=false; break;}
      if(ch=='0' && length>pos+1){
       if(Input.charAt(pos+1)!='.'){ret=false; break;}
      }
      break;
     }
     if(CheckFirst==7){ // -(zero)
      if(ch=='-'){
       pos=pos+1; if(pos==length){break;}
       ch=(int)Input.charAt(pos);
      }
      if(ch=='0'){ret=false; break;}
      break;
     }
    }while(false);
    if(!ret){break;}
    
   }
   
   // Validating CheckLast
   if(CheckLast!=0){
    ch=(int)Input.charAt(length-1);
    
    do{
     if(CheckLast==1){ // -(space)
      if(ch==' '){ret=false; break;}
      break;
     }
     if(CheckLast==4){ // -(space, '.')
      if(ch==' ' || ch=='.'){ret=false; break;}
      break;
     }
     if(CheckLast==6){ // -('.')
      if(ch=='.'){ret=false; break;}
      break;
     }
     if(CheckLast==7){ // -('-')
      if(ch=='-'){ret=false; break;}
      break;
     }
     if(CheckLast==8){ // -('.', '-')
      if(ch=='.' || ch=='-'){ret=false; break;}
      break;
     }
    }while(false);
    if(!ret){break;}
    
   }
   
   if(OtherOption!=0){
    
    do{
     if(OtherOption==6){
      // if '-' exist, then max count of '-' is 1, position of character '-' is 1
      // if '.' not exist, then max length is "NumberDigit"
      // if '.' exist, then max count of '.' is 1, max position of '.' is "NumberDigit+1"
      pos=0;
      if(mincount!=0){
       if(mincount!=1){ret=false; break;}
       if(minfirstpos!=0){ret=false; break;}
       if(zeroall){ret=false; break;}
       pos=pos+1;
      }
      if(dotcount==0){
       if(length>pos+MaxDigitCountBeforeFraction){ret=false; break;}
      }
      else{
       if(dotcount!=1){ret=false; break;}
       if(dotfirstpos>pos+MaxDigitCountBeforeFraction){ret=false; break;}
      }
      break;
     }
     if(OtherOption==7){
      // if '-' exist, then max count of '-' is 1, position of character '-' is 1
      // if '.' not exist, then max length is "NumberDigit"
      // if '.' exist, then max count of '.' is 1, max position of '.' is "NumberDigit+1"
      // non zero
      pos=0;
      if(mincount!=0){
       if(mincount!=1){ret=false; break;}
       if(minfirstpos!=0){ret=false; break;}
       if(zeroall){ret=false; break;}
       pos=pos+1;
      }
      if(dotcount==0){
       if(length>pos+MaxDigitCountBeforeFraction){ret=false; break;}
      }
      else{
       if(dotcount!=1){ret=false; break;}
       if(dotfirstpos>pos+MaxDigitCountBeforeFraction){ret=false; break;}
      }
      if(zeroall){ret=false; break;}
      break;
     }
    }while(false);
    if(!ret){break;}
    
   }
  }while(false);
  return ret;
 }
 public static String getInputInfo(boolean AcceptEmpty, int MaxLength,
  int CheckAll, int CheckFirst, int CheckLast, int OtherOption,
  boolean ShowDatabaseInputInfo){
  String info1="";
  String info2="";
  String info3="";
  String info4="";
  String info5="";
  String info6="";
  String info7="";
  if(AcceptEmpty==true){info1="- Data boleh tidak diisi.";}else{info1="- Data harus diisi.";}
  if(MaxLength!=0){info2="\n- Jumlah maksimal karakter ialah "+String.valueOf(MaxLength)+" karakter.";}
  switch(CheckAll){
   case 0  : info3="\n- Semua karakter diperbolehkan."; break;
   case 1  : info3="\n- Hanya diperbolehkan memasukkan karakter 'a-z A-Z'."; break;
   case 2  : info3="\n- Hanya diperbolehkan memasukkan karakter '0-9'."; break;
   case 3  : info3="\n- Hanya diperbolehkan memasukkan karakter 'a-z A-Z 0-9'."; break;
   case 4  : info3="\n- Hanya diperbolehkan memasukkan karakter 'a-z A-Z 0-9 _'."; break;
   case 6  : info3="\n- Hanya diperbolehkan memasukkan karakter '0-9 .'."; break;
   case 7  : info3="\n- Hanya diperbolehkan memasukkan karakter '0-9 -'."; break;
   case 8  : info3="\n- Hanya diperbolehkan memasukkan karakter '0-9 - .'."; break;
   case 41 : info3="\n- Diperbolehkan memasukkan semua karakter, kecuali karakter 'spasi'."; break;
   case 42 : info3="\n- Diperbolehkan memasukkan semua karakter, kecuali karakter '\\ / : * ? \" < > |'."; break;
  }
  switch(CheckFirst){
   case 1  : info4="\n- Tidak diperbolehkan memasukkan karakter 'spasi' di posisi pertama."; break;
   case 2  : info4="\n- Tidak diperbolehkan memasukkan karakter '0-9' di posisi pertama."; break;
   case 3  : info4="\n- Jika jumlah karakter lebih dari 1, maka tidak diperbolehkan\nmemasukkan karakter '0' (nol) di posisi pertama."; break;
   case 4  : info4="\n- Tidak diperbolehkan memasukkan karakter 'spasi .' di posisi pertama."; break;
   case 6  : info4=
    "\n- Tidak diperbolehkan memasukkan karakter '.' di posisi pertama."+
    "\n- Karakter '0' boleh berada di posisi pertama jika\njumlah karakter ialah 1 atau karakter ke-2 ialah '.'."; break;
   case 7  : info4="\n- Tidak diperbolehkan memasukkan karakter '0' di posisi pertama."; break;
  }
  switch(CheckLast){
   case 1  : info5="\n- Tidak diperbolehkan memasukkan karakter 'spasi' di posisi terakhir."; break;
   case 4  : info5="\n- Tidak diperbolehkan memasukkan karakter 'spasi .' di posisi terakhir."; break;
   case 6  : info5="\n- Tidak diperbolehkan memasukkan karakter '.' di posisi terakhir."; break;
   case 7  : info5="\n- Tidak diperbolehkan memasukkan karakter '-' di posisi terakhir."; break;
   case 8  : info5="\n- Tidak diperbolehkan memasukkan karakter '- .' di posisi terakhir."; break;
  }
  switch(OtherOption){
   case 6  : info6=
    "\n- Jika terdapat karakter '-', maka harus berada di posisi pertama."+
    "\n- Jika tidak terdapat karakter '.', maka jumlah maksimal digit ialah "+CCore.NumberDigit+"."+  
    "\n- Jika terdapat karakter '.', maka jumlah maksimal digit\nsebelum dan sesudah karakter '.' ialah "+CCore.NumberDigit+" dan "+CCore.FractionDigit+"."; break;
   case 7  : info6=
    "\n- Harus terdapat setidaknya 1 karakter '1-9'."+
    "\n- Jika terdapat karakter '-', maka harus berada di posisi pertama."+
    "\n- Jika tidak terdapat karakter '.', maka jumlah maksimal digit ialah "+CCore.NumberDigit+"."+  
    "\n- Jika terdapat karakter '.', maka jumlah maksimal digit\nsebelum dan sesudah karakter '.' ialah "+CCore.NumberDigit+" dan "+CCore.FractionDigit+"."; break;
  }
  if(ShowDatabaseInputInfo){
   /*
   info7=
    "\n- Jangan menginput karakter ' (kutip tunggal) pd data teks karena"+
    "\n    akan menghasilkan error ketika menyimpan atau mencari ke database.";
   */
  }
  
  return new String(info1+info2+info3+info4+info5+info6+info7);
 }

 // compare, search/find, and replace
 public static int findIndexChar(String Word, char Chr, int pos1, int pos2){
  int ret=-1; // -1 not found, >=0 found
  int temp, temp_;
  temp=pos2+1;
  temp_=pos1;
  do{
   if(Word.charAt(temp_)==Chr){
    ret=temp_;
    break;
   }
   temp_=temp_+1;
  }while(temp_!=temp);
  return ret;
 }
 public static int findIndexNotChar(String Word, char Chr, boolean FromLeft, int pos1, int pos2){
  int ret=-1; // -1 not found, >=0 found
  int temp, temp_;
  if(FromLeft==true){
   temp=pos2+1;
   temp_=pos1;
   do{
    if(Word.charAt(temp_)!=Chr){
     ret=temp_;
     break;
    }
    temp_=temp_+1;
   }while(temp_!=temp);
  }
  else{
   temp=pos1-1;
   temp_=pos2;
   do{
    if(Word.charAt(temp_)!=Chr){
     ret=temp_;
     break;
    }
    temp_=temp_-1;
   }while(temp_!=temp);
  }
  return ret;
 }
 public static int findSubString(String Word, String SubString, boolean CaseSensitive){
  int ret=-1;
  int temp1, temp2, temp3, temp4;
  int[] ch1, ch2;
		if(Word==null || SubString==null){return ret;}
  temp1=Word.length();
  temp3=SubString.length();
  if(temp1>=temp3 && temp1!=0 && temp3!=0){
   // create int[]
   ch1=new int[temp1];
   temp2=0;
   do{
    ch1[temp2]=(int)Word.charAt(temp2);
    if(!CaseSensitive){
     if(ch1[temp2]>=97 && ch1[temp2]<=122){ch1[temp2]=ch1[temp2]-32;}
    }
    temp2=temp2+1;
   }while(temp2!=temp1);
   ch2=new int[temp3];
   temp2=0;
   do{
    ch2[temp2]=(int)SubString.charAt(temp2);
    if(!CaseSensitive){
     if(ch2[temp2]>=97 && ch2[temp2]<=122){ch2[temp2]=ch2[temp2]-32;}
    }
    temp2=temp2+1;
   }while(temp2!=temp3);
   // check
   temp2=temp1-temp3+1;
   temp1=0;
   temp4=temp3;
   do{
    temp3=0;
    do{
     if(ch1[temp1+temp3]!=ch2[temp3]){break;}
     temp3=temp3+1;
    }while(temp3!=temp4);
    if(temp3==temp4){ret=temp1; break;}
    temp1=temp1+1;
   }while(temp1!=temp2);
  }
  return ret;
 }
 public static boolean findSubString(String Word, String SubString, boolean CaseSensitive,
  boolean DoBrokeWords, char[] BySeparators, boolean CollectSeparators, boolean UsingLogicAnd){
  boolean ret=false;
  String[] SubWords=null;
  int temp, length;
  boolean found;
  
  if(!DoBrokeWords){SubWords=PCore.refArr(SubString);}
  else{SubWords=breakWords(SubString, BySeparators, CaseSensitive, CollectSeparators, true);}
  
  length=SubWords.length;
  if(length!=0){
   temp=0;
   do{
    found=findSubString(Word, SubWords[temp], CaseSensitive)!=-1;

    if(UsingLogicAnd){
     if(!found){break;}
    }
    else{
     if(found){break;}
    }

    temp=temp+1;
   }while(temp!=length);

   if(UsingLogicAnd){
    if(temp==length){ret=true;}
   }
   else{
    if(temp!=length){ret=true;}
   }
  }
  
  return ret;
 }
 public static String findAndReplace(boolean CaseSensitive, String Word, String StrFind, String StrReplace){
  StringBuilder ret=null;
  int word_length, word_start, find_length, temp;
  char word_ch;
  int ch1, ch2;
  
  if(Word==null || StrFind==null || StrReplace==null){return Word;}
  word_length=Word.length();
  find_length=StrFind.length();
  if(word_length==0 || find_length==0 || find_length>word_length){return Word;}
  
  ret=new StringBuilder();
  word_start=0;
  do{
   if(find_length>word_length-word_start){
    ret.append(subString(Word, word_start, word_length-1));
    break;
   }
   
   temp=0;
   do{
    word_ch=Word.charAt(word_start+temp);
    ch1=word_ch; ch2=StrFind.charAt(temp);
    if(!CaseSensitive){if(ch1>=97 && ch1<=122){ch1=ch1-32;} if(ch2>=97 && ch2<=122){ch2=ch2-32;}}
    if(ch1!=ch2){break;}
    temp=temp+1;
   }while(temp!=find_length);
   
   if(temp==find_length){ret.append(StrReplace);}
   else{ret.append(Word.charAt(word_start)); temp=1;}
   
   word_start=word_start+temp;
  }while(word_start!=word_length);
  
  return ret.toString();
 }
 public static boolean compare(String W1, int w1pos, String W2, boolean CaseSensitive){
  boolean ret=true;
  boolean exit;
  int pos, length, a, a_;
  if(W1!=null && W2!=null){
   length=W2.length();
   if(length>0){
    if(w1pos>=0 && w1pos+length-1<W1.length()){
     pos=0;
     exit=false;
     do{
      a=(int)W1.charAt(w1pos+pos); if(!CaseSensitive){if(a>=97 && a<=122){a=a-32;}}
      a_=(int)W2.charAt(pos); if(!CaseSensitive){if(a_>=97 && a_<=122){a_=a_-32;}}
      if(a==a_){
       pos=pos+1;
       if(pos>length-1){exit=true;}
      }
      else{
       ret=false;
       exit=true;
      }
     }while(exit==false);
    }
    else{ret=false;}
   }
  }
  else{
   if(W1!=null || W2!=null){ret=false;}
  }
  return ret;
 }
 public static boolean compare(char C1, char C2, boolean CaseSensitive){
  int a, b;
  
  a=(int)C1;
  if(!CaseSensitive){
   if(a>=97 && a<=122){a=a-32;}
  }
  b=(int)C2;
  if(!CaseSensitive){
   if(b>=97 && b<=122){b=b-32;}
  }
  
  return a==b;
 }
 public static boolean compare(String W1, String W2, boolean CaseSensitive){
  boolean ret=false;
  boolean exit;
  int pos, length;
  int ch1, ch2;
  if(W1!=null && W2!=null){
   length=W2.length();
   if(length==W1.length()){
    if(length!=0){
     pos=0;
     exit=false;
     do{
      ch1=W1.charAt(pos); if(!CaseSensitive){if(ch1>=97 && ch1<=122){ch1=ch1-32;}}
      ch2=W2.charAt(pos); if(!CaseSensitive){if(ch2>=97 && ch2<=122){ch2=ch2-32;}}
      if(ch1==ch2){
       pos=pos+1;
       if(pos==length){
        ret=true;
        exit=true;
       }
      }
      else{exit=true;}
     }while(exit==false);
    }
    else{ret=true;}
   }
  }
  else{
   if(W1==null && W2==null){ret=true;}
  }
  return ret;
 }
 public static int grading(String W1, String W2, boolean CaseSensitive){
  int ret=0; // 0 equal, 1 W1 < W2, 2 W2 < W1
  int c1, c2;
  int w1length, w2length;
  int temp, temp2;
  
  // validating parameters
  w1length=0; if(W1!=null){w1length=W1.length();}
  w2length=0; if(W2!=null){w2length=W2.length();}
  if(w1length==0 || w2length==0){
   if(w1length!=w2length){
    if(w1length<w2length){ret=1;}
    else{ret=2;}
   }
   return ret;
  }
  
  // grading (on this step, w1length & w2length must > 0)
   // define the shortest length of w1 & w2
  temp2=w1length;
  if(temp2>w2length){temp2=w2length;}
   // checking grade between w1 & w2
  temp=0;
  do{
   c1=W1.charAt(temp); if(!CaseSensitive){if(c1>=97 && c1<=122){c1=c1-32;}}
   c2=W2.charAt(temp); if(!CaseSensitive){if(c2>=97 && c2<=122){c2=c2-32;}}
   if(c1!=c2){
    if(c1<c2){ret=1;}
    else{ret=2;}
    break;
   }
   temp=temp+1;
  }while(temp!=temp2);
   // if still equal && w1length!=w2length, then compare w1length to w2length
  if(ret==0){
   if(w1length!=w2length){
    if(w1length<w2length){ret=1;}
    else{ret=2;}
   }
  }
  
  return ret;
 }
 
 public static int findElement(Vector<String> Words, String FindWord, boolean CaseSensitive){
  int ret=-1;
  int temp, length;
  
  if(Words==null){return ret;}
  
  length=Words.size();
  if(length==0){return ret;}
  
  temp=0;
  do{
   if(compare(Words.elementAt(temp), FindWord, CaseSensitive)){ret=temp; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static int findElement(char[] Chars, char ch){
  return findElementCharacter(Chars, ch);
 }
 public static int findElementCharacter(char[] Chars, Character ch){
  int ret=-1;
  int temp, length;
  
  if(Chars==null || ch==null){return ret;}
  length=Chars.length;
  if(length==0){return ret;}
  
  temp=0;
  do{
   if(ch==Chars[temp]){ret=temp; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 public static int findElement(Vector<Character> Chars, char ch){
  return findElementCharacter(Chars, ch);
 }
 public static int findElementCharacter(Vector<Character> Chars, Character ch){
  int ret=-1;
  int temp, length;
  
  if(Chars==null || ch==null){return ret;}
  length=Chars.size();
  if(length==0){return ret;}
  
  temp=0;
  do{
   if(ch==Chars.elementAt(temp)){ret=temp; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }

 public static boolean isWhiteSpace(char ch){return findElement(CCore.Chars_WhiteSpace, ch)!=-1;}
 public static boolean isLineBreak(char ch){return findElement(CCore.Chars_LineBreak, ch)!=-1;}
 public static boolean isWhiteChar(char ch){return findElement(CCore.Chars_WhiteChar, ch)!=-1;}
 
 public static boolean isAllWhiteChar(String Word){
  boolean ret=true;
  int temp, length;
  
  if(Word==null){return ret;}
  
  length=Word.length();
  if(length==0){return ret;}
  
  temp=0;
  do{
   if(!isWhiteChar(Word.charAt(temp))){ret=false; break;}
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static boolean isEmptyString(String Word, boolean CheckWhiteSpace, boolean ReturnIfNull){
  boolean ret=true;
  
  if(Word==null){return ReturnIfNull;}
  
  do{
   if(Word.length()==0){break;}
   if(CheckWhiteSpace){if(isAllWhiteChar(Word)){break;}}
   ret=false;
  }while(false);
  
  return ret;
 }
 
 //
 public static Character getCharAt(String Word, int WordIndex){
  Character ret=null;
  int length;
  
  if(Word==null){return ret;}
  length=Word.length();
  if(WordIndex>=length){return ret;}
  
  ret=Word.charAt(WordIndex);
  
  return ret;
 }
 
 // char array operation
 private static boolean copyChars(char[] Chars, char[] Dest, int DestOffset){
  boolean ret=false;
  int clength, c, o;
  if(Chars!=null && Dest!=null && DestOffset>=0){
   clength=Chars.length;
   if(clength!=0 && DestOffset+clength<=Dest.length){
    c=0;
    o=DestOffset;
    do{
     Dest[o]=Chars[c];
     c=c+1;
     o=o+1;
    }while(c!=clength);
    ret=true;
   }
  }
  return ret;
 }
 public static char[] createChars(int Length, char InitialChar){
  char[] ret=null;
  int temp;
  if(Length==0){return ret;}
  ret=new char[Length];
  temp=0;
  do{
   ret[temp]=InitialChar;
   temp=temp+1;
  }while(temp!=Length);
  return ret;
 }
 public static void refillChars(char[] Chars, char RefillChar){
  int temp, length;
  length=Chars.length;
  temp=0;
  do{
   Chars[temp]=RefillChar;
   temp=temp+1;
  }while(temp!=length);
 }
 public static void fillStringToChars(char[] Chars, String FillString, int CharsStartOffset, int AlignMode){
  // Align Mode = 1 left, 2 center, 3 right
  // note : if align mode is 'center', the CharsStartOffset is always positioned at left side
  //        example 'ABCDEFGHIJ'  (10 char (even), CharsStartOffset=5 ('E'))
  //                'ABCDEFGHIJK' (11 char (odd), CharsStartOffset=5 ('E'))
  int FillCount, temp, FillStartOffset, StringStartOffset;
  
  if(FillString==null){return;}
  if(FillString.length()==0){return;}
  
  FillStartOffset=CharsStartOffset;
  if(AlignMode==2){
   FillStartOffset=CharsStartOffset-(int)(FillString.length()/2)+1;
  }
  else if(AlignMode==3){
   FillStartOffset=CharsStartOffset-FillString.length()+1;
  }
  if(FillStartOffset<Chars.length && FillStartOffset+FillString.length()>0){
   StringStartOffset=0;
   if(FillStartOffset<0){
    StringStartOffset=0-FillStartOffset;
    FillStartOffset=0;
   }
   FillCount=FillString.length()-StringStartOffset;
   if(FillCount>Chars.length-FillStartOffset){
    FillCount=Chars.length-FillStartOffset;
   }
   temp=0;
   do{
    Chars[FillStartOffset+temp]=FillString.charAt(StringStartOffset+temp);
    temp=temp+1;
   }while(temp!=FillCount);
  }
 }

 // string basic operation
 public static char upperCase(char C){
  int ret=(int)C;
  if(ret>=97 && ret<=122){ret=ret-32;}
  return (char)ret;
 }
 public static char lowerCase(char C){
  int ret=(int)C;
  if(ret>=65 && ret<=90){ret=ret+32;}
  return (char)ret;
 }

 public static String subString(String W, int pos1, int pos2){
  String ret=null;
  int pos_;
  char W_[];
  if(W!=null){
   if(W.length()!=0 && pos1>=0 &&
      pos2>=pos1 && pos2<=W.length()-1){
    W_=new char[pos2-pos1+1];
    pos_=pos1;
    do{
     W_[pos_-pos1]=W.charAt(pos_);
     pos_=pos_+1;
    }while(pos_<=pos2);
    ret=new String(W_);
   }
  }
  return ret;
 }
 public static String fitString(String Word, int FitCount,
  boolean FixedLeftSide, int FixedSideCount,
  int DotCount, char DotChar){
  /*
   example:
   
   before fit operation
   "hello there? could somebody please open the door?" <- (word length = 49 characters)
   
   after fit operation
   "hello there...e open the door?" <- (FitCount = 30, FixedLeftSide=true, FixedSideCount = 11, and DotCount = 3)
    11 left       16 right
   "hello there? coul..n the door?" <- (FitCount = 30, FixedLeftSide=false, FixedSideCount = 11, and DotCount = 2)
    17 left            11 right
  */
  String ret=null;
  char[] retTemp;
  int temp1, temp2;
  if(Word!=null && FixedSideCount>=1 && DotCount>=1 && FitCount>=FixedSideCount+DotCount){
   if(Word.length()>FitCount){
    retTemp=new char[FitCount];
    temp2=0;
    // fill left side
    if(FixedLeftSide){temp1=FixedSideCount;}
    else{temp1=FitCount-(FixedSideCount+DotCount);}
    if(temp1!=0){
     do{
      retTemp[temp2]=Word.charAt(temp2);
      temp2=temp2+1;
     }while(temp2!=temp1);
    }
    // fill dot
    temp1=temp2+DotCount;
    do{
     retTemp[temp2]=DotChar;
     temp2=temp2+1;
    }while(temp2!=temp1);
    // fill right side
    if(temp2!=FitCount){
     temp1=Word.length()-(FitCount-temp2);
     do{
      retTemp[temp2]=Word.charAt(temp1);
      temp1=temp1+1;
      temp2=temp2+1;
     }while(temp2!=FitCount);
    }
    ret=new String(retTemp);
   }
   else{ret=Word;}
  }
  return ret;
 }

 // conversion
 public static String intToString(long Number, char NumericSeparatorThousand){
  char[] ret=new char[26]; // 26 = 19 digit number + 6 thousands separator + 1 minus sign
  long left, mod;
  int temp, triple;
  long NumberPositive=PCore.subtBool_Long(Number>=0, Number, -1*Number);
  left=NumberPositive;
  temp=ret.length;
  triple=0;
  do{
   mod=left%10;
   triple=triple+1;
   if(triple==4){
    temp=temp-1;
    ret[temp]=NumericSeparatorThousand;
    triple=1;
   }
   temp=temp-1;
   ret[temp]=(char)(mod+48);
   left=left/10;
  }while(left!=0);
  if(Number<0){
   temp=temp-1;
   ret[temp]='-';
  }
  return new String(ret, temp, ret.length-temp);
 }
 public static String intToString(long Number){return intToString(Number, CCore.NumericSeparatorThousand);}
 public static String priceToString(double Number, int MaxChar, char NumericSeparatorThousand, char NumericSeparatorFraction){
  OPreciseDecimal ret=new OPreciseDecimal(Number, CCore.Display_Normal_FractionDigit, CCore.RoundDigit, NumericSeparatorThousand, NumericSeparatorFraction);
  return ret.getString(false, true, MaxChar, false);
 }
 public static String priceToString(double Number){return priceToString(Number, CCore.getDisplayDigitMaxChars(0), CCore.NumericSeparatorThousand, CCore.NumericSeparatorFraction);}
 public static String priceToString(double Number, char NumericSeparatorThousand, char NumericSeparatorFraction){return priceToString(Number, CCore.getDisplayDigitMaxChars(0), NumericSeparatorThousand, NumericSeparatorFraction);}
 public static String priceToString(double Number, int MaxChar){return priceToString(Number, MaxChar, CCore.NumericSeparatorThousand, CCore.NumericSeparatorFraction);}
 public static String signedPriceToString(double Number,
  boolean ShowPositiveSign, String PositiveSign, boolean ShowNegativeSign, String NegativeSign,
  boolean UseFixedSign, boolean FixedSignIsPositive,
  char NumericSeparatorThousand, char NumericSeparatorFraction){
  StringBuilder ret=new StringBuilder();
  boolean IsPositive=Number>=0;
  double PositiveNumber=PCore.subtBool_Double(Number>=0, Number, -1*Number);
  boolean AddSign;
  String Sign=null;
  
  // define AddSign
  AddSign=false;
  do{
   if(!UseFixedSign){
    if(IsPositive && !ShowPositiveSign){break;}
    if(!IsPositive && !ShowNegativeSign){break;}
   }
   AddSign=true;
  }while(false);
  
  // define Sign
  if(AddSign){
   if(!UseFixedSign){Sign=PText.getString(IsPositive, PositiveSign, NegativeSign);}
   else{Sign=PText.getString(FixedSignIsPositive, PositiveSign, NegativeSign);}
  }
  
  // build String
  if(AddSign){ret.append(Sign);}
  ret.append(priceToString(PositiveNumber, NumericSeparatorThousand, NumericSeparatorFraction));
  
  return ret.toString();
 }
 public static String signedPriceToString(double Number,
  boolean ShowPositiveSign, String PositiveSign, boolean ShowNegativeSign, String NegativeSign,
  boolean UseFixedSign, boolean FixedSignIsPositive){
  return signedPriceToString(Number,
   ShowPositiveSign, PositiveSign, ShowNegativeSign, NegativeSign,
   UseFixedSign, FixedSignIsPositive,
   CCore.NumericSeparatorThousand, CCore.NumericSeparatorFraction);
 }
 public static String doubleToString(double Number, boolean IsDisplay, char NumericSeparatorFraction){
  int FractionDigit=PCore.subtBool_Int(IsDisplay, CCore.Display_Normal_FractionDigit, CCore.FractionDigit);
  OPreciseDecimal ret=new OPreciseDecimal(Number, FractionDigit, CCore.RoundDigit, '~', NumericSeparatorFraction);
  return ret.getString(false, false, Integer.MAX_VALUE, false);
 }
 public static String doubleToString(double Number, boolean IsDisplay){return doubleToString(Number, IsDisplay, CCore.NumericSeparatorFraction);}
 public static int getCharsCountOfNumber(long Number, boolean WithThousandSeparator, boolean IncludeNegativeSign){
  int ret=0;
  long positive_number=PCore.subtBool_Long(Number>=0, Number, -1*Number);
  long temp=positive_number;
  boolean bool=true;
  int number_length;
  
  number_length=1;
  do{
   temp=temp/10;
   
   if(temp==0){break;}
   
   number_length=number_length+1;
  }while(bool);
  ret=ret+number_length;
  
  if(WithThousandSeparator){ret=ret+((number_length-1)/3);}
  
  if(IncludeNegativeSign && Number<0){ret=ret+1;}
  
  return ret;
 }
 public static int getCharsCountOfDigit(int NumberDigit, int FractionDigit, boolean WithThousandSeparator, boolean IncludeNegativeSign){
  int ret=0;
  
  if(NumberDigit<=0){return ret;}
  
  if(IncludeNegativeSign){ret=ret+1;}
  ret=ret+NumberDigit; if(WithThousandSeparator){ret=ret+((NumberDigit-1)/3);}
  if(FractionDigit>0){ret=ret+1+FractionDigit;}
  
  return ret;
 }
 public static String dateToString(Date Dt, int Mode){
  String ret=null;
  if(Dt==null){return "";}
  Cal.setNewTime(Dt);
  switch(Mode){
   case 1 : // 2016-1-13, yyyy-d-m
    ret=String.valueOf(Cal.get(Calendar.YEAR))+"-"+String.valueOf(Cal.get(Calendar.MONTH)+1)+
     "-"+String.valueOf(Cal.get(Calendar.DAY_OF_MONTH));
    break;
   case 2 : // 13-Jan-2016, dd-mmm-yyyy
    ret=paddingNumber(Cal.get(Calendar.DAY_OF_MONTH), 2)+"-"+CTime.Month[Cal.get(Calendar.MONTH)]+
     "-"+String.valueOf(Cal.get(Calendar.YEAR));
    break;
   case 3 : // 2016-Jan-13, yyyy-mmm-dd
    ret=String.valueOf(Cal.get(Calendar.YEAR))+"-"+CTime.Month[Cal.get(Calendar.MONTH)]+
     "-"+paddingNumber(Cal.get(Calendar.DAY_OF_MONTH), 2);
    break;
   case 4 : // 13-Jan-2016, 13:00:00, dd-mmm-yyyy, hh-mm-ss
    ret=paddingNumber(Cal.get(Calendar.DAY_OF_MONTH), 2)+"-"+CTime.Month[Cal.get(Calendar.MONTH)]+
     "-"+String.valueOf(Cal.get(Calendar.YEAR)+", "+paddingNumber(Cal.get(Calendar.HOUR_OF_DAY), 2)+":"+
     paddingNumber(Cal.get(Calendar.MINUTE), 2)+":"+paddingNumber(Cal.get(Calendar.SECOND), 2));
    break;
   case 6 : // timeinmillis
    ret=String.valueOf(Dt.getTime());
    break;
   case 101 : // 2016Jan13_135959
    ret=String.valueOf(Cal.get(Calendar.YEAR))+CTime.Month[Cal.get(Calendar.MONTH)]+paddingNumber(Cal.get(Calendar.DAY_OF_MONTH), 2)+"_"+
     paddingNumber(Cal.get(Calendar.HOUR_OF_DAY), 2)+paddingNumber(Cal.get(Calendar.MINUTE), 2)+paddingNumber(Cal.get(Calendar.SECOND), 2);
    break;
   default : ret=String.valueOf(Dt.getTime()); break;
  }
  return ret;
 }

 public static Integer parseInt(String Str, Integer ReturnIfNullOrEmpty, Integer ReturnIfError){
  return parseInt(Str, ReturnIfNullOrEmpty, ReturnIfError, true, false, false, 0, 0);
 }
 public static Long parseLong(String Str, Long ReturnIfNullOrEmpty, Long ReturnIfError){
  return parseLong(Str, ReturnIfNullOrEmpty, ReturnIfError, true, false, false, 0, 0);
 }
 public static Double parseDouble(String Str, Double ReturnIfNullOrEmpty, Double ReturnIfError){
  return parseDouble(Str, ReturnIfNullOrEmpty, ReturnIfError, true, false, false, 0, 0);
 }
 public static Integer parseInt(String Str, Integer ReturnIfNullOrEmpty, Integer ReturnIfError,
  boolean AcceptZero, boolean PositiveOnly,
  boolean WithinRange, int Range1, int Range2){
  Integer ret=ReturnIfNullOrEmpty;
  int value;
  
  if(Str==null){return ret;}
  if(Str.length()==0){return ret;}
  
  ret=ReturnIfError;
  do{
   try{value=Integer.parseInt(Str);}catch(Exception E){break;}
   if(value<0 && PositiveOnly){break;}
   if(value==0 && !AcceptZero){break;}
   if(WithinRange && !PCore.betweenRangeInt(value, Range1, Range2)){break;}
   ret=value;
  }while(false);
  
  return ret;
 }
 public static Long parseLong(String Str, Long ReturnIfNullOrEmpty, Long ReturnIfError,
  boolean AcceptZero, boolean PositiveOnly,
  boolean WithinRange, long Range1, long Range2){
  Long ret=ReturnIfNullOrEmpty;
  long value;
  
  if(Str==null){return ret;}
  if(Str.length()==0){return ret;}
  
  ret=ReturnIfError;
  do{
   try{value=Long.parseLong(Str);}catch(Exception E){break;}
   if(value<0 && PositiveOnly){break;}
   if(value==0 && !AcceptZero){break;}
   if(WithinRange && !PCore.betweenRangeLong(value, Range1, Range2)){break;}
   ret=value;
  }while(false);
  
  return ret;
 }
 public static Double parseDouble(String Str, Double ReturnIfNullOrEmpty, Double ReturnIfError,
  boolean AcceptZero, boolean PositiveOnly,
  boolean WithinRange, double Range1, double Range2){
  Double ret=ReturnIfNullOrEmpty;
  double value;
  
  if(Str==null){return ret;}
  if(Str.length()==0){return ret;}
  
  ret=ReturnIfError;
  do{
   try{value=Double.parseDouble(Str);}catch(Exception E){break;}
   if(value<0 && PositiveOnly){break;}
   if(value==0 && !AcceptZero){break;}
   if(WithinRange && !PCore.betweenRangeDouble(value, Range1, Range2)){break;}
   ret=value;
  }while(false);
  
  return ret;
 }
 public static int stringToInt(String Number, int pos1, int pos2){
  int ret=0;
  int y, temp, temp_;
  y=1;
  temp_=pos2;
  temp=pos1-1;
  do{
   switch(Number.charAt(temp_)){
    case '0' : break;
    case '1' : ret=ret+(y*1); break;
    case '2' : ret=ret+(y*2); break;
    case '3' : ret=ret+(y*3); break;
    case '4' : ret=ret+(y*4); break;
    case '5' : ret=ret+(y*5); break;
    case '6' : ret=ret+(y*6); break;
    case '7' : ret=ret+(y*7); break;
    case '8' : ret=ret+(y*8); break;
    case '9' : ret=ret+(y*9); break;
   }
   y=y*10;
   temp_=temp_-1;
  }while(temp_!=temp);
  return ret;
 }
 public static int dateInNumber(OGregorianCalendar Cal_){
  return (Cal_.get(Calendar.YEAR)*10000)+((Cal_.get(Calendar.MONTH)+1)*100)+Cal_.get(Calendar.DAY_OF_MONTH);
 }
 public static int dateInNumber(Date Dt){
  Cal.setNewTime(Dt);
  return (Cal.get(Calendar.YEAR)*10000)+((Cal.get(Calendar.MONTH)+1)*100)+Cal.get(Calendar.DAY_OF_MONTH);
 }
 public static String[] parseNumbersToString(String Str){
  Vector<String> ret=new Vector();
  int temp, length, num_start;
  int ch;
  
  length=Str.length();
  temp=-1;
  do{
   // find first char of number
   temp=temp+1; if(temp==length){break;}
   do{
    ch=Str.charAt(temp);
    if(ch>=(int)'0' && ch<=(int)'9'){break;}
    temp=temp+1;
   }while(temp!=length);
   if(temp==length){break;}

   // if found, then build a string
   num_start=temp;
   temp=temp+1;
   if(temp!=length){
    do{
     ch=Str.charAt(temp);
     if(!(ch>=(int)'0' && ch<=(int)'9')){break;}
     temp=temp+1;
    }while(temp!=length);
   }
   ret.addElement(subString(Str, num_start, temp-1));
  }while(temp!=length);
  
  return PCore.refArr_VectStr(ret);
 }
 public static long[] parseNumbersToLong(String Str){
  long[] ret;
  int temp, length;
  String[] parse;
  
  parse=parseNumbersToString(Str);
  length=parse.length;
  ret=new long[length];
  if(length!=0){
   temp=0;
   do{
    try{ret[temp]=Long.parseLong(parse[temp]);}catch(Exception E){break;}
    temp=temp+1;
   }while(temp!=length);
   if(temp!=length){return null;}
  }
  
  return ret;
 }
 public static String[] breakWords(String Word, char[] BySeparators, boolean CollectWords_CaseSensitive, boolean CollectSeparators,
  boolean IfCollectWordsIsEmpty_AddCollectSeparators){
  String[] ret=null;
  Vector<String> words_found=new Vector();
  Vector<Character> separators_found=new Vector();
  StringBuilder CurrWord=null;
  int temp, word_length;
  char curr_char, bef_char;
  boolean curr_isseparator, bef_isseparator;
  String str;
  
  do{
   
   word_length=0; if(Word!=null){word_length=Word.length();}
   if(word_length==0){break;}
   
   CurrWord=new StringBuilder();
   bef_char=' ';
   bef_isseparator=true;
   
   temp=0;
   do{
    curr_char=Word.charAt(temp);
    curr_isseparator=findElement(BySeparators, curr_char)!=-1;
    
    if(!curr_isseparator){
     CurrWord.append(curr_char);
    }
    else{
     if(!bef_isseparator){
      str=CurrWord.toString();
      if(findElement(words_found, str, CollectWords_CaseSensitive)==-1){words_found.addElement(str);}
      
      CurrWord=new StringBuilder();
     }
     
     if(findElement(separators_found, curr_char)==-1){separators_found.addElement(curr_char);}
    }
    
    bef_char=curr_char;
    bef_isseparator=curr_isseparator;
    temp=temp+1;
   }while(temp!=word_length);
   
   if(CurrWord.length()!=0){
    str=CurrWord.toString();
    if(findElement(words_found, str, CollectWords_CaseSensitive)==-1){words_found.addElement(str);}
   }
  
  }while(false);
  
  ret=PCore.refArr_VectStr(words_found);
  if(CollectSeparators || (IfCollectWordsIsEmpty_AddCollectSeparators && words_found.size()==0)){
   ret=PCore.concat(false, ret, PCore.refArr_VectCharToStr(separators_found));
  }
  
  return ret;
 }

 // single & multi line
 public static String singleLine(String Word, char LineBreakReplaceChar){
  String ret=Word;
  char[] chars=null;
  boolean HasLineBreak=false;
  int temp, length;
  char ch;
  
  if(Word==null){return "";}
  
  length=Word.length();
  if(length!=0){
   chars=new char[length];
   temp=0;
   do{
    ch=Word.charAt(temp);
    if(ch!='\n'){chars[temp]=ch;}
    else{
     chars[temp]=LineBreakReplaceChar;
     HasLineBreak=true;
    }
    temp=temp+1;
   }while(temp!=length);
  }
  
  if(HasLineBreak){ret=new String(chars);}
  return ret;
 }
 public static Vector<String> multiLine(String Words, int MaxColumn){return multiLine(Words, MaxColumn, false, true, 1);}
 public static Vector<String> multiLine(String Words, int MaxColumn, boolean KeepLineBreak, boolean TrimLineBreak, int TrimLineBreakThreshold){
  // MaxColumn >= 2
  Vector<String> ret=new Vector();
  char[] CurrLine;
  int temp, temp2, wlength, XWord, XWord2,
      XCurrLine, AddLength,
      LineBreakCount;
  char ch;
  boolean CurrPosHasLineBreak;
  
  CurrLine=new char[MaxColumn]; XCurrLine=0;
  wlength=0; if(Words!=null){wlength=Words.length();}
  if(wlength!=0){
   // parse a word by a word
   XWord=-1; CurrPosHasLineBreak=false;
   do{
    LineBreakCount=0; if(CurrPosHasLineBreak){LineBreakCount=LineBreakCount+1;}
    XWord=XWord+1;
    
    // find next initial char of word
    if(XWord!=wlength){
     do{
      ch=Words.charAt(XWord);
      if(ch!=' ' && ch!='\n'){break;}
      if(ch=='\n'){LineBreakCount=LineBreakCount+1;}
      XWord=XWord+1;
     }while(XWord!=wlength);
    }
    
    // parse a word until find white char
    XWord2=XWord;
    if(XWord2!=wlength){
     XWord2=XWord2+1;
     if(XWord2!=wlength){
      do{
       ch=Words.charAt(XWord2);
       if(ch==' ' || ch=='\n'){
        CurrPosHasLineBreak=ch=='\n';
        break;
       }
       XWord2=XWord2+1;
      }while(XWord2!=wlength);
     }
    }
    
    // do something with the parsed characters
    AddLength=XWord2-XWord;
    
     // do something with the parsed line-break
    if(LineBreakCount!=0 && KeepLineBreak && AddLength!=0){
     temp2=LineBreakCount; if(TrimLineBreak && temp2>TrimLineBreakThreshold){temp2=TrimLineBreakThreshold;}
     temp=0;
     do{
      ret.add(new String(CurrLine, 0, XCurrLine)); XCurrLine=0;
      temp=temp+1;
     }while(temp!=temp2);
    }
    
     // do something with the parsed word
    if(AddLength!=0){
     // add space / new line
     if(XCurrLine!=0){
      if(LineBreakCount!=0 && !KeepLineBreak){AddLength=AddLength+1;}
      if(XCurrLine+1+AddLength<=MaxColumn){
       CurrLine[XCurrLine]=' '; XCurrLine=XCurrLine+1;
      }
      else{
       ret.add(new String(CurrLine, 0, XCurrLine)); XCurrLine=0;
      }
     }
     
     // add word
     if(LineBreakCount!=0 && !KeepLineBreak){
      CurrLine[XCurrLine]='~'; XCurrLine=XCurrLine+1;
     }
     do{
      CurrLine[XCurrLine]=Words.charAt(XWord);
      XCurrLine=XCurrLine+1; XWord=XWord+1;
      if(XCurrLine==MaxColumn){
       if(XWord!=XWord2){ret.add(new String(CurrLine, 0, XCurrLine)); XCurrLine=0;}
      }
     }while(XWord!=XWord2);
    }
   }while(XWord!=wlength);
  }
  ret.add(new String(CurrLine, 0, XCurrLine));
  
  return ret;
 }
 public static Vector<String> fitMultiLine(Vector<String> Words,
  int FitCount, boolean FixedTopSide, int FixedSideCount,
  int ConcatenateFitCount, boolean ConcatenateFixedLeftSide, int ConcatenateFixedSideCount,
  int ConcatenateDotCount, char ConcatenateDotChar){
  Vector<String> ret;
  String[] str;
  int linecount, temp, temp2, retpos, left;
  
  linecount=Words.size();
  if(linecount<=FitCount){return Words;}
  
  str=new String[FitCount];
  left=FitCount;
  do{
   
   // add fixed side
   if(FixedTopSide){
    temp2=0;
    retpos=0;
   }
   else{
    temp2=linecount-FixedSideCount;
    retpos=FitCount-FixedSideCount;
   }
   temp=0;
   do{
    str[retpos+temp]=Words.elementAt(temp2+temp);
    temp=temp+1;
   }while(temp!=FixedSideCount);
   
   left=left-FixedSideCount;
   if(left==0){break;}
   
   // add concatenate
   if(FixedTopSide){
    retpos=FixedSideCount;
    temp=FixedSideCount;
    temp2=linecount-left;
   }
   else{
    retpos=FitCount-FixedSideCount-1;
    temp=left-1;
    temp2=linecount-FixedSideCount-1;
   }
   str[retpos]=fitString(Words.elementAt(temp)+" "+Words.elementAt(temp2), ConcatenateFitCount,
    ConcatenateFixedLeftSide, ConcatenateFixedSideCount, ConcatenateDotCount, ConcatenateDotChar);
   
   left=left-1;
   if(left==0){break;}
   
   // add non-fixed side
   if(FixedTopSide){
    temp2=linecount-left;
    retpos=FitCount-left;
   }
   else{
    temp2=0;
    retpos=0;
   }
   temp=0;
   do{
    str[retpos+temp]=Words.elementAt(temp2+temp);
    temp=temp+1;
   }while(temp!=left);
   
  }while(false);
  
  ret=new Vector();
  temp=0;
  do{
   ret.addElement(str[temp]);
   temp=temp+1;
  }while(temp!=FitCount);
  
  return ret;
 }
 public static int getMinMaxChars(boolean IsMinimal, Vector<String> Words){
  int ret=0;
  int temp, length, charcount;
  String Word;
  boolean first;
  
  if(Words==null){return ret;}
  length=Words.size();
  if(length==0){return ret;}
  
  temp=0; first=true;
  do{
   Word=Words.elementAt(temp);
   
   charcount=0; if(Word!=null){charcount=Word.length();}
   if(first){ret=charcount; first=false;}
   else{
    if(IsMinimal){
     if(ret>charcount){ret=charcount;}
    }
    else{
     if(ret<charcount){ret=charcount;}
    }
   }
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }

 // string manipulation
 public static String getRepeatedChars(char AChar, int Count){
  char[] ret=new char[Count];
  int temp;
  if(Count!=0){
   temp=0;
   do{
    ret[temp]=AChar;
    temp=temp+1;
   }while(temp!=Count);
  }
  return new String(ret);
 }
 public static String paddingNumber(long Number, int Count){
  String ret=null;
  String Num=String.valueOf(Number);
  int NumLength=Num.length();
  int temp=Count-NumLength;
  int temp_;
  char[] PadNum;
  if(temp>0){
   PadNum=new char[Count];
   // fill front characters with 0
   temp_=0;
   do{
    PadNum[temp_]='0';
    temp_=temp_+1;
   }while(temp_!=temp);
   // fill Num
   temp=0;
   do{
    PadNum[temp_+temp]=Num.charAt(temp);
    temp=temp+1;
   }while(temp!=NumLength);
   ret=new String(PadNum);
  }
  else{ret=Num;}
  return ret;
 }
 public static String separate(String Word, String Separator, int SeparateEveryNChar){
  StringBuilder ret=null;
  int length, temp, sublength;
  
  if(Word==null){return Word;}
  length=Word.length();
  if(length==0 || length<=SeparateEveryNChar){return Word;}
  
  ret=new StringBuilder();
  temp=0;
  do{
   if(temp!=0){ret.append(Separator);}
   
   sublength=SeparateEveryNChar;
   if(temp+sublength>length){sublength=length-temp;}
   ret.append(subString(Word, temp, temp+sublength-1));
   
   temp=temp+sublength;
  }while(temp!=length);
  
  return ret.toString();
 }
 public static String separate(String Word, String Separator, int[] SeparateLength){
  StringBuilder ret=null;
  int word_length, word_pos, word_sublength, sep_pos;
  
  if(Word==null){return Word;}
  word_length=Word.length();
  if(word_length==0 || word_length<=SeparateLength[0]){return Word;}
  
  ret=new StringBuilder();
  word_pos=0;
  
  sep_pos=0;
  do{
   if(word_pos!=0){ret.append(Separator);}
   
   word_sublength=SeparateLength[sep_pos];
   if(word_pos+word_sublength>word_length){word_sublength=word_length-word_pos;}
   ret.append(subString(Word, word_pos, word_pos+word_sublength-1));
   word_pos=word_pos+word_sublength;
   if(word_pos==word_length){break;}
   
   sep_pos=sep_pos+1;
  }while(sep_pos!=SeparateLength.length);
  
  if(word_pos!=word_length){
   ret.append(Separator);
   ret.append(subString(Word, word_pos, word_length-1));
  }
  
  return ret.toString();
 }
 public static String quote(String Word, String ReplaceNull, char Quote, boolean ActEmptyStringAsNull){
  String Text;
  boolean ReplaceWithNull;
  
  Text=Word; ReplaceWithNull=true;
  do{
   if(Text==null){break;}
   if(Text.length()==0 && ActEmptyStringAsNull){break;}
   ReplaceWithNull=false;
  }while(false);
  if(ReplaceWithNull){Text=ReplaceNull;}
  
  return Quote+Text+Quote;
 }

 // get string
	public static String getString(ResultSet Rs, int ColumnIndex, int ColumnType, String ReturnIfNull,
		boolean NumberWithSeparator) throws Exception{
		String ret=ReturnIfNull;
		OAnObject Obj=null;
		
		switch(ColumnType){
			case CCore.TypeString : Obj=new OAnObject(Rs.getString(ColumnIndex+1)); break;
			case CCore.TypeInteger : Obj=new OAnObject(Rs.getInt(ColumnIndex+1), NumberWithSeparator); break;
			case CCore.TypeLong : Obj=new OAnObject(Rs.getLong(ColumnIndex+1), NumberWithSeparator); break;
			case CCore.TypeDouble : Obj=new OAnObject(Rs.getDouble(ColumnIndex+1), NumberWithSeparator); break;
			case CCore.TypeBoolean : Obj=new OAnObject(Rs.getBoolean(ColumnIndex+1)); break;
			case CCore.TypeDate : Obj=new OAnObject(Rs.getDate(ColumnIndex+1)); break;
		}
		
		if(!Rs.wasNull()){ret=Obj.toString();}
		
		return ret;
	}
 public static String getString(String obj, String ReplaceNull, boolean ActEmptyStringAsNull){
  String ret=obj;
  if(ret==null){ret=ReplaceNull;}
  else{
   if(ActEmptyStringAsNull){
    if(ret.length()==0){ret=ReplaceNull;}
   }
  }
  return ret;
 }
 public static String getString(String obj, String ReplaceIfNull, String ReplaceIfNotNull, boolean ActEmptyStringAsNull){
  String ret=ReplaceIfNotNull;
  if(obj==null){ret=ReplaceIfNull;}
  else{
   if(ActEmptyStringAsNull){
    if(obj.length()==0){ret=ReplaceIfNull;}
   }
  }
  return ret;
 }
 public static String getStringObj(Object obj, String ReplaceNull, boolean ActEmptyStringAsNull){
  String ret=ReplaceNull;
  if(obj!=null){
   ret=obj.toString();
   if(ActEmptyStringAsNull){
    if(ret.length()==0){ret=ReplaceNull;}
   }
  }
  return ret;
 }
 public static String getStringObj(Object obj, String ReplaceIfNull, String ReplaceIfNotNull, boolean ActEmptyStringAsNull){
  String ret=ReplaceIfNotNull;
  if(obj==null){ret=ReplaceIfNull;}
  else{
   if(ActEmptyStringAsNull){
    if(obj.toString().length()==0){ret=ReplaceIfNull;}
   }
  }
  return ret;
 }
 public static String getString(long Num, String ReplaceNegative, long NegativeThreshold, boolean ReturnAsFormattedNumber){
  String ret=ReplaceNegative;
  if(Num>NegativeThreshold){
   if(ReturnAsFormattedNumber){ret=intToString(Num);}
   else{ret=String.valueOf(Num);}
  }
  return ret;
 }
 public static String getString(long Num, long NegativeThreshold, String ReplacePositive, String ReplaceNegative){
  if(Num<=NegativeThreshold){return ReplaceNegative;}
  else{return ReplacePositive;}
 }
 public static String getStringDouble2(Double Num, String ReplaceNull, boolean ReturnAsFormattedNumber, boolean UnformattedNumberAsDisplay){
  String ret=ReplaceNull;
  if(Num!=null){
   if(ReturnAsFormattedNumber){ret=priceToString(Num);}
   else{ret=doubleToString(Num, UnformattedNumberAsDisplay);}
  }
  return ret;
 }
 public static String getStringDouble2(Double Num, String ReplaceNull,
  String ReplaceNegative, double NegativeThreshold, boolean ReturnAsFormattedNumber, boolean UnformattedNumberAsDisplay){
  String ret;
  
  do{
   ret=ReplaceNull; if(Num==null){break;}
   ret=ReplaceNegative; if(Num<=NegativeThreshold){break;}
   if(ReturnAsFormattedNumber){ret=priceToString(Num);}
   else{ret=doubleToString(Num, UnformattedNumberAsDisplay);}
  }while(false);
  
  return ret;
 }
 public static String getStringDouble(double Num, String ReplaceNegative, double NegativeThreshold, boolean ReturnAsFormattedNumber,
  boolean UnformattedNumberAsDisplay){
  String ret=ReplaceNegative;
  if(Num>NegativeThreshold){
   if(ReturnAsFormattedNumber){ret=priceToString(Num);}
   else{ret=doubleToString(Num, UnformattedNumberAsDisplay);}
  }
  return ret;
 }
 public static String getStringDouble(double Num, double NegativeThreshold, String ReplacePositive, String ReplaceNegative){
  if(Num<=NegativeThreshold){return ReplaceNegative;}
  else{return ReplacePositive;}
 }
 public static String getString(boolean Bool, String TrueValue, String FalseValue){
  if(Bool){return TrueValue;}
  else{return FalseValue;}
 }
 public static String getString(int Index, int IndexOfTrue, int IndexOfFalse, String TrueValue, String FalseValue,
  String UndefinedValue){
  if(Index==IndexOfTrue){return TrueValue;}
  if(Index==IndexOfFalse){return FalseValue;}
  return UndefinedValue;
 }
 public static String getStringWithQuote(String obj, String ReplaceNull, char Quote, boolean ActEmptyStringAsNull){
  if(obj==null){return ReplaceNull;}
  else{
   if(ActEmptyStringAsNull){
    if(obj.length()==0){return ReplaceNull;}
   }
  }
  return Quote+obj+Quote;
 }

 // generate string from list
 public static String toString(Object[] Arr, int StartIndex, int Count, String Separator){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  String str=null;
  
  if(Arr==null){return ret.toString();}
  if(Arr.length==0){return ret.toString();}
  
  first=true;
  until=StartIndex+Count;
  temp=StartIndex;
  do{
   if(first){first=false;}else{ret.append(Separator);}
   if(Arr[temp]==null){str=null;}else{str=Arr[temp].toString();}
   ret.append(str);
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }
 public static String toString(int[] Arr, int StartIndex, int Count, String Separator){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  
  if(Arr==null){return ret.toString();}
  if(Arr.length==0){return ret.toString();}
  
  first=true;
  until=StartIndex+Count;
  temp=StartIndex;
  do{
   if(first){first=false;}else{ret.append(Separator);}
   ret.append(Arr[temp]);
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }
 public static String toString(long[] Arr, int StartIndex, int Count, String Separator){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  
  if(Arr==null){return ret.toString();}
  if(Arr.length==0){return ret.toString();}
  
  first=true;
  until=StartIndex+Count;
  temp=StartIndex;
  do{
   if(first){first=false;}else{ret.append(Separator);}
   ret.append(Arr[temp]);
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }
 public static String toString(String[] Arr, int StartIndex, int Count, String Separator){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  
  if(Arr==null){return ret.toString();}
  if(Arr.length==0){return ret.toString();}
  
  first=true;
  until=StartIndex+Count;
  temp=StartIndex;
  do{
   if(first){first=false;}else{ret.append(Separator);}
   ret.append(Arr[temp]);
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }

 public static String toStringWithQuote(String[] Arr, int StartIndex, int Count, String Separator, String Quote, boolean WithSqlNormalize){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  String str;
  
  if(Arr==null){return ret.toString();}
  if(Arr.length==0){return ret.toString();}
  
  first=true;
  until=StartIndex+Count;
  temp=StartIndex;
  do{
   if(first){first=false;}else{ret.append(Separator);}
   str=Arr[temp]; if(WithSqlNormalize){str=PSql.norm(str);}
   ret.append(Quote+str+Quote);
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }
 public static String toStringWithQuote(Vector<Object[]> Vect, int StartIndex, int Count, String Separator,
  int[] ObjIndex, boolean[] ObjWithQuote, String ObjOpenColon, String ObjCloseColon, String ObjSeparator, String ObjQuote,
  String ReplaceObjNull, boolean ActEmptyStringAsNull){
  return toStringWithQuote(Vect, PCore.newIntegerArrayInOrderedSequence(Count, StartIndex, 1), Separator,
			ObjIndex, ObjWithQuote, ObjOpenColon, ObjCloseColon, ObjSeparator, ObjQuote,
   ReplaceObjNull, ActEmptyStringAsNull);
 }
 public static String toStringWithQuote(Vector<Object[]> Vect, int[] Index, String Separator,
  int[] ObjIndex, boolean[] ObjWithQuote, String ObjOpenColon, String ObjCloseColon, String ObjSeparator, String ObjQuote,
  String ReplaceObjNull, boolean ActEmptyStringAsNull){
  StringBuilder ret=new StringBuilder();
  boolean first;
  int until, temp;
  
  boolean objfirst;
  int objtemp, objcount, objindex, rowcurr, rowcount;
  Object[] Objs;
		String str;
  
  if(Vect==null){return ret.toString();}
  rowcount=Vect.size();
  if(rowcount==0){return ret.toString();}
  
  objcount=ObjIndex.length;
  
  first=true;
  until=Index.length;
  temp=0;
  do{
   rowcurr=Index[temp];
   if(rowcurr<rowcount){
    if(first){first=false;}else{ret.append(Separator);}
    Objs=Vect.elementAt(rowcurr);
    ret.append(ObjOpenColon);

    objfirst=true;
    objtemp=0;
    do{
     if(objfirst){objfirst=false;}else{ret.append(ObjSeparator);}
     objindex=ObjIndex[objtemp];
					str=getStringObj(Objs[objindex], ReplaceObjNull, ActEmptyStringAsNull);
     if(ObjWithQuote[objtemp]){ret.append(ObjQuote+str+ObjQuote);}else{ret.append(str);}
     objtemp=objtemp+1;
    }while(objtemp!=objcount);

    ret.append(ObjCloseColon);
   }
   temp=temp+1;
  }while(temp!=until);
  
  return ret.toString();
 }
 public static String toStringColsValues(String[] Cols, String[] Operators, String[] ColsValues, String[] Separators){
  /* The data count of Separators, Cols, Operators, ColsValues must be the same */
  String ret=null;
  StringBuilder strb;
  int temp, length;
  boolean success;
  
  if(Separators==null || Cols==null || Operators==null || ColsValues==null){return ret;}
  length=Cols.length;
  if(Operators.length!=length && ColsValues.length!=length && Separators.length!=length){return ret;}
  
  strb=new StringBuilder();
  success=false;
  do{
   if(length==0){success=true; break;}
   
   temp=0;
   do{
    strb.append(Separators[temp]);
    strb.append(Cols[temp]);
    strb.append(Operators[temp]);
    strb.append(ColsValues[temp]);
    
    temp=temp+1;
   }while(temp!=length);
   if(temp!=length){break;}
   
   success=true;
  }while(false);
  
  if(success){ret=strb.toString();}
  return ret;
 }
 
 public static String[] modify(String[] Words, String[] PreWords, String[] PostWords){
  String[] ret=null;
  int temp, length;
  
  if(Words==null){return ret;}
  
  length=Words.length;
  ret=new String[length];
  if(length==0){return ret;}
  
  temp=0;
  do{
   ret[temp]=PreWords[temp]+Words[temp]+PostWords[temp];
   
   temp=temp+1;
  }while(temp!=length);
  
  return ret;
 }
 
 public static int parsing(String Word, int Offset, boolean ParsingForward, boolean ParsingUntilFoundChars, char[] Chars){
  int ret=-1;
  int length, temp, end, add;
  
  length=0; if(Word!=null){length=Word.length();}
  if(length==0 || (ParsingForward && Offset>=length) || (!ParsingForward && Offset<=-1)){return ret;}
  
  temp=Offset; if(ParsingForward){end=length; add=1;}else{end=-1; add=-1;}
  do{
   if((findElement(Chars, Word.charAt(temp))!=-1)==ParsingUntilFoundChars){ret=temp; break;}
   temp=temp+add;
  }while(temp!=end);
  
  return ret;
 }
 public static String checkSide(String Word,
  int CheckSide, String Check, boolean CheckCaseSensitive, boolean Parsing_IgnoreWhiteChar,
  int IfFound_ProcessMode, String IfFound_ProcessText,
  int IfNotFound_ProcessMode, String IfNotFound_ProcessText,
  boolean Return_Trimmed){
  /*
   CheckSide = 1 left, 2 right, ? both left & right
   IfNotFound_ProcessMode = 1 insert
   IfFound_ProcessMode = 1 insert, 2 insert-in-front, 3 replace
  */
  StringBuilder ret=new StringBuilder();
  int length, checklength;
  int pos_left, pos_right;
  boolean found_left, found_right;
  String w;
  
  boolean move_mid_left, move_mid_right;
  int pos1, pos2;
  
  w=Word; if(w==null){w="";}
  length=w.length();
  checklength=Check.length();
  
  // define pos
  pos_left=0;
  if(CheckSide!=2 && Parsing_IgnoreWhiteChar){
   pos_left=parsing(w, 0, true, false, CCore.Chars_WhiteChar); if(pos_left==-1){pos_left=length;}
  }
  
  pos_right=length;
  if(CheckSide!=1 && Parsing_IgnoreWhiteChar && pos_left!=length){
   pos_right=parsing(w, length-1, false, false, CCore.Chars_WhiteChar); if(pos_right==-1){pos_right=length;}
  }
  
  // define found
  found_left=false; if(CheckSide!=2){found_left=compare(w, pos_left, Check, CheckCaseSensitive);}
  found_right=false; if(CheckSide!=1){found_right=compare(w, pos_right-checklength+1, Check, CheckCaseSensitive);}
  
  // add left's trailing white-char
  if(pos_left!=0 && !Return_Trimmed){ret.append(subString(w, 0, pos_left-1));}
  
  // process left
  if(CheckSide!=2){
   if(!found_left){
    // insert process-text
    if(IfNotFound_ProcessMode==1){
     ret.append(IfNotFound_ProcessText);
    }
   }
   else{
    // insert found
    if(IfFound_ProcessMode==2){
     ret.append(Check);
    }
    // insert process-text
    if(IfFound_ProcessMode==1 || IfFound_ProcessMode==2 || IfFound_ProcessMode==3){
     ret.append(IfFound_ProcessText);
    }
   }
  }
  
  // add middle
  if(pos_left!=length){
   move_mid_left=false;
   if(found_left){
    if(IfFound_ProcessMode==2 || IfFound_ProcessMode==3){move_mid_left=true;}
   }
   move_mid_right=false;
   if(found_right){
    if(IfFound_ProcessMode==2 || IfFound_ProcessMode==3){move_mid_right=true;}
   }
   pos1=pos_left; if(move_mid_left){pos1=pos1+checklength;}
   pos2=pos_right; if(move_mid_right){pos2=pos2-checklength;}
   if(pos1<=pos2){ret.append(subString(w, pos1, pos2));}
  }
  
  // process right
  if(CheckSide!=1){
   if(!found_right){
    // insert process-text
    if(IfNotFound_ProcessMode==1){
     ret.append(IfNotFound_ProcessText);
    }
   }
   else{
    // insert process-text
    if(IfFound_ProcessMode==1 || IfFound_ProcessMode==2 || IfFound_ProcessMode==3){
     ret.append(IfFound_ProcessText);
    }
    // insert found
    if(IfFound_ProcessMode==2){
     ret.append(Check);
    }
   }
  }
  
  // add right's tailing white-char
  if(pos_right<length-1 && !Return_Trimmed){ret.append(subString(w, pos_right+1, length-1));}
  
  return ret.toString();
 }
 
 public static String precedeWithEscapeChar(String Word, char[] CharsRequireEscapeChar, char EscapeChar){
  String ret=Word;
  StringBuilder strb=null;
  int temp, length;
  boolean IsThere;
  char curr_wordch;
  
  if(Word==null){return ret;}
  
  length=Word.length();
  if(length==0){return ret;}
  
  IsThere=false;
  strb=new StringBuilder();
  temp=0;
  do{
   curr_wordch=Word.charAt(temp);
   if(findElement(CharsRequireEscapeChar, curr_wordch)!=-1){strb.append(EscapeChar); IsThere=true;}
   strb.append(curr_wordch);
   temp=temp+1;
  }while(temp!=length);
  if(IsThere){ret=strb.toString();}
  
  return ret;
 }

 // other
 public static String getRandom(Object[] Value){
  int count;
  Object Obj;
  
  if(Value==null){return null;}
  
  count=Value.length;
  if(count==0){return null;}
  
  Obj=Value[PCore.getRandomIndex(count)];
  if(Obj==null){return null;}
  
  return Obj.toString();
 }

 public static void printArray(Object[] Data){
  int temp=0;
  if(Data==null){return;}
  if(Data.length==0){return;}
  do{
   System.out.println(Data[temp]);
   temp=temp+1;
  }while(temp!=Data.length);
 }
 public static void printArray(String[] Data){
  int temp=0;
  if(Data==null){return;}
  if(Data.length==0){return;}
  do{
   System.out.println(Data[temp]);
   temp=temp+1;
  }while(temp!=Data.length);
 }
 public static void printVectorObj(Vector<Object> Data){
  int temp=0;
  int temp2;
  if(Data==null){return;}
  temp2=Data.size();
  if(temp2==0){return;}
  do{
   System.out.println(Data.elementAt(temp));
   temp=temp+1;
  }while(temp!=temp2);
 }
 public static void printVectorStr(Vector<String> Data){
  int temp=0;
  int temp2;
  if(Data==null){return;}
  temp2=Data.size();
  if(temp2==0){return;}
  do{
   System.out.println(Data.elementAt(temp));
   temp=temp+1;
  }while(temp!=temp2);
 }
 
 public static String concat(String ReturnIfWordsNull, String ConcatIfWordNull, String... Words){
  StringBuilder ret;
  int temp, length;
  
  if(Words==null){return ReturnIfWordsNull;}
  
  ret=new StringBuilder();
  length=Words.length;
  
  if(length!=0){
   temp=0;
   do{
    if(Words[temp]==null){ret.append(ConcatIfWordNull);}
    else{ret.append(Words[temp]);}
    temp=temp+1;
   }while(temp!=length);
  }
  
  return ret.toString();
 }

 public static String trim(String Word, String ReturnIfWordIsNull, int TrimMode, char[] TrimChars){
  // TrimMode = 1 left, 2 right, 3 both left & right
  String ret=Word;
  int word_length, result_length;
  int pos_left, pos_right, end_pos;
  
  do{
   if(Word==null){ret=ReturnIfWordIsNull; break;}
   word_length=Word.length(); if(word_length==0){break;}
   
   pos_left=0; pos_right=word_length-1;
   
   // start trimming
   do{
    // trim left
    if(TrimMode==1 || TrimMode==3){
     end_pos=word_length;
     do{
      if(findElement(TrimChars, Word.charAt(pos_left))==-1){break;}
      pos_left=pos_left+1;
     }while(pos_left!=end_pos);
    }
    if(pos_left>=pos_right){break;}

    // trim right
    if(TrimMode==2 || TrimMode==3){
     end_pos=-1;
     do{
      if(findElement(TrimChars, Word.charAt(pos_right))==-1){break;}
      pos_right=pos_right-1;
     }while(pos_right!=end_pos);
    }
    if(pos_right<=pos_left){break;}
   }while(false);
   // end trimming
   
   result_length=(pos_right-pos_left)+1;
   if(result_length==word_length){break;}
   if(result_length==0){ret=""; break;}
   ret=subString(Word, pos_left, pos_right);
  }while(false);
  
  return ret;
 }

}