public class CMath {
 public static final int Add=1;
 public static final int Minus=2;
 public static final int Times=3;
 public static final int Divide=4;
 public static final int Mod=5;
 
 public static final int AddMinus=1;
 public static final int TimesDivide=2;
}