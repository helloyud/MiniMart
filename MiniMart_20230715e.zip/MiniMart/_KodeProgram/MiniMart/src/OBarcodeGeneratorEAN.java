public class OBarcodeGeneratorEAN
 implements OBarcodeGenerator{
 
 static final int Ean08_Length=8;
 static final int Ean13_Length=13;
 
 public static int[] getSupportedEanLength(){return PCore.primArr(Ean08_Length, Ean13_Length);}
 public static int calculateCodeChecksum(String Code, int EanLength){
  int ret=-1;
  int weight, sum;
  int temp;
  int CalculateLength=EanLength-1;
  
  if(Code.length()<CalculateLength){return ret;}
  
  sum=0;
  temp=0;
  do{
   weight=Code.charAt(temp)-48; if((CalculateLength-temp)%2==1){weight=weight*3;}
   sum=sum+weight;
   temp=temp+1;
  }while(temp!=CalculateLength);
  ret=(10-(sum%10))%10;
  
  return ret;
 }
 public static int calculateCodeChecksum(long Code, int EanLength){
  return calculateCodeChecksum(PText.paddingNumber(Code, EanLength), EanLength);
 }
 public static boolean checkCodeValidity(String Code, int EanLength){
  boolean ret=false;
  int last_digit, checksum;
  
  do{
   if(Code.length()!=EanLength){break;}
   
   last_digit=Code.charAt(EanLength-1)-48; checksum=calculateCodeChecksum(Code, EanLength);
   if(last_digit!=checksum){break;}
   
   ret=true;
  }while(false);
  
  return ret;
 }
 public static boolean checkCodeValidity(long Code, int EanLength){
  return checkCodeValidity(PText.paddingNumber(Code, EanLength), EanLength);
 }
 public static int generateChecksum(long Number, int EanLength){
  return calculateCodeChecksum(PText.paddingNumber(Number, EanLength-1), EanLength);
 }
 public static long generateCompatibleBarcodeFromNumber(long Number, int EanLength){
  // manual choose ean-series by specific 'EanLength'
  long ret=-1;
  String StrNumber;
  int CalculateLength=EanLength-1;
  
  StrNumber=PText.paddingNumber(Number, CalculateLength);
  if(StrNumber.length()!=CalculateLength){return ret;}
  
  ret=(Number*10)+calculateCodeChecksum(StrNumber, EanLength);
  
  return ret;
 }
 
 public long generateCompatibleBarcodeFromNumber(long Number){
  // automatic choose ean-series by prefering the shortest length
  long ret=-1;
  int EanLength, CalculateLength, NumberLength, temp;
  int[] SupportedEanLength=getSupportedEanLength();
  
  NumberLength=String.valueOf(Number).length();
  temp=0;
  do{
   EanLength=SupportedEanLength[temp]; CalculateLength=EanLength-1;
   if(CalculateLength>=NumberLength){break;}
   temp=temp+1;
  }while(temp!=SupportedEanLength.length);
  if(temp==SupportedEanLength.length){return ret;}
  
  ret=generateCompatibleBarcodeFromNumber(Number, EanLength);
  
  return ret;
 }
 public long generateCompatibleBarcodeFromNumberGetErrorSign(){return -1;}
 public String generateCompatibleBarcodeFromText(String Text){return null;}
 public String generateCompatibleBarcodeFromTextGetErrorSign(){return null;}
 
}