import javax.print.PrintService;

class OConfiguration{

 String Host; boolean HostDefined;
 int Port; boolean PortDefined;
 String User; boolean UserDefined;
 String Password; boolean PasswordDefined;
 
 String DefaultDatabase; boolean DefaultDatabaseDefined;
 
 String ImageDirItem; boolean ImageDirItemDefined;
 String ImageDirSubject; boolean ImageDirSubjectDefined;
 
 OPaper DefaultReceiptPaper; boolean DefaultReceiptPaperDefined;
 PrintService DefaultReceiptPrinter; boolean DefaultReceiptPrinterDefined;
 OPaper DefaultReportPaper; boolean DefaultReportPaperDefined;
 PrintService DefaultReportPrinter; boolean DefaultReportPrinterDefined;
 
 OPaperMargin ThermalPaperMargin;
 boolean ThermalPaperMarginTopDefined;
 boolean ThermalPaperMarginBottomDefined;
 boolean ThermalPaperMarginLeftDefined;
 boolean ThermalPaperMarginRightDefined;
 
 OPaperMargin StandardPaperMargin;
 boolean StandardPaperMarginTopDefined;
 boolean StandardPaperMarginBottomDefined;
 boolean StandardPaperMarginLeftDefined;
 boolean StandardPaperMarginRightDefined;
 
 String ApplicationTitle; boolean ApplicationTitleDefined;
 boolean ItemCategorized; boolean ItemCategorizedDefined;

 public OConfiguration(
  String Host, int Port, String User, String Password,
  String DefaultDatabase,
  String ImageDirItem,
  String ImageDirSubject,
  String ApplicationTitle,
  boolean ItemCategorized,
  OPaper DefaultReportPaper, PrintService DefaultReportPrinter,
  OPaper DefaultReceiptPaper, PrintService DefaultReceiptPrinter,
  OPaperMargin StandardPaperMargin,
  OPaperMargin ThermalPaperMargin) {
  this.Host = Host; HostDefined = false;
  this.Port = Port; PortDefined = false;
  this.User = User; UserDefined = false;
  this.Password = Password; PasswordDefined = false;
  
  this.DefaultDatabase = DefaultDatabase; DefaultDatabaseDefined = false;
  
  this.ImageDirItem = ImageDirItem; ImageDirItemDefined = false;
  this.ImageDirSubject = ImageDirSubject; ImageDirSubjectDefined = false;
  
  this.ApplicationTitle = ApplicationTitle; ApplicationTitleDefined = false;
  this.ItemCategorized = ItemCategorized; ItemCategorizedDefined=false;
  
  this.DefaultReportPaper = DefaultReportPaper; DefaultReportPaperDefined = false;
  this.DefaultReportPrinter = DefaultReportPrinter; DefaultReportPrinterDefined = false;
  
  this.DefaultReceiptPaper = DefaultReceiptPaper; DefaultReceiptPaperDefined = false;
  this.DefaultReceiptPrinter = DefaultReceiptPrinter; DefaultReceiptPrinterDefined = false;
  
  this.StandardPaperMargin = StandardPaperMargin;
  StandardPaperMarginTopDefined = false;
  StandardPaperMarginBottomDefined = false;
  StandardPaperMarginLeftDefined = false;
  StandardPaperMarginRightDefined = false;
  
  this.ThermalPaperMargin = ThermalPaperMargin;
  ThermalPaperMarginTopDefined = false;
  ThermalPaperMarginBottomDefined = false;
  ThermalPaperMarginLeftDefined = false;
  ThermalPaperMarginRightDefined = false;
 }

}