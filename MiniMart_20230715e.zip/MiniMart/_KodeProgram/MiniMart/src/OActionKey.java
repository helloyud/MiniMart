import java.awt.Component;
import java.awt.Window;
import java.awt.event.KeyEvent;

public abstract class OActionKey extends OAction {
 
 Window Form;
 Component Cmp;
 KeyEvent evt;

 OActionKey init(Window Form, Component Cmp, KeyEvent evt) {
  this.Form = Form;
  this.Cmp = Cmp;
  this.evt = evt;
  return this;
 }
 
 public abstract int doAction();
 
}