import java.util.Vector;
import javax.swing.AbstractSpinnerModel;

public class OCustomSpinnerModelList extends AbstractSpinnerModel {

 Vector<Object> Data;
 int ElementsCount;
 int CurrSelection;
 
 public OCustomSpinnerModelList(Vector<Object> NewData, int NewSelection) {
  initVariables();
  setVariables(NewData, NewSelection);
 }
 void initVariables(){
  Data=new Vector();
  ElementsCount=0;
  
  CurrSelection=0;
 }
 public void setVariables(Vector<Object> NewData, int NewSelection){
  setData(NewData);
  if(!setSelection(NewSelection)){CurrSelection=0;}
 }
 public void changeVariables(Vector<Object> NewData, int NewSelection){
  setVariables(NewData, NewSelection);
  fireStateChanged();
 }
 
 public void setData(Vector<Object> NewData){
  int temp, count;
  
  Data.removeAllElements();
  
  do{
   if(NewData==null){break;}
   count=NewData.size();
   if(count==0){break;}
   temp=0;
   do{
    Data.addElement(NewData.elementAt(temp));
    temp=temp+1;
   }while(temp!=count);
  }while(false);
  
  ElementsCount=Data.size();
 }
 public boolean setSelection(int NewSelection){
  boolean ret=false;
  
  if(ElementsCount==0 || NewSelection<0 || NewSelection>ElementsCount-1){return ret;}
  
  CurrSelection=NewSelection;
  ret=true;
  
  return ret;
 }
 public void changeSelection(int NewSelection){
  if(!setSelection(NewSelection)){return;}
  fireStateChanged();
 }

 public Object getNextValue() {
  Object ret=null;
  
  if(ElementsCount==0){return ret;}
  
  if(CurrSelection!=ElementsCount-1){CurrSelection=CurrSelection+1;}
  ret=Data.elementAt(CurrSelection);
  
  return ret;
 }
 public Object getPreviousValue() {
  Object ret=null;
  
  if(ElementsCount==0){return ret;}
  
  if(CurrSelection!=0){CurrSelection=CurrSelection-1;}
  ret=Data.elementAt(CurrSelection);
  
  return ret;
 }
 public Object getValue() {
  Object ret=null;
  
  if(ElementsCount==0){return ret;}
  
  ret=Data.elementAt(CurrSelection);
  
  return ret;
 }
 public void setValue(Object value) {}
 
}