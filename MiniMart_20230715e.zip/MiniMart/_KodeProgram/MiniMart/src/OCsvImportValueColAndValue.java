import java.util.Vector;

public class OCsvImportValueColAndValue extends OCsvImportValue {
 
 String Column;
 String OperatorBetweenColumnAndColumnValue;
 OCsvImportValue ColumnValue;

 public OCsvImportValueColAndValue(String Column, String OperatorBetweenColumnAndColumnValue, OCsvImportValue ColumnValue) {
  initVariables(Column, OperatorBetweenColumnAndColumnValue, ColumnValue);
 }
 
 protected void initVariables(String Column, String OperatorBetweenColumnAndColumnValue, OCsvImportValue ColumnValue){
  this.Column=Column;
  this.OperatorBetweenColumnAndColumnValue=OperatorBetweenColumnAndColumnValue;
  this.ColumnValue=ColumnValue;
 }
 
 public void prepareGenerateSQLValue(Vector<String> LastReadRecordFromFile){
  preGenerateSQLValue(LastReadRecordFromFile);
  ColumnValue.prepareGenerateSQLValue(LastReadRecordFromFile);
 }
 
 public OGeneratedSQLValue generateSQLValue(){
  OGeneratedSQLValue ret=new OGeneratedSQLValue();
  OGeneratedSQLValue AColumnValue;
  
  AColumnValue=ColumnValue.generateSQLValue();
  if(AColumnValue.isGenerated()){ret.setGeneratedSQLValue(Column+OperatorBetweenColumnAndColumnValue+AColumnValue.getGeneratedSQLValue());}
  
  return ret;
 }
 
}