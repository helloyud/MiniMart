import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Vector;

public class OLabelCreatorItemMiniPriceTagB_Barcode1 extends OLabelCreatorItem {
 
 
 
 
 
 public static ODimension getDimensionByCharacters(Font Fn, int RowsCount, int ColumnsCount, double MarginHorizontal, double MarginVertical, double TextAddLineSpacing){
  return PGraphics.getDimension(Fn, RowsCount, ColumnsCount, MarginHorizontal, MarginVertical, TextAddLineSpacing);
 }
 
 
 
 
 
 double Area1_X, Area1_Y, Area1_Width, Area1_Height, Area1_WidthMin, Area1_HeightMin;
 
 final double BarcodeHeightMin=CGraph.BarcodeHeightMin+OUnit.mm_to_pixel(1.5);
 double BarcodeBoxY;
 double BarcodeBoxAreaHeight;
 
 final double SpaceArea1ToArea2=OUnit.mm_to_pixel(0.6);
 
 double Area2_X, Area2_Y, Area2_Width, Area2_Height, Area2_WidthMin, Area2_HeightMin;

 
 
 
 
 public OLabelCreatorItemMiniPriceTagB_Barcode1(OFont FontStandard, OFontLayout FontStandardIdealLayout, OFont FontCustom,
  OPaperMargin MgSt, OPaperMargin MgTher){
  
  super.init(FontStandard, FontStandardIdealLayout, FontCustom, MgSt, MgTher);
  
  BoxWidthMin=
   2*MarginHorizontal+
   PCore.getMinMax_Double(false, PCore.refArr(Area1_WidthMin, Area2_WidthMin));
  
  BoxHeightMin=
   2*MarginVertical+
   Area1_HeightMin+
   SpaceArea1ToArea2+
   Area2_HeightMin;
 }
 protected void initDrawComponentsVariables(){
  ODimension dim;
  
  super.initDrawComponentsVariables();
  TextLineSpacing=OUnit.mm_to_pixel(0.3);
  
  ColumnsCountMin=20;
  ColumnsCountMax=120;
  RowsCountMin=1;
  RowsCountMax=6;
  
  dim=getDimensionByCharacters(Fon, RowsCountMin, ColumnsCountMin, 0, 0, TextLineSpacing);
  
  Area1_WidthMin=CGraph.BarcodeWidthMax;
  Area1_HeightMin=BarcodeHeightMin;
  
  Area2_WidthMin=dim.Width;
  Area2_HeightMin=dim.Height;
 }
 protected String getName(){return "Price Tag) Mini B (Barcode I)";}
 protected Vector<OPaper> getInternalPapers(){
  Vector<OPaper> ret=new Vector();
  OPaper papr;
  ODimension dim, LabelSize;
  Vector<OPaperInfoMiniPriceTag2> Formats;
  OPaperInfoMiniPriceTag2 CurrFormat;
  int temp, count;
  int rowstart, rowadd, rowaddcount, colstart, coladd, coladdcount;
  int rowaddcurr, coladdcurr;
  
  Formats=new Vector();
  
  rowstart=RowsCountMin; rowadd=1; rowaddcount=6;
  colstart=ColumnsCountMin; coladd=5; coladdcount=12;
  
  rowaddcurr=0;
  do{
   coladdcurr=0;
   do{
    Formats.addElement(new OPaperInfoMiniPriceTag2(rowstart+(rowadd*rowaddcurr), colstart+(coladd*coladdcurr), false));
    coladdcurr=coladdcurr+1;
   }while(coladdcurr!=coladdcount);
   rowaddcurr=rowaddcurr+1;
  }while(rowaddcurr!=rowaddcount);
  
  count=Formats.size();
  
  // A4 Half
  temp=0;
  do{
   CurrFormat=Formats.elementAt(temp);
   
   papr=CPrint.A4Half.cloneWithMargin(MgSt);

   dim=getDimensionByCharacters(Fon, CurrFormat.RowsCount, CurrFormat.ColumnsCount, 0, 0, TextLineSpacing);
   LabelSize=new ODimension(2*MarginHorizontal+PCore.getMinMax_Double(false, PCore.refArr(dim.getWidth(), Area1_WidthMin)),
    2*MarginVertical+Area1_HeightMin+SpaceArea1ToArea2+dim.getHeight());
   CurrFormat.IsRotated=PGraphics.gradingLabelCount(papr.RealImageableWidth, papr.RealImageableHeight,
    0, 0, 0, LabelSize.getWidth(), LabelSize.getHeight(), LabelSize.getHeight(), LabelSize.getWidth(), papr.IsRollPaper, true, false, true)==2;

   papr.Description=papr.Description+" {"+CurrFormat.RowsCount+" x "+CurrFormat.ColumnsCount+"}";
   papr.setAdditionalInfo(CurrFormat);

   if(!CurrFormat.IsRotated){ret.addElement(new OPaperLabel(papr, LabelSize.getWidth(), LabelSize.getHeight(), 0, 0, 0, false, true, true, true, false));}
   else{ret.addElement(new OPaperLabel(papr, LabelSize.getHeight(), LabelSize.getWidth(), 0, 0, 0, false, true, true, true, false));}
   
   temp=temp+1;
  }while(temp!=count);
  
  return ret;
 }
 protected int getDefaultInternalPaper(){return 39-1;}
 
 
 
 
 
 protected boolean supportCustomPaperLabel(){return true;}
 protected int getDefaultOrientation(){return CPrint.LandscapeOrientation;}
 protected ODefMinMax getLabelWidthRange(){return new ODefMinMax(0, BoxWidthMin, Double.MAX_VALUE);}
 protected ODefMinMax getLabelHeightRange(){return new ODefMinMax(0, BoxHeightMin, Double.MAX_VALUE);}
 protected boolean defineInternalPaperLabelRotationManually(){return true;}
 protected boolean isLabelRotatedInternalPaper(){return ((OPaperInfoMiniPriceTag2)Papr.AdditionalInfo).IsRotated;}
 protected boolean scaleBoxToFitWithLabel(){return true;}
 protected boolean genLayoutVariables(){
  boolean ret=true;
  OPaperInfoMiniPriceTag2 Format=null;
  ODimensionAbsolute rowcol_count;
  ODimension dim;
  int it;
  
  if(!Papr.IsCustomPaperLabel){Format=(OPaperInfoMiniPriceTag2)Papr.AdditionalInfo;}
  
  Area2_Width=LabelWidth-2*MarginHorizontal;
  Area2_Height=LabelHeight-(2*MarginVertical+Area1_HeightMin+SpaceArea1ToArea2);
  if(Area2_Width<=0 || Area2_Height<=0){return false;}

  rowcol_count=PGraphics.calculateLabelColumnAndRowCount(Area2_Width, Area2_Height,
   0, 0, TextLineSpacing, TextWidth, TextHeight, false);
  if(rowcol_count.RowsCount>RowsCountMax){rowcol_count.RowsCount=RowsCountMax;}
  if(rowcol_count.ColumnsCount>ColumnsCountMax){rowcol_count.ColumnsCount=ColumnsCountMax;}
  
  it=0; if(!Papr.IsCustomPaperLabel){it=Format.RowsCount;}
  RowsCount=PCore.getMinMax_Integer(false, PCore.refArr(it, rowcol_count.RowsCount));
  it=0; if(!Papr.IsCustomPaperLabel){it=Format.ColumnsCount;}
  ColumnsCount=PCore.getMinMax_Integer(false, PCore.refArr(it, rowcol_count.ColumnsCount)); 
  if(RowsCount==0 || ColumnsCount==0){return false;}
  
  dim=getDimensionByCharacters(Fon, RowsCount, ColumnsCount, 0, 0, TextLineSpacing);
  
  Area1_X=MarginHorizontal;
  Area1_Y=MarginVertical;
  
  BarcodeBoxY=Area1_Y;
  BarcodeBoxAreaHeight=LabelHeight-(2*MarginVertical+dim.getHeight()+SpaceArea1ToArea2);
  if(BarcodeBoxAreaHeight>CGraph.BarcodeHeightMax){BarcodeBoxAreaHeight=CGraph.BarcodeHeightMax;}
  if(BarcodeBoxAreaHeight<=0){return false;}
  
  Area1_Height=BarcodeBoxAreaHeight;
  
  Area2_X=MarginHorizontal;
  Area2_Y=Area1_Y+Area1_Height+SpaceArea1ToArea2;
  Area2_Height=dim.getHeight();
  
  BoxWidth=2*MarginHorizontal+PCore.getMinMax_Double(false, PCore.refArr(dim.getWidth(), Area1_WidthMin)); if(BoxWidth>LabelWidth){BoxWidth=LabelWidth;}
  Area1_Width=BoxWidth-2*MarginHorizontal;
  Area2_Width=BoxWidth-2*MarginHorizontal;
  
  BoxHeight=2*MarginVertical+Area1_Height+SpaceArea1ToArea2+Area2_Height;
  
  return ret;
 }
 
 
 
 
 
 protected void draw(Graphics2D g, double AlreadyScaled){
  OLabelDataItem Data;
  OBarcodePatterns patt;
  Vector<String> strv;
  String str;
  int temp, count;
  double CurrY;
  
  g.setFont(Fon);
  
  Data=(OLabelDataItem)LabelData;
  
  patt=PMyShop.patternize(Data.ItemId);
  if(patt!=null){
   PGraphics.paintImageInBox(g, Scaled_BoxX+Area1_X, Scaled_BoxY+BarcodeBoxY,
    PGraphics.cropHeightBarcode(true, patt.getBufferedImage(BarcodeBoxAreaHeight, Scaling*AlreadyScaled), Area1_Width*Scaling*AlreadyScaled, BarcodeBoxAreaHeight*Scaling*AlreadyScaled),
    true, null, 1, CGraph.Rotate_000Degree, Area1_Width, BarcodeBoxAreaHeight, null, false);
  }
  
  str="("+Data.ItemId+") "+Data.ItemName+" - "+PText.priceToString(Data.ItemSellPrice)+
   PText.getString(Data.PromoComment, "", " ("+Data.PromoComment+")", true);
  if(RowsCount==1){
   strv=PCore.vect(PText.fitString(str, ColumnsCount, true, ColumnsCount/2, 1, '~'));
  }
  else{
   strv=PText.fitMultiLine(PText.multiLine(str, ColumnsCount), RowsCount, true, RowsCount/2, ColumnsCount, true, ColumnsCount/2, 1, '~');
  }
  
  count=strv.size();
  CurrY=Area2_Y+(PGraphics.getInsetY(Area2_Height, Fon, count, TextLineSpacing, OAlignment.VerticalCenter));
  temp=0;
  do{
   if(temp!=0){CurrY=CurrY+TextLineSpacing;}
   
   str=strv.elementAt(temp);
   g.drawString(str, (float)(Scaled_BoxX+Area2_X+PGraphics.getInsetX(Area2_Width, Fon, str, OAlignment.HorizontalCenter)), (float)(Scaled_BoxY+CurrY+TextAscent));
   CurrY=CurrY+TextHeight;
   
   temp=temp+1;
  }while(temp!=count);
 }
 
 
 
 
 
}